/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const W = globalThis, he = W.ShadowRoot && (W.ShadyCSS === void 0 || W.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, ue = Symbol(), ke = /* @__PURE__ */ new WeakMap();
let qe = class {
  constructor(e, t, s) {
    if (this._$cssResult$ = !0, s !== ue) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = e, this.t = t;
  }
  get styleSheet() {
    let e = this.o;
    const t = this.t;
    if (he && e === void 0) {
      const s = t !== void 0 && t.length === 1;
      s && (e = ke.get(t)), e === void 0 && ((this.o = e = new CSSStyleSheet()).replaceSync(this.cssText), s && ke.set(t, e));
    }
    return e;
  }
  toString() {
    return this.cssText;
  }
};
const ct = (i) => new qe(typeof i == "string" ? i : i + "", void 0, ue), y = (i, ...e) => {
  const t = i.length === 1 ? i[0] : e.reduce((s, n, a) => s + ((r) => {
    if (r._$cssResult$ === !0) return r.cssText;
    if (typeof r == "number") return r;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + r + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(n) + i[a + 1], i[0]);
  return new qe(t, i, ue);
}, dt = (i, e) => {
  if (he) i.adoptedStyleSheets = e.map((t) => t instanceof CSSStyleSheet ? t : t.styleSheet);
  else for (const t of e) {
    const s = document.createElement("style"), n = W.litNonce;
    n !== void 0 && s.setAttribute("nonce", n), s.textContent = t.cssText, i.appendChild(s);
  }
}, we = he ? (i) => i : (i) => i instanceof CSSStyleSheet ? ((e) => {
  let t = "";
  for (const s of e.cssRules) t += s.cssText;
  return ct(t);
})(i) : i;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: ht, defineProperty: ut, getOwnPropertyDescriptor: pt, getOwnPropertyNames: mt, getOwnPropertySymbols: ft, getPrototypeOf: gt } = Object, G = globalThis, xe = G.trustedTypes, bt = xe ? xe.emptyScript : "", vt = G.reactiveElementPolyfillSupport, P = (i, e) => i, se = { toAttribute(i, e) {
  switch (e) {
    case Boolean:
      i = i ? bt : null;
      break;
    case Object:
    case Array:
      i = i == null ? i : JSON.stringify(i);
  }
  return i;
}, fromAttribute(i, e) {
  let t = i;
  switch (e) {
    case Boolean:
      t = i !== null;
      break;
    case Number:
      t = i === null ? null : Number(i);
      break;
    case Object:
    case Array:
      try {
        t = JSON.parse(i);
      } catch {
        t = null;
      }
  }
  return t;
} }, We = (i, e) => !ht(i, e), ze = { attribute: !0, type: String, converter: se, reflect: !1, useDefault: !1, hasChanged: We };
Symbol.metadata ??= Symbol("metadata"), G.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
let E = class extends HTMLElement {
  static addInitializer(e) {
    this._$Ei(), (this.l ??= []).push(e);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(e, t = ze) {
    if (t.state && (t.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(e) && ((t = Object.create(t)).wrapped = !0), this.elementProperties.set(e, t), !t.noAccessor) {
      const s = Symbol(), n = this.getPropertyDescriptor(e, s, t);
      n !== void 0 && ut(this.prototype, e, n);
    }
  }
  static getPropertyDescriptor(e, t, s) {
    const { get: n, set: a } = pt(this.prototype, e) ?? { get() {
      return this[t];
    }, set(r) {
      this[t] = r;
    } };
    return { get: n, set(r) {
      const o = n?.call(this);
      a?.call(this, r), this.requestUpdate(e, o, s);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(e) {
    return this.elementProperties.get(e) ?? ze;
  }
  static _$Ei() {
    if (this.hasOwnProperty(P("elementProperties"))) return;
    const e = gt(this);
    e.finalize(), e.l !== void 0 && (this.l = [...e.l]), this.elementProperties = new Map(e.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(P("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(P("properties"))) {
      const t = this.properties, s = [...mt(t), ...ft(t)];
      for (const n of s) this.createProperty(n, t[n]);
    }
    const e = this[Symbol.metadata];
    if (e !== null) {
      const t = litPropertyMetadata.get(e);
      if (t !== void 0) for (const [s, n] of t) this.elementProperties.set(s, n);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [t, s] of this.elementProperties) {
      const n = this._$Eu(t, s);
      n !== void 0 && this._$Eh.set(n, t);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(e) {
    const t = [];
    if (Array.isArray(e)) {
      const s = new Set(e.flat(1 / 0).reverse());
      for (const n of s) t.unshift(we(n));
    } else e !== void 0 && t.push(we(e));
    return t;
  }
  static _$Eu(e, t) {
    const s = t.attribute;
    return s === !1 ? void 0 : typeof s == "string" ? s : typeof e == "string" ? e.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise((e) => this.enableUpdating = e), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((e) => e(this));
  }
  addController(e) {
    (this._$EO ??= /* @__PURE__ */ new Set()).add(e), this.renderRoot !== void 0 && this.isConnected && e.hostConnected?.();
  }
  removeController(e) {
    this._$EO?.delete(e);
  }
  _$E_() {
    const e = /* @__PURE__ */ new Map(), t = this.constructor.elementProperties;
    for (const s of t.keys()) this.hasOwnProperty(s) && (e.set(s, this[s]), delete this[s]);
    e.size > 0 && (this._$Ep = e);
  }
  createRenderRoot() {
    const e = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return dt(e, this.constructor.elementStyles), e;
  }
  connectedCallback() {
    this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$EO?.forEach((e) => e.hostConnected?.());
  }
  enableUpdating(e) {
  }
  disconnectedCallback() {
    this._$EO?.forEach((e) => e.hostDisconnected?.());
  }
  attributeChangedCallback(e, t, s) {
    this._$AK(e, s);
  }
  _$ET(e, t) {
    const s = this.constructor.elementProperties.get(e), n = this.constructor._$Eu(e, s);
    if (n !== void 0 && s.reflect === !0) {
      const a = (s.converter?.toAttribute !== void 0 ? s.converter : se).toAttribute(t, s.type);
      this._$Em = e, a == null ? this.removeAttribute(n) : this.setAttribute(n, a), this._$Em = null;
    }
  }
  _$AK(e, t) {
    const s = this.constructor, n = s._$Eh.get(e);
    if (n !== void 0 && this._$Em !== n) {
      const a = s.getPropertyOptions(n), r = typeof a.converter == "function" ? { fromAttribute: a.converter } : a.converter?.fromAttribute !== void 0 ? a.converter : se;
      this._$Em = n;
      const o = r.fromAttribute(t, a.type);
      this[n] = o ?? this._$Ej?.get(n) ?? o, this._$Em = null;
    }
  }
  requestUpdate(e, t, s, n = !1, a) {
    if (e !== void 0) {
      const r = this.constructor;
      if (n === !1 && (a = this[e]), s ??= r.getPropertyOptions(e), !((s.hasChanged ?? We)(a, t) || s.useDefault && s.reflect && a === this._$Ej?.get(e) && !this.hasAttribute(r._$Eu(e, s)))) return;
      this.C(e, t, s);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(e, t, { useDefault: s, reflect: n, wrapped: a }, r) {
    s && !(this._$Ej ??= /* @__PURE__ */ new Map()).has(e) && (this._$Ej.set(e, r ?? t ?? this[e]), a !== !0 || r !== void 0) || (this._$AL.has(e) || (this.hasUpdated || s || (t = void 0), this._$AL.set(e, t)), n === !0 && this._$Em !== e && (this._$Eq ??= /* @__PURE__ */ new Set()).add(e));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (t) {
      Promise.reject(t);
    }
    const e = this.scheduleUpdate();
    return e != null && await e, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
        for (const [n, a] of this._$Ep) this[n] = a;
        this._$Ep = void 0;
      }
      const s = this.constructor.elementProperties;
      if (s.size > 0) for (const [n, a] of s) {
        const { wrapped: r } = a, o = this[n];
        r !== !0 || this._$AL.has(n) || o === void 0 || this.C(n, void 0, a, o);
      }
    }
    let e = !1;
    const t = this._$AL;
    try {
      e = this.shouldUpdate(t), e ? (this.willUpdate(t), this._$EO?.forEach((s) => s.hostUpdate?.()), this.update(t)) : this._$EM();
    } catch (s) {
      throw e = !1, this._$EM(), s;
    }
    e && this._$AE(t);
  }
  willUpdate(e) {
  }
  _$AE(e) {
    this._$EO?.forEach((t) => t.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(e)), this.updated(e);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(e) {
    return !0;
  }
  update(e) {
    this._$Eq &&= this._$Eq.forEach((t) => this._$ET(t, this[t])), this._$EM();
  }
  updated(e) {
  }
  firstUpdated(e) {
  }
};
E.elementStyles = [], E.shadowRootOptions = { mode: "open" }, E[P("elementProperties")] = /* @__PURE__ */ new Map(), E[P("finalized")] = /* @__PURE__ */ new Map(), vt?.({ ReactiveElement: E }), (G.reactiveElementVersions ??= []).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const pe = globalThis, Ae = (i) => i, Y = pe.trustedTypes, _e = Y ? Y.createPolicy("lit-html", { createHTML: (i) => i }) : void 0, Ye = "$lit$", w = `lit$${Math.random().toFixed(9).slice(2)}$`, Ze = "?" + w, $t = `<${Ze}>`, S = document, H = () => S.createComment(""), L = (i) => i === null || typeof i != "object" && typeof i != "function", me = Array.isArray, yt = (i) => me(i) || typeof i?.[Symbol.iterator] == "function", Q = `[ 	
\f\r]`, N = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Se = /-->/g, Ce = />/g, A = RegExp(`>|${Q}(?:([^\\s"'>=/]+)(${Q}*=${Q}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Ee = /'/g, Te = /"/g, Ve = /^(?:script|style|textarea|title)$/i, Ge = (i) => (e, ...t) => ({ _$litType$: i, strings: e, values: t }), h = Ge(1), q = Ge(2), I = Symbol.for("lit-noChange"), p = Symbol.for("lit-nothing"), Me = /* @__PURE__ */ new WeakMap(), _ = S.createTreeWalker(S, 129);
function Xe(i, e) {
  if (!me(i) || !i.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return _e !== void 0 ? _e.createHTML(e) : e;
}
const kt = (i, e) => {
  const t = i.length - 1, s = [];
  let n, a = e === 2 ? "<svg>" : e === 3 ? "<math>" : "", r = N;
  for (let o = 0; o < t; o++) {
    const c = i[o];
    let l, d, u = -1, m = 0;
    for (; m < c.length && (r.lastIndex = m, d = r.exec(c), d !== null); ) m = r.lastIndex, r === N ? d[1] === "!--" ? r = Se : d[1] !== void 0 ? r = Ce : d[2] !== void 0 ? (Ve.test(d[2]) && (n = RegExp("</" + d[2], "g")), r = A) : d[3] !== void 0 && (r = A) : r === A ? d[0] === ">" ? (r = n ?? N, u = -1) : d[1] === void 0 ? u = -2 : (u = r.lastIndex - d[2].length, l = d[1], r = d[3] === void 0 ? A : d[3] === '"' ? Te : Ee) : r === Te || r === Ee ? r = A : r === Se || r === Ce ? r = N : (r = A, n = void 0);
    const g = r === A && i[o + 1].startsWith("/>") ? " " : "";
    a += r === N ? c + $t : u >= 0 ? (s.push(l), c.slice(0, u) + Ye + c.slice(u) + w + g) : c + w + (u === -2 ? o : g);
  }
  return [Xe(i, a + (i[t] || "<?>") + (e === 2 ? "</svg>" : e === 3 ? "</math>" : "")), s];
};
class U {
  constructor({ strings: e, _$litType$: t }, s) {
    let n;
    this.parts = [];
    let a = 0, r = 0;
    const o = e.length - 1, c = this.parts, [l, d] = kt(e, t);
    if (this.el = U.createElement(l, s), _.currentNode = this.el.content, t === 2 || t === 3) {
      const u = this.el.content.firstChild;
      u.replaceWith(...u.childNodes);
    }
    for (; (n = _.nextNode()) !== null && c.length < o; ) {
      if (n.nodeType === 1) {
        if (n.hasAttributes()) for (const u of n.getAttributeNames()) if (u.endsWith(Ye)) {
          const m = d[r++], g = n.getAttribute(u).split(w), C = /([.?@])?(.*)/.exec(m);
          c.push({ type: 1, index: a, name: C[2], strings: g, ctor: C[1] === "." ? xt : C[1] === "?" ? zt : C[1] === "@" ? At : X }), n.removeAttribute(u);
        } else u.startsWith(w) && (c.push({ type: 6, index: a }), n.removeAttribute(u));
        if (Ve.test(n.tagName)) {
          const u = n.textContent.split(w), m = u.length - 1;
          if (m > 0) {
            n.textContent = Y ? Y.emptyScript : "";
            for (let g = 0; g < m; g++) n.append(u[g], H()), _.nextNode(), c.push({ type: 2, index: ++a });
            n.append(u[m], H());
          }
        }
      } else if (n.nodeType === 8) if (n.data === Ze) c.push({ type: 2, index: a });
      else {
        let u = -1;
        for (; (u = n.data.indexOf(w, u + 1)) !== -1; ) c.push({ type: 7, index: a }), u += w.length - 1;
      }
      a++;
    }
  }
  static createElement(e, t) {
    const s = S.createElement("template");
    return s.innerHTML = e, s;
  }
}
function O(i, e, t = i, s) {
  if (e === I) return e;
  let n = s !== void 0 ? t._$Co?.[s] : t._$Cl;
  const a = L(e) ? void 0 : e._$litDirective$;
  return n?.constructor !== a && (n?._$AO?.(!1), a === void 0 ? n = void 0 : (n = new a(i), n._$AT(i, t, s)), s !== void 0 ? (t._$Co ??= [])[s] = n : t._$Cl = n), n !== void 0 && (e = O(i, n._$AS(i, e.values), n, s)), e;
}
class wt {
  constructor(e, t) {
    this._$AV = [], this._$AN = void 0, this._$AD = e, this._$AM = t;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(e) {
    const { el: { content: t }, parts: s } = this._$AD, n = (e?.creationScope ?? S).importNode(t, !0);
    _.currentNode = n;
    let a = _.nextNode(), r = 0, o = 0, c = s[0];
    for (; c !== void 0; ) {
      if (r === c.index) {
        let l;
        c.type === 2 ? l = new F(a, a.nextSibling, this, e) : c.type === 1 ? l = new c.ctor(a, c.name, c.strings, this, e) : c.type === 6 && (l = new _t(a, this, e)), this._$AV.push(l), c = s[++o];
      }
      r !== c?.index && (a = _.nextNode(), r++);
    }
    return _.currentNode = S, n;
  }
  p(e) {
    let t = 0;
    for (const s of this._$AV) s !== void 0 && (s.strings !== void 0 ? (s._$AI(e, s, t), t += s.strings.length - 2) : s._$AI(e[t])), t++;
  }
}
class F {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(e, t, s, n) {
    this.type = 2, this._$AH = p, this._$AN = void 0, this._$AA = e, this._$AB = t, this._$AM = s, this.options = n, this._$Cv = n?.isConnected ?? !0;
  }
  get parentNode() {
    let e = this._$AA.parentNode;
    const t = this._$AM;
    return t !== void 0 && e?.nodeType === 11 && (e = t.parentNode), e;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(e, t = this) {
    e = O(this, e, t), L(e) ? e === p || e == null || e === "" ? (this._$AH !== p && this._$AR(), this._$AH = p) : e !== this._$AH && e !== I && this._(e) : e._$litType$ !== void 0 ? this.$(e) : e.nodeType !== void 0 ? this.T(e) : yt(e) ? this.k(e) : this._(e);
  }
  O(e) {
    return this._$AA.parentNode.insertBefore(e, this._$AB);
  }
  T(e) {
    this._$AH !== e && (this._$AR(), this._$AH = this.O(e));
  }
  _(e) {
    this._$AH !== p && L(this._$AH) ? this._$AA.nextSibling.data = e : this.T(S.createTextNode(e)), this._$AH = e;
  }
  $(e) {
    const { values: t, _$litType$: s } = e, n = typeof s == "number" ? this._$AC(e) : (s.el === void 0 && (s.el = U.createElement(Xe(s.h, s.h[0]), this.options)), s);
    if (this._$AH?._$AD === n) this._$AH.p(t);
    else {
      const a = new wt(n, this), r = a.u(this.options);
      a.p(t), this.T(r), this._$AH = a;
    }
  }
  _$AC(e) {
    let t = Me.get(e.strings);
    return t === void 0 && Me.set(e.strings, t = new U(e)), t;
  }
  k(e) {
    me(this._$AH) || (this._$AH = [], this._$AR());
    const t = this._$AH;
    let s, n = 0;
    for (const a of e) n === t.length ? t.push(s = new F(this.O(H()), this.O(H()), this, this.options)) : s = t[n], s._$AI(a), n++;
    n < t.length && (this._$AR(s && s._$AB.nextSibling, n), t.length = n);
  }
  _$AR(e = this._$AA.nextSibling, t) {
    for (this._$AP?.(!1, !0, t); e !== this._$AB; ) {
      const s = Ae(e).nextSibling;
      Ae(e).remove(), e = s;
    }
  }
  setConnected(e) {
    this._$AM === void 0 && (this._$Cv = e, this._$AP?.(e));
  }
}
class X {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(e, t, s, n, a) {
    this.type = 1, this._$AH = p, this._$AN = void 0, this.element = e, this.name = t, this._$AM = n, this.options = a, s.length > 2 || s[0] !== "" || s[1] !== "" ? (this._$AH = Array(s.length - 1).fill(new String()), this.strings = s) : this._$AH = p;
  }
  _$AI(e, t = this, s, n) {
    const a = this.strings;
    let r = !1;
    if (a === void 0) e = O(this, e, t, 0), r = !L(e) || e !== this._$AH && e !== I, r && (this._$AH = e);
    else {
      const o = e;
      let c, l;
      for (e = a[0], c = 0; c < a.length - 1; c++) l = O(this, o[s + c], t, c), l === I && (l = this._$AH[c]), r ||= !L(l) || l !== this._$AH[c], l === p ? e = p : e !== p && (e += (l ?? "") + a[c + 1]), this._$AH[c] = l;
    }
    r && !n && this.j(e);
  }
  j(e) {
    e === p ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, e ?? "");
  }
}
class xt extends X {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(e) {
    this.element[this.name] = e === p ? void 0 : e;
  }
}
class zt extends X {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(e) {
    this.element.toggleAttribute(this.name, !!e && e !== p);
  }
}
class At extends X {
  constructor(e, t, s, n, a) {
    super(e, t, s, n, a), this.type = 5;
  }
  _$AI(e, t = this) {
    if ((e = O(this, e, t, 0) ?? p) === I) return;
    const s = this._$AH, n = e === p && s !== p || e.capture !== s.capture || e.once !== s.once || e.passive !== s.passive, a = e !== p && (s === p || n);
    n && this.element.removeEventListener(this.name, this, s), a && this.element.addEventListener(this.name, this, e), this._$AH = e;
  }
  handleEvent(e) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, e) : this._$AH.handleEvent(e);
  }
}
class _t {
  constructor(e, t, s) {
    this.element = e, this.type = 6, this._$AN = void 0, this._$AM = t, this.options = s;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(e) {
    O(this, e);
  }
}
const St = pe.litHtmlPolyfillSupport;
St?.(U, F), (pe.litHtmlVersions ??= []).push("3.3.3");
const Ct = (i, e, t) => {
  const s = t?.renderBefore ?? e;
  let n = s._$litPart$;
  if (n === void 0) {
    const a = t?.renderBefore ?? null;
    s._$litPart$ = n = new F(e.insertBefore(H(), a), a, void 0, t ?? {});
  }
  return n._$AI(i), n;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const fe = globalThis;
class R extends E {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    const e = super.createRenderRoot();
    return this.renderOptions.renderBefore ??= e.firstChild, e;
  }
  update(e) {
    const t = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(e), this._$Do = Ct(t, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return I;
  }
}
R._$litElement$ = !0, R.finalized = !0, fe.litElementHydrateSupport?.({ LitElement: R });
const Et = fe.litElementPolyfillSupport;
Et?.({ LitElement: R });
(fe.litElementVersions ??= []).push("4.2.2");
const ge = { printSeconds: 0, jobs: 0, filamentMm: 0 }, Tt = 864e5;
function Je(i, e) {
  return {
    baseline: { ...i },
    since: e,
    carry: { ...ge },
    adjust: {},
    lastSeen: { ...i }
  };
}
function Mt(i) {
  const e = i?.job_totals;
  if (!e || typeof e != "object") return null;
  const t = (r) => typeof r == "number" && Number.isFinite(r) && r >= 0 ? r : null, s = t(e.total_print_time), n = t(e.total_jobs), a = t(e.total_filament_used);
  return s === null || n === null || a === null ? null : { printSeconds: s, jobs: n, filamentMm: a };
}
function It(i) {
  const e = i;
  if (!(e?.state === "printing" || e?.state === "paused")) return { ...ge };
  const s = (n) => typeof n == "number" && Number.isFinite(n) && n > 0 ? n : 0;
  return { printSeconds: s(e?.print_duration), jobs: 0, filamentMm: s(e?.filament_used) };
}
function Ot(i, e) {
  const t = i.lastSeen;
  if (t && Nt(t, e)) return i;
  const s = { ...i.baseline }, n = { ...i.carry };
  if (t)
    for (const a of ["printSeconds", "jobs", "filamentMm"])
      e[a] < t[a] && (n[a] += Math.max(0, t[a] - s[a]), s[a] = e[a]);
  return { ...i, baseline: s, carry: n, lastSeen: { ...e } };
}
function Nt(i, e) {
  return i.printSeconds === e.printSeconds && i.jobs === e.jobs && i.filamentMm === e.filamentMm;
}
function jt(i, e, t, s, n) {
  const a = i.adjust[e] ?? 0, r = (o) => i.carry[o] + Math.max(0, t[o] - i.baseline[o]) + s[o];
  switch (e) {
    case "hours":
      return Math.max(0, r("printSeconds") / 3600 + a);
    case "prints":
      return Math.max(0, r("jobs") + a);
    case "filamentKm":
      return Math.max(0, r("filamentMm") / 1e6 + a);
    case "days":
      return Math.max(0, (n - i.since) / Tt + a);
  }
}
function Pt(i) {
  const e = [];
  for (const t of ["hours", "prints", "days", "filamentKm"]) {
    const s = i[t];
    typeof s == "number" && s > 0 && e.push([t, s]);
  }
  return e;
}
const ee = ["hours", "prints", "days", "filamentKm"], Qe = 1, et = "extruder";
function j(i, e) {
  return `${i}:${e}`;
}
const b = (i, e, t = {}) => ({
  id: i,
  labelKey: `maintenance.outcome.${i}`,
  resetsTimer: e,
  activates: [],
  ...t
});
function $(i, e, t) {
  return {
    id: i.id,
    defId: i.defId,
    kind: i.kind,
    tool: i.tool,
    enabled: i.enabled ?? !0,
    active: !1,
    customized: !1,
    intervals: { ...i.intervals ?? {} },
    lead: {},
    guard: i.guard ?? !0,
    notify: !0,
    outcomes: i.outcomes,
    counter: Je(e, t),
    link: i.link,
    lastDone: null,
    activatedAt: null,
    notified: null
  };
}
function Rt(i, e) {
  return [
    $({ id: "bed-check", defId: "bed-check", kind: "precheck", outcomes: [] }, i, e),
    $(
      { id: "bed-wash", defId: "bed-wash", kind: "interval", intervals: { days: 7 }, outcomes: [b("done", !0)] },
      i,
      e
    ),
    $(
      { id: "lube-axes", defId: "lube-axes", kind: "interval", intervals: { days: 30 }, outcomes: [b("done", !0)] },
      i,
      e
    ),
    // Carbon rails are cleaned, not lubricated; the wizard enables this one for them.
    $(
      {
        id: "rails-clean",
        defId: "rails-clean",
        kind: "interval",
        intervals: { days: 30 },
        enabled: !1,
        outcomes: [b("done", !0)]
      },
      i,
      e
    ),
    $(
      {
        id: "belts",
        defId: "belts",
        kind: "interval",
        intervals: { days: 90 },
        link: { calibrations: "belts" },
        outcomes: [b("checked", !0), b("adjusted", !0, { activates: ["shaper-calib"] })]
      },
      i,
      e
    ),
    $(
      {
        id: "shaper-calib",
        defId: "shaper-calib",
        kind: "followup",
        link: { calibrations: "shaper" },
        outcomes: [b("done", !1, { completes: !0 })]
      },
      i,
      e
    )
  ];
}
function tt(i, e, t) {
  const s = j("nozzle", i), n = j("zoffset", i), a = j("hot-tighten", i);
  return [
    $(
      {
        id: s,
        defId: "nozzle",
        kind: "interval",
        tool: i,
        intervals: { filamentKm: 10 },
        outcomes: [b("checked", !0), b("replaced", !0, { activates: [n, a] })]
      },
      e,
      t
    ),
    $(
      {
        id: n,
        defId: "zoffset",
        kind: "followup",
        tool: i,
        link: { calibrations: "probe" },
        outcomes: [b("done", !1, { completes: !0 })]
      },
      e,
      t
    ),
    $(
      { id: a, defId: "hot-tighten", kind: "followup", tool: i, outcomes: [b("done", !1, { completes: !0 })] },
      e,
      t
    ),
    $(
      {
        id: j("feeder-lube", i),
        defId: "feeder-lube",
        kind: "interval",
        tool: i,
        intervals: { hours: 1e3 },
        outcomes: [b("done", !0)]
      },
      e,
      t
    )
  ];
}
function Ht(i, e, t) {
  const s = i.length > 0 ? i : [et];
  return {
    v: Qe,
    onboarding: { done: !1, answers: null },
    settings: { notifications: !0, guard: !0 },
    tasks: [...Rt(e, t), ...s.flatMap((n) => tt(n, e, t))]
  };
}
function Lt(i, e, t, s) {
  const n = new Set(i.tasks.map((r) => r.id)), a = e.filter((r) => !n.has(j("nozzle", r))).flatMap((r) => tt(r, t, s));
  return a.length === 0 ? i : { ...i, tasks: [...i.tasks, ...a] };
}
function Ut(i, e, t, s, n) {
  return {
    ...$(
      { id: i, defId: "custom", kind: t, outcomes: [b("done", t === "interval", t === "followup" ? { completes: !0 } : {})] },
      s,
      n
    ),
    name: e,
    customized: !0,
    // A custom interval task has to say when it is due; the editor fills this in.
    intervals: t === "interval" ? { days: 30 } : {}
  };
}
const Dt = { hours: 1, prints: 1, days: 1, filamentKm: 0.1 };
function Bt(i, e, t) {
  const s = i.lead[e], n = typeof s == "number" && s >= 0 ? s : Math.max(Dt[e], t * 0.1);
  return Math.min(n, t / 2);
}
const Z = { off: 0, ok: 1, soon: 2, overdue: 3 };
function Kt(i, e) {
  return Z[i] >= Z[e] ? i : e;
}
function Ft(i, e, t, s) {
  const n = { taskId: i.id, status: "off", triggered: !1, units: [] };
  if (!i.enabled) return n;
  if (i.kind === "precheck") return { ...n, status: "ok" };
  if (i.kind === "followup")
    return i.active ? { ...n, status: "overdue", triggered: !0 } : n;
  const a = Pt(i.intervals).map(([o, c]) => {
    const l = jt(i.counter, o, e, t, s), d = c - l, u = Bt(i, o, c), m = d <= 0 ? "overdue" : d <= u ? "soon" : "ok";
    return { unit: o, used: l, interval: c, remaining: d, lead: u, status: m };
  });
  let r = a.length > 0 ? "ok" : "off";
  for (const o of a) r = Kt(r, o.status);
  return i.active && (r = "overdue"), { taskId: i.id, status: r, triggered: i.active, units: a };
}
function qt(i, e, t, s) {
  return i.tasks.map((n) => Ft(n, e, t, s));
}
function st(i) {
  let e = 0, t = 0;
  for (const s of i)
    s.status === "overdue" ? e += 1 : s.status === "soon" && (t += 1);
  return { overdue: e, soon: t };
}
function nt(i, e) {
  const t = new Map(e.map((a) => [a.taskId, a])), s = i.tasks.flatMap((a) => {
    const r = t.get(a.id);
    return r && r.status !== "off" ? [{ task: a, evaluation: r }] : [];
  }), n = (a) => a.units.length === 0 ? 0 : Math.min(...a.units.map((r) => r.remaining / r.interval));
  return s.sort(
    (a, r) => Z[r.evaluation.status] - Z[a.evaluation.status] || n(a.evaluation) - n(r.evaluation)
  );
}
const Ie = (i) => `${i.from}|${i.outcome}|${i.to}`;
function M(i) {
  return i.tasks.filter((e) => e.kind !== "precheck");
}
function ne(i) {
  const e = new Set(M(i).map((s) => s.id)), t = [];
  for (const s of M(i))
    for (const n of s.outcomes)
      for (const a of n.activates) e.has(a) && t.push({ from: s.id, outcome: n.id, to: a });
  return t;
}
const be = 232, ie = 96, ae = 24, Wt = 52, Yt = 34, Zt = 16;
function it(i) {
  return Wt + Math.max(1, i.outcomes.length) * Yt + Zt;
}
function Vt(i) {
  const e = M(i), t = ne(i), s = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
  for (const l of e)
    s.set(l.id, 0), n.set(l.id, []);
  for (const l of t)
    l.from !== l.to && (s.set(l.to, (s.get(l.to) ?? 0) + 1), n.get(l.from)?.push(l.to));
  const a = /* @__PURE__ */ new Map(), r = (l, d, u) => {
    if (!u.has(l) && !((a.get(l) ?? -1) >= d)) {
      a.set(l, d), u.add(l);
      for (const m of n.get(l) ?? []) r(m, d + 1, u);
      u.delete(l);
    }
  };
  for (const l of e) (s.get(l.id) ?? 0) === 0 && r(l.id, 0, /* @__PURE__ */ new Set());
  for (const l of e) a.has(l.id) || r(l.id, 0, /* @__PURE__ */ new Set());
  const o = /* @__PURE__ */ new Map();
  for (const l of e) {
    const d = a.get(l.id) ?? 0;
    o.set(d, [...o.get(d) ?? [], l]);
  }
  const c = {};
  for (const [l, d] of o) {
    let u = ae;
    const m = [...d].sort((g, C) => Number(Oe(g, t)) - Number(Oe(C, t)));
    for (const g of m)
      c[g.id] = { x: ie / 2 + l * (be + ie), y: u }, u += it(g) + ae;
  }
  return c;
}
function Oe(i, e) {
  return !e.some((t) => t.from === i.id || t.to === i.id);
}
function Gt(i, e) {
  let t = 0, s = 0;
  for (const n of i) {
    const a = e[n.id];
    a && (t = Math.max(t, a.x + be), s = Math.max(s, a.y + it(n)));
  }
  return { w: t + ie, h: s + ae * 2 };
}
function Ne(i) {
  return !!i && i.kind !== "precheck";
}
function Xt(i, e, t, s) {
  const n = i.tasks.find((o) => o.id === e), a = i.tasks.find((o) => o.id === s);
  if (!Ne(n)) return { error: "unknown-task" };
  if (!Ne(a)) return { error: "bad-target" };
  const r = n.outcomes.find((o) => o.id === t);
  return r ? r.activates.includes(s) ? { error: "duplicate" } : {
    state: {
      ...i,
      tasks: i.tasks.map(
        (o) => o.id === e ? { ...o, outcomes: o.outcomes.map((c) => c.id === t ? { ...c, activates: [...c.activates, s] } : c) } : o
      )
    }
  } : { error: "unknown-outcome" };
}
function Jt(i, e) {
  return i.tasks.find((s) => s.id === e.from)?.outcomes.some((s) => s.id === e.outcome && s.activates.includes(e.to)) ? {
    ...i,
    tasks: i.tasks.map(
      (s) => s.id === e.from ? { ...s, outcomes: s.outcomes.map((n) => n.id === e.outcome ? { ...n, activates: n.activates.filter((a) => a !== e.to) } : n) } : s
    )
  } : i;
}
function je(i, e, t) {
  const s = Math.max(48, Math.abs(e.x - i.x) / 2), n = { x: i.x + t * s, y: i.y }, a = { x: e.x - t * s, y: e.y };
  return `M ${i.x} ${i.y} C ${n.x} ${n.y}, ${a.x} ${a.y}, ${e.x} ${e.y}`;
}
function at(i) {
  const e = [], t = /* @__PURE__ */ new Map();
  for (const o of i.tasks)
    t.has(o.id) && e.push({ code: "duplicate-id", severity: "error", taskId: o.id }), t.set(o.id, o);
  const s = /* @__PURE__ */ new Map();
  for (const o of i.tasks) {
    const c = [];
    for (const l of o.outcomes)
      for (const d of l.activates)
        t.get(d) ? c.push(d) : e.push({ code: "dangling", severity: "error", taskId: o.id, outcomeId: l.id, target: d });
    s.set(o.id, c);
  }
  const n = /* @__PURE__ */ new Set(), a = [], r = (o) => {
    const c = a.indexOf(o);
    if (c !== -1) {
      e.push({ code: "cycle", severity: "warning", taskId: o, path: [...a.slice(c), o] });
      return;
    }
    if (!n.has(o)) {
      a.push(o);
      for (const l of s.get(o) ?? []) r(l);
      a.pop(), n.add(o);
    }
  };
  for (const o of i.tasks) r(o.id);
  return e;
}
function Qt(i, e, t, s, n, a) {
  const r = i.tasks.find((u) => u.id === e), o = r?.outcomes.find((u) => u.id === t);
  if (!r || !o) return null;
  const c = [], l = i.tasks.map((u) => {
    let m = u;
    return u.id === e && (o.resetsTimer && (m = { ...m, counter: Je(s, n), active: !1, activatedAt: null, lastDone: n, notified: null }), o.completes && (m = { ...m, active: !1, activatedAt: null, lastDone: n, notified: null })), o.activates.includes(u.id) && u.kind !== "precheck" && m.enabled && !m.active && (m = { ...m, active: !0, activatedAt: n, notified: null }, c.push(u.id)), m;
  }), d = {
    id: a.entryId,
    at: n,
    taskId: e,
    taskLabel: a.taskLabel,
    outcomeId: t,
    note: a.note?.trim() || void 0,
    totals: { ...s }
  };
  return { state: { ...i, tasks: l }, entry: d, activated: c };
}
const es = 200;
function Pe(i, e) {
  return [e, ...i].slice(0, es);
}
const Re = {
  "ball-liquid": 7,
  "ball-grease": 30,
  carbon: null,
  none: null
}, He = {
  /** Brass wears fast and must not see abrasive filaments. */
  brass: 10,
  /** Hardened steel and tip-hardened nozzles: the lower end of the 80-100 km range. */
  hardened: 80
}, ts = { regular: 1e3, planetary: 500 }, ss = 90, ns = 7;
function is(i) {
  const e = i.length > 0 ? i : [et];
  return {
    bedCheck: !0,
    wash: { habit: "normal" },
    rails: { x: "ball-grease", y: "ball-grease", z: "ball-grease" },
    belts: !0,
    nozzle: Object.fromEntries(e.map((t) => [t, { type: "brass" }])),
    feeder: Object.fromEntries(e.map((t) => [t, { type: "regular" }]))
  };
}
function as(i) {
  return i.type === "custom" ? i.km && i.km > 0 ? i.km : He.brass : He[i.type];
}
function rs(i, e) {
  const t = /* @__PURE__ */ new Map();
  t.set("bed-check", { enabled: e.bedCheck });
  const s = e.wash.habit === "glue-stick" ? { prints: 1 } : { days: e.wash.habit === "custom" && (e.wash.days ?? 0) > 0 ? e.wash.days : ns };
  t.set("bed-wash", { enabled: !0, intervals: s });
  const n = ["x", "y", "z"].map((c) => [c, e.rails[c]]), a = n.flatMap(([, c]) => Re[c] === null ? [] : [Re[c]]), r = Object.fromEntries(n.map(([c, l]) => [c, l]));
  t.set("lube-axes", {
    enabled: a.length > 0,
    intervals: { days: a.length > 0 ? Math.min(...a) : 30 },
    details: r
  }), t.set("rails-clean", { enabled: n.some(([, c]) => c === "carbon"), details: r }), t.set("belts", { enabled: e.belts, intervals: { days: ss } });
  for (const [c, l] of Object.entries(e.nozzle))
    t.set(`nozzle:${c}`, { enabled: !0, intervals: { filamentKm: as(l) } });
  for (const [c, l] of Object.entries(e.feeder))
    t.set(`feeder-lube:${c}`, { enabled: !0, intervals: { hours: ts[l.type] } });
  const o = i.tasks.map((c) => {
    const l = t.get(c.id);
    return !l || c.customized ? c : {
      ...c,
      enabled: l.enabled ?? c.enabled,
      intervals: l.intervals ?? c.intervals,
      details: l.details ?? c.details
    };
  });
  return { ...i, tasks: o, onboarding: { done: !0, answers: e } };
}
function os(i) {
  return { ...i, onboarding: { done: !0, answers: null } };
}
const D = (i) => `printer:${i}:state`, B = (i) => `printer:${i}:journal`;
function T(i) {
  return typeof i == "object" && i !== null && !Array.isArray(i);
}
function ls(i, e) {
  const t = i.get(D(e));
  if (!T(t) || t.v !== Qe || !Array.isArray(t.tasks) || !T(t.settings) || !T(t.onboarding)) return null;
  const s = t.tasks.filter(
    (n) => T(n) && typeof n.id == "string" && typeof n.defId == "string" && Array.isArray(n.outcomes) && T(n.counter)
  );
  return { ...t, tasks: s };
}
function cs(i, e, t) {
  i.set(D(e), t);
}
function ds(i, e) {
  const t = i.get(B(e));
  return Array.isArray(t) ? t.filter((s) => T(s) && typeof s.id == "string" && typeof s.at == "number") : [];
}
function hs(i, e, t) {
  i.set(B(e), t);
}
function us(i, e, t) {
  return i.onChange((s) => {
    (s === "" || s === D(e) || s === B(e)) && t();
  });
}
function ps(i) {
  const e = i?.objects;
  return Array.isArray(e) ? e.filter((t) => typeof t == "string" && /^extruder\d*$/.test(t)) : [];
}
class ms {
  printerId;
  state = null;
  journal = [];
  totals = null;
  running = { ...ge };
  tools = [];
  evals = [];
  #e;
  #s = /* @__PURE__ */ new Set();
  #t = /* @__PURE__ */ new Set();
  #n = !1;
  #a = "";
  #i = [];
  #r = null;
  #u = !1;
  /** JSON of what this runtime wrote last, to ignore the echo of its own write. */
  #c = /* @__PURE__ */ new Map();
  #o = {};
  constructor(e) {
    this.#e = e, this.printerId = e.printerId;
  }
  get #l() {
    return (this.#e.now ?? Date.now)();
  }
  /** Subscribes to every change (state, totals, the clock tick). */
  subscribe(e) {
    return this.#s.add(e), () => this.#s.delete(e);
  }
  #f() {
    for (const e of this.#s) e();
  }
  /**
   * Subscribes to the moments when reminders should be evaluated: the first load (`start`),
   * a changed history (`history`), a finished print (`printEnd`) and the clock (`timer`).
   * The notification monitor is the only consumer; the UI uses {@link subscribe}.
   */
  onEvent(e) {
    return this.#t.add(e), () => this.#t.delete(e);
  }
  #d(e) {
    for (const t of this.#t) t(e);
  }
  /** Re-evaluates with the current clock (the guard calls this right before it decides). */
  reevaluate() {
    this.#h();
  }
  /** Idempotent: loads the data and starts following the printer. */
  start() {
    if (this.#u) return;
    this.#u = !0;
    const { settings: e, moonraker: t } = this.#e;
    this.#i.push(us(e, this.printerId, () => this.#y())), this.#i.push(t.subscribe({ print_stats: ["state", "print_duration", "filament_used"] }, (n) => this.#v(n), { immediate: !0 })), this.#i.push(t.onNotify("notify_history_changed", () => void this.refreshTotals().then(() => this.#d("history")))), this.#i.push(t.onReady(() => void this.#m()));
    const s = this.#e.tickMs ?? 6e4;
    s > 0 && (this.#r = setInterval(() => {
      this.#h(), this.#d("timer");
    }, s)), this.#y(!1), this.#m();
  }
  stop() {
    for (const e of this.#i) e();
    this.#i = [], this.#r !== null && clearInterval(this.#r), this.#r = null, this.#u = !1;
  }
  async #m() {
    try {
      const e = await this.#e.moonraker.request("printer.objects.list"), t = ps(e);
      t.length > 0 && (this.tools = t);
    } catch {
    }
    await this.refreshTotals();
  }
  /** Reads `server.history.totals` and brings the counters up to date. */
  async refreshTotals() {
    let e = null;
    try {
      e = Mt(await this.#e.moonraker.request("server.history.totals"));
    } catch {
      e = null;
    }
    e && (this.totals = e, this.#g());
  }
  #v(e) {
    const t = e?.print_stats ?? e;
    if (!t || typeof t != "object") return;
    this.#o = { ...this.#o, ...t }, this.running = It(this.#o), this.#h();
    const s = typeof this.#o.state == "string" ? this.#o.state : "", n = this.#a === "printing" || this.#a === "paused", a = s === "complete" || s === "cancelled" || s === "error";
    this.#a = s || this.#a, n && a && this.refreshTotals().then(() => this.#d("printEnd"));
  }
  /** Creates the state on first run, adds tasks for new extruders, syncs the counters. */
  #g() {
    const e = this.totals;
    if (!e) return;
    const t = this.#l;
    let s = this.state, n = !1;
    if (!s)
      s = Ht(this.tools, e, t), n = !0;
    else if (this.tools.length > 0) {
      const r = Lt(s, this.tools, e, t);
      r !== s && (s = r, n = !0);
    }
    const a = s.tasks.map((r) => {
      const o = Ot(r.counter, e);
      return o === r.counter ? r : { ...r, counter: o };
    });
    a.some((r, o) => r !== s.tasks[o]) && (s = { ...s, tasks: a }, n = !0), n ? this.#p(s) : this.#h(), this.#n || (this.#n = !0, this.#d("start"));
  }
  #p(e) {
    this.state = e, this.#c.set(D(this.printerId), JSON.stringify(e)), cs(this.#e.settings, this.printerId, e), this.#h();
  }
  #$(e) {
    this.journal = e, this.#c.set(B(this.printerId), JSON.stringify(e)), hs(this.#e.settings, this.printerId, e);
  }
  /** Picks up changes made by another browser (the host pulled them from the Moonraker DB). */
  #y(e = !0) {
    const t = ls(this.#e.settings, this.printerId);
    !(t !== null && JSON.stringify(t) === this.#c.get(D(this.printerId))) && t && (this.state = t);
    const n = ds(this.#e.settings, this.printerId);
    JSON.stringify(n) !== this.#c.get(B(this.printerId)) && (this.journal = n), e ? this.#h() : this.#b();
  }
  #b() {
    this.evals = this.state && this.totals ? qt(this.state, this.totals, this.running, this.#l) : [];
  }
  #h() {
    this.#b(), this.#f();
  }
  // ----- actions ------------------------------------------------------------
  /** Applies a change to the state and saves it. Does nothing before the first load. */
  mutate(e) {
    if (!this.state) return;
    const t = e(this.state);
    t !== this.state && this.#p(t);
  }
  /** Presses an outcome button of a card. Returns the tasks it triggered. */
  press(e, t, s, n) {
    if (!this.state || !this.totals) return [];
    const a = Qt(this.state, e, t, this.totals, this.#l, {
      note: s,
      entryId: this.#e.genId ? this.#e.genId() : `${this.#l}-${Math.random().toString(36).slice(2, 8)}`,
      taskLabel: n
    });
    return a ? (this.#p(a.state), this.#$(Pe(this.journal, a.entry)), a.activated) : [];
  }
  /**
   * Writes a journal line that does not belong to a card (for example "print started with
   * overdue tasks"). `outcomeId` names an i18n key under `maintenance.journalEvent`.
   */
  logEvent(e, t, s) {
    const n = {
      id: this.#e.genId ? this.#e.genId() : `${this.#l}-${Math.random().toString(36).slice(2, 8)}`,
      at: this.#l,
      taskId: "",
      taskLabel: e,
      outcomeId: t,
      note: s?.trim() || void 0,
      totals: this.totals ? { ...this.totals } : null
    };
    this.#$(Pe(this.journal, n)), this.#f();
  }
  /** Edits a task; the edit pins it, so the wizard will not overwrite it later. */
  updateTask(e, t) {
    this.mutate((s) => ({ ...s, tasks: s.tasks.map((n) => n.id === e ? { ...t(n), customized: !0 } : n) }));
  }
  addCustomTask(e, t) {
    if (!this.state || !this.totals) return null;
    const s = `custom:${this.#e.genId ? this.#e.genId() : Math.random().toString(36).slice(2, 10)}`, n = Ut(s, e, t, this.totals, this.#l);
    return this.mutate((a) => ({ ...a, tasks: [...a.tasks, n] })), s;
  }
  /** Removes a custom task and every link that pointed at it. */
  deleteTask(e) {
    this.mutate((t) => {
      const s = t.tasks.find((n) => n.id === e);
      return !s || s.defId !== "custom" ? t : {
        ...t,
        tasks: t.tasks.filter((n) => n.id !== e).map((n) => ({ ...n, outcomes: n.outcomes.map((a) => ({ ...a, activates: a.activates.filter((r) => r !== e) })) }))
      };
    });
  }
  /** Adds a link "outcome of `from` makes `to` due". Returns why it was refused, or null. */
  linkOutcome(e, t, s) {
    if (!this.state) return "unknown-task";
    const n = Xt(this.state, e, t, s);
    return "error" in n ? n.error : (this.#p(n.state), null);
  }
  unlinkOutcome(e) {
    this.mutate((t) => Jt(t, e));
  }
  /** Saves card positions of the chain editor (`null` forgets them: back to the automatic layout). */
  setLayout(e) {
    this.mutate((t) => {
      if (e === null) {
        if (!t.layout) return t;
        const { layout: s, ...n } = t;
        return n;
      }
      return { ...t, layout: e };
    });
  }
  updateSettings(e) {
    this.mutate((t) => ({ ...t, settings: { ...t.settings, ...e } }));
  }
  finishWizard(e) {
    this.mutate((t) => rs(t, e));
  }
  skipWizard() {
    this.mutate((e) => os(e));
  }
}
const re = /* @__PURE__ */ new Map();
function oe(i) {
  return re.get(i);
}
function le(i, e) {
  let t = re.get(e);
  return t || (t = new ms({
    printerId: e,
    settings: i.settingsFor(e),
    moonraker: i.moonrakerFor(e)
  }), re.set(e, t)), t.start(), t;
}
class f extends R {
  static properties = {
    api: { attribute: !1 },
    params: { attribute: !1 }
  };
  #e = [];
  constructor() {
    super(), this.api = null, this.params = {};
  }
  connectedCallback() {
    super.connectedCallback(), this.api && this.attachApi(this.api);
  }
  willUpdate(e) {
    e.has("api") && this.api && this.#e.length === 0 && this.isConnected && this.attachApi(this.api);
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    for (const e of this.#e) e();
    this.#e = [];
  }
  /** Subclasses extend this to bind to the api; the returned unsubscribers are released on disconnect. */
  attachApi(e) {
    this.#e.push(e.onLocaleChange(() => this.requestUpdate()));
  }
  track(e) {
    this.#e.push(e);
  }
  /** Translation through the HOST dictionary (our `locales` export is merged into it). */
  t(e, t) {
    return this.api ? this.api.i18n.t(e, t) : e;
  }
}
class ce extends f {
  static properties = {
    ...f.properties,
    runtime: { state: !0 }
  };
  #e = null;
  constructor() {
    super(), this.runtime = null;
  }
  attachApi(e) {
    super.attachApi(e), this.#s(le(e, e.printer.id)), this.track(e.onPrinterChange((t) => this.#s(le(e, t.id)))), this.track(() => {
      this.#e?.(), this.#e = null;
    });
  }
  #s(e) {
    this.#e?.(), this.runtime = e, this.#e = e.subscribe(() => this.requestUpdate());
  }
}
function x(i, e) {
  customElements.get(i) || customElements.define(i, e);
}
const fs = {
  maintenance: {
    tabTitle: "Service",
    widgetTitle: "Maintenance",
    loading: "Waiting for the printer…",
    open: "Open maintenance",
    common: {
      save: "Save",
      cancel: "Cancel",
      edit: "Edit",
      delete: "Delete task",
      add: "Add task",
      confirm: "Confirm",
      create: "Create",
      close: "Close",
      why: "Why, and how to choose the interval",
      notePlaceholder: "Note (optional): what was done, which parts",
      yes: "Yes",
      no: "No"
    },
    nav: { tasks: "Tasks", chains: "Chains", journal: "Journal", settings: "Settings" },
    summary: {
      overdue: "{n} due",
      soon: "{n} soon",
      allOk: "Everything is in order",
      activeTitle: "Active tasks",
      disabledTitle: "Switched-off tasks"
    },
    status: { ok: "OK", soon: "Soon", overdue: "Due", off: "Off", triggered: "Requested by another task" },
    unit: {
      hours: "{used} / {interval} print hours",
      prints: "{used} / {interval} prints",
      days: "{used} / {interval} days",
      filamentKm: "{used} / {interval} km of filament"
    },
    unitName: { hours: "Print hours", prints: "Prints", days: "Days", filamentKm: "Filament, km" },
    triggeredHint: "This step was requested by a result you chose on another card. Do it, then press its button.",
    pressed: "Now due: {names}",
    noTasks: "Nothing to show yet.",
    link: {
      belts: "Open the belts tools",
      shaper: "Open Input Shaper",
      probe: "Open the probe tools",
      heaters: "Open the heater tools",
      mesh: "Open the bed mesh tools"
    },
    tool: "Tool {tool}",
    outcome: {
      done: "Done",
      checked: "Checked",
      adjusted: "Adjusted",
      replaced: "Replaced"
    },
    task: {
      "bed-check": {
        name: "Bed check before printing",
        why: "Before each print Tessera shows the cameras and asks you to confirm that nothing is left on the bed and the sheet is in place. A forgotten part or a missing sheet can damage the nozzle and the bed."
      },
      "bed-wash": {
        name: "Wash the bed",
        why: "Depends on how dusty the room is, which adhesive you use and how much you touch the bed with your fingers when you take the models off. With glue stick it is recommended to wash the bed at every print. For a not very dusty room and careful handling the recommended interval is once a week."
      },
      "lube-axes": {
        name: "Lubricate the X, Y and Z axes",
        why: "Depends on the consumables and the type of guides. For ball bearing guides use liquid lubricants every 7 days, or lithium soap grease of NLGI 1 / NLGI 2 consistency every month. Carbon guides need no lubrication, only regular cleaning. Also not lubricated: bronze-graphite plain bearings, POM lead screw nuts on Z (usually) and POM wheels running on V-Slot profile.",
        axes: "Axes: {axes}"
      },
      "rails-clean": {
        name: "Clean the carbon rails",
        why: "Carbon guides must not be lubricated: wipe them regularly with a lint-free cloth instead, so that dust and old grease do not build up."
      },
      belts: {
        name: "Check the belt tension",
        why: 'A slack belt gives backlash and ringing at the corners and spoils the result of the resonance measurement. Pick "Checked" if the tension was fine, "Adjusted" if you had to change it.'
      },
      "shaper-calib": {
        name: "Calibrate the input shaper",
        why: 'The resonance frequencies depend on the belt tension, so the shaper has to be measured again whenever the belts were adjusted. It appears here only after "Adjusted" on the belts card.'
      },
      nozzle: {
        name: "Check the nozzle",
        why: 'Brass nozzles wear fast, are not compatible with abrasive filaments, but heat the filament well; the recommended replacement interval is 10 km of filament. Hardened steel nozzles resist composites but heat the filament worse than brass; the recommended interval is 80-100 km, on abrasive filaments possibly more often. Nozzles with a hardened tip combine the advantages of both; replace them like hardened steel ones. Pick "Checked" if it is still good, "Replaced" after a swap.'
      },
      zoffset: {
        name: "Check the Z offset",
        why: 'A new nozzle never has exactly the height of the old one, so the first layer drifts. Check the Z offset after every nozzle swap. It appears here only after "Replaced" on the nozzle card.'
      },
      "hot-tighten": {
        name: "Hot-tighten the nozzle",
        why: 'The parts expand when heated, so a nozzle tightened cold becomes loose at working temperature and leaks around the thread. Tighten it once at working temperature after a swap. It appears here only after "Replaced" on the nozzle card.'
      },
      "feeder-lube": {
        name: "Lubricate the feeder gearbox",
        why: "For feeders with an ordinary gearbox every 1000 hours, with a planetary gearbox (Orbiter, Galileo, Nebula) every 500 hours. NEVER lubricate the teeth that grip the filament!"
      },
      custom: { name: "Custom task" }
    },
    rail: {
      "ball-liquid": "Ball bearings, liquid oil (every 7 days)",
      "ball-grease": "Ball bearings, lithium grease NLGI 1/2 (every month)",
      carbon: "Carbon rails (no lubrication, regular cleaning)",
      none: "No lubrication needed (bronze-graphite bushings, POM nuts and wheels, V-Slot)"
    },
    wizard: {
      title: "Set up maintenance",
      intro: "The right intervals depend on your consumables and hardware. Answer a few questions and the reminders are set up for you; you can change everything afterwards. Until you finish (or skip) this, no reminders or pre-print dialogs are shown.",
      skip: "Skip, use defaults",
      finish: "Apply",
      cancel: "Cancel",
      bedCheck: {
        title: "Bed check before printing",
        text: "Before each print, show the cameras and ask to confirm that the bed is empty and the sheet is in place.",
        on: "Ask before each print",
        off: "Do not ask"
      },
      wash: {
        title: "Washing the bed",
        glue: "I use glue stick: wash at every print",
        normal: "Normal conditions: once a week (7 days)",
        custom: "My own interval, days:"
      },
      rails: { title: "Guides", text: "Pick the type for each axis. Reminders follow the shortest interval; axes that need no lubrication are left out." },
      axis: { x: "X axis", y: "Y axis", z: "Z axis" },
      belts: { title: "Belts", on: "Remind me to check the belt tension every 3 months", off: "No belt reminders" },
      nozzle: {
        title: "Nozzle",
        text: "Pick the nozzle you use on this tool.",
        brass: "Brass (10 km of filament)",
        hardened: "Hardened steel or hardened tip (80 km)",
        custom: "My own interval, km of filament:"
      },
      feeder: {
        title: "Feeder gearbox",
        regular: "Ordinary gearbox (1000 hours)",
        planetary: "Planetary gearbox: Orbiter, Galileo, Nebula (500 hours)",
        warning: "Never lubricate the teeth that grip the filament."
      },
      custom: {
        title: "Your own tasks and chains",
        text: 'Besides these tasks you can add your own, with a name, an interval and a short instruction. Every card has result buttons, and a result can make other cards due: "Belts: Adjusted" asks for the input shaper calibration, "Nozzle: Replaced" asks for the Z offset check and hot tightening. You can link your own cards the same way when you edit a task. A visual chain editor will come later.'
      }
    },
    editor: {
      title: "Edit task",
      newTitle: "New task",
      name: "Name",
      instruction: "Instruction",
      kind: "Kind",
      kindInterval: "By a timer",
      kindFollowup: "Appears only when another card asks for it",
      enabled: "Enabled",
      intervals: "Interval (it is due when ANY of the set values is reached; empty = not used)",
      lead: "Start reminding in advance",
      leadHint: "Empty = automatically (about 10 % of the interval). Same units as above.",
      adjust: "Correct the counter",
      adjustHint: "Moonraker counts the whole printer, so for a tool that printed less (or more) than the others add or subtract the difference here.",
      guard: "Warn about this task before printing",
      notify: "Send notifications for this task",
      outcomes: "Results (the buttons on the card)",
      outcomeLabel: "Button text",
      resetsTimer: "restarts the timer",
      completes: "finishes the task",
      triggers: "Makes these tasks due",
      addOutcome: "Add a result",
      removeOutcome: "Remove",
      cycle: "These cards ask for each other in a circle. It is allowed, but check that it is what you want.",
      deleteConfirm: "Delete this task?"
    },
    journal: {
      empty: "Nothing has been done yet.",
      when: "When",
      export: "Download CSV"
    },
    settings: {
      notifications: "Notifications",
      notificationsHint: "Tell me when a task is about to be due and when it is overdue.",
      guard: "Warn before printing",
      guardHint: "Before a print starts from Tessera, show a dialog with the overdue tasks. You can always start anyway.",
      bedCheck: "Bed check before printing",
      wizard: "Run the setup wizard again",
      counters: "Hours, prints and filament come from the Moonraker history of the whole printer and keep counting if you reset the totals on the History page. Prints from other apps (Mainsail, a slicer) are counted, but the pre-print dialog is shown only for prints started from Tessera."
    },
    chains: {
      title: "Chains of tasks",
      hint: "Drag a card by its title to move it. To link, drag from the dot next to a result onto the card that result should make due. Click a line to select it, then press Delete or the button above. Double-click a card to edit it.",
      hintNarrow: "The board needs more room than this screen has. Edit the links in the list below.",
      undo: "Undo",
      redo: "Redo",
      undoHint: "Undo the last change (Ctrl+Z)",
      redoHint: "Redo (Ctrl+Y)",
      arrange: "Arrange automatically",
      removeSelected: "Remove the selected link",
      dragHint: 'Drag from here onto a card: "{name}" will make it due',
      links: "Links",
      noLinks: "No links yet: no result makes another card due.",
      addLink: "Add a link",
      from: "Card",
      outcome: "Result",
      to: "Makes this card due",
      add: "Add link",
      remove: "Remove",
      duplicate: "This link already exists."
    },
    notify: {
      label: "Service",
      soon: "{task} is due soon ({progress})",
      overdue: "{task} is due ({progress})",
      triggered: "{task}: requested by another task"
    },
    guard: {
      title: "Before printing",
      bedTitle: "Check the bed",
      bedConfirm: "The bed is empty and the sheet is in place",
      overdueTitle: "Maintenance is due",
      overdueHint: "You can still start the print. This is only a reminder that the work above is due.",
      start: "Start printing",
      startAnyway: "Start anyway",
      open: "Open maintenance",
      noCamera: "No camera is set up for this printer. Check the bed yourself and confirm below.",
      cameraOff: "The camera does not answer",
      cancelled: "Print not started: cancelled in the maintenance check"
    },
    journalEvent: { startedAnyway: "Print started with this work overdue" },
    widget: { more: "+{n} more", openTab: "Open the tab" }
  }
}, gs = {
  maintenance: {
    tabTitle: "Обслуживание",
    widgetTitle: "Обслуживание",
    loading: "Ждём принтер…",
    open: "Открыть обслуживание",
    common: {
      save: "Сохранить",
      cancel: "Отмена",
      edit: "Изменить",
      delete: "Удалить задачу",
      add: "Добавить задачу",
      confirm: "Подтвердить",
      create: "Создать",
      close: "Закрыть",
      why: "Зачем и как выбрать интервал",
      notePlaceholder: "Заметка (необязательно): что сделано, какие детали",
      yes: "Да",
      no: "Нет"
    },
    nav: { tasks: "Задачи", chains: "Цепочки", journal: "Журнал", settings: "Настройки" },
    summary: {
      overdue: "Пора: {n}",
      soon: "Скоро: {n}",
      allOk: "Всё в порядке",
      activeTitle: "Активные задачи",
      disabledTitle: "Выключенные задачи"
    },
    status: { ok: "В порядке", soon: "Скоро", overdue: "Пора", off: "Выключено", triggered: "Запрошено другой задачей" },
    unit: {
      hours: "{used} / {interval} ч печати",
      prints: "{used} / {interval} печатей",
      days: "{used} / {interval} дн.",
      filamentKm: "{used} / {interval} км филамента"
    },
    unitName: { hours: "Часы печати", prints: "Печати", days: "Дни", filamentKm: "Филамент, км" },
    triggeredHint: "Этот шаг запросил результат, выбранный на другой карточке. Выполните его и нажмите кнопку.",
    pressed: "Теперь пора: {names}",
    noTasks: "Пока нечего показывать.",
    link: {
      belts: "Открыть инструменты ремней",
      shaper: "Открыть Input Shaper",
      probe: "Открыть инструменты щупа",
      heaters: "Открыть инструменты нагревателей",
      mesh: "Открыть инструменты сетки стола"
    },
    tool: "Инструмент {tool}",
    outcome: {
      done: "Выполнено",
      checked: "Проверено",
      adjusted: "Скорректировано",
      replaced: "Заменено"
    },
    task: {
      "bed-check": {
        name: "Проверка стола перед печатью",
        why: "Перед каждой печатью Tessera показывает камеры и просит подтвердить, что на столе ничего не оставлено и лист лежит на месте. Забытая деталь или отсутствующий лист могут повредить сопло и стол."
      },
      "bed-wash": {
        name: "Мойка стола",
        why: "Зависит от запылённости помещения, используемого адгезива, а также от того, насколько сильно вы трогаете стол пальцами, когда снимаете с него модели. При использовании клея-карандаша рекомендуется мыть стол каждую печать. Для несильно запылённой комнаты и аккуратного использования рекомендуемый интервал — раз в неделю."
      },
      "lube-axes": {
        name: "Смазка осей X, Y, Z",
        why: "Зависит от используемых расходников и типа направляющих. Для направляющих с шариковыми подшипниками рекомендуются жидкие смазки с интервалом 7 дней либо консистентные на основе литиевого мыла вязкостью NLGI 1 / NLGI 2 с интервалом 1 месяц. Карбоновые направляющие смазки не требуют, требуют регулярной очистки. Также не требуют смазки: подшипники скольжения с бронзографитовой втулкой, ходовые POM-гайки на винтах привода оси Z (обычно), POM-колёса, перемещающиеся по V-Slot конструкционному профилю.",
        axes: "Оси: {axes}"
      },
      "rails-clean": {
        name: "Очистка карбоновых направляющих",
        why: "Карбоновые направляющие нельзя смазывать: вместо этого их регулярно протирают безворсовой тканью, чтобы не копились пыль и старая смазка."
      },
      belts: {
        name: "Проверка натяжения ремней",
        why: "Ослабленный ремень даёт люфт и «звон» на углах и портит результат замера резонансов. Выберите «Проверено», если натяжение было в порядке, и «Скорректировано», если пришлось его менять."
      },
      "shaper-calib": {
        name: "Калибровка шейперов",
        why: "Частоты резонансов зависят от натяжения ремней, поэтому шейперы нужно замерять заново после каждой коррекции ремней. Карточка появляется только после «Скорректировано» на карточке ремней."
      },
      nozzle: {
        name: "Проверка сопла",
        why: "Латунные сопла быстро изнашиваются, не совместимы с абразивными филаментами, зато хорошо прогревают филамент; рекомендуемый интервал замены — 10 км филамента. Сопла из закалённой стали устойчивы к композитам, но прогревают филамент хуже латунных; рекомендуемый интервал замены — 80–100 км, на абразивных филаментах возможно чаще. Сопла с закалённым кончиком сочетают преимущества обоих вариантов; меняйте их как стальные. Выберите «Проверено», если сопло в порядке, и «Заменено» после замены."
      },
      zoffset: {
        name: "Проверка Z-offset",
        why: "У нового сопла высота никогда не совпадает с прежней, поэтому первый слой «уплывает». Проверяйте Z-offset после каждой замены сопла. Карточка появляется только после «Заменено» на карточке сопла."
      },
      "hot-tighten": {
        name: "Протяжка сопла на горячую",
        why: "Детали расширяются при нагреве, поэтому сопло, затянутое на холодную, при рабочей температуре ослабевает, и из-под резьбы начинает подтекать. После замены сопло один раз затягивают при рабочей температуре. Карточка появляется только после «Заменено» на карточке сопла."
      },
      "feeder-lube": {
        name: "Смазка редуктора подающего механизма",
        why: "Для подающих механизмов с обычным редуктором — 1000 часов, с планетарным редуктором (Orbiter, Galileo, Nebula) — 500 часов. Категорически нельзя смазывать зубцы, подающие филамент!"
      },
      custom: { name: "Своя задача" }
    },
    rail: {
      "ball-liquid": "Шариковые подшипники, жидкая смазка (раз в 7 дней)",
      "ball-grease": "Шариковые подшипники, литиевая смазка NLGI 1/2 (раз в месяц)",
      carbon: "Карбоновые направляющие (без смазки, регулярная очистка)",
      none: "Смазка не нужна (бронзографитовые втулки, POM-гайки и колёса, V-Slot)"
    },
    wizard: {
      title: "Настройка обслуживания",
      intro: "Правильные интервалы зависят от ваших расходников и железа. Ответьте на несколько вопросов — напоминания настроятся сами, потом всё можно изменить. Пока вы не закончите (или не пропустите) настройку, напоминания и диалог перед печатью не показываются.",
      skip: "Пропустить, оставить по умолчанию",
      finish: "Применить",
      cancel: "Отмена",
      bedCheck: {
        title: "Проверка стола перед печатью",
        text: "Перед каждой печатью показывать камеры и просить подтвердить, что стол пуст и лист на месте.",
        on: "Спрашивать перед каждой печатью",
        off: "Не спрашивать"
      },
      wash: {
        title: "Мойка стола",
        glue: "Использую клей-карандаш: мыть каждую печать",
        normal: "Обычные условия: раз в неделю (7 дней)",
        custom: "Свой интервал, дней:"
      },
      rails: { title: "Направляющие", text: "Выберите тип для каждой оси. Напоминание идёт по самому короткому интервалу; оси, которым смазка не нужна, не учитываются." },
      axis: { x: "Ось X", y: "Ось Y", z: "Ось Z" },
      belts: { title: "Ремни", on: "Напоминать проверять натяжение ремней раз в 3 месяца", off: "Не напоминать про ремни" },
      nozzle: {
        title: "Сопло",
        text: "Выберите сопло, которое стоит на этом инструменте.",
        brass: "Латунное (10 км филамента)",
        hardened: "Закалённая сталь или с закалённым кончиком (80 км)",
        custom: "Свой интервал, км филамента:"
      },
      feeder: {
        title: "Редуктор подающего механизма",
        regular: "Обычный редуктор (1000 часов)",
        planetary: "Планетарный редуктор: Orbiter, Galileo, Nebula (500 часов)",
        warning: "Категорически нельзя смазывать зубцы, подающие филамент."
      },
      custom: {
        title: "Свои задачи и цепочки",
        text: "Кроме этих задач можно добавить свои: с названием, интервалом и короткой инструкцией. У каждой карточки есть кнопки-результаты, и результат может сделать другие карточки актуальными: «Ремни: Скорректировано» просит калибровку шейперов, «Сопло: Заменено» — проверку Z-offset и протяжку на горячую. Свои карточки можно связать так же при редактировании задачи. Визуальный конструктор цепочек появится позже."
      }
    },
    editor: {
      title: "Изменить задачу",
      newTitle: "Новая задача",
      name: "Название",
      instruction: "Инструкция",
      kind: "Вид",
      kindInterval: "По таймеру",
      kindFollowup: "Появляется, только когда её запросит другая карточка",
      enabled: "Включена",
      intervals: "Интервал (пора, когда достигнуто ЛЮБОЕ из заданных значений; пусто — не используется)",
      lead: "Начать напоминать заранее",
      leadHint: "Пусто — автоматически (около 10 % интервала). Единицы те же, что выше.",
      adjust: "Поправка счётчика",
      adjustHint: "Moonraker считает весь принтер, поэтому если инструмент напечатал меньше (или больше) остальных, добавьте или вычтите разницу здесь.",
      guard: "Предупреждать об этой задаче перед печатью",
      notify: "Присылать уведомления по этой задаче",
      outcomes: "Результаты (кнопки на карточке)",
      outcomeLabel: "Текст кнопки",
      resetsTimer: "перезапускает таймер",
      completes: "завершает задачу",
      triggers: "Делает актуальными задачи",
      addOutcome: "Добавить результат",
      removeOutcome: "Убрать",
      cycle: "Эти карточки по кругу запрашивают друг друга. Это разрешено, но проверьте, что так и задумано.",
      deleteConfirm: "Удалить эту задачу?"
    },
    journal: {
      empty: "Пока ничего не сделано.",
      when: "Когда",
      export: "Скачать CSV"
    },
    settings: {
      notifications: "Уведомления",
      notificationsHint: "Сообщать, когда задача скоро наступит и когда она просрочена.",
      guard: "Предупреждать перед печатью",
      guardHint: "Перед запуском печати из Tessera показывать диалог с просроченными задачами. Начать печать можно в любом случае.",
      bedCheck: "Проверка стола перед печатью",
      wizard: "Пройти мастер настройки заново",
      counters: "Часы, печати и филамент берутся из истории Moonraker по всему принтеру и продолжают считаться, даже если вы сбросите итоги на странице History. Печати из других программ (Mainsail, слайсер) учитываются, но диалог перед печатью показывается только для печатей, запущенных из Tessera."
    },
    chains: {
      title: "Цепочки задач",
      hint: "Карточку можно перетаскивать за заголовок. Чтобы связать, перетащите точку рядом с результатом на карточку, которую этот результат должен сделать актуальной. Щёлкните по линии, чтобы выбрать её, затем нажмите Delete или кнопку выше. Двойной щелчок по карточке открывает редактирование.",
      hintNarrow: "Для схемы нужно больше места, чем есть на этом экране. Редактируйте связи в списке ниже.",
      undo: "Отменить",
      redo: "Повторить",
      undoHint: "Отменить последнее изменение (Ctrl+Z)",
      redoHint: "Повторить (Ctrl+Y)",
      arrange: "Расставить автоматически",
      removeSelected: "Убрать выбранную связь",
      dragHint: "Перетащите отсюда на карточку: «{name}» сделает её актуальной",
      links: "Связи",
      noLinks: "Связей пока нет: ни один результат не делает другую карточку актуальной.",
      addLink: "Добавить связь",
      from: "Карточка",
      outcome: "Результат",
      to: "Делает актуальной карточку",
      add: "Добавить связь",
      remove: "Убрать",
      duplicate: "Такая связь уже есть."
    },
    notify: {
      label: "Обслуживание",
      soon: "{task}: скоро срок ({progress})",
      overdue: "{task}: пора ({progress})",
      triggered: "{task}: запросила другая задача"
    },
    guard: {
      title: "Перед печатью",
      bedTitle: "Проверьте стол",
      bedConfirm: "Стол пуст, лист на месте",
      overdueTitle: "Пора обслужить принтер",
      overdueHint: "Печать всё равно можно начать. Это только напоминание, что работы выше пора сделать.",
      start: "Начать печать",
      startAnyway: "Всё равно начать",
      open: "Открыть обслуживание",
      noCamera: "Для этого принтера не настроено ни одной камеры. Проверьте стол сами и подтвердите ниже.",
      cameraOff: "Камера не отвечает",
      cancelled: "Печать не начата: отменена в проверке обслуживания"
    },
    journalEvent: { startedAnyway: "Печать начата при просроченных работах" },
    widget: { more: "и ещё {n}", openTab: "Открыть вкладку" }
  }
};
function Le(i, e) {
  switch (i) {
    case "hours":
      return String(Math.round(e * 10) / 10);
    case "filamentKm":
      return String(Math.round(e * 100) / 100);
    default:
      return String(Math.floor(e + 1e-9));
  }
}
function J(i, e) {
  return i(`maintenance.unit.${e.unit}`, {
    used: Le(e.unit, Math.min(e.used, e.interval)),
    interval: Le(e.unit, e.interval)
  });
}
function v(i, e) {
  return e.name?.trim() || i(`maintenance.task.${e.defId}.name`);
}
function k(i, e) {
  return e.labelKey ? i(e.labelKey) : e.label ?? e.id;
}
function rt(i) {
  return `maintenance.status.${i}`;
}
function bs(i) {
  return Math.max(0, Math.min(1, i.used / i.interval));
}
function ve(i) {
  return [...i.units].sort((e, t) => t.used / t.interval - e.used / e.interval)[0];
}
function vs(i, e) {
  return `#/p/${encodeURIComponent(i)}/calibrations?section=${e === "belts" ? "shaper" : e}`;
}
function $s(i, e, t, s) {
  const n = e.tool ? `${v(i, e)} (${e.tool})` : v(i, e);
  if (t.triggered) return i("maintenance.notify.triggered", { task: n });
  const a = ve(t), r = a ? J(i, a) : "";
  return i(s === "soon" ? "maintenance.notify.soon" : "maintenance.notify.overdue", { task: n, progress: r });
}
function ot(i) {
  return `#/p/${encodeURIComponent(i)}/machine?section=${encodeURIComponent("tessera/maintenance/maintenance")}`;
}
const z = y`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
    min-width: 0;
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    font-size: var(--font-size-md);
    container-type: inline-size;
  }

  .panel {
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-width: 0;
  }
  .panel-header {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: var(--space-sm);
    padding: var(--space-sm) var(--space-md);
    border-block-end: 1px solid var(--border-color);
  }
  /* A title never shrinks below ~14em: a long title takes its own line and the chips and
     buttons wrap under it, instead of being squeezed into a column of single letters. */
  .panel-title {
    flex: 1 1 14em;
    min-width: 0;
    font-size: var(--font-size-md);
    font-weight: 600;
    overflow-wrap: anywhere;
  }
  /* Chips and buttons of a header. On the title's line they stay at the end; when they wrap
     onto their own line the auto margins centre them (there is free space only then). */
  .panel-meta {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    gap: var(--space-sm);
    margin-inline: auto;
  }
  .panel-body {
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    min-width: 0;
  }

  .row {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    flex-wrap: wrap;
  }
  .grow {
    flex: 1;
    min-width: 0;
  }
  .muted {
    color: var(--text-muted);
    font-size: var(--font-size-sm);
    margin: 0;
  }
  .warn {
    color: var(--warning);
    font-size: var(--font-size-sm);
    margin: 0;
  }
  .error {
    color: var(--danger);
    font-size: var(--font-size-sm);
    margin: 0;
    overflow-wrap: anywhere;
  }
  .ok {
    color: var(--success);
    font-size: var(--font-size-sm);
    margin: 0;
  }
  /* Printer names, datasets and numbers read left-to-right in any UI direction. */
  .ltr {
    direction: ltr;
    unicode-bidi: isolate;
    overflow-wrap: anywhere;
  }

  /* Buttons copy the dashboard edit toolbar of the host (EditToolbar.svelte): filled, no
     border, the host's radius. Neutral = the hover surface, primary = the accent, danger =
     the danger colour. The height matches it too, and grows to a touch target on narrow widths. */
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-xs);
    min-block-size: 32px;
    padding: var(--space-xs) var(--space-md);
    border: none;
    border-radius: var(--radius-md);
    background: var(--bg-surface-hover);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
  }
  button:hover:not(:disabled) {
    filter: brightness(1.12);
  }
  button:disabled {
    opacity: 0.4;
    cursor: not-allowed;
  }
  button.primary {
    background: var(--accent);
    color: #fff;
  }
  button.danger {
    background: var(--danger);
    color: #fff;
  }
  button.small {
    min-block-size: 28px;
    padding: 2px var(--space-sm);
  }
  button.icon {
    min-inline-size: 28px;
    padding: 2px 6px;
  }
  /* Undo / redo: a square icon button like the dashboard's history buttons. */
  button.icon-btn {
    inline-size: var(--touch-target, 44px);
    padding: 0;
  }
  svg.flip {
    transform: scaleX(-1);
  }
  @container (max-width: 560px) {
    button {
      min-block-size: var(--touch-target, 44px);
    }
    button.small,
    button.icon {
      min-block-size: 36px;
    }
  }

  .fields {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
    gap: var(--space-sm);
  }
  .field {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }
  .field-label {
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
  }
  input,
  select {
    min-width: 0;
    min-block-size: 36px;
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
  }
  input[type='checkbox'] {
    min-block-size: 0;
    inline-size: 18px;
    block-size: 18px;
    accent-color: var(--accent);
  }
  input[type='range'] {
    min-block-size: 0;
    padding: 0;
  }
  input:focus-visible,
  select:focus-visible,
  button:focus-visible {
    outline: 2px solid var(--border-focus);
    outline-offset: 1px;
  }

  .chip {
    padding: 1px 8px;
    border-radius: 999px;
    border: 1px solid var(--border-color);
    background: var(--bg-surface-hover);
    color: var(--text-secondary);
    font-size: var(--font-size-sm);
    white-space: nowrap;
  }
  .chip.live {
    border-color: var(--success);
    color: var(--success);
  }
  .chip.bad {
    border-color: var(--danger);
    color: var(--danger);
  }
  .chip.accent {
    border-color: var(--accent);
    color: var(--accent);
    font-weight: 600;
  }

  .bar {
    block-size: 6px;
    border-radius: 3px;
    background: var(--bg-surface-hover);
    overflow: hidden;
  }
  .bar > span {
    display: block;
    block-size: 100%;
    background: var(--accent);
  }
`, $e = y`
  .bar.soon > span {
    background: var(--warning);
  }
  .bar.overdue > span {
    background: var(--danger);
  }
  .chip.soon {
    border-color: var(--warning);
    color: var(--warning);
  }
  .chip.overdue {
    border-color: var(--danger);
    color: var(--danger);
    font-weight: 600;
  }
`;
class ys extends f {
  static styles = [
    z,
    $e,
    y`
      :host {
        display: block;
      }
      /* Centred, like the chips and the button when they wrap under the title. */
      .name {
        overflow-wrap: anywhere;
        text-align: center;
      }
      .unit {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      textarea {
        min-width: 0;
        min-block-size: 56px;
        padding: var(--space-xs) var(--space-sm);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        background: var(--bg-surface);
        color: var(--text-primary);
        font: inherit;
        font-size: var(--font-size-sm);
        resize: vertical;
      }
      details > summary {
        cursor: pointer;
        color: var(--text-secondary);
        font-size: var(--font-size-sm);
        min-block-size: 32px;
        display: flex;
        align-items: center;
      }
      details p {
        margin: var(--space-xs) 0 0;
        color: var(--text-secondary);
        font-size: var(--font-size-sm);
        overflow-wrap: anywhere;
      }
    `
  ];
  static properties = {
    ...f.properties,
    runtime: { attribute: !1 },
    task: { attribute: !1 },
    evaluation: { attribute: !1 },
    pending: { state: !0 },
    note: { state: !0 }
  };
  constructor() {
    super(), this.runtime = null, this.task = null, this.evaluation = null, this.pending = null, this.note = "";
  }
  #e() {
    const { runtime: e, task: t, pending: s } = this;
    if (!e || !t || !s) return;
    const n = v((r, o) => this.t(r, o), t), a = e.press(t.id, s, this.note, n);
    this.pending = null, this.note = "", this.dispatchEvent(new CustomEvent("pressed", { detail: { triggered: a }, bubbles: !0, composed: !0 }));
  }
  #s() {
    this.dispatchEvent(new CustomEvent("edit-task", { detail: { id: this.task?.id }, bubbles: !0, composed: !0 }));
  }
  render() {
    const { task: e, evaluation: t, api: s } = this;
    if (!e || !t || !s) return h``;
    const n = (l, d) => this.t(l, d), a = t.status, r = e.details, o = e.defId === "lube-axes" && r ? ["x", "y", "z"].map((l) => `${n(`maintenance.wizard.axis.${l}`)}: ${n(`maintenance.rail.${r[l] ?? "none"}`)}`).join("; ") : "", c = e.defId === "custom" ? e.instruction ?? "" : n(`maintenance.task.${e.defId}.why`);
    return h`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title name">${v(n, e)}</span>
          <span class="panel-meta">
            ${e.tool ? h`<span class="chip ltr">${n("maintenance.tool", { tool: e.tool })}</span>` : p}
            <span class="chip ${a}">${n(rt(a))}</span>
            <button class="small" @click=${() => this.#s()}>${n("maintenance.common.edit")}</button>
          </span>
        </div>
        <div class="panel-body">
          ${t.units.map(
      (l) => h`
              <div class="unit">
                <span class="muted">${J(n, l)}</span>
                <div class="bar ${l.status}"><span style="inline-size:${Math.round(bs(l) * 100)}%"></span></div>
              </div>
            `
    )}
          ${t.triggered ? h`<p class="warn">${n("maintenance.triggeredHint")}</p>` : p}
          ${c || o ? h`<details>
                <summary>${n("maintenance.common.why")}</summary>
                ${o ? h`<p>${n("maintenance.task.lube-axes.axes", { axes: o })}</p>` : p}
                ${c ? h`<p>${c}</p>` : p}
              </details>` : p}
          ${this.pending ? h`
                <textarea
                  .value=${this.note}
                  placeholder=${n("maintenance.common.notePlaceholder")}
                  @input=${(l) => this.note = l.target.value}
                ></textarea>
                <div class="row">
                  <button class="primary" @click=${() => this.#e()}>
                    ${n("maintenance.common.confirm")}: ${k(n, e.outcomes.find((l) => l.id === this.pending) ?? { id: this.pending })}
                  </button>
                  <button
                    @click=${() => {
      this.pending = null, this.note = "";
    }}
                  >
                    ${n("maintenance.common.cancel")}
                  </button>
                </div>
              ` : h`<div class="row">
                ${e.outcomes.map(
      (l) => h`<button class=${a === "overdue" ? "primary" : ""} @click=${() => this.pending = l.id}>${k(n, l)}</button>`
    )}
                ${e.link?.calibrations && this.runtime ? h`<a class="muted" href=${vs(this.runtime.printerId, e.link.calibrations)}>${n(`maintenance.link.${e.link.calibrations}`)}</a>` : p}
              </div>`}
        </div>
      </section>
    `;
  }
}
function ks(i) {
  const e = i?.webcams;
  return Array.isArray(e) ? e.filter((t) => !!t && typeof t == "object" && t.enabled !== !1).map((t) => ({
    name: String(t.name ?? ""),
    service: String(t.service ?? ""),
    snapshotUrl: String(t.snapshot_url ?? "/webcam/?action=snapshot"),
    rotation: Number(t.rotation ?? 0),
    flipH: !!t.flip_horizontal,
    flipV: !!t.flip_vertical
  })).filter((t) => t.name && t.snapshotUrl) : [];
}
function ws(i, e) {
  if (/^https?:\/\//i.test(i)) return i;
  try {
    const t = new URL(e);
    return t.port = "", t.origin + (i.startsWith("/") ? i : `/${i}`);
  } catch {
    return i;
  }
}
const xs = 1e3;
class zs extends f {
  static styles = [
    z,
    y`
      :host {
        display: block;
      }
      .grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(min(100%, 260px), 1fr));
        gap: var(--space-sm);
      }
      figure {
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 2px;
        min-width: 0;
      }
      .frame {
        position: relative;
        aspect-ratio: 16 / 9;
        background: var(--bg-surface-hover);
        border-radius: var(--radius-sm);
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      img {
        max-inline-size: 100%;
        max-block-size: 100%;
        object-fit: contain;
      }
      figcaption {
        font-size: var(--font-size-sm);
        color: var(--text-secondary);
        overflow-wrap: anywhere;
      }
      .off {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: var(--space-sm);
        text-align: center;
        color: var(--text-muted);
        font-size: var(--font-size-sm);
        background: var(--bg-surface-hover);
      }
    `
  ];
  static properties = {
    ...f.properties,
    printerId: { type: String },
    cameras: { state: !0 },
    failed: { state: !0 },
    loaded: { state: !0 },
    frames: { state: !0 }
  };
  #e = null;
  #s = /* @__PURE__ */ new Set();
  constructor() {
    super(), this.printerId = "", this.cameras = [], this.failed = {}, this.loaded = !1, this.frames = {};
  }
  attachApi(e) {
    super.attachApi(e), this.#t(), this.track(() => this.#a());
  }
  async #t() {
    const e = this.api;
    if (e) {
      try {
        const t = await e.moonrakerFor(this.printerId || e.printer.id).request("server.webcams.list");
        this.cameras = ks(t);
      } catch {
        this.cameras = [];
      }
      this.loaded = !0, this.cameras.length > 0 && this.#n();
    }
  }
  #n() {
    this.#i(), this.#e = setInterval(() => this.#i(), xs);
  }
  #a() {
    this.#e !== null && clearInterval(this.#e), this.#e = null;
  }
  #i() {
    const e = this.api;
    if (!e) return;
    const t = e.moonrakerFor(this.printerId || e.printer.id).httpBaseUrl, s = { ...this.frames };
    for (const n of this.cameras) {
      if (this.#s.has(n.name)) continue;
      this.#s.add(n.name);
      const a = ws(n.snapshotUrl, t);
      s[n.name] = `${a}${a.includes("?") ? "&" : "?"}_cb=${Date.now()}`;
    }
    this.frames = s;
  }
  #r(e, t) {
    this.#s.delete(e), this.failed[e] !== !t && (this.failed = { ...this.failed, [e]: !t });
  }
  render() {
    if (!this.loaded) return h``;
    const e = (t) => this.t(t);
    return this.cameras.length === 0 ? h`<p class="muted">${e("maintenance.guard.noCamera")}</p>` : h`<div class="grid">
      ${this.cameras.map((t) => {
      const s = [t.rotation ? `rotate(${t.rotation}deg)` : "", t.flipH ? "scaleX(-1)" : "", t.flipV ? "scaleY(-1)" : ""].filter(Boolean).join(" ");
      return h`<figure>
          <div class="frame">
            ${this.frames[t.name] ? h`<img
                  src=${this.frames[t.name]}
                  alt=${t.name}
                  style=${s ? `transform:${s}` : ""}
                  @load=${() => this.#r(t.name, !0)}
                  @error=${() => this.#r(t.name, !1)}
                />` : p}
            ${this.failed[t.name] ? h`<div class="off">${e("maintenance.guard.cameraOff")}</div>` : p}
          </div>
          <figcaption class="ltr">${t.name}</figcaption>
        </figure>`;
    })}
    </div>`;
  }
}
function Ue(i) {
  const e = {};
  for (const t of i.tasks)
    e[t.id] = Object.fromEntries(t.outcomes.map((s) => [s.id, [...s.activates]]));
  return i.layout ? { links: e, layout: structuredClone(i.layout) } : { links: e };
}
function As(i, e) {
  const t = new Set(i.tasks.map((r) => r.id)), s = i.tasks.map((r) => {
    const o = e.links[r.id];
    return o ? {
      ...r,
      outcomes: r.outcomes.map((c) => {
        const l = o[c.id];
        return l ? { ...c, activates: l.filter((d) => t.has(d)) } : c;
      })
    } : r;
  }), { layout: n, ...a } = i;
  return e.layout ? { ...a, tasks: s, layout: structuredClone(e.layout) } : { ...a, tasks: s };
}
const _s = (i, e) => JSON.stringify(i) === JSON.stringify(e), Ss = 100;
class Cs {
  #e = [];
  #s = [];
  #t = null;
  get canUndo() {
    return this.#e.length > 0;
  }
  get canRedo() {
    return this.#s.length > 0;
  }
  /** Starts a session from the state as it is now. */
  reset(e) {
    this.#e = [], this.#s = [], this.#t = e ? Ue(e) : null;
  }
  /**
   * Tells the history that the state may have changed. A real change puts the previous
   * snapshot on the undo stack and empties the redo stack. Returns true if it was recorded.
   */
  changed(e) {
    const t = Ue(e);
    return this.#t ? _s(t, this.#t) ? !1 : (this.#e.push(this.#t), this.#e.length > Ss && this.#e.shift(), this.#s = [], this.#t = t, !0) : (this.#t = t, !1);
  }
  /** The snapshot to restore for Undo, or null. The caller applies it, then calls {@link applied}. */
  undo() {
    const e = this.#e.pop();
    return !e || !this.#t ? null : (this.#s.push(this.#t), this.#t = e, e);
  }
  redo() {
    const e = this.#s.pop();
    return !e || !this.#t ? null : (this.#e.push(this.#t), this.#t = e, e);
  }
}
const Es = 4;
class Ts extends f {
  static styles = [
    z,
    y`
      .scroller {
        overflow: auto;
        max-block-size: min(70vh, 720px);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        background: var(--bg-surface-hover-no-override);
      }
      .board {
        position: relative;
        min-inline-size: 100%;
      }
      /* Only the two drawing layers of the board: a bare "svg" rule would also stretch the
         small icons inside the buttons over the whole tab. */
      .board > svg {
        position: absolute;
        inset: 0;
        inline-size: 100%;
        block-size: 100%;
        overflow: visible;
        pointer-events: none;
      }
      .board > svg.top {
        z-index: 2;
      }
      path.line {
        fill: none;
        stroke: var(--accent);
        stroke-width: 2;
        opacity: 0.75;
      }
      path.line.selected {
        stroke-width: 4;
        opacity: 1;
      }
      path.hit {
        fill: none;
        stroke: transparent;
        stroke-width: 16;
        pointer-events: stroke;
        cursor: pointer;
      }
      path.ghost {
        fill: none;
        stroke: var(--accent);
        stroke-width: 2;
        stroke-dasharray: 6 4;
      }
      .node {
        position: absolute;
        z-index: 1;
        background: var(--bg-surface);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        box-shadow: var(--shadow-sm);
      }
      .node.soon {
        border-color: var(--warning);
      }
      .node.overdue {
        border-color: var(--danger);
      }
      .node.off {
        opacity: 0.6;
      }
      .node.target {
        outline: 2px solid var(--accent);
      }
      .node-head {
        position: relative;
        display: flex;
        align-items: center;
        gap: var(--space-xs);
        padding: var(--space-xs) var(--space-sm);
        min-block-size: 44px;
        border-block-end: 1px solid var(--border-color);
        cursor: grab;
        touch-action: none;
        user-select: none;
      }
      .node-head.dragging {
        cursor: grabbing;
      }
      .node-title {
        flex: 1;
        min-width: 0;
        font-weight: 600;
        font-size: var(--font-size-sm);
        overflow-wrap: anywhere;
      }
      .row-out {
        position: relative;
        display: flex;
        align-items: center;
        min-block-size: 34px;
        padding-inline: var(--space-sm) var(--space-md);
        font-size: var(--font-size-sm);
        color: var(--text-secondary);
        overflow-wrap: anywhere;
      }
      .port {
        position: absolute;
        inline-size: 14px;
        block-size: 14px;
        box-sizing: border-box;
        border-radius: 50%;
        border: 2px solid var(--accent);
        background: var(--bg-surface);
        touch-action: none;
      }
      .port.in {
        inset-inline-start: -8px;
        inset-block-start: 50%;
        transform: translateY(-50%);
      }
      .port.out {
        inset-inline-end: -8px;
        inset-block-start: 50%;
        transform: translateY(-50%);
        cursor: crosshair;
      }
      .port.out.linked {
        background: var(--accent);
      }
      .port.out:hover,
      .port.out:focus-visible {
        outline: 3px solid var(--border-focus);
      }
      /* The board needs room: narrow widths get the list editor only. */
      .wide-only {
        display: block;
      }
      .narrow-only {
        display: none;
      }
      @container (max-width: 700px) {
        .wide-only {
          display: none;
        }
        .narrow-only {
          display: block;
        }
      }
      table {
        inline-size: 100%;
        border-collapse: collapse;
        font-size: var(--font-size-sm);
      }
      td {
        padding: var(--space-xs) var(--space-sm);
        border-block-end: 1px solid var(--border-color);
        overflow-wrap: anywhere;
        vertical-align: middle;
      }
      td.act {
        inline-size: 1%;
        white-space: nowrap;
      }
      .arrow {
        color: var(--text-muted);
      }
      .form {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(min(100%, 180px), 1fr));
        gap: var(--space-sm);
        align-items: end;
      }
    `
  ];
  static properties = {
    ...f.properties,
    runtime: { attribute: !1 },
    selected: { state: !0 },
    formFrom: { state: !0 },
    formOutcome: { state: !0 },
    formTo: { state: !0 },
    formError: { state: !0 }
  };
  /** Positions while a card is being dragged, before they are saved. */
  #e = /* @__PURE__ */ new Map();
  #s = null;
  #t = null;
  #n = "";
  constructor() {
    super(), this.runtime = null, this.selected = "", this.formFrom = "", this.formOutcome = "", this.formTo = "", this.formError = "";
  }
  #a = null;
  /** Undo / redo of the links and the card positions, for as long as this editor is open. */
  #i = new Cs();
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("keydown", this.#x), window.addEventListener("keydown", this.#f), this.#r();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("keydown", this.#x), window.removeEventListener("keydown", this.#f), this.#a?.(), this.#a = null;
  }
  willUpdate(e) {
    super.willUpdate(e), e.has("runtime") && this.#r();
  }
  /** The runtime object stays the same while its state changes, so listen to it. */
  #r() {
    this.#a?.(), this.#i.reset(this.runtime?.state ?? null), this.#a = this.runtime && this.isConnected ? this.runtime.subscribe(() => {
      const e = this.runtime?.state;
      e && this.#i.changed(e), this.requestUpdate();
    }) : null;
  }
  #u(e) {
    e && (this.selected = "", this.runtime?.mutate((t) => As(t, e)));
  }
  /** The host's undo / redo icons (components/icons/Icon.svelte); mirrored in right-to-left. */
  #c(e) {
    return q`<svg class=${this.#d === -1 ? "flip" : ""} width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
      ${e === "undo" ? q`<path d="M9 14 4 9l5-5"></path><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"></path>` : q`<path d="m15 14 5-5-5-5"></path><path d="M20 9H9.5a5.5 5.5 0 0 0 0 11H13"></path>`}
    </svg>`;
  }
  #o() {
    this.#u(this.#i.undo()), this.requestUpdate();
  }
  #l() {
    this.#u(this.#i.redo()), this.requestUpdate();
  }
  /**
   * Ctrl+Z undoes, Ctrl+Y (or Ctrl+Shift+Z) redoes; Cmd works the same on a Mac. Like the
   * dashboard editor it is a window-wide shortcut while the editor is open, so the user does
   * not have to click the board first. It stays out of the way of text fields (their own undo)
   * and of the task editor dialog.
   */
  #f = (e) => {
    if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
    const t = /^Key([A-Z])$/.exec(e.code ?? "")?.[1]?.toLowerCase() ?? e.key.toLowerCase(), s = t === "y" || t === "z" && e.shiftKey, n = t === "z" && !e.shiftKey;
    if (!n && !s) return;
    const a = e.composedPath();
    a[0]?.matches?.("input, select, textarea, [contenteditable]") || a.some((o) => o instanceof HTMLElement && (o.tagName === "DIALOG" || o.tagName === "TESSERA-MAINT-EDITOR")) || (e.preventDefault(), n ? this.#o() : this.#l());
  };
  // ----- geometry -------------------------------------------------------------
  get #d() {
    return getComputedStyle(this).direction === "rtl" ? -1 : 1;
  }
  #m() {
    const e = this.runtime?.state;
    if (!e) return {};
    const t = Vt(e), s = {};
    for (const n of M(e)) s[n.id] = this.#e.get(n.id) ?? e.layout?.[n.id] ?? t[n.id] ?? { x: 0, y: 0 };
    return s;
  }
  #v() {
    return this.renderRoot.querySelector(".board");
  }
  /** Centre of an element in board coordinates (works in either text direction). */
  #g(e, t) {
    const s = e.getBoundingClientRect();
    return { x: s.left + s.width / 2 - t.left, y: s.top + s.height / 2 - t.top };
  }
  /** Re-measures the dots and redraws every line. Called after each render and while dragging. */
  #p() {
    const e = this.#v(), t = this.runtime?.state;
    if (!e || !t) return;
    const s = e.getBoundingClientRect(), n = /* @__PURE__ */ new Map();
    for (const r of this.renderRoot.querySelectorAll("[data-port]")) n.set(r.dataset.port, r);
    const a = this.#d;
    for (const r of this.renderRoot.querySelectorAll("path[data-edge]")) {
      const [o, c, l] = r.dataset.edge.split("|"), d = n.get(`out:${o}:${c}`), u = n.get(`in:${l}`);
      d && u && r.setAttribute("d", je(this.#g(d, s), this.#g(u, s), a));
    }
  }
  updated(e) {
    super.updated(e), this.#p();
  }
  // ----- moving cards ---------------------------------------------------------
  #$(e, t) {
    if (e.button !== 0 || e.target.closest("button")) return;
    const s = e.currentTarget;
    s.setPointerCapture(e.pointerId), s.classList.add("dragging"), this.#s = { id: t, startX: e.clientX, startY: e.clientY, orig: this.#m()[t] ?? { x: 0, y: 0 }, moved: !1 };
  }
  #y(e) {
    const t = this.#s;
    if (!t) return;
    const s = (e.clientX - t.startX) * this.#d, n = e.clientY - t.startY;
    if (!t.moved && Math.hypot(s, n) < Es) return;
    t.moved = !0;
    const a = { x: Math.max(0, t.orig.x + s), y: Math.max(0, t.orig.y + n) };
    this.#e.set(t.id, a);
    const r = this.renderRoot.querySelector(`.node[data-id="${CSS.escape(t.id)}"]`);
    r && (r.style.insetInlineStart = `${a.x}px`, r.style.insetBlockStart = `${a.y}px`), this.#p();
  }
  #b(e) {
    const t = this.#s;
    if (this.#s = null, e.currentTarget.classList.remove("dragging"), !t?.moved || !this.runtime) {
      this.#e.clear();
      return;
    }
    this.runtime.setLayout({ ...this.#m() }), this.#e.clear();
  }
  // ----- linking --------------------------------------------------------------
  #h() {
    return this.renderRoot.querySelector("path.ghost");
  }
  #_(e, t, s) {
    e.button === 0 && (e.preventDefault(), e.stopPropagation(), e.currentTarget.setPointerCapture(e.pointerId), this.#t = { from: t, outcome: s });
  }
  #S(e) {
    if (!this.#t) return;
    const t = this.#v();
    if (!t) return;
    const s = t.getBoundingClientRect(), n = this.#g(e.currentTarget, s);
    this.#h()?.setAttribute("d", je(n, { x: e.clientX - s.left, y: e.clientY - s.top }, this.#d));
    const a = this.renderRoot.elementFromPoint(e.clientX, e.clientY)?.closest(".node"), r = a?.dataset.id ?? "";
    r !== this.#n && (this.renderRoot.querySelector(".node.target")?.classList.remove("target"), a && a.classList.add("target"), this.#n = r);
  }
  #w() {
    const e = this.#t, t = this.#n;
    this.#t = null, this.#n = "", this.renderRoot.querySelector(".node.target")?.classList.remove("target"), this.#h()?.setAttribute("d", ""), e && t && this.runtime && this.runtime.linkOutcome(e.from, e.outcome, t);
  }
  // ----- selection and the list editor ----------------------------------------
  #x = (e) => {
    e.key !== "Delete" && e.key !== "Backspace" || !this.selected || e.composedPath()[0]?.matches?.("input, select, textarea") || this.#A();
  };
  #z(e) {
    const t = this.runtime?.state;
    return t ? ne(t).find((s) => Ie(s) === e) : void 0;
  }
  #A() {
    const e = this.#z(this.selected);
    this.selected = "", e && this.runtime?.unlinkOutcome(e);
  }
  #C() {
    if (!this.runtime || !this.formFrom || !this.formOutcome || !this.formTo) return;
    const e = this.runtime.linkOutcome(this.formFrom, this.formOutcome, this.formTo);
    this.formError = e === "duplicate" ? this.t("maintenance.chains.duplicate") : "";
  }
  #k(e, t) {
    this.dispatchEvent(new CustomEvent(e, { detail: t, bubbles: !0, composed: !0 }));
  }
  // ----- rendering ------------------------------------------------------------
  #E(e, t) {
    const s = this.runtime, n = (o, c) => this.t(o, c), a = s.state.tasks.find((o) => o.id === e), r = s.evals.find((o) => o.taskId === e)?.status ?? "off";
    return h`<div
      class="node ${r}"
      data-id=${a.id}
      style="inset-inline-start:${t.x}px;inset-block-start:${t.y}px;inline-size:${be}px"
    >
      <div
        class="node-head"
        @pointerdown=${(o) => this.#$(o, a.id)}
        @pointermove=${(o) => this.#y(o)}
        @pointerup=${(o) => this.#b(o)}
        @pointercancel=${(o) => this.#b(o)}
        @dblclick=${() => this.#k("edit-task", { id: a.id })}
      >
        <span class="port in" data-port=${`in:${a.id}`}></span>
        <span class="node-title">${v(n, a)}${a.tool ? h` <span class="muted ltr">(${a.tool})</span>` : p}</span>
        <button class="small icon" title=${n("maintenance.common.edit")} aria-label=${n("maintenance.common.edit")} @click=${() => this.#k("edit-task", { id: a.id })}>…</button>
      </div>
      ${a.outcomes.map(
      (o) => h`<div class="row-out">
          <span>${k(n, o)}</span>
          <span
            class="port out ${o.activates.length > 0 ? "linked" : ""}"
            data-port=${`out:${a.id}:${o.id}`}
            role="button"
            aria-label=${n("maintenance.chains.dragHint", { name: k(n, o) })}
            title=${n("maintenance.chains.dragHint", { name: k(n, o) })}
            @pointerdown=${(c) => this.#_(c, a.id, o.id)}
            @pointermove=${(c) => this.#S(c)}
            @pointerup=${() => this.#w()}
            @pointercancel=${() => this.#w()}
          ></span>
        </div>`
    )}
    </div>`;
  }
  #T(e) {
    const t = this.runtime, s = t.state, n = (l, d) => this.t(l, d), a = M(s), r = (l) => {
      const d = s.tasks.find((u) => u.id === l);
      return d ? `${v(n, d)}${d.tool ? ` (${d.tool})` : ""}` : l;
    }, o = s.tasks.find((l) => l.id === this.formFrom)?.outcomes ?? [], c = !!(this.formFrom && this.formOutcome && this.formTo);
    return h`<section class="panel">
      <div class="panel-header"><span class="panel-title">${n("maintenance.chains.links")}</span></div>
      <div class="panel-body">
        ${e.length === 0 ? h`<p class="muted">${n("maintenance.chains.noLinks")}</p>` : h`<table>
              <tbody>
                ${e.map((l) => {
      const u = s.tasks.find((m) => m.id === l.from)?.outcomes.find((m) => m.id === l.outcome);
      return h`<tr>
                    <td>${r(l.from)}: <strong>${u ? k(n, u) : l.outcome}</strong></td>
                    <td class="arrow" aria-hidden="true">→</td>
                    <td>${r(l.to)}</td>
                    <td class="act"><button class="small danger" @click=${() => t.unlinkOutcome(l)}>${n("maintenance.chains.remove")}</button></td>
                  </tr>`;
    })}
              </tbody>
            </table>`}
        <span class="field-label">${n("maintenance.chains.addLink")}</span>
        <div class="form">
          <label class="field">
            <span class="field-label">${n("maintenance.chains.from")}</span>
            <select
              @change=${(l) => {
      this.formFrom = l.target.value, this.formOutcome = s.tasks.find((d) => d.id === this.formFrom)?.outcomes[0]?.id ?? "";
    }}
            >
              <option value="" ?selected=${!this.formFrom}></option>
              ${a.map((l) => h`<option value=${l.id} ?selected=${this.formFrom === l.id}>${r(l.id)}</option>`)}
            </select>
          </label>
          <label class="field">
            <span class="field-label">${n("maintenance.chains.outcome")}</span>
            <select @change=${(l) => this.formOutcome = l.target.value}>
              ${o.map((l) => h`<option value=${l.id} ?selected=${this.formOutcome === l.id}>${k(n, l)}</option>`)}
            </select>
          </label>
          <label class="field">
            <span class="field-label">${n("maintenance.chains.to")}</span>
            <select @change=${(l) => this.formTo = l.target.value}>
              <option value="" ?selected=${!this.formTo}></option>
              ${a.map((l) => h`<option value=${l.id} ?selected=${this.formTo === l.id}>${r(l.id)}</option>`)}
            </select>
          </label>
          <button class="primary" ?disabled=${!c} @click=${() => this.#C()}>${n("maintenance.chains.add")}</button>
        </div>
        ${this.formError ? h`<p class="warn">${this.formError}</p>` : p}
      </div>
    </section>`;
  }
  render() {
    const e = this.runtime, t = e?.state;
    if (!e || !t) return h``;
    const s = (d, u) => this.t(d, u), n = M(t), a = this.#m(), r = ne(t), o = Gt(n, a), c = at(t).some((d) => d.code === "cycle"), l = !!this.selected && !!this.#z(this.selected);
    return h`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title">${s("maintenance.chains.title")}</span>
          <span class="panel-meta">
            <button class="icon-btn" ?disabled=${!this.#i.canUndo} title=${s("maintenance.chains.undoHint")} aria-label=${s("maintenance.chains.undo")} @click=${() => this.#o()}>${this.#c("undo")}</button>
            <button class="icon-btn" ?disabled=${!this.#i.canRedo} title=${s("maintenance.chains.redoHint")} aria-label=${s("maintenance.chains.redo")} @click=${() => this.#l()}>${this.#c("redo")}</button>
            ${l ? h`<button class="danger" @click=${() => this.#A()}>${s("maintenance.chains.removeSelected")}</button>` : p}
            <button class="wide-only" ?disabled=${!t.layout} @click=${() => e.setLayout(null)}>${s("maintenance.chains.arrange")}</button>
            <button class="primary" @click=${() => this.#k("create-task")}>${s("maintenance.common.add")}</button>
          </span>
        </div>
        <div class="panel-body">
          <p class="muted wide-only">${s("maintenance.chains.hint")}</p>
          <p class="muted narrow-only">${s("maintenance.chains.hintNarrow")}</p>
          ${c ? h`<p class="warn">${s("maintenance.editor.cycle")}</p>` : p}
          <div class="scroller wide-only">
            <div class="board" style="inline-size:${o.w}px;block-size:${o.h}px" @click=${(d) => {
      d.target.closest("path.hit") || (this.selected = "");
    }}>
              <svg aria-hidden="true">
                <defs>
                  <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">
                    <path d="M 0 0 L 10 5 L 0 10 z" fill="var(--accent)" />
                  </marker>
                </defs>
                ${r.map((d) => {
      const u = Ie(d);
      return q`<path class="line ${this.selected === u ? "selected" : ""}" data-edge=${u} marker-end="url(#arrow)" d=""></path>
                    <path class="hit" data-edge=${u} d="" @click=${(m) => {
        m.stopPropagation(), this.selected = u;
      }}></path>`;
    })}
              </svg>
              ${n.map((d) => this.#E(d.id, a[d.id] ?? { x: 0, y: 0 }))}
              <svg class="top" aria-hidden="true"><path class="ghost" d=""></path></svg>
            </div>
          </div>
        </div>
      </section>
      ${this.#T(r)}
    `;
  }
}
class Ms extends f {
  static styles = [
    z,
    y`
      dialog {
        inline-size: min(640px, calc(100vw - 2 * var(--space-md)));
        max-block-size: calc(100dvh - 2 * var(--space-md));
        padding: 0;
        border: 1px solid var(--border-color);
        border-radius: var(--radius-md);
        background: var(--bg-surface);
        color: var(--text-primary);
        font-family: var(--font-family, inherit);
        overflow: auto;
      }
      dialog::backdrop {
        background: rgba(0, 0, 0, 0.5);
      }
      label.check {
        display: flex;
        align-items: center;
        gap: var(--space-sm);
        min-block-size: 32px;
        overflow-wrap: anywhere;
      }
      textarea {
        min-width: 0;
        min-block-size: 64px;
        padding: var(--space-xs) var(--space-sm);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        background: var(--bg-surface);
        color: var(--text-primary);
        font: inherit;
        font-size: var(--font-size-sm);
        resize: vertical;
      }
      .outcome {
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        padding: var(--space-sm);
        display: flex;
        flex-direction: column;
        gap: var(--space-xs);
      }
      .targets {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 2px var(--space-sm);
      }
    `
  ];
  static properties = {
    ...f.properties,
    runtime: { attribute: !1 },
    draft: { state: !0 },
    creating: { state: !0 },
    newName: { state: !0 },
    newKind: { state: !0 }
  };
  constructor() {
    super(), this.runtime = null, this.draft = null, this.creating = !1, this.newName = "", this.newKind = "interval";
  }
  get #e() {
    return this.renderRoot.querySelector("dialog");
  }
  /** Opens the dialog for an existing task. */
  edit(e) {
    const t = this.runtime?.state?.tasks.find((s) => s.id === e);
    t && (this.draft = structuredClone(t), this.creating = !1, this.updateComplete.then(() => this.#e?.showModal()));
  }
  /** Opens the dialog on the first step of creating a custom task. */
  create() {
    this.draft = null, this.creating = !0, this.newName = "", this.newKind = "interval", this.updateComplete.then(() => this.#e?.showModal());
  }
  #s() {
    this.#e?.close(), this.draft = null, this.creating = !1;
  }
  #t(e) {
    if (!this.draft) return;
    const t = structuredClone(this.draft);
    e(t), this.draft = t;
  }
  #n(e, t) {
    const s = this.draft, n = s[t === "adjust" ? "counter" : t], a = t === "adjust" ? s.counter.adjust[e] ?? "" : n[e] ?? "";
    return h`
      <label class="field">
        <span class="field-label">${this.t(`maintenance.unitName.${e}`)}</span>
        <input
          type="number"
          step="any"
          .value=${String(a)}
          @input=${(r) => {
      const o = r.target.value, c = o === "" ? void 0 : Number(o);
      this.#t((l) => {
        const d = t === "adjust" ? l.counter.adjust : l[t];
        c === void 0 || !Number.isFinite(c) ? delete d[e] : d[e] = c;
      });
    }}
        />
      </label>
    `;
  }
  #a() {
    const e = this.draft;
    !e || !this.runtime || (this.runtime.updateTask(e.id, () => e), this.#s());
  }
  #i() {
    !this.draft || !this.runtime || window.confirm(this.t("maintenance.editor.deleteConfirm")) && (this.runtime.deleteTask(this.draft.id), this.#s());
  }
  #r() {
    const e = this.newName.trim();
    if (!e || !this.runtime) return;
    const t = this.runtime.addCustomTask(e, this.newKind);
    this.creating = !1, t && this.edit(t);
  }
  #u() {
    const e = (t) => this.t(t);
    return h`
      <div class="panel-header"><span class="panel-title">${e("maintenance.editor.newTitle")}</span></div>
      <div class="panel-body">
        <label class="field">
          <span class="field-label">${e("maintenance.editor.name")}</span>
          <input .value=${this.newName} @input=${(t) => this.newName = t.target.value} />
        </label>
        <label class="field">
          <span class="field-label">${e("maintenance.editor.kind")}</span>
          <select .value=${this.newKind} @change=${(t) => this.newKind = t.target.value}>
            <option value="interval">${e("maintenance.editor.kindInterval")}</option>
            <option value="followup">${e("maintenance.editor.kindFollowup")}</option>
          </select>
        </label>
        <div class="row">
          <button class="primary" ?disabled=${!this.newName.trim()} @click=${() => this.#r()}>${e("maintenance.common.create")}</button>
          <button @click=${() => this.#s()}>${e("maintenance.common.cancel")}</button>
        </div>
      </div>
    `;
  }
  #c(e, t, s) {
    const n = (o, c) => this.t(o, c), a = s.defId === "custom", r = (this.runtime?.state?.tasks ?? []).filter((o) => o.kind !== "precheck");
    return h`
      <div class="outcome">
        <div class="row">
          ${a ? h`<input
                class="grow"
                aria-label=${n("maintenance.editor.outcomeLabel")}
                placeholder=${n("maintenance.editor.outcomeLabel")}
                .value=${e.label ?? ""}
                @input=${(o) => this.#t((c) => c.outcomes[t].label = o.target.value)}
              />` : h`<strong class="grow">${k(n, e)}</strong>`}
          ${a && s.outcomes.length > 1 ? h`<button class="small danger" @click=${() => this.#t((o) => o.outcomes.splice(t, 1))}>${n("maintenance.editor.removeOutcome")}</button>` : p}
        </div>
        <label class="check">
          <input type="checkbox" .checked=${e.resetsTimer} @change=${(o) => this.#t((c) => c.outcomes[t].resetsTimer = o.target.checked)} />
          ${n("maintenance.editor.resetsTimer")}
        </label>
        ${s.kind === "followup" ? h`<label class="check">
              <input type="checkbox" .checked=${!!e.completes} @change=${(o) => this.#t((c) => c.outcomes[t].completes = o.target.checked)} />
              ${n("maintenance.editor.completes")}
            </label>` : p}
        <span class="field-label">${n("maintenance.editor.triggers")}</span>
        <div class="targets">
          ${r.map(
      (o) => h`<label class="check">
              <input
                type="checkbox"
                .checked=${e.activates.includes(o.id)}
                @change=${(c) => this.#t((l) => {
        const d = l.outcomes[t].activates, u = c.target.checked;
        l.outcomes[t].activates = u ? [...d, o.id] : d.filter((m) => m !== o.id);
      })}
              />
              <span>${v(n, o)}${o.tool ? ` (${o.tool})` : ""}</span>
            </label>`
    )}
        </div>
      </div>
    `;
  }
  #o(e) {
    const t = (r, o) => this.t(r, o), s = e.defId === "custom", n = this.runtime?.state ? { tasks: this.runtime.state.tasks.map((r) => r.id === e.id ? e : r) } : null, a = n ? at(n).some((r) => r.code === "cycle") : !1;
    return h`
      <div class="panel-header"><span class="panel-title">${t("maintenance.editor.title")}: ${v(t, e)}</span></div>
      <div class="panel-body">
        <label class="check">
          <input type="checkbox" .checked=${e.enabled} @change=${(r) => this.#t((o) => o.enabled = r.target.checked)} />
          ${t("maintenance.editor.enabled")}
        </label>
        ${s ? h`
              <label class="field">
                <span class="field-label">${t("maintenance.editor.name")}</span>
                <input .value=${e.name ?? ""} @input=${(r) => this.#t((o) => o.name = r.target.value)} />
              </label>
              <label class="field">
                <span class="field-label">${t("maintenance.editor.instruction")}</span>
                <textarea .value=${e.instruction ?? ""} @input=${(r) => this.#t((o) => o.instruction = r.target.value)}></textarea>
              </label>
            ` : p}
        ${e.kind === "interval" ? h`
              <span class="field-label">${t("maintenance.editor.intervals")}</span>
              <div class="fields">${ee.map((r) => this.#n(r, "intervals"))}</div>
              <span class="field-label">${t("maintenance.editor.lead")}</span>
              <div class="fields">${ee.map((r) => this.#n(r, "lead"))}</div>
              <p class="muted">${t("maintenance.editor.leadHint")}</p>
              <span class="field-label">${t("maintenance.editor.adjust")}</span>
              <div class="fields">${ee.filter((r) => r !== "days").map((r) => this.#n(r, "adjust"))}</div>
              <p class="muted">${t("maintenance.editor.adjustHint")}</p>
            ` : p}
        <label class="check">
          <input type="checkbox" .checked=${e.guard} @change=${(r) => this.#t((o) => o.guard = r.target.checked)} />
          ${t("maintenance.editor.guard")}
        </label>
        <label class="check">
          <input type="checkbox" .checked=${e.notify} @change=${(r) => this.#t((o) => o.notify = r.target.checked)} />
          ${t("maintenance.editor.notify")}
        </label>

        <span class="field-label">${t("maintenance.editor.outcomes")}</span>
        ${e.outcomes.map((r, o) => this.#c(r, o, e))}
        ${s ? h`<div class="row">
              <button
                class="small"
                @click=${() => this.#t(
      (r) => r.outcomes.push({ id: `r${Date.now().toString(36)}`, label: "", resetsTimer: r.kind === "interval", activates: [] })
    )}
              >
                ${t("maintenance.editor.addOutcome")}
              </button>
            </div>` : p}
        ${a ? h`<p class="warn">${t("maintenance.editor.cycle")}</p>` : p}

        <div class="row">
          <button class="primary" @click=${() => this.#a()}>${t("maintenance.common.save")}</button>
          <button @click=${() => this.#s()}>${t("maintenance.common.cancel")}</button>
          <span class="grow"></span>
          ${s ? h`<button class="danger" @click=${() => this.#i()}>${t("maintenance.common.delete")}</button>` : p}
        </div>
      </div>
    `;
  }
  render() {
    return h`<dialog @close=${() => {
      this.draft = null, this.creating = !1;
    }}>
      ${this.creating ? this.#u() : this.draft ? this.#o(this.draft) : p}
    </dialog>`;
  }
}
const Is = 864e5;
function Os(i, e, t, s) {
  if (!i.onboarding.done) return { items: [], state: i };
  const n = new Map(e.map((c) => [c.taskId, c])), a = [];
  let r = !1;
  const o = i.tasks.map((c) => {
    const l = n.get(c.id), d = c.notified;
    if (!l || l.status === "ok" || l.status === "off")
      return d ? (r = !0, { ...c, notified: null }) : c;
    if (!i.settings.notifications || !c.notify) return c;
    const u = l.status;
    return !d || u === "overdue" && d.level === "soon" || u === "overdue" && d.level === "overdue" && s === "printEnd" && t - d.at >= Is ? (a.push({ taskId: c.id, level: u }), r = !0, { ...c, notified: { level: u, at: t } }) : c;
  });
  return { items: a, state: r ? { ...i, tasks: o } : i };
}
const V = /* @__PURE__ */ new Map();
let De = null;
function Ns(i, e, t, s = Date.now()) {
  const n = e.state;
  if (!n) return;
  const a = Os(n, e.evals, s, t);
  a.state !== n && e.mutate(() => a.state);
  for (const r of a.items) {
    const o = n.tasks.find((l) => l.id === r.taskId), c = e.evals.find((l) => l.taskId === r.taskId);
    !o || !c || i.notifications.push({
      severity: r.level === "overdue" ? "error" : "info",
      text: $s((l, d) => i.i18n.t(l, d), o, c, r.level),
      label: i.i18n.t("maintenance.notify.label"),
      // The printer is passed explicitly: this runs for every printer, not only the active one.
      printerId: e.printerId
    });
  }
}
function Be(i, e) {
  if (V.has(e)) return;
  const t = le(i, e);
  V.set(e, t.onEvent((s) => Ns(i, t, s)));
}
function js(i) {
  for (const e of i.printers) Be(i, e.id);
  De || (De = i.onPrintersChange((e) => {
    for (const s of e) Be(i, s.id);
    const t = new Set(e.map((s) => s.id));
    for (const [s, n] of V)
      t.has(s) || (n(), V.delete(s));
  }));
}
function Ps(i, e) {
  if (!i || !e || !i.onboarding.done || !i.settings.guard) return { action: "allow" };
  const t = new Map(e.map((a) => [a.taskId, a])), s = i.tasks.filter((a) => a.enabled && a.guard && a.kind !== "precheck" && t.get(a.id)?.status === "overdue").map((a) => a.id), n = i.tasks.some((a) => a.kind === "precheck" && a.enabled);
  return s.length === 0 && !n ? { action: "allow" } : { action: "freeze", overdue: s, bedCheck: n };
}
const Rs = "maintenance.guard.cancelled";
let K = null;
const ye = [], de = /* @__PURE__ */ new Set();
function Ke(i) {
  K = i;
}
function lt() {
  for (const i of de) i();
}
function Hs(i) {
  return de.add(i), () => de.delete(i);
}
function Fe() {
  return ye[0] ?? null;
}
function Zs(i, e, t) {
  try {
    if (!K) return { action: "allow" };
    const s = t?.targetPrinterId ?? i.targetPrinterId ?? K.printer.id, n = oe(s);
    if (!n?.state) return { action: "allow" };
    n.reevaluate();
    const a = Ps(n.state, n.evals);
    if (a.action === "allow") return a;
    const r = i.params?.filename;
    return ye.push({
      token: e,
      printerId: s,
      method: i.method,
      filename: typeof r == "string" ? r : "",
      overdue: a.overdue,
      bedCheck: a.bedCheck
    }), lt(), { action: "freeze" };
  } catch (s) {
    return console.warn("[maintenance] guard failed, letting the print through", s), { action: "allow" };
  }
}
function Ls(i) {
  const e = ye.shift();
  return e ? (i ? K?.guards.resume(e.token, "accept") : K?.guards.resume(e.token, "deny", Rs), lt(), e) : null;
}
class Us extends f {
  static styles = [
    z,
    y`
      :host {
        display: contents;
      }
      .backdrop {
        position: fixed;
        inset: 0;
        z-index: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: var(--space-md);
        background: rgba(0, 0, 0, 0.55);
      }
      .dialog {
        inline-size: min(760px, 100%);
        max-block-size: 100%;
        overflow: auto;
      }
      label.check {
        display: flex;
        align-items: center;
        gap: var(--space-sm);
        min-block-size: 36px;
        overflow-wrap: anywhere;
      }
      ul {
        margin: 0;
        padding-inline-start: var(--space-lg);
        display: flex;
        flex-direction: column;
        gap: var(--space-xs);
      }
      h4 {
        margin: 0;
        font-size: var(--font-size-md);
      }
    `
  ];
  static properties = {
    ...f.properties,
    pending: { state: !0 },
    confirmed: { state: !0 }
  };
  #e = (e) => {
    e.key === "Escape" && this.pending && this.#t(!1);
  };
  constructor() {
    super(), this.pending = null, this.confirmed = !1;
  }
  attachApi(e) {
    super.attachApi(e), Ke(e), js(e), this.pending = Fe(), this.track(Hs(() => this.#s())), window.addEventListener("keydown", this.#e), this.track(() => {
      window.removeEventListener("keydown", this.#e), Ke(null);
    });
  }
  #s() {
    const e = Fe();
    e?.token !== this.pending?.token && (this.confirmed = !1), this.pending = e;
  }
  #t(e, t = !1) {
    const s = this.pending;
    if (!s) return;
    const n = oe(s.printerId), a = s.overdue.map((r) => n?.state?.tasks.find((o) => o.id === r)).filter((r) => !!r).map((r) => v((o, c) => this.t(o, c), r));
    Ls(e), e && a.length > 0 && n?.logEvent(a.join(", "), "startedAnyway"), t && (location.hash = ot(s.printerId));
  }
  render() {
    const e = this.pending;
    if (!e || !this.api) return h``;
    const t = (r, o) => this.t(r, o), s = oe(e.printerId), n = e.overdue.map((r) => {
      const o = s?.state?.tasks.find((l) => l.id === r), c = s?.evals.find((l) => l.taskId === r);
      return o && c ? { task: o, ev: c } : null;
    }).filter((r) => !!r), a = !e.bedCheck || this.confirmed;
    return h`
      <div class="backdrop" role="presentation">
        <section class="panel dialog" role="dialog" aria-modal="true" aria-label=${t("maintenance.guard.title")}>
          <div class="panel-header">
            <span class="panel-title">${t("maintenance.guard.title")}</span>
            ${e.filename ? h`<span class="chip ltr">${e.filename}</span>` : p}
          </div>
          <div class="panel-body">
            ${e.bedCheck ? h`
                  <h4>${t("maintenance.guard.bedTitle")}</h4>
                  <tessera-maint-cameras .api=${this.api} .printerId=${e.printerId}></tessera-maint-cameras>
                  <label class="check">
                    <input type="checkbox" .checked=${this.confirmed} @change=${(r) => this.confirmed = r.target.checked} />
                    ${t("maintenance.guard.bedConfirm")}
                  </label>
                ` : p}
            ${n.length > 0 ? h`
                  <h4>${t("maintenance.guard.overdueTitle")}</h4>
                  <ul>
                    ${n.map(({ task: r, ev: o }) => {
      const c = ve(o);
      return h`<li>
                        ${v(t, r)}${r.tool ? h` <span class="muted ltr">(${r.tool})</span>` : p}
                        <span class="muted">${o.triggered || !c ? "" : `- ${J(t, c)}`}</span>
                      </li>`;
    })}
                  </ul>
                  <p class="muted">${t("maintenance.guard.overdueHint")}</p>
                ` : p}
            <div class="row">
              <button class="primary" ?disabled=${!a} @click=${() => this.#t(!0)}>${t(n.length > 0 ? "maintenance.guard.startAnyway" : "maintenance.guard.start")}</button>
              <button @click=${() => this.#t(!1)}>${t("maintenance.common.cancel")}</button>
              ${n.length > 0 ? h`<button @click=${() => this.#t(!1, !0)}>${t("maintenance.guard.open")}</button>` : p}
            </div>
          </div>
        </section>
      </div>
    `;
  }
}
class Ds extends ce {
  static styles = [
    z,
    $e,
    y`
      .cards {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(min(100%, 340px), 1fr));
        gap: var(--space-md);
        align-items: start;
      }
      /* The selected section looks like a primary button, the others like neutral ones. */
      .nav button[aria-pressed='true'] {
        background: var(--accent);
        color: #fff;
        font-weight: 600;
      }
      table {
        inline-size: 100%;
        border-collapse: collapse;
        font-size: var(--font-size-sm);
      }
      th,
      td {
        text-align: start;
        padding: var(--space-xs) var(--space-sm);
        border-block-end: 1px solid var(--border-color);
        vertical-align: top;
        overflow-wrap: anywhere;
      }
      label.check {
        display: flex;
        align-items: center;
        gap: var(--space-sm);
        min-block-size: 32px;
      }
      .journal-wrap {
        overflow-x: auto;
      }
    `
  ];
  static properties = {
    ...ce.properties,
    section: { state: !0 },
    rerun: { state: !0 },
    notice: { state: !0 }
  };
  constructor() {
    super(), this.section = "tasks", this.rerun = !1, this.notice = "";
  }
  get #e() {
    return this.renderRoot.querySelector("tessera-maint-editor");
  }
  #s(e) {
    const t = e.detail.triggered, s = this.runtime?.state?.tasks ?? [];
    this.notice = t.length ? this.t("maintenance.pressed", {
      names: t.map((n) => s.find((a) => a.id === n)).filter((n) => !!n).map((n) => v((a, r) => this.t(a, r), n)).join(", ")
    }) : "";
  }
  #t() {
    const e = this.runtime, t = e.state, s = (d, u) => this.t(d, u), n = nt(t, e.evals), a = t.tasks.filter((d) => !n.some((u) => u.task.id === d.id) && (!d.enabled || d.kind === "interval")).map((d) => ({ task: d, evaluation: { taskId: d.id, status: "off", triggered: !1, units: [] } })), r = st(e.evals), o = n, c = ({ task: d, evaluation: u }) => h`<tessera-maint-card .api=${this.api} .runtime=${e} .task=${d} .evaluation=${u}></tessera-maint-card>`, l = {
      pressed: (d) => this.#s(d),
      edit: (d) => this.#e?.edit(d.detail.id)
    };
    return h`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title">${s("maintenance.summary.activeTitle")}</span>
          <span class="panel-meta">
            ${r.overdue > 0 ? h`<span class="chip overdue">${s("maintenance.summary.overdue", { n: r.overdue })}</span>` : p}
            ${r.soon > 0 ? h`<span class="chip soon">${s("maintenance.summary.soon", { n: r.soon })}</span>` : p}
            ${r.overdue + r.soon === 0 ? h`<span class="chip live">${s("maintenance.summary.allOk")}</span>` : p}
            <button class="primary" @click=${() => this.#e?.create()}>${s("maintenance.common.add")}</button>
          </span>
        </div>
        <div class="panel-body">
          ${this.notice ? h`<p class="ok">${this.notice}</p>` : p}
          ${o.length === 0 ? h`<p class="muted">${s("maintenance.noTasks")}</p>` : h`<div class="cards" @pressed=${l.pressed} @edit-task=${l.edit}>${o.map(c)}</div>`}
        </div>
      </section>
      ${a.length > 0 ? h`<section class="panel">
            <div class="panel-header"><span class="panel-title">${s("maintenance.summary.disabledTitle")}</span></div>
            <div class="panel-body">
              <div class="cards" @pressed=${l.pressed} @edit-task=${l.edit}>${a.map(c)}</div>
            </div>
          </section>` : p}
    `;
  }
  #n() {
    const e = this.runtime, t = (r, o) => this.t(r, o);
    if (e.journal.length === 0) return h`<p class="muted">${t("maintenance.journal.empty")}</p>`;
    const s = this.api?.i18n.locale, n = (r) => new Date(r.at).toLocaleString(s), a = (r) => {
      const c = e.state?.tasks.find((d) => d.id === r.taskId)?.outcomes.find((d) => d.id === r.outcomeId);
      if (c) return k(t, c);
      const l = `maintenance.journalEvent.${r.outcomeId}`;
      return t(l) !== l ? t(l) : r.outcomeId;
    };
    return h`
      <div class="row">
        <span class="grow"></span>
        <button class="small" @click=${() => this.#a()}>${t("maintenance.journal.export")}</button>
      </div>
      <div class="journal-wrap">
        <table>
          <tbody>
            ${e.journal.map(
      (r) => h`<tr>
                <td class="ltr">${n(r)}</td>
                <td>${r.taskLabel}</td>
                <td>${a(r)}</td>
                <td>${r.note ?? ""}</td>
              </tr>`
    )}
          </tbody>
        </table>
      </div>
    `;
  }
  #a() {
    const e = this.runtime;
    if (!e) return;
    const t = (o) => `"${o.replace(/"/g, '""')}"`, s = e.journal.map((o) => [new Date(o.at).toISOString(), o.taskLabel, o.outcomeId, o.note ?? ""].map(t).join(",")), n = new Blob(["\uFEFF", ["time,task,result,note", ...s].join(`
`)], { type: "text/csv;charset=utf-8" }), a = URL.createObjectURL(n), r = document.createElement("a");
    r.href = a, r.download = "maintenance-journal.csv", r.click(), URL.revokeObjectURL(a);
  }
  #i() {
    const e = this.runtime, t = e.state, s = (a) => this.t(a), n = t.tasks.find((a) => a.kind === "precheck");
    return h`
      <div class="panel">
        <div class="panel-body">
          <label class="check">
            <input type="checkbox" .checked=${t.settings.notifications} @change=${(a) => e.updateSettings({ notifications: a.target.checked })} />
            <span><strong>${s("maintenance.settings.notifications")}</strong><br /><span class="muted">${s("maintenance.settings.notificationsHint")}</span></span>
          </label>
          <label class="check">
            <input type="checkbox" .checked=${t.settings.guard} @change=${(a) => e.updateSettings({ guard: a.target.checked })} />
            <span><strong>${s("maintenance.settings.guard")}</strong><br /><span class="muted">${s("maintenance.settings.guardHint")}</span></span>
          </label>
          ${n ? h`<label class="check">
                <input
                  type="checkbox"
                  .checked=${n.enabled}
                  @change=${(a) => {
      const r = a.target.checked;
      e.mutate((o) => ({ ...o, tasks: o.tasks.map((c) => c.id === n.id ? { ...c, enabled: r } : c) }));
    }}
                />
                <span><strong>${s("maintenance.settings.bedCheck")}</strong><br /><span class="muted">${s("maintenance.task.bed-check.why")}</span></span>
              </label>` : p}
          <div class="row"><button @click=${() => this.rerun = !0}>${s("maintenance.settings.wizard")}</button></div>
          <p class="muted">${s("maintenance.settings.counters")}</p>
        </div>
      </div>
    `;
  }
  render() {
    const e = this.runtime;
    if (!e || !e.state) return h`<p class="muted">${this.t("maintenance.loading")}</p>`;
    const t = (s) => this.t(s);
    return !e.state.onboarding.done || this.rerun ? h`<tessera-maint-wizard
        .api=${this.api}
        .runtime=${e}
        .rerun=${this.rerun}
        @wizard-done=${() => this.rerun = !1}
      ></tessera-maint-wizard>` : h`
      <div class="row nav" role="group">
        ${["tasks", "chains", "journal", "settings"].map(
      (s) => h`<button aria-pressed=${this.section === s} @click=${() => this.section = s}>${t(`maintenance.nav.${s}`)}</button>`
    )}
      </div>
      ${this.section === "tasks" ? this.#t() : this.section === "chains" ? h`<tessera-maint-chains
              .api=${this.api}
              .runtime=${e}
              @edit-task=${(s) => this.#e?.edit(s.detail.id)}
              @create-task=${() => this.#e?.create()}
            ></tessera-maint-chains>` : this.section === "journal" ? this.#n() : this.#i()}
      <tessera-maint-editor .api=${this.api} .runtime=${e}></tessera-maint-editor>
    `;
  }
}
const te = 5;
class Bs extends ce {
  static styles = [
    z,
    $e,
    y`
      :host {
        block-size: 100%;
        overflow: auto;
      }
      ul {
        list-style: none;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        gap: var(--space-xs);
      }
      li {
        display: flex;
        align-items: center;
        gap: var(--space-sm);
        flex-wrap: wrap;
        min-width: 0;
      }
      li .name {
        flex: 1;
        min-width: 8em;
        overflow-wrap: anywhere;
      }
      a {
        color: var(--accent);
        font-size: var(--font-size-sm);
      }
    `
  ];
  render() {
    const e = this.runtime;
    if (!e || !e.state) return h`<p class="muted">${this.t("maintenance.loading")}</p>`;
    const t = (o, c) => this.t(o, c), s = ot(e.printerId);
    if (!e.state.onboarding.done)
      return h`<a href=${s}>${t("maintenance.wizard.title")}</a>`;
    const n = nt(e.state, e.evals).filter((o) => o.evaluation.status === "overdue" || o.evaluation.status === "soon"), a = st(e.evals), r = n.slice(0, te);
    return h`
      <div class="row">
        ${a.overdue > 0 ? h`<span class="chip overdue">${t("maintenance.summary.overdue", { n: a.overdue })}</span>` : p}
        ${a.soon > 0 ? h`<span class="chip soon">${t("maintenance.summary.soon", { n: a.soon })}</span>` : p}
        ${a.overdue + a.soon === 0 ? h`<span class="chip live">${t("maintenance.summary.allOk")}</span>` : p}
      </div>
      <ul>
        ${r.map(({ task: o, evaluation: c }) => {
      const l = ve(c);
      return h`<li>
            <span class="name">${v(t, o)}${o.tool ? h` <span class="muted ltr">(${o.tool})</span>` : p}</span>
            <span class="chip ${c.status}">${l && !c.triggered ? J(t, l) : t(rt(c.status))}</span>
          </li>`;
    })}
      </ul>
      ${n.length > te ? h`<p class="muted">${t("maintenance.widget.more", { n: n.length - te })}</p>` : p}
      <a href=${s}>${t("maintenance.widget.openTab")}</a>
    `;
  }
}
const Ks = ["ball-liquid", "ball-grease", "carbon", "none"], Fs = ["x", "y", "z"];
class qs extends f {
  static styles = [
    z,
    y`
      fieldset {
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        margin: 0;
        padding: var(--space-sm) var(--space-md);
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: var(--space-xs);
      }
      legend {
        font-weight: 600;
        padding-inline: var(--space-xs);
      }
      label {
        display: flex;
        align-items: center;
        gap: var(--space-sm);
        min-block-size: 32px;
        overflow-wrap: anywhere;
      }
      input[type='number'] {
        inline-size: 6em;
      }
      .axis {
        display: grid;
        grid-template-columns: max-content 1fr;
        gap: var(--space-sm);
        align-items: center;
      }
      @container (max-width: 520px) {
        .axis {
          grid-template-columns: 1fr;
        }
      }
    `
  ];
  static properties = {
    ...f.properties,
    runtime: { attribute: !1 },
    answers: { state: !0 },
    rerun: { type: Boolean }
  };
  constructor() {
    super(), this.runtime = null, this.answers = null, this.rerun = !1;
  }
  willUpdate(e) {
    if (super.willUpdate(e), !this.answers && this.runtime?.state) {
      const t = this.#e();
      this.answers = structuredClone(this.runtime.state.onboarding.answers ?? is(t));
      for (const s of t)
        this.answers.nozzle[s] ??= { type: "brass" }, this.answers.feeder[s] ??= { type: "regular" };
    }
  }
  #e() {
    const e = this.runtime?.state?.tasks.flatMap((t) => t.defId === "nozzle" && t.tool ? [t.tool] : []) ?? [];
    return e.length > 0 ? e : ["extruder"];
  }
  #s() {
    this.dispatchEvent(new CustomEvent("wizard-done", { bubbles: !0, composed: !0 }));
  }
  #t(e) {
    if (!this.answers) return;
    const t = structuredClone(this.answers);
    e(t), this.answers = t;
  }
  #n(e, t, s, n, a) {
    return h`<label><input type="radio" name=${e} .checked=${s} @change=${a} />${n}</label>`;
  }
  render() {
    const e = this.answers;
    if (!e || !this.runtime) return h``;
    const t = (n, a) => this.t(n, a), s = this.#e();
    return h`
      <section class="panel">
        <div class="panel-header"><span class="panel-title">${t("maintenance.wizard.title")}</span></div>
        <div class="panel-body">
          <p class="muted">${t("maintenance.wizard.intro")}</p>

          <fieldset>
            <legend>${t("maintenance.wizard.bedCheck.title")}</legend>
            <p class="muted">${t("maintenance.wizard.bedCheck.text")}</p>
            ${this.#n("bed", "on", e.bedCheck, t("maintenance.wizard.bedCheck.on"), () => this.#t((n) => n.bedCheck = !0))}
            ${this.#n("bed", "off", !e.bedCheck, t("maintenance.wizard.bedCheck.off"), () => this.#t((n) => n.bedCheck = !1))}
          </fieldset>

          <fieldset>
            <legend>${t("maintenance.wizard.wash.title")}</legend>
            <p class="muted">${t("maintenance.task.bed-wash.why")}</p>
            ${["glue-stick", "normal", "custom"].map(
      (n) => this.#n(
        "wash",
        n,
        e.wash.habit === n,
        t(n === "glue-stick" ? "maintenance.wizard.wash.glue" : n === "normal" ? "maintenance.wizard.wash.normal" : "maintenance.wizard.wash.custom"),
        () => this.#t((a) => a.wash.habit = n)
      )
    )}
            ${e.wash.habit === "custom" ? h`<input
                  type="number"
                  min="1"
                  .value=${String(e.wash.days ?? 7)}
                  @input=${(n) => this.#t((a) => a.wash.days = Number(n.target.value) || 7)}
                />` : p}
          </fieldset>

          <fieldset>
            <legend>${t("maintenance.wizard.rails.title")}</legend>
            <p class="muted">${t("maintenance.wizard.rails.text")}</p>
            <p class="muted">${t("maintenance.task.lube-axes.why")}</p>
            ${Fs.map(
      (n) => h`
                <div class="axis">
                  <span>${t(`maintenance.wizard.axis.${n}`)}</span>
                  <select
                    .value=${e.rails[n]}
                    @change=${(a) => this.#t((r) => r.rails[n] = a.target.value)}
                  >
                    ${Ks.map((a) => h`<option value=${a} ?selected=${e.rails[n] === a}>${t(`maintenance.rail.${a}`)}</option>`)}
                  </select>
                </div>
              `
    )}
          </fieldset>

          <fieldset>
            <legend>${t("maintenance.wizard.belts.title")}</legend>
            <p class="muted">${t("maintenance.task.belts.why")}</p>
            ${this.#n("belts", "on", e.belts, t("maintenance.wizard.belts.on"), () => this.#t((n) => n.belts = !0))}
            ${this.#n("belts", "off", !e.belts, t("maintenance.wizard.belts.off"), () => this.#t((n) => n.belts = !1))}
          </fieldset>

          ${s.map(
      (n) => h`
              <fieldset>
                <legend>${t("maintenance.wizard.nozzle.title")} <span class="chip ltr">${n}</span></legend>
                <p class="muted">${t("maintenance.task.nozzle.why")}</p>
                ${["brass", "hardened", "custom"].map(
        (a) => this.#n(
          `nozzle-${n}`,
          a,
          e.nozzle[n]?.type === a,
          t(`maintenance.wizard.nozzle.${a}`),
          () => this.#t((r) => r.nozzle[n] = { type: a, km: r.nozzle[n]?.km })
        )
      )}
                ${e.nozzle[n]?.type === "custom" ? h`<input
                      type="number"
                      min="0.1"
                      step="0.1"
                      .value=${String(e.nozzle[n]?.km ?? 10)}
                      @input=${(a) => this.#t((r) => r.nozzle[n] = { type: "custom", km: Number(a.target.value) || 10 })}
                    />` : p}
              </fieldset>
              <fieldset>
                <legend>${t("maintenance.wizard.feeder.title")} <span class="chip ltr">${n}</span></legend>
                <p class="warn">${t("maintenance.wizard.feeder.warning")}</p>
                ${["regular", "planetary"].map(
        (a) => this.#n(
          `feeder-${n}`,
          a,
          e.feeder[n]?.type === a,
          t(`maintenance.wizard.feeder.${a}`),
          () => this.#t((r) => r.feeder[n] = { type: a })
        )
      )}
              </fieldset>
            `
    )}

          <fieldset>
            <legend>${t("maintenance.wizard.custom.title")}</legend>
            <p class="muted">${t("maintenance.wizard.custom.text")}</p>
          </fieldset>

          <div class="row">
            <button
              class="primary"
              @click=${() => {
      this.runtime?.finishWizard(e), this.#s();
    }}
            >
              ${t("maintenance.wizard.finish")}
            </button>
            <button
              @click=${() => {
      this.rerun || this.runtime?.skipWizard(), this.#s();
    }}
            >
              ${this.rerun ? t("maintenance.wizard.cancel") : t("maintenance.wizard.skip")}
            </button>
          </div>
        </div>
      </section>
    `;
  }
}
x("tessera-maintenance-tab", Ds);
x("tessera-maintenance-widget", Bs);
x("tessera-maint-card", ys);
x("tessera-maint-editor", Ms);
x("tessera-maint-wizard", qs);
x("tessera-maint-cameras", zs);
x("tessera-maint-chains", Ts);
x("tessera-maintenance-overlay", Us);
const Vs = { en: fs, ru: gs };
export {
  Zs as guardPrintStart,
  Vs as locales
};
