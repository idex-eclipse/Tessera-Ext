/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Cn = globalThis, Vi = Cn.ShadowRoot && (Cn.ShadyCSS === void 0 || Cn.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, Gi = Symbol(), Vl = /* @__PURE__ */ new WeakMap();
let jr = class {
  constructor(e, s, n) {
    if (this._$cssResult$ = !0, n !== Gi) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = e, this.t = s;
  }
  get styleSheet() {
    let e = this.o;
    const s = this.t;
    if (Vi && e === void 0) {
      const n = s !== void 0 && s.length === 1;
      n && (e = Vl.get(s)), e === void 0 && ((this.o = e = new CSSStyleSheet()).replaceSync(this.cssText), n && Vl.set(s, e));
    }
    return e;
  }
  toString() {
    return this.cssText;
  }
};
const qr = (t) => new jr(typeof t == "string" ? t : t + "", void 0, Gi), Yr = (t, ...e) => {
  const s = t.length === 1 ? t[0] : e.reduce((n, i, r) => n + ((a) => {
    if (a._$cssResult$ === !0) return a.cssText;
    if (typeof a == "number") return a;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + a + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(i) + t[r + 1], t[0]);
  return new jr(s, t, Gi);
}, Ra = (t, e) => {
  if (Vi) t.adoptedStyleSheets = e.map((s) => s instanceof CSSStyleSheet ? s : s.styleSheet);
  else for (const s of e) {
    const n = document.createElement("style"), i = Cn.litNonce;
    i !== void 0 && n.setAttribute("nonce", i), n.textContent = s.cssText, t.appendChild(n);
  }
}, Gl = Vi ? (t) => t : (t) => t instanceof CSSStyleSheet ? ((e) => {
  let s = "";
  for (const n of e.cssRules) s += n.cssText;
  return qr(s);
})(t) : t;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: Ma, defineProperty: Ca, getOwnPropertyDescriptor: Pa, getOwnPropertyNames: Na, getOwnPropertySymbols: La, getPrototypeOf: Oa } = Object, Fn = globalThis, Bl = Fn.trustedTypes, Da = Bl ? Bl.emptyScript : "", Ha = Fn.reactiveElementPolyfillSupport, on = (t, e) => t, ki = { toAttribute(t, e) {
  switch (e) {
    case Boolean:
      t = t ? Da : null;
      break;
    case Object:
    case Array:
      t = t == null ? t : JSON.stringify(t);
  }
  return t;
}, fromAttribute(t, e) {
  let s = t;
  switch (e) {
    case Boolean:
      s = t !== null;
      break;
    case Number:
      s = t === null ? null : Number(t);
      break;
    case Object:
    case Array:
      try {
        s = JSON.parse(t);
      } catch {
        s = null;
      }
  }
  return s;
} }, Jr = (t, e) => !Ma(t, e), Kl = { attribute: !0, type: String, converter: ki, reflect: !1, useDefault: !1, hasChanged: Jr };
Symbol.metadata ??= Symbol("metadata"), Fn.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
let Ms = class extends HTMLElement {
  static addInitializer(e) {
    this._$Ei(), (this.l ??= []).push(e);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(e, s = Kl) {
    if (s.state && (s.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(e) && ((s = Object.create(s)).wrapped = !0), this.elementProperties.set(e, s), !s.noAccessor) {
      const n = Symbol(), i = this.getPropertyDescriptor(e, n, s);
      i !== void 0 && Ca(this.prototype, e, i);
    }
  }
  static getPropertyDescriptor(e, s, n) {
    const { get: i, set: r } = Pa(this.prototype, e) ?? { get() {
      return this[s];
    }, set(a) {
      this[s] = a;
    } };
    return { get: i, set(a) {
      const u = i?.call(this);
      r?.call(this, a), this.requestUpdate(e, u, n);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(e) {
    return this.elementProperties.get(e) ?? Kl;
  }
  static _$Ei() {
    if (this.hasOwnProperty(on("elementProperties"))) return;
    const e = Oa(this);
    e.finalize(), e.l !== void 0 && (this.l = [...e.l]), this.elementProperties = new Map(e.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(on("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(on("properties"))) {
      const s = this.properties, n = [...Na(s), ...La(s)];
      for (const i of n) this.createProperty(i, s[i]);
    }
    const e = this[Symbol.metadata];
    if (e !== null) {
      const s = litPropertyMetadata.get(e);
      if (s !== void 0) for (const [n, i] of s) this.elementProperties.set(n, i);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [s, n] of this.elementProperties) {
      const i = this._$Eu(s, n);
      i !== void 0 && this._$Eh.set(i, s);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(e) {
    const s = [];
    if (Array.isArray(e)) {
      const n = new Set(e.flat(1 / 0).reverse());
      for (const i of n) s.unshift(Gl(i));
    } else e !== void 0 && s.push(Gl(e));
    return s;
  }
  static _$Eu(e, s) {
    const n = s.attribute;
    return n === !1 ? void 0 : typeof n == "string" ? n : typeof e == "string" ? e.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise((e) => this.enableUpdating = e), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((e) => e(this));
  }
  addController(e) {
    (this._$EO ??= /* @__PURE__ */ new Set()).add(e), this.renderRoot !== void 0 && this.isConnected && e.hostConnected?.();
  }
  removeController(e) {
    this._$EO?.delete(e);
  }
  _$E_() {
    const e = /* @__PURE__ */ new Map(), s = this.constructor.elementProperties;
    for (const n of s.keys()) this.hasOwnProperty(n) && (e.set(n, this[n]), delete this[n]);
    e.size > 0 && (this._$Ep = e);
  }
  createRenderRoot() {
    const e = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return Ra(e, this.constructor.elementStyles), e;
  }
  connectedCallback() {
    this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$EO?.forEach((e) => e.hostConnected?.());
  }
  enableUpdating(e) {
  }
  disconnectedCallback() {
    this._$EO?.forEach((e) => e.hostDisconnected?.());
  }
  attributeChangedCallback(e, s, n) {
    this._$AK(e, n);
  }
  _$ET(e, s) {
    const n = this.constructor.elementProperties.get(e), i = this.constructor._$Eu(e, n);
    if (i !== void 0 && n.reflect === !0) {
      const r = (n.converter?.toAttribute !== void 0 ? n.converter : ki).toAttribute(s, n.type);
      this._$Em = e, r == null ? this.removeAttribute(i) : this.setAttribute(i, r), this._$Em = null;
    }
  }
  _$AK(e, s) {
    const n = this.constructor, i = n._$Eh.get(e);
    if (i !== void 0 && this._$Em !== i) {
      const r = n.getPropertyOptions(i), a = typeof r.converter == "function" ? { fromAttribute: r.converter } : r.converter?.fromAttribute !== void 0 ? r.converter : ki;
      this._$Em = i;
      const u = a.fromAttribute(s, r.type);
      this[i] = u ?? this._$Ej?.get(i) ?? u, this._$Em = null;
    }
  }
  requestUpdate(e, s, n, i = !1, r) {
    if (e !== void 0) {
      const a = this.constructor;
      if (i === !1 && (r = this[e]), n ??= a.getPropertyOptions(e), !((n.hasChanged ?? Jr)(r, s) || n.useDefault && n.reflect && r === this._$Ej?.get(e) && !this.hasAttribute(a._$Eu(e, n)))) return;
      this.C(e, s, n);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(e, s, { useDefault: n, reflect: i, wrapped: r }, a) {
    n && !(this._$Ej ??= /* @__PURE__ */ new Map()).has(e) && (this._$Ej.set(e, a ?? s ?? this[e]), r !== !0 || a !== void 0) || (this._$AL.has(e) || (this.hasUpdated || n || (s = void 0), this._$AL.set(e, s)), i === !0 && this._$Em !== e && (this._$Eq ??= /* @__PURE__ */ new Set()).add(e));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (s) {
      Promise.reject(s);
    }
    const e = this.scheduleUpdate();
    return e != null && await e, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
        for (const [i, r] of this._$Ep) this[i] = r;
        this._$Ep = void 0;
      }
      const n = this.constructor.elementProperties;
      if (n.size > 0) for (const [i, r] of n) {
        const { wrapped: a } = r, u = this[i];
        a !== !0 || this._$AL.has(i) || u === void 0 || this.C(i, void 0, r, u);
      }
    }
    let e = !1;
    const s = this._$AL;
    try {
      e = this.shouldUpdate(s), e ? (this.willUpdate(s), this._$EO?.forEach((n) => n.hostUpdate?.()), this.update(s)) : this._$EM();
    } catch (n) {
      throw e = !1, this._$EM(), n;
    }
    e && this._$AE(s);
  }
  willUpdate(e) {
  }
  _$AE(e) {
    this._$EO?.forEach((s) => s.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(e)), this.updated(e);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(e) {
    return !0;
  }
  update(e) {
    this._$Eq &&= this._$Eq.forEach((s) => this._$ET(s, this[s])), this._$EM();
  }
  updated(e) {
  }
  firstUpdated(e) {
  }
};
Ms.elementStyles = [], Ms.shadowRootOptions = { mode: "open" }, Ms[on("elementProperties")] = /* @__PURE__ */ new Map(), Ms[on("finalized")] = /* @__PURE__ */ new Map(), Ha?.({ ReactiveElement: Ms }), (Fn.reactiveElementVersions ??= []).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Bi = globalThis, jl = (t) => t, Ln = Bi.trustedTypes, ql = Ln ? Ln.createPolicy("lit-html", { createHTML: (t) => t }) : void 0, Zr = "$lit$", Wt = `lit$${Math.random().toFixed(9).slice(2)}$`, Qr = "?" + Wt, za = `<${Qr}>`, rs = document, un = () => rs.createComment(""), hn = (t) => t === null || typeof t != "object" && typeof t != "function", Ki = Array.isArray, Fa = (t) => Ki(t) || typeof t?.[Symbol.iterator] == "function", bi = `[ 	
\f\r]`, Zs = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Yl = /-->/g, Jl = />/g, es = RegExp(`>|${bi}(?:([^\\s"'>=/]+)(${bi}*=${bi}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Zl = /'/g, Ql = /"/g, Xr = /^(?:script|style|textarea|title)$/i, Ia = (t) => (e, ...s) => ({ _$litType$: t, strings: e, values: s }), I = Ia(1), Ls = Symbol.for("lit-noChange"), B = Symbol.for("lit-nothing"), Xl = /* @__PURE__ */ new WeakMap(), is = rs.createTreeWalker(rs, 129);
function eo(t, e) {
  if (!Ki(t) || !t.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return ql !== void 0 ? ql.createHTML(e) : e;
}
const Ua = (t, e) => {
  const s = t.length - 1, n = [];
  let i, r = e === 2 ? "<svg>" : e === 3 ? "<math>" : "", a = Zs;
  for (let u = 0; u < s; u++) {
    const f = t[u];
    let d, g, p = -1, b = 0;
    for (; b < f.length && (a.lastIndex = b, g = a.exec(f), g !== null); ) b = a.lastIndex, a === Zs ? g[1] === "!--" ? a = Yl : g[1] !== void 0 ? a = Jl : g[2] !== void 0 ? (Xr.test(g[2]) && (i = RegExp("</" + g[2], "g")), a = es) : g[3] !== void 0 && (a = es) : a === es ? g[0] === ">" ? (a = i ?? Zs, p = -1) : g[1] === void 0 ? p = -2 : (p = a.lastIndex - g[2].length, d = g[1], a = g[3] === void 0 ? es : g[3] === '"' ? Ql : Zl) : a === Ql || a === Zl ? a = es : a === Yl || a === Jl ? a = Zs : (a = es, i = void 0);
    const y = a === es && t[u + 1].startsWith("/>") ? " " : "";
    r += a === Zs ? f + za : p >= 0 ? (n.push(d), f.slice(0, p) + Zr + f.slice(p) + Wt + y) : f + Wt + (p === -2 ? u : y);
  }
  return [eo(t, r + (t[s] || "<?>") + (e === 2 ? "</svg>" : e === 3 ? "</math>" : "")), n];
};
class fn {
  constructor({ strings: e, _$litType$: s }, n) {
    let i;
    this.parts = [];
    let r = 0, a = 0;
    const u = e.length - 1, f = this.parts, [d, g] = Ua(e, s);
    if (this.el = fn.createElement(d, n), is.currentNode = this.el.content, s === 2 || s === 3) {
      const p = this.el.content.firstChild;
      p.replaceWith(...p.childNodes);
    }
    for (; (i = is.nextNode()) !== null && f.length < u; ) {
      if (i.nodeType === 1) {
        if (i.hasAttributes()) for (const p of i.getAttributeNames()) if (p.endsWith(Zr)) {
          const b = g[a++], y = i.getAttribute(p).split(Wt), $ = /([.?@])?(.*)/.exec(b);
          f.push({ type: 1, index: r, name: $[2], strings: y, ctor: $[1] === "." ? Va : $[1] === "?" ? Ga : $[1] === "@" ? Ba : In }), i.removeAttribute(p);
        } else p.startsWith(Wt) && (f.push({ type: 6, index: r }), i.removeAttribute(p));
        if (Xr.test(i.tagName)) {
          const p = i.textContent.split(Wt), b = p.length - 1;
          if (b > 0) {
            i.textContent = Ln ? Ln.emptyScript : "";
            for (let y = 0; y < b; y++) i.append(p[y], un()), is.nextNode(), f.push({ type: 2, index: ++r });
            i.append(p[b], un());
          }
        }
      } else if (i.nodeType === 8) if (i.data === Qr) f.push({ type: 2, index: r });
      else {
        let p = -1;
        for (; (p = i.data.indexOf(Wt, p + 1)) !== -1; ) f.push({ type: 7, index: r }), p += Wt.length - 1;
      }
      r++;
    }
  }
  static createElement(e, s) {
    const n = rs.createElement("template");
    return n.innerHTML = e, n;
  }
}
function Os(t, e, s = t, n) {
  if (e === Ls) return e;
  let i = n !== void 0 ? s._$Co?.[n] : s._$Cl;
  const r = hn(e) ? void 0 : e._$litDirective$;
  return i?.constructor !== r && (i?._$AO?.(!1), r === void 0 ? i = void 0 : (i = new r(t), i._$AT(t, s, n)), n !== void 0 ? (s._$Co ??= [])[n] = i : s._$Cl = i), i !== void 0 && (e = Os(t, i._$AS(t, e.values), i, n)), e;
}
class Wa {
  constructor(e, s) {
    this._$AV = [], this._$AN = void 0, this._$AD = e, this._$AM = s;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(e) {
    const { el: { content: s }, parts: n } = this._$AD, i = (e?.creationScope ?? rs).importNode(s, !0);
    is.currentNode = i;
    let r = is.nextNode(), a = 0, u = 0, f = n[0];
    for (; f !== void 0; ) {
      if (a === f.index) {
        let d;
        f.type === 2 ? d = new gn(r, r.nextSibling, this, e) : f.type === 1 ? d = new f.ctor(r, f.name, f.strings, this, e) : f.type === 6 && (d = new Ka(r, this, e)), this._$AV.push(d), f = n[++u];
      }
      a !== f?.index && (r = is.nextNode(), a++);
    }
    return is.currentNode = rs, i;
  }
  p(e) {
    let s = 0;
    for (const n of this._$AV) n !== void 0 && (n.strings !== void 0 ? (n._$AI(e, n, s), s += n.strings.length - 2) : n._$AI(e[s])), s++;
  }
}
class gn {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(e, s, n, i) {
    this.type = 2, this._$AH = B, this._$AN = void 0, this._$AA = e, this._$AB = s, this._$AM = n, this.options = i, this._$Cv = i?.isConnected ?? !0;
  }
  get parentNode() {
    let e = this._$AA.parentNode;
    const s = this._$AM;
    return s !== void 0 && e?.nodeType === 11 && (e = s.parentNode), e;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(e, s = this) {
    e = Os(this, e, s), hn(e) ? e === B || e == null || e === "" ? (this._$AH !== B && this._$AR(), this._$AH = B) : e !== this._$AH && e !== Ls && this._(e) : e._$litType$ !== void 0 ? this.$(e) : e.nodeType !== void 0 ? this.T(e) : Fa(e) ? this.k(e) : this._(e);
  }
  O(e) {
    return this._$AA.parentNode.insertBefore(e, this._$AB);
  }
  T(e) {
    this._$AH !== e && (this._$AR(), this._$AH = this.O(e));
  }
  _(e) {
    this._$AH !== B && hn(this._$AH) ? this._$AA.nextSibling.data = e : this.T(rs.createTextNode(e)), this._$AH = e;
  }
  $(e) {
    const { values: s, _$litType$: n } = e, i = typeof n == "number" ? this._$AC(e) : (n.el === void 0 && (n.el = fn.createElement(eo(n.h, n.h[0]), this.options)), n);
    if (this._$AH?._$AD === i) this._$AH.p(s);
    else {
      const r = new Wa(i, this), a = r.u(this.options);
      r.p(s), this.T(a), this._$AH = r;
    }
  }
  _$AC(e) {
    let s = Xl.get(e.strings);
    return s === void 0 && Xl.set(e.strings, s = new fn(e)), s;
  }
  k(e) {
    Ki(this._$AH) || (this._$AH = [], this._$AR());
    const s = this._$AH;
    let n, i = 0;
    for (const r of e) i === s.length ? s.push(n = new gn(this.O(un()), this.O(un()), this, this.options)) : n = s[i], n._$AI(r), i++;
    i < s.length && (this._$AR(n && n._$AB.nextSibling, i), s.length = i);
  }
  _$AR(e = this._$AA.nextSibling, s) {
    for (this._$AP?.(!1, !0, s); e !== this._$AB; ) {
      const n = jl(e).nextSibling;
      jl(e).remove(), e = n;
    }
  }
  setConnected(e) {
    this._$AM === void 0 && (this._$Cv = e, this._$AP?.(e));
  }
}
class In {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(e, s, n, i, r) {
    this.type = 1, this._$AH = B, this._$AN = void 0, this.element = e, this.name = s, this._$AM = i, this.options = r, n.length > 2 || n[0] !== "" || n[1] !== "" ? (this._$AH = Array(n.length - 1).fill(new String()), this.strings = n) : this._$AH = B;
  }
  _$AI(e, s = this, n, i) {
    const r = this.strings;
    let a = !1;
    if (r === void 0) e = Os(this, e, s, 0), a = !hn(e) || e !== this._$AH && e !== Ls, a && (this._$AH = e);
    else {
      const u = e;
      let f, d;
      for (e = r[0], f = 0; f < r.length - 1; f++) d = Os(this, u[n + f], s, f), d === Ls && (d = this._$AH[f]), a ||= !hn(d) || d !== this._$AH[f], d === B ? e = B : e !== B && (e += (d ?? "") + r[f + 1]), this._$AH[f] = d;
    }
    a && !i && this.j(e);
  }
  j(e) {
    e === B ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, e ?? "");
  }
}
class Va extends In {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(e) {
    this.element[this.name] = e === B ? void 0 : e;
  }
}
class Ga extends In {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(e) {
    this.element.toggleAttribute(this.name, !!e && e !== B);
  }
}
class Ba extends In {
  constructor(e, s, n, i, r) {
    super(e, s, n, i, r), this.type = 5;
  }
  _$AI(e, s = this) {
    if ((e = Os(this, e, s, 0) ?? B) === Ls) return;
    const n = this._$AH, i = e === B && n !== B || e.capture !== n.capture || e.once !== n.once || e.passive !== n.passive, r = e !== B && (n === B || i);
    i && this.element.removeEventListener(this.name, this, n), r && this.element.addEventListener(this.name, this, e), this._$AH = e;
  }
  handleEvent(e) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, e) : this._$AH.handleEvent(e);
  }
}
class Ka {
  constructor(e, s, n) {
    this.element = e, this.type = 6, this._$AN = void 0, this._$AM = s, this.options = n;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(e) {
    Os(this, e);
  }
}
const ja = Bi.litHtmlPolyfillSupport;
ja?.(fn, gn), (Bi.litHtmlVersions ??= []).push("3.3.3");
const qa = (t, e, s) => {
  const n = s?.renderBefore ?? e;
  let i = n._$litPart$;
  if (i === void 0) {
    const r = s?.renderBefore ?? null;
    n._$litPart$ = i = new gn(e.insertBefore(un(), r), r, void 0, s ?? {});
  }
  return i._$AI(t), i;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const ji = globalThis;
class Ps extends Ms {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    const e = super.createRenderRoot();
    return this.renderOptions.renderBefore ??= e.firstChild, e;
  }
  update(e) {
    const s = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(e), this._$Do = qa(s, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return Ls;
  }
}
Ps._$litElement$ = !0, Ps.finalized = !0, ji.litElementHydrateSupport?.({ LitElement: Ps });
const Ya = ji.litElementPolyfillSupport;
Ya?.({ LitElement: Ps });
(ji.litElementVersions ??= []).push("4.2.2");
let to = null;
function Ja(t) {
  to = t;
}
function Za() {
  return to;
}
class Ti extends Ps {
  static properties = {
    api: { attribute: !1 },
    params: { attribute: !1 }
  };
  #e = [];
  constructor() {
    super(), this.api = null, this.params = {};
  }
  connectedCallback() {
    super.connectedCallback(), this.api && this.#s(this.api);
  }
  willUpdate(e) {
    e.has("api") && this.api && this.#e.length === 0 && this.isConnected && this.#s(this.api);
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    for (const e of this.#e) e();
    this.#e = [];
  }
  #s(e) {
    Ja(e), this.#e.push(e.onLocaleChange(() => this.requestUpdate()));
  }
  /** Translation through the HOST dictionary (our `locales` export is merged into it). */
  t(e, s) {
    return this.api ? this.api.i18n.t(e, s) : e;
  }
}
function qi(t, e) {
  customElements.get(t) || customElements.define(t, e);
}
const Qa = {
  patester: {
    tabTitle: "Pressure Advance",
    title: "Pressure Advance",
    common: {
      loading: "Loading…",
      default: "default",
      noPrinter: "No active printer",
      configError: "Cannot read the printer config. Is Klipper ready?",
      copy: "Copy",
      copied: "Copied",
      copyManually: "Copy the text:"
    },
    install: {
      title: "pa_tester is not set up",
      intro: "This tab drives the Klipper module pa_tester, which measures Pressure Advance with a load cell in the nozzle. There is no [pa_tester] section in the printer config.",
      noLoadCell: "No [load_cell] or [load_cell_probe] in the printer config either: the module needs a load cell in the nozzle.",
      recheck: "Check again",
      stepModule: "The module is not in mainline Klipper. It lives in the generic-cartesian branch of the fork:",
      stepNumpy: "It needs NumPy in the Klipper Python environment.",
      stepConfig: "Add the section to printer.cfg (high_flow and purge_length are required; see the module source for the rest):",
      stepExtruder: "In [extruder], max_extrude_cross_section must allow the high flow.",
      stepRestart: "Restart Klipper completely: sudo systemctl restart klipper. The tab picks the module up by itself afterwards."
    },
    help: {
      title: "Help",
      runTitle: "Running a measurement",
      run: "Test only measures and reports. Calibrate also applies the result with SET_PRESSURE_ADVANCE. Empty fields use your [pa_tester] section. Axes must be homed, the extruder hot and the printer not printing. The run takes minutes; you can leave the tab, it keeps running in Klipper and is picked up again when you return.",
      applyTitle: "Apply vs printer.cfg",
      apply: "SET_PRESSURE_ADVANCE works at once but is lost on restart, and SAVE_CONFIG does not store it. Copy the value into the pressure_advance option of your [extruder] section to keep it.",
      chartTitle: "Load cell graph",
      chart: "The trace of the force sensor in the nozzle. It is streamed only while the graph is shown: hide it when you do not need it. Without the raw stream the graph falls back to about 4 samples per second."
    },
    command: {
      label: "Command",
      test: "Test",
      calibrate: "Calibrate",
      testHint: "TEST_PRESSURE_ADVANCE: measures and reports, changes nothing.",
      calibrateHint: "PA_CALIBRATE: measures and applies the result with SET_PRESSURE_ADVANCE."
    },
    method: {
      label: "Method",
      step_response: "Step response",
      search_overshoot: "Search overshoot",
      step_responseHint: "Extrudes at several flows and finds PA from the force response. Result per flow and overall.",
      search_overshootHint: "Searches the PA range for the value without overshoot. Set PA_RANGE to narrow it."
    },
    param: {
      SLOW_FLOW: "Slow flow, mm³/s (above 0)",
      HIGH_FLOW: "High flow, mm³/s: must be greater than slow flow",
      PURGE_LENGTH: "Filament length to purge, mm",
      SEGMENT_TIME: "Duration of one flow segment, s",
      TEST_REPETITIONS: "Repetitions (at least 1)",
      FILTER_WINDOW: "Force filter window, s (above 0, at most 0.04)",
      EXTRUDE_FORCE_SIGN: "Sign of the force while extruding: -1, 0 (auto) or 1",
      PA_RANGE: "min,max of the search: min ≥ 0, max below 2.0, min below max",
      EXTRUDER: "Extruder to test (must be the active one)",
      FORCE_SENSOR: "Load cell to use"
    },
    block: {
      klippy: "Klipper is not ready.",
      running: "A measurement is in progress.",
      printing: "Not available while printing.",
      homing: "Home all axes first.",
      cold: "The extruder is too cold to extrude: heat it up first.",
      noSensor: "No load cell in the printer config.",
      ambiguous: "Several load cells: choose FORCE_SENSOR.",
      invalid: "Invalid values: {fields}"
    },
    run: {
      test: "Run test",
      calibrate: "Calibrate",
      running: "Running…",
      home: "Home all",
      started: "Measuring: the result appears when Klipper finishes the calculation.",
      external: "started elsewhere",
      log: "Console log ({count} lines)",
      applyMeasured: "Apply",
      saveHint: "Applied until restart only. Put the value into [extruder] pressure_advance in printer.cfg to keep it."
    },
    confirm: {
      title: "Calibrate and apply?",
      body: "PA_CALIBRATE changes the pressure advance of the extruder when it finishes. The change is lost on restart unless you save it to printer.cfg.",
      ok: "Calibrate",
      cancel: "Cancel"
    },
    result: {
      title: "Result",
      current: "Current pressure advance of the extruder",
      lastKlipper: "Last result kept by Klipper: {test}, PA {pa}",
      flow: "Flow, mm³/s",
      pa: "Pressure advance",
      overall: "Overall pressure advance",
      tested: "Tested pressure advance",
      overshoot: "overshoot",
      noOvershoot: "no overshoot",
      found: "Found pressure advance",
      corrected: "Corrected for the force filter",
      forceSign: "Detected force sign: {sign}"
    },
    chart: {
      title: "Load cell",
      show: "Show",
      hide: "Hide",
      now: "now",
      min: "min",
      max: "max",
      counts: "counts",
      sec: "s",
      window: "Time window",
      pause: "Pause",
      resume: "Resume",
      clear: "Clear",
      connecting: "Connecting…",
      noData: "Waiting for data…",
      sourceStream: "raw stream",
      sourceStatus: "≈4 Hz",
      sourceStatusHint: "The raw stream is not available: the graph uses the status subscription (about 4 samples per second).",
      filter: "Filter",
      filter_raw: "Raw",
      filter_average: "Average",
      filter_moving: "Moving average",
      filter_median: "Moving median",
      filter_envelope: "Min/max envelope",
      filterMs: "Window",
      ms: "ms",
      showRaw: "Show raw",
      mains: "Mains filter",
      mainsHz: "Mains frequency",
      hz: "Hz",
      mainsLowRate: "Sensor too slow for the mains filter",
      tare: "Without calibration the graph shows counts relative to the tare. Tare the cell (LOAD_CELL_TARE) before a measurement."
    },
    guard: {
      printing: "Pressure advance measurement is not allowed while printing.",
      homing: "Home all axes before the pressure advance measurement.",
      cold: "The extruder is too cold for the pressure advance measurement."
    }
  }
}, Xa = {
  patester: {
    tabTitle: "Pressure Advance",
    title: "Pressure Advance",
    common: {
      loading: "Загрузка…",
      default: "по умолчанию",
      noPrinter: "Нет активного принтера",
      configError: "Не удалось прочитать конфигурацию принтера. Klipper готов?",
      copy: "Копировать",
      copied: "Скопировано",
      copyManually: "Скопируйте текст:"
    },
    install: {
      title: "pa_tester не настроен",
      intro: "Эта вкладка управляет модулем Klipper pa_tester, который измеряет Pressure Advance по датчику усилия в сопле. В конфигурации принтера нет секции [pa_tester].",
      noLoadCell: "Нет и [load_cell] или [load_cell_probe]: модулю нужен датчик усилия в сопле.",
      recheck: "Проверить снова",
      stepModule: "Модуля нет в основной ветке Klipper. Он лежит в ветке generic-cartesian форка:",
      stepNumpy: "Ему нужен NumPy в Python-окружении Klipper.",
      stepConfig: "Добавьте секцию в printer.cfg (high_flow и purge_length обязательны; остальное — в исходниках модуля):",
      stepExtruder: "В [extruder] max_extrude_cross_section должен допускать высокий расход.",
      stepRestart: "Полностью перезапустите Klipper: sudo systemctl restart klipper. После этого вкладка подхватит модуль сама."
    },
    help: {
      title: "Справка",
      runTitle: "Запуск измерения",
      run: "Test только измеряет и показывает результат. Calibrate дополнительно применяет его через SET_PRESSURE_ADVANCE. Пустые поля берутся из секции [pa_tester]. Оси должны быть в исходной позиции, экструдер горячим, принтер не печатает. Измерение идёт минуты; со вкладки можно уйти, оно продолжится в Klipper и подхватится при возвращении.",
      applyTitle: "Применение и printer.cfg",
      apply: "SET_PRESSURE_ADVANCE действует сразу, но пропадает при перезапуске, и SAVE_CONFIG его не сохраняет. Чтобы значение осталось, перенесите его в pressure_advance секции [extruder].",
      chartTitle: "График датчика усилия",
      chart: "Сигнал датчика усилия в сопле. Поток идёт, только пока график показан: скрывайте его, когда он не нужен. Без raw-потока график строится по статусу, около 4 отсчётов в секунду."
    },
    command: {
      label: "Команда",
      test: "Тест",
      calibrate: "Калибровка",
      testHint: "TEST_PRESSURE_ADVANCE: измеряет и показывает результат, ничего не меняет.",
      calibrateHint: "PA_CALIBRATE: измеряет и применяет результат через SET_PRESSURE_ADVANCE."
    },
    method: {
      label: "Метод",
      step_response: "Step response",
      search_overshoot: "Search overshoot",
      step_responseHint: "Экструзия на нескольких расходах, PA находится по отклику усилия. Результат по каждому расходу и общий.",
      search_overshootHint: "Поиск значения PA без перерегулирования в заданном диапазоне. Сузить диапазон можно через PA_RANGE."
    },
    param: {
      SLOW_FLOW: "Медленный расход, мм³/с (больше 0)",
      HIGH_FLOW: "Быстрый расход, мм³/с: должен быть больше медленного",
      PURGE_LENGTH: "Длина прутка для прочистки, мм",
      SEGMENT_TIME: "Длительность сегмента одного расхода, с",
      TEST_REPETITIONS: "Число повторов (не меньше 1)",
      FILTER_WINDOW: "Окно фильтра усилия, с (больше 0, не больше 0.04)",
      EXTRUDE_FORCE_SIGN: "Знак усилия при экструзии: -1, 0 (авто) или 1",
      PA_RANGE: "min,max поиска: min ≥ 0, max меньше 2.0, min меньше max",
      EXTRUDER: "Тестируемый экструдер (должен быть активным)",
      FORCE_SENSOR: "Используемый датчик усилия"
    },
    block: {
      klippy: "Klipper не готов.",
      running: "Измерение уже идёт.",
      printing: "Недоступно во время печати.",
      homing: "Сначала выполните парковку всех осей.",
      cold: "Экструдер слишком холодный для экструзии: сначала прогрейте его.",
      noSensor: "В конфигурации принтера нет датчика усилия.",
      ambiguous: "Несколько датчиков усилия: выберите FORCE_SENSOR.",
      invalid: "Неверные значения: {fields}"
    },
    run: {
      test: "Запустить тест",
      calibrate: "Калибровать",
      running: "Выполняется…",
      home: "Парковка",
      started: "Измерение: результат появится, когда Klipper закончит расчёт.",
      external: "запущено не здесь",
      log: "Лог консоли ({count} строк)",
      applyMeasured: "Применить",
      saveHint: "Действует только до перезапуска. Чтобы сохранить, впишите значение в pressure_advance секции [extruder] в printer.cfg."
    },
    confirm: {
      title: "Откалибровать и применить?",
      body: "По окончании PA_CALIBRATE изменит pressure advance экструдера. Изменение пропадёт при перезапуске, если не сохранить его в printer.cfg.",
      ok: "Калибровать",
      cancel: "Отмена"
    },
    result: {
      title: "Результат",
      current: "Текущий pressure advance экструдера",
      lastKlipper: "Последний результат в Klipper: {test}, PA {pa}",
      flow: "Расход, мм³/с",
      pa: "Pressure advance",
      overall: "Общий pressure advance",
      tested: "Проверенный pressure advance",
      overshoot: "перерегулирование",
      noOvershoot: "без перерегулирования",
      found: "Найденный pressure advance",
      corrected: "С поправкой на фильтр усилия",
      forceSign: "Определённый знак усилия: {sign}"
    },
    chart: {
      title: "Датчик усилия",
      show: "Показать",
      hide: "Скрыть",
      now: "сейчас",
      min: "мин",
      max: "макс",
      counts: "отсчётов",
      sec: "с",
      window: "Окно времени",
      pause: "Пауза",
      resume: "Продолжить",
      clear: "Очистить",
      connecting: "Подключение…",
      noData: "Ожидание данных…",
      sourceStream: "raw-поток",
      sourceStatus: "≈4 Гц",
      sourceStatusHint: "Raw-поток недоступен: график строится по подписке на статус (около 4 отсчётов в секунду).",
      filter: "Фильтр",
      filter_raw: "Сырой",
      filter_average: "Среднее",
      filter_moving: "Скользящее среднее",
      filter_median: "Скользящая медиана",
      filter_envelope: "Огибающая мин/макс",
      filterMs: "Окно",
      ms: "мс",
      showRaw: "Показать сырой",
      mains: "Фильтр сетевой помехи",
      mainsHz: "Частота сети",
      hz: "Гц",
      mainsLowRate: "Датчик слишком медленный для фильтра сети",
      tare: "Без калибровки график показывает отсчёты относительно тары. Перед измерением обнулите датчик (LOAD_CELL_TARE)."
    },
    guard: {
      printing: "Измерение pressure advance недоступно во время печати.",
      homing: "Перед измерением pressure advance выполните парковку всех осей.",
      cold: "Экструдер слишком холодный для измерения pressure advance."
    }
  }
};
class ec extends Ti {
  render() {
    return B;
  }
}
const tc = !0, Ce = "u-", sc = "uplot", nc = Ce + "hz", ic = Ce + "vt", lc = Ce + "title", rc = Ce + "wrap", oc = Ce + "under", ac = Ce + "over", cc = Ce + "axis", ns = Ce + "off", uc = Ce + "select", hc = Ce + "cursor-x", fc = Ce + "cursor-y", pc = Ce + "cursor-pt", dc = Ce + "legend", mc = Ce + "live", gc = Ce + "inline", vc = Ce + "series", bc = Ce + "marker", er = Ce + "label", _c = Ce + "value", nn = "width", ln = "height", Qs = "top", tr = "bottom", Rs = "left", _i = "right", Yi = "#000", sr = Yi + "0", wi = "mousemove", nr = "mousedown", yi = "mouseup", ir = "mouseenter", lr = "mouseleave", rr = "dblclick", wc = "resize", yc = "scroll", or = "change", On = "dppxchange", Ji = "--", Is = typeof window < "u", Ri = Is ? document : null, Ns = Is ? window : null, Sc = Is ? navigator : null;
let oe, kn;
function Mi() {
  let t = devicePixelRatio;
  oe != t && (oe = t, kn && Pi(or, kn, Mi), kn = matchMedia(`(min-resolution: ${oe - 1e-3}dppx) and (max-resolution: ${oe + 1e-3}dppx)`), ls(or, kn, Mi), Ns.dispatchEvent(new CustomEvent(On)));
}
function st(t, e) {
  if (e != null) {
    let s = t.classList;
    !s.contains(e) && s.add(e);
  }
}
function Ci(t, e) {
  let s = t.classList;
  s.contains(e) && s.remove(e);
}
function be(t, e, s) {
  t.style[e] = s + "px";
}
function bt(t, e, s, n) {
  let i = Ri.createElement(t);
  return e != null && st(i, e), s?.insertBefore(i, n), i;
}
function ht(t, e) {
  return bt("div", t, e);
}
const ar = /* @__PURE__ */ new WeakMap();
function Tt(t, e, s, n, i) {
  let r = "translate(" + e + "px," + s + "px)", a = ar.get(t);
  r != a && (t.style.transform = r, ar.set(t, r), e < 0 || s < 0 || e > n || s > i ? st(t, ns) : Ci(t, ns));
}
const cr = /* @__PURE__ */ new WeakMap();
function ur(t, e, s) {
  let n = e + s, i = cr.get(t);
  n != i && (cr.set(t, n), t.style.background = e, t.style.borderColor = s);
}
const hr = /* @__PURE__ */ new WeakMap();
function fr(t, e, s, n) {
  let i = e + "" + s, r = hr.get(t);
  i != r && (hr.set(t, i), t.style.height = s + "px", t.style.width = e + "px", t.style.marginLeft = n ? -e / 2 + "px" : 0, t.style.marginTop = n ? -s / 2 + "px" : 0);
}
const Zi = { passive: !0 }, xc = { ...Zi, capture: !0 };
function ls(t, e, s, n) {
  e.addEventListener(t, s, n ? xc : Zi);
}
function Pi(t, e, s, n) {
  e.removeEventListener(t, s, Zi);
}
Is && Mi();
function _t(t, e, s, n) {
  let i;
  s = s || 0, n = n || e.length - 1;
  let r = n <= 2147483647;
  for (; n - s > 1; )
    i = r ? s + n >> 1 : nt((s + n) / 2), e[i] < t ? s = i : n = i;
  return t - e[s] <= e[n] - t ? s : n;
}
function so(t) {
  return (s, n, i) => {
    let r = -1, a = -1;
    for (let u = n; u <= i; u++)
      if (t(s[u])) {
        r = u;
        break;
      }
    for (let u = i; u >= n; u--)
      if (t(s[u])) {
        a = u;
        break;
      }
    return [r, a];
  };
}
const no = (t) => t != null, io = (t) => t != null && t > 0, Un = so(no), $c = so(io);
function Ec(t, e, s, n = 0, i = !1) {
  let r = i ? $c : Un, a = i ? io : no;
  [e, s] = r(t, e, s);
  let u = t[e], f = t[e];
  if (e > -1)
    if (n == 1)
      u = t[e], f = t[s];
    else if (n == -1)
      u = t[s], f = t[e];
    else
      for (let d = e; d <= s; d++) {
        let g = t[d];
        a(g) && (g < u ? u = g : g > f && (f = g));
      }
  return [u ?? fe, f ?? -fe];
}
function Wn(t, e, s, n) {
  let i = mr(t), r = mr(e);
  t == e && (i == -1 ? (t *= s, e /= s) : (t /= s, e *= s));
  let a = s == 10 ? Nt : lo, u = i == 1 ? nt : ft, f = r == 1 ? ft : nt, d = u(a(Me(t))), g = f(a(Me(e))), p = Ds(s, d), b = Ds(s, g);
  return s == 10 && (d < 0 && (p = pe(p, -d)), g < 0 && (b = pe(b, -g))), n || s == 2 ? (t = p * i, e = b * r) : (t = co(t, p), e = Vn(e, b)), [t, e];
}
function Qi(t, e, s, n) {
  let i = Wn(t, e, s, n);
  return t == 0 && (i[0] = 0), e == 0 && (i[1] = 0), i;
}
const Xi = 0.1, pr = {
  mode: 3,
  pad: Xi
}, an = {
  pad: 0,
  soft: null,
  mode: 0
}, Ac = {
  min: an,
  max: an
};
function Dn(t, e, s, n) {
  return Gn(s) ? dr(t, e, s) : (an.pad = s, an.soft = n ? 0 : null, an.mode = n ? 3 : 0, dr(t, e, Ac));
}
function le(t, e) {
  return t ?? e;
}
function kc(t, e, s) {
  for (e = le(e, 0), s = le(s, t.length - 1); e <= s; ) {
    if (t[e] != null)
      return !0;
    e++;
  }
  return !1;
}
function dr(t, e, s) {
  let n = s.min, i = s.max, r = le(n.pad, 0), a = le(i.pad, 0), u = le(n.hard, -fe), f = le(i.hard, fe), d = le(n.soft, fe), g = le(i.soft, -fe), p = le(n.mode, 0), b = le(i.mode, 0), y = e - t, $ = Nt(y), P = je(Me(t), Me(e)), N = Nt(P), U = Me(N - $);
  (y < 1e-24 || U > 10) && (y = 0, (t == 0 || e == 0) && (y = 1e-24, p == 2 && d != fe && (r = 0), b == 2 && g != -fe && (a = 0)));
  let x = y || P || 1e3, F = Nt(x), E = Ds(10, nt(F)), J = x * (y == 0 ? t == 0 ? 0.1 : 1 : r), C = pe(co(t - J, E / 10), 24), Z = t >= d && (p == 1 || p == 3 && C <= d || p == 2 && C >= d) ? d : fe, j = je(u, C < Z && t >= Z ? Z : wt(Z, C)), ee = x * (y == 0 ? e == 0 ? 0.1 : 1 : a), K = pe(Vn(e + ee, E / 10), 24), A = e <= g && (b == 1 || b == 3 && K >= g || b == 2 && K <= g) ? g : -fe, Y = wt(f, K > A && e <= A ? A : je(A, K));
  return j == Y && j == 0 && (Y = 100), [j, Y];
}
const Tc = new Intl.NumberFormat(Is ? Sc.language : "en-US"), el = (t) => Tc.format(t), it = Math, Pn = it.PI, Me = it.abs, nt = it.floor, Re = it.round, ft = it.ceil, wt = it.min, je = it.max, Ds = it.pow, mr = it.sign, Nt = it.log10, lo = it.log2, Rc = (t, e = 1) => it.sinh(t) * e, Si = (t, e = 1) => it.asinh(t / e), fe = 1 / 0;
function gr(t) {
  return (Nt((t ^ t >> 31) - (t >> 31)) | 0) + 1;
}
function Ni(t, e, s) {
  return wt(je(t, e), s);
}
function ro(t) {
  return typeof t == "function";
}
function te(t) {
  return ro(t) ? t : () => t;
}
const Mc = () => {
}, oo = (t) => t, ao = (t, e) => e, Cc = (t) => null, vr = (t) => !0, br = (t, e) => t == e, Pc = /\.\d*?(?=9{6,}|0{6,})/gm, os = (t) => {
  if (ho(t) || Vt.has(t))
    return t;
  const e = `${t}`, s = e.match(Pc);
  if (s == null)
    return t;
  let n = s[0].length - 1;
  if (e.indexOf("e-") != -1) {
    let [i, r] = e.split("e");
    return +`${os(i)}e${r}`;
  }
  return pe(t, n);
};
function ts(t, e) {
  return os(pe(os(t / e)) * e);
}
function Vn(t, e) {
  return os(ft(os(t / e)) * e);
}
function co(t, e) {
  return os(nt(os(t / e)) * e);
}
function pe(t, e = 0) {
  if (ho(t))
    return t;
  let s = 10 ** e, n = t * s * (1 + Number.EPSILON);
  return Re(n) / s;
}
const Vt = /* @__PURE__ */ new Map();
function uo(t) {
  return (("" + t).split(".")[1] || "").length;
}
function pn(t, e, s, n) {
  let i = [], r = n.map(uo);
  for (let a = e; a < s; a++) {
    let u = Me(a), f = pe(Ds(t, a), u);
    for (let d = 0; d < n.length; d++) {
      let g = t == 10 ? +`${n[d]}e${a}` : n[d] * f, p = (a >= 0 ? 0 : u) + (a >= r[d] ? 0 : r[d]), b = t == 10 ? g : pe(g, p);
      i.push(b), Vt.set(b, p);
    }
  }
  return i;
}
const cn = {}, tl = [], Hs = [null, null], Ut = Array.isArray, ho = Number.isInteger, Nc = (t) => t === void 0;
function _r(t) {
  return typeof t == "string";
}
function Gn(t) {
  let e = !1;
  if (t != null) {
    let s = t.constructor;
    e = s == null || s == Object;
  }
  return e;
}
function Lc(t) {
  return t != null && typeof t == "object";
}
const Oc = Object.getPrototypeOf(Uint8Array), fo = "__proto__";
function zs(t, e = Gn) {
  let s;
  if (Ut(t)) {
    let n = t.find((i) => i != null);
    if (Ut(n) || e(n)) {
      s = Array(t.length);
      for (let i = 0; i < t.length; i++)
        s[i] = zs(t[i], e);
    } else
      s = t.slice();
  } else if (t instanceof Oc)
    s = t.slice();
  else if (e(t)) {
    s = {};
    for (let n in t)
      n != fo && (s[n] = zs(t[n], e));
  } else
    s = t;
  return s;
}
function Ae(t) {
  let e = arguments;
  for (let s = 1; s < e.length; s++) {
    let n = e[s];
    for (let i in n)
      i != fo && (Gn(t[i]) ? Ae(t[i], zs(n[i])) : t[i] = zs(n[i]));
  }
  return t;
}
const Dc = 0, Hc = 1, zc = 2;
function Fc(t, e, s) {
  for (let n = 0, i, r = -1; n < e.length; n++) {
    let a = e[n];
    if (a > r) {
      for (i = a - 1; i >= 0 && t[i] == null; )
        t[i--] = null;
      for (i = a + 1; i < s && t[i] == null; )
        t[r = i++] = null;
    }
  }
}
function Ic(t, e) {
  if (Vc(t)) {
    let a = t[0].slice();
    for (let u = 1; u < t.length; u++)
      a.push(...t[u].slice(1));
    return Gc(a[0]) || (a = Wc(a)), a;
  }
  let s = /* @__PURE__ */ new Set();
  for (let a = 0; a < t.length; a++) {
    let f = t[a][0], d = f.length;
    for (let g = 0; g < d; g++)
      s.add(f[g]);
  }
  let n = [Array.from(s).sort((a, u) => a - u)], i = n[0].length, r = /* @__PURE__ */ new Map();
  for (let a = 0; a < i; a++)
    r.set(n[0][a], a);
  for (let a = 0; a < t.length; a++) {
    let u = t[a], f = u[0];
    for (let d = 1; d < u.length; d++) {
      let g = u[d], p = Array(i).fill(void 0), b = e ? e[a][d] : Hc, y = [];
      for (let $ = 0; $ < g.length; $++) {
        let P = g[$], N = r.get(f[$]);
        P === null ? b != Dc && (p[N] = P, b == zc && y.push(N)) : p[N] = P;
      }
      Fc(p, y, i), n.push(p);
    }
  }
  return n;
}
const Uc = typeof queueMicrotask > "u" ? (t) => Promise.resolve().then(t) : queueMicrotask;
function Wc(t) {
  let e = t[0], s = e.length, n = Array(s);
  for (let r = 0; r < n.length; r++)
    n[r] = r;
  n.sort((r, a) => e[r] - e[a]);
  let i = [];
  for (let r = 0; r < t.length; r++) {
    let a = t[r], u = Array(s);
    for (let f = 0; f < s; f++)
      u[f] = a[n[f]];
    i.push(u);
  }
  return i;
}
function Vc(t) {
  let e = t[0][0], s = e.length;
  for (let n = 1; n < t.length; n++) {
    let i = t[n][0];
    if (i.length != s)
      return !1;
    if (i != e) {
      for (let r = 0; r < s; r++)
        if (i[r] != e[r])
          return !1;
    }
  }
  return !0;
}
function Gc(t, e = 100) {
  const s = t.length;
  if (s <= 1)
    return !0;
  let n = 0, i = s - 1;
  for (; n <= i && t[n] == null; )
    n++;
  for (; i >= n && t[i] == null; )
    i--;
  if (i <= n)
    return !0;
  const r = je(1, nt((i - n + 1) / e));
  for (let a = t[n], u = n + r; u <= i; u += r) {
    const f = t[u];
    if (f != null) {
      if (f <= a)
        return !1;
      a = f;
    }
  }
  return !0;
}
const po = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
], mo = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday"
];
function go(t) {
  return t.slice(0, 3);
}
const Bc = mo.map(go), Kc = po.map(go), jc = {
  MMMM: po,
  MMM: Kc,
  WWWW: mo,
  WWW: Bc
};
function Xs(t) {
  return (t < 10 ? "0" : "") + t;
}
function qc(t) {
  return (t < 10 ? "00" : t < 100 ? "0" : "") + t;
}
const Yc = {
  // 2019
  YYYY: (t) => t.getFullYear(),
  // 19
  YY: (t) => (t.getFullYear() + "").slice(2),
  // July
  MMMM: (t, e) => e.MMMM[t.getMonth()],
  // Jul
  MMM: (t, e) => e.MMM[t.getMonth()],
  // 07
  MM: (t) => Xs(t.getMonth() + 1),
  // 7
  M: (t) => t.getMonth() + 1,
  // 09
  DD: (t) => Xs(t.getDate()),
  // 9
  D: (t) => t.getDate(),
  // Monday
  WWWW: (t, e) => e.WWWW[t.getDay()],
  // Mon
  WWW: (t, e) => e.WWW[t.getDay()],
  // 03
  HH: (t) => Xs(t.getHours()),
  // 3
  H: (t) => t.getHours(),
  // 9 (12hr, unpadded)
  h: (t) => {
    let e = t.getHours();
    return e == 0 ? 12 : e > 12 ? e - 12 : e;
  },
  // AM
  AA: (t) => t.getHours() >= 12 ? "PM" : "AM",
  // am
  aa: (t) => t.getHours() >= 12 ? "pm" : "am",
  // a
  a: (t) => t.getHours() >= 12 ? "p" : "a",
  // 09
  mm: (t) => Xs(t.getMinutes()),
  // 9
  m: (t) => t.getMinutes(),
  // 09
  ss: (t) => Xs(t.getSeconds()),
  // 9
  s: (t) => t.getSeconds(),
  // 374
  fff: (t) => qc(t.getMilliseconds())
};
function sl(t, e) {
  e = e || jc;
  let s = [], n = /\{([a-z]+)\}|[^{]+/gi, i;
  for (; i = n.exec(t); )
    s.push(i[0][0] == "{" ? Yc[i[1]] : i[0]);
  return (r) => {
    let a = "";
    for (let u = 0; u < s.length; u++)
      a += typeof s[u] == "string" ? s[u] : s[u](r, e);
    return a;
  };
}
const Jc = new Intl.DateTimeFormat().resolvedOptions().timeZone;
function Zc(t, e) {
  let s;
  return e == "UTC" || e == "Etc/UTC" ? s = new Date(+t + t.getTimezoneOffset() * 6e4) : e == Jc ? s = t : (s = new Date(t.toLocaleString("en-US", { timeZone: e })), s.setMilliseconds(t.getMilliseconds())), s;
}
const vo = (t) => t % 1 == 0, Hn = [1, 2, 2.5, 5], Qc = pn(10, -32, 0, Hn), bo = pn(10, 0, 32, Hn), Xc = bo.filter(vo), ss = Qc.concat(bo), nl = `
`, _o = "{YYYY}", wr = nl + _o, wo = "{M}/{D}", rn = nl + wo, Tn = rn + "/{YY}", yo = "{aa}", eu = "{h}:{mm}", Cs = eu + yo, yr = nl + Cs, Sr = ":{ss}", ce = null;
function So(t) {
  let e = t * 1e3, s = e * 60, n = s * 60, i = n * 24, r = i * 30, a = i * 365, f = (t == 1 ? pn(10, 0, 3, Hn).filter(vo) : pn(10, -3, 0, Hn)).concat([
    // minute divisors (# of secs)
    e,
    e * 5,
    e * 10,
    e * 15,
    e * 30,
    // hour divisors (# of mins)
    s,
    s * 5,
    s * 10,
    s * 15,
    s * 30,
    // day divisors (# of hrs)
    n,
    n * 2,
    n * 3,
    n * 4,
    n * 6,
    n * 8,
    n * 12,
    // month divisors TODO: need more?
    i,
    i * 2,
    i * 3,
    i * 4,
    i * 5,
    i * 6,
    i * 7,
    i * 8,
    i * 9,
    i * 10,
    i * 15,
    // year divisors (# months, approx)
    r,
    r * 2,
    r * 3,
    r * 4,
    r * 6,
    // century divisors
    a,
    a * 2,
    a * 5,
    a * 10,
    a * 25,
    a * 50,
    a * 100
  ]);
  const d = [
    //   tick incr    default          year                    month   day                   hour    min       sec   mode
    [a, _o, ce, ce, ce, ce, ce, ce, 1],
    [i * 28, "{MMM}", wr, ce, ce, ce, ce, ce, 1],
    [i, wo, wr, ce, ce, ce, ce, ce, 1],
    [n, "{h}" + yo, Tn, ce, rn, ce, ce, ce, 1],
    [s, Cs, Tn, ce, rn, ce, ce, ce, 1],
    [e, Sr, Tn + " " + Cs, ce, rn + " " + Cs, ce, yr, ce, 1],
    [t, Sr + ".{fff}", Tn + " " + Cs, ce, rn + " " + Cs, ce, yr, ce, 1]
  ];
  function g(p) {
    return (b, y, $, P, N, U) => {
      let x = [], F = N >= a, E = N >= r && N < a, J = p($), C = pe(J * t, 3), Z = xi(J.getFullYear(), F ? 0 : J.getMonth(), E || F ? 1 : J.getDate()), j = pe(Z * t, 3);
      if (E || F) {
        let ee = E ? N / r : 0, K = F ? N / a : 0, A = C == j ? C : pe(xi(Z.getFullYear() + K, Z.getMonth() + ee, 1) * t, 3), Y = new Date(Re(A / t)), L = Y.getFullYear(), V = Y.getMonth();
        for (let z = 0; A <= P; z++) {
          let se = xi(L + K * z, V + ee * z, 1), H = se - p(pe(se * t, 3));
          A = pe((+se + H) * t, 3), A <= P && x.push(A);
        }
      } else {
        let ee = N >= i ? i : N, K = nt($) - nt(C), A = j + K + Vn(C - j, ee);
        x.push(A);
        let Y = p(A), L = Y.getHours() + Y.getMinutes() / s + Y.getSeconds() / n, V = N / n, z = b.axes[y]._space, se = U / z;
        for (; A = pe(A + N, t == 1 ? 0 : 3), !(A > P); )
          if (V > 1) {
            let H = nt(pe(L + V, 6)) % 24, ne = p(A).getHours() - H;
            ne > 1 && (ne = -1), A -= ne * n, L = (L + V) % 24;
            let ue = x[x.length - 1];
            pe((A - ue) / N, 3) * se >= 0.7 && x.push(A);
          } else
            x.push(A);
      }
      return x;
    };
  }
  return [
    f,
    d,
    g
  ];
}
const [tu, su, nu] = So(1), [iu, lu, ru] = So(1e-3);
pn(2, -53, 53, [1]);
function xr(t, e) {
  return t.map((s) => s.map(
    (n, i) => i == 0 || i == 8 || n == null ? n : e(i == 1 || s[8] == 0 ? n : s[1] + n)
  ));
}
function $r(t, e) {
  return (s, n, i, r, a) => {
    let u = e.find(($) => a >= $[0]) || e[e.length - 1], f, d, g, p, b, y;
    return n.map(($) => {
      let P = t($), N = P.getFullYear(), U = P.getMonth(), x = P.getDate(), F = P.getHours(), E = P.getMinutes(), J = P.getSeconds(), C = N != f && u[2] || U != d && u[3] || x != g && u[4] || F != p && u[5] || E != b && u[6] || J != y && u[7] || u[1];
      return f = N, d = U, g = x, p = F, b = E, y = J, C(P);
    });
  };
}
function ou(t, e) {
  let s = sl(e);
  return (n, i, r, a, u) => i.map((f) => s(t(f)));
}
function xi(t, e, s) {
  return new Date(t, e, s);
}
function Er(t, e) {
  return e(t);
}
const au = "{YYYY}-{MM}-{DD} {h}:{mm}{aa}";
function Ar(t, e) {
  return (s, n, i, r) => r == null ? Ji : e(t(n));
}
function cu(t, e) {
  let s = t.series[e];
  return s.width ? s.stroke(t, e) : s.points.width ? s.points.stroke(t, e) : null;
}
function uu(t, e) {
  return t.series[e].fill(t, e);
}
const hu = {
  show: !0,
  live: !0,
  isolate: !1,
  mount: Mc,
  markers: {
    show: !0,
    width: 2,
    stroke: cu,
    fill: uu,
    dash: "solid"
  },
  idx: null,
  idxs: null,
  values: []
};
function fu(t, e) {
  let s = t.cursor.points, n = ht(), i = s.size(t, e);
  be(n, nn, i), be(n, ln, i);
  let r = i / -2;
  be(n, "marginLeft", r), be(n, "marginTop", r);
  let a = s.width(t, e, i);
  return a && be(n, "borderWidth", a), n;
}
function pu(t, e) {
  let s = t.series[e].points;
  return s._fill || s._stroke;
}
function du(t, e) {
  let s = t.series[e].points;
  return s._stroke || s._fill;
}
function mu(t, e) {
  return t.series[e].points.size;
}
const $i = [0, 0];
function gu(t, e, s) {
  return $i[0] = e, $i[1] = s, $i;
}
function Rn(t, e, s, n = !0) {
  return (i) => {
    i.button == 0 && (!n || i.target == e) && s(i);
  };
}
function Ei(t, e, s, n = !0) {
  return (i) => {
    (!n || i.target == e) && s(i);
  };
}
const vu = {
  show: !0,
  x: !0,
  y: !0,
  lock: !1,
  move: gu,
  points: {
    one: !1,
    show: fu,
    size: mu,
    width: 0,
    stroke: du,
    fill: pu
  },
  bind: {
    mousedown: Rn,
    mouseup: Rn,
    click: Rn,
    // legend clicks, not .u-over clicks
    dblclick: Rn,
    mousemove: Ei,
    mouseleave: Ei,
    mouseenter: Ei
  },
  drag: {
    setScale: !0,
    x: !0,
    y: !1,
    dist: 0,
    uni: null,
    click: (t, e) => {
      e.stopPropagation(), e.stopImmediatePropagation();
    },
    _x: !1,
    _y: !1
  },
  focus: {
    dist: (t, e, s, n, i) => n - i,
    prox: -1,
    bias: 0
  },
  hover: {
    skip: [void 0],
    prox: null,
    bias: 0
  },
  left: -10,
  top: -10,
  idx: null,
  dataIdx: null,
  idxs: null,
  event: null
}, xo = {
  show: !0,
  stroke: "rgba(0,0,0,0.07)",
  width: 2
  //	dash: [],
}, il = Ae({}, xo, {
  filter: ao
}), $o = Ae({}, il, {
  size: 10
}), Eo = Ae({}, xo, {
  show: !1
}), ll = '12px system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"', Ao = "bold " + ll, ko = 1.5, kr = {
  show: !0,
  scale: "x",
  stroke: Yi,
  space: 50,
  gap: 5,
  alignTo: 1,
  size: 50,
  labelGap: 0,
  labelSize: 30,
  labelFont: Ao,
  side: 2,
  //	class: "x-vals",
  //	incrs: timeIncrs,
  //	values: timeVals,
  //	filter: retArg1,
  grid: il,
  ticks: $o,
  border: Eo,
  font: ll,
  lineGap: ko,
  rotate: 0
}, bu = "Value", _u = "Time", Tr = {
  show: !0,
  scale: "x",
  auto: !1,
  sorted: 1,
  //	label: "Time",
  //	value: v => stamp(new Date(v * 1e3)),
  // internal caches
  min: fe,
  max: -fe,
  idxs: []
};
function wu(t, e, s, n, i) {
  return e.map((r) => r == null ? "" : el(r));
}
function yu(t, e, s, n, i, r, a) {
  let u = [], f = Vt.get(i) || 0;
  s = a ? s : pe(Vn(s, i), f);
  for (let d = s; d <= n; d = pe(d + i, f))
    u.push(Object.is(d, -0) ? 0 : d);
  return u;
}
function Li(t, e, s, n, i, r, a) {
  const u = [], f = t.scales[t.axes[e].scale].log, d = f == 10 ? Nt : lo, g = nt(d(s));
  i = Ds(f, g), f == 10 && (i = ss[_t(i, ss)]);
  let p = s, b = i * f;
  f == 10 && (b = ss[_t(b, ss)]);
  do
    u.push(p), p = p + i, f == 10 && !Vt.has(p) && (p = pe(p, Vt.get(i))), p >= b && (i = p, b = i * f, f == 10 && (b = ss[_t(b, ss)]));
  while (p <= n);
  return u;
}
function Su(t, e, s, n, i, r, a) {
  let f = t.scales[t.axes[e].scale].asinh, d = n > f ? Li(t, e, je(f, s), n, i) : [f], g = n >= 0 && s <= 0 ? [0] : [];
  return (s < -f ? Li(t, e, je(f, -n), -s, i) : [f]).reverse().map((b) => -b).concat(g, d);
}
const To = /./, xu = /[12357]/, $u = /[125]/, Rr = /1/, Oi = (t, e, s, n) => t.map((i, r) => e == 4 && i == 0 || r % n == 0 && s.test(i.toExponential()[i < 0 ? 1 : 0]) ? i : null);
function Eu(t, e, s, n, i) {
  let r = t.axes[s], a = r.scale, u = t.scales[a], f = t.valToPos, d = r._space, g = f(10, a), p = f(9, a) - g >= d ? To : f(7, a) - g >= d ? xu : f(5, a) - g >= d ? $u : Rr;
  if (p == Rr) {
    let b = Me(f(1, a) - g);
    if (b < d)
      return Oi(e.slice().reverse(), u.distr, p, ft(d / b)).reverse();
  }
  return Oi(e, u.distr, p, 1);
}
function Au(t, e, s, n, i) {
  let r = t.axes[s], a = r.scale, u = r._space, f = t.valToPos, d = Me(f(1, a) - f(2, a));
  return d < u ? Oi(e.slice().reverse(), 3, To, ft(u / d)).reverse() : e;
}
function ku(t, e, s, n) {
  return n == null ? Ji : e == null ? "" : el(e);
}
const Mr = {
  show: !0,
  scale: "y",
  stroke: Yi,
  space: 30,
  gap: 5,
  alignTo: 1,
  size: 50,
  labelGap: 0,
  labelSize: 30,
  labelFont: Ao,
  side: 3,
  //	class: "y-vals",
  //	incrs: numIncrs,
  //	values: (vals, space) => vals,
  //	filter: retArg1,
  grid: il,
  ticks: $o,
  border: Eo,
  font: ll,
  lineGap: ko,
  rotate: 0
};
function Tu(t, e) {
  let s = 3 + (t || 1) * 2;
  return pe(s * e, 3);
}
function Ru(t, e) {
  let { scale: s, idxs: n } = t.series[0], i = t._data[0], r = t.valToPos(i[n[0]], s, !0), a = t.valToPos(i[n[1]], s, !0), u = Me(a - r), f = t.series[e], d = u / (f.points.space * oe);
  return n[1] - n[0] <= d;
}
const Cr = {
  scale: null,
  auto: !0,
  sorted: 0,
  // internal caches
  min: fe,
  max: -fe
}, Ro = (t, e, s, n, i) => i, Pr = {
  show: !0,
  auto: !0,
  sorted: 0,
  gaps: Ro,
  alpha: 1,
  facets: [
    Ae({}, Cr, { scale: "x" }),
    Ae({}, Cr, { scale: "y" })
  ]
}, Nr = {
  scale: "y",
  auto: !0,
  sorted: 0,
  show: !0,
  spanGaps: !1,
  gaps: Ro,
  alpha: 1,
  points: {
    show: Ru,
    filter: null
    //  paths:
    //	stroke: "#000",
    //	fill: "#fff",
    //	width: 1,
    //	size: 10,
  },
  //	label: "Value",
  //	value: v => v,
  values: null,
  // internal caches
  min: fe,
  max: -fe,
  idxs: [],
  path: null,
  clip: null
};
function Mu(t, e, s, n, i) {
  return s / 10;
}
const Mo = {
  time: tc,
  auto: !0,
  distr: 1,
  log: 10,
  asinh: 1,
  min: null,
  max: null,
  dir: 1,
  ori: 0
}, Cu = Ae({}, Mo, {
  time: !1,
  ori: 1
}), Lr = {};
function Co(t, e) {
  let s = Lr[t];
  return s || (s = {
    key: t,
    plots: [],
    sub(n) {
      s.plots.push(n);
    },
    unsub(n) {
      s.plots = s.plots.filter((i) => i != n);
    },
    pub(n, i, r, a, u, f, d) {
      for (let g = 0; g < s.plots.length; g++)
        s.plots[g] != i && s.plots[g].pub(n, i, r, a, u, f, d);
    }
  }, t != null && (Lr[t] = s)), s;
}
const Fs = 1, Di = 2;
function as(t, e, s) {
  const n = t.mode, i = t.series[e], r = n == 2 ? t._data[e] : t._data, a = t.scales, u = t.bbox;
  let f = r[0], d = n == 2 ? r[1] : r[e], g = n == 2 ? a[i.facets[0].scale] : a[t.series[0].scale], p = n == 2 ? a[i.facets[1].scale] : a[i.scale], b = u.left, y = u.top, $ = u.width, P = u.height, N = t.valToPosH, U = t.valToPosV;
  return g.ori == 0 ? s(
    i,
    f,
    d,
    g,
    p,
    N,
    U,
    b,
    y,
    $,
    P,
    Kn,
    Us,
    qn,
    No,
    Oo
  ) : s(
    i,
    f,
    d,
    g,
    p,
    U,
    N,
    y,
    b,
    P,
    $,
    jn,
    Ws,
    al,
    Lo,
    Do
  );
}
function rl(t, e) {
  let s = 0, n = 0, i = le(t.bands, tl);
  for (let r = 0; r < i.length; r++) {
    let a = i[r];
    a.series[0] == e ? s = a.dir : a.series[1] == e && (a.dir == 1 ? n |= 1 : n |= 2);
  }
  return [
    s,
    n == 1 ? -1 : (
      // neg only
      n == 2 ? 1 : (
        // pos only
        n == 3 ? 2 : (
          // both
          0
        )
      )
    )
  ];
}
function Pu(t, e, s, n, i) {
  let r = t.mode, a = t.series[e], u = r == 2 ? a.facets[1].scale : a.scale, f = t.scales[u];
  return i == -1 ? f.min : i == 1 ? f.max : f.distr == 3 ? f.dir == 1 ? f.min : f.max : 0;
}
function Lt(t, e, s, n, i, r) {
  return as(t, e, (a, u, f, d, g, p, b, y, $, P, N) => {
    let U = a.pxRound;
    const x = d.dir * (d.ori == 0 ? 1 : -1), F = d.ori == 0 ? Us : Ws;
    let E, J;
    x == 1 ? (E = s, J = n) : (E = n, J = s);
    let C = U(p(u[E], d, P, y)), Z = U(b(f[E], g, N, $)), j = U(p(u[J], d, P, y)), ee = U(b(r == 1 ? g.max : g.min, g, N, $)), K = new Path2D(i);
    return F(K, j, ee), F(K, C, ee), F(K, C, Z), K;
  });
}
function Bn(t, e, s, n, i, r) {
  let a = null;
  if (t.length > 0) {
    a = new Path2D();
    const u = e == 0 ? qn : al;
    let f = s;
    for (let p = 0; p < t.length; p++) {
      let b = t[p];
      if (b[1] > b[0]) {
        let y = b[0] - f;
        y > 0 && u(a, f, n, y, n + r), f = b[1];
      }
    }
    let d = s + i - f, g = 10;
    d > 0 && u(a, f, n - g / 2, d, n + r + g);
  }
  return a;
}
function Nu(t, e, s) {
  let n = t[t.length - 1];
  n && n[0] == e ? n[1] = s : t.push([e, s]);
}
function ol(t, e, s, n, i, r, a) {
  let u = [], f = t.length;
  for (let d = i == 1 ? s : n; d >= s && d <= n; d += i)
    if (e[d] === null) {
      let p = d, b = d;
      if (i == 1)
        for (; ++d <= n && e[d] === null; )
          b = d;
      else
        for (; --d >= s && e[d] === null; )
          b = d;
      let y = r(t[p]), $ = b == p ? y : r(t[b]), P = p - i;
      y = a <= 0 && P >= 0 && P < f ? r(t[P]) : y;
      let U = b + i;
      $ = a >= 0 && U >= 0 && U < f ? r(t[U]) : $, $ >= y && u.push([y, $]);
    }
  return u;
}
function Or(t) {
  return t == 0 ? oo : t == 1 ? Re : (e) => ts(e, t);
}
function Po(t) {
  let e = t == 0 ? Kn : jn, s = t == 0 ? (i, r, a, u, f, d) => {
    i.arcTo(r, a, u, f, d);
  } : (i, r, a, u, f, d) => {
    i.arcTo(a, r, f, u, d);
  }, n = t == 0 ? (i, r, a, u, f) => {
    i.rect(r, a, u, f);
  } : (i, r, a, u, f) => {
    i.rect(a, r, f, u);
  };
  return (i, r, a, u, f, d = 0, g = 0) => {
    d == 0 && g == 0 ? n(i, r, a, u, f) : (d = wt(d, u / 2, f / 2), g = wt(g, u / 2, f / 2), e(i, r + d, a), s(i, r + u, a, r + u, a + f, d), s(i, r + u, a + f, r, a + f, g), s(i, r, a + f, r, a, g), s(i, r, a, r + u, a, d), i.closePath());
  };
}
const Kn = (t, e, s) => {
  t.moveTo(e, s);
}, jn = (t, e, s) => {
  t.moveTo(s, e);
}, Us = (t, e, s) => {
  t.lineTo(e, s);
}, Ws = (t, e, s) => {
  t.lineTo(s, e);
}, qn = Po(0), al = Po(1), No = (t, e, s, n, i, r) => {
  t.arc(e, s, n, i, r);
}, Lo = (t, e, s, n, i, r) => {
  t.arc(s, e, n, i, r);
}, Oo = (t, e, s, n, i, r, a) => {
  t.bezierCurveTo(e, s, n, i, r, a);
}, Do = (t, e, s, n, i, r, a) => {
  t.bezierCurveTo(s, e, i, n, a, r);
};
function Ho(t) {
  return (e, s, n, i, r) => as(e, s, (a, u, f, d, g, p, b, y, $, P, N) => {
    let { pxRound: U, points: x } = a, F, E;
    d.ori == 0 ? (F = Kn, E = No) : (F = jn, E = Lo);
    const J = pe(x.width * oe, 3);
    let C = (x.size - x.width) / 2 * oe, Z = pe(C * 2, 3), j = new Path2D(), ee = new Path2D(), { left: K, top: A, width: Y, height: L } = e.bbox;
    qn(
      ee,
      K - Z,
      A - Z,
      Y + Z * 2,
      L + Z * 2
    );
    const V = (z) => {
      if (f[z] != null) {
        let se = U(p(u[z], d, P, y)), H = U(b(f[z], g, N, $));
        F(j, se + C, H), E(j, se, H, C, 0, Pn * 2);
      }
    };
    if (r)
      r.forEach(V);
    else
      for (let z = n; z <= i; z++)
        V(z);
    return {
      stroke: J > 0 ? j : null,
      fill: j,
      clip: ee,
      flags: Fs | Di
    };
  });
}
function zo(t) {
  return (e, s, n, i, r, a) => {
    n != i && (r != n && a != n && t(e, s, n), r != i && a != i && t(e, s, i), t(e, s, a));
  };
}
const Lu = zo(Us), Ou = zo(Ws);
function Fo(t) {
  const e = le(t?.alignGaps, 0);
  return (s, n, i, r) => as(s, n, (a, u, f, d, g, p, b, y, $, P, N) => {
    [i, r] = Un(f, i, r);
    let U = a.pxRound, x = (L) => U(p(L, d, P, y)), F = (L) => U(b(L, g, N, $)), E, J;
    d.ori == 0 ? (E = Us, J = Lu) : (E = Ws, J = Ou);
    const C = d.dir * (d.ori == 0 ? 1 : -1), Z = { stroke: new Path2D(), fill: null, clip: null, band: null, gaps: null, flags: Fs }, j = Z.stroke;
    let ee = !1;
    if (r - i >= P * 4) {
      let L = (O) => s.posToVal(O, d.key, !0), V = null, z = null, se, H, qe, _e = x(u[C == 1 ? i : r]), ne = x(u[i]), ue = x(u[r]), Q = L(C == 1 ? ne + 1 : ue - 1);
      for (let O = C == 1 ? i : r; O >= i && O <= r; O += C) {
        let ke = u[O], we = (C == 1 ? ke < Q : ke > Q) ? _e : x(ke), ae = f[O];
        we == _e ? ae != null ? (H = ae, V == null ? (E(j, we, F(H)), se = V = z = H) : H < V ? V = H : H > z && (z = H)) : ae === null && (ee = !0) : (V != null && J(j, _e, F(V), F(z), F(se), F(H)), ae != null ? (H = ae, E(j, we, F(H)), V = z = se = H) : (V = z = null, ae === null && (ee = !0)), _e = we, Q = L(_e + C));
      }
      V != null && V != z && qe != _e && J(j, _e, F(V), F(z), F(se), F(H));
    } else
      for (let L = C == 1 ? i : r; L >= i && L <= r; L += C) {
        let V = f[L];
        V === null ? ee = !0 : V != null && E(j, x(u[L]), F(V));
      }
    let [A, Y] = rl(s, n);
    if (a.fill != null || A != 0) {
      let L = Z.fill = new Path2D(j), V = a.fillTo(s, n, a.min, a.max, A), z = F(V), se = x(u[i]), H = x(u[r]);
      C == -1 && ([H, se] = [se, H]), E(L, H, z), E(L, se, z);
    }
    if (!a.spanGaps) {
      let L = [];
      ee && L.push(...ol(u, f, i, r, C, x, e)), Z.gaps = L = a.gaps(s, n, i, r, L), Z.clip = Bn(L, d.ori, y, $, P, N);
    }
    return Y != 0 && (Z.band = Y == 2 ? [
      Lt(s, n, i, r, j, -1),
      Lt(s, n, i, r, j, 1)
    ] : Lt(s, n, i, r, j, Y)), Z;
  });
}
function Du(t) {
  const e = le(t.align, 1), s = le(t.ascDesc, !1), n = le(t.alignGaps, 0), i = le(t.extend, !1);
  return (r, a, u, f) => as(r, a, (d, g, p, b, y, $, P, N, U, x, F) => {
    [u, f] = Un(p, u, f);
    let E = d.pxRound, { left: J, width: C } = r.bbox, Z = (ne) => E($(ne, b, x, N)), j = (ne) => E(P(ne, y, F, U)), ee = b.ori == 0 ? Us : Ws;
    const K = { stroke: new Path2D(), fill: null, clip: null, band: null, gaps: null, flags: Fs }, A = K.stroke, Y = b.dir * (b.ori == 0 ? 1 : -1);
    let L = j(p[Y == 1 ? u : f]), V = Z(g[Y == 1 ? u : f]), z = V, se = V;
    i && e == -1 && (se = J, ee(A, se, L)), ee(A, V, L);
    for (let ne = Y == 1 ? u : f; ne >= u && ne <= f; ne += Y) {
      let ue = p[ne];
      if (ue == null)
        continue;
      let Q = Z(g[ne]), O = j(ue);
      e == 1 ? ee(A, Q, L) : ee(A, z, O), ee(A, Q, O), L = O, z = Q;
    }
    let H = z;
    i && e == 1 && (H = J + C, ee(A, H, L));
    let [qe, _e] = rl(r, a);
    if (d.fill != null || qe != 0) {
      let ne = K.fill = new Path2D(A), ue = d.fillTo(r, a, d.min, d.max, qe), Q = j(ue);
      ee(ne, H, Q), ee(ne, se, Q);
    }
    if (!d.spanGaps) {
      let ne = [];
      ne.push(...ol(g, p, u, f, Y, Z, n));
      let ue = d.width * oe / 2, Q = s || e == 1 ? ue : -ue, O = s || e == -1 ? -ue : ue;
      ne.forEach((ke) => {
        ke[0] += Q, ke[1] += O;
      }), K.gaps = ne = d.gaps(r, a, u, f, ne), K.clip = Bn(ne, b.ori, N, U, x, F);
    }
    return _e != 0 && (K.band = _e == 2 ? [
      Lt(r, a, u, f, A, -1),
      Lt(r, a, u, f, A, 1)
    ] : Lt(r, a, u, f, A, _e)), K;
  });
}
function Dr(t, e, s, n, i, r, a = fe) {
  if (t.length > 1) {
    let u = null;
    for (let f = 0, d = 1 / 0; f < t.length; f++)
      if (e[f] !== void 0) {
        if (u != null) {
          let g = Me(t[f] - t[u]);
          g < d && (d = g, a = Me(s(t[f], n, i, r) - s(t[u], n, i, r)));
        }
        u = f;
      }
  }
  return a;
}
function Hu(t) {
  t = t || cn;
  const e = le(t.size, [0.6, fe, 1]), s = t.align || 0, n = t.gap || 0;
  let i = t.radius;
  i = // [valueRadius, baselineRadius]
  i == null ? [0, 0] : typeof i == "number" ? [i, 0] : i;
  const r = te(i), a = 1 - e[0], u = le(e[1], fe), f = le(e[2], 1), d = le(t.disp, cn), g = le(t.each, (y) => {
  }), { fill: p, stroke: b } = d;
  return (y, $, P, N) => as(y, $, (U, x, F, E, J, C, Z, j, ee, K, A) => {
    let Y = U.pxRound, L = s, V = n * oe, z = u * oe, se = f * oe, H, qe;
    E.ori == 0 ? [H, qe] = r(y, $) : [qe, H] = r(y, $);
    const _e = E.dir * (E.ori == 0 ? 1 : -1);
    let ne = E.ori == 0 ? qn : al, ue = E.ori == 0 ? g : (R, de, Te, ps, Kt, St, jt) => {
      g(R, de, Te, Kt, ps, jt, St);
    }, Q = le(y.bands, tl).find((R) => R.series[0] == $), O = Q != null ? Q.dir : 0, ke = U.fillTo(y, $, U.min, U.max, O), We = Y(Z(ke, J, A, ee)), we, ae, pt, Ze = K, Se = Y(U.width * oe), yt = !1, Mt = null, lt = null, Ot = null, us = null;
    p != null && (Se == 0 || b != null) && (yt = !0, Mt = p.values(y, $, P, N), lt = /* @__PURE__ */ new Map(), new Set(Mt).forEach((R) => {
      R != null && lt.set(R, new Path2D());
    }), Se > 0 && (Ot = b.values(y, $, P, N), us = /* @__PURE__ */ new Map(), new Set(Ot).forEach((R) => {
      R != null && us.set(R, new Path2D());
    })));
    let { x0: hs, size: Vs } = d;
    if (hs != null && Vs != null) {
      L = 1, x = hs.values(y, $, P, N), hs.unit == 2 && (x = x.map((Te) => y.posToVal(j + Te * K, E.key, !0)));
      let R = Vs.values(y, $, P, N);
      Vs.unit == 2 ? ae = R[0] * K : ae = C(R[0], E, K, j) - C(0, E, K, j), Ze = Dr(x, F, C, E, K, j, Ze), pt = Ze - ae + V;
    } else
      Ze = Dr(x, F, C, E, K, j, Ze), pt = Ze * a + V, ae = Ze - pt;
    pt < 1 && (pt = 0), Se >= ae / 2 && (Se = 0), pt < 5 && (Y = oo);
    let vn = pt > 0, Gt = Ze - pt - (vn ? Se : 0);
    ae = Y(Ni(Gt, se, z)), we = (L == 0 ? ae / 2 : L == _e ? 0 : ae) - L * _e * ((L == 0 ? V / 2 : 0) + (vn ? Se / 2 : 0));
    const Ve = { stroke: null, fill: null, clip: null, band: null, gaps: null, flags: 0 }, fs = yt ? null : new Path2D();
    let Ct = null;
    if (Q != null)
      Ct = y.data[Q.series[1]];
    else {
      let { y0: R, y1: de } = d;
      R != null && de != null && (F = de.values(y, $, P, N), Ct = R.values(y, $, P, N));
    }
    let Bt = H * ae, q = qe * ae;
    for (let R = _e == 1 ? P : N; R >= P && R <= N; R += _e) {
      let de = F[R];
      if (de == null)
        continue;
      if (Ct != null) {
        let Ye = Ct[R] ?? 0;
        if (de - Ye == 0)
          continue;
        We = Z(Ye, J, A, ee);
      }
      let Te = E.distr != 2 || d != null ? x[R] : R, ps = C(Te, E, K, j), Kt = Z(le(de, ke), J, A, ee), St = Y(ps - we), jt = Y(je(Kt, We)), Qe = Y(wt(Kt, We)), rt = jt - Qe;
      if (de != null) {
        let Ye = de < 0 ? q : Bt, dt = de < 0 ? Bt : q;
        yt ? (Se > 0 && Ot[R] != null && ne(us.get(Ot[R]), St, Qe + nt(Se / 2), ae, je(0, rt - Se), Ye, dt), Mt[R] != null && ne(lt.get(Mt[R]), St, Qe + nt(Se / 2), ae, je(0, rt - Se), Ye, dt)) : ne(fs, St, Qe + nt(Se / 2), ae, je(0, rt - Se), Ye, dt), ue(
          y,
          $,
          R,
          St - Se / 2,
          Qe,
          ae + Se,
          rt
        );
      }
    }
    return Se > 0 ? Ve.stroke = yt ? us : fs : yt || (Ve._fill = U.width == 0 ? U._fill : U._stroke ?? U._fill, Ve.width = 0), Ve.fill = yt ? lt : fs, Ve;
  });
}
function zu(t, e) {
  const s = le(e?.alignGaps, 0);
  return (n, i, r, a) => as(n, i, (u, f, d, g, p, b, y, $, P, N, U) => {
    [r, a] = Un(d, r, a);
    let x = u.pxRound, F = (H) => x(b(H, g, N, $)), E = (H) => x(y(H, p, U, P)), J, C, Z;
    g.ori == 0 ? (J = Kn, Z = Us, C = Oo) : (J = jn, Z = Ws, C = Do);
    const j = g.dir * (g.ori == 0 ? 1 : -1);
    let ee = F(f[j == 1 ? r : a]), K = ee, A = [], Y = [];
    for (let H = j == 1 ? r : a; H >= r && H <= a; H += j)
      if (d[H] != null) {
        let _e = f[H], ne = F(_e);
        A.push(K = ne), Y.push(E(d[H]));
      }
    const L = { stroke: t(A, Y, J, Z, C, x), fill: null, clip: null, band: null, gaps: null, flags: Fs }, V = L.stroke;
    let [z, se] = rl(n, i);
    if (u.fill != null || z != 0) {
      let H = L.fill = new Path2D(V), qe = u.fillTo(n, i, u.min, u.max, z), _e = E(qe);
      Z(H, K, _e), Z(H, ee, _e);
    }
    if (!u.spanGaps) {
      let H = [];
      H.push(...ol(f, d, r, a, j, F, s)), L.gaps = H = u.gaps(n, i, r, a, H), L.clip = Bn(H, g.ori, $, P, N, U);
    }
    return se != 0 && (L.band = se == 2 ? [
      Lt(n, i, r, a, V, -1),
      Lt(n, i, r, a, V, 1)
    ] : Lt(n, i, r, a, V, se)), L;
  });
}
function Fu(t) {
  return zu(Iu, t);
}
function Iu(t, e, s, n, i, r) {
  const a = t.length;
  if (a < 2)
    return null;
  const u = new Path2D();
  if (s(u, t[0], e[0]), a == 2)
    n(u, t[1], e[1]);
  else {
    let f = Array(a), d = Array(a - 1), g = Array(a - 1), p = Array(a - 1);
    for (let b = 0; b < a - 1; b++)
      g[b] = e[b + 1] - e[b], p[b] = t[b + 1] - t[b], d[b] = g[b] / p[b];
    f[0] = d[0];
    for (let b = 1; b < a - 1; b++)
      d[b] === 0 || d[b - 1] === 0 || d[b - 1] > 0 != d[b] > 0 ? f[b] = 0 : (f[b] = 3 * (p[b - 1] + p[b]) / ((2 * p[b] + p[b - 1]) / d[b - 1] + (p[b] + 2 * p[b - 1]) / d[b]), isFinite(f[b]) || (f[b] = 0));
    f[a - 1] = d[a - 2];
    for (let b = 0; b < a - 1; b++)
      i(
        u,
        t[b] + p[b] / 3,
        e[b] + f[b] * p[b] / 3,
        t[b + 1] - p[b] / 3,
        e[b + 1] - f[b + 1] * p[b] / 3,
        t[b + 1],
        e[b + 1]
      );
  }
  return u;
}
const Hi = /* @__PURE__ */ new Set();
function Hr() {
  for (let t of Hi)
    t.syncRect(!0);
}
Is && (ls(wc, Ns, Hr), ls(yc, Ns, Hr, !0), ls(On, Ns, () => {
  Ue.pxRatio = oe;
}));
const Uu = Fo(), Wu = Ho();
function zr(t, e, s, n) {
  return (n ? [t[0], t[1]].concat(t.slice(2)) : [t[0]].concat(t.slice(1))).map((r, a) => zi(r, a, e, s));
}
function Vu(t, e) {
  return t.map((s, n) => n == 0 ? {} : Ae({}, e, s));
}
function zi(t, e, s, n) {
  return Ae({}, e == 0 ? s : n, t);
}
function Io(t, e, s) {
  return e == null ? Hs : [e, s];
}
const Gu = Io;
function Bu(t, e, s) {
  return e == null ? Hs : Dn(e, s, Xi, !0);
}
function Uo(t, e, s, n) {
  return e == null ? Hs : Wn(e, s, t.scales[n].log, !1);
}
const Ku = Uo;
function Wo(t, e, s, n) {
  return e == null ? Hs : Qi(e, s, t.scales[n].log, !1);
}
const ju = Wo;
function qu(t, e, s, n, i) {
  let r = je(gr(t), gr(e)), a = e - t, u = _t(i / n * a, s);
  do {
    let f = s[u], d = n * f / a;
    if (d >= i && r + (f < 5 ? Vt.get(f) : 0) <= 17)
      return [f, d];
  } while (++u < s.length);
  return [0, 0];
}
function Fr(t) {
  let e, s;
  return t = t.replace(/(\d+)px/, (n, i) => (e = Re((s = +i) * oe)) + "px"), [t, e, s];
}
function Yu(t) {
  t.show && [t.font, t.labelFont].forEach((e) => {
    let s = pe(e[2] * oe, 1);
    e[0] = e[0].replace(/[0-9.]+px/, s + "px"), e[1] = s;
  });
}
function Ue(t, e, s) {
  const n = {
    mode: le(t.mode, 1)
  }, i = n.mode;
  function r(l, o, c, h) {
    let m = o.valToPct(l);
    return h + c * (o.dir == -1 ? 1 - m : m);
  }
  function a(l, o, c, h) {
    let m = o.valToPct(l);
    return h + c * (o.dir == -1 ? m : 1 - m);
  }
  function u(l, o, c, h) {
    return o.ori == 0 ? r(l, o, c, h) : a(l, o, c, h);
  }
  n.valToPosH = r, n.valToPosV = a;
  let f = !1;
  n.status = 0;
  const d = n.root = ht(sc);
  if (t.id != null && (d.id = t.id), st(d, t.class), t.title) {
    let l = ht(lc, d);
    l.textContent = t.title;
  }
  const g = bt("canvas"), p = n.ctx = g.getContext("2d"), b = ht(rc, d);
  ls("click", b, (l) => {
    l.target === $ && (me != $s || ye != Es) && Fe.click(n, l);
  }, !0);
  const y = n.under = ht(oc, b);
  b.appendChild(g);
  const $ = n.over = ht(ac, b);
  t = zs(t);
  const P = +le(t.pxAlign, 1), N = Or(P);
  (t.plugins || []).forEach((l) => {
    l.opts && (t = l.opts(n, t) || t);
  });
  const U = t.ms || 1e-3, x = n.series = i == 1 ? zr(t.series || [], Tr, Nr, !1) : Vu(t.series || [null], Pr), F = n.axes = zr(t.axes || [], kr, Mr, !0), E = n.scales = {}, J = n.bands = t.bands || [];
  J.forEach((l) => {
    l.fill = te(l.fill || null), l.dir = le(l.dir, -1);
  });
  const C = i == 2 ? x[1].facets[0].scale : x[0].scale, Z = {
    axes: da,
    series: ca
  }, j = (t.drawOrder || ["axes", "series"]).map((l) => Z[l]);
  function ee(l) {
    const o = l.distr == 3 ? (c) => Nt(c > 0 ? c : l.clamp(n, c, l.min, l.max, l.key)) : l.distr == 4 ? (c) => Si(c, l.asinh) : l.distr == 100 ? (c) => l.fwd(c) : (c) => c;
    return (c) => {
      let h = o(c), { _min: m, _max: v } = l, _ = v - m;
      return (h - m) / _;
    };
  }
  function K(l) {
    let o = E[l];
    if (o == null) {
      let c = (t.scales || cn)[l] || cn;
      if (c.from != null) {
        K(c.from);
        let h = Ae({}, E[c.from], c, { key: l });
        h.valToPct = ee(h), E[l] = h;
      } else {
        o = E[l] = Ae({}, l == C ? Mo : Cu, c), o.key = l;
        let h = o.time, m = o.range, v = Ut(m);
        if ((l != C || i == 2 && !h) && (v && (m[0] == null || m[1] == null) && (m = {
          min: m[0] == null ? pr : {
            mode: 1,
            hard: m[0],
            soft: m[0]
          },
          max: m[1] == null ? pr : {
            mode: 1,
            hard: m[1],
            soft: m[1]
          }
        }, v = !1), !v && Gn(m))) {
          let _ = m;
          m = (w, S, k) => S == null ? Hs : Dn(S, k, _);
        }
        o.range = te(m || (h ? Gu : l == C ? o.distr == 3 ? Ku : o.distr == 4 ? ju : Io : o.distr == 3 ? Uo : o.distr == 4 ? Wo : Bu)), o.auto = te(v ? !1 : o.auto), o.clamp = te(o.clamp || Mu), o._min = o._max = null, o.valToPct = ee(o);
      }
    }
  }
  K("x"), K("y"), i == 1 && x.forEach((l) => {
    K(l.scale);
  }), F.forEach((l) => {
    K(l.scale);
  });
  for (let l in t.scales)
    K(l);
  const A = E[C], Y = A.distr;
  let L, V;
  A.ori == 0 ? (st(d, nc), L = r, V = a) : (st(d, ic), L = a, V = r);
  const z = {};
  for (let l in E) {
    let o = E[l];
    (o.min != null || o.max != null) && (z[l] = { min: o.min, max: o.max }, o.min = o.max = null);
  }
  const se = t.tzDate || ((l) => new Date(Re(l / U))), H = t.fmtDate || sl, qe = U == 1 ? nu(se) : ru(se), _e = $r(se, xr(U == 1 ? su : lu, H)), ne = Ar(se, Er(au, H)), ue = [], Q = n.legend = Ae({}, hu, t.legend), O = n.cursor = Ae({}, vu, { drag: { y: i == 2 } }, t.cursor), ke = Q.show, We = O.show, we = Q.markers;
  Q.idxs = ue, we.width = te(we.width), we.dash = te(we.dash), we.stroke = te(we.stroke), we.fill = te(we.fill);
  let ae, pt, Ze, Se = [], yt = [], Mt, lt = !1, Ot = {};
  if (Q.live) {
    const l = x[1] ? x[1].values : null;
    lt = l != null, Mt = lt ? l(n, 1, 0) : { _: 0 };
    for (let o in Mt)
      Ot[o] = Ji;
  }
  if (ke)
    if (ae = bt("table", dc, d), Ze = bt("tbody", null, ae), Q.mount(n, ae), lt) {
      pt = bt("thead", null, ae, Ze);
      let l = bt("tr", null, pt);
      bt("th", null, l);
      for (var us in Mt)
        bt("th", er, l).textContent = us;
    } else
      st(ae, gc), Q.live && st(ae, mc);
  const hs = { show: !0 }, Vs = { show: !1 };
  function vn(l, o) {
    if (o == 0 && (lt || !Q.live || i == 2))
      return Hs;
    let c = [], h = bt("tr", vc, Ze, Ze.childNodes[o]);
    st(h, l.class), l.show || st(h, ns);
    let m = bt("th", null, h);
    if (we.show) {
      let w = ht(bc, m);
      if (o > 0) {
        let S = we.width(n, o);
        S && (w.style.border = S + "px " + we.dash(n, o) + " " + we.stroke(n, o)), w.style.background = we.fill(n, o);
      }
    }
    let v = ht(er, m);
    l.label instanceof HTMLElement ? v.appendChild(l.label) : v.textContent = l.label, o > 0 && (we.show || (v.style.color = l.width > 0 ? we.stroke(n, o) : we.fill(n, o)), Ve("click", m, (w) => {
      if (O._lock)
        return;
      Yt(w);
      let S = x.indexOf(l);
      if ((w.ctrlKey || w.metaKey) != Q.isolate) {
        let k = x.some((T, M) => M > 0 && M != S && T.show);
        x.forEach((T, M) => {
          M > 0 && $t(M, k ? M == S ? hs : Vs : hs, !0, Ee.setSeries);
        });
      } else
        $t(S, { show: !l.show }, !0, Ee.setSeries);
    }, !1), ms && Ve(ir, m, (w) => {
      O._lock || (Yt(w), $t(x.indexOf(l), ks, !0, Ee.setSeries));
    }, !1));
    for (var _ in Mt) {
      let w = bt("td", _c, h);
      w.textContent = "--", c.push(w);
    }
    return [h, c];
  }
  const Gt = /* @__PURE__ */ new Map();
  function Ve(l, o, c, h = !0) {
    const m = Gt.get(o) || {}, v = O.bind[l](n, o, c, h);
    v && (ls(l, o, m[l] = v), Gt.set(o, m));
  }
  function fs(l, o, c) {
    const h = Gt.get(o) || {};
    for (let m in h)
      (l == null || m == l) && (Pi(m, o, h[m]), delete h[m]);
    l == null && Gt.delete(o);
  }
  let Ct = 0, Bt = 0, q = 0, R = 0, de = 0, Te = 0, ps = de, Kt = Te, St = q, jt = R, Qe = 0, rt = 0, Ye = 0, dt = 0;
  n.bbox = {};
  let Yn = !1, bn = !1, ds = !1, qt = !1, _n = !1, ot = !1;
  function Jn(l, o, c) {
    (c || l != n.width || o != n.height) && pl(l, o), ws(!1), ds = !0, bn = !0, ys();
  }
  function pl(l, o) {
    n.width = Ct = q = l, n.height = Bt = R = o, de = Te = 0, sa(), na();
    let c = n.bbox;
    Qe = c.left = ts(de * oe, 0.5), rt = c.top = ts(Te * oe, 0.5), Ye = c.width = ts(q * oe, 0.5), dt = c.height = ts(R * oe, 0.5);
  }
  const Xo = 3;
  function ea() {
    let l = !1, o = 0;
    for (; !l; ) {
      o++;
      let c = fa(o), h = pa(o);
      l = o == Xo || c && h, l || (pl(n.width, n.height), bn = !0);
    }
  }
  function ta({ width: l, height: o }) {
    Jn(l, o);
  }
  n.setSize = ta;
  function sa() {
    let l = !1, o = !1, c = !1, h = !1;
    F.forEach((m, v) => {
      if (m.show && m._show) {
        let { side: _, _size: w } = m, S = _ % 2, k = m.label != null ? m.labelSize : 0, T = w + k;
        T > 0 && (S ? (q -= T, _ == 3 ? (de += T, h = !0) : c = !0) : (R -= T, _ == 0 ? (Te += T, l = !0) : o = !0));
      }
    }), Jt[0] = l, Jt[1] = c, Jt[2] = o, Jt[3] = h, q -= Dt[1] + Dt[3], de += Dt[3], R -= Dt[2] + Dt[0], Te += Dt[0];
  }
  function na() {
    let l = de + q, o = Te + R, c = de, h = Te;
    function m(v, _) {
      switch (v) {
        case 1:
          return l += _, l - _;
        case 2:
          return o += _, o - _;
        case 3:
          return c -= _, c + _;
        case 0:
          return h -= _, h + _;
      }
    }
    F.forEach((v, _) => {
      if (v.show && v._show) {
        let w = v.side;
        v._pos = m(w, v._size), v.label != null && (v._lpos = m(w, v.labelSize));
      }
    });
  }
  if (O.dataIdx == null) {
    let l = O.hover, o = l.skip = new Set(l.skip ?? []);
    o.add(void 0);
    let c = l.prox = te(l.prox), h = l.bias ??= 0;
    O.dataIdx = (m, v, _, w) => {
      if (v == 0)
        return _;
      let S = _, k = c(m, v, _, w) ?? fe, T = k >= 0 && k < fe, M = A.ori == 0 ? q : R, G = O.left, re = e[0], ie = e[v];
      if (o.has(ie[_])) {
        S = null;
        let X = null, W = null, D;
        if (h == 0 || h == -1)
          for (D = _; X == null && D-- > 0; )
            o.has(ie[D]) || (X = D);
        if (h == 0 || h == 1)
          for (D = _; W == null && D++ < ie.length; )
            o.has(ie[D]) || (W = D);
        if (X != null || W != null)
          if (T) {
            let ve = X == null ? -1 / 0 : L(re[X], A, M, 0), xe = W == null ? 1 / 0 : L(re[W], A, M, 0), He = G - ve, he = xe - G;
            He <= he ? He <= k && (S = X) : he <= k && (S = W);
          } else
            S = W == null ? X : X == null ? W : _ - X <= W - _ ? X : W;
      } else T && Me(G - L(re[_], A, M, 0)) > k && (S = null);
      return S;
    };
  }
  const Yt = (l) => {
    O.event = l;
  };
  O.idxs = ue, O._lock = !1;
  let Ie = O.points;
  Ie.show = te(Ie.show), Ie.size = te(Ie.size), Ie.stroke = te(Ie.stroke), Ie.width = te(Ie.width), Ie.fill = te(Ie.fill);
  const xt = n.focus = Ae({}, t.focus || { alpha: 0.3 }, O.focus), ms = xt.prox >= 0, gs = ms && Ie.one;
  let at = [], vs = [], bs = [];
  function dl(l, o) {
    let c = Ie.show(n, o);
    if (c instanceof HTMLElement)
      return st(c, pc), st(c, l.class), Tt(c, -10, -10, q, R), $.insertBefore(c, at[o]), c;
  }
  function ml(l, o) {
    if (i == 1 || o > 0) {
      let c = i == 1 && E[l.scale].time, h = l.value;
      l.value = c ? _r(h) ? Ar(se, Er(h, H)) : h || ne : h || ku, l.label = l.label || (c ? _u : bu);
    }
    if (gs || o > 0) {
      l.width = l.width == null ? 1 : l.width, l.paths = l.paths || Uu || Cc, l.fillTo = te(l.fillTo || Pu), l.pxAlign = +le(l.pxAlign, P), l.pxRound = Or(l.pxAlign), l.stroke = te(l.stroke || null), l.fill = te(l.fill || null), l._stroke = l._fill = l._paths = l._focus = null;
      let c = Tu(je(1, l.width), 1), h = l.points = Ae({}, {
        size: c,
        width: je(1, c * 0.2),
        stroke: l.stroke,
        space: c * 2,
        paths: Wu,
        _stroke: null,
        _fill: null
      }, l.points);
      h.show = te(h.show), h.filter = te(h.filter), h.fill = te(h.fill), h.stroke = te(h.stroke), h.paths = te(h.paths), h.pxAlign = l.pxAlign;
    }
    if (ke) {
      let c = vn(l, o);
      Se.splice(o, 0, c[0]), yt.splice(o, 0, c[1]), Q.values.push(null);
    }
    if (We) {
      ue.splice(o, 0, null);
      let c = null;
      gs ? o == 0 && (c = dl(l, o)) : o > 0 && (c = dl(l, o)), at.splice(o, 0, c), vs.splice(o, 0, 0), bs.splice(o, 0, 0);
    }
    De("addSeries", o);
  }
  function ia(l, o) {
    o = o ?? x.length, l = i == 1 ? zi(l, o, Tr, Nr) : zi(l, o, {}, Pr), x.splice(o, 0, l), ml(x[o], o);
  }
  n.addSeries = ia;
  function la(l) {
    if (x.splice(l, 1), ke) {
      Q.values.splice(l, 1), yt.splice(l, 1);
      let o = Se.splice(l, 1)[0];
      fs(null, o.firstChild), o.remove();
    }
    We && (ue.splice(l, 1), at.splice(l, 1)[0].remove(), vs.splice(l, 1), bs.splice(l, 1)), De("delSeries", l);
  }
  n.delSeries = la;
  const Jt = [!1, !1, !1, !1];
  function ra(l, o) {
    if (l._show = l.show, l.show) {
      let c = l.side % 2, h = E[l.scale];
      h == null && (l.scale = c ? x[1].scale : C, h = E[l.scale]);
      let m = h.time;
      l.size = te(l.size), l.space = te(l.space), l.rotate = te(l.rotate), Ut(l.incrs) && l.incrs.forEach((_) => {
        !Vt.has(_) && Vt.set(_, uo(_));
      }), l.incrs = te(l.incrs || (h.distr == 2 ? Xc : m ? U == 1 ? tu : iu : ss)), l.splits = te(l.splits || (m && h.distr == 1 ? qe : h.distr == 3 ? Li : h.distr == 4 ? Su : yu)), l.stroke = te(l.stroke), l.grid.stroke = te(l.grid.stroke), l.ticks.stroke = te(l.ticks.stroke), l.border.stroke = te(l.border.stroke);
      let v = l.values;
      l.values = // static array of tick values
      Ut(v) && !Ut(v[0]) ? te(v) : (
        // temporal
        m ? (
          // config array of fmtDate string tpls
          Ut(v) ? $r(se, xr(v, H)) : (
            // fmtDate string tpl
            _r(v) ? ou(se, v) : v || _e
          )
        ) : v || wu
      ), l.filter = te(l.filter || (h.distr >= 3 && h.log == 10 ? Eu : h.distr == 3 && h.log == 2 ? Au : ao)), l.font = Fr(l.font), l.labelFont = Fr(l.labelFont), l._size = l.size(n, null, o, 0), l._space = l._rotate = l._incrs = l._found = // foundIncrSpace
      l._splits = l._values = null, l._size > 0 && (Jt[o] = !0, l._el = ht(cc, b));
    }
  }
  function Gs(l, o, c, h) {
    let [m, v, _, w] = c, S = o % 2, k = 0;
    return S == 0 && (w || v) && (k = o == 0 && !m || o == 2 && !_ ? Re(kr.size / 3) : 0), S == 1 && (m || _) && (k = o == 1 && !v || o == 3 && !w ? Re(Mr.size / 2) : 0), k;
  }
  const gl = n.padding = (t.padding || [Gs, Gs, Gs, Gs]).map((l) => te(le(l, Gs))), Dt = n._padding = gl.map((l, o) => l(n, o, Jt, 0));
  let ze, Pe = null, Ne = null;
  const wn = i == 1 ? x[0].idxs : null;
  let mt = null, Bs = !1;
  function vl(l, o) {
    if (e = l ?? [], n.data = n._data = e, i == 2) {
      ze = 0;
      for (let c = 1; c < x.length; c++)
        ze += e[c][0].length;
    } else {
      e.length == 0 && (n.data = n._data = e = [[]]), mt = e[0], ze = mt.length;
      let c = e;
      if (Y == 2) {
        c = e.slice();
        let h = c[0] = Array(ze);
        for (let m = 0; m < ze; m++)
          h[m] = m;
      }
      n._data = e = c;
    }
    if (ws(!0), De("setData"), Y == 2 && (ds = !0), o !== !1) {
      let c = A;
      c.auto(n, Bs) ? Zn() : zt(C, c.min, c.max), qt = qt || O.left >= 0, ot = !0, ys();
    }
  }
  n.setData = vl;
  function Zn() {
    Bs = !0;
    let l, o;
    i == 1 && (ze > 0 ? (Pe = wn[0] = 0, Ne = wn[1] = ze - 1, l = e[0][Pe], o = e[0][Ne], Y == 2 ? (l = Pe, o = Ne) : l == o && (Y == 3 ? [l, o] = Wn(l, l, A.log, !1) : Y == 4 ? [l, o] = Qi(l, l, A.log, !1) : A.time ? o = l + Re(86400 / U) : [l, o] = Dn(l, o, Xi, !0))) : (Pe = wn[0] = l = null, Ne = wn[1] = o = null)), zt(C, l, o);
  }
  let yn, _s, Qn, Xn, ei, ti, si, ni, ii, Je;
  function bl(l, o, c, h, m, v) {
    l ??= sr, c ??= tl, h ??= "butt", m ??= sr, v ??= "round", l != yn && (p.strokeStyle = yn = l), m != _s && (p.fillStyle = _s = m), o != Qn && (p.lineWidth = Qn = o), v != ei && (p.lineJoin = ei = v), h != ti && (p.lineCap = ti = h), c != Xn && p.setLineDash(Xn = c);
  }
  function _l(l, o, c, h) {
    o != _s && (p.fillStyle = _s = o), l != si && (p.font = si = l), c != ni && (p.textAlign = ni = c), h != ii && (p.textBaseline = ii = h);
  }
  function li(l, o, c, h, m = 0) {
    if (h.length > 0 && l.auto(n, Bs) && (o == null || o.min == null)) {
      let v = le(Pe, 0), _ = le(Ne, h.length - 1), w = c.min == null ? Ec(h, v, _, m, l.distr == 3) : [c.min, c.max];
      l.min = wt(l.min, c.min = w[0]), l.max = je(l.max, c.max = w[1]);
    }
  }
  const wl = { min: null, max: null };
  function oa() {
    for (let h in E) {
      let m = E[h];
      z[h] == null && // scales that have never been set (on init)
      (m.min == null || // or auto scales when the x scale was explicitly set
      z[C] != null && m.auto(n, Bs)) && (z[h] = wl);
    }
    for (let h in E) {
      let m = E[h];
      z[h] == null && m.from != null && z[m.from] != null && (z[h] = wl);
    }
    z[C] != null && ws(!0);
    let l = {};
    for (let h in z) {
      let m = z[h];
      if (m != null) {
        let v = l[h] = zs(E[h], Lc);
        if (m.min != null)
          Ae(v, m);
        else if (h != C || i == 2)
          if (ze == 0 && v.from == null) {
            let _ = v.range(n, null, null, h);
            v.min = _[0], v.max = _[1];
          } else
            v.min = fe, v.max = -fe;
      }
    }
    if (ze > 0) {
      x.forEach((h, m) => {
        if (i == 1) {
          let v = h.scale, _ = z[v];
          if (_ == null)
            return;
          let w = l[v];
          if (m == 0) {
            let S = w.range(n, w.min, w.max, v);
            w.min = S[0], w.max = S[1], Pe = _t(w.min, e[0]), Ne = _t(w.max, e[0]), Ne - Pe > 1 && (e[0][Pe] < w.min && Pe++, e[0][Ne] > w.max && Ne--), h.min = mt[Pe], h.max = mt[Ne];
          } else h.show && h.auto && li(w, _, h, e[m], h.sorted);
          h.idxs[0] = Pe, h.idxs[1] = Ne;
        } else if (m > 0 && h.show && h.auto) {
          let [v, _] = h.facets, w = v.scale, S = _.scale, [k, T] = e[m], M = l[w], G = l[S];
          M != null && li(M, z[w], v, k, v.sorted), G != null && li(G, z[S], _, T, _.sorted), h.min = _.min, h.max = _.max;
        }
      });
      for (let h in l) {
        let m = l[h], v = z[h];
        if (m.from == null && (v == null || v.min == null)) {
          let _ = m.range(
            n,
            m.min == fe ? null : m.min,
            m.max == -fe ? null : m.max,
            h
          );
          m.min = _[0], m.max = _[1];
        }
      }
    }
    for (let h in l) {
      let m = l[h];
      if (m.from != null) {
        let v = l[m.from];
        if (v.min == null)
          m.min = m.max = null;
        else {
          let _ = m.range(n, v.min, v.max, h);
          m.min = _[0], m.max = _[1];
        }
      }
    }
    let o = {}, c = !1;
    for (let h in l) {
      let m = l[h], v = E[h];
      if (v.min != m.min || v.max != m.max) {
        v.min = m.min, v.max = m.max;
        let _ = v.distr;
        v._min = _ == 3 ? Nt(v.min) : _ == 4 ? Si(v.min, v.asinh) : _ == 100 ? v.fwd(v.min) : v.min, v._max = _ == 3 ? Nt(v.max) : _ == 4 ? Si(v.max, v.asinh) : _ == 100 ? v.fwd(v.max) : v.max, o[h] = c = !0;
      }
    }
    if (c) {
      x.forEach((h, m) => {
        i == 2 ? m > 0 && o.y && (h._paths = null) : o[h.scale] && (h._paths = null);
      });
      for (let h in o)
        ds = !0, De("setScale", h);
      We && O.left >= 0 && (qt = ot = !0);
    }
    for (let h in z)
      z[h] = null;
  }
  function aa(l) {
    let o = Ni(Pe - 1, 0, ze - 1), c = Ni(Ne + 1, 0, ze - 1);
    for (; l[o] == null && o > 0; )
      o--;
    for (; l[c] == null && c < ze - 1; )
      c++;
    return [o, c];
  }
  function ca() {
    if (ze > 0) {
      let l = x.some((o) => o._focus) && Je != xt.alpha;
      l && (p.globalAlpha = Je = xt.alpha), x.forEach((o, c) => {
        if (c > 0 && o.show && (yl(c, !1), yl(c, !0), o._paths == null)) {
          let h = Je;
          Je != o.alpha && (p.globalAlpha = Je = o.alpha);
          let m = i == 2 ? [0, e[c][0].length - 1] : aa(e[c]);
          o._paths = o.paths(n, c, m[0], m[1]), Je != h && (p.globalAlpha = Je = h);
        }
      }), x.forEach((o, c) => {
        if (c > 0 && o.show) {
          let h = Je;
          Je != o.alpha && (p.globalAlpha = Je = o.alpha), o._paths != null && Sl(c, !1);
          {
            let m = o._paths != null ? o._paths.gaps : null, v = o.points.show(n, c, Pe, Ne, m), _ = o.points.filter(n, c, v, m);
            (v || _) && (o.points._paths = o.points.paths(n, c, Pe, Ne, _), Sl(c, !0));
          }
          Je != h && (p.globalAlpha = Je = h), De("drawSeries", c);
        }
      }), l && (p.globalAlpha = Je = 1);
    }
  }
  function yl(l, o) {
    let c = o ? x[l].points : x[l];
    c._stroke = c.stroke(n, l), c._fill = c.fill(n, l);
  }
  function Sl(l, o) {
    let c = o ? x[l].points : x[l], {
      stroke: h,
      fill: m,
      clip: v,
      flags: _,
      _stroke: w = c._stroke,
      _fill: S = c._fill,
      _width: k = c.width
    } = c._paths;
    k = pe(k * oe, 3);
    let T = null, M = k % 2 / 2;
    o && S == null && (S = k > 0 ? "#fff" : w);
    let G = c.pxAlign == 1 && M > 0;
    if (G && p.translate(M, M), !o) {
      let re = Qe - k / 2, ie = rt - k / 2, X = Ye + k, W = dt + k;
      T = new Path2D(), T.rect(re, ie, X, W);
    }
    o ? ri(w, k, c.dash, c.cap, S, h, m, _, v) : ua(l, w, k, c.dash, c.cap, S, h, m, _, T, v), G && p.translate(-M, -M);
  }
  function ua(l, o, c, h, m, v, _, w, S, k, T) {
    let M = !1;
    S != 0 && J.forEach((G, re) => {
      if (G.series[0] == l) {
        let ie = x[G.series[1]], X = e[G.series[1]], W = (ie._paths || cn).band;
        Ut(W) && (W = G.dir == 1 ? W[0] : W[1]);
        let D, ve = null;
        ie.show && W && kc(X, Pe, Ne) ? (ve = G.fill(n, re) || v, D = ie._paths.clip) : W = null, ri(o, c, h, m, ve, _, w, S, k, T, D, W), M = !0;
      }
    }), M || ri(o, c, h, m, v, _, w, S, k, T);
  }
  const xl = Fs | Di;
  function ri(l, o, c, h, m, v, _, w, S, k, T, M) {
    bl(l, o, c, h, m), (S || k || M) && (p.save(), S && p.clip(S), k && p.clip(k)), M ? (w & xl) == xl ? (p.clip(M), T && p.clip(T), xn(m, _), Sn(l, v, o)) : w & Di ? (xn(m, _), p.clip(M), Sn(l, v, o)) : w & Fs && (p.save(), p.clip(M), T && p.clip(T), xn(m, _), p.restore(), Sn(l, v, o)) : (xn(m, _), Sn(l, v, o)), (S || k || M) && p.restore();
  }
  function Sn(l, o, c) {
    c > 0 && (o instanceof Map ? o.forEach((h, m) => {
      p.strokeStyle = yn = m, p.stroke(h);
    }) : o != null && l && p.stroke(o));
  }
  function xn(l, o) {
    o instanceof Map ? o.forEach((c, h) => {
      p.fillStyle = _s = h, p.fill(c);
    }) : o != null && l && p.fill(o);
  }
  function ha(l, o, c, h) {
    let m = F[l], v;
    if (h <= 0)
      v = [0, 0];
    else {
      let _ = m._space = m.space(n, l, o, c, h), w = m._incrs = m.incrs(n, l, o, c, h, _);
      v = qu(o, c, w, h, _);
    }
    return m._found = v;
  }
  function oi(l, o, c, h, m, v, _, w, S, k) {
    let T = _ % 2 / 2;
    P == 1 && p.translate(T, T), bl(w, _, S, k, w), p.beginPath();
    let M, G, re, ie, X = m + (h == 0 || h == 3 ? -v : v);
    c == 0 ? (G = m, ie = X) : (M = m, re = X);
    for (let W = 0; W < l.length; W++)
      o[W] != null && (c == 0 ? M = re = l[W] : G = ie = l[W], p.moveTo(M, G), p.lineTo(re, ie));
    p.stroke(), P == 1 && p.translate(-T, -T);
  }
  function fa(l) {
    let o = !0;
    return F.forEach((c, h) => {
      if (!c.show)
        return;
      let m = E[c.scale];
      if (m.min == null) {
        c._show && (o = !1, c._show = !1, ws(!1));
        return;
      } else
        c._show || (o = !1, c._show = !0, ws(!1));
      let v = c.side, _ = v % 2, { min: w, max: S } = m, [k, T] = ha(h, w, S, _ == 0 ? q : R);
      if (T == 0)
        return;
      let M = m.distr == 2, G = c._splits = c.splits(n, h, w, S, k, T, M), re = m.distr == 2 ? G.map((D) => mt[D]) : G, ie = m.distr == 2 ? mt[G[1]] - mt[G[0]] : k, X = c._values = c.values(n, c.filter(n, re, h, T, ie), h, T, ie);
      c._rotate = v == 2 ? c.rotate(n, X, h, T) : 0;
      let W = c._size;
      c._size = ft(c.size(n, X, h, l)), W != null && c._size != W && (o = !1);
    }), o;
  }
  function pa(l) {
    let o = !0;
    return gl.forEach((c, h) => {
      let m = c(n, h, Jt, l);
      m != Dt[h] && (o = !1), Dt[h] = m;
    }), o;
  }
  function da() {
    for (let l = 0; l < F.length; l++) {
      let o = F[l];
      if (!o.show || !o._show)
        continue;
      let c = o.side, h = c % 2, m, v, _ = o.stroke(n, l), w = c == 0 || c == 3 ? -1 : 1, [S, k] = o._found;
      if (o.label != null) {
        let Be = o.labelGap * w, tt = Re((o._lpos + Be) * oe);
        _l(o.labelFont[0], _, "center", c == 2 ? Qs : tr), p.save(), h == 1 ? (m = v = 0, p.translate(
          tt,
          Re(rt + dt / 2)
        ), p.rotate((c == 3 ? -Pn : Pn) / 2)) : (m = Re(Qe + Ye / 2), v = tt);
        let Xt = ro(o.label) ? o.label(n, l, S, k) : o.label;
        p.fillText(Xt, m, v), p.restore();
      }
      if (k == 0)
        continue;
      let T = E[o.scale], M = h == 0 ? Ye : dt, G = h == 0 ? Qe : rt, re = o._splits, ie = T.distr == 2 ? re.map((Be) => mt[Be]) : re, X = T.distr == 2 ? mt[re[1]] - mt[re[0]] : S, W = o.ticks, D = o.border, ve = W.show ? W.size : 0, xe = Re(ve * oe), He = Re((o.alignTo == 2 ? o._size - ve - o.gap : o.gap) * oe), he = o._rotate * -Pn / 180, $e = N(o._pos * oe), Xe = (xe + He) * w, Ge = $e + Xe;
      v = h == 0 ? Ge : 0, m = h == 1 ? Ge : 0;
      let ct = o.font[0], gt = o.align == 1 ? Rs : o.align == 2 ? _i : he > 0 ? Rs : he < 0 ? _i : h == 0 ? "center" : c == 3 ? _i : Rs, At = he || h == 1 ? "middle" : c == 2 ? Qs : tr;
      _l(ct, _, gt, At);
      let et = o.font[1] * o.lineGap, ut = re.map((Be) => N(u(Be, T, M, G))), vt = o._values;
      for (let Be = 0; Be < vt.length; Be++) {
        let tt = vt[Be];
        if (tt != null) {
          h == 0 ? m = ut[Be] : v = ut[Be], tt = "" + tt;
          let Xt = tt.indexOf(`
`) == -1 ? [tt] : tt.split(/\n/gm);
          for (let Ke = 0; Ke < Xt.length; Ke++) {
            let Wl = Xt[Ke];
            he ? (p.save(), p.translate(m, v + Ke * et), p.rotate(he), p.fillText(Wl, 0, 0), p.restore()) : p.fillText(Wl, m, v + Ke * et);
          }
        }
      }
      W.show && oi(
        ut,
        W.filter(n, ie, l, k, X),
        h,
        c,
        $e,
        xe,
        pe(W.width * oe, 3),
        W.stroke(n, l),
        W.dash,
        W.cap
      );
      let kt = o.grid;
      kt.show && oi(
        ut,
        kt.filter(n, ie, l, k, X),
        h,
        h == 0 ? 2 : 1,
        h == 0 ? rt : Qe,
        h == 0 ? dt : Ye,
        pe(kt.width * oe, 3),
        kt.stroke(n, l),
        kt.dash,
        kt.cap
      ), D.show && oi(
        [$e],
        [1],
        h == 0 ? 1 : 0,
        h == 0 ? 1 : 2,
        h == 1 ? rt : Qe,
        h == 1 ? dt : Ye,
        pe(D.width * oe, 3),
        D.stroke(n, l),
        D.dash,
        D.cap
      );
    }
    De("drawAxes");
  }
  function ws(l) {
    x.forEach((o, c) => {
      c > 0 && (o._paths = null, l && (i == 1 ? (o.min = null, o.max = null) : o.facets.forEach((h) => {
        h.min = null, h.max = null;
      })));
    });
  }
  let $n = !1, ai = !1, Ks = [];
  function ma() {
    ai = !1;
    for (let l = 0; l < Ks.length; l++)
      De(...Ks[l]);
    Ks.length = 0;
  }
  function ys() {
    $n || (Uc($l), $n = !0);
  }
  function ga(l, o = !1) {
    $n = !0, ai = o, l(n), $l(), o && Ks.length > 0 && queueMicrotask(ma);
  }
  n.batch = ga;
  function $l() {
    if (Yn && (oa(), Yn = !1), ds && (ea(), ds = !1), bn) {
      if (be(y, Rs, de), be(y, Qs, Te), be(y, nn, q), be(y, ln, R), be($, Rs, de), be($, Qs, Te), be($, nn, q), be($, ln, R), be(b, nn, Ct), be(b, ln, Bt), g.width = Re(Ct * oe), g.height = Re(Bt * oe), F.forEach(({ _el: l, _show: o, _size: c, _pos: h, side: m }) => {
        if (l != null)
          if (o) {
            let v = m === 3 || m === 0 ? c : 0, _ = m % 2 == 1;
            be(l, _ ? "left" : "top", h - v), be(l, _ ? "width" : "height", c), be(l, _ ? "top" : "left", _ ? Te : de), be(l, _ ? "height" : "width", _ ? R : q), Ci(l, ns);
          } else
            st(l, ns);
      }), yn = _s = Qn = ei = ti = si = ni = ii = Xn = null, Je = 1, Ys(!0), de != ps || Te != Kt || q != St || R != jt) {
        ws(!1);
        let l = q / St, o = R / jt;
        if (We && !qt && O.left >= 0) {
          O.left *= l, O.top *= o, Ss && Tt(Ss, Re(O.left), 0, q, R), xs && Tt(xs, 0, Re(O.top), q, R);
          for (let c = 0; c < at.length; c++) {
            let h = at[c];
            h != null && (vs[c] *= l, bs[c] *= o, Tt(h, ft(vs[c]), ft(bs[c]), q, R));
          }
        }
        if (ge.show && !_n && ge.left >= 0 && ge.width > 0) {
          ge.left *= l, ge.width *= l, ge.top *= o, ge.height *= o;
          for (let c in di)
            be(As, c, ge[c]);
        }
        ps = de, Kt = Te, St = q, jt = R;
      }
      De("setSize"), bn = !1;
    }
    Ct > 0 && Bt > 0 && (p.clearRect(0, 0, g.width, g.height), De("drawClear"), j.forEach((l) => l()), De("draw")), ge.show && _n && (En(ge), _n = !1), We && qt && (Qt(null, !0, !1), qt = !1), Q.show && Q.live && ot && (fi(), ot = !1), f || (f = !0, n.status = 1, De("ready")), Bs = !1, $n = !1;
  }
  n.redraw = (l, o) => {
    ds = o || !1, l !== !1 ? zt(C, A.min, A.max) : ys();
  };
  function ci(l, o) {
    let c = E[l];
    if (c.from == null) {
      if (ze == 0) {
        let h = c.range(n, o.min, o.max, l);
        o.min = h[0], o.max = h[1];
      }
      if (o.min > o.max) {
        let h = o.min;
        o.min = o.max, o.max = h;
      }
      if (ze > 1 && o.min != null && o.max != null && o.max - o.min < 1e-16)
        return;
      l == C && c.distr == 2 && ze > 0 && (o.min = _t(o.min, e[0]), o.max = _t(o.max, e[0]), o.min == o.max && o.max++), z[l] = o, Yn = !0, ys();
    }
  }
  n.setScale = ci;
  let ui, hi, Ss, xs, El, Al, $s, Es, kl, Tl, me, ye, Ht = !1;
  const Fe = O.drag;
  let Le = Fe.x, Oe = Fe.y;
  We && (O.x && (ui = ht(hc, $)), O.y && (hi = ht(fc, $)), A.ori == 0 ? (Ss = ui, xs = hi) : (Ss = hi, xs = ui), me = O.left, ye = O.top);
  const ge = n.select = Ae({
    show: !0,
    over: !0,
    left: 0,
    width: 0,
    top: 0,
    height: 0
  }, t.select), As = ge.show ? ht(uc, ge.over ? $ : y) : null;
  function En(l, o) {
    if (ge.show) {
      for (let c in l)
        ge[c] = l[c], c in di && be(As, c, l[c]);
      o !== !1 && De("setSelect");
    }
  }
  n.setSelect = En;
  function va(l) {
    if (x[l].show)
      ke && Ci(Se[l], ns);
    else if (ke && st(Se[l], ns), We) {
      let c = gs ? at[0] : at[l];
      c != null && Tt(c, -10, -10, q, R);
    }
  }
  function zt(l, o, c) {
    ci(l, { min: o, max: c });
  }
  function $t(l, o, c, h) {
    o.focus != null && Sa(l), o.show != null && x.forEach((m, v) => {
      v > 0 && (l == v || l == null) && (m.show = o.show, va(v), i == 2 ? (zt(m.facets[0].scale, null, null), zt(m.facets[1].scale, null, null)) : zt(m.scale, null, null), ys());
    }), c !== !1 && De("setSeries", l, o), h && Js("setSeries", n, l, o);
  }
  n.setSeries = $t;
  function ba(l, o) {
    Ae(J[l], o);
  }
  function _a(l, o) {
    l.fill = te(l.fill || null), l.dir = le(l.dir, -1), o = o ?? J.length, J.splice(o, 0, l);
  }
  function wa(l) {
    l == null ? J.length = 0 : J.splice(l, 1);
  }
  n.addBand = _a, n.setBand = ba, n.delBand = wa;
  function ya(l, o) {
    x[l].alpha = o, We && at[l] != null && (at[l].style.opacity = o), ke && Se[l] && (Se[l].style.opacity = o);
  }
  let Pt, Ft, Zt;
  const ks = { focus: !0 };
  function Sa(l) {
    if (l != Zt) {
      let o = l == null, c = xt.alpha != 1;
      x.forEach((h, m) => {
        if (i == 1 || m > 0) {
          let v = o || m == 0 || m == l;
          h._focus = o ? null : v, c && ya(m, v ? 1 : xt.alpha);
        }
      }), Zt = l, c && ys();
    }
  }
  ke && ms && Ve(lr, ae, (l) => {
    O._lock || (Yt(l), Zt != null && $t(null, ks, !0, Ee.setSeries));
  });
  function Et(l, o, c) {
    let h = E[o];
    c && (l = l / oe - (h.ori == 1 ? Te : de));
    let m = q;
    h.ori == 1 && (m = R, l = m - l), h.dir == -1 && (l = m - l);
    let v = h._min, _ = h._max, w = l / m, S = v + (_ - v) * w, k = h.distr;
    return k == 3 ? Ds(10, S) : k == 4 ? Rc(S, h.asinh) : k == 100 ? h.bwd(S) : S;
  }
  function xa(l, o) {
    let c = Et(l, C, o);
    return _t(c, e[0], Pe, Ne);
  }
  n.valToIdx = (l) => _t(l, e[0]), n.posToIdx = xa, n.posToVal = Et, n.valToPos = (l, o, c) => E[o].ori == 0 ? r(
    l,
    E[o],
    c ? Ye : q,
    c ? Qe : 0
  ) : a(
    l,
    E[o],
    c ? dt : R,
    c ? rt : 0
  ), n.setCursor = (l, o, c) => {
    me = l.left, ye = l.top, Qt(null, o, c);
  };
  function Rl(l, o) {
    be(As, Rs, ge.left = l), be(As, nn, ge.width = o);
  }
  function Ml(l, o) {
    be(As, Qs, ge.top = l), be(As, ln, ge.height = o);
  }
  let js = A.ori == 0 ? Rl : Ml, qs = A.ori == 1 ? Rl : Ml;
  function $a() {
    if (ke && Q.live)
      for (let l = i == 2 ? 1 : 0; l < x.length; l++) {
        if (l == 0 && lt)
          continue;
        let o = Q.values[l], c = 0;
        for (let h in o)
          yt[l][c++].firstChild.nodeValue = o[h];
      }
  }
  function fi(l, o) {
    if (l != null && (l.idxs ? l.idxs.forEach((c, h) => {
      ue[h] = c;
    }) : Nc(l.idx) || ue.fill(l.idx), Q.idx = ue[0]), ke && Q.live) {
      for (let c = 0; c < x.length; c++)
        (c > 0 || i == 1 && !lt) && Ea(c, ue[c]);
      $a();
    }
    ot = !1, o !== !1 && De("setLegend");
  }
  n.setLegend = fi;
  function Ea(l, o) {
    let c = x[l], h = l == 0 && Y == 2 ? mt : e[l], m;
    lt ? m = c.values(n, l, o) ?? Ot : (m = c.value(n, o == null ? null : h[o], l, o), m = m == null ? Ot : { _: m }), Q.values[l] = m;
  }
  function Qt(l, o, c) {
    kl = me, Tl = ye, [me, ye] = O.move(n, me, ye), O.left = me, O.top = ye, We && (Ss && Tt(Ss, Re(me), 0, q, R), xs && Tt(xs, 0, Re(ye), q, R));
    let h, m = Pe > Ne;
    Pt = fe, Ft = null;
    let v = A.ori == 0 ? q : R, _ = A.ori == 1 ? q : R;
    if (me < 0 || ze == 0 || m) {
      h = O.idx = null;
      for (let w = 0; w < x.length; w++) {
        let S = at[w];
        S != null && Tt(S, -10, -10, q, R);
      }
      ms && $t(null, ks, !0, l == null && Ee.setSeries), Q.live && (ue.fill(h), ot = !0);
    } else {
      let w, S, k;
      i == 1 && (w = A.ori == 0 ? me : ye, S = Et(w, C), h = O.idx = _t(S, e[0], Pe, Ne), k = L(e[0][h], A, v, 0));
      let T = -10, M = -10, G = 0, re = 0, ie = !0, X = "", W = "";
      for (let D = i == 2 ? 1 : 0; D < x.length; D++) {
        let ve = x[D], xe = ue[D], He = xe == null ? null : i == 1 ? e[D][xe] : e[D][1][xe], he = O.dataIdx(n, D, h, S), $e = he == null ? null : i == 1 ? e[D][he] : e[D][1][he];
        if (ot = ot || $e != He || he != xe, ue[D] = he, D > 0 && ve.show) {
          let Xe = he == null ? -10 : he == h ? k : L(i == 1 ? e[0][he] : e[D][0][he], A, v, 0), Ge = $e == null ? -10 : V($e, i == 1 ? E[ve.scale] : E[ve.facets[1].scale], _, 0);
          if (ms && $e != null) {
            let ct = A.ori == 1 ? me : ye, gt = Me(xt.dist(n, D, he, Ge, ct));
            if (gt < Pt) {
              let At = xt.bias;
              if (At != 0) {
                let et = Et(ct, ve.scale), ut = $e >= 0 ? 1 : -1, vt = et >= 0 ? 1 : -1;
                vt == ut && (vt == 1 ? At == 1 ? $e >= et : $e <= et : (
                  // >= 0
                  At == 1 ? $e <= et : $e >= et
                )) && (Pt = gt, Ft = D);
              } else
                Pt = gt, Ft = D;
            }
          }
          if (ot || gs) {
            let ct, gt;
            A.ori == 0 ? (ct = Xe, gt = Ge) : (ct = Ge, gt = Xe);
            let At, et, ut, vt, kt, Be, tt = !0, Xt = Ie.bbox;
            if (Xt != null) {
              tt = !1;
              let Ke = Xt(n, D);
              ut = Ke.left, vt = Ke.top, At = Ke.width, et = Ke.height;
            } else
              ut = ct, vt = gt, At = et = Ie.size(n, D);
            if (Be = Ie.fill(n, D), kt = Ie.stroke(n, D), gs)
              D == Ft && Pt <= xt.prox && (T = ut, M = vt, G = At, re = et, ie = tt, X = Be, W = kt);
            else {
              let Ke = at[D];
              Ke != null && (vs[D] = ut, bs[D] = vt, fr(Ke, At, et, tt), ur(Ke, Be, kt), Tt(Ke, ft(ut), ft(vt), q, R));
            }
          }
        }
      }
      if (gs) {
        let D = xt.prox, ve = Zt == null ? Pt <= D : Pt > D || Ft != Zt;
        if (ot || ve) {
          let xe = at[0];
          xe != null && (vs[0] = T, bs[0] = M, fr(xe, G, re, ie), ur(xe, X, W), Tt(xe, ft(T), ft(M), q, R));
        }
      }
    }
    if (ge.show && Ht)
      if (l != null) {
        let [w, S] = Ee.scales, [k, T] = Ee.match, [M, G] = l.cursor.sync.scales, re = l.cursor.drag;
        if (Le = re._x, Oe = re._y, Le || Oe) {
          let { left: ie, top: X, width: W, height: D } = l.select, ve = l.scales[M].ori, xe = l.posToVal, He, he, $e, Xe, Ge, ct = w != null && k(w, M), gt = S != null && T(S, G);
          ct && Le ? (ve == 0 ? (He = ie, he = W) : (He = X, he = D), $e = E[w], Xe = L(xe(He, M), $e, v, 0), Ge = L(xe(He + he, M), $e, v, 0), js(wt(Xe, Ge), Me(Ge - Xe))) : js(0, v), gt && Oe ? (ve == 1 ? (He = ie, he = W) : (He = X, he = D), $e = E[S], Xe = V(xe(He, G), $e, _, 0), Ge = V(xe(He + he, G), $e, _, 0), qs(wt(Xe, Ge), Me(Ge - Xe))) : qs(0, _);
        } else
          mi();
      } else {
        let w = Me(kl - El), S = Me(Tl - Al);
        if (A.ori == 1) {
          let G = w;
          w = S, S = G;
        }
        Le = Fe.x && w >= Fe.dist, Oe = Fe.y && S >= Fe.dist;
        let k = Fe.uni;
        k != null ? Le && Oe && (Le = w >= k, Oe = S >= k, !Le && !Oe && (S > w ? Oe = !0 : Le = !0)) : Fe.x && Fe.y && (Le || Oe) && (Le = Oe = !0);
        let T, M;
        Le && (A.ori == 0 ? (T = $s, M = me) : (T = Es, M = ye), js(wt(T, M), Me(M - T)), Oe || qs(0, _)), Oe && (A.ori == 1 ? (T = $s, M = me) : (T = Es, M = ye), qs(wt(T, M), Me(M - T)), Le || js(0, v)), !Le && !Oe && (js(0, 0), qs(0, 0));
      }
    if (Fe._x = Le, Fe._y = Oe, l == null) {
      if (c) {
        if (Ul != null) {
          let [w, S] = Ee.scales;
          Ee.values[0] = w != null ? Et(A.ori == 0 ? me : ye, w) : null, Ee.values[1] = S != null ? Et(A.ori == 1 ? me : ye, S) : null;
        }
        Js(wi, n, me, ye, q, R, h);
      }
      if (ms) {
        let w = c && Ee.setSeries, S = xt.prox;
        Zt == null ? Pt <= S && $t(Ft, ks, !0, w) : Pt > S ? $t(null, ks, !0, w) : Ft != Zt && $t(Ft, ks, !0, w);
      }
    }
    ot && (Q.idx = h, fi()), o !== !1 && De("setCursor");
  }
  let It = null;
  Object.defineProperty(n, "rect", {
    get() {
      return It == null && Ys(!1), It;
    }
  });
  function Ys(l = !1) {
    l ? It = null : (It = $.getBoundingClientRect(), De("syncRect", It));
  }
  function Cl(l, o, c, h, m, v, _) {
    O._lock || Ht && l != null && l.movementX == 0 && l.movementY == 0 || (pi(l, o, c, h, m, v, _, !1, l != null), l != null ? Qt(null, !0, !0) : Qt(o, !0, !1));
  }
  function pi(l, o, c, h, m, v, _, w, S) {
    if (It == null && Ys(!1), Yt(l), l != null)
      c = l.clientX - It.left, h = l.clientY - It.top;
    else {
      if (c < 0 || h < 0) {
        me = -10, ye = -10;
        return;
      }
      let [k, T] = Ee.scales, M = o.cursor.sync, [G, re] = M.values, [ie, X] = M.scales, [W, D] = Ee.match, ve = o.axes[0].side % 2 == 1, xe = A.ori == 0 ? q : R, He = A.ori == 1 ? q : R, he = ve ? v : m, $e = ve ? m : v, Xe = ve ? h : c, Ge = ve ? c : h;
      if (ie != null ? c = W(k, ie) ? u(G, E[k], xe, 0) : -10 : c = xe * (Xe / he), X != null ? h = D(T, X) ? u(re, E[T], He, 0) : -10 : h = He * (Ge / $e), A.ori == 1) {
        let ct = c;
        c = h, h = ct;
      }
    }
    S && (o == null || o.cursor.event.type == wi) && ((c <= 1 || c >= q - 1) && (c = ts(c, q)), (h <= 1 || h >= R - 1) && (h = ts(h, R))), w ? (El = c, Al = h, [$s, Es] = O.move(n, c, h)) : (me = c, ye = h);
  }
  const di = {
    width: 0,
    height: 0,
    left: 0,
    top: 0
  };
  function mi() {
    En(di, !1);
  }
  let Pl, Nl, Ll, Ol;
  function Dl(l, o, c, h, m, v, _) {
    Ht = !0, Le = Oe = Fe._x = Fe._y = !1, pi(l, o, c, h, m, v, _, !0, !1), l != null && (Ve(yi, Ri, Hl, !1), Js(nr, n, $s, Es, q, R, null));
    let { left: w, top: S, width: k, height: T } = ge;
    Pl = w, Nl = S, Ll = k, Ol = T;
  }
  function Hl(l, o, c, h, m, v, _) {
    Ht = Fe._x = Fe._y = !1, pi(l, o, c, h, m, v, _, !1, !0);
    let { left: w, top: S, width: k, height: T } = ge, M = k > 0 || T > 0, G = Pl != w || Nl != S || Ll != k || Ol != T;
    if (M && G && En(ge), Fe.setScale && M && G) {
      let re = w, ie = k, X = S, W = T;
      if (A.ori == 1 && (re = S, ie = T, X = w, W = k), Le && zt(
        C,
        Et(re, C),
        Et(re + ie, C)
      ), Oe)
        for (let D in E) {
          let ve = E[D];
          D != C && ve.from == null && ve.min != fe && zt(
            D,
            Et(X + W, D),
            Et(X, D)
          );
        }
      mi();
    } else O.lock && (O._lock = !O._lock, Qt(o, !0, l != null));
    l != null && (fs(yi, Ri), Js(yi, n, me, ye, q, R, null));
  }
  function Aa(l, o, c, h, m, v, _) {
    if (O._lock)
      return;
    Yt(l);
    let w = Ht;
    if (Ht) {
      let S = !0, k = !0, T = 10, M, G;
      A.ori == 0 ? (M = Le, G = Oe) : (M = Oe, G = Le), M && G && (S = me <= T || me >= q - T, k = ye <= T || ye >= R - T), M && S && (me = me < $s ? 0 : q), G && k && (ye = ye < Es ? 0 : R), Qt(null, !0, !0), Ht = !1;
    }
    me = -10, ye = -10, ue.fill(null), Qt(null, !0, !0), w && (Ht = w);
  }
  function zl(l, o, c, h, m, v, _) {
    O._lock || (Yt(l), Zn(), mi(), l != null && Js(rr, n, me, ye, q, R, null));
  }
  function Fl() {
    F.forEach(Yu), Jn(n.width, n.height, !0);
  }
  ls(On, Ns, Fl);
  const Ts = {};
  Ts.mousedown = Dl, Ts.mousemove = Cl, Ts.mouseup = Hl, Ts.dblclick = zl, Ts.setSeries = (l, o, c, h) => {
    let m = Ee.match[2];
    c = m(n, o, c), c != -1 && $t(c, h, !0, !1);
  }, We && (Ve(nr, $, Dl), Ve(wi, $, Cl), Ve(ir, $, (l) => {
    Yt(l), Ys(!1);
  }), Ve(lr, $, Aa), Ve(rr, $, zl), Hi.add(n), n.syncRect = Ys);
  const An = n.hooks = t.hooks || {};
  function De(l, o, c) {
    ai ? Ks.push([l, o, c]) : l in An && An[l].forEach((h) => {
      h.call(null, n, o, c);
    });
  }
  (t.plugins || []).forEach((l) => {
    for (let o in l.hooks)
      An[o] = (An[o] || []).concat(l.hooks[o]);
  });
  const Il = (l, o, c) => c, Ee = Ae({
    key: null,
    setSeries: !1,
    filters: {
      pub: vr,
      sub: vr
    },
    scales: [C, x[1] ? x[1].scale : null],
    match: [br, br, Il],
    values: [null, null]
  }, O.sync);
  Ee.match.length == 2 && Ee.match.push(Il), O.sync = Ee;
  const Ul = Ee.key, gi = Co(Ul);
  function Js(l, o, c, h, m, v, _) {
    Ee.filters.pub(l, o, c, h, m, v, _) && gi.pub(l, o, c, h, m, v, _);
  }
  gi.sub(n);
  function ka(l, o, c, h, m, v, _) {
    Ee.filters.sub(l, o, c, h, m, v, _) && Ts[l](null, o, c, h, m, v, _);
  }
  n.pub = ka;
  function Ta() {
    gi.unsub(n), Hi.delete(n), Gt.clear(), Pi(On, Ns, Fl), d.remove(), ae?.remove(), De("destroy");
  }
  n.destroy = Ta;
  function vi() {
    De("init", t, e), vl(e || t.data, !1), z[C] ? ci(C, z[C]) : Zn(), _n = ge.show && (ge.width > 0 || ge.height > 0), qt = ot = !0, Jn(t.width, t.height);
  }
  return x.forEach(ml), F.forEach(ra), s ? s instanceof HTMLElement ? (s.appendChild(d), vi()) : s(n, vi) : vi(), n;
}
Ue.assign = Ae;
Ue.fmtNum = el;
Ue.rangeNum = Dn;
Ue.rangeLog = Wn;
Ue.rangeAsinh = Qi;
Ue.orient = as;
Ue.pxRatio = oe;
Ue.join = Ic;
Ue.fmtDate = sl, Ue.tzDate = Zc;
Ue.sync = Co;
{
  Ue.addGap = Nu, Ue.clipGaps = Bn;
  let t = Ue.paths = {
    points: Ho
  };
  t.linear = Fo, t.stepped = Du, t.bars = Hu, t.spline = Fu;
}
const Ju = '.uplot,.uplot *,.uplot *:before,.uplot *:after{box-sizing:border-box}.uplot{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";line-height:1.5;width:min-content}.u-title{text-align:center;font-size:18px;font-weight:700}.u-wrap{position:relative;user-select:none}.u-over,.u-under{position:absolute}.u-under{overflow:hidden}.uplot canvas{display:block;position:relative;width:100%;height:100%}.u-axis{position:absolute}.u-legend{font-size:14px;margin:auto;text-align:center}.u-inline{display:block}.u-inline *{display:inline-block}.u-inline tr{margin-right:16px}.u-legend th{font-weight:600}.u-legend th>*{vertical-align:middle;display:inline-block}.u-legend .u-marker{width:1em;height:1em;margin-right:4px;background-clip:padding-box!important}.u-inline.u-live th:after{content:":";vertical-align:middle}.u-inline:not(.u-live) .u-value{display:none}.u-series>*{padding:4px}.u-series th{cursor:pointer}.u-legend .u-off>*{opacity:.3}.u-select{background:#00000012;position:absolute;pointer-events:none}.u-cursor-x,.u-cursor-y{position:absolute;left:0;top:0;pointer-events:none;will-change:transform}.u-hz .u-cursor-x,.u-vt .u-cursor-y{height:100%;border-right:1px dashed #607D8B}.u-hz .u-cursor-y,.u-vt .u-cursor-x{width:100%;border-bottom:1px dashed #607D8B}.u-cursor-pt{position:absolute;top:0;left:0;border-radius:50%;border:0 solid;pointer-events:none;will-change:transform;background-clip:padding-box!important}.u-axis.u-off,.u-select.u-off,.u-cursor-x.u-off,.u-cursor-y.u-off,.u-cursor-pt.u-off{display:none}', Vo = ["raw", "average", "moving", "median", "envelope"], Go = 20, Bo = 2e3, cl = 100;
function Ir(t) {
  return Vo.includes(t) ? t : "raw";
}
function Fi(t) {
  return typeof t != "number" || !Number.isFinite(t) ? cl : Math.min(Bo, Math.max(Go, Math.round(t)));
}
function Ko(t, e, s, n) {
  const i = Math.min(s.length, n.length);
  if (t === "raw" || i === 0) return { xs: s, cols: [n] };
  const r = Fi(e) / 1e3;
  switch (t) {
    case "average":
      return { xs: s, cols: [Ai(s, n, i, r, "mean")] };
    case "envelope":
      return { xs: s, cols: [Ai(s, n, i, r, "min"), Ai(s, n, i, r, "max")] };
    case "moving":
      return { xs: s, cols: [Zu(s, n, i, r)] };
    case "median":
      return { xs: s, cols: [Qu(s, n, i, r)] };
  }
}
function Ai(t, e, s, n, i) {
  const r = new Array(s);
  let a = 0;
  for (; a < s; ) {
    const u = Math.floor(t[a] / n);
    let f = a, d = 0, g = 1 / 0, p = -1 / 0;
    for (; f < s && Math.floor(t[f] / n) === u; ) {
      const y = e[f];
      d += y, y < g && (g = y), y > p && (p = y), f++;
    }
    const b = i === "mean" ? d / (f - a) : i === "min" ? g : p;
    for (let y = a; y < f; y++) r[y] = b;
    a = f;
  }
  return r;
}
function Zu(t, e, s, n) {
  const i = new Array(s);
  let r = 0, a = 0;
  for (let u = 0; u < s; u++) {
    for (a += e[u]; t[u] - t[r] >= n; ) a -= e[r++];
    i[u] = a / (u - r + 1);
  }
  return i;
}
function Qu(t, e, s, n) {
  const i = new Array(s), r = [], a = (f) => {
    let d = 0, g = r.length;
    for (; d < g; ) {
      const p = d + g >> 1;
      r[p] < f ? d = p + 1 : g = p;
    }
    return d;
  };
  let u = 0;
  for (let f = 0; f < s; f++) {
    for (r.splice(a(e[f]), 0, e[f]); t[f] - t[u] >= n; )
      r.splice(a(e[u]), 1), u++;
    const d = r.length >> 1;
    i[f] = r.length % 2 ? r[d] : (r[d - 1] + r[d]) / 2;
  }
  return i;
}
class Xu extends Ps {
  static styles = [
    qr(Ju),
    Yr`
      :host { display: block; position: relative; min-width: 0; }
      .wrap { width: 100%; height: var(--pa-chart-height, 220px); }
      .u-legend { display: none; }
      .readout {
        position: absolute;
        top: 4px;
        inset-inline-end: 8px;
        padding: 1px 6px;
        border-radius: var(--radius-sm, 4px);
        background: var(--bg-surface, #fff);
        border: 1px solid var(--border-color, #ccc);
        color: var(--text-primary);
        font-size: var(--font-size-sm, 12px);
        font-variant-numeric: tabular-nums;
        pointer-events: none;
      }
      .empty {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--text-muted);
        font-size: var(--font-size-sm, 12px);
        pointer-events: none;
        text-align: center;
        padding: var(--space-md, 12px);
      }
    `
  ];
  static properties = {
    buffer: { attribute: !1 },
    version: { type: Number },
    unit: { type: String },
    seconds: { type: Number },
    emptyText: { type: String },
    paused: { type: Boolean },
    filter: { type: String },
    filterMs: { type: Number },
    showRaw: { type: Boolean },
    readout: { state: !0 }
  };
  #e = null;
  #s = 0;
  #t = null;
  /** Last data given to uPlot (the cursor readout looks values up in it). */
  #i = [[], []];
  /** Snapshot shown while paused, so a filter change does not pull in newer samples. */
  #r = null;
  /** Series layout of the current plot: the raw trace is drawn only under a filter. */
  #n = !1;
  constructor() {
    super(), this.buffer = null, this.version = 0, this.unit = "g", this.seconds = 30, this.emptyText = "", this.paused = !1, this.filter = "raw", this.filterMs = cl, this.showRaw = !1, this.readout = "";
  }
  connectedCallback() {
    super.connectedCallback(), this.#t = new ResizeObserver(() => this.#c()), this.#t.observe(this);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.#t?.disconnect(), this.#t = null, this.#s && cancelAnimationFrame(this.#s), this.#s = 0, this.#a();
  }
  /** Rebuilds the chart with the current theme colours. */
  restyle() {
    this.#a(), this.#o(!0);
  }
  updated(e) {
    if (e.has("paused")) {
      const s = this.buffer;
      this.#r = this.paused && s ? { t: s.times(), v: s.values() } : null;
    }
    e.has("seconds") || e.has("unit") || e.has("filter") || e.has("showRaw") ? this.restyle() : e.has("filterMs") ? this.#o(!0) : (e.has("version") || e.has("paused")) && this.#o();
  }
  /** `force`: redraw even while paused (a filter change must show on the frozen trace). */
  #o(e = !1) {
    this.#s || this.paused && !e || (this.#s = requestAnimationFrame(() => {
      this.#s = 0, this.#h();
    }));
  }
  #l(e, s) {
    return getComputedStyle(this).getPropertyValue(e).trim() || s;
  }
  #a() {
    this.#e?.destroy(), this.#e = null;
  }
  #c() {
    const e = this.renderRoot.querySelector(".wrap");
    !e || e.clientWidth === 0 || (this.#e ? this.#e.setSize({ width: e.clientWidth, height: e.clientHeight }) : this.#o());
  }
  /** uPlot series for the current filter: [x, raw?, filtered | lower + upper]. */
  #u(e) {
    const s = [{}];
    return this.#n && s.push({ stroke: this.#l("--text-muted", "#888"), width: 1, points: { show: !1 } }), this.filter === "envelope" ? (s.push({ stroke: this.#l("--cool", "#40c4ff"), width: 1.5, points: { show: !1 } }), s.push({ stroke: this.#l("--heat", "#ff6d00"), width: 1.5, points: { show: !1 } })) : s.push({ stroke: e, width: 1.5, points: { show: !1 } }), s;
  }
  #f(e) {
    const s = this.#l("--accent", "#3b82f6"), n = this.#l("--text-muted", "#888"), i = this.#l("--border-color", "#8884"), r = this.unit === "g" ? "g" : "counts", a = this.unit === "g" ? 2 : 25, u = {
      width: Math.max(e.clientWidth, 200),
      height: Math.max(e.clientHeight, 120),
      legend: { show: !1 },
      cursor: { drag: { x: !1, y: !1 }, points: { size: 6 } },
      scales: {
        x: { time: !1, range: () => [-this.seconds, 0] },
        y: {
          range: (f, d, g) => {
            if (!Number.isFinite(d) || !Number.isFinite(g)) return [-1, 1];
            const p = Math.max(g - d, a), b = (g + d) / 2;
            return [b - p * 0.6, b + p * 0.6];
          }
        }
      },
      axes: [
        {
          stroke: n,
          grid: { stroke: i, width: 1 },
          ticks: { stroke: i },
          values: (f, d) => d.map((g) => `${g}s`)
        },
        {
          stroke: n,
          grid: { stroke: i, width: 1 },
          ticks: { stroke: i },
          size: 56,
          label: r,
          labelSize: 14
        }
      ],
      series: this.#u(s),
      hooks: {
        setCursor: [
          (f) => {
            const d = f.cursor.idx;
            if (d == null) {
              this.readout = "";
              return;
            }
            const g = this.unit === "g" ? 2 : 0, p = this.#n ? 2 : 1, y = this.#i.slice(p).map(($) => $[d]);
            this.readout = y.some(($) => $ === void 0) ? "" : `${y.map(($) => $.toFixed(g)).join(" … ")} ${r}`;
          }
        ]
      }
    };
    return new Ue(u, this.#i, e);
  }
  #h() {
    const e = this.renderRoot.querySelector(".wrap"), s = this.buffer;
    if (!e || !s) return;
    const n = this.#r?.t ?? s.times(), i = this.#r?.v ?? s.values(), r = n[n.length - 1] ?? 0, a = n.map((f) => f - r);
    this.#n = this.showRaw && this.filter !== "raw";
    const u = Ko(this.filter, this.filterMs, n, i).cols;
    if (this.#i = [a, ...this.#n ? [i] : [], ...u], !this.#e) {
      if (e.clientWidth === 0) return;
      this.#e = this.#f(e);
      return;
    }
    this.#e.setData(this.#i);
  }
  render() {
    const e = !this.buffer || this.buffer.length === 0;
    return I`
      <div class="wrap"></div>
      ${this.readout ? I`<span class="readout">${this.readout}</span>` : B}
      ${e && this.emptyText ? I`<div class="empty">${this.emptyText}</div>` : B}
    `;
  }
}
const Ur = ["step_response", "search_overshoot"], eh = 2, dn = [
  { id: "test", gcode: "TEST_PRESSURE_ADVANCE", applies: !1 },
  { id: "calibrate", gcode: "PA_CALIBRATE", applies: !0 }
];
function en(t) {
  return dn.find((e) => e.id === t) ?? dn[0];
}
const th = [
  { key: "SLOW_FLOW", type: "number", placeholder: "2", above: 0 },
  { key: "HIGH_FLOW", type: "number", above: 0 },
  { key: "PURGE_LENGTH", type: "number", above: 0 },
  { key: "SEGMENT_TIME", type: "number", placeholder: "0.5", above: 0 },
  { key: "TEST_REPETITIONS", type: "int", placeholder: "10", min: 1 },
  { key: "FILTER_WINDOW", type: "number", placeholder: "0.01", above: 0, max: 0.04 },
  { key: "EXTRUDE_FORCE_SIGN", type: "sign", placeholder: "0" },
  { key: "PA_RANGE", type: "range", placeholder: "0,0.2", method: "search_overshoot" },
  { key: "EXTRUDER", type: "extruder" },
  { key: "FORCE_SENSOR", type: "sensor" }
];
function Ii(t) {
  return th.filter((e) => !e.method || e.method === t);
}
function mn(t) {
  const e = Number(t);
  return t !== "" && Number.isFinite(e) ? e : null;
}
function sh(t, e) {
  const s = mn(e);
  return s === null || t.type === "int" && !Number.isInteger(s) || t.type === "sign" && !(Number.isInteger(s) && s >= -1 && s <= 1) || t.above !== void 0 && !(s > t.above) || t.min !== void 0 && s < t.min || t.max !== void 0 && s > t.max ? null : s;
}
function nh(t) {
  const e = t.split(",").map((i) => i.trim());
  if (e.length !== 2) return null;
  const s = mn(e[0]), n = mn(e[1]);
  return s === null || n === null || s < 0 || n >= eh || s >= n ? null : [s, n];
}
const ih = /^[^\s"'\r\n]+$/;
function tn(t, e, s) {
  const n = [t.gcode, `METHOD=${e}`], i = [];
  for (const u of Ii(e)) {
    const f = (s[u.key] ?? "").trim();
    if (f !== "")
      if (u.type === "range") {
        const d = nh(f);
        d ? n.push(`${u.key}=${d[0]},${d[1]}`) : i.push(u.key);
      } else if (u.type === "sensor" || u.type === "extruder")
        ih.test(f) ? n.push(`${u.key}=${f}`) : i.push(u.key);
      else {
        const d = sh(u, f);
        d === null ? i.push(u.key) : n.push(`${u.key}=${d}`);
      }
  }
  const r = mn((s.SLOW_FLOW ?? "").trim()), a = mn((s.HIGH_FLOW ?? "").trim());
  return r !== null && a !== null && r > 0 && a > 0 && a <= r && (i.includes("HIGH_FLOW") || i.push("HIGH_FLOW")), { script: n.join(" "), invalid: i };
}
const lh = new Set(dn.map((t) => t.gcode));
function rh(t) {
  const e = [];
  for (const s of t.split(/\r?\n/)) {
    const n = s.trim();
    !n || n.startsWith(";") || n.startsWith("#") || e.push(n.split(/\s+/)[0].toUpperCase());
  }
  return e;
}
function Wr(t, e) {
  if (t === null || !Number.isFinite(t) || t < 0) return null;
  const s = Number(t.toFixed(4));
  return e && e !== "extruder" ? `SET_PRESSURE_ADVANCE ADVANCE=${s} EXTRUDER=${e}` : `SET_PRESSURE_ADVANCE ADVANCE=${s}`;
}
const oh = [50, 60];
function Vr(t) {
  return t === 60 ? 60 : 50;
}
const ah = 4, ch = 1e-9;
class uh {
  period;
  #e = [];
  #s = [];
  #t = 0;
  #i = 0;
  #r = null;
  /** Smoothed time between samples, seconds; 0 until two samples were seen. */
  #n = 0;
  /** Sample rate reported by the sensor (`sample_rate` in its status), Hz; 0 when unknown. */
  #o = 0;
  #l = !0;
  constructor(e) {
    this.period = 1 / e;
  }
  /** False when the sensor is too slow for the filter: samples then pass through as they are. */
  get active() {
    return this.#l;
  }
  /**
   * Tells the filter the sensor's own sample rate. A known rate beats the estimate made from
   * timestamps: it is right from the first sample, even when batches hold a single one.
   * Pass null or a non-positive value to fall back to the estimate.
   */
  setSampleRate(e) {
    this.#o = e !== null && Number.isFinite(e) && e > 0 ? e : 0;
  }
  /** Filters one batch (ascending times). */
  process(e) {
    if (e.length === 0) return [];
    for (const i of e) {
      if (this.#r !== null) {
        const r = i.time - this.#r;
        r > 0 && r < 1 && (this.#n = this.#n ? this.#n * 0.9 + r * 0.1 : r);
      }
      this.#r = i.time;
    }
    const s = this.#o ? 1 / this.#o : this.#n;
    if (this.#l = s === 0 || this.period / s >= ah, !this.#l)
      return this.#a(), e.slice();
    const n = [];
    for (const i of e) {
      for (this.#e.push(i.time), this.#s.push(i.value), this.#i += i.value; i.time - this.#e[this.#t] >= this.period - ch; ) this.#i -= this.#s[this.#t++];
      n.push({ time: i.time, value: this.#i / (this.#e.length - this.#t) });
    }
    return this.#t > 1024 && (this.#e.splice(0, this.#t), this.#s.splice(0, this.#t), this.#t = 0), n;
  }
  #a() {
    this.#e = [], this.#s = [], this.#t = 0, this.#i = 0;
  }
}
const hh = /^load_cell(_probe)?(\s|$)/i, fh = /^extruder\d*$/i;
function jo(t) {
  const e = t.trim().split(/\s+/);
  return e[e.length - 1];
}
function ph(t) {
  const e = t.pa_tester, s = {};
  for (const [i, r] of Object.entries(e ?? {}))
    r != null && r !== "" && (s[i] = String(r));
  const n = Object.keys(t);
  return {
    hasPaTester: e !== void 0,
    options: s,
    loadCells: n.filter((i) => hh.test(i)).map((i) => ({ section: i, name: jo(i) })),
    extruders: n.filter((i) => fh.test(i))
  };
}
function Nn(t, e = "") {
  const s = e || t.options.force_sensor || "";
  return s ? t.loadCells.find((n) => n.section === s || n.name === s) ?? {
    section: s,
    name: jo(s)
  } : t.loadCells.length === 1 ? t.loadCells[0] : null;
}
async function dh(t) {
  const e = await t.request(
    "printer.objects.query",
    { objects: { configfile: ["settings"] } }
  );
  return ph(e?.status?.configfile?.settings ?? {});
}
function Mn(t) {
  return typeof t == "number" && Number.isFinite(t) ? t : null;
}
function mh(t) {
  const e = t?.data;
  if (!Array.isArray(e)) return { unit: "g", samples: [] };
  let s = !0;
  const n = [];
  for (const a of e) {
    if (!Array.isArray(a)) continue;
    const u = Mn(a[0]);
    if (u === null) continue;
    const f = Mn(a[1]);
    f === null && (s = !1), n.push({ time: u, g: f, counts: Mn(a[2]), tare: Mn(a[3]) ?? 0 });
  }
  const i = s ? "g" : "counts", r = [];
  for (const a of n) {
    const u = i === "g" ? a.g : a.counts === null ? null : a.counts - a.tare;
    u !== null && r.push({ time: a.time, value: u });
  }
  return { unit: i, samples: r };
}
function gh(t, e) {
  if (t.length === 0) return t.slice();
  const s = [];
  let n = t[0].time, i = 0, r = 0, a = n;
  for (const u of t)
    u.time - n >= e && r > 0 && (s.push({ time: a, value: i / r }), n = u.time, i = 0, r = 0), i += u.value, r++, a = u.time;
  return r > 0 && s.push({ time: a, value: i / r }), s;
}
const Gr = /* @__PURE__ */ new Map();
function vh(t, e, s, n, i) {
  const r = Gr.get(e) ?? 0, a = [r, ...s.map((p, b) => b).filter((p) => p !== r)], u = [];
  let f = !1, d = 0;
  const g = (p) => {
    const b = ++d;
    u.push(
      t.klippyStream(e, s[a[p]], n, (y) => {
        if (!(f || b !== d)) {
          if (y === "unavailable" && p + 1 < a.length) {
            g(p + 1);
            return;
          }
          y === "live" && Gr.set(e, a[p]), i?.(y);
        }
      })
    );
  };
  return g(0), () => {
    f = !0;
    for (const p of u) p?.();
    u.length = 0;
  };
}
const bh = 0.02;
function _h(t, e, s, n = () => performance.now() / 1e3, i = () => 0) {
  let r = null, a = null, u = 0, f = null, d = null, g = !1;
  const p = () => {
    d || g || (s.onSource("status", "connecting"), d = t.subscribe(
      { [e.section]: ["force_g"] },
      ($) => {
        const P = $?.[e.section]?.force_g;
        typeof P != "number" || !Number.isFinite(P) || (s.onSource("status", "live"), s.onMains?.(!1), s.onSamples([{ time: n(), value: P }], "g"));
      },
      { immediate: !0 }
    ));
  }, b = () => {
    d?.(), d = null;
  }, y = ($) => {
    $ && !a && !g ? a = t.subscribe(
      { [e.section]: ["sample_rate"] },
      (P) => {
        const N = P?.[e.section]?.sample_rate;
        typeof N != "number" || !Number.isFinite(N) || N <= 0 || (u = N, r?.setSampleRate(N));
      },
      { immediate: !0 }
    ) : !$ && a && (a(), a = null, u = 0);
  };
  return typeof t.klippyStream != "function" ? p() : f = vh(
    t,
    "load_cell/dump_force",
    // documented key first; older Klipper answers "Missing Argument [load_cell]" to it
    [{ sensor: e.name }, { load_cell: e.name }],
    ($) => {
      const P = mh($);
      if (!P.samples.length) return;
      let N = P.samples;
      const U = i();
      y(U !== 0), U ? ((!r || r.period !== 1 / U) && (r = new uh(U), r.setSampleRate(u)), N = r.process(N), s.onMains?.(r.active)) : r = null, s.onSamples(gh(N, bh), P.unit);
    },
    ($) => {
      g || ($ === "unavailable" ? (s.onSource("stream", "unavailable"), p()) : (b(), s.onSource("stream", $)));
    }
  ), () => {
    g = !0, f?.(), f = null, a?.(), a = null, b();
  };
}
function ul() {
  return {
    running: !1,
    method: null,
    perFlow: [],
    overall: null,
    search: [],
    found: null,
    corrected: null,
    forceSign: null,
    warnings: [],
    error: null,
    value: null
  };
}
const hl = /^(TEST_PRESSURE_ADVANCE|PA_CALIBRATE)\b/i, qo = /^Detected extrude_force_sign=(-?\d+)/, Yo = /^WARNING: high_flow is less than 2x slow_flow/, Jo = /^Searching for optimal pressure_advance/, wh = /^PA calibration results:/, yh = /^flow=\s*(-?\d+(?:\.\d+)?)\s+pressure_advance=(-?\d+(?:\.\d+)?)/, Sh = /^overall pressure_advance=(-?\d+(?:\.\d+)?)/, xh = /^Failed to detect Pressure Advance value/, $h = /^Tested pressure_advance=(-?\d+(?:\.\d+)?)\s*->\s*(no overshoot|overshoot)/, Eh = /^Search complete:\s*(\d+) tests?, pressure_advance=(-?\d+(?:\.\d+)?)/, Ah = /^PA correction: pressure_advance=(-?\d+(?:\.\d+)?)/, Br = /^WARNING:\s*(.+)$/, kh = /^Test (\d+): pressure_advance=(-?\d+(?:\.\d+)?)/, Th = /^(Wait for calculations\.\.|\(accounts for force data filtering\)|Check sensor and filament)/;
function Rh(t) {
  const e = Array.isArray(t) ? t : [t], s = [];
  for (const n of e)
    if (typeof n == "string")
      for (const i of n.split(/\r?\n/)) {
        const r = i.trim();
        r && s.push(r);
      }
  return s;
}
function fl(t) {
  return t.startsWith("!!") ? { text: t.replace(/^!!\s*/, ""), error: !0 } : { text: t.replace(/^\/\/\s*/, ""), error: !1 };
}
function Zo(t) {
  const { text: e } = fl(t);
  return hl.test(e) || qo.test(e) || Yo.test(e) || Jo.test(e);
}
function Mh(t) {
  return hl.test(fl(t).text);
}
function Ch(t) {
  for (let e = t.length - 1; e >= 0; e--)
    if (Mh(t[e])) return t.slice(e);
  for (let e = t.length - 1; e >= 0; e--)
    if (Zo(t[e])) return t.slice(e);
  return [];
}
function Ph(t) {
  const e = /\bMETHOD=(step_response|search_overshoot)\b/i.exec(t);
  return e ? e[1].toLowerCase() : null;
}
function zn(t) {
  const e = ul();
  for (const s of t) {
    const { text: n, error: i } = fl(s);
    if (i) {
      e.error = n, e.running = !1;
      continue;
    }
    if (hl.test(n)) {
      e.running = !0, e.error = null;
      const a = Ph(n);
      a && (e.method = a);
      continue;
    }
    let r;
    if (r = qo.exec(n))
      e.running = !0, e.forceSign = Number(r[1]);
    else if (Yo.test(n))
      e.running = !0, e.warnings.push(n.replace(/^WARNING:\s*/, ""));
    else if (Jo.test(n))
      e.running = !0, e.method = "search_overshoot";
    else if (r = kh.exec(n))
      e.running = !0, e.method = "search_overshoot";
    else if (r = $h.exec(n))
      e.method = "search_overshoot", e.search.push({ pa: Number(r[1]), overshoot: r[2] === "overshoot" });
    else if (r = Eh.exec(n))
      e.method = "search_overshoot", e.found = Number(r[2]), e.value = e.found, e.running = !1;
    else if (r = Ah.exec(n))
      e.corrected = Number(r[1]), e.value = e.corrected;
    else if (wh.test(n))
      e.method = "step_response", e.running = !0;
    else if (r = yh.exec(n))
      e.method = "step_response", e.perFlow.push({ flow: Number(r[1]), pa: Number(r[2]) });
    else if (r = Sh.exec(n))
      e.method = "step_response", e.overall = Number(r[1]), e.value = e.overall, e.running = !1;
    else if (xh.test(n))
      e.error = n, e.running = !1;
    else if (Br.test(n))
      e.warnings.push(Br.exec(n)[1]);
    else if (Th.test(n))
      continue;
  }
  return e.corrected === null && e.found !== null && (e.value = e.found), e;
}
const Qo = 600;
function Nh() {
  return {
    lines: [],
    result: ul(),
    busy: !1,
    external: !1,
    restored: !1,
    lastLineAt: 0,
    config: null,
    configError: !1
  };
}
const Ui = /* @__PURE__ */ new Map(), Wi = /* @__PURE__ */ new Map();
function cs(t) {
  let e = Ui.get(t);
  return e || (e = Nh(), Ui.set(t, e)), e;
}
function Rt(t, e) {
  Ui.set(t, { ...cs(t), ...e });
  for (const s of Wi.get(t) ?? []) s();
}
function Lh(t, e) {
  let s = Wi.get(t);
  return s || (s = /* @__PURE__ */ new Set(), Wi.set(t, s)), s.add(e), () => s.delete(e);
}
function Oh(t) {
  const e = cs(t);
  Rt(t, {
    busy: !1,
    external: !1,
    result: { ...e.result, running: !1 },
    config: null
  });
}
function Dh(t) {
  Rt(t, {
    lines: [],
    result: { ...ul(), running: !0 },
    busy: !0,
    external: !1
  });
}
function Hh(t, e) {
  const s = cs(t), n = e ? [...s.lines, `!! ${e}`].slice(-300) : s.lines, i = zn(n);
  Rt(t, { busy: !1, lines: n, result: { ...i, running: !1 } });
}
function zh(t, e, s = Date.now() / 1e3) {
  const n = cs(t);
  let i = n.lines, r = n.external, a = n.busy || n.result.running;
  for (const f of e)
    !n.busy && Zo(f) && !a && (i = [], r = !0, a = !0), a && (i = [...i, f], !n.busy && !zn(i).running && (a = !1));
  if (i === n.lines) return;
  i = i.slice(-300);
  const u = zn(i);
  Rt(t, {
    lines: i,
    result: n.busy ? { ...u, running: !0 } : u,
    external: r && u.running,
    lastLineAt: s
  });
}
function Fh(t, e, s = Date.now() / 1e3) {
  const n = cs(t);
  if (n.restored || n.busy || n.lines.length > 0) {
    Rt(t, { restored: !0 });
    return;
  }
  const i = e.flatMap((d) => typeof d.message == "string" ? d.message.split(/\r?\n/) : []), r = Ch(i.map((d) => d.trim()).filter(Boolean)).slice(-300), a = zn(r), u = Number(e[e.length - 1]?.time ?? 0), f = a.running && s - u < Qo;
  Rt(t, {
    restored: !0,
    lines: r,
    result: { ...a, running: f },
    external: f,
    lastLineAt: u
  });
}
function Ih(t, e = Date.now() / 1e3) {
  const s = cs(t);
  !s.external || s.busy || !s.result.running || e - s.lastLineAt < Qo || Rt(t, { external: !1, result: { ...s.result, running: !1 } });
}
class Uh {
  constructor(e = 30, s = 6e3) {
    this.windowSeconds = e, this.maxPoints = s;
  }
  #e = [];
  #s = [];
  /** Index of the first live point; points before it are waiting to be spliced. */
  #t = 0;
  get length() {
    return this.#e.length - this.#t;
  }
  push(e, s) {
    this.#e.push(e), this.#s.push(s);
    const n = e - this.windowSeconds;
    for (; this.#t < this.#e.length && this.#e[this.#t] < n; ) this.#t++;
    const i = this.length - this.maxPoints;
    i > 0 && (this.#t += i), this.#t > 1024 && this.#t > this.length && (this.#e.splice(0, this.#t), this.#s.splice(0, this.#t), this.#t = 0);
  }
  clear() {
    this.#e = [], this.#s = [], this.#t = 0;
  }
  /** Live times (a copy; uPlot keeps the arrays it is given). */
  times() {
    return this.#e.slice(this.#t);
  }
  values() {
    return this.#s.slice(this.#t);
  }
  last() {
    const e = this.#e.length - 1;
    return e >= this.#t ? { time: this.#e[e], value: this.#s[e] } : null;
  }
  /** Min / max of the live window, null when empty. */
  range() {
    if (this.length === 0) return null;
    let e = 1 / 0, s = -1 / 0;
    for (let n = this.#t; n < this.#s.length; n++) {
      const i = this.#s[n];
      i < e && (e = i), i > s && (s = i);
    }
    return { min: e, max: s };
  }
}
const Wh = 120;
class Vh {
  #e;
  #s = "";
  #t = null;
  #i = [];
  #r = null;
  #n = null;
  /** Live printer status for the Run button (re-read on mount, not kept in run-store). */
  printState = "";
  homedAxes = "";
  activeExtruder = "";
  klippyReady = !0;
  extruders = {};
  paStatus = null;
  // ----- live chart
  buffer = new Uh(Wh, 8e3);
  /** Bumped after every push so the chart element redraws. */
  version = 0;
  chart = { kind: null, state: "connecting", unit: "g", mainsActive: !0 };
  #o = !1;
  #l = "";
  #a = null;
  #c = "";
  #u = 0;
  constructor(e) {
    this.#e = e, e.addController(this);
  }
  get printerId() {
    return this.#s;
  }
  get state() {
    return cs(this.#s);
  }
  get isPrinting() {
    return this.printState === "printing" || this.printState === "paused";
  }
  get isHomed() {
    return this.homedAxes === "xyz";
  }
  get extruder() {
    return this.extruders[this.activeExtruder] ?? null;
  }
  get handle() {
    return this.#t;
  }
  hostConnected() {
    document.addEventListener("visibilitychange", this.#f), this.#h();
  }
  hostUpdate() {
    this.#t || this.#h();
  }
  hostDisconnected() {
    document.removeEventListener("visibilitychange", this.#f), this.#v();
  }
  #f = () => this.#m();
  #h() {
    const e = this.#e.api;
    if (!e || this.#t || !this.#e.isConnected || (this.#i.push(
      e.onPrinterChange(() => {
        this.#v(), this.#h(), this.#e.requestUpdate();
      })
    ), !e.printer.id)) return;
    let s;
    try {
      s = e.moonraker();
    } catch {
      return;
    }
    this.#t = s, this.#s = e.printer.id;
    const n = this.#s;
    this.#i.push(Lh(n, () => this.#e.requestUpdate())), this.#i.push(
      s.subscribe(
        { print_stats: ["state"], toolhead: ["homed_axes", "extruder"], webhooks: ["state"] },
        (i) => {
          i?.print_stats?.state !== void 0 && (this.printState = String(i.print_stats.state)), i?.toolhead?.homed_axes !== void 0 && (this.homedAxes = String(i.toolhead.homed_axes)), i?.toolhead?.extruder !== void 0 && (this.activeExtruder = String(i.toolhead.extruder)), i?.webhooks?.state !== void 0 && (this.klippyReady = i.webhooks.state === "ready"), this.#e.requestUpdate();
        },
        { immediate: !0 }
      )
    ), this.#i.push(
      s.subscribe(
        {
          pa_tester: [
            "last_pressure_advance_test",
            "last_pressure_advance",
            "last_measured_pressure_advance",
            "last_corrected_pressure_advance"
          ]
        },
        (i) => {
          const r = i?.pa_tester;
          if (!r) return;
          const a = this.paStatus;
          this.paStatus = {
            test: typeof r.last_pressure_advance_test == "string" ? r.last_pressure_advance_test : a?.test ?? null,
            pa: typeof r.last_pressure_advance == "number" ? r.last_pressure_advance : a?.pa ?? null,
            measured: Array.isArray(r.last_measured_pressure_advance) ? r.last_measured_pressure_advance.filter((u) => typeof u == "number") : a?.measured ?? [],
            corrected: typeof r.last_corrected_pressure_advance == "number" ? r.last_corrected_pressure_advance : a?.corrected ?? null
          }, this.#e.requestUpdate();
        },
        { immediate: !0 }
      )
    ), this.#i.push(s.onNotify("notify_gcode_response", (i) => zh(n, Rh(i)))), this.#i.push(
      s.onNotify("notify_klippy_ready", () => {
        Oh(n), this.#p();
      })
    ), this.#i.push(s.onNotify("notify_config_changed", () => void this.#p())), this.#n = setInterval(() => Ih(n), 3e4), this.state.config ? this.#b() : this.#p(), this.state.restored || this.#_(), this.#m();
  }
  #v() {
    for (const e of this.#i) e();
    this.#i = [], this.#r?.(), this.#r = null, this.#d(), this.#n && clearInterval(this.#n), this.#n = null, this.#t = null;
  }
  /** Reads the printer config again (the "Check again" button of the not-installed panel). */
  recheck() {
    return this.#p();
  }
  async #p() {
    const e = this.#t, s = this.#s;
    if (e)
      try {
        const n = await dh(e);
        Rt(s, { config: n, configError: !1 }), this.#b(), this.#m();
      } catch {
        Rt(s, { configError: !0 });
      }
  }
  #b() {
    this.#r?.(), this.#r = null;
    const e = this.#t, s = this.state.config?.extruders ?? [];
    if (!e || s.length === 0) return;
    const n = ["temperature", "target", "pressure_advance", "can_extrude"];
    this.#r = e.subscribe(
      Object.fromEntries(s.map((i) => [i, n])),
      (i) => {
        for (const r of s) {
          const a = i?.[r];
          if (!a) continue;
          const u = this.extruders[r] ?? { temperature: null, target: null, pressureAdvance: null, canExtrude: null };
          this.extruders = {
            ...this.extruders,
            [r]: {
              temperature: typeof a.temperature == "number" ? a.temperature : u.temperature,
              target: typeof a.target == "number" ? a.target : u.target,
              pressureAdvance: typeof a.pressure_advance == "number" ? a.pressure_advance : u.pressureAdvance,
              canExtrude: typeof a.can_extrude == "boolean" ? a.can_extrude : u.canExtrude
            }
          };
        }
        this.#e.requestUpdate();
      },
      { immediate: !0 }
    );
  }
  async #_() {
    const e = this.#t, s = this.#s;
    if (e)
      try {
        const n = await e.request(
          "server.gcode_store",
          { count: 300 }
        );
        Fh(s, n?.gcode_store ?? []);
      } catch {
        Rt(s, { restored: !0 });
      }
  }
  // ---------------------------------------------------------------- chart
  /** Asks for the trace of the load cell `sensor` (a section name, '' — automatic). */
  setChart(e, s = "") {
    this.#o === e && this.#l === s || (this.#o = e, this.#l = s, this.#m());
  }
  /**
   * Switches the mains filter (`hz` 0 = off). It acts on the incoming stream, so samples
   * already in the buffer keep the old setting: start the trace over rather than mix them.
   */
  setMains(e) {
    e !== this.#u && (this.#u = e, this.buffer.clear(), this.chart = { ...this.chart, mainsActive: !0 }, this.version++, this.#e.requestUpdate());
  }
  clearChart() {
    this.buffer.clear(), this.version++, this.#e.requestUpdate();
  }
  #d() {
    this.#a?.(), this.#a = null, this.#c = "";
  }
  #m() {
    const e = this.#t, s = this.state.config, i = this.#o && !document.hidden && e !== null && s !== null && s ? Nn(s, this.#l) : null, r = i ? `${this.#s}|${i.section}` : "";
    r !== this.#c && (this.#d(), !(!i || !e) && (this.#c = r, this.buffer.clear(), this.chart = { kind: null, state: "connecting", unit: this.chart.unit, mainsActive: !0 }, this.#a = _h(
      e,
      i,
      {
        onSamples: (a, u) => {
          u !== this.chart.unit && (this.buffer.clear(), this.chart = { ...this.chart, unit: u });
          for (const f of a) this.buffer.push(f.time, f.value);
          this.version++, this.#e.requestUpdate();
        },
        onSource: (a, u) => {
          this.chart.kind !== null && this.chart.kind !== a && this.buffer.clear(), this.chart = { ...this.chart, kind: a, state: u }, this.#e.requestUpdate();
        },
        onMains: (a) => {
          a !== this.chart.mainsActive && (this.chart = { ...this.chart, mainsActive: a }, this.#e.requestUpdate());
        }
      },
      void 0,
      () => this.#u
    ), this.#e.requestUpdate()));
  }
  // ------------------------------------------------------------- commands
  /**
   * Sends one command and waits for it. `printer.gcode.script` resolves only
   * when Klipper has finished it, i.e. after the whole measurement and the
   * calculation (minutes); the host proxy has no request timeout. Meanwhile
   * the console lines arrive live.
   */
  async run(e) {
    const s = this.#t, n = this.#s;
    if (!s || this.state.busy) return;
    Dh(n);
    let i;
    try {
      await s.request("printer.gcode.script", { script: e });
    } catch (r) {
      i = r instanceof Error ? r.message : String(r);
    } finally {
      Hh(n, i);
    }
  }
  /** A short command that is not a measurement (G28, SET_PRESSURE_ADVANCE): no run state. */
  async send(e) {
    if (!this.#t) return !1;
    try {
      return await this.#t.request("printer.gcode.script", { script: e }), !0;
    } catch (s) {
      return console.warn("[pa-tester] command failed:", e, s), !1;
    }
  }
}
const Gh = Yr`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
    min-width: 0;
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    font-size: var(--font-size-md);
    /* Width-based layout: the page area, not the window, decides (sidebars). */
    container-type: inline-size;
  }

  .panel {
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-width: 0;
  }
  .panel-header {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-sm) var(--space-md);
    border-bottom: 1px solid var(--border-color);
  }
  .panel-title {
    flex: 1;
    min-width: 0;
    font-size: var(--font-size-md);
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .panel-body {
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    min-width: 0;
  }

  .row { display: flex; align-items: center; gap: var(--space-sm); flex-wrap: wrap; }
  .muted { color: var(--text-muted); font-size: var(--font-size-sm); margin: 0; }
  .warn { color: var(--warning); font-size: var(--font-size-sm); margin: 0; }
  .error { color: var(--danger); font-size: var(--font-size-sm); margin: 0; }
  .ok { color: var(--success); font-size: var(--font-size-sm); margin: 0; }
  .mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }

  .chip {
    padding: 1px 8px;
    border-radius: 999px;
    border: 1px solid var(--border-color);
    background: var(--bg-surface-hover);
    color: var(--text-secondary);
    font-size: var(--font-size-sm);
    white-space: nowrap;
  }
  .chip.accent { border-color: var(--accent); color: var(--accent); font-weight: 600; }

  /* Command selector + gallery filters: same look as Calibrations' .sel-btn. */
  .sel-row { display: flex; gap: var(--space-xs); flex-wrap: wrap; }
  .sel-btn {
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-secondary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
  }
  .sel-btn:hover:not(:disabled) { background: var(--bg-surface-hover); }
  .sel-btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .sel-btn.active { background: var(--bg-surface-active); color: var(--accent); border-color: var(--accent); }

  .fields {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    gap: var(--space-sm);
  }
  .field { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
  .field-label { font-size: var(--font-size-sm); color: var(--text-secondary); }
  .field.invalid .field-label { color: var(--danger); }
  input, select {
    min-width: 0;
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
  }
  .field.invalid input { border-color: var(--danger); }
  input.num { inline-size: 7rem; }
  /* checkbox rows and uncaptioned controls sit on the baseline of the captioned fields */
  .check {
    display: inline-flex;
    align-items: center;
    gap: var(--space-xs);
    align-self: flex-end;
    min-height: 32px;
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    cursor: pointer;
  }
  .end { align-self: flex-end; }
  .chip.warn-chip { border-color: var(--warning); color: var(--warning); white-space: normal; }

  .gcode {
    display: block;
    padding: var(--space-xs) var(--space-sm);
    background: var(--bg-surface-hover-no-override, var(--bg-surface-hover));
    border: 1px dashed var(--border-color);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    white-space: pre-wrap;
    word-break: break-all;
    user-select: text;
  }

  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-xs);
    padding: var(--space-xs) var(--space-md);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface-hover);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
    white-space: nowrap;
  }
  .btn:hover:not(:disabled) { background: var(--bg-surface-active); }
  .btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .btn.primary { background: var(--accent); border-color: var(--accent); color: var(--accent-text, #fff); }
  .btn:focus-visible, .sel-btn:focus-visible {
    outline: 2px solid var(--accent-ring, var(--accent));
    outline-offset: 1px;
  }
  .icon-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    width: 28px;
    height: 28px;
    padding: 0;
    border: none;
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-muted);
    cursor: pointer;
    font-size: 15px;
    line-height: 1;
  }
  .icon-btn:hover { background: var(--bg-surface-hover); color: var(--text-primary); }
  .icon-btn.active { background: var(--accent); color: var(--accent-text, #fff); }
  .icon-btn svg { display: block; }

  .spinner {
    width: 12px;
    height: 12px;
    border: 2px solid currentColor;
    border-right-color: transparent;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    flex-shrink: 0;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  .card {
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    padding: var(--space-sm);
    display: flex;
    flex-direction: column;
    gap: var(--space-xs);
  }
  .card h4 { margin: 0; font-size: var(--font-size-sm); font-weight: 600; }

  table { width: 100%; border-collapse: collapse; font-size: var(--font-size-sm); }
  th, td { padding: var(--space-xs) var(--space-sm); text-align: start; border-bottom: 1px solid var(--border-color); }
  th { color: var(--text-muted); font-weight: 500; text-transform: uppercase; letter-spacing: 0.04em; }

  details.log summary { cursor: pointer; color: var(--text-secondary); font-size: var(--font-size-sm); }
  details.log pre {
    margin: var(--space-xs) 0 0;
    max-height: 200px;
    overflow: auto;
    padding: var(--space-sm);
    background: var(--bg-surface-hover);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    white-space: pre-wrap;
    word-break: break-word;
  }
  details.log pre .err { color: var(--danger); }

  /*
   * Help popover: same look as the host's HeaderHelp. It is a [popover] in the
   * top layer (see #placeHelp in pa-tab.ts); the UA style centres popovers
   * (inset: 0; margin: auto), we drop that and set top/left/right from JS.
   */
  .help-menu {
    position: fixed;
    inset: auto;
    margin: 0;
    min-width: min(280px, calc(100vw - 16px));
    max-width: min(380px, calc(100vw - 16px));
    max-height: calc(100vh - 16px);
    overflow-y: auto;
    padding: var(--space-sm);
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-md, 0 4px 12px rgba(0, 0, 0, 0.15));
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
  }
  .help-menu:popover-open { display: flex; flex-direction: column; gap: var(--space-sm); }
  .help-title {
    padding: var(--space-xs) var(--space-sm);
    font-size: var(--font-size-sm);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    color: var(--text-muted);
  }
  .help-body {
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    padding: 0 var(--space-sm) var(--space-xs);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    line-height: 1.5;
  }
  .help-body h4 { margin: var(--space-xs) 0 2px; color: var(--text-primary); font-size: var(--font-size-sm); font-weight: 600; }
  .help-body p { margin: 0; }

  .gcode-row { display: flex; gap: var(--space-sm); align-items: stretch; }
  .gcode-row .gcode { flex: 1; min-width: 0; }
  ol.steps { margin: 0; padding-inline-start: 1.4em; display: flex; flex-direction: column; gap: var(--space-xs); }
  ol.steps li { color: var(--text-secondary); font-size: var(--font-size-sm); }
  ol.steps li .gcode { margin-top: 2px; }
  a { color: var(--accent); }
  .row.end { justify-content: flex-end; }
  b { font-weight: 600; }

  /*
   * Confirmation of PA_CALIBRATE: a native <dialog> opened with showModal()
   * lives in the browser's TOP LAYER. The Calibrations page is a size container
   * (container-type), which makes it the containing block of position:fixed
   * descendants, so a fixed div of ours would be clipped to the page area.
   */
  dialog.confirm {
    padding: 0;
    border: 1px solid var(--border-color);
    border-radius: var(--radius-lg);
    background: var(--bg-surface);
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    max-width: min(460px, 94vw);
  }
  dialog.confirm::backdrop { background: var(--bg-overlay, rgba(0, 0, 0, 0.6)); }
  .confirm-body { display: flex; flex-direction: column; gap: var(--space-sm); padding: var(--space-md); }
  .confirm-body h3 { margin: 0; font-size: var(--font-size-md); }
  .confirm-body p { margin: 0; color: var(--text-secondary); font-size: var(--font-size-sm); }

  @container (max-width: 480px) {
    .panel-body { padding: var(--space-sm); }
    .fields { grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); }
  }
  @media (pointer: coarse) {
    .icon-btn { width: 36px; height: 36px; }
    .sel-btn, .btn, .check, select, input.num { min-height: 36px; }
  }
`, Bh = I`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor"
  stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
  <circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
  <line x1="12" y1="17" x2="12.01" y2="17"></line>
</svg>`, Kr = [30, 60, 120], Kh = "https://github.com/dmbutyugin/klipper/tree/generic-cartesian", sn = (t, e = 4) => t == null ? "—" : t.toFixed(e);
class jh extends Ti {
  static styles = Gh;
  static properties = {
    ...Ti.properties,
    command: { state: !0 },
    method: { state: !0 },
    values: { state: !0 },
    chartOpen: { state: !0 },
    chartSeconds: { state: !0 },
    chartPaused: { state: !0 },
    chartFilter: { state: !0 },
    chartFilterMs: { state: !0 },
    chartRaw: { state: !0 },
    chartMains: { state: !0 },
    chartMainsHz: { state: !0 },
    copied: { state: !0 },
    helpOpen: { state: !0 }
  };
  #e = new Vh(this);
  /** Printer whose settings are loaded into the fields. */
  #s = "";
  #t = null;
  #i = null;
  constructor() {
    super(), this.command = "test", this.method = "step_response", this.values = {}, this.chartOpen = !0, this.chartSeconds = 30, this.chartPaused = !1, this.chartFilter = "raw", this.chartFilterMs = cl, this.chartRaw = !1, this.chartMains = !1, this.chartMainsHz = 50, this.copied = null, this.helpOpen = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.#i = this.api?.onThemeChange(() => this.renderRoot.querySelector("tessera-pa-force-chart")?.restyle()) ?? null;
  }
  willUpdate(e) {
    super.willUpdate(e);
    const s = this.#e.printerId;
    this.api && s && s !== this.#s && (this.#s = s, this.#r()), this.#e.setChart(this.chartOpen && this.#o(), this.values.FORCE_SENSOR ?? ""), this.#e.setMains(this.chartMains ? this.chartMainsHz : 0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.#i?.(), this.#i = null, this.#S(!1), this.#s = "", this.#t && clearTimeout(this.#t);
  }
  #r() {
    const e = this.api.settings, s = e.get("command");
    this.command = dn.some((r) => r.id === s) ? s : "test";
    const n = e.get("method");
    this.method = n && Ur.includes(n) ? n : "step_response", this.values = e.get("values") ?? {}, this.chartOpen = e.get("chartOpen") ?? !0;
    const i = e.get("chartSeconds");
    this.chartSeconds = Kr.includes(i) ? i : 30, this.chartFilter = Ir(e.get("chartFilter")), this.chartFilterMs = Fi(e.get("chartFilterMs")), this.chartRaw = e.get("chartRaw") ?? !1, this.chartMains = e.get("chartMains") ?? !1, this.chartMainsHz = Vr(e.get("chartMainsHz"));
  }
  #n(e, s) {
    this.api?.settings.set(e, s);
  }
  #o() {
    const e = this.#e.state.config;
    return !!(e?.hasPaTester && Nn(e, this.values.FORCE_SENSOR ?? ""));
  }
  // ---------------------------------------------------------------- actions
  #l(e) {
    this.command = e, this.#n("command", e);
  }
  #a(e) {
    this.method = e, this.#n("method", e);
  }
  #c(e, s) {
    this.values = { ...this.values, [e]: s }, this.#n("values", this.values);
  }
  #u() {
    this.chartOpen = !this.chartOpen, this.#n("chartOpen", this.chartOpen);
  }
  #f(e) {
    this.chartSeconds = e, this.#n("chartSeconds", e);
  }
  #h(e) {
    this.chartFilter = e, this.#n("chartFilter", e);
  }
  #v(e) {
    Number.isFinite(e) && (this.chartFilterMs = Fi(e), this.#n("chartFilterMs", this.chartFilterMs));
  }
  #p(e) {
    this.chartRaw = e, this.#n("chartRaw", e);
  }
  #b(e) {
    this.chartMains = e, this.#n("chartMains", e);
  }
  #_(e) {
    this.chartMainsHz = e, this.#n("chartMainsHz", e);
  }
  /** Memo of the filtered extremes: the tab renders on every batch, the filter should not rerun for that. */
  #d = null;
  /**
   * Min / max of the drawn trace: the raw window, or the filtered curve (for the envelope
   * its lower and upper lines). Null when there is nothing to show.
   */
  #m() {
    const e = this.#e.buffer;
    if (this.chartFilter === "raw") return e.range();
    if (e.length === 0) return null;
    const s = `${this.#e.version}|${this.#e.printerId}|${this.chartFilter}|${this.chartFilterMs}`;
    if (this.#d?.key !== s) {
      const n = Ko(this.chartFilter, this.chartFilterMs, e.times(), e.values()).cols, i = n[0], r = n[n.length - 1];
      let a = 1 / 0, u = -1 / 0;
      for (let f = 0; f < i.length; f++)
        i[f] < a && (a = i[f]), r[f] > u && (u = r[f]);
      this.#d = { key: s, min: a, max: u };
    }
    return this.#d;
  }
  #x(e) {
    return this.t(`patester.chart.filter_${e}`);
  }
  #$() {
    const e = en(this.command), s = tn(e, this.method, this.values);
    s.invalid.length || this.#w() || (e.applies ? this.renderRoot.querySelector("dialog")?.showModal() : this.#e.run(s.script));
  }
  #E() {
    const e = tn(en(this.command), this.method, this.values);
    this.renderRoot.querySelector("dialog")?.close(), !(e.invalid.length || this.#w()) && this.#e.run(e.script);
  }
  async #A() {
    const e = Wr(this.#e.state.result.value, this.#e.activeExtruder || null);
    e && await this.#e.send(e);
  }
  async #y(e, s) {
    try {
      await navigator.clipboard.writeText(e);
    } catch {
      window.prompt(this.t("patester.common.copyManually"), e);
      return;
    }
    this.copied = s, this.#t && clearTimeout(this.#t), this.#t = setTimeout(() => this.copied = null, 1500);
  }
  // ------------------------------------------------------------------ help
  /**
   * The help popover lives in the browser's TOP LAYER (Popover API): our panel
   * clips its content and the Calibrations page is a size container, so a
   * positioned div of ours could not leave the page area. `popover="auto"`
   * brings light dismiss for free; we place it next to the button like the
   * host's HeaderHelp does.
   */
  #g = () => {
    const e = this.renderRoot.querySelector(".help-btn"), s = this.renderRoot.querySelector(".help-menu");
    if (!e || !s) return;
    const n = e.getBoundingClientRect(), i = s.offsetHeight, r = s.offsetWidth, a = window.innerHeight - n.bottom - 4, u = i <= a ? n.bottom + 4 : i <= n.top - 4 ? n.top - 4 - i : Math.max(8, window.innerHeight - i - 8);
    if (s.style.top = `${u}px`, document.documentElement.getAttribute("dir") === "rtl")
      s.style.left = `${Math.min(Math.max(8, n.left), Math.max(8, window.innerWidth - r - 8))}px`, s.style.right = "auto";
    else {
      const f = Math.min(Math.max(8, window.innerWidth - n.right), Math.max(8, window.innerWidth - r - 8));
      s.style.right = `${f}px`, s.style.left = "auto";
    }
  };
  #S(e) {
    window.removeEventListener("resize", this.#g), document.removeEventListener("scroll", this.#g, !0), e && (window.addEventListener("resize", this.#g), document.addEventListener("scroll", this.#g, !0));
  }
  #k(e) {
    this.helpOpen = e.newState === "open", this.helpOpen && this.#g(), this.#S(this.helpOpen);
  }
  /** Why Run is not possible now, or null. Our own requests skip our guard (see guard.ts), so we check here. */
  #w() {
    const e = this.#e, s = e.state.config;
    return e.klippyReady ? e.state.busy || e.state.result.running ? this.t("patester.block.running") : e.isPrinting ? this.t("patester.block.printing") : e.isHomed ? s && !Nn(s, this.values.FORCE_SENSOR ?? "") ? s.loadCells.length === 0 ? this.t("patester.block.noSensor") : this.t("patester.block.ambiguous") : e.extruder?.canExtrude === !1 ? this.t("patester.block.cold") : null : this.t("patester.block.homing") : this.t("patester.block.klippy");
  }
  // ---------------------------------------------------------------- render
  render() {
    const e = this.#e.state;
    return !this.api || !this.#e.printerId ? I`<p class="muted">${this.t("patester.common.noPrinter")}</p>` : e.config ? e.config.hasPaTester ? I`${this.#C()}${this.#L()}${this.#N()}` : this.#T(e.config.loadCells.length > 0) : I`<section class="panel"><div class="panel-body">
        <p class="muted">${e.configError ? this.t("patester.common.configError") : this.t("patester.common.loading")}</p>
      </div></section>`;
  }
  /**
   * No `[pa_tester]` section. The tab is always shown (no `available` export),
   * so this is what the user finds: where the module lives and what to add.
   * The config is re-read on `notify_klippy_ready` / `notify_config_changed`
   * (PaController), and by the button for the impatient.
   */
  #T(e) {
    return I`<section class="panel">
      <div class="panel-header">
        <span class="panel-title">${this.t("patester.install.title")}</span>
        <button type="button" class="btn" @click=${() => void this.#e.recheck()}>${this.t("patester.install.recheck")}</button>
      </div>
      <div class="panel-body">
        <p>${this.t("patester.install.intro")}</p>
        ${e ? B : I`<p class="warn">${this.t("patester.install.noLoadCell")}</p>`}
        <ol class="steps">
          <li>
            ${this.t("patester.install.stepModule")}
            <a href=${Kh} target="_blank" rel="noopener noreferrer">dmbutyugin/klipper (generic-cartesian)</a>
          </li>
          <li>${this.t("patester.install.stepNumpy")}</li>
          <li>
            ${this.t("patester.install.stepConfig")}
            <code class="gcode">[pa_tester]
force_sensor: load_cell
high_flow: 12
purge_length: 30</code>
          </li>
          <li>${this.t("patester.install.stepExtruder")}</li>
          <li>${this.t("patester.install.stepRestart")}</li>
        </ol>
      </div>
    </section>`;
  }
  #R() {
    const e = this.t("patester.help.title");
    return I`
      <button
        class="icon-btn help-btn ${this.helpOpen ? "active" : ""}"
        popovertarget="pa-help"
        title=${e}
        aria-label=${e}
      >${Bh}</button>
      <div id="pa-help" class="help-menu" popover="auto" role="dialog" aria-label=${e} @toggle=${this.#k}>
        <div class="help-title">${e}</div>
        <div class="help-body">
          <h4>${this.t("patester.help.runTitle")}</h4>
          <p>${this.t("patester.help.run")}</p>
          <h4>${this.t("patester.help.applyTitle")}</h4>
          <p>${this.t("patester.help.apply")}</p>
          <h4>${this.t("patester.help.chartTitle")}</h4>
          <p>${this.t("patester.help.chart")}</p>
        </div>
      </div>
    `;
  }
  #M(e) {
    const s = Ii(this.method).find((g) => g.key === e), n = this.#e.state.config, i = this.values[e] ?? "", a = tn(en(this.command), this.method, this.values).invalid.includes(e), u = this.#e.state.busy, f = (g) => this.#c(e, g.target.value);
    let d;
    if (s.type === "sensor" || s.type === "extruder") {
      const g = s.type === "sensor" ? n.loadCells.map((p) => p.section) : n.extruders;
      d = I`<select .value=${i} ?disabled=${u} @change=${f}>
        <option value="">${this.t("patester.common.default")}</option>
        ${g.map((p) => I`<option value=${p} ?selected=${p === i}>${p}</option>`)}
      </select>`;
    } else if (s.type === "sign")
      d = I`<select .value=${i} ?disabled=${u} @change=${f}>
        <option value="">${this.t("patester.common.default")}</option>
        ${["-1", "0", "1"].map((g) => I`<option value=${g} ?selected=${g === i}>${g}</option>`)}
      </select>`;
    else {
      const g = n.options[e.toLowerCase()];
      d = I`<input
        type=${s.type === "range" ? "text" : "number"}
        inputmode="decimal"
        step=${s.type === "int" ? "1" : "any"}
        placeholder=${g ?? s.placeholder ?? "—"}
        .value=${i}
        ?disabled=${u}
        @input=${f}
      />`;
    }
    return I`<label class="field ${a ? "invalid" : ""}" title=${this.t(`patester.param.${e}`)}>
      <span class="field-label mono">${e}</span>
      ${d}
    </label>`;
  }
  #C() {
    const e = this.#e, s = e.state, n = s.result, i = en(this.command), r = tn(i, this.method, this.values), a = this.#w(), u = s.busy || n.running, f = e.extruder?.pressureAdvance ?? null, d = Wr(n.value, e.activeExtruder || null);
    return I`
      <section class="panel">
        <header class="panel-header">
          <span class="panel-title">${this.t("patester.title")}</span>
          ${f !== null ? I`<span class="chip mono" title=${this.t("patester.result.current")}>PA ${sn(f, 4)}</span>` : B}
          ${this.#R()}
        </header>
        <div class="panel-body">
          <div class="sel-row" role="radiogroup" aria-label=${this.t("patester.command.label")}>
            ${dn.map(
      (g) => I`<button
                class="sel-btn ${g.id === this.command ? "active" : ""}"
                role="radio"
                aria-checked=${g.id === this.command}
                ?disabled=${s.busy}
                title=${g.gcode}
                @click=${() => this.#l(g.id)}
              >${this.t(`patester.command.${g.id}`)}</button>`
    )}
          </div>
          <p class="muted">${this.t(`patester.command.${this.command}Hint`)}</p>

          <div class="sel-row" role="radiogroup" aria-label=${this.t("patester.method.label")}>
            ${Ur.map(
      (g) => I`<button
                class="sel-btn ${g === this.method ? "active" : ""}"
                role="radio"
                aria-checked=${g === this.method}
                ?disabled=${s.busy}
                @click=${() => this.#a(g)}
              >${this.t(`patester.method.${g}`)}</button>`
    )}
          </div>
          <p class="muted">${this.t(`patester.method.${this.method}Hint`)}</p>

          <div class="fields">${Ii(this.method).map((g) => this.#M(g.key))}</div>

          ${r.invalid.length ? I`<p class="error">${this.t("patester.block.invalid", { fields: r.invalid.join(", ") })}</p>` : B}
          ${a && !u ? I`<p class="warn">${a}</p>` : B}

          <div class="gcode-row">
            <code class="gcode mono">${r.script}</code>
            <button class="btn" @click=${() => void this.#y(r.script, "gcode")}>
              ${this.copied === "gcode" ? this.t("patester.common.copied") : this.t("patester.common.copy")}
            </button>
          </div>
          <div class="row">
            <button class="btn primary" ?disabled=${!!a || r.invalid.length > 0} @click=${() => this.#$()}>
              ${u ? I`<span class="spinner"></span> ${this.t("patester.run.running")}` : this.t(`patester.run.${this.command}`)}
            </button>
            ${!e.isHomed && e.klippyReady && !u && !e.isPrinting ? I`<button class="btn" @click=${() => void e.send("G28")}>${this.t("patester.run.home")}</button>` : B}
          </div>

          ${u ? I`<p class="row muted">
                <span class="spinner"></span>
                ${s.external ? I`<span class="chip">${this.t("patester.run.external")}</span>` : B}
                ${this.t("patester.run.started")}
              </p>` : B}
          ${n.error ? I`<p class="error">${n.error}</p>` : B}

          ${this.#P(d, u)}

          ${s.lines.length ? I`<details class="log">
                <summary>${this.t("patester.run.log", { count: s.lines.length })}</summary>
                <pre class="mono">${s.lines.map((g) => I`<span class=${g.startsWith("!!") ? "err" : ""}>${g}\n</span>`)}</pre>
              </details>` : B}
        </div>
      </section>
    `;
  }
  #P(e, s) {
    const n = this.#e.state.result, i = this.#e.paStatus;
    return n.perFlow.length || n.search.length || n.overall !== null || n.found !== null ? I`
      <div class="card">
        <h4>${this.t("patester.result.title")}</h4>
        ${n.perFlow.length ? I`<table>
              <thead><tr><th>${this.t("patester.result.flow")}</th><th>${this.t("patester.result.pa")}</th></tr></thead>
              <tbody>${n.perFlow.map(
      (a) => I`<tr><td class="mono">${a.flow.toFixed(2)}</td><td class="mono">${a.pa.toFixed(3)}</td></tr>`
    )}</tbody>
            </table>` : B}
        ${n.search.length ? I`<table>
              <thead><tr><th>${this.t("patester.result.tested")}</th><th></th></tr></thead>
              <tbody>${n.search.map(
      (a) => I`<tr>
                  <td class="mono">${a.pa.toFixed(4)}</td>
                  <td>${a.overshoot ? this.t("patester.result.overshoot") : this.t("patester.result.noOvershoot")}</td>
                </tr>`
    )}</tbody>
            </table>` : B}
        ${n.overall !== null ? I`<p class="ok">${this.t("patester.result.overall")}: <b class="mono">${sn(n.overall, 3)}</b></p>` : B}
        ${n.found !== null ? I`<p class="ok">${this.t("patester.result.found")}: <b class="mono">${sn(n.found)}</b></p>` : B}
        ${n.corrected !== null ? I`<p class="ok">${this.t("patester.result.corrected")}: <b class="mono">${sn(n.corrected)}</b></p>` : B}
        ${n.forceSign !== null ? I`<p class="muted">${this.t("patester.result.forceSign", { sign: n.forceSign })}</p>` : B}
        ${n.warnings.map((a) => I`<p class="warn">${a}</p>`)}
        ${e && !s && this.command === "test" && this.#e.klippyReady ? I`<div class="row">
              <button class="btn" @click=${() => void this.#A()}>${this.t("patester.run.applyMeasured")}</button>
              <button class="btn" @click=${() => void this.#y(e, "apply")}>
                ${this.copied === "apply" ? this.t("patester.common.copied") : this.t("patester.common.copy")}
              </button>
              <code class="mono muted">${e}</code>
            </div>
            <p class="muted">${this.t("patester.run.saveHint")}</p>` : B}
      </div>
    ` : i?.pa !== null && i?.pa !== void 0 ? I`<p class="muted">${this.t("patester.result.lastKlipper", { test: i.test ?? "—", pa: sn(i.pa) })}</p>` : B;
  }
  #N() {
    const e = tn(en(this.command), this.method, this.values);
    return I`<dialog class="confirm" @click=${(s) => s.target === s.currentTarget && s.currentTarget.close()}>
      <div class="confirm-body">
        <h3>${this.t("patester.confirm.title")}</h3>
        <p>${this.t("patester.confirm.body")}</p>
        <code class="gcode mono">${e.script}</code>
        <div class="row end">
          <button class="btn" @click=${(s) => s.currentTarget.closest("dialog").close()}>
            ${this.t("patester.confirm.cancel")}
          </button>
          <button class="btn primary" @click=${() => this.#E()}>${this.t("patester.confirm.ok")}</button>
        </div>
      </div>
    </dialog>`;
  }
  #L() {
    const e = this.#e, s = e.state.config, n = Nn(s, this.values.FORCE_SENSOR ?? ""), i = e.buffer.last(), r = this.#m(), a = e.chart.unit === "g" ? "g" : this.t("patester.chart.counts"), u = e.chart.unit === "g" ? 2 : 0, f = (p) => p === void 0 ? "—" : `${p.toFixed(u)} ${a}`;
    let d = B;
    e.chart.kind === "stream" && e.chart.state === "live" ? d = I`<span class="chip">${this.t("patester.chart.sourceStream")}</span>` : e.chart.kind === "status" && (d = I`<span class="chip" title=${this.t("patester.chart.sourceStatusHint")}>${this.t("patester.chart.sourceStatus")}</span>`);
    let g = this.t("patester.chart.noData");
    return n ? this.chartOpen ? e.chart.state === "connecting" && (g = this.t("patester.chart.connecting")) : g = "" : g = s.loadCells.length ? this.t("patester.block.ambiguous") : this.t("patester.block.noSensor"), I`
      <section class="panel">
        <header class="panel-header">
          <span class="panel-title">${this.t("patester.chart.title")}</span>
          ${n ? I`<span class="chip mono" title=${n.section}>${n.section}</span>` : B}
          ${this.chartOpen ? d : B}
          <button class="btn" @click=${() => this.#u()}>
            ${this.chartOpen ? this.t("patester.chart.hide") : this.t("patester.chart.show")}
          </button>
        </header>
        ${this.chartOpen ? I`<div class="panel-body">
              <div class="row">
                <span class="chip mono">${this.t("patester.chart.now")} ${f(i?.value)}</span>
                <span class="chip mono">${this.t("patester.chart.min")} ${f(r?.min)}</span>
                <span class="chip mono">${this.t("patester.chart.max")} ${f(r?.max)}</span>
              </div>
              <tessera-pa-force-chart
                .buffer=${e.buffer}
                .version=${e.version}
                .unit=${e.chart.unit}
                .seconds=${this.chartSeconds}
                .paused=${this.chartPaused}
                .filter=${this.chartFilter}
                .filterMs=${this.chartFilterMs}
                .showRaw=${this.chartRaw}
                .emptyText=${g}
              ></tessera-pa-force-chart>
              <div class="row">
                <div class="sel-row" role="radiogroup" aria-label=${this.t("patester.chart.window")}>
                  ${Kr.map(
      (p) => I`<button
                      class="sel-btn ${p === this.chartSeconds ? "active" : ""}"
                      role="radio"
                      aria-checked=${p === this.chartSeconds}
                      @click=${() => this.#f(p)}
                    >${p} ${this.t("patester.chart.sec")}</button>`
    )}
                </div>
                <button class="btn" @click=${() => this.chartPaused = !this.chartPaused}>
                  ${this.chartPaused ? this.t("patester.chart.resume") : this.t("patester.chart.pause")}
                </button>
                <button class="btn" @click=${() => e.clearChart()}>${this.t("patester.chart.clear")}</button>
              </div>
              <div class="row">
                <label class="field">
                  <span class="field-label">${this.t("patester.chart.filter")}</span>
                  <select @change=${(p) => this.#h(Ir(p.target.value))}>
                    ${Vo.map(
      (p) => I`<option value=${p} ?selected=${p === this.chartFilter}>${this.#x(p)}</option>`
    )}
                  </select>
                </label>
                ${this.chartFilter !== "raw" ? I`<label class="field">
                        <span class="field-label">${this.t("patester.chart.filterMs")}, ${this.t("patester.chart.ms")}</span>
                        <input
                          class="num"
                          type="number"
                          dir="ltr"
                          inputmode="numeric"
                          min=${Go}
                          max=${Bo}
                          step="10"
                          .value=${String(this.chartFilterMs)}
                          @change=${(p) => this.#v(p.target.valueAsNumber)}
                        />
                      </label>
                      <label class="check">
                        <input type="checkbox" .checked=${this.chartRaw} @change=${(p) => this.#p(p.target.checked)} />
                        <span>${this.t("patester.chart.showRaw")}</span>
                      </label>` : B}
                <label class="check">
                  <input type="checkbox" .checked=${this.chartMains} @change=${(p) => this.#b(p.target.checked)} />
                  <span>${this.t("patester.chart.mains")}</span>
                </label>
                ${this.chartMains ? I`<select
                        class="end"
                        aria-label=${this.t("patester.chart.mainsHz")}
                        @change=${(p) => this.#_(Vr(Number(p.target.value)))}
                      >
                        ${oh.map((p) => I`<option value=${p} ?selected=${p === this.chartMainsHz}>${p} ${this.t("patester.chart.hz")}</option>`)}
                      </select>
                      ${e.chart.mainsActive ? B : I`<span class="chip warn-chip end">${this.t("patester.chart.mainsLowRate")}</span>`}` : B}
              </div>
              <p class="muted">${this.t("patester.chart.tare")}</p>
            </div>` : B}
      </section>
    `;
  }
}
const qh = 3e3;
async function Yh(t) {
  const e = Za();
  if (!e) return null;
  const s = e.moonrakerFor(t);
  try {
    const n = async () => {
      const r = (await s.request("printer.objects.query", {
        objects: { print_stats: ["state"], toolhead: ["homed_axes", "extruder"], configfile: ["settings"] }
      }))?.status ?? {}, a = String(r.toolhead?.extruder ?? "");
      let u = null;
      if (a) {
        const f = r.configfile?.settings ?? {}, d = Number(f[a]?.min_extrude_temp), p = (await s.request("printer.objects.query", {
          objects: { [a]: ["temperature"] }
        }))?.status?.[a]?.temperature;
        Number.isFinite(d) && typeof p == "number" && (u = p < d);
      }
      return {
        printState: String(r.print_stats?.state ?? ""),
        homedAxes: String(r.toolhead?.homed_axes ?? ""),
        cold: u
      };
    };
    return await Promise.race([
      n(),
      new Promise((i) => setTimeout(() => i(null), qh))
    ]);
  } catch {
    return null;
  }
}
async function Qh(t, e, s) {
  if (t.method !== "printer.gcode.script") return { action: "allow" };
  const n = String(t.params?.script ?? "");
  if (!rh(n).some((r) => lh.has(r))) return { action: "allow" };
  const i = await Yh(s.targetPrinterId);
  return i ? i.printState === "printing" || i.printState === "paused" ? { action: "deny", reasonKey: "patester.guard.printing" } : i.homedAxes !== "xyz" ? { action: "deny", reasonKey: "patester.guard.homing" } : i.cold === !0 ? { action: "deny", reasonKey: "patester.guard.cold" } : { action: "allow" } : { action: "allow" };
}
qi("tessera-pa-tester-tab", jh);
qi("tessera-pa-tester-bridge", ec);
qi("tessera-pa-force-chart", Xu);
const Xh = { en: Qa, ru: Xa };
export {
  Qh as guardPaTester,
  Xh as locales
};
