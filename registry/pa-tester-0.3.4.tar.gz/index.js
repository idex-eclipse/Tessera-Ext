/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Cn = globalThis, Vi = Cn.ShadowRoot && (Cn.ShadyCSS === void 0 || Cn.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, Gi = Symbol(), Vl = /* @__PURE__ */ new WeakMap();
let jr = class {
  constructor(e, n, s) {
    if (this._$cssResult$ = !0, s !== Gi) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = e, this.t = n;
  }
  get styleSheet() {
    let e = this.o;
    const n = this.t;
    if (Vi && e === void 0) {
      const s = n !== void 0 && n.length === 1;
      s && (e = Vl.get(n)), e === void 0 && ((this.o = e = new CSSStyleSheet()).replaceSync(this.cssText), s && Vl.set(n, e));
    }
    return e;
  }
  toString() {
    return this.cssText;
  }
};
const qr = (t) => new jr(typeof t == "string" ? t : t + "", void 0, Gi), Yr = (t, ...e) => {
  const n = t.length === 1 ? t[0] : e.reduce((s, i, r) => s + ((o) => {
    if (o._$cssResult$ === !0) return o.cssText;
    if (typeof o == "number") return o;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + o + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(i) + t[r + 1], t[0]);
  return new jr(n, t, Gi);
}, Ra = (t, e) => {
  if (Vi) t.adoptedStyleSheets = e.map((n) => n instanceof CSSStyleSheet ? n : n.styleSheet);
  else for (const n of e) {
    const s = document.createElement("style"), i = Cn.litNonce;
    i !== void 0 && s.setAttribute("nonce", i), s.textContent = n.cssText, t.appendChild(s);
  }
}, Gl = Vi ? (t) => t : (t) => t instanceof CSSStyleSheet ? ((e) => {
  let n = "";
  for (const s of e.cssRules) n += s.cssText;
  return qr(n);
})(t) : t;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: Ma, defineProperty: Ca, getOwnPropertyDescriptor: Pa, getOwnPropertyNames: Na, getOwnPropertySymbols: La, getPrototypeOf: Oa } = Object, zn = globalThis, Bl = zn.trustedTypes, Da = Bl ? Bl.emptyScript : "", Fa = zn.reactiveElementPolyfillSupport, on = (t, e) => t, ki = { toAttribute(t, e) {
  switch (e) {
    case Boolean:
      t = t ? Da : null;
      break;
    case Object:
    case Array:
      t = t == null ? t : JSON.stringify(t);
  }
  return t;
}, fromAttribute(t, e) {
  let n = t;
  switch (e) {
    case Boolean:
      n = t !== null;
      break;
    case Number:
      n = t === null ? null : Number(t);
      break;
    case Object:
    case Array:
      try {
        n = JSON.parse(t);
      } catch {
        n = null;
      }
  }
  return n;
} }, Jr = (t, e) => !Ma(t, e), Kl = { attribute: !0, type: String, converter: ki, reflect: !1, useDefault: !1, hasChanged: Jr };
Symbol.metadata ??= Symbol("metadata"), zn.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
let Ms = class extends HTMLElement {
  static addInitializer(e) {
    this._$Ei(), (this.l ??= []).push(e);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(e, n = Kl) {
    if (n.state && (n.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(e) && ((n = Object.create(n)).wrapped = !0), this.elementProperties.set(e, n), !n.noAccessor) {
      const s = Symbol(), i = this.getPropertyDescriptor(e, s, n);
      i !== void 0 && Ca(this.prototype, e, i);
    }
  }
  static getPropertyDescriptor(e, n, s) {
    const { get: i, set: r } = Pa(this.prototype, e) ?? { get() {
      return this[n];
    }, set(o) {
      this[n] = o;
    } };
    return { get: i, set(o) {
      const u = i?.call(this);
      r?.call(this, o), this.requestUpdate(e, u, s);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(e) {
    return this.elementProperties.get(e) ?? Kl;
  }
  static _$Ei() {
    if (this.hasOwnProperty(on("elementProperties"))) return;
    const e = Oa(this);
    e.finalize(), e.l !== void 0 && (this.l = [...e.l]), this.elementProperties = new Map(e.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(on("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(on("properties"))) {
      const n = this.properties, s = [...Na(n), ...La(n)];
      for (const i of s) this.createProperty(i, n[i]);
    }
    const e = this[Symbol.metadata];
    if (e !== null) {
      const n = litPropertyMetadata.get(e);
      if (n !== void 0) for (const [s, i] of n) this.elementProperties.set(s, i);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [n, s] of this.elementProperties) {
      const i = this._$Eu(n, s);
      i !== void 0 && this._$Eh.set(i, n);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(e) {
    const n = [];
    if (Array.isArray(e)) {
      const s = new Set(e.flat(1 / 0).reverse());
      for (const i of s) n.unshift(Gl(i));
    } else e !== void 0 && n.push(Gl(e));
    return n;
  }
  static _$Eu(e, n) {
    const s = n.attribute;
    return s === !1 ? void 0 : typeof s == "string" ? s : typeof e == "string" ? e.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise((e) => this.enableUpdating = e), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((e) => e(this));
  }
  addController(e) {
    (this._$EO ??= /* @__PURE__ */ new Set()).add(e), this.renderRoot !== void 0 && this.isConnected && e.hostConnected?.();
  }
  removeController(e) {
    this._$EO?.delete(e);
  }
  _$E_() {
    const e = /* @__PURE__ */ new Map(), n = this.constructor.elementProperties;
    for (const s of n.keys()) this.hasOwnProperty(s) && (e.set(s, this[s]), delete this[s]);
    e.size > 0 && (this._$Ep = e);
  }
  createRenderRoot() {
    const e = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return Ra(e, this.constructor.elementStyles), e;
  }
  connectedCallback() {
    this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$EO?.forEach((e) => e.hostConnected?.());
  }
  enableUpdating(e) {
  }
  disconnectedCallback() {
    this._$EO?.forEach((e) => e.hostDisconnected?.());
  }
  attributeChangedCallback(e, n, s) {
    this._$AK(e, s);
  }
  _$ET(e, n) {
    const s = this.constructor.elementProperties.get(e), i = this.constructor._$Eu(e, s);
    if (i !== void 0 && s.reflect === !0) {
      const r = (s.converter?.toAttribute !== void 0 ? s.converter : ki).toAttribute(n, s.type);
      this._$Em = e, r == null ? this.removeAttribute(i) : this.setAttribute(i, r), this._$Em = null;
    }
  }
  _$AK(e, n) {
    const s = this.constructor, i = s._$Eh.get(e);
    if (i !== void 0 && this._$Em !== i) {
      const r = s.getPropertyOptions(i), o = typeof r.converter == "function" ? { fromAttribute: r.converter } : r.converter?.fromAttribute !== void 0 ? r.converter : ki;
      this._$Em = i;
      const u = o.fromAttribute(n, r.type);
      this[i] = u ?? this._$Ej?.get(i) ?? u, this._$Em = null;
    }
  }
  requestUpdate(e, n, s, i = !1, r) {
    if (e !== void 0) {
      const o = this.constructor;
      if (i === !1 && (r = this[e]), s ??= o.getPropertyOptions(e), !((s.hasChanged ?? Jr)(r, n) || s.useDefault && s.reflect && r === this._$Ej?.get(e) && !this.hasAttribute(o._$Eu(e, s)))) return;
      this.C(e, n, s);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(e, n, { useDefault: s, reflect: i, wrapped: r }, o) {
    s && !(this._$Ej ??= /* @__PURE__ */ new Map()).has(e) && (this._$Ej.set(e, o ?? n ?? this[e]), r !== !0 || o !== void 0) || (this._$AL.has(e) || (this.hasUpdated || s || (n = void 0), this._$AL.set(e, n)), i === !0 && this._$Em !== e && (this._$Eq ??= /* @__PURE__ */ new Set()).add(e));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (n) {
      Promise.reject(n);
    }
    const e = this.scheduleUpdate();
    return e != null && await e, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
        for (const [i, r] of this._$Ep) this[i] = r;
        this._$Ep = void 0;
      }
      const s = this.constructor.elementProperties;
      if (s.size > 0) for (const [i, r] of s) {
        const { wrapped: o } = r, u = this[i];
        o !== !0 || this._$AL.has(i) || u === void 0 || this.C(i, void 0, r, u);
      }
    }
    let e = !1;
    const n = this._$AL;
    try {
      e = this.shouldUpdate(n), e ? (this.willUpdate(n), this._$EO?.forEach((s) => s.hostUpdate?.()), this.update(n)) : this._$EM();
    } catch (s) {
      throw e = !1, this._$EM(), s;
    }
    e && this._$AE(n);
  }
  willUpdate(e) {
  }
  _$AE(e) {
    this._$EO?.forEach((n) => n.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(e)), this.updated(e);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(e) {
    return !0;
  }
  update(e) {
    this._$Eq &&= this._$Eq.forEach((n) => this._$ET(n, this[n])), this._$EM();
  }
  updated(e) {
  }
  firstUpdated(e) {
  }
};
Ms.elementStyles = [], Ms.shadowRootOptions = { mode: "open" }, Ms[on("elementProperties")] = /* @__PURE__ */ new Map(), Ms[on("finalized")] = /* @__PURE__ */ new Map(), Fa?.({ ReactiveElement: Ms }), (zn.reactiveElementVersions ??= []).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Bi = globalThis, jl = (t) => t, Ln = Bi.trustedTypes, ql = Ln ? Ln.createPolicy("lit-html", { createHTML: (t) => t }) : void 0, Zr = "$lit$", Wt = `lit$${Math.random().toFixed(9).slice(2)}$`, Qr = "?" + Wt, Ha = `<${Qr}>`, rs = document, un = () => rs.createComment(""), hn = (t) => t === null || typeof t != "object" && typeof t != "function", Ki = Array.isArray, za = (t) => Ki(t) || typeof t?.[Symbol.iterator] == "function", bi = `[ 	
\f\r]`, Zs = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Yl = /-->/g, Jl = />/g, es = RegExp(`>|${bi}(?:([^\\s"'>=/]+)(${bi}*=${bi}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Zl = /'/g, Ql = /"/g, Xr = /^(?:script|style|textarea|title)$/i, Ia = (t) => (e, ...n) => ({ _$litType$: t, strings: e, values: n }), I = Ia(1), Ls = Symbol.for("lit-noChange"), B = Symbol.for("lit-nothing"), Xl = /* @__PURE__ */ new WeakMap(), is = rs.createTreeWalker(rs, 129);
function eo(t, e) {
  if (!Ki(t) || !t.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return ql !== void 0 ? ql.createHTML(e) : e;
}
const Ua = (t, e) => {
  const n = t.length - 1, s = [];
  let i, r = e === 2 ? "<svg>" : e === 3 ? "<math>" : "", o = Zs;
  for (let u = 0; u < n; u++) {
    const h = t[u];
    let p, g, d = -1, b = 0;
    for (; b < h.length && (o.lastIndex = b, g = o.exec(h), g !== null); ) b = o.lastIndex, o === Zs ? g[1] === "!--" ? o = Yl : g[1] !== void 0 ? o = Jl : g[2] !== void 0 ? (Xr.test(g[2]) && (i = RegExp("</" + g[2], "g")), o = es) : g[3] !== void 0 && (o = es) : o === es ? g[0] === ">" ? (o = i ?? Zs, d = -1) : g[1] === void 0 ? d = -2 : (d = o.lastIndex - g[2].length, p = g[1], o = g[3] === void 0 ? es : g[3] === '"' ? Ql : Zl) : o === Ql || o === Zl ? o = es : o === Yl || o === Jl ? o = Zs : (o = es, i = void 0);
    const y = o === es && t[u + 1].startsWith("/>") ? " " : "";
    r += o === Zs ? h + Ha : d >= 0 ? (s.push(p), h.slice(0, d) + Zr + h.slice(d) + Wt + y) : h + Wt + (d === -2 ? u : y);
  }
  return [eo(t, r + (t[n] || "<?>") + (e === 2 ? "</svg>" : e === 3 ? "</math>" : "")), s];
};
class fn {
  constructor({ strings: e, _$litType$: n }, s) {
    let i;
    this.parts = [];
    let r = 0, o = 0;
    const u = e.length - 1, h = this.parts, [p, g] = Ua(e, n);
    if (this.el = fn.createElement(p, s), is.currentNode = this.el.content, n === 2 || n === 3) {
      const d = this.el.content.firstChild;
      d.replaceWith(...d.childNodes);
    }
    for (; (i = is.nextNode()) !== null && h.length < u; ) {
      if (i.nodeType === 1) {
        if (i.hasAttributes()) for (const d of i.getAttributeNames()) if (d.endsWith(Zr)) {
          const b = g[o++], y = i.getAttribute(d).split(Wt), $ = /([.?@])?(.*)/.exec(b);
          h.push({ type: 1, index: r, name: $[2], strings: y, ctor: $[1] === "." ? Va : $[1] === "?" ? Ga : $[1] === "@" ? Ba : In }), i.removeAttribute(d);
        } else d.startsWith(Wt) && (h.push({ type: 6, index: r }), i.removeAttribute(d));
        if (Xr.test(i.tagName)) {
          const d = i.textContent.split(Wt), b = d.length - 1;
          if (b > 0) {
            i.textContent = Ln ? Ln.emptyScript : "";
            for (let y = 0; y < b; y++) i.append(d[y], un()), is.nextNode(), h.push({ type: 2, index: ++r });
            i.append(d[b], un());
          }
        }
      } else if (i.nodeType === 8) if (i.data === Qr) h.push({ type: 2, index: r });
      else {
        let d = -1;
        for (; (d = i.data.indexOf(Wt, d + 1)) !== -1; ) h.push({ type: 7, index: r }), d += Wt.length - 1;
      }
      r++;
    }
  }
  static createElement(e, n) {
    const s = rs.createElement("template");
    return s.innerHTML = e, s;
  }
}
function Os(t, e, n = t, s) {
  if (e === Ls) return e;
  let i = s !== void 0 ? n._$Co?.[s] : n._$Cl;
  const r = hn(e) ? void 0 : e._$litDirective$;
  return i?.constructor !== r && (i?._$AO?.(!1), r === void 0 ? i = void 0 : (i = new r(t), i._$AT(t, n, s)), s !== void 0 ? (n._$Co ??= [])[s] = i : n._$Cl = i), i !== void 0 && (e = Os(t, i._$AS(t, e.values), i, s)), e;
}
class Wa {
  constructor(e, n) {
    this._$AV = [], this._$AN = void 0, this._$AD = e, this._$AM = n;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(e) {
    const { el: { content: n }, parts: s } = this._$AD, i = (e?.creationScope ?? rs).importNode(n, !0);
    is.currentNode = i;
    let r = is.nextNode(), o = 0, u = 0, h = s[0];
    for (; h !== void 0; ) {
      if (o === h.index) {
        let p;
        h.type === 2 ? p = new gn(r, r.nextSibling, this, e) : h.type === 1 ? p = new h.ctor(r, h.name, h.strings, this, e) : h.type === 6 && (p = new Ka(r, this, e)), this._$AV.push(p), h = s[++u];
      }
      o !== h?.index && (r = is.nextNode(), o++);
    }
    return is.currentNode = rs, i;
  }
  p(e) {
    let n = 0;
    for (const s of this._$AV) s !== void 0 && (s.strings !== void 0 ? (s._$AI(e, s, n), n += s.strings.length - 2) : s._$AI(e[n])), n++;
  }
}
class gn {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(e, n, s, i) {
    this.type = 2, this._$AH = B, this._$AN = void 0, this._$AA = e, this._$AB = n, this._$AM = s, this.options = i, this._$Cv = i?.isConnected ?? !0;
  }
  get parentNode() {
    let e = this._$AA.parentNode;
    const n = this._$AM;
    return n !== void 0 && e?.nodeType === 11 && (e = n.parentNode), e;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(e, n = this) {
    e = Os(this, e, n), hn(e) ? e === B || e == null || e === "" ? (this._$AH !== B && this._$AR(), this._$AH = B) : e !== this._$AH && e !== Ls && this._(e) : e._$litType$ !== void 0 ? this.$(e) : e.nodeType !== void 0 ? this.T(e) : za(e) ? this.k(e) : this._(e);
  }
  O(e) {
    return this._$AA.parentNode.insertBefore(e, this._$AB);
  }
  T(e) {
    this._$AH !== e && (this._$AR(), this._$AH = this.O(e));
  }
  _(e) {
    this._$AH !== B && hn(this._$AH) ? this._$AA.nextSibling.data = e : this.T(rs.createTextNode(e)), this._$AH = e;
  }
  $(e) {
    const { values: n, _$litType$: s } = e, i = typeof s == "number" ? this._$AC(e) : (s.el === void 0 && (s.el = fn.createElement(eo(s.h, s.h[0]), this.options)), s);
    if (this._$AH?._$AD === i) this._$AH.p(n);
    else {
      const r = new Wa(i, this), o = r.u(this.options);
      r.p(n), this.T(o), this._$AH = r;
    }
  }
  _$AC(e) {
    let n = Xl.get(e.strings);
    return n === void 0 && Xl.set(e.strings, n = new fn(e)), n;
  }
  k(e) {
    Ki(this._$AH) || (this._$AH = [], this._$AR());
    const n = this._$AH;
    let s, i = 0;
    for (const r of e) i === n.length ? n.push(s = new gn(this.O(un()), this.O(un()), this, this.options)) : s = n[i], s._$AI(r), i++;
    i < n.length && (this._$AR(s && s._$AB.nextSibling, i), n.length = i);
  }
  _$AR(e = this._$AA.nextSibling, n) {
    for (this._$AP?.(!1, !0, n); e !== this._$AB; ) {
      const s = jl(e).nextSibling;
      jl(e).remove(), e = s;
    }
  }
  setConnected(e) {
    this._$AM === void 0 && (this._$Cv = e, this._$AP?.(e));
  }
}
class In {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(e, n, s, i, r) {
    this.type = 1, this._$AH = B, this._$AN = void 0, this.element = e, this.name = n, this._$AM = i, this.options = r, s.length > 2 || s[0] !== "" || s[1] !== "" ? (this._$AH = Array(s.length - 1).fill(new String()), this.strings = s) : this._$AH = B;
  }
  _$AI(e, n = this, s, i) {
    const r = this.strings;
    let o = !1;
    if (r === void 0) e = Os(this, e, n, 0), o = !hn(e) || e !== this._$AH && e !== Ls, o && (this._$AH = e);
    else {
      const u = e;
      let h, p;
      for (e = r[0], h = 0; h < r.length - 1; h++) p = Os(this, u[s + h], n, h), p === Ls && (p = this._$AH[h]), o ||= !hn(p) || p !== this._$AH[h], p === B ? e = B : e !== B && (e += (p ?? "") + r[h + 1]), this._$AH[h] = p;
    }
    o && !i && this.j(e);
  }
  j(e) {
    e === B ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, e ?? "");
  }
}
class Va extends In {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(e) {
    this.element[this.name] = e === B ? void 0 : e;
  }
}
class Ga extends In {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(e) {
    this.element.toggleAttribute(this.name, !!e && e !== B);
  }
}
class Ba extends In {
  constructor(e, n, s, i, r) {
    super(e, n, s, i, r), this.type = 5;
  }
  _$AI(e, n = this) {
    if ((e = Os(this, e, n, 0) ?? B) === Ls) return;
    const s = this._$AH, i = e === B && s !== B || e.capture !== s.capture || e.once !== s.once || e.passive !== s.passive, r = e !== B && (s === B || i);
    i && this.element.removeEventListener(this.name, this, s), r && this.element.addEventListener(this.name, this, e), this._$AH = e;
  }
  handleEvent(e) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, e) : this._$AH.handleEvent(e);
  }
}
class Ka {
  constructor(e, n, s) {
    this.element = e, this.type = 6, this._$AN = void 0, this._$AM = n, this.options = s;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(e) {
    Os(this, e);
  }
}
const ja = Bi.litHtmlPolyfillSupport;
ja?.(fn, gn), (Bi.litHtmlVersions ??= []).push("3.3.3");
const qa = (t, e, n) => {
  const s = n?.renderBefore ?? e;
  let i = s._$litPart$;
  if (i === void 0) {
    const r = n?.renderBefore ?? null;
    s._$litPart$ = i = new gn(e.insertBefore(un(), r), r, void 0, n ?? {});
  }
  return i._$AI(t), i;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const ji = globalThis;
class Ps extends Ms {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    const e = super.createRenderRoot();
    return this.renderOptions.renderBefore ??= e.firstChild, e;
  }
  update(e) {
    const n = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(e), this._$Do = qa(n, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return Ls;
  }
}
Ps._$litElement$ = !0, Ps.finalized = !0, ji.litElementHydrateSupport?.({ LitElement: Ps });
const Ya = ji.litElementPolyfillSupport;
Ya?.({ LitElement: Ps });
(ji.litElementVersions ??= []).push("4.2.2");
let to = null;
function Ja(t) {
  to = t;
}
function Za() {
  return to;
}
class Ti extends Ps {
  static properties = {
    api: { attribute: !1 },
    params: { attribute: !1 }
  };
  #e = [];
  constructor() {
    super(), this.api = null, this.params = {};
  }
  connectedCallback() {
    super.connectedCallback(), this.api && this.#s(this.api);
  }
  willUpdate(e) {
    e.has("api") && this.api && this.#e.length === 0 && this.isConnected && this.#s(this.api);
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    for (const e of this.#e) e();
    this.#e = [];
  }
  #s(e) {
    Ja(e), this.#e.push(e.onLocaleChange(() => this.requestUpdate()));
  }
  /** Translation through the HOST dictionary (our `locales` export is merged into it). */
  t(e, n) {
    return this.api ? this.api.i18n.t(e, n) : e;
  }
}
function qi(t, e) {
  customElements.get(t) || customElements.define(t, e);
}
const Qa = {
  patester: {
    tabTitle: "Pressure Advance",
    title: "Pressure Advance",
    common: {
      loading: "Loading…",
      default: "default",
      noPrinter: "No active printer",
      configError: "Cannot read the printer config. Is Klipper ready?",
      copy: "Copy",
      copied: "Copied",
      copyManually: "Copy the text:"
    },
    install: {
      title: "pa_tester is not set up",
      intro: "This tab drives the Klipper module pa_tester, which measures Pressure Advance with a load cell in the nozzle. There is no [pa_tester] section in the printer config.",
      noLoadCell: "No [load_cell] or [load_cell_probe] in the printer config either: the module needs a load cell in the nozzle.",
      recheck: "Check again",
      stepModule: "The module is not in mainline Klipper. It lives in the generic-cartesian branch of the fork:",
      stepNumpy: "It needs NumPy in the Klipper Python environment.",
      stepConfig: "Add the section to printer.cfg (high_flow and purge_length are required; see the module source for the rest):",
      stepExtruder: "In [extruder], max_extrude_cross_section must allow the high flow.",
      stepRestart: "Restart Klipper completely: sudo systemctl restart klipper. The tab picks the module up by itself afterwards."
    },
    help: {
      title: "Help",
      runTitle: "Running a measurement",
      run: "Test only measures and reports. Calibrate also applies the result with SET_PRESSURE_ADVANCE. Empty fields use your [pa_tester] section. Axes must be homed, the extruder hot and the printer not printing. The run takes minutes; you can leave the tab, it keeps running in Klipper and is picked up again when you return.",
      applyTitle: "Apply vs printer.cfg",
      apply: "SET_PRESSURE_ADVANCE works at once but is lost on restart, and SAVE_CONFIG does not store it. Copy the value into the pressure_advance option of your [extruder] section to keep it.",
      chartTitle: "Load cell graph",
      chart: "The trace of the force sensor in the nozzle. It is streamed only while the graph is shown: hide it when you do not need it. Without the raw stream the graph falls back to about 4 samples per second."
    },
    command: {
      label: "Command",
      test: "Test",
      calibrate: "Calibrate",
      testHint: "TEST_PRESSURE_ADVANCE: measures and reports, changes nothing.",
      calibrateHint: "PA_CALIBRATE: measures and applies the result with SET_PRESSURE_ADVANCE."
    },
    method: {
      label: "Method",
      step_response: "Step response",
      search_overshoot: "Search overshoot",
      step_responseHint: "Extrudes at several flows and finds PA from the force response. Result per flow and overall.",
      search_overshootHint: "Searches the PA range for the value without overshoot. Set PA_RANGE to narrow it."
    },
    param: {
      SLOW_FLOW: "Slow flow, mm³/s (above 0)",
      HIGH_FLOW: "High flow, mm³/s: must be greater than slow flow",
      PURGE_LENGTH: "Filament length to purge, mm",
      SEGMENT_TIME: "Duration of one flow segment, s",
      TEST_REPETITIONS: "Repetitions (at least 1)",
      FILTER_WINDOW: "Force filter window, s (above 0, at most 0.04)",
      EXTRUDE_FORCE_SIGN: "Sign of the force while extruding: -1, 0 (auto) or 1",
      PA_RANGE: "min,max of the search: min ≥ 0, max below 2.0, min below max",
      EXTRUDER: "Extruder to test (must be the active one)",
      FORCE_SENSOR: "Load cell to use"
    },
    block: {
      klippy: "Klipper is not ready.",
      running: "A measurement is in progress.",
      printing: "Not available while printing.",
      homing: "Home all axes first.",
      cold: "The extruder is too cold to extrude: heat it up first.",
      noSensor: "No load cell in the printer config.",
      ambiguous: "Several load cells: choose FORCE_SENSOR.",
      invalid: "Invalid values: {fields}"
    },
    run: {
      test: "Run test",
      calibrate: "Calibrate",
      running: "Running…",
      home: "Home all",
      started: "Measuring: the result appears when Klipper finishes the calculation.",
      external: "started elsewhere",
      log: "Console log ({count} lines)",
      applyMeasured: "Apply",
      saveHint: "Applied until restart only. Put the value into [extruder] pressure_advance in printer.cfg to keep it."
    },
    confirm: {
      title: "Calibrate and apply?",
      body: "PA_CALIBRATE changes the pressure advance of the extruder when it finishes. The change is lost on restart unless you save it to printer.cfg.",
      ok: "Calibrate",
      cancel: "Cancel"
    },
    result: {
      title: "Result",
      current: "Current pressure advance of the extruder",
      lastKlipper: "Last result kept by Klipper: {test}, PA {pa}",
      flow: "Flow, mm³/s",
      pa: "Pressure advance",
      overall: "Overall pressure advance",
      tested: "Tested pressure advance",
      overshoot: "overshoot",
      noOvershoot: "no overshoot",
      found: "Found pressure advance",
      corrected: "Corrected for the force filter",
      forceSign: "Detected force sign: {sign}"
    },
    chart: {
      title: "Load cell",
      show: "Show",
      hide: "Hide",
      now: "now",
      min: "min",
      max: "max",
      counts: "counts",
      sec: "s",
      window: "Time window",
      pause: "Pause",
      resume: "Resume",
      clear: "Clear",
      connecting: "Connecting…",
      noData: "Waiting for data…",
      sourceStream: "raw stream",
      sourceStatus: "≈4 Hz",
      sourceStatusHint: "The raw stream is not available: the graph uses the status subscription (about 4 samples per second).",
      filter: "Filter",
      filter_raw: "Raw",
      filter_average: "Average",
      filter_moving: "Moving average",
      filter_median: "Moving median",
      filter_envelope: "Min/max envelope",
      filterMs: "Window",
      ms: "ms",
      showRaw: "Show raw",
      mains: "Mains filter",
      mainsHz: "Mains frequency",
      hz: "Hz",
      mainsLowRate: "Sensor too slow for the mains filter",
      tare: "Without calibration the graph shows counts relative to the tare. Tare the cell (LOAD_CELL_TARE) before a measurement."
    },
    guard: {
      printing: "Pressure advance measurement is not allowed while printing.",
      homing: "Home all axes before the pressure advance measurement.",
      cold: "The extruder is too cold for the pressure advance measurement."
    }
  }
}, Xa = {
  patester: {
    tabTitle: "Pressure Advance",
    title: "Pressure Advance",
    common: {
      loading: "Загрузка…",
      default: "по умолчанию",
      noPrinter: "Нет активного принтера",
      configError: "Не удалось прочитать конфигурацию принтера. Klipper готов?",
      copy: "Копировать",
      copied: "Скопировано",
      copyManually: "Скопируйте текст:"
    },
    install: {
      title: "pa_tester не настроен",
      intro: "Эта вкладка управляет модулем Klipper pa_tester, который измеряет Pressure Advance по датчику усилия в сопле. В конфигурации принтера нет секции [pa_tester].",
      noLoadCell: "Нет и [load_cell] или [load_cell_probe]: модулю нужен датчик усилия в сопле.",
      recheck: "Проверить снова",
      stepModule: "Модуля нет в основной ветке Klipper. Он лежит в ветке generic-cartesian форка:",
      stepNumpy: "Ему нужен NumPy в Python-окружении Klipper.",
      stepConfig: "Добавьте секцию в printer.cfg (high_flow и purge_length обязательны; остальное — в исходниках модуля):",
      stepExtruder: "В [extruder] max_extrude_cross_section должен допускать высокий расход.",
      stepRestart: "Полностью перезапустите Klipper: sudo systemctl restart klipper. После этого вкладка подхватит модуль сама."
    },
    help: {
      title: "Справка",
      runTitle: "Запуск измерения",
      run: "Test только измеряет и показывает результат. Calibrate дополнительно применяет его через SET_PRESSURE_ADVANCE. Пустые поля берутся из секции [pa_tester]. Оси должны быть в исходной позиции, экструдер горячим, принтер не печатает. Измерение идёт минуты; со вкладки можно уйти, оно продолжится в Klipper и подхватится при возвращении.",
      applyTitle: "Применение и printer.cfg",
      apply: "SET_PRESSURE_ADVANCE действует сразу, но пропадает при перезапуске, и SAVE_CONFIG его не сохраняет. Чтобы значение осталось, перенесите его в pressure_advance секции [extruder].",
      chartTitle: "График датчика усилия",
      chart: "Сигнал датчика усилия в сопле. Поток идёт, только пока график показан: скрывайте его, когда он не нужен. Без raw-потока график строится по статусу, около 4 отсчётов в секунду."
    },
    command: {
      label: "Команда",
      test: "Тест",
      calibrate: "Калибровка",
      testHint: "TEST_PRESSURE_ADVANCE: измеряет и показывает результат, ничего не меняет.",
      calibrateHint: "PA_CALIBRATE: измеряет и применяет результат через SET_PRESSURE_ADVANCE."
    },
    method: {
      label: "Метод",
      step_response: "Step response",
      search_overshoot: "Search overshoot",
      step_responseHint: "Экструзия на нескольких расходах, PA находится по отклику усилия. Результат по каждому расходу и общий.",
      search_overshootHint: "Поиск значения PA без перерегулирования в заданном диапазоне. Сузить диапазон можно через PA_RANGE."
    },
    param: {
      SLOW_FLOW: "Медленный расход, мм³/с (больше 0)",
      HIGH_FLOW: "Быстрый расход, мм³/с: должен быть больше медленного",
      PURGE_LENGTH: "Длина прутка для прочистки, мм",
      SEGMENT_TIME: "Длительность сегмента одного расхода, с",
      TEST_REPETITIONS: "Число повторов (не меньше 1)",
      FILTER_WINDOW: "Окно фильтра усилия, с (больше 0, не больше 0.04)",
      EXTRUDE_FORCE_SIGN: "Знак усилия при экструзии: -1, 0 (авто) или 1",
      PA_RANGE: "min,max поиска: min ≥ 0, max меньше 2.0, min меньше max",
      EXTRUDER: "Тестируемый экструдер (должен быть активным)",
      FORCE_SENSOR: "Используемый датчик усилия"
    },
    block: {
      klippy: "Klipper не готов.",
      running: "Измерение уже идёт.",
      printing: "Недоступно во время печати.",
      homing: "Сначала выполните парковку всех осей.",
      cold: "Экструдер слишком холодный для экструзии: сначала прогрейте его.",
      noSensor: "В конфигурации принтера нет датчика усилия.",
      ambiguous: "Несколько датчиков усилия: выберите FORCE_SENSOR.",
      invalid: "Неверные значения: {fields}"
    },
    run: {
      test: "Запустить тест",
      calibrate: "Калибровать",
      running: "Выполняется…",
      home: "Парковка",
      started: "Измерение: результат появится, когда Klipper закончит расчёт.",
      external: "запущено не здесь",
      log: "Лог консоли ({count} строк)",
      applyMeasured: "Применить",
      saveHint: "Действует только до перезапуска. Чтобы сохранить, впишите значение в pressure_advance секции [extruder] в printer.cfg."
    },
    confirm: {
      title: "Откалибровать и применить?",
      body: "По окончании PA_CALIBRATE изменит pressure advance экструдера. Изменение пропадёт при перезапуске, если не сохранить его в printer.cfg.",
      ok: "Калибровать",
      cancel: "Отмена"
    },
    result: {
      title: "Результат",
      current: "Текущий pressure advance экструдера",
      lastKlipper: "Последний результат в Klipper: {test}, PA {pa}",
      flow: "Расход, мм³/с",
      pa: "Pressure advance",
      overall: "Общий pressure advance",
      tested: "Проверенный pressure advance",
      overshoot: "перерегулирование",
      noOvershoot: "без перерегулирования",
      found: "Найденный pressure advance",
      corrected: "С поправкой на фильтр усилия",
      forceSign: "Определённый знак усилия: {sign}"
    },
    chart: {
      title: "Датчик усилия",
      show: "Показать",
      hide: "Скрыть",
      now: "сейчас",
      min: "мин",
      max: "макс",
      counts: "отсчётов",
      sec: "с",
      window: "Окно времени",
      pause: "Пауза",
      resume: "Продолжить",
      clear: "Очистить",
      connecting: "Подключение…",
      noData: "Ожидание данных…",
      sourceStream: "raw-поток",
      sourceStatus: "≈4 Гц",
      sourceStatusHint: "Raw-поток недоступен: график строится по подписке на статус (около 4 отсчётов в секунду).",
      filter: "Фильтр",
      filter_raw: "Сырой",
      filter_average: "Среднее",
      filter_moving: "Скользящее среднее",
      filter_median: "Скользящая медиана",
      filter_envelope: "Огибающая мин/макс",
      filterMs: "Окно",
      ms: "мс",
      showRaw: "Показать сырой",
      mains: "Фильтр сетевой помехи",
      mainsHz: "Частота сети",
      hz: "Гц",
      mainsLowRate: "Датчик слишком медленный для фильтра сети",
      tare: "Без калибровки график показывает отсчёты относительно тары. Перед измерением обнулите датчик (LOAD_CELL_TARE)."
    },
    guard: {
      printing: "Измерение pressure advance недоступно во время печати.",
      homing: "Перед измерением pressure advance выполните парковку всех осей.",
      cold: "Экструдер слишком холодный для измерения pressure advance."
    }
  }
};
class ec extends Ti {
  render() {
    return B;
  }
}
const tc = !0, Ce = "u-", sc = "uplot", nc = Ce + "hz", ic = Ce + "vt", lc = Ce + "title", rc = Ce + "wrap", oc = Ce + "under", ac = Ce + "over", cc = Ce + "axis", ns = Ce + "off", uc = Ce + "select", hc = Ce + "cursor-x", fc = Ce + "cursor-y", pc = Ce + "cursor-pt", dc = Ce + "legend", mc = Ce + "live", gc = Ce + "inline", vc = Ce + "series", bc = Ce + "marker", er = Ce + "label", _c = Ce + "value", nn = "width", ln = "height", Qs = "top", tr = "bottom", Rs = "left", _i = "right", Yi = "#000", sr = Yi + "0", wi = "mousemove", nr = "mousedown", yi = "mouseup", ir = "mouseenter", lr = "mouseleave", rr = "dblclick", wc = "resize", yc = "scroll", or = "change", On = "dppxchange", Ji = "--", Is = typeof window < "u", Ri = Is ? document : null, Ns = Is ? window : null, Sc = Is ? navigator : null;
let oe, kn;
function Mi() {
  let t = devicePixelRatio;
  oe != t && (oe = t, kn && Pi(or, kn, Mi), kn = matchMedia(`(min-resolution: ${oe - 1e-3}dppx) and (max-resolution: ${oe + 1e-3}dppx)`), ls(or, kn, Mi), Ns.dispatchEvent(new CustomEvent(On)));
}
function st(t, e) {
  if (e != null) {
    let n = t.classList;
    !n.contains(e) && n.add(e);
  }
}
function Ci(t, e) {
  let n = t.classList;
  n.contains(e) && n.remove(e);
}
function be(t, e, n) {
  t.style[e] = n + "px";
}
function bt(t, e, n, s) {
  let i = Ri.createElement(t);
  return e != null && st(i, e), n?.insertBefore(i, s), i;
}
function ht(t, e) {
  return bt("div", t, e);
}
const ar = /* @__PURE__ */ new WeakMap();
function Tt(t, e, n, s, i) {
  let r = "translate(" + e + "px," + n + "px)", o = ar.get(t);
  r != o && (t.style.transform = r, ar.set(t, r), e < 0 || n < 0 || e > s || n > i ? st(t, ns) : Ci(t, ns));
}
const cr = /* @__PURE__ */ new WeakMap();
function ur(t, e, n) {
  let s = e + n, i = cr.get(t);
  s != i && (cr.set(t, s), t.style.background = e, t.style.borderColor = n);
}
const hr = /* @__PURE__ */ new WeakMap();
function fr(t, e, n, s) {
  let i = e + "" + n, r = hr.get(t);
  i != r && (hr.set(t, i), t.style.height = n + "px", t.style.width = e + "px", t.style.marginLeft = s ? -e / 2 + "px" : 0, t.style.marginTop = s ? -n / 2 + "px" : 0);
}
const Zi = { passive: !0 }, xc = { ...Zi, capture: !0 };
function ls(t, e, n, s) {
  e.addEventListener(t, n, s ? xc : Zi);
}
function Pi(t, e, n, s) {
  e.removeEventListener(t, n, Zi);
}
Is && Mi();
function _t(t, e, n, s) {
  let i;
  n = n || 0, s = s || e.length - 1;
  let r = s <= 2147483647;
  for (; s - n > 1; )
    i = r ? n + s >> 1 : nt((n + s) / 2), e[i] < t ? n = i : s = i;
  return t - e[n] <= e[s] - t ? n : s;
}
function so(t) {
  return (n, s, i) => {
    let r = -1, o = -1;
    for (let u = s; u <= i; u++)
      if (t(n[u])) {
        r = u;
        break;
      }
    for (let u = i; u >= s; u--)
      if (t(n[u])) {
        o = u;
        break;
      }
    return [r, o];
  };
}
const no = (t) => t != null, io = (t) => t != null && t > 0, Un = so(no), $c = so(io);
function Ec(t, e, n, s = 0, i = !1) {
  let r = i ? $c : Un, o = i ? io : no;
  [e, n] = r(t, e, n);
  let u = t[e], h = t[e];
  if (e > -1)
    if (s == 1)
      u = t[e], h = t[n];
    else if (s == -1)
      u = t[n], h = t[e];
    else
      for (let p = e; p <= n; p++) {
        let g = t[p];
        o(g) && (g < u ? u = g : g > h && (h = g));
      }
  return [u ?? fe, h ?? -fe];
}
function Wn(t, e, n, s) {
  let i = mr(t), r = mr(e);
  t == e && (i == -1 ? (t *= n, e /= n) : (t /= n, e *= n));
  let o = n == 10 ? Nt : lo, u = i == 1 ? nt : ft, h = r == 1 ? ft : nt, p = u(o(Me(t))), g = h(o(Me(e))), d = Ds(n, p), b = Ds(n, g);
  return n == 10 && (p < 0 && (d = pe(d, -p)), g < 0 && (b = pe(b, -g))), s || n == 2 ? (t = d * i, e = b * r) : (t = co(t, d), e = Vn(e, b)), [t, e];
}
function Qi(t, e, n, s) {
  let i = Wn(t, e, n, s);
  return t == 0 && (i[0] = 0), e == 0 && (i[1] = 0), i;
}
const Xi = 0.1, pr = {
  mode: 3,
  pad: Xi
}, an = {
  pad: 0,
  soft: null,
  mode: 0
}, Ac = {
  min: an,
  max: an
};
function Dn(t, e, n, s) {
  return Gn(n) ? dr(t, e, n) : (an.pad = n, an.soft = s ? 0 : null, an.mode = s ? 3 : 0, dr(t, e, Ac));
}
function le(t, e) {
  return t ?? e;
}
function kc(t, e, n) {
  for (e = le(e, 0), n = le(n, t.length - 1); e <= n; ) {
    if (t[e] != null)
      return !0;
    e++;
  }
  return !1;
}
function dr(t, e, n) {
  let s = n.min, i = n.max, r = le(s.pad, 0), o = le(i.pad, 0), u = le(s.hard, -fe), h = le(i.hard, fe), p = le(s.soft, fe), g = le(i.soft, -fe), d = le(s.mode, 0), b = le(i.mode, 0), y = e - t, $ = Nt(y), P = je(Me(t), Me(e)), N = Nt(P), U = Me(N - $);
  (y < 1e-24 || U > 10) && (y = 0, (t == 0 || e == 0) && (y = 1e-24, d == 2 && p != fe && (r = 0), b == 2 && g != -fe && (o = 0)));
  let x = y || P || 1e3, z = Nt(x), E = Ds(10, nt(z)), J = x * (y == 0 ? t == 0 ? 0.1 : 1 : r), C = pe(co(t - J, E / 10), 24), Z = t >= p && (d == 1 || d == 3 && C <= p || d == 2 && C >= p) ? p : fe, j = je(u, C < Z && t >= Z ? Z : wt(Z, C)), ee = x * (y == 0 ? e == 0 ? 0.1 : 1 : o), K = pe(Vn(e + ee, E / 10), 24), A = e <= g && (b == 1 || b == 3 && K >= g || b == 2 && K <= g) ? g : -fe, Y = wt(h, K > A && e <= A ? A : je(A, K));
  return j == Y && j == 0 && (Y = 100), [j, Y];
}
const Tc = new Intl.NumberFormat(Is ? Sc.language : "en-US"), el = (t) => Tc.format(t), it = Math, Pn = it.PI, Me = it.abs, nt = it.floor, Re = it.round, ft = it.ceil, wt = it.min, je = it.max, Ds = it.pow, mr = it.sign, Nt = it.log10, lo = it.log2, Rc = (t, e = 1) => it.sinh(t) * e, Si = (t, e = 1) => it.asinh(t / e), fe = 1 / 0;
function gr(t) {
  return (Nt((t ^ t >> 31) - (t >> 31)) | 0) + 1;
}
function Ni(t, e, n) {
  return wt(je(t, e), n);
}
function ro(t) {
  return typeof t == "function";
}
function te(t) {
  return ro(t) ? t : () => t;
}
const Mc = () => {
}, oo = (t) => t, ao = (t, e) => e, Cc = (t) => null, vr = (t) => !0, br = (t, e) => t == e, Pc = /\.\d*?(?=9{6,}|0{6,})/gm, os = (t) => {
  if (ho(t) || Vt.has(t))
    return t;
  const e = `${t}`, n = e.match(Pc);
  if (n == null)
    return t;
  let s = n[0].length - 1;
  if (e.indexOf("e-") != -1) {
    let [i, r] = e.split("e");
    return +`${os(i)}e${r}`;
  }
  return pe(t, s);
};
function ts(t, e) {
  return os(pe(os(t / e)) * e);
}
function Vn(t, e) {
  return os(ft(os(t / e)) * e);
}
function co(t, e) {
  return os(nt(os(t / e)) * e);
}
function pe(t, e = 0) {
  if (ho(t))
    return t;
  let n = 10 ** e, s = t * n * (1 + Number.EPSILON);
  return Re(s) / n;
}
const Vt = /* @__PURE__ */ new Map();
function uo(t) {
  return (("" + t).split(".")[1] || "").length;
}
function pn(t, e, n, s) {
  let i = [], r = s.map(uo);
  for (let o = e; o < n; o++) {
    let u = Me(o), h = pe(Ds(t, o), u);
    for (let p = 0; p < s.length; p++) {
      let g = t == 10 ? +`${s[p]}e${o}` : s[p] * h, d = (o >= 0 ? 0 : u) + (o >= r[p] ? 0 : r[p]), b = t == 10 ? g : pe(g, d);
      i.push(b), Vt.set(b, d);
    }
  }
  return i;
}
const cn = {}, tl = [], Fs = [null, null], Ut = Array.isArray, ho = Number.isInteger, Nc = (t) => t === void 0;
function _r(t) {
  return typeof t == "string";
}
function Gn(t) {
  let e = !1;
  if (t != null) {
    let n = t.constructor;
    e = n == null || n == Object;
  }
  return e;
}
function Lc(t) {
  return t != null && typeof t == "object";
}
const Oc = Object.getPrototypeOf(Uint8Array), fo = "__proto__";
function Hs(t, e = Gn) {
  let n;
  if (Ut(t)) {
    let s = t.find((i) => i != null);
    if (Ut(s) || e(s)) {
      n = Array(t.length);
      for (let i = 0; i < t.length; i++)
        n[i] = Hs(t[i], e);
    } else
      n = t.slice();
  } else if (t instanceof Oc)
    n = t.slice();
  else if (e(t)) {
    n = {};
    for (let s in t)
      s != fo && (n[s] = Hs(t[s], e));
  } else
    n = t;
  return n;
}
function Ae(t) {
  let e = arguments;
  for (let n = 1; n < e.length; n++) {
    let s = e[n];
    for (let i in s)
      i != fo && (Gn(t[i]) ? Ae(t[i], Hs(s[i])) : t[i] = Hs(s[i]));
  }
  return t;
}
const Dc = 0, Fc = 1, Hc = 2;
function zc(t, e, n) {
  for (let s = 0, i, r = -1; s < e.length; s++) {
    let o = e[s];
    if (o > r) {
      for (i = o - 1; i >= 0 && t[i] == null; )
        t[i--] = null;
      for (i = o + 1; i < n && t[i] == null; )
        t[r = i++] = null;
    }
  }
}
function Ic(t, e) {
  if (Vc(t)) {
    let o = t[0].slice();
    for (let u = 1; u < t.length; u++)
      o.push(...t[u].slice(1));
    return Gc(o[0]) || (o = Wc(o)), o;
  }
  let n = /* @__PURE__ */ new Set();
  for (let o = 0; o < t.length; o++) {
    let h = t[o][0], p = h.length;
    for (let g = 0; g < p; g++)
      n.add(h[g]);
  }
  let s = [Array.from(n).sort((o, u) => o - u)], i = s[0].length, r = /* @__PURE__ */ new Map();
  for (let o = 0; o < i; o++)
    r.set(s[0][o], o);
  for (let o = 0; o < t.length; o++) {
    let u = t[o], h = u[0];
    for (let p = 1; p < u.length; p++) {
      let g = u[p], d = Array(i).fill(void 0), b = e ? e[o][p] : Fc, y = [];
      for (let $ = 0; $ < g.length; $++) {
        let P = g[$], N = r.get(h[$]);
        P === null ? b != Dc && (d[N] = P, b == Hc && y.push(N)) : d[N] = P;
      }
      zc(d, y, i), s.push(d);
    }
  }
  return s;
}
const Uc = typeof queueMicrotask > "u" ? (t) => Promise.resolve().then(t) : queueMicrotask;
function Wc(t) {
  let e = t[0], n = e.length, s = Array(n);
  for (let r = 0; r < s.length; r++)
    s[r] = r;
  s.sort((r, o) => e[r] - e[o]);
  let i = [];
  for (let r = 0; r < t.length; r++) {
    let o = t[r], u = Array(n);
    for (let h = 0; h < n; h++)
      u[h] = o[s[h]];
    i.push(u);
  }
  return i;
}
function Vc(t) {
  let e = t[0][0], n = e.length;
  for (let s = 1; s < t.length; s++) {
    let i = t[s][0];
    if (i.length != n)
      return !1;
    if (i != e) {
      for (let r = 0; r < n; r++)
        if (i[r] != e[r])
          return !1;
    }
  }
  return !0;
}
function Gc(t, e = 100) {
  const n = t.length;
  if (n <= 1)
    return !0;
  let s = 0, i = n - 1;
  for (; s <= i && t[s] == null; )
    s++;
  for (; i >= s && t[i] == null; )
    i--;
  if (i <= s)
    return !0;
  const r = je(1, nt((i - s + 1) / e));
  for (let o = t[s], u = s + r; u <= i; u += r) {
    const h = t[u];
    if (h != null) {
      if (h <= o)
        return !1;
      o = h;
    }
  }
  return !0;
}
const po = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
], mo = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday"
];
function go(t) {
  return t.slice(0, 3);
}
const Bc = mo.map(go), Kc = po.map(go), jc = {
  MMMM: po,
  MMM: Kc,
  WWWW: mo,
  WWW: Bc
};
function Xs(t) {
  return (t < 10 ? "0" : "") + t;
}
function qc(t) {
  return (t < 10 ? "00" : t < 100 ? "0" : "") + t;
}
const Yc = {
  // 2019
  YYYY: (t) => t.getFullYear(),
  // 19
  YY: (t) => (t.getFullYear() + "").slice(2),
  // July
  MMMM: (t, e) => e.MMMM[t.getMonth()],
  // Jul
  MMM: (t, e) => e.MMM[t.getMonth()],
  // 07
  MM: (t) => Xs(t.getMonth() + 1),
  // 7
  M: (t) => t.getMonth() + 1,
  // 09
  DD: (t) => Xs(t.getDate()),
  // 9
  D: (t) => t.getDate(),
  // Monday
  WWWW: (t, e) => e.WWWW[t.getDay()],
  // Mon
  WWW: (t, e) => e.WWW[t.getDay()],
  // 03
  HH: (t) => Xs(t.getHours()),
  // 3
  H: (t) => t.getHours(),
  // 9 (12hr, unpadded)
  h: (t) => {
    let e = t.getHours();
    return e == 0 ? 12 : e > 12 ? e - 12 : e;
  },
  // AM
  AA: (t) => t.getHours() >= 12 ? "PM" : "AM",
  // am
  aa: (t) => t.getHours() >= 12 ? "pm" : "am",
  // a
  a: (t) => t.getHours() >= 12 ? "p" : "a",
  // 09
  mm: (t) => Xs(t.getMinutes()),
  // 9
  m: (t) => t.getMinutes(),
  // 09
  ss: (t) => Xs(t.getSeconds()),
  // 9
  s: (t) => t.getSeconds(),
  // 374
  fff: (t) => qc(t.getMilliseconds())
};
function sl(t, e) {
  e = e || jc;
  let n = [], s = /\{([a-z]+)\}|[^{]+/gi, i;
  for (; i = s.exec(t); )
    n.push(i[0][0] == "{" ? Yc[i[1]] : i[0]);
  return (r) => {
    let o = "";
    for (let u = 0; u < n.length; u++)
      o += typeof n[u] == "string" ? n[u] : n[u](r, e);
    return o;
  };
}
const Jc = new Intl.DateTimeFormat().resolvedOptions().timeZone;
function Zc(t, e) {
  let n;
  return e == "UTC" || e == "Etc/UTC" ? n = new Date(+t + t.getTimezoneOffset() * 6e4) : e == Jc ? n = t : (n = new Date(t.toLocaleString("en-US", { timeZone: e })), n.setMilliseconds(t.getMilliseconds())), n;
}
const vo = (t) => t % 1 == 0, Fn = [1, 2, 2.5, 5], Qc = pn(10, -32, 0, Fn), bo = pn(10, 0, 32, Fn), Xc = bo.filter(vo), ss = Qc.concat(bo), nl = `
`, _o = "{YYYY}", wr = nl + _o, wo = "{M}/{D}", rn = nl + wo, Tn = rn + "/{YY}", yo = "{aa}", eu = "{h}:{mm}", Cs = eu + yo, yr = nl + Cs, Sr = ":{ss}", ce = null;
function So(t) {
  let e = t * 1e3, n = e * 60, s = n * 60, i = s * 24, r = i * 30, o = i * 365, h = (t == 1 ? pn(10, 0, 3, Fn).filter(vo) : pn(10, -3, 0, Fn)).concat([
    // minute divisors (# of secs)
    e,
    e * 5,
    e * 10,
    e * 15,
    e * 30,
    // hour divisors (# of mins)
    n,
    n * 5,
    n * 10,
    n * 15,
    n * 30,
    // day divisors (# of hrs)
    s,
    s * 2,
    s * 3,
    s * 4,
    s * 6,
    s * 8,
    s * 12,
    // month divisors TODO: need more?
    i,
    i * 2,
    i * 3,
    i * 4,
    i * 5,
    i * 6,
    i * 7,
    i * 8,
    i * 9,
    i * 10,
    i * 15,
    // year divisors (# months, approx)
    r,
    r * 2,
    r * 3,
    r * 4,
    r * 6,
    // century divisors
    o,
    o * 2,
    o * 5,
    o * 10,
    o * 25,
    o * 50,
    o * 100
  ]);
  const p = [
    //   tick incr    default          year                    month   day                   hour    min       sec   mode
    [o, _o, ce, ce, ce, ce, ce, ce, 1],
    [i * 28, "{MMM}", wr, ce, ce, ce, ce, ce, 1],
    [i, wo, wr, ce, ce, ce, ce, ce, 1],
    [s, "{h}" + yo, Tn, ce, rn, ce, ce, ce, 1],
    [n, Cs, Tn, ce, rn, ce, ce, ce, 1],
    [e, Sr, Tn + " " + Cs, ce, rn + " " + Cs, ce, yr, ce, 1],
    [t, Sr + ".{fff}", Tn + " " + Cs, ce, rn + " " + Cs, ce, yr, ce, 1]
  ];
  function g(d) {
    return (b, y, $, P, N, U) => {
      let x = [], z = N >= o, E = N >= r && N < o, J = d($), C = pe(J * t, 3), Z = xi(J.getFullYear(), z ? 0 : J.getMonth(), E || z ? 1 : J.getDate()), j = pe(Z * t, 3);
      if (E || z) {
        let ee = E ? N / r : 0, K = z ? N / o : 0, A = C == j ? C : pe(xi(Z.getFullYear() + K, Z.getMonth() + ee, 1) * t, 3), Y = new Date(Re(A / t)), L = Y.getFullYear(), V = Y.getMonth();
        for (let H = 0; A <= P; H++) {
          let se = xi(L + K * H, V + ee * H, 1), F = se - d(pe(se * t, 3));
          A = pe((+se + F) * t, 3), A <= P && x.push(A);
        }
      } else {
        let ee = N >= i ? i : N, K = nt($) - nt(C), A = j + K + Vn(C - j, ee);
        x.push(A);
        let Y = d(A), L = Y.getHours() + Y.getMinutes() / n + Y.getSeconds() / s, V = N / s, H = b.axes[y]._space, se = U / H;
        for (; A = pe(A + N, t == 1 ? 0 : 3), !(A > P); )
          if (V > 1) {
            let F = nt(pe(L + V, 6)) % 24, ne = d(A).getHours() - F;
            ne > 1 && (ne = -1), A -= ne * s, L = (L + V) % 24;
            let ue = x[x.length - 1];
            pe((A - ue) / N, 3) * se >= 0.7 && x.push(A);
          } else
            x.push(A);
      }
      return x;
    };
  }
  return [
    h,
    p,
    g
  ];
}
const [tu, su, nu] = So(1), [iu, lu, ru] = So(1e-3);
pn(2, -53, 53, [1]);
function xr(t, e) {
  return t.map((n) => n.map(
    (s, i) => i == 0 || i == 8 || s == null ? s : e(i == 1 || n[8] == 0 ? s : n[1] + s)
  ));
}
function $r(t, e) {
  return (n, s, i, r, o) => {
    let u = e.find(($) => o >= $[0]) || e[e.length - 1], h, p, g, d, b, y;
    return s.map(($) => {
      let P = t($), N = P.getFullYear(), U = P.getMonth(), x = P.getDate(), z = P.getHours(), E = P.getMinutes(), J = P.getSeconds(), C = N != h && u[2] || U != p && u[3] || x != g && u[4] || z != d && u[5] || E != b && u[6] || J != y && u[7] || u[1];
      return h = N, p = U, g = x, d = z, b = E, y = J, C(P);
    });
  };
}
function ou(t, e) {
  let n = sl(e);
  return (s, i, r, o, u) => i.map((h) => n(t(h)));
}
function xi(t, e, n) {
  return new Date(t, e, n);
}
function Er(t, e) {
  return e(t);
}
const au = "{YYYY}-{MM}-{DD} {h}:{mm}{aa}";
function Ar(t, e) {
  return (n, s, i, r) => r == null ? Ji : e(t(s));
}
function cu(t, e) {
  let n = t.series[e];
  return n.width ? n.stroke(t, e) : n.points.width ? n.points.stroke(t, e) : null;
}
function uu(t, e) {
  return t.series[e].fill(t, e);
}
const hu = {
  show: !0,
  live: !0,
  isolate: !1,
  mount: Mc,
  markers: {
    show: !0,
    width: 2,
    stroke: cu,
    fill: uu,
    dash: "solid"
  },
  idx: null,
  idxs: null,
  values: []
};
function fu(t, e) {
  let n = t.cursor.points, s = ht(), i = n.size(t, e);
  be(s, nn, i), be(s, ln, i);
  let r = i / -2;
  be(s, "marginLeft", r), be(s, "marginTop", r);
  let o = n.width(t, e, i);
  return o && be(s, "borderWidth", o), s;
}
function pu(t, e) {
  let n = t.series[e].points;
  return n._fill || n._stroke;
}
function du(t, e) {
  let n = t.series[e].points;
  return n._stroke || n._fill;
}
function mu(t, e) {
  return t.series[e].points.size;
}
const $i = [0, 0];
function gu(t, e, n) {
  return $i[0] = e, $i[1] = n, $i;
}
function Rn(t, e, n, s = !0) {
  return (i) => {
    i.button == 0 && (!s || i.target == e) && n(i);
  };
}
function Ei(t, e, n, s = !0) {
  return (i) => {
    (!s || i.target == e) && n(i);
  };
}
const vu = {
  show: !0,
  x: !0,
  y: !0,
  lock: !1,
  move: gu,
  points: {
    one: !1,
    show: fu,
    size: mu,
    width: 0,
    stroke: du,
    fill: pu
  },
  bind: {
    mousedown: Rn,
    mouseup: Rn,
    click: Rn,
    // legend clicks, not .u-over clicks
    dblclick: Rn,
    mousemove: Ei,
    mouseleave: Ei,
    mouseenter: Ei
  },
  drag: {
    setScale: !0,
    x: !0,
    y: !1,
    dist: 0,
    uni: null,
    click: (t, e) => {
      e.stopPropagation(), e.stopImmediatePropagation();
    },
    _x: !1,
    _y: !1
  },
  focus: {
    dist: (t, e, n, s, i) => s - i,
    prox: -1,
    bias: 0
  },
  hover: {
    skip: [void 0],
    prox: null,
    bias: 0
  },
  left: -10,
  top: -10,
  idx: null,
  dataIdx: null,
  idxs: null,
  event: null
}, xo = {
  show: !0,
  stroke: "rgba(0,0,0,0.07)",
  width: 2
  //	dash: [],
}, il = Ae({}, xo, {
  filter: ao
}), $o = Ae({}, il, {
  size: 10
}), Eo = Ae({}, xo, {
  show: !1
}), ll = '12px system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"', Ao = "bold " + ll, ko = 1.5, kr = {
  show: !0,
  scale: "x",
  stroke: Yi,
  space: 50,
  gap: 5,
  alignTo: 1,
  size: 50,
  labelGap: 0,
  labelSize: 30,
  labelFont: Ao,
  side: 2,
  //	class: "x-vals",
  //	incrs: timeIncrs,
  //	values: timeVals,
  //	filter: retArg1,
  grid: il,
  ticks: $o,
  border: Eo,
  font: ll,
  lineGap: ko,
  rotate: 0
}, bu = "Value", _u = "Time", Tr = {
  show: !0,
  scale: "x",
  auto: !1,
  sorted: 1,
  //	label: "Time",
  //	value: v => stamp(new Date(v * 1e3)),
  // internal caches
  min: fe,
  max: -fe,
  idxs: []
};
function wu(t, e, n, s, i) {
  return e.map((r) => r == null ? "" : el(r));
}
function yu(t, e, n, s, i, r, o) {
  let u = [], h = Vt.get(i) || 0;
  n = o ? n : pe(Vn(n, i), h);
  for (let p = n; p <= s; p = pe(p + i, h))
    u.push(Object.is(p, -0) ? 0 : p);
  return u;
}
function Li(t, e, n, s, i, r, o) {
  const u = [], h = t.scales[t.axes[e].scale].log, p = h == 10 ? Nt : lo, g = nt(p(n));
  i = Ds(h, g), h == 10 && (i = ss[_t(i, ss)]);
  let d = n, b = i * h;
  h == 10 && (b = ss[_t(b, ss)]);
  do
    u.push(d), d = d + i, h == 10 && !Vt.has(d) && (d = pe(d, Vt.get(i))), d >= b && (i = d, b = i * h, h == 10 && (b = ss[_t(b, ss)]));
  while (d <= s);
  return u;
}
function Su(t, e, n, s, i, r, o) {
  let h = t.scales[t.axes[e].scale].asinh, p = s > h ? Li(t, e, je(h, n), s, i) : [h], g = s >= 0 && n <= 0 ? [0] : [];
  return (n < -h ? Li(t, e, je(h, -s), -n, i) : [h]).reverse().map((b) => -b).concat(g, p);
}
const To = /./, xu = /[12357]/, $u = /[125]/, Rr = /1/, Oi = (t, e, n, s) => t.map((i, r) => e == 4 && i == 0 || r % s == 0 && n.test(i.toExponential()[i < 0 ? 1 : 0]) ? i : null);
function Eu(t, e, n, s, i) {
  let r = t.axes[n], o = r.scale, u = t.scales[o], h = t.valToPos, p = r._space, g = h(10, o), d = h(9, o) - g >= p ? To : h(7, o) - g >= p ? xu : h(5, o) - g >= p ? $u : Rr;
  if (d == Rr) {
    let b = Me(h(1, o) - g);
    if (b < p)
      return Oi(e.slice().reverse(), u.distr, d, ft(p / b)).reverse();
  }
  return Oi(e, u.distr, d, 1);
}
function Au(t, e, n, s, i) {
  let r = t.axes[n], o = r.scale, u = r._space, h = t.valToPos, p = Me(h(1, o) - h(2, o));
  return p < u ? Oi(e.slice().reverse(), 3, To, ft(u / p)).reverse() : e;
}
function ku(t, e, n, s) {
  return s == null ? Ji : e == null ? "" : el(e);
}
const Mr = {
  show: !0,
  scale: "y",
  stroke: Yi,
  space: 30,
  gap: 5,
  alignTo: 1,
  size: 50,
  labelGap: 0,
  labelSize: 30,
  labelFont: Ao,
  side: 3,
  //	class: "y-vals",
  //	incrs: numIncrs,
  //	values: (vals, space) => vals,
  //	filter: retArg1,
  grid: il,
  ticks: $o,
  border: Eo,
  font: ll,
  lineGap: ko,
  rotate: 0
};
function Tu(t, e) {
  let n = 3 + (t || 1) * 2;
  return pe(n * e, 3);
}
function Ru(t, e) {
  let { scale: n, idxs: s } = t.series[0], i = t._data[0], r = t.valToPos(i[s[0]], n, !0), o = t.valToPos(i[s[1]], n, !0), u = Me(o - r), h = t.series[e], p = u / (h.points.space * oe);
  return s[1] - s[0] <= p;
}
const Cr = {
  scale: null,
  auto: !0,
  sorted: 0,
  // internal caches
  min: fe,
  max: -fe
}, Ro = (t, e, n, s, i) => i, Pr = {
  show: !0,
  auto: !0,
  sorted: 0,
  gaps: Ro,
  alpha: 1,
  facets: [
    Ae({}, Cr, { scale: "x" }),
    Ae({}, Cr, { scale: "y" })
  ]
}, Nr = {
  scale: "y",
  auto: !0,
  sorted: 0,
  show: !0,
  spanGaps: !1,
  gaps: Ro,
  alpha: 1,
  points: {
    show: Ru,
    filter: null
    //  paths:
    //	stroke: "#000",
    //	fill: "#fff",
    //	width: 1,
    //	size: 10,
  },
  //	label: "Value",
  //	value: v => v,
  values: null,
  // internal caches
  min: fe,
  max: -fe,
  idxs: [],
  path: null,
  clip: null
};
function Mu(t, e, n, s, i) {
  return n / 10;
}
const Mo = {
  time: tc,
  auto: !0,
  distr: 1,
  log: 10,
  asinh: 1,
  min: null,
  max: null,
  dir: 1,
  ori: 0
}, Cu = Ae({}, Mo, {
  time: !1,
  ori: 1
}), Lr = {};
function Co(t, e) {
  let n = Lr[t];
  return n || (n = {
    key: t,
    plots: [],
    sub(s) {
      n.plots.push(s);
    },
    unsub(s) {
      n.plots = n.plots.filter((i) => i != s);
    },
    pub(s, i, r, o, u, h, p) {
      for (let g = 0; g < n.plots.length; g++)
        n.plots[g] != i && n.plots[g].pub(s, i, r, o, u, h, p);
    }
  }, t != null && (Lr[t] = n)), n;
}
const zs = 1, Di = 2;
function as(t, e, n) {
  const s = t.mode, i = t.series[e], r = s == 2 ? t._data[e] : t._data, o = t.scales, u = t.bbox;
  let h = r[0], p = s == 2 ? r[1] : r[e], g = s == 2 ? o[i.facets[0].scale] : o[t.series[0].scale], d = s == 2 ? o[i.facets[1].scale] : o[i.scale], b = u.left, y = u.top, $ = u.width, P = u.height, N = t.valToPosH, U = t.valToPosV;
  return g.ori == 0 ? n(
    i,
    h,
    p,
    g,
    d,
    N,
    U,
    b,
    y,
    $,
    P,
    Kn,
    Us,
    qn,
    No,
    Oo
  ) : n(
    i,
    h,
    p,
    g,
    d,
    U,
    N,
    y,
    b,
    P,
    $,
    jn,
    Ws,
    al,
    Lo,
    Do
  );
}
function rl(t, e) {
  let n = 0, s = 0, i = le(t.bands, tl);
  for (let r = 0; r < i.length; r++) {
    let o = i[r];
    o.series[0] == e ? n = o.dir : o.series[1] == e && (o.dir == 1 ? s |= 1 : s |= 2);
  }
  return [
    n,
    s == 1 ? -1 : (
      // neg only
      s == 2 ? 1 : (
        // pos only
        s == 3 ? 2 : (
          // both
          0
        )
      )
    )
  ];
}
function Pu(t, e, n, s, i) {
  let r = t.mode, o = t.series[e], u = r == 2 ? o.facets[1].scale : o.scale, h = t.scales[u];
  return i == -1 ? h.min : i == 1 ? h.max : h.distr == 3 ? h.dir == 1 ? h.min : h.max : 0;
}
function Lt(t, e, n, s, i, r) {
  return as(t, e, (o, u, h, p, g, d, b, y, $, P, N) => {
    let U = o.pxRound;
    const x = p.dir * (p.ori == 0 ? 1 : -1), z = p.ori == 0 ? Us : Ws;
    let E, J;
    x == 1 ? (E = n, J = s) : (E = s, J = n);
    let C = U(d(u[E], p, P, y)), Z = U(b(h[E], g, N, $)), j = U(d(u[J], p, P, y)), ee = U(b(r == 1 ? g.max : g.min, g, N, $)), K = new Path2D(i);
    return z(K, j, ee), z(K, C, ee), z(K, C, Z), K;
  });
}
function Bn(t, e, n, s, i, r) {
  let o = null;
  if (t.length > 0) {
    o = new Path2D();
    const u = e == 0 ? qn : al;
    let h = n;
    for (let d = 0; d < t.length; d++) {
      let b = t[d];
      if (b[1] > b[0]) {
        let y = b[0] - h;
        y > 0 && u(o, h, s, y, s + r), h = b[1];
      }
    }
    let p = n + i - h, g = 10;
    p > 0 && u(o, h, s - g / 2, p, s + r + g);
  }
  return o;
}
function Nu(t, e, n) {
  let s = t[t.length - 1];
  s && s[0] == e ? s[1] = n : t.push([e, n]);
}
function ol(t, e, n, s, i, r, o) {
  let u = [], h = t.length;
  for (let p = i == 1 ? n : s; p >= n && p <= s; p += i)
    if (e[p] === null) {
      let d = p, b = p;
      if (i == 1)
        for (; ++p <= s && e[p] === null; )
          b = p;
      else
        for (; --p >= n && e[p] === null; )
          b = p;
      let y = r(t[d]), $ = b == d ? y : r(t[b]), P = d - i;
      y = o <= 0 && P >= 0 && P < h ? r(t[P]) : y;
      let U = b + i;
      $ = o >= 0 && U >= 0 && U < h ? r(t[U]) : $, $ >= y && u.push([y, $]);
    }
  return u;
}
function Or(t) {
  return t == 0 ? oo : t == 1 ? Re : (e) => ts(e, t);
}
function Po(t) {
  let e = t == 0 ? Kn : jn, n = t == 0 ? (i, r, o, u, h, p) => {
    i.arcTo(r, o, u, h, p);
  } : (i, r, o, u, h, p) => {
    i.arcTo(o, r, h, u, p);
  }, s = t == 0 ? (i, r, o, u, h) => {
    i.rect(r, o, u, h);
  } : (i, r, o, u, h) => {
    i.rect(o, r, h, u);
  };
  return (i, r, o, u, h, p = 0, g = 0) => {
    p == 0 && g == 0 ? s(i, r, o, u, h) : (p = wt(p, u / 2, h / 2), g = wt(g, u / 2, h / 2), e(i, r + p, o), n(i, r + u, o, r + u, o + h, p), n(i, r + u, o + h, r, o + h, g), n(i, r, o + h, r, o, g), n(i, r, o, r + u, o, p), i.closePath());
  };
}
const Kn = (t, e, n) => {
  t.moveTo(e, n);
}, jn = (t, e, n) => {
  t.moveTo(n, e);
}, Us = (t, e, n) => {
  t.lineTo(e, n);
}, Ws = (t, e, n) => {
  t.lineTo(n, e);
}, qn = Po(0), al = Po(1), No = (t, e, n, s, i, r) => {
  t.arc(e, n, s, i, r);
}, Lo = (t, e, n, s, i, r) => {
  t.arc(n, e, s, i, r);
}, Oo = (t, e, n, s, i, r, o) => {
  t.bezierCurveTo(e, n, s, i, r, o);
}, Do = (t, e, n, s, i, r, o) => {
  t.bezierCurveTo(n, e, i, s, o, r);
};
function Fo(t) {
  return (e, n, s, i, r) => as(e, n, (o, u, h, p, g, d, b, y, $, P, N) => {
    let { pxRound: U, points: x } = o, z, E;
    p.ori == 0 ? (z = Kn, E = No) : (z = jn, E = Lo);
    const J = pe(x.width * oe, 3);
    let C = (x.size - x.width) / 2 * oe, Z = pe(C * 2, 3), j = new Path2D(), ee = new Path2D(), { left: K, top: A, width: Y, height: L } = e.bbox;
    qn(
      ee,
      K - Z,
      A - Z,
      Y + Z * 2,
      L + Z * 2
    );
    const V = (H) => {
      if (h[H] != null) {
        let se = U(d(u[H], p, P, y)), F = U(b(h[H], g, N, $));
        z(j, se + C, F), E(j, se, F, C, 0, Pn * 2);
      }
    };
    if (r)
      r.forEach(V);
    else
      for (let H = s; H <= i; H++)
        V(H);
    return {
      stroke: J > 0 ? j : null,
      fill: j,
      clip: ee,
      flags: zs | Di
    };
  });
}
function Ho(t) {
  return (e, n, s, i, r, o) => {
    s != i && (r != s && o != s && t(e, n, s), r != i && o != i && t(e, n, i), t(e, n, o));
  };
}
const Lu = Ho(Us), Ou = Ho(Ws);
function zo(t) {
  const e = le(t?.alignGaps, 0);
  return (n, s, i, r) => as(n, s, (o, u, h, p, g, d, b, y, $, P, N) => {
    [i, r] = Un(h, i, r);
    let U = o.pxRound, x = (L) => U(d(L, p, P, y)), z = (L) => U(b(L, g, N, $)), E, J;
    p.ori == 0 ? (E = Us, J = Lu) : (E = Ws, J = Ou);
    const C = p.dir * (p.ori == 0 ? 1 : -1), Z = { stroke: new Path2D(), fill: null, clip: null, band: null, gaps: null, flags: zs }, j = Z.stroke;
    let ee = !1;
    if (r - i >= P * 4) {
      let L = (O) => n.posToVal(O, p.key, !0), V = null, H = null, se, F, qe, _e = x(u[C == 1 ? i : r]), ne = x(u[i]), ue = x(u[r]), Q = L(C == 1 ? ne + 1 : ue - 1);
      for (let O = C == 1 ? i : r; O >= i && O <= r; O += C) {
        let ke = u[O], we = (C == 1 ? ke < Q : ke > Q) ? _e : x(ke), ae = h[O];
        we == _e ? ae != null ? (F = ae, V == null ? (E(j, we, z(F)), se = V = H = F) : F < V ? V = F : F > H && (H = F)) : ae === null && (ee = !0) : (V != null && J(j, _e, z(V), z(H), z(se), z(F)), ae != null ? (F = ae, E(j, we, z(F)), V = H = se = F) : (V = H = null, ae === null && (ee = !0)), _e = we, Q = L(_e + C));
      }
      V != null && V != H && qe != _e && J(j, _e, z(V), z(H), z(se), z(F));
    } else
      for (let L = C == 1 ? i : r; L >= i && L <= r; L += C) {
        let V = h[L];
        V === null ? ee = !0 : V != null && E(j, x(u[L]), z(V));
      }
    let [A, Y] = rl(n, s);
    if (o.fill != null || A != 0) {
      let L = Z.fill = new Path2D(j), V = o.fillTo(n, s, o.min, o.max, A), H = z(V), se = x(u[i]), F = x(u[r]);
      C == -1 && ([F, se] = [se, F]), E(L, F, H), E(L, se, H);
    }
    if (!o.spanGaps) {
      let L = [];
      ee && L.push(...ol(u, h, i, r, C, x, e)), Z.gaps = L = o.gaps(n, s, i, r, L), Z.clip = Bn(L, p.ori, y, $, P, N);
    }
    return Y != 0 && (Z.band = Y == 2 ? [
      Lt(n, s, i, r, j, -1),
      Lt(n, s, i, r, j, 1)
    ] : Lt(n, s, i, r, j, Y)), Z;
  });
}
function Du(t) {
  const e = le(t.align, 1), n = le(t.ascDesc, !1), s = le(t.alignGaps, 0), i = le(t.extend, !1);
  return (r, o, u, h) => as(r, o, (p, g, d, b, y, $, P, N, U, x, z) => {
    [u, h] = Un(d, u, h);
    let E = p.pxRound, { left: J, width: C } = r.bbox, Z = (ne) => E($(ne, b, x, N)), j = (ne) => E(P(ne, y, z, U)), ee = b.ori == 0 ? Us : Ws;
    const K = { stroke: new Path2D(), fill: null, clip: null, band: null, gaps: null, flags: zs }, A = K.stroke, Y = b.dir * (b.ori == 0 ? 1 : -1);
    let L = j(d[Y == 1 ? u : h]), V = Z(g[Y == 1 ? u : h]), H = V, se = V;
    i && e == -1 && (se = J, ee(A, se, L)), ee(A, V, L);
    for (let ne = Y == 1 ? u : h; ne >= u && ne <= h; ne += Y) {
      let ue = d[ne];
      if (ue == null)
        continue;
      let Q = Z(g[ne]), O = j(ue);
      e == 1 ? ee(A, Q, L) : ee(A, H, O), ee(A, Q, O), L = O, H = Q;
    }
    let F = H;
    i && e == 1 && (F = J + C, ee(A, F, L));
    let [qe, _e] = rl(r, o);
    if (p.fill != null || qe != 0) {
      let ne = K.fill = new Path2D(A), ue = p.fillTo(r, o, p.min, p.max, qe), Q = j(ue);
      ee(ne, F, Q), ee(ne, se, Q);
    }
    if (!p.spanGaps) {
      let ne = [];
      ne.push(...ol(g, d, u, h, Y, Z, s));
      let ue = p.width * oe / 2, Q = n || e == 1 ? ue : -ue, O = n || e == -1 ? -ue : ue;
      ne.forEach((ke) => {
        ke[0] += Q, ke[1] += O;
      }), K.gaps = ne = p.gaps(r, o, u, h, ne), K.clip = Bn(ne, b.ori, N, U, x, z);
    }
    return _e != 0 && (K.band = _e == 2 ? [
      Lt(r, o, u, h, A, -1),
      Lt(r, o, u, h, A, 1)
    ] : Lt(r, o, u, h, A, _e)), K;
  });
}
function Dr(t, e, n, s, i, r, o = fe) {
  if (t.length > 1) {
    let u = null;
    for (let h = 0, p = 1 / 0; h < t.length; h++)
      if (e[h] !== void 0) {
        if (u != null) {
          let g = Me(t[h] - t[u]);
          g < p && (p = g, o = Me(n(t[h], s, i, r) - n(t[u], s, i, r)));
        }
        u = h;
      }
  }
  return o;
}
function Fu(t) {
  t = t || cn;
  const e = le(t.size, [0.6, fe, 1]), n = t.align || 0, s = t.gap || 0;
  let i = t.radius;
  i = // [valueRadius, baselineRadius]
  i == null ? [0, 0] : typeof i == "number" ? [i, 0] : i;
  const r = te(i), o = 1 - e[0], u = le(e[1], fe), h = le(e[2], 1), p = le(t.disp, cn), g = le(t.each, (y) => {
  }), { fill: d, stroke: b } = p;
  return (y, $, P, N) => as(y, $, (U, x, z, E, J, C, Z, j, ee, K, A) => {
    let Y = U.pxRound, L = n, V = s * oe, H = u * oe, se = h * oe, F, qe;
    E.ori == 0 ? [F, qe] = r(y, $) : [qe, F] = r(y, $);
    const _e = E.dir * (E.ori == 0 ? 1 : -1);
    let ne = E.ori == 0 ? qn : al, ue = E.ori == 0 ? g : (R, de, Te, ps, Kt, St, jt) => {
      g(R, de, Te, Kt, ps, jt, St);
    }, Q = le(y.bands, tl).find((R) => R.series[0] == $), O = Q != null ? Q.dir : 0, ke = U.fillTo(y, $, U.min, U.max, O), We = Y(Z(ke, J, A, ee)), we, ae, pt, Ze = K, Se = Y(U.width * oe), yt = !1, Mt = null, lt = null, Ot = null, us = null;
    d != null && (Se == 0 || b != null) && (yt = !0, Mt = d.values(y, $, P, N), lt = /* @__PURE__ */ new Map(), new Set(Mt).forEach((R) => {
      R != null && lt.set(R, new Path2D());
    }), Se > 0 && (Ot = b.values(y, $, P, N), us = /* @__PURE__ */ new Map(), new Set(Ot).forEach((R) => {
      R != null && us.set(R, new Path2D());
    })));
    let { x0: hs, size: Vs } = p;
    if (hs != null && Vs != null) {
      L = 1, x = hs.values(y, $, P, N), hs.unit == 2 && (x = x.map((Te) => y.posToVal(j + Te * K, E.key, !0)));
      let R = Vs.values(y, $, P, N);
      Vs.unit == 2 ? ae = R[0] * K : ae = C(R[0], E, K, j) - C(0, E, K, j), Ze = Dr(x, z, C, E, K, j, Ze), pt = Ze - ae + V;
    } else
      Ze = Dr(x, z, C, E, K, j, Ze), pt = Ze * o + V, ae = Ze - pt;
    pt < 1 && (pt = 0), Se >= ae / 2 && (Se = 0), pt < 5 && (Y = oo);
    let vn = pt > 0, Gt = Ze - pt - (vn ? Se : 0);
    ae = Y(Ni(Gt, se, H)), we = (L == 0 ? ae / 2 : L == _e ? 0 : ae) - L * _e * ((L == 0 ? V / 2 : 0) + (vn ? Se / 2 : 0));
    const Ve = { stroke: null, fill: null, clip: null, band: null, gaps: null, flags: 0 }, fs = yt ? null : new Path2D();
    let Ct = null;
    if (Q != null)
      Ct = y.data[Q.series[1]];
    else {
      let { y0: R, y1: de } = p;
      R != null && de != null && (z = de.values(y, $, P, N), Ct = R.values(y, $, P, N));
    }
    let Bt = F * ae, q = qe * ae;
    for (let R = _e == 1 ? P : N; R >= P && R <= N; R += _e) {
      let de = z[R];
      if (de == null)
        continue;
      if (Ct != null) {
        let Ye = Ct[R] ?? 0;
        if (de - Ye == 0)
          continue;
        We = Z(Ye, J, A, ee);
      }
      let Te = E.distr != 2 || p != null ? x[R] : R, ps = C(Te, E, K, j), Kt = Z(le(de, ke), J, A, ee), St = Y(ps - we), jt = Y(je(Kt, We)), Qe = Y(wt(Kt, We)), rt = jt - Qe;
      if (de != null) {
        let Ye = de < 0 ? q : Bt, dt = de < 0 ? Bt : q;
        yt ? (Se > 0 && Ot[R] != null && ne(us.get(Ot[R]), St, Qe + nt(Se / 2), ae, je(0, rt - Se), Ye, dt), Mt[R] != null && ne(lt.get(Mt[R]), St, Qe + nt(Se / 2), ae, je(0, rt - Se), Ye, dt)) : ne(fs, St, Qe + nt(Se / 2), ae, je(0, rt - Se), Ye, dt), ue(
          y,
          $,
          R,
          St - Se / 2,
          Qe,
          ae + Se,
          rt
        );
      }
    }
    return Se > 0 ? Ve.stroke = yt ? us : fs : yt || (Ve._fill = U.width == 0 ? U._fill : U._stroke ?? U._fill, Ve.width = 0), Ve.fill = yt ? lt : fs, Ve;
  });
}
function Hu(t, e) {
  const n = le(e?.alignGaps, 0);
  return (s, i, r, o) => as(s, i, (u, h, p, g, d, b, y, $, P, N, U) => {
    [r, o] = Un(p, r, o);
    let x = u.pxRound, z = (F) => x(b(F, g, N, $)), E = (F) => x(y(F, d, U, P)), J, C, Z;
    g.ori == 0 ? (J = Kn, Z = Us, C = Oo) : (J = jn, Z = Ws, C = Do);
    const j = g.dir * (g.ori == 0 ? 1 : -1);
    let ee = z(h[j == 1 ? r : o]), K = ee, A = [], Y = [];
    for (let F = j == 1 ? r : o; F >= r && F <= o; F += j)
      if (p[F] != null) {
        let _e = h[F], ne = z(_e);
        A.push(K = ne), Y.push(E(p[F]));
      }
    const L = { stroke: t(A, Y, J, Z, C, x), fill: null, clip: null, band: null, gaps: null, flags: zs }, V = L.stroke;
    let [H, se] = rl(s, i);
    if (u.fill != null || H != 0) {
      let F = L.fill = new Path2D(V), qe = u.fillTo(s, i, u.min, u.max, H), _e = E(qe);
      Z(F, K, _e), Z(F, ee, _e);
    }
    if (!u.spanGaps) {
      let F = [];
      F.push(...ol(h, p, r, o, j, z, n)), L.gaps = F = u.gaps(s, i, r, o, F), L.clip = Bn(F, g.ori, $, P, N, U);
    }
    return se != 0 && (L.band = se == 2 ? [
      Lt(s, i, r, o, V, -1),
      Lt(s, i, r, o, V, 1)
    ] : Lt(s, i, r, o, V, se)), L;
  });
}
function zu(t) {
  return Hu(Iu, t);
}
function Iu(t, e, n, s, i, r) {
  const o = t.length;
  if (o < 2)
    return null;
  const u = new Path2D();
  if (n(u, t[0], e[0]), o == 2)
    s(u, t[1], e[1]);
  else {
    let h = Array(o), p = Array(o - 1), g = Array(o - 1), d = Array(o - 1);
    for (let b = 0; b < o - 1; b++)
      g[b] = e[b + 1] - e[b], d[b] = t[b + 1] - t[b], p[b] = g[b] / d[b];
    h[0] = p[0];
    for (let b = 1; b < o - 1; b++)
      p[b] === 0 || p[b - 1] === 0 || p[b - 1] > 0 != p[b] > 0 ? h[b] = 0 : (h[b] = 3 * (d[b - 1] + d[b]) / ((2 * d[b] + d[b - 1]) / p[b - 1] + (d[b] + 2 * d[b - 1]) / p[b]), isFinite(h[b]) || (h[b] = 0));
    h[o - 1] = p[o - 2];
    for (let b = 0; b < o - 1; b++)
      i(
        u,
        t[b] + d[b] / 3,
        e[b] + h[b] * d[b] / 3,
        t[b + 1] - d[b] / 3,
        e[b + 1] - h[b + 1] * d[b] / 3,
        t[b + 1],
        e[b + 1]
      );
  }
  return u;
}
const Fi = /* @__PURE__ */ new Set();
function Fr() {
  for (let t of Fi)
    t.syncRect(!0);
}
Is && (ls(wc, Ns, Fr), ls(yc, Ns, Fr, !0), ls(On, Ns, () => {
  Ue.pxRatio = oe;
}));
const Uu = zo(), Wu = Fo();
function Hr(t, e, n, s) {
  return (s ? [t[0], t[1]].concat(t.slice(2)) : [t[0]].concat(t.slice(1))).map((r, o) => Hi(r, o, e, n));
}
function Vu(t, e) {
  return t.map((n, s) => s == 0 ? {} : Ae({}, e, n));
}
function Hi(t, e, n, s) {
  return Ae({}, e == 0 ? n : s, t);
}
function Io(t, e, n) {
  return e == null ? Fs : [e, n];
}
const Gu = Io;
function Bu(t, e, n) {
  return e == null ? Fs : Dn(e, n, Xi, !0);
}
function Uo(t, e, n, s) {
  return e == null ? Fs : Wn(e, n, t.scales[s].log, !1);
}
const Ku = Uo;
function Wo(t, e, n, s) {
  return e == null ? Fs : Qi(e, n, t.scales[s].log, !1);
}
const ju = Wo;
function qu(t, e, n, s, i) {
  let r = je(gr(t), gr(e)), o = e - t, u = _t(i / s * o, n);
  do {
    let h = n[u], p = s * h / o;
    if (p >= i && r + (h < 5 ? Vt.get(h) : 0) <= 17)
      return [h, p];
  } while (++u < n.length);
  return [0, 0];
}
function zr(t) {
  let e, n;
  return t = t.replace(/(\d+)px/, (s, i) => (e = Re((n = +i) * oe)) + "px"), [t, e, n];
}
function Yu(t) {
  t.show && [t.font, t.labelFont].forEach((e) => {
    let n = pe(e[2] * oe, 1);
    e[0] = e[0].replace(/[0-9.]+px/, n + "px"), e[1] = n;
  });
}
function Ue(t, e, n) {
  const s = {
    mode: le(t.mode, 1)
  }, i = s.mode;
  function r(l, a, c, f) {
    let m = a.valToPct(l);
    return f + c * (a.dir == -1 ? 1 - m : m);
  }
  function o(l, a, c, f) {
    let m = a.valToPct(l);
    return f + c * (a.dir == -1 ? m : 1 - m);
  }
  function u(l, a, c, f) {
    return a.ori == 0 ? r(l, a, c, f) : o(l, a, c, f);
  }
  s.valToPosH = r, s.valToPosV = o;
  let h = !1;
  s.status = 0;
  const p = s.root = ht(sc);
  if (t.id != null && (p.id = t.id), st(p, t.class), t.title) {
    let l = ht(lc, p);
    l.textContent = t.title;
  }
  const g = bt("canvas"), d = s.ctx = g.getContext("2d"), b = ht(rc, p);
  ls("click", b, (l) => {
    l.target === $ && (me != $s || ye != Es) && ze.click(s, l);
  }, !0);
  const y = s.under = ht(oc, b);
  b.appendChild(g);
  const $ = s.over = ht(ac, b);
  t = Hs(t);
  const P = +le(t.pxAlign, 1), N = Or(P);
  (t.plugins || []).forEach((l) => {
    l.opts && (t = l.opts(s, t) || t);
  });
  const U = t.ms || 1e-3, x = s.series = i == 1 ? Hr(t.series || [], Tr, Nr, !1) : Vu(t.series || [null], Pr), z = s.axes = Hr(t.axes || [], kr, Mr, !0), E = s.scales = {}, J = s.bands = t.bands || [];
  J.forEach((l) => {
    l.fill = te(l.fill || null), l.dir = le(l.dir, -1);
  });
  const C = i == 2 ? x[1].facets[0].scale : x[0].scale, Z = {
    axes: da,
    series: ca
  }, j = (t.drawOrder || ["axes", "series"]).map((l) => Z[l]);
  function ee(l) {
    const a = l.distr == 3 ? (c) => Nt(c > 0 ? c : l.clamp(s, c, l.min, l.max, l.key)) : l.distr == 4 ? (c) => Si(c, l.asinh) : l.distr == 100 ? (c) => l.fwd(c) : (c) => c;
    return (c) => {
      let f = a(c), { _min: m, _max: v } = l, _ = v - m;
      return (f - m) / _;
    };
  }
  function K(l) {
    let a = E[l];
    if (a == null) {
      let c = (t.scales || cn)[l] || cn;
      if (c.from != null) {
        K(c.from);
        let f = Ae({}, E[c.from], c, { key: l });
        f.valToPct = ee(f), E[l] = f;
      } else {
        a = E[l] = Ae({}, l == C ? Mo : Cu, c), a.key = l;
        let f = a.time, m = a.range, v = Ut(m);
        if ((l != C || i == 2 && !f) && (v && (m[0] == null || m[1] == null) && (m = {
          min: m[0] == null ? pr : {
            mode: 1,
            hard: m[0],
            soft: m[0]
          },
          max: m[1] == null ? pr : {
            mode: 1,
            hard: m[1],
            soft: m[1]
          }
        }, v = !1), !v && Gn(m))) {
          let _ = m;
          m = (w, S, k) => S == null ? Fs : Dn(S, k, _);
        }
        a.range = te(m || (f ? Gu : l == C ? a.distr == 3 ? Ku : a.distr == 4 ? ju : Io : a.distr == 3 ? Uo : a.distr == 4 ? Wo : Bu)), a.auto = te(v ? !1 : a.auto), a.clamp = te(a.clamp || Mu), a._min = a._max = null, a.valToPct = ee(a);
      }
    }
  }
  K("x"), K("y"), i == 1 && x.forEach((l) => {
    K(l.scale);
  }), z.forEach((l) => {
    K(l.scale);
  });
  for (let l in t.scales)
    K(l);
  const A = E[C], Y = A.distr;
  let L, V;
  A.ori == 0 ? (st(p, nc), L = r, V = o) : (st(p, ic), L = o, V = r);
  const H = {};
  for (let l in E) {
    let a = E[l];
    (a.min != null || a.max != null) && (H[l] = { min: a.min, max: a.max }, a.min = a.max = null);
  }
  const se = t.tzDate || ((l) => new Date(Re(l / U))), F = t.fmtDate || sl, qe = U == 1 ? nu(se) : ru(se), _e = $r(se, xr(U == 1 ? su : lu, F)), ne = Ar(se, Er(au, F)), ue = [], Q = s.legend = Ae({}, hu, t.legend), O = s.cursor = Ae({}, vu, { drag: { y: i == 2 } }, t.cursor), ke = Q.show, We = O.show, we = Q.markers;
  Q.idxs = ue, we.width = te(we.width), we.dash = te(we.dash), we.stroke = te(we.stroke), we.fill = te(we.fill);
  let ae, pt, Ze, Se = [], yt = [], Mt, lt = !1, Ot = {};
  if (Q.live) {
    const l = x[1] ? x[1].values : null;
    lt = l != null, Mt = lt ? l(s, 1, 0) : { _: 0 };
    for (let a in Mt)
      Ot[a] = Ji;
  }
  if (ke)
    if (ae = bt("table", dc, p), Ze = bt("tbody", null, ae), Q.mount(s, ae), lt) {
      pt = bt("thead", null, ae, Ze);
      let l = bt("tr", null, pt);
      bt("th", null, l);
      for (var us in Mt)
        bt("th", er, l).textContent = us;
    } else
      st(ae, gc), Q.live && st(ae, mc);
  const hs = { show: !0 }, Vs = { show: !1 };
  function vn(l, a) {
    if (a == 0 && (lt || !Q.live || i == 2))
      return Fs;
    let c = [], f = bt("tr", vc, Ze, Ze.childNodes[a]);
    st(f, l.class), l.show || st(f, ns);
    let m = bt("th", null, f);
    if (we.show) {
      let w = ht(bc, m);
      if (a > 0) {
        let S = we.width(s, a);
        S && (w.style.border = S + "px " + we.dash(s, a) + " " + we.stroke(s, a)), w.style.background = we.fill(s, a);
      }
    }
    let v = ht(er, m);
    l.label instanceof HTMLElement ? v.appendChild(l.label) : v.textContent = l.label, a > 0 && (we.show || (v.style.color = l.width > 0 ? we.stroke(s, a) : we.fill(s, a)), Ve("click", m, (w) => {
      if (O._lock)
        return;
      Yt(w);
      let S = x.indexOf(l);
      if ((w.ctrlKey || w.metaKey) != Q.isolate) {
        let k = x.some((T, M) => M > 0 && M != S && T.show);
        x.forEach((T, M) => {
          M > 0 && $t(M, k ? M == S ? hs : Vs : hs, !0, Ee.setSeries);
        });
      } else
        $t(S, { show: !l.show }, !0, Ee.setSeries);
    }, !1), ms && Ve(ir, m, (w) => {
      O._lock || (Yt(w), $t(x.indexOf(l), ks, !0, Ee.setSeries));
    }, !1));
    for (var _ in Mt) {
      let w = bt("td", _c, f);
      w.textContent = "--", c.push(w);
    }
    return [f, c];
  }
  const Gt = /* @__PURE__ */ new Map();
  function Ve(l, a, c, f = !0) {
    const m = Gt.get(a) || {}, v = O.bind[l](s, a, c, f);
    v && (ls(l, a, m[l] = v), Gt.set(a, m));
  }
  function fs(l, a, c) {
    const f = Gt.get(a) || {};
    for (let m in f)
      (l == null || m == l) && (Pi(m, a, f[m]), delete f[m]);
    l == null && Gt.delete(a);
  }
  let Ct = 0, Bt = 0, q = 0, R = 0, de = 0, Te = 0, ps = de, Kt = Te, St = q, jt = R, Qe = 0, rt = 0, Ye = 0, dt = 0;
  s.bbox = {};
  let Yn = !1, bn = !1, ds = !1, qt = !1, _n = !1, ot = !1;
  function Jn(l, a, c) {
    (c || l != s.width || a != s.height) && pl(l, a), ws(!1), ds = !0, bn = !0, ys();
  }
  function pl(l, a) {
    s.width = Ct = q = l, s.height = Bt = R = a, de = Te = 0, sa(), na();
    let c = s.bbox;
    Qe = c.left = ts(de * oe, 0.5), rt = c.top = ts(Te * oe, 0.5), Ye = c.width = ts(q * oe, 0.5), dt = c.height = ts(R * oe, 0.5);
  }
  const Xo = 3;
  function ea() {
    let l = !1, a = 0;
    for (; !l; ) {
      a++;
      let c = fa(a), f = pa(a);
      l = a == Xo || c && f, l || (pl(s.width, s.height), bn = !0);
    }
  }
  function ta({ width: l, height: a }) {
    Jn(l, a);
  }
  s.setSize = ta;
  function sa() {
    let l = !1, a = !1, c = !1, f = !1;
    z.forEach((m, v) => {
      if (m.show && m._show) {
        let { side: _, _size: w } = m, S = _ % 2, k = m.label != null ? m.labelSize : 0, T = w + k;
        T > 0 && (S ? (q -= T, _ == 3 ? (de += T, f = !0) : c = !0) : (R -= T, _ == 0 ? (Te += T, l = !0) : a = !0));
      }
    }), Jt[0] = l, Jt[1] = c, Jt[2] = a, Jt[3] = f, q -= Dt[1] + Dt[3], de += Dt[3], R -= Dt[2] + Dt[0], Te += Dt[0];
  }
  function na() {
    let l = de + q, a = Te + R, c = de, f = Te;
    function m(v, _) {
      switch (v) {
        case 1:
          return l += _, l - _;
        case 2:
          return a += _, a - _;
        case 3:
          return c -= _, c + _;
        case 0:
          return f -= _, f + _;
      }
    }
    z.forEach((v, _) => {
      if (v.show && v._show) {
        let w = v.side;
        v._pos = m(w, v._size), v.label != null && (v._lpos = m(w, v.labelSize));
      }
    });
  }
  if (O.dataIdx == null) {
    let l = O.hover, a = l.skip = new Set(l.skip ?? []);
    a.add(void 0);
    let c = l.prox = te(l.prox), f = l.bias ??= 0;
    O.dataIdx = (m, v, _, w) => {
      if (v == 0)
        return _;
      let S = _, k = c(m, v, _, w) ?? fe, T = k >= 0 && k < fe, M = A.ori == 0 ? q : R, G = O.left, re = e[0], ie = e[v];
      if (a.has(ie[_])) {
        S = null;
        let X = null, W = null, D;
        if (f == 0 || f == -1)
          for (D = _; X == null && D-- > 0; )
            a.has(ie[D]) || (X = D);
        if (f == 0 || f == 1)
          for (D = _; W == null && D++ < ie.length; )
            a.has(ie[D]) || (W = D);
        if (X != null || W != null)
          if (T) {
            let ve = X == null ? -1 / 0 : L(re[X], A, M, 0), xe = W == null ? 1 / 0 : L(re[W], A, M, 0), Fe = G - ve, he = xe - G;
            Fe <= he ? Fe <= k && (S = X) : he <= k && (S = W);
          } else
            S = W == null ? X : X == null ? W : _ - X <= W - _ ? X : W;
      } else T && Me(G - L(re[_], A, M, 0)) > k && (S = null);
      return S;
    };
  }
  const Yt = (l) => {
    O.event = l;
  };
  O.idxs = ue, O._lock = !1;
  let Ie = O.points;
  Ie.show = te(Ie.show), Ie.size = te(Ie.size), Ie.stroke = te(Ie.stroke), Ie.width = te(Ie.width), Ie.fill = te(Ie.fill);
  const xt = s.focus = Ae({}, t.focus || { alpha: 0.3 }, O.focus), ms = xt.prox >= 0, gs = ms && Ie.one;
  let at = [], vs = [], bs = [];
  function dl(l, a) {
    let c = Ie.show(s, a);
    if (c instanceof HTMLElement)
      return st(c, pc), st(c, l.class), Tt(c, -10, -10, q, R), $.insertBefore(c, at[a]), c;
  }
  function ml(l, a) {
    if (i == 1 || a > 0) {
      let c = i == 1 && E[l.scale].time, f = l.value;
      l.value = c ? _r(f) ? Ar(se, Er(f, F)) : f || ne : f || ku, l.label = l.label || (c ? _u : bu);
    }
    if (gs || a > 0) {
      l.width = l.width == null ? 1 : l.width, l.paths = l.paths || Uu || Cc, l.fillTo = te(l.fillTo || Pu), l.pxAlign = +le(l.pxAlign, P), l.pxRound = Or(l.pxAlign), l.stroke = te(l.stroke || null), l.fill = te(l.fill || null), l._stroke = l._fill = l._paths = l._focus = null;
      let c = Tu(je(1, l.width), 1), f = l.points = Ae({}, {
        size: c,
        width: je(1, c * 0.2),
        stroke: l.stroke,
        space: c * 2,
        paths: Wu,
        _stroke: null,
        _fill: null
      }, l.points);
      f.show = te(f.show), f.filter = te(f.filter), f.fill = te(f.fill), f.stroke = te(f.stroke), f.paths = te(f.paths), f.pxAlign = l.pxAlign;
    }
    if (ke) {
      let c = vn(l, a);
      Se.splice(a, 0, c[0]), yt.splice(a, 0, c[1]), Q.values.push(null);
    }
    if (We) {
      ue.splice(a, 0, null);
      let c = null;
      gs ? a == 0 && (c = dl(l, a)) : a > 0 && (c = dl(l, a)), at.splice(a, 0, c), vs.splice(a, 0, 0), bs.splice(a, 0, 0);
    }
    De("addSeries", a);
  }
  function ia(l, a) {
    a = a ?? x.length, l = i == 1 ? Hi(l, a, Tr, Nr) : Hi(l, a, {}, Pr), x.splice(a, 0, l), ml(x[a], a);
  }
  s.addSeries = ia;
  function la(l) {
    if (x.splice(l, 1), ke) {
      Q.values.splice(l, 1), yt.splice(l, 1);
      let a = Se.splice(l, 1)[0];
      fs(null, a.firstChild), a.remove();
    }
    We && (ue.splice(l, 1), at.splice(l, 1)[0].remove(), vs.splice(l, 1), bs.splice(l, 1)), De("delSeries", l);
  }
  s.delSeries = la;
  const Jt = [!1, !1, !1, !1];
  function ra(l, a) {
    if (l._show = l.show, l.show) {
      let c = l.side % 2, f = E[l.scale];
      f == null && (l.scale = c ? x[1].scale : C, f = E[l.scale]);
      let m = f.time;
      l.size = te(l.size), l.space = te(l.space), l.rotate = te(l.rotate), Ut(l.incrs) && l.incrs.forEach((_) => {
        !Vt.has(_) && Vt.set(_, uo(_));
      }), l.incrs = te(l.incrs || (f.distr == 2 ? Xc : m ? U == 1 ? tu : iu : ss)), l.splits = te(l.splits || (m && f.distr == 1 ? qe : f.distr == 3 ? Li : f.distr == 4 ? Su : yu)), l.stroke = te(l.stroke), l.grid.stroke = te(l.grid.stroke), l.ticks.stroke = te(l.ticks.stroke), l.border.stroke = te(l.border.stroke);
      let v = l.values;
      l.values = // static array of tick values
      Ut(v) && !Ut(v[0]) ? te(v) : (
        // temporal
        m ? (
          // config array of fmtDate string tpls
          Ut(v) ? $r(se, xr(v, F)) : (
            // fmtDate string tpl
            _r(v) ? ou(se, v) : v || _e
          )
        ) : v || wu
      ), l.filter = te(l.filter || (f.distr >= 3 && f.log == 10 ? Eu : f.distr == 3 && f.log == 2 ? Au : ao)), l.font = zr(l.font), l.labelFont = zr(l.labelFont), l._size = l.size(s, null, a, 0), l._space = l._rotate = l._incrs = l._found = // foundIncrSpace
      l._splits = l._values = null, l._size > 0 && (Jt[a] = !0, l._el = ht(cc, b));
    }
  }
  function Gs(l, a, c, f) {
    let [m, v, _, w] = c, S = a % 2, k = 0;
    return S == 0 && (w || v) && (k = a == 0 && !m || a == 2 && !_ ? Re(kr.size / 3) : 0), S == 1 && (m || _) && (k = a == 1 && !v || a == 3 && !w ? Re(Mr.size / 2) : 0), k;
  }
  const gl = s.padding = (t.padding || [Gs, Gs, Gs, Gs]).map((l) => te(le(l, Gs))), Dt = s._padding = gl.map((l, a) => l(s, a, Jt, 0));
  let He, Pe = null, Ne = null;
  const wn = i == 1 ? x[0].idxs : null;
  let mt = null, Bs = !1;
  function vl(l, a) {
    if (e = l ?? [], s.data = s._data = e, i == 2) {
      He = 0;
      for (let c = 1; c < x.length; c++)
        He += e[c][0].length;
    } else {
      e.length == 0 && (s.data = s._data = e = [[]]), mt = e[0], He = mt.length;
      let c = e;
      if (Y == 2) {
        c = e.slice();
        let f = c[0] = Array(He);
        for (let m = 0; m < He; m++)
          f[m] = m;
      }
      s._data = e = c;
    }
    if (ws(!0), De("setData"), Y == 2 && (ds = !0), a !== !1) {
      let c = A;
      c.auto(s, Bs) ? Zn() : Ht(C, c.min, c.max), qt = qt || O.left >= 0, ot = !0, ys();
    }
  }
  s.setData = vl;
  function Zn() {
    Bs = !0;
    let l, a;
    i == 1 && (He > 0 ? (Pe = wn[0] = 0, Ne = wn[1] = He - 1, l = e[0][Pe], a = e[0][Ne], Y == 2 ? (l = Pe, a = Ne) : l == a && (Y == 3 ? [l, a] = Wn(l, l, A.log, !1) : Y == 4 ? [l, a] = Qi(l, l, A.log, !1) : A.time ? a = l + Re(86400 / U) : [l, a] = Dn(l, a, Xi, !0))) : (Pe = wn[0] = l = null, Ne = wn[1] = a = null)), Ht(C, l, a);
  }
  let yn, _s, Qn, Xn, ei, ti, si, ni, ii, Je;
  function bl(l, a, c, f, m, v) {
    l ??= sr, c ??= tl, f ??= "butt", m ??= sr, v ??= "round", l != yn && (d.strokeStyle = yn = l), m != _s && (d.fillStyle = _s = m), a != Qn && (d.lineWidth = Qn = a), v != ei && (d.lineJoin = ei = v), f != ti && (d.lineCap = ti = f), c != Xn && d.setLineDash(Xn = c);
  }
  function _l(l, a, c, f) {
    a != _s && (d.fillStyle = _s = a), l != si && (d.font = si = l), c != ni && (d.textAlign = ni = c), f != ii && (d.textBaseline = ii = f);
  }
  function li(l, a, c, f, m = 0) {
    if (f.length > 0 && l.auto(s, Bs) && (a == null || a.min == null)) {
      let v = le(Pe, 0), _ = le(Ne, f.length - 1), w = c.min == null ? Ec(f, v, _, m, l.distr == 3) : [c.min, c.max];
      l.min = wt(l.min, c.min = w[0]), l.max = je(l.max, c.max = w[1]);
    }
  }
  const wl = { min: null, max: null };
  function oa() {
    for (let f in E) {
      let m = E[f];
      H[f] == null && // scales that have never been set (on init)
      (m.min == null || // or auto scales when the x scale was explicitly set
      H[C] != null && m.auto(s, Bs)) && (H[f] = wl);
    }
    for (let f in E) {
      let m = E[f];
      H[f] == null && m.from != null && H[m.from] != null && (H[f] = wl);
    }
    H[C] != null && ws(!0);
    let l = {};
    for (let f in H) {
      let m = H[f];
      if (m != null) {
        let v = l[f] = Hs(E[f], Lc);
        if (m.min != null)
          Ae(v, m);
        else if (f != C || i == 2)
          if (He == 0 && v.from == null) {
            let _ = v.range(s, null, null, f);
            v.min = _[0], v.max = _[1];
          } else
            v.min = fe, v.max = -fe;
      }
    }
    if (He > 0) {
      x.forEach((f, m) => {
        if (i == 1) {
          let v = f.scale, _ = H[v];
          if (_ == null)
            return;
          let w = l[v];
          if (m == 0) {
            let S = w.range(s, w.min, w.max, v);
            w.min = S[0], w.max = S[1], Pe = _t(w.min, e[0]), Ne = _t(w.max, e[0]), Ne - Pe > 1 && (e[0][Pe] < w.min && Pe++, e[0][Ne] > w.max && Ne--), f.min = mt[Pe], f.max = mt[Ne];
          } else f.show && f.auto && li(w, _, f, e[m], f.sorted);
          f.idxs[0] = Pe, f.idxs[1] = Ne;
        } else if (m > 0 && f.show && f.auto) {
          let [v, _] = f.facets, w = v.scale, S = _.scale, [k, T] = e[m], M = l[w], G = l[S];
          M != null && li(M, H[w], v, k, v.sorted), G != null && li(G, H[S], _, T, _.sorted), f.min = _.min, f.max = _.max;
        }
      });
      for (let f in l) {
        let m = l[f], v = H[f];
        if (m.from == null && (v == null || v.min == null)) {
          let _ = m.range(
            s,
            m.min == fe ? null : m.min,
            m.max == -fe ? null : m.max,
            f
          );
          m.min = _[0], m.max = _[1];
        }
      }
    }
    for (let f in l) {
      let m = l[f];
      if (m.from != null) {
        let v = l[m.from];
        if (v.min == null)
          m.min = m.max = null;
        else {
          let _ = m.range(s, v.min, v.max, f);
          m.min = _[0], m.max = _[1];
        }
      }
    }
    let a = {}, c = !1;
    for (let f in l) {
      let m = l[f], v = E[f];
      if (v.min != m.min || v.max != m.max) {
        v.min = m.min, v.max = m.max;
        let _ = v.distr;
        v._min = _ == 3 ? Nt(v.min) : _ == 4 ? Si(v.min, v.asinh) : _ == 100 ? v.fwd(v.min) : v.min, v._max = _ == 3 ? Nt(v.max) : _ == 4 ? Si(v.max, v.asinh) : _ == 100 ? v.fwd(v.max) : v.max, a[f] = c = !0;
      }
    }
    if (c) {
      x.forEach((f, m) => {
        i == 2 ? m > 0 && a.y && (f._paths = null) : a[f.scale] && (f._paths = null);
      });
      for (let f in a)
        ds = !0, De("setScale", f);
      We && O.left >= 0 && (qt = ot = !0);
    }
    for (let f in H)
      H[f] = null;
  }
  function aa(l) {
    let a = Ni(Pe - 1, 0, He - 1), c = Ni(Ne + 1, 0, He - 1);
    for (; l[a] == null && a > 0; )
      a--;
    for (; l[c] == null && c < He - 1; )
      c++;
    return [a, c];
  }
  function ca() {
    if (He > 0) {
      let l = x.some((a) => a._focus) && Je != xt.alpha;
      l && (d.globalAlpha = Je = xt.alpha), x.forEach((a, c) => {
        if (c > 0 && a.show && (yl(c, !1), yl(c, !0), a._paths == null)) {
          let f = Je;
          Je != a.alpha && (d.globalAlpha = Je = a.alpha);
          let m = i == 2 ? [0, e[c][0].length - 1] : aa(e[c]);
          a._paths = a.paths(s, c, m[0], m[1]), Je != f && (d.globalAlpha = Je = f);
        }
      }), x.forEach((a, c) => {
        if (c > 0 && a.show) {
          let f = Je;
          Je != a.alpha && (d.globalAlpha = Je = a.alpha), a._paths != null && Sl(c, !1);
          {
            let m = a._paths != null ? a._paths.gaps : null, v = a.points.show(s, c, Pe, Ne, m), _ = a.points.filter(s, c, v, m);
            (v || _) && (a.points._paths = a.points.paths(s, c, Pe, Ne, _), Sl(c, !0));
          }
          Je != f && (d.globalAlpha = Je = f), De("drawSeries", c);
        }
      }), l && (d.globalAlpha = Je = 1);
    }
  }
  function yl(l, a) {
    let c = a ? x[l].points : x[l];
    c._stroke = c.stroke(s, l), c._fill = c.fill(s, l);
  }
  function Sl(l, a) {
    let c = a ? x[l].points : x[l], {
      stroke: f,
      fill: m,
      clip: v,
      flags: _,
      _stroke: w = c._stroke,
      _fill: S = c._fill,
      _width: k = c.width
    } = c._paths;
    k = pe(k * oe, 3);
    let T = null, M = k % 2 / 2;
    a && S == null && (S = k > 0 ? "#fff" : w);
    let G = c.pxAlign == 1 && M > 0;
    if (G && d.translate(M, M), !a) {
      let re = Qe - k / 2, ie = rt - k / 2, X = Ye + k, W = dt + k;
      T = new Path2D(), T.rect(re, ie, X, W);
    }
    a ? ri(w, k, c.dash, c.cap, S, f, m, _, v) : ua(l, w, k, c.dash, c.cap, S, f, m, _, T, v), G && d.translate(-M, -M);
  }
  function ua(l, a, c, f, m, v, _, w, S, k, T) {
    let M = !1;
    S != 0 && J.forEach((G, re) => {
      if (G.series[0] == l) {
        let ie = x[G.series[1]], X = e[G.series[1]], W = (ie._paths || cn).band;
        Ut(W) && (W = G.dir == 1 ? W[0] : W[1]);
        let D, ve = null;
        ie.show && W && kc(X, Pe, Ne) ? (ve = G.fill(s, re) || v, D = ie._paths.clip) : W = null, ri(a, c, f, m, ve, _, w, S, k, T, D, W), M = !0;
      }
    }), M || ri(a, c, f, m, v, _, w, S, k, T);
  }
  const xl = zs | Di;
  function ri(l, a, c, f, m, v, _, w, S, k, T, M) {
    bl(l, a, c, f, m), (S || k || M) && (d.save(), S && d.clip(S), k && d.clip(k)), M ? (w & xl) == xl ? (d.clip(M), T && d.clip(T), xn(m, _), Sn(l, v, a)) : w & Di ? (xn(m, _), d.clip(M), Sn(l, v, a)) : w & zs && (d.save(), d.clip(M), T && d.clip(T), xn(m, _), d.restore(), Sn(l, v, a)) : (xn(m, _), Sn(l, v, a)), (S || k || M) && d.restore();
  }
  function Sn(l, a, c) {
    c > 0 && (a instanceof Map ? a.forEach((f, m) => {
      d.strokeStyle = yn = m, d.stroke(f);
    }) : a != null && l && d.stroke(a));
  }
  function xn(l, a) {
    a instanceof Map ? a.forEach((c, f) => {
      d.fillStyle = _s = f, d.fill(c);
    }) : a != null && l && d.fill(a);
  }
  function ha(l, a, c, f) {
    let m = z[l], v;
    if (f <= 0)
      v = [0, 0];
    else {
      let _ = m._space = m.space(s, l, a, c, f), w = m._incrs = m.incrs(s, l, a, c, f, _);
      v = qu(a, c, w, f, _);
    }
    return m._found = v;
  }
  function oi(l, a, c, f, m, v, _, w, S, k) {
    let T = _ % 2 / 2;
    P == 1 && d.translate(T, T), bl(w, _, S, k, w), d.beginPath();
    let M, G, re, ie, X = m + (f == 0 || f == 3 ? -v : v);
    c == 0 ? (G = m, ie = X) : (M = m, re = X);
    for (let W = 0; W < l.length; W++)
      a[W] != null && (c == 0 ? M = re = l[W] : G = ie = l[W], d.moveTo(M, G), d.lineTo(re, ie));
    d.stroke(), P == 1 && d.translate(-T, -T);
  }
  function fa(l) {
    let a = !0;
    return z.forEach((c, f) => {
      if (!c.show)
        return;
      let m = E[c.scale];
      if (m.min == null) {
        c._show && (a = !1, c._show = !1, ws(!1));
        return;
      } else
        c._show || (a = !1, c._show = !0, ws(!1));
      let v = c.side, _ = v % 2, { min: w, max: S } = m, [k, T] = ha(f, w, S, _ == 0 ? q : R);
      if (T == 0)
        return;
      let M = m.distr == 2, G = c._splits = c.splits(s, f, w, S, k, T, M), re = m.distr == 2 ? G.map((D) => mt[D]) : G, ie = m.distr == 2 ? mt[G[1]] - mt[G[0]] : k, X = c._values = c.values(s, c.filter(s, re, f, T, ie), f, T, ie);
      c._rotate = v == 2 ? c.rotate(s, X, f, T) : 0;
      let W = c._size;
      c._size = ft(c.size(s, X, f, l)), W != null && c._size != W && (a = !1);
    }), a;
  }
  function pa(l) {
    let a = !0;
    return gl.forEach((c, f) => {
      let m = c(s, f, Jt, l);
      m != Dt[f] && (a = !1), Dt[f] = m;
    }), a;
  }
  function da() {
    for (let l = 0; l < z.length; l++) {
      let a = z[l];
      if (!a.show || !a._show)
        continue;
      let c = a.side, f = c % 2, m, v, _ = a.stroke(s, l), w = c == 0 || c == 3 ? -1 : 1, [S, k] = a._found;
      if (a.label != null) {
        let Be = a.labelGap * w, tt = Re((a._lpos + Be) * oe);
        _l(a.labelFont[0], _, "center", c == 2 ? Qs : tr), d.save(), f == 1 ? (m = v = 0, d.translate(
          tt,
          Re(rt + dt / 2)
        ), d.rotate((c == 3 ? -Pn : Pn) / 2)) : (m = Re(Qe + Ye / 2), v = tt);
        let Xt = ro(a.label) ? a.label(s, l, S, k) : a.label;
        d.fillText(Xt, m, v), d.restore();
      }
      if (k == 0)
        continue;
      let T = E[a.scale], M = f == 0 ? Ye : dt, G = f == 0 ? Qe : rt, re = a._splits, ie = T.distr == 2 ? re.map((Be) => mt[Be]) : re, X = T.distr == 2 ? mt[re[1]] - mt[re[0]] : S, W = a.ticks, D = a.border, ve = W.show ? W.size : 0, xe = Re(ve * oe), Fe = Re((a.alignTo == 2 ? a._size - ve - a.gap : a.gap) * oe), he = a._rotate * -Pn / 180, $e = N(a._pos * oe), Xe = (xe + Fe) * w, Ge = $e + Xe;
      v = f == 0 ? Ge : 0, m = f == 1 ? Ge : 0;
      let ct = a.font[0], gt = a.align == 1 ? Rs : a.align == 2 ? _i : he > 0 ? Rs : he < 0 ? _i : f == 0 ? "center" : c == 3 ? _i : Rs, At = he || f == 1 ? "middle" : c == 2 ? Qs : tr;
      _l(ct, _, gt, At);
      let et = a.font[1] * a.lineGap, ut = re.map((Be) => N(u(Be, T, M, G))), vt = a._values;
      for (let Be = 0; Be < vt.length; Be++) {
        let tt = vt[Be];
        if (tt != null) {
          f == 0 ? m = ut[Be] : v = ut[Be], tt = "" + tt;
          let Xt = tt.indexOf(`
`) == -1 ? [tt] : tt.split(/\n/gm);
          for (let Ke = 0; Ke < Xt.length; Ke++) {
            let Wl = Xt[Ke];
            he ? (d.save(), d.translate(m, v + Ke * et), d.rotate(he), d.fillText(Wl, 0, 0), d.restore()) : d.fillText(Wl, m, v + Ke * et);
          }
        }
      }
      W.show && oi(
        ut,
        W.filter(s, ie, l, k, X),
        f,
        c,
        $e,
        xe,
        pe(W.width * oe, 3),
        W.stroke(s, l),
        W.dash,
        W.cap
      );
      let kt = a.grid;
      kt.show && oi(
        ut,
        kt.filter(s, ie, l, k, X),
        f,
        f == 0 ? 2 : 1,
        f == 0 ? rt : Qe,
        f == 0 ? dt : Ye,
        pe(kt.width * oe, 3),
        kt.stroke(s, l),
        kt.dash,
        kt.cap
      ), D.show && oi(
        [$e],
        [1],
        f == 0 ? 1 : 0,
        f == 0 ? 1 : 2,
        f == 1 ? rt : Qe,
        f == 1 ? dt : Ye,
        pe(D.width * oe, 3),
        D.stroke(s, l),
        D.dash,
        D.cap
      );
    }
    De("drawAxes");
  }
  function ws(l) {
    x.forEach((a, c) => {
      c > 0 && (a._paths = null, l && (i == 1 ? (a.min = null, a.max = null) : a.facets.forEach((f) => {
        f.min = null, f.max = null;
      })));
    });
  }
  let $n = !1, ai = !1, Ks = [];
  function ma() {
    ai = !1;
    for (let l = 0; l < Ks.length; l++)
      De(...Ks[l]);
    Ks.length = 0;
  }
  function ys() {
    $n || (Uc($l), $n = !0);
  }
  function ga(l, a = !1) {
    $n = !0, ai = a, l(s), $l(), a && Ks.length > 0 && queueMicrotask(ma);
  }
  s.batch = ga;
  function $l() {
    if (Yn && (oa(), Yn = !1), ds && (ea(), ds = !1), bn) {
      if (be(y, Rs, de), be(y, Qs, Te), be(y, nn, q), be(y, ln, R), be($, Rs, de), be($, Qs, Te), be($, nn, q), be($, ln, R), be(b, nn, Ct), be(b, ln, Bt), g.width = Re(Ct * oe), g.height = Re(Bt * oe), z.forEach(({ _el: l, _show: a, _size: c, _pos: f, side: m }) => {
        if (l != null)
          if (a) {
            let v = m === 3 || m === 0 ? c : 0, _ = m % 2 == 1;
            be(l, _ ? "left" : "top", f - v), be(l, _ ? "width" : "height", c), be(l, _ ? "top" : "left", _ ? Te : de), be(l, _ ? "height" : "width", _ ? R : q), Ci(l, ns);
          } else
            st(l, ns);
      }), yn = _s = Qn = ei = ti = si = ni = ii = Xn = null, Je = 1, Ys(!0), de != ps || Te != Kt || q != St || R != jt) {
        ws(!1);
        let l = q / St, a = R / jt;
        if (We && !qt && O.left >= 0) {
          O.left *= l, O.top *= a, Ss && Tt(Ss, Re(O.left), 0, q, R), xs && Tt(xs, 0, Re(O.top), q, R);
          for (let c = 0; c < at.length; c++) {
            let f = at[c];
            f != null && (vs[c] *= l, bs[c] *= a, Tt(f, ft(vs[c]), ft(bs[c]), q, R));
          }
        }
        if (ge.show && !_n && ge.left >= 0 && ge.width > 0) {
          ge.left *= l, ge.width *= l, ge.top *= a, ge.height *= a;
          for (let c in di)
            be(As, c, ge[c]);
        }
        ps = de, Kt = Te, St = q, jt = R;
      }
      De("setSize"), bn = !1;
    }
    Ct > 0 && Bt > 0 && (d.clearRect(0, 0, g.width, g.height), De("drawClear"), j.forEach((l) => l()), De("draw")), ge.show && _n && (En(ge), _n = !1), We && qt && (Qt(null, !0, !1), qt = !1), Q.show && Q.live && ot && (fi(), ot = !1), h || (h = !0, s.status = 1, De("ready")), Bs = !1, $n = !1;
  }
  s.redraw = (l, a) => {
    ds = a || !1, l !== !1 ? Ht(C, A.min, A.max) : ys();
  };
  function ci(l, a) {
    let c = E[l];
    if (c.from == null) {
      if (He == 0) {
        let f = c.range(s, a.min, a.max, l);
        a.min = f[0], a.max = f[1];
      }
      if (a.min > a.max) {
        let f = a.min;
        a.min = a.max, a.max = f;
      }
      if (He > 1 && a.min != null && a.max != null && a.max - a.min < 1e-16)
        return;
      l == C && c.distr == 2 && He > 0 && (a.min = _t(a.min, e[0]), a.max = _t(a.max, e[0]), a.min == a.max && a.max++), H[l] = a, Yn = !0, ys();
    }
  }
  s.setScale = ci;
  let ui, hi, Ss, xs, El, Al, $s, Es, kl, Tl, me, ye, Ft = !1;
  const ze = O.drag;
  let Le = ze.x, Oe = ze.y;
  We && (O.x && (ui = ht(hc, $)), O.y && (hi = ht(fc, $)), A.ori == 0 ? (Ss = ui, xs = hi) : (Ss = hi, xs = ui), me = O.left, ye = O.top);
  const ge = s.select = Ae({
    show: !0,
    over: !0,
    left: 0,
    width: 0,
    top: 0,
    height: 0
  }, t.select), As = ge.show ? ht(uc, ge.over ? $ : y) : null;
  function En(l, a) {
    if (ge.show) {
      for (let c in l)
        ge[c] = l[c], c in di && be(As, c, l[c]);
      a !== !1 && De("setSelect");
    }
  }
  s.setSelect = En;
  function va(l) {
    if (x[l].show)
      ke && Ci(Se[l], ns);
    else if (ke && st(Se[l], ns), We) {
      let c = gs ? at[0] : at[l];
      c != null && Tt(c, -10, -10, q, R);
    }
  }
  function Ht(l, a, c) {
    ci(l, { min: a, max: c });
  }
  function $t(l, a, c, f) {
    a.focus != null && Sa(l), a.show != null && x.forEach((m, v) => {
      v > 0 && (l == v || l == null) && (m.show = a.show, va(v), i == 2 ? (Ht(m.facets[0].scale, null, null), Ht(m.facets[1].scale, null, null)) : Ht(m.scale, null, null), ys());
    }), c !== !1 && De("setSeries", l, a), f && Js("setSeries", s, l, a);
  }
  s.setSeries = $t;
  function ba(l, a) {
    Ae(J[l], a);
  }
  function _a(l, a) {
    l.fill = te(l.fill || null), l.dir = le(l.dir, -1), a = a ?? J.length, J.splice(a, 0, l);
  }
  function wa(l) {
    l == null ? J.length = 0 : J.splice(l, 1);
  }
  s.addBand = _a, s.setBand = ba, s.delBand = wa;
  function ya(l, a) {
    x[l].alpha = a, We && at[l] != null && (at[l].style.opacity = a), ke && Se[l] && (Se[l].style.opacity = a);
  }
  let Pt, zt, Zt;
  const ks = { focus: !0 };
  function Sa(l) {
    if (l != Zt) {
      let a = l == null, c = xt.alpha != 1;
      x.forEach((f, m) => {
        if (i == 1 || m > 0) {
          let v = a || m == 0 || m == l;
          f._focus = a ? null : v, c && ya(m, v ? 1 : xt.alpha);
        }
      }), Zt = l, c && ys();
    }
  }
  ke && ms && Ve(lr, ae, (l) => {
    O._lock || (Yt(l), Zt != null && $t(null, ks, !0, Ee.setSeries));
  });
  function Et(l, a, c) {
    let f = E[a];
    c && (l = l / oe - (f.ori == 1 ? Te : de));
    let m = q;
    f.ori == 1 && (m = R, l = m - l), f.dir == -1 && (l = m - l);
    let v = f._min, _ = f._max, w = l / m, S = v + (_ - v) * w, k = f.distr;
    return k == 3 ? Ds(10, S) : k == 4 ? Rc(S, f.asinh) : k == 100 ? f.bwd(S) : S;
  }
  function xa(l, a) {
    let c = Et(l, C, a);
    return _t(c, e[0], Pe, Ne);
  }
  s.valToIdx = (l) => _t(l, e[0]), s.posToIdx = xa, s.posToVal = Et, s.valToPos = (l, a, c) => E[a].ori == 0 ? r(
    l,
    E[a],
    c ? Ye : q,
    c ? Qe : 0
  ) : o(
    l,
    E[a],
    c ? dt : R,
    c ? rt : 0
  ), s.setCursor = (l, a, c) => {
    me = l.left, ye = l.top, Qt(null, a, c);
  };
  function Rl(l, a) {
    be(As, Rs, ge.left = l), be(As, nn, ge.width = a);
  }
  function Ml(l, a) {
    be(As, Qs, ge.top = l), be(As, ln, ge.height = a);
  }
  let js = A.ori == 0 ? Rl : Ml, qs = A.ori == 1 ? Rl : Ml;
  function $a() {
    if (ke && Q.live)
      for (let l = i == 2 ? 1 : 0; l < x.length; l++) {
        if (l == 0 && lt)
          continue;
        let a = Q.values[l], c = 0;
        for (let f in a)
          yt[l][c++].firstChild.nodeValue = a[f];
      }
  }
  function fi(l, a) {
    if (l != null && (l.idxs ? l.idxs.forEach((c, f) => {
      ue[f] = c;
    }) : Nc(l.idx) || ue.fill(l.idx), Q.idx = ue[0]), ke && Q.live) {
      for (let c = 0; c < x.length; c++)
        (c > 0 || i == 1 && !lt) && Ea(c, ue[c]);
      $a();
    }
    ot = !1, a !== !1 && De("setLegend");
  }
  s.setLegend = fi;
  function Ea(l, a) {
    let c = x[l], f = l == 0 && Y == 2 ? mt : e[l], m;
    lt ? m = c.values(s, l, a) ?? Ot : (m = c.value(s, a == null ? null : f[a], l, a), m = m == null ? Ot : { _: m }), Q.values[l] = m;
  }
  function Qt(l, a, c) {
    kl = me, Tl = ye, [me, ye] = O.move(s, me, ye), O.left = me, O.top = ye, We && (Ss && Tt(Ss, Re(me), 0, q, R), xs && Tt(xs, 0, Re(ye), q, R));
    let f, m = Pe > Ne;
    Pt = fe, zt = null;
    let v = A.ori == 0 ? q : R, _ = A.ori == 1 ? q : R;
    if (me < 0 || He == 0 || m) {
      f = O.idx = null;
      for (let w = 0; w < x.length; w++) {
        let S = at[w];
        S != null && Tt(S, -10, -10, q, R);
      }
      ms && $t(null, ks, !0, l == null && Ee.setSeries), Q.live && (ue.fill(f), ot = !0);
    } else {
      let w, S, k;
      i == 1 && (w = A.ori == 0 ? me : ye, S = Et(w, C), f = O.idx = _t(S, e[0], Pe, Ne), k = L(e[0][f], A, v, 0));
      let T = -10, M = -10, G = 0, re = 0, ie = !0, X = "", W = "";
      for (let D = i == 2 ? 1 : 0; D < x.length; D++) {
        let ve = x[D], xe = ue[D], Fe = xe == null ? null : i == 1 ? e[D][xe] : e[D][1][xe], he = O.dataIdx(s, D, f, S), $e = he == null ? null : i == 1 ? e[D][he] : e[D][1][he];
        if (ot = ot || $e != Fe || he != xe, ue[D] = he, D > 0 && ve.show) {
          let Xe = he == null ? -10 : he == f ? k : L(i == 1 ? e[0][he] : e[D][0][he], A, v, 0), Ge = $e == null ? -10 : V($e, i == 1 ? E[ve.scale] : E[ve.facets[1].scale], _, 0);
          if (ms && $e != null) {
            let ct = A.ori == 1 ? me : ye, gt = Me(xt.dist(s, D, he, Ge, ct));
            if (gt < Pt) {
              let At = xt.bias;
              if (At != 0) {
                let et = Et(ct, ve.scale), ut = $e >= 0 ? 1 : -1, vt = et >= 0 ? 1 : -1;
                vt == ut && (vt == 1 ? At == 1 ? $e >= et : $e <= et : (
                  // >= 0
                  At == 1 ? $e <= et : $e >= et
                )) && (Pt = gt, zt = D);
              } else
                Pt = gt, zt = D;
            }
          }
          if (ot || gs) {
            let ct, gt;
            A.ori == 0 ? (ct = Xe, gt = Ge) : (ct = Ge, gt = Xe);
            let At, et, ut, vt, kt, Be, tt = !0, Xt = Ie.bbox;
            if (Xt != null) {
              tt = !1;
              let Ke = Xt(s, D);
              ut = Ke.left, vt = Ke.top, At = Ke.width, et = Ke.height;
            } else
              ut = ct, vt = gt, At = et = Ie.size(s, D);
            if (Be = Ie.fill(s, D), kt = Ie.stroke(s, D), gs)
              D == zt && Pt <= xt.prox && (T = ut, M = vt, G = At, re = et, ie = tt, X = Be, W = kt);
            else {
              let Ke = at[D];
              Ke != null && (vs[D] = ut, bs[D] = vt, fr(Ke, At, et, tt), ur(Ke, Be, kt), Tt(Ke, ft(ut), ft(vt), q, R));
            }
          }
        }
      }
      if (gs) {
        let D = xt.prox, ve = Zt == null ? Pt <= D : Pt > D || zt != Zt;
        if (ot || ve) {
          let xe = at[0];
          xe != null && (vs[0] = T, bs[0] = M, fr(xe, G, re, ie), ur(xe, X, W), Tt(xe, ft(T), ft(M), q, R));
        }
      }
    }
    if (ge.show && Ft)
      if (l != null) {
        let [w, S] = Ee.scales, [k, T] = Ee.match, [M, G] = l.cursor.sync.scales, re = l.cursor.drag;
        if (Le = re._x, Oe = re._y, Le || Oe) {
          let { left: ie, top: X, width: W, height: D } = l.select, ve = l.scales[M].ori, xe = l.posToVal, Fe, he, $e, Xe, Ge, ct = w != null && k(w, M), gt = S != null && T(S, G);
          ct && Le ? (ve == 0 ? (Fe = ie, he = W) : (Fe = X, he = D), $e = E[w], Xe = L(xe(Fe, M), $e, v, 0), Ge = L(xe(Fe + he, M), $e, v, 0), js(wt(Xe, Ge), Me(Ge - Xe))) : js(0, v), gt && Oe ? (ve == 1 ? (Fe = ie, he = W) : (Fe = X, he = D), $e = E[S], Xe = V(xe(Fe, G), $e, _, 0), Ge = V(xe(Fe + he, G), $e, _, 0), qs(wt(Xe, Ge), Me(Ge - Xe))) : qs(0, _);
        } else
          mi();
      } else {
        let w = Me(kl - El), S = Me(Tl - Al);
        if (A.ori == 1) {
          let G = w;
          w = S, S = G;
        }
        Le = ze.x && w >= ze.dist, Oe = ze.y && S >= ze.dist;
        let k = ze.uni;
        k != null ? Le && Oe && (Le = w >= k, Oe = S >= k, !Le && !Oe && (S > w ? Oe = !0 : Le = !0)) : ze.x && ze.y && (Le || Oe) && (Le = Oe = !0);
        let T, M;
        Le && (A.ori == 0 ? (T = $s, M = me) : (T = Es, M = ye), js(wt(T, M), Me(M - T)), Oe || qs(0, _)), Oe && (A.ori == 1 ? (T = $s, M = me) : (T = Es, M = ye), qs(wt(T, M), Me(M - T)), Le || js(0, v)), !Le && !Oe && (js(0, 0), qs(0, 0));
      }
    if (ze._x = Le, ze._y = Oe, l == null) {
      if (c) {
        if (Ul != null) {
          let [w, S] = Ee.scales;
          Ee.values[0] = w != null ? Et(A.ori == 0 ? me : ye, w) : null, Ee.values[1] = S != null ? Et(A.ori == 1 ? me : ye, S) : null;
        }
        Js(wi, s, me, ye, q, R, f);
      }
      if (ms) {
        let w = c && Ee.setSeries, S = xt.prox;
        Zt == null ? Pt <= S && $t(zt, ks, !0, w) : Pt > S ? $t(null, ks, !0, w) : zt != Zt && $t(zt, ks, !0, w);
      }
    }
    ot && (Q.idx = f, fi()), a !== !1 && De("setCursor");
  }
  let It = null;
  Object.defineProperty(s, "rect", {
    get() {
      return It == null && Ys(!1), It;
    }
  });
  function Ys(l = !1) {
    l ? It = null : (It = $.getBoundingClientRect(), De("syncRect", It));
  }
  function Cl(l, a, c, f, m, v, _) {
    O._lock || Ft && l != null && l.movementX == 0 && l.movementY == 0 || (pi(l, a, c, f, m, v, _, !1, l != null), l != null ? Qt(null, !0, !0) : Qt(a, !0, !1));
  }
  function pi(l, a, c, f, m, v, _, w, S) {
    if (It == null && Ys(!1), Yt(l), l != null)
      c = l.clientX - It.left, f = l.clientY - It.top;
    else {
      if (c < 0 || f < 0) {
        me = -10, ye = -10;
        return;
      }
      let [k, T] = Ee.scales, M = a.cursor.sync, [G, re] = M.values, [ie, X] = M.scales, [W, D] = Ee.match, ve = a.axes[0].side % 2 == 1, xe = A.ori == 0 ? q : R, Fe = A.ori == 1 ? q : R, he = ve ? v : m, $e = ve ? m : v, Xe = ve ? f : c, Ge = ve ? c : f;
      if (ie != null ? c = W(k, ie) ? u(G, E[k], xe, 0) : -10 : c = xe * (Xe / he), X != null ? f = D(T, X) ? u(re, E[T], Fe, 0) : -10 : f = Fe * (Ge / $e), A.ori == 1) {
        let ct = c;
        c = f, f = ct;
      }
    }
    S && (a == null || a.cursor.event.type == wi) && ((c <= 1 || c >= q - 1) && (c = ts(c, q)), (f <= 1 || f >= R - 1) && (f = ts(f, R))), w ? (El = c, Al = f, [$s, Es] = O.move(s, c, f)) : (me = c, ye = f);
  }
  const di = {
    width: 0,
    height: 0,
    left: 0,
    top: 0
  };
  function mi() {
    En(di, !1);
  }
  let Pl, Nl, Ll, Ol;
  function Dl(l, a, c, f, m, v, _) {
    Ft = !0, Le = Oe = ze._x = ze._y = !1, pi(l, a, c, f, m, v, _, !0, !1), l != null && (Ve(yi, Ri, Fl, !1), Js(nr, s, $s, Es, q, R, null));
    let { left: w, top: S, width: k, height: T } = ge;
    Pl = w, Nl = S, Ll = k, Ol = T;
  }
  function Fl(l, a, c, f, m, v, _) {
    Ft = ze._x = ze._y = !1, pi(l, a, c, f, m, v, _, !1, !0);
    let { left: w, top: S, width: k, height: T } = ge, M = k > 0 || T > 0, G = Pl != w || Nl != S || Ll != k || Ol != T;
    if (M && G && En(ge), ze.setScale && M && G) {
      let re = w, ie = k, X = S, W = T;
      if (A.ori == 1 && (re = S, ie = T, X = w, W = k), Le && Ht(
        C,
        Et(re, C),
        Et(re + ie, C)
      ), Oe)
        for (let D in E) {
          let ve = E[D];
          D != C && ve.from == null && ve.min != fe && Ht(
            D,
            Et(X + W, D),
            Et(X, D)
          );
        }
      mi();
    } else O.lock && (O._lock = !O._lock, Qt(a, !0, l != null));
    l != null && (fs(yi, Ri), Js(yi, s, me, ye, q, R, null));
  }
  function Aa(l, a, c, f, m, v, _) {
    if (O._lock)
      return;
    Yt(l);
    let w = Ft;
    if (Ft) {
      let S = !0, k = !0, T = 10, M, G;
      A.ori == 0 ? (M = Le, G = Oe) : (M = Oe, G = Le), M && G && (S = me <= T || me >= q - T, k = ye <= T || ye >= R - T), M && S && (me = me < $s ? 0 : q), G && k && (ye = ye < Es ? 0 : R), Qt(null, !0, !0), Ft = !1;
    }
    me = -10, ye = -10, ue.fill(null), Qt(null, !0, !0), w && (Ft = w);
  }
  function Hl(l, a, c, f, m, v, _) {
    O._lock || (Yt(l), Zn(), mi(), l != null && Js(rr, s, me, ye, q, R, null));
  }
  function zl() {
    z.forEach(Yu), Jn(s.width, s.height, !0);
  }
  ls(On, Ns, zl);
  const Ts = {};
  Ts.mousedown = Dl, Ts.mousemove = Cl, Ts.mouseup = Fl, Ts.dblclick = Hl, Ts.setSeries = (l, a, c, f) => {
    let m = Ee.match[2];
    c = m(s, a, c), c != -1 && $t(c, f, !0, !1);
  }, We && (Ve(nr, $, Dl), Ve(wi, $, Cl), Ve(ir, $, (l) => {
    Yt(l), Ys(!1);
  }), Ve(lr, $, Aa), Ve(rr, $, Hl), Fi.add(s), s.syncRect = Ys);
  const An = s.hooks = t.hooks || {};
  function De(l, a, c) {
    ai ? Ks.push([l, a, c]) : l in An && An[l].forEach((f) => {
      f.call(null, s, a, c);
    });
  }
  (t.plugins || []).forEach((l) => {
    for (let a in l.hooks)
      An[a] = (An[a] || []).concat(l.hooks[a]);
  });
  const Il = (l, a, c) => c, Ee = Ae({
    key: null,
    setSeries: !1,
    filters: {
      pub: vr,
      sub: vr
    },
    scales: [C, x[1] ? x[1].scale : null],
    match: [br, br, Il],
    values: [null, null]
  }, O.sync);
  Ee.match.length == 2 && Ee.match.push(Il), O.sync = Ee;
  const Ul = Ee.key, gi = Co(Ul);
  function Js(l, a, c, f, m, v, _) {
    Ee.filters.pub(l, a, c, f, m, v, _) && gi.pub(l, a, c, f, m, v, _);
  }
  gi.sub(s);
  function ka(l, a, c, f, m, v, _) {
    Ee.filters.sub(l, a, c, f, m, v, _) && Ts[l](null, a, c, f, m, v, _);
  }
  s.pub = ka;
  function Ta() {
    gi.unsub(s), Fi.delete(s), Gt.clear(), Pi(On, Ns, zl), p.remove(), ae?.remove(), De("destroy");
  }
  s.destroy = Ta;
  function vi() {
    De("init", t, e), vl(e || t.data, !1), H[C] ? ci(C, H[C]) : Zn(), _n = ge.show && (ge.width > 0 || ge.height > 0), qt = ot = !0, Jn(t.width, t.height);
  }
  return x.forEach(ml), z.forEach(ra), n ? n instanceof HTMLElement ? (n.appendChild(p), vi()) : n(s, vi) : vi(), s;
}
Ue.assign = Ae;
Ue.fmtNum = el;
Ue.rangeNum = Dn;
Ue.rangeLog = Wn;
Ue.rangeAsinh = Qi;
Ue.orient = as;
Ue.pxRatio = oe;
Ue.join = Ic;
Ue.fmtDate = sl, Ue.tzDate = Zc;
Ue.sync = Co;
{
  Ue.addGap = Nu, Ue.clipGaps = Bn;
  let t = Ue.paths = {
    points: Fo
  };
  t.linear = zo, t.stepped = Du, t.bars = Fu, t.spline = zu;
}
const Ju = '.uplot,.uplot *,.uplot *:before,.uplot *:after{box-sizing:border-box}.uplot{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";line-height:1.5;width:min-content}.u-title{text-align:center;font-size:18px;font-weight:700}.u-wrap{position:relative;user-select:none}.u-over,.u-under{position:absolute}.u-under{overflow:hidden}.uplot canvas{display:block;position:relative;width:100%;height:100%}.u-axis{position:absolute}.u-legend{font-size:14px;margin:auto;text-align:center}.u-inline{display:block}.u-inline *{display:inline-block}.u-inline tr{margin-right:16px}.u-legend th{font-weight:600}.u-legend th>*{vertical-align:middle;display:inline-block}.u-legend .u-marker{width:1em;height:1em;margin-right:4px;background-clip:padding-box!important}.u-inline.u-live th:after{content:":";vertical-align:middle}.u-inline:not(.u-live) .u-value{display:none}.u-series>*{padding:4px}.u-series th{cursor:pointer}.u-legend .u-off>*{opacity:.3}.u-select{background:#00000012;position:absolute;pointer-events:none}.u-cursor-x,.u-cursor-y{position:absolute;left:0;top:0;pointer-events:none;will-change:transform}.u-hz .u-cursor-x,.u-vt .u-cursor-y{height:100%;border-right:1px dashed #607D8B}.u-hz .u-cursor-y,.u-vt .u-cursor-x{width:100%;border-bottom:1px dashed #607D8B}.u-cursor-pt{position:absolute;top:0;left:0;border-radius:50%;border:0 solid;pointer-events:none;will-change:transform;background-clip:padding-box!important}.u-axis.u-off,.u-select.u-off,.u-cursor-x.u-off,.u-cursor-y.u-off,.u-cursor-pt.u-off{display:none}', Vo = ["raw", "average", "moving", "median", "envelope"], Go = 20, Bo = 2e3, cl = 100;
function Ir(t) {
  return Vo.includes(t) ? t : "raw";
}
function zi(t) {
  return typeof t != "number" || !Number.isFinite(t) ? cl : Math.min(Bo, Math.max(Go, Math.round(t)));
}
function Ko(t, e, n, s) {
  const i = Math.min(n.length, s.length);
  if (t === "raw" || i === 0) return { xs: n, cols: [s] };
  const r = zi(e) / 1e3;
  switch (t) {
    case "average":
      return { xs: n, cols: [Ai(n, s, i, r, "mean")] };
    case "envelope":
      return { xs: n, cols: [Ai(n, s, i, r, "min"), Ai(n, s, i, r, "max")] };
    case "moving":
      return { xs: n, cols: [Zu(n, s, i, r)] };
    case "median":
      return { xs: n, cols: [Qu(n, s, i, r)] };
  }
}
function Ai(t, e, n, s, i) {
  const r = new Array(n);
  let o = 0;
  for (; o < n; ) {
    const u = Math.floor(t[o] / s);
    let h = o, p = 0, g = 1 / 0, d = -1 / 0;
    for (; h < n && Math.floor(t[h] / s) === u; ) {
      const y = e[h];
      p += y, y < g && (g = y), y > d && (d = y), h++;
    }
    const b = i === "mean" ? p / (h - o) : i === "min" ? g : d;
    for (let y = o; y < h; y++) r[y] = b;
    o = h;
  }
  return r;
}
function Zu(t, e, n, s) {
  const i = new Array(n);
  let r = 0, o = 0;
  for (let u = 0; u < n; u++) {
    for (o += e[u]; t[u] - t[r] >= s; ) o -= e[r++];
    i[u] = o / (u - r + 1);
  }
  return i;
}
function Qu(t, e, n, s) {
  const i = new Array(n), r = [], o = (h) => {
    let p = 0, g = r.length;
    for (; p < g; ) {
      const d = p + g >> 1;
      r[d] < h ? p = d + 1 : g = d;
    }
    return p;
  };
  let u = 0;
  for (let h = 0; h < n; h++) {
    for (r.splice(o(e[h]), 0, e[h]); t[h] - t[u] >= s; )
      r.splice(o(e[u]), 1), u++;
    const p = r.length >> 1;
    i[h] = r.length % 2 ? r[p] : (r[p - 1] + r[p]) / 2;
  }
  return i;
}
class Xu extends Ps {
  static styles = [
    qr(Ju),
    Yr`
      :host { display: block; position: relative; min-width: 0; }
      .wrap { width: 100%; height: var(--pa-chart-height, 220px); }
      .u-legend { display: none; }
      .readout {
        position: absolute;
        top: 4px;
        inset-inline-end: 8px;
        padding: 1px 6px;
        border-radius: var(--radius-sm, 4px);
        background: var(--bg-surface, #fff);
        border: 1px solid var(--border-color, #ccc);
        color: var(--text-primary);
        font-size: var(--font-size-sm, 12px);
        font-variant-numeric: tabular-nums;
        pointer-events: none;
      }
      .empty {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--text-muted);
        font-size: var(--font-size-sm, 12px);
        pointer-events: none;
        text-align: center;
        padding: var(--space-md, 12px);
      }
    `
  ];
  static properties = {
    buffer: { attribute: !1 },
    version: { type: Number },
    unit: { type: String },
    seconds: { type: Number },
    emptyText: { type: String },
    paused: { type: Boolean },
    filter: { type: String },
    filterMs: { type: Number },
    showRaw: { type: Boolean },
    readout: { state: !0 }
  };
  #e = null;
  #s = 0;
  #t = null;
  /** Last data given to uPlot (the cursor readout looks values up in it). */
  #i = [[], []];
  /** Snapshot shown while paused, so a filter change does not pull in newer samples. */
  #r = null;
  /** Series layout of the current plot: the raw trace is drawn only under a filter. */
  #n = !1;
  constructor() {
    super(), this.buffer = null, this.version = 0, this.unit = "g", this.seconds = 30, this.emptyText = "", this.paused = !1, this.filter = "raw", this.filterMs = cl, this.showRaw = !1, this.readout = "";
  }
  connectedCallback() {
    super.connectedCallback(), this.#t = new ResizeObserver(() => this.#c()), this.#t.observe(this);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.#t?.disconnect(), this.#t = null, this.#s && cancelAnimationFrame(this.#s), this.#s = 0, this.#a();
  }
  /** Rebuilds the chart with the current theme colours. */
  restyle() {
    this.#a(), this.#o(!0);
  }
  updated(e) {
    if (e.has("paused")) {
      const n = this.buffer;
      this.#r = this.paused && n ? { t: n.times(), v: n.values() } : null;
    }
    e.has("seconds") || e.has("unit") || e.has("filter") || e.has("showRaw") ? this.restyle() : e.has("filterMs") ? this.#o(!0) : (e.has("version") || e.has("paused")) && this.#o();
  }
  /** `force`: redraw even while paused (a filter change must show on the frozen trace). */
  #o(e = !1) {
    this.#s || this.paused && !e || (this.#s = requestAnimationFrame(() => {
      this.#s = 0, this.#h();
    }));
  }
  #l(e, n) {
    return getComputedStyle(this).getPropertyValue(e).trim() || n;
  }
  #a() {
    this.#e?.destroy(), this.#e = null;
  }
  #c() {
    const e = this.renderRoot.querySelector(".wrap");
    !e || e.clientWidth === 0 || (this.#e ? this.#e.setSize({ width: e.clientWidth, height: e.clientHeight }) : this.#o());
  }
  /** uPlot series for the current filter: [x, raw?, filtered | lower + upper]. */
  #u(e) {
    const n = [{}];
    return this.#n && n.push({ stroke: this.#l("--text-muted", "#888"), width: 1, points: { show: !1 } }), this.filter === "envelope" ? (n.push({ stroke: this.#l("--cool", "#40c4ff"), width: 1.5, points: { show: !1 } }), n.push({ stroke: this.#l("--heat", "#ff6d00"), width: 1.5, points: { show: !1 } })) : n.push({ stroke: e, width: 1.5, points: { show: !1 } }), n;
  }
  #f(e) {
    const n = this.#l("--accent", "#3b82f6"), s = this.#l("--text-muted", "#888"), i = this.#l("--border-color", "#8884"), r = this.unit === "g" ? "g" : "counts", o = this.unit === "g" ? 2 : 25, u = {
      width: Math.max(e.clientWidth, 200),
      height: Math.max(e.clientHeight, 120),
      legend: { show: !1 },
      cursor: { drag: { x: !1, y: !1 }, points: { size: 6 } },
      scales: {
        x: { time: !1, range: () => [-this.seconds, 0] },
        y: {
          range: (h, p, g) => {
            if (!Number.isFinite(p) || !Number.isFinite(g)) return [-1, 1];
            const d = Math.max(g - p, o), b = (g + p) / 2;
            return [b - d * 0.6, b + d * 0.6];
          }
        }
      },
      axes: [
        {
          stroke: s,
          grid: { stroke: i, width: 1 },
          ticks: { stroke: i },
          values: (h, p) => p.map((g) => `${g}s`)
        },
        {
          stroke: s,
          grid: { stroke: i, width: 1 },
          ticks: { stroke: i },
          size: 56,
          label: r,
          labelSize: 14
        }
      ],
      series: this.#u(n),
      hooks: {
        setCursor: [
          (h) => {
            const p = h.cursor.idx;
            if (p == null) {
              this.readout = "";
              return;
            }
            const g = this.unit === "g" ? 2 : 0, d = this.#n ? 2 : 1, y = this.#i.slice(d).map(($) => $[p]);
            this.readout = y.some(($) => $ === void 0) ? "" : `${y.map(($) => $.toFixed(g)).join(" … ")} ${r}`;
          }
        ]
      }
    };
    return new Ue(u, this.#i, e);
  }
  #h() {
    const e = this.renderRoot.querySelector(".wrap"), n = this.buffer;
    if (!e || !n) return;
    const s = this.#r?.t ?? n.times(), i = this.#r?.v ?? n.values(), r = s[s.length - 1] ?? 0, o = s.map((h) => h - r);
    this.#n = this.showRaw && this.filter !== "raw";
    const u = Ko(this.filter, this.filterMs, s, i).cols;
    if (this.#i = [o, ...this.#n ? [i] : [], ...u], !this.#e) {
      if (e.clientWidth === 0) return;
      this.#e = this.#f(e);
      return;
    }
    this.#e.setData(this.#i);
  }
  render() {
    const e = !this.buffer || this.buffer.length === 0;
    return I`
      <div class="wrap"></div>
      ${this.readout ? I`<span class="readout">${this.readout}</span>` : B}
      ${e && this.emptyText ? I`<div class="empty">${this.emptyText}</div>` : B}
    `;
  }
}
const Ur = ["step_response", "search_overshoot"], eh = 2, dn = [
  { id: "test", gcode: "TEST_PRESSURE_ADVANCE", applies: !1 },
  { id: "calibrate", gcode: "PA_CALIBRATE", applies: !0 }
];
function en(t) {
  return dn.find((e) => e.id === t) ?? dn[0];
}
const th = [
  { key: "SLOW_FLOW", type: "number", placeholder: "2", above: 0 },
  { key: "HIGH_FLOW", type: "number", above: 0 },
  { key: "PURGE_LENGTH", type: "number", above: 0 },
  { key: "SEGMENT_TIME", type: "number", placeholder: "0.5", above: 0 },
  { key: "TEST_REPETITIONS", type: "int", placeholder: "10", min: 1 },
  { key: "FILTER_WINDOW", type: "number", placeholder: "0.01", above: 0, max: 0.04 },
  { key: "EXTRUDE_FORCE_SIGN", type: "sign", placeholder: "0" },
  { key: "PA_RANGE", type: "range", placeholder: "0,0.2", method: "search_overshoot" },
  { key: "EXTRUDER", type: "extruder" },
  { key: "FORCE_SENSOR", type: "sensor" }
];
function Ii(t) {
  return th.filter((e) => !e.method || e.method === t);
}
function mn(t) {
  const e = Number(t);
  return t !== "" && Number.isFinite(e) ? e : null;
}
function sh(t, e) {
  const n = mn(e);
  return n === null || t.type === "int" && !Number.isInteger(n) || t.type === "sign" && !(Number.isInteger(n) && n >= -1 && n <= 1) || t.above !== void 0 && !(n > t.above) || t.min !== void 0 && n < t.min || t.max !== void 0 && n > t.max ? null : n;
}
function nh(t) {
  const e = t.split(",").map((i) => i.trim());
  if (e.length !== 2) return null;
  const n = mn(e[0]), s = mn(e[1]);
  return n === null || s === null || n < 0 || s >= eh || n >= s ? null : [n, s];
}
const ih = /^[^\s"'\r\n]+$/;
function tn(t, e, n) {
  const s = [t.gcode, `METHOD=${e}`], i = [];
  for (const u of Ii(e)) {
    const h = (n[u.key] ?? "").trim();
    if (h !== "")
      if (u.type === "range") {
        const p = nh(h);
        p ? s.push(`${u.key}=${p[0]},${p[1]}`) : i.push(u.key);
      } else if (u.type === "sensor" || u.type === "extruder")
        ih.test(h) ? s.push(`${u.key}=${h}`) : i.push(u.key);
      else {
        const p = sh(u, h);
        p === null ? i.push(u.key) : s.push(`${u.key}=${p}`);
      }
  }
  const r = mn((n.SLOW_FLOW ?? "").trim()), o = mn((n.HIGH_FLOW ?? "").trim());
  return r !== null && o !== null && r > 0 && o > 0 && o <= r && (i.includes("HIGH_FLOW") || i.push("HIGH_FLOW")), { script: s.join(" "), invalid: i };
}
const lh = new Set(dn.map((t) => t.gcode));
function rh(t) {
  const e = [];
  for (const n of t.split(/\r?\n/)) {
    const s = n.trim();
    !s || s.startsWith(";") || s.startsWith("#") || e.push(s.split(/\s+/)[0].toUpperCase());
  }
  return e;
}
function Wr(t, e) {
  if (t === null || !Number.isFinite(t) || t < 0) return null;
  const n = Number(t.toFixed(4));
  return e && e !== "extruder" ? `SET_PRESSURE_ADVANCE ADVANCE=${n} EXTRUDER=${e}` : `SET_PRESSURE_ADVANCE ADVANCE=${n}`;
}
const oh = [50, 60];
function Vr(t) {
  return t === 60 ? 60 : 50;
}
const ah = 4, ch = 1e-9;
class uh {
  period;
  #e = [];
  #s = [];
  #t = 0;
  #i = 0;
  #r = null;
  /** Smoothed time between samples, seconds; 0 until two samples were seen. */
  #n = 0;
  /** Sample rate reported by the sensor (`sample_rate` in its status), Hz; 0 when unknown. */
  #o = 0;
  #l = !0;
  constructor(e) {
    this.period = 1 / e;
  }
  /** False when the sensor is too slow for the filter: samples then pass through as they are. */
  get active() {
    return this.#l;
  }
  /**
   * Tells the filter the sensor's own sample rate. A known rate beats the estimate made from
   * timestamps: it is right from the first sample, even when batches hold a single one.
   * Pass null or a non-positive value to fall back to the estimate.
   */
  setSampleRate(e) {
    this.#o = e !== null && Number.isFinite(e) && e > 0 ? e : 0;
  }
  /** Filters one batch (ascending times). */
  process(e) {
    if (e.length === 0) return [];
    for (const i of e) {
      if (this.#r !== null) {
        const r = i.time - this.#r;
        r > 0 && r < 1 && (this.#n = this.#n ? this.#n * 0.9 + r * 0.1 : r);
      }
      this.#r = i.time;
    }
    const n = this.#o ? 1 / this.#o : this.#n;
    if (this.#l = n === 0 || this.period / n >= ah, !this.#l)
      return this.#a(), e.slice();
    const s = [];
    for (const i of e) {
      for (this.#e.push(i.time), this.#s.push(i.value), this.#i += i.value; i.time - this.#e[this.#t] >= this.period - ch; ) this.#i -= this.#s[this.#t++];
      s.push({ time: i.time, value: this.#i / (this.#e.length - this.#t) });
    }
    return this.#t > 1024 && (this.#e.splice(0, this.#t), this.#s.splice(0, this.#t), this.#t = 0), s;
  }
  #a() {
    this.#e = [], this.#s = [], this.#t = 0, this.#i = 0;
  }
}
const hh = /^load_cell(_probe)?(\s|$)/i, fh = /^extruder\d*$/i;
function jo(t) {
  const e = t.trim().split(/\s+/);
  return e[e.length - 1];
}
function ph(t) {
  const e = t.pa_tester, n = {};
  for (const [i, r] of Object.entries(e ?? {}))
    r != null && r !== "" && (n[i] = String(r));
  const s = Object.keys(t);
  return {
    hasPaTester: e !== void 0,
    options: n,
    loadCells: s.filter((i) => hh.test(i)).map((i) => ({ section: i, name: jo(i) })),
    extruders: s.filter((i) => fh.test(i))
  };
}
function Nn(t, e = "") {
  const n = e || t.options.force_sensor || "";
  return n ? t.loadCells.find((s) => s.section === n || s.name === n) ?? {
    section: n,
    name: jo(n)
  } : t.loadCells.length === 1 ? t.loadCells[0] : null;
}
async function dh(t) {
  const e = await t.request(
    "printer.objects.query",
    { objects: { configfile: ["settings"] } }
  );
  return ph(e?.status?.configfile?.settings ?? {});
}
function Mn(t) {
  return typeof t == "number" && Number.isFinite(t) ? t : null;
}
function mh(t) {
  const e = t?.data;
  if (!Array.isArray(e)) return { unit: "g", samples: [] };
  let n = !0;
  const s = [];
  for (const o of e) {
    if (!Array.isArray(o)) continue;
    const u = Mn(o[0]);
    if (u === null) continue;
    const h = Mn(o[1]);
    h === null && (n = !1), s.push({ time: u, g: h, counts: Mn(o[2]), tare: Mn(o[3]) ?? 0 });
  }
  const i = n ? "g" : "counts", r = [];
  for (const o of s) {
    const u = i === "g" ? o.g : o.counts === null ? null : o.counts - o.tare;
    u !== null && r.push({ time: o.time, value: u });
  }
  return { unit: i, samples: r };
}
function gh(t, e) {
  if (t.length === 0) return t.slice();
  const n = [];
  let s = t[0].time, i = 0, r = 0, o = s;
  for (const u of t)
    u.time - s >= e && r > 0 && (n.push({ time: o, value: i / r }), s = u.time, i = 0, r = 0), i += u.value, r++, o = u.time;
  return r > 0 && n.push({ time: o, value: i / r }), n;
}
const Gr = /* @__PURE__ */ new Map();
function vh(t, e, n, s, i) {
  const r = Gr.get(e) ?? 0, o = [r, ...n.map((d, b) => b).filter((d) => d !== r)], u = [];
  let h = !1, p = 0;
  const g = (d) => {
    const b = ++p;
    u.push(
      t.klippyStream(e, n[o[d]], s, (y) => {
        if (!(h || b !== p)) {
          if (y === "unavailable" && d + 1 < o.length) {
            g(d + 1);
            return;
          }
          y === "live" && Gr.set(e, o[d]), i?.(y);
        }
      })
    );
  };
  return g(0), () => {
    h = !0;
    for (const d of u) d?.();
    u.length = 0;
  };
}
const bh = 0.02;
function _h(t, e, n, s = () => performance.now() / 1e3, i = () => 0) {
  let r = null, o = null, u = 0, h = null, p = null, g = !1;
  const d = () => {
    p || g || (n.onSource("status", "connecting"), p = t.subscribe(
      { [e.section]: ["force_g"] },
      ($) => {
        const P = $?.[e.section]?.force_g;
        typeof P != "number" || !Number.isFinite(P) || (n.onSource("status", "live"), n.onMains?.(!1), n.onSamples([{ time: s(), value: P }], "g"));
      },
      { immediate: !0 }
    ));
  }, b = () => {
    p?.(), p = null;
  }, y = ($) => {
    $ && !o && !g ? o = t.subscribe(
      { [e.section]: ["sample_rate"] },
      (P) => {
        const N = P?.[e.section]?.sample_rate;
        typeof N != "number" || !Number.isFinite(N) || N <= 0 || (u = N, r?.setSampleRate(N));
      },
      { immediate: !0 }
    ) : !$ && o && (o(), o = null, u = 0);
  };
  return typeof t.klippyStream != "function" ? d() : h = vh(
    t,
    "load_cell/dump_force",
    // documented key first; older Klipper answers "Missing Argument [load_cell]" to it
    [{ sensor: e.name }, { load_cell: e.name }],
    ($) => {
      const P = mh($);
      if (!P.samples.length) return;
      let N = P.samples;
      const U = i();
      y(U !== 0), U ? ((!r || r.period !== 1 / U) && (r = new uh(U), r.setSampleRate(u)), N = r.process(N), n.onMains?.(r.active)) : r = null, n.onSamples(gh(N, bh), P.unit);
    },
    ($) => {
      g || ($ === "unavailable" ? (n.onSource("stream", "unavailable"), d()) : (b(), n.onSource("stream", $)));
    }
  ), () => {
    g = !0, h?.(), h = null, o?.(), o = null, b();
  };
}
function ul() {
  return {
    running: !1,
    method: null,
    perFlow: [],
    overall: null,
    search: [],
    found: null,
    corrected: null,
    forceSign: null,
    warnings: [],
    error: null,
    value: null
  };
}
const hl = /^(TEST_PRESSURE_ADVANCE|PA_CALIBRATE)\b/i, qo = /^Detected extrude_force_sign=(-?\d+)/, Yo = /^WARNING: high_flow is less than 2x slow_flow/, Jo = /^Searching for optimal pressure_advance/, wh = /^PA calibration results:/, yh = /^flow=\s*(-?\d+(?:\.\d+)?)\s+pressure_advance=(-?\d+(?:\.\d+)?)/, Sh = /^overall pressure_advance=(-?\d+(?:\.\d+)?)/, xh = /^Failed to detect Pressure Advance value/, $h = /^Tested pressure_advance=(-?\d+(?:\.\d+)?)\s*->\s*(no overshoot|overshoot)/, Eh = /^Search complete:\s*(\d+) tests?, pressure_advance=(-?\d+(?:\.\d+)?)/, Ah = /^PA correction: pressure_advance=(-?\d+(?:\.\d+)?)/, Br = /^WARNING:\s*(.+)$/, kh = /^Test (\d+): pressure_advance=(-?\d+(?:\.\d+)?)/, Th = /^(Wait for calculations\.\.|\(accounts for force data filtering\)|Check sensor and filament)/;
function Rh(t) {
  const e = Array.isArray(t) ? t : [t], n = [];
  for (const s of e)
    if (typeof s == "string")
      for (const i of s.split(/\r?\n/)) {
        const r = i.trim();
        r && n.push(r);
      }
  return n;
}
function fl(t) {
  return t.startsWith("!!") ? { text: t.replace(/^!!\s*/, ""), error: !0 } : { text: t.replace(/^\/\/\s*/, ""), error: !1 };
}
function Zo(t) {
  const { text: e } = fl(t);
  return hl.test(e) || qo.test(e) || Yo.test(e) || Jo.test(e);
}
function Mh(t) {
  return hl.test(fl(t).text);
}
function Ch(t) {
  for (let e = t.length - 1; e >= 0; e--)
    if (Mh(t[e])) return t.slice(e);
  for (let e = t.length - 1; e >= 0; e--)
    if (Zo(t[e])) return t.slice(e);
  return [];
}
function Ph(t) {
  const e = /\bMETHOD=(step_response|search_overshoot)\b/i.exec(t);
  return e ? e[1].toLowerCase() : null;
}
function Hn(t) {
  const e = ul();
  for (const n of t) {
    const { text: s, error: i } = fl(n);
    if (i) {
      e.error = s, e.running = !1;
      continue;
    }
    if (hl.test(s)) {
      e.running = !0, e.error = null;
      const o = Ph(s);
      o && (e.method = o);
      continue;
    }
    let r;
    if (r = qo.exec(s))
      e.running = !0, e.forceSign = Number(r[1]);
    else if (Yo.test(s))
      e.running = !0, e.warnings.push(s.replace(/^WARNING:\s*/, ""));
    else if (Jo.test(s))
      e.running = !0, e.method = "search_overshoot";
    else if (r = kh.exec(s))
      e.running = !0, e.method = "search_overshoot";
    else if (r = $h.exec(s))
      e.method = "search_overshoot", e.search.push({ pa: Number(r[1]), overshoot: r[2] === "overshoot" });
    else if (r = Eh.exec(s))
      e.method = "search_overshoot", e.found = Number(r[2]), e.value = e.found, e.running = !1;
    else if (r = Ah.exec(s))
      e.corrected = Number(r[1]), e.value = e.corrected;
    else if (wh.test(s))
      e.method = "step_response", e.running = !0;
    else if (r = yh.exec(s))
      e.method = "step_response", e.perFlow.push({ flow: Number(r[1]), pa: Number(r[2]) });
    else if (r = Sh.exec(s))
      e.method = "step_response", e.overall = Number(r[1]), e.value = e.overall, e.running = !1;
    else if (xh.test(s))
      e.error = s, e.running = !1;
    else if (Br.test(s))
      e.warnings.push(Br.exec(s)[1]);
    else if (Th.test(s))
      continue;
  }
  return e.corrected === null && e.found !== null && (e.value = e.found), e;
}
const Qo = 600;
function Nh() {
  return {
    lines: [],
    result: ul(),
    busy: !1,
    external: !1,
    restored: !1,
    lastLineAt: 0,
    config: null,
    configError: !1
  };
}
const Ui = /* @__PURE__ */ new Map(), Wi = /* @__PURE__ */ new Map();
function cs(t) {
  let e = Ui.get(t);
  return e || (e = Nh(), Ui.set(t, e)), e;
}
function Rt(t, e) {
  Ui.set(t, { ...cs(t), ...e });
  for (const n of Wi.get(t) ?? []) n();
}
function Lh(t, e) {
  let n = Wi.get(t);
  return n || (n = /* @__PURE__ */ new Set(), Wi.set(t, n)), n.add(e), () => n.delete(e);
}
function Oh(t) {
  const e = cs(t);
  Rt(t, {
    busy: !1,
    external: !1,
    result: { ...e.result, running: !1 },
    config: null
  });
}
function Dh(t) {
  Rt(t, {
    lines: [],
    result: { ...ul(), running: !0 },
    busy: !0,
    external: !1
  });
}
function Fh(t, e) {
  const n = cs(t), s = e ? [...n.lines, `!! ${e}`].slice(-300) : n.lines, i = Hn(s);
  Rt(t, { busy: !1, lines: s, result: { ...i, running: !1 } });
}
function Hh(t, e, n = Date.now() / 1e3) {
  const s = cs(t);
  let i = s.lines, r = s.external, o = s.busy || s.result.running;
  for (const h of e)
    !s.busy && Zo(h) && !o && (i = [], r = !0, o = !0), o && (i = [...i, h], !s.busy && !Hn(i).running && (o = !1));
  if (i === s.lines) return;
  i = i.slice(-300);
  const u = Hn(i);
  Rt(t, {
    lines: i,
    result: s.busy ? { ...u, running: !0 } : u,
    external: r && u.running,
    lastLineAt: n
  });
}
function zh(t, e, n = Date.now() / 1e3) {
  const s = cs(t);
  if (s.restored || s.busy || s.lines.length > 0) {
    Rt(t, { restored: !0 });
    return;
  }
  const i = e.flatMap((p) => typeof p.message == "string" ? p.message.split(/\r?\n/) : []), r = Ch(i.map((p) => p.trim()).filter(Boolean)).slice(-300), o = Hn(r), u = Number(e[e.length - 1]?.time ?? 0), h = o.running && n - u < Qo;
  Rt(t, {
    restored: !0,
    lines: r,
    result: { ...o, running: h },
    external: h,
    lastLineAt: u
  });
}
function Ih(t, e = Date.now() / 1e3) {
  const n = cs(t);
  !n.external || n.busy || !n.result.running || e - n.lastLineAt < Qo || Rt(t, { external: !1, result: { ...n.result, running: !1 } });
}
class Uh {
  constructor(e = 30, n = 6e3) {
    this.windowSeconds = e, this.maxPoints = n;
  }
  #e = [];
  #s = [];
  /** Index of the first live point; points before it are waiting to be spliced. */
  #t = 0;
  get length() {
    return this.#e.length - this.#t;
  }
  push(e, n) {
    this.#e.push(e), this.#s.push(n);
    const s = e - this.windowSeconds;
    for (; this.#t < this.#e.length && this.#e[this.#t] < s; ) this.#t++;
    const i = this.length - this.maxPoints;
    i > 0 && (this.#t += i), this.#t > 1024 && this.#t > this.length && (this.#e.splice(0, this.#t), this.#s.splice(0, this.#t), this.#t = 0);
  }
  clear() {
    this.#e = [], this.#s = [], this.#t = 0;
  }
  /** Live times (a copy; uPlot keeps the arrays it is given). */
  times() {
    return this.#e.slice(this.#t);
  }
  values() {
    return this.#s.slice(this.#t);
  }
  last() {
    const e = this.#e.length - 1;
    return e >= this.#t ? { time: this.#e[e], value: this.#s[e] } : null;
  }
  /** Min / max of the live window, null when empty. */
  range() {
    if (this.length === 0) return null;
    let e = 1 / 0, n = -1 / 0;
    for (let s = this.#t; s < this.#s.length; s++) {
      const i = this.#s[s];
      i < e && (e = i), i > n && (n = i);
    }
    return { min: e, max: n };
  }
}
const Wh = 120;
class Vh {
  #e;
  #s = "";
  #t = null;
  #i = [];
  #r = null;
  #n = null;
  /** Live printer status for the Run button (re-read on mount, not kept in run-store). */
  printState = "";
  homedAxes = "";
  activeExtruder = "";
  klippyReady = !0;
  extruders = {};
  paStatus = null;
  // ----- live chart
  buffer = new Uh(Wh, 8e3);
  /** Bumped after every push so the chart element redraws. */
  version = 0;
  chart = { kind: null, state: "connecting", unit: "g", mainsActive: !0 };
  #o = !1;
  #l = "";
  #a = null;
  #c = "";
  #u = 0;
  constructor(e) {
    this.#e = e, e.addController(this);
  }
  get printerId() {
    return this.#s;
  }
  get state() {
    return cs(this.#s);
  }
  get isPrinting() {
    return this.printState === "printing" || this.printState === "paused";
  }
  get isHomed() {
    return this.homedAxes === "xyz";
  }
  get extruder() {
    return this.extruders[this.activeExtruder] ?? null;
  }
  get handle() {
    return this.#t;
  }
  hostConnected() {
    document.addEventListener("visibilitychange", this.#f), this.#h();
  }
  hostUpdate() {
    this.#t || this.#h();
  }
  hostDisconnected() {
    document.removeEventListener("visibilitychange", this.#f), this.#v();
  }
  #f = () => this.#m();
  #h() {
    const e = this.#e.api;
    if (!e || this.#t || !this.#e.isConnected) return;
    const n = () => {
      this.#v(), this.#h(), this.#e.requestUpdate();
    };
    this.#i.push(
      e.onPrinterChange(n),
      e.onPrintersChange((o) => {
        this.#s && !o.some((u) => u.id === this.#s) && n();
      })
    );
    const s = e.printer.id;
    if (!s) return;
    let i;
    try {
      i = e.moonrakerFor(s);
    } catch {
      return;
    }
    this.#t = i, this.#s = s;
    const r = this.#s;
    this.#i.push(Lh(r, () => this.#e.requestUpdate())), this.#i.push(
      i.subscribe(
        { print_stats: ["state"], toolhead: ["homed_axes", "extruder"], webhooks: ["state"] },
        (o) => {
          o?.print_stats?.state !== void 0 && (this.printState = String(o.print_stats.state)), o?.toolhead?.homed_axes !== void 0 && (this.homedAxes = String(o.toolhead.homed_axes)), o?.toolhead?.extruder !== void 0 && (this.activeExtruder = String(o.toolhead.extruder)), o?.webhooks?.state !== void 0 && (this.klippyReady = o.webhooks.state === "ready"), this.#e.requestUpdate();
        },
        { immediate: !0 }
      )
    ), this.#i.push(
      i.subscribe(
        {
          pa_tester: [
            "last_pressure_advance_test",
            "last_pressure_advance",
            "last_measured_pressure_advance",
            "last_corrected_pressure_advance"
          ]
        },
        (o) => {
          const u = o?.pa_tester;
          if (!u) return;
          const h = this.paStatus;
          this.paStatus = {
            test: typeof u.last_pressure_advance_test == "string" ? u.last_pressure_advance_test : h?.test ?? null,
            pa: typeof u.last_pressure_advance == "number" ? u.last_pressure_advance : h?.pa ?? null,
            measured: Array.isArray(u.last_measured_pressure_advance) ? u.last_measured_pressure_advance.filter((p) => typeof p == "number") : h?.measured ?? [],
            corrected: typeof u.last_corrected_pressure_advance == "number" ? u.last_corrected_pressure_advance : h?.corrected ?? null
          }, this.#e.requestUpdate();
        },
        { immediate: !0 }
      )
    ), this.#i.push(i.onNotify("notify_gcode_response", (o) => Hh(r, Rh(o)))), this.#i.push(
      i.onNotify("notify_klippy_ready", () => {
        Oh(r), this.#p();
      })
    ), this.#i.push(i.onNotify("notify_config_changed", () => void this.#p())), this.#n = setInterval(() => Ih(r), 3e4), this.state.config ? this.#b() : this.#p(), this.state.restored || this.#_(), this.#m();
  }
  #v() {
    for (const e of this.#i) e();
    this.#i = [], this.#r?.(), this.#r = null, this.#d(), this.#n && clearInterval(this.#n), this.#n = null, this.#t = null, this.#s = "";
  }
  /** Reads the printer config again (the "Check again" button of the not-installed panel). */
  recheck() {
    return this.#p();
  }
  async #p() {
    const e = this.#t, n = this.#s;
    if (e)
      try {
        const s = await dh(e);
        Rt(n, { config: s, configError: !1 }), this.#b(), this.#m();
      } catch {
        Rt(n, { configError: !0 });
      }
  }
  #b() {
    this.#r?.(), this.#r = null;
    const e = this.#t, n = this.state.config?.extruders ?? [];
    if (!e || n.length === 0) return;
    const s = ["temperature", "target", "pressure_advance", "can_extrude"];
    this.#r = e.subscribe(
      Object.fromEntries(n.map((i) => [i, s])),
      (i) => {
        for (const r of n) {
          const o = i?.[r];
          if (!o) continue;
          const u = this.extruders[r] ?? { temperature: null, target: null, pressureAdvance: null, canExtrude: null };
          this.extruders = {
            ...this.extruders,
            [r]: {
              temperature: typeof o.temperature == "number" ? o.temperature : u.temperature,
              target: typeof o.target == "number" ? o.target : u.target,
              pressureAdvance: typeof o.pressure_advance == "number" ? o.pressure_advance : u.pressureAdvance,
              canExtrude: typeof o.can_extrude == "boolean" ? o.can_extrude : u.canExtrude
            }
          };
        }
        this.#e.requestUpdate();
      },
      { immediate: !0 }
    );
  }
  async #_() {
    const e = this.#t, n = this.#s;
    if (e)
      try {
        const s = await e.request(
          "server.gcode_store",
          { count: 300 }
        );
        zh(n, s?.gcode_store ?? []);
      } catch {
        Rt(n, { restored: !0 });
      }
  }
  // ---------------------------------------------------------------- chart
  /** Asks for the trace of the load cell `sensor` (a section name, '' — automatic). */
  setChart(e, n = "") {
    this.#o === e && this.#l === n || (this.#o = e, this.#l = n, this.#m());
  }
  /**
   * Switches the mains filter (`hz` 0 = off). It acts on the incoming stream, so samples
   * already in the buffer keep the old setting: start the trace over rather than mix them.
   */
  setMains(e) {
    e !== this.#u && (this.#u = e, this.buffer.clear(), this.chart = { ...this.chart, mainsActive: !0 }, this.version++, this.#e.requestUpdate());
  }
  clearChart() {
    this.buffer.clear(), this.version++, this.#e.requestUpdate();
  }
  #d() {
    this.#a?.(), this.#a = null, this.#c = "";
  }
  #m() {
    const e = this.#t, n = this.state.config, i = this.#o && !document.hidden && e !== null && n !== null && n ? Nn(n, this.#l) : null, r = i ? `${this.#s}|${i.section}` : "";
    r !== this.#c && (this.#d(), !(!i || !e) && (this.#c = r, this.buffer.clear(), this.chart = { kind: null, state: "connecting", unit: this.chart.unit, mainsActive: !0 }, this.#a = _h(
      e,
      i,
      {
        onSamples: (o, u) => {
          u !== this.chart.unit && (this.buffer.clear(), this.chart = { ...this.chart, unit: u });
          for (const h of o) this.buffer.push(h.time, h.value);
          this.version++, this.#e.requestUpdate();
        },
        onSource: (o, u) => {
          this.chart.kind !== null && this.chart.kind !== o && this.buffer.clear(), this.chart = { ...this.chart, kind: o, state: u }, this.#e.requestUpdate();
        },
        onMains: (o) => {
          o !== this.chart.mainsActive && (this.chart = { ...this.chart, mainsActive: o }, this.#e.requestUpdate());
        }
      },
      void 0,
      () => this.#u
    ), this.#e.requestUpdate()));
  }
  // ------------------------------------------------------------- commands
  /**
   * Sends one command and waits for it. `printer.gcode.script` resolves only
   * when Klipper has finished it, i.e. after the whole measurement and the
   * calculation (minutes); the host proxy has no request timeout. Meanwhile
   * the console lines arrive live.
   */
  async run(e) {
    const n = this.#t, s = this.#s;
    if (!n || this.state.busy) return;
    Dh(s);
    let i;
    try {
      await n.request("printer.gcode.script", { script: e });
    } catch (r) {
      i = r instanceof Error ? r.message : String(r);
    } finally {
      Fh(s, i);
    }
  }
  /** A short command that is not a measurement (G28, SET_PRESSURE_ADVANCE): no run state. */
  async send(e) {
    if (!this.#t) return !1;
    try {
      return await this.#t.request("printer.gcode.script", { script: e }), !0;
    } catch (n) {
      return console.warn("[pa-tester] command failed:", e, n), !1;
    }
  }
}
const Gh = Yr`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
    min-width: 0;
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    font-size: var(--font-size-md);
    /* Width-based layout: the page area, not the window, decides (sidebars). */
    container-type: inline-size;
  }

  .panel {
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-width: 0;
  }
  .panel-header {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-sm) var(--space-md);
    border-bottom: 1px solid var(--border-color);
  }
  .panel-title {
    flex: 1;
    min-width: 0;
    font-size: var(--font-size-md);
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .panel-body {
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    min-width: 0;
  }

  .row { display: flex; align-items: center; gap: var(--space-sm); flex-wrap: wrap; }
  .muted { color: var(--text-muted); font-size: var(--font-size-sm); margin: 0; }
  .warn { color: var(--warning); font-size: var(--font-size-sm); margin: 0; }
  .error { color: var(--danger); font-size: var(--font-size-sm); margin: 0; }
  .ok { color: var(--success); font-size: var(--font-size-sm); margin: 0; }
  .mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }

  .chip {
    padding: 1px 8px;
    border-radius: 999px;
    border: 1px solid var(--border-color);
    background: var(--bg-surface-hover);
    color: var(--text-secondary);
    font-size: var(--font-size-sm);
    white-space: nowrap;
  }
  .chip.accent { border-color: var(--accent); color: var(--accent); font-weight: 600; }

  /* Command selector + gallery filters: same look as Calibrations' .sel-btn. */
  .sel-row { display: flex; gap: var(--space-xs); flex-wrap: wrap; }
  .sel-btn {
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-secondary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
  }
  .sel-btn:hover:not(:disabled) { background: var(--bg-surface-hover); }
  .sel-btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .sel-btn.active { background: var(--bg-surface-active); color: var(--accent); border-color: var(--accent); }

  .fields {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    gap: var(--space-sm);
  }
  .field { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
  .field-label { font-size: var(--font-size-sm); color: var(--text-secondary); }
  .field.invalid .field-label { color: var(--danger); }
  input, select {
    min-width: 0;
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
  }
  .field.invalid input { border-color: var(--danger); }
  input.num { inline-size: 7rem; }
  /* checkbox rows and uncaptioned controls sit on the baseline of the captioned fields */
  .check {
    display: inline-flex;
    align-items: center;
    gap: var(--space-xs);
    align-self: flex-end;
    min-height: 32px;
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    cursor: pointer;
  }
  .end { align-self: flex-end; }
  .chip.warn-chip { border-color: var(--warning); color: var(--warning); white-space: normal; }

  .gcode {
    display: block;
    padding: var(--space-xs) var(--space-sm);
    background: var(--bg-surface-hover-no-override, var(--bg-surface-hover));
    border: 1px dashed var(--border-color);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    white-space: pre-wrap;
    word-break: break-all;
    user-select: text;
  }

  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-xs);
    padding: var(--space-xs) var(--space-md);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface-hover);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
    white-space: nowrap;
  }
  .btn:hover:not(:disabled) { background: var(--bg-surface-active); }
  .btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .btn.primary { background: var(--accent); border-color: var(--accent); color: var(--accent-text, #fff); }
  .btn:focus-visible, .sel-btn:focus-visible {
    outline: 2px solid var(--accent-ring, var(--accent));
    outline-offset: 1px;
  }
  .icon-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    width: 28px;
    height: 28px;
    padding: 0;
    border: none;
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-muted);
    cursor: pointer;
    font-size: 15px;
    line-height: 1;
  }
  .icon-btn:hover { background: var(--bg-surface-hover); color: var(--text-primary); }
  .icon-btn.active { background: var(--accent); color: var(--accent-text, #fff); }
  .icon-btn svg { display: block; }

  .spinner {
    width: 12px;
    height: 12px;
    border: 2px solid currentColor;
    border-right-color: transparent;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    flex-shrink: 0;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  .card {
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    padding: var(--space-sm);
    display: flex;
    flex-direction: column;
    gap: var(--space-xs);
  }
  .card h4 { margin: 0; font-size: var(--font-size-sm); font-weight: 600; }

  table { width: 100%; border-collapse: collapse; font-size: var(--font-size-sm); }
  th, td { padding: var(--space-xs) var(--space-sm); text-align: start; border-bottom: 1px solid var(--border-color); }
  th { color: var(--text-muted); font-weight: 500; text-transform: uppercase; letter-spacing: 0.04em; }

  details.log summary { cursor: pointer; color: var(--text-secondary); font-size: var(--font-size-sm); }
  details.log pre {
    margin: var(--space-xs) 0 0;
    max-height: 200px;
    overflow: auto;
    padding: var(--space-sm);
    background: var(--bg-surface-hover);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    white-space: pre-wrap;
    word-break: break-word;
  }
  details.log pre .err { color: var(--danger); }

  /*
   * Help popover: same look as the host's HeaderHelp. It is a [popover] in the
   * top layer (see #placeHelp in pa-tab.ts); the UA style centres popovers
   * (inset: 0; margin: auto), we drop that and set top/left/right from JS.
   */
  .help-menu {
    position: fixed;
    inset: auto;
    margin: 0;
    min-width: min(280px, calc(100vw - 16px));
    max-width: min(380px, calc(100vw - 16px));
    max-height: calc(100vh - 16px);
    overflow-y: auto;
    padding: var(--space-sm);
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-md, 0 4px 12px rgba(0, 0, 0, 0.15));
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
  }
  .help-menu:popover-open { display: flex; flex-direction: column; gap: var(--space-sm); }
  .help-title {
    padding: var(--space-xs) var(--space-sm);
    font-size: var(--font-size-sm);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    color: var(--text-muted);
  }
  .help-body {
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    padding: 0 var(--space-sm) var(--space-xs);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    line-height: 1.5;
  }
  .help-body h4 { margin: var(--space-xs) 0 2px; color: var(--text-primary); font-size: var(--font-size-sm); font-weight: 600; }
  .help-body p { margin: 0; }

  .gcode-row { display: flex; gap: var(--space-sm); align-items: stretch; }
  .gcode-row .gcode { flex: 1; min-width: 0; }
  ol.steps { margin: 0; padding-inline-start: 1.4em; display: flex; flex-direction: column; gap: var(--space-xs); }
  ol.steps li { color: var(--text-secondary); font-size: var(--font-size-sm); }
  ol.steps li .gcode { margin-top: 2px; }
  a { color: var(--accent); }
  .row.end { justify-content: flex-end; }
  b { font-weight: 600; }

  /*
   * Confirmation of PA_CALIBRATE: a native <dialog> opened with showModal()
   * lives in the browser's TOP LAYER. The Calibrations page is a size container
   * (container-type), which makes it the containing block of position:fixed
   * descendants, so a fixed div of ours would be clipped to the page area.
   */
  dialog.confirm {
    padding: 0;
    border: 1px solid var(--border-color);
    border-radius: var(--radius-lg);
    background: var(--bg-surface);
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    max-width: min(460px, 94vw);
  }
  dialog.confirm::backdrop { background: var(--bg-overlay, rgba(0, 0, 0, 0.6)); }
  .confirm-body { display: flex; flex-direction: column; gap: var(--space-sm); padding: var(--space-md); }
  .confirm-body h3 { margin: 0; font-size: var(--font-size-md); }
  .confirm-body p { margin: 0; color: var(--text-secondary); font-size: var(--font-size-sm); }

  @container (max-width: 480px) {
    .panel-body { padding: var(--space-sm); }
    .fields { grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); }
  }
  @media (pointer: coarse) {
    .icon-btn { width: 36px; height: 36px; }
    .sel-btn, .btn, .check, select, input.num { min-height: 36px; }
  }
`, Bh = I`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor"
  stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
  <circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
  <line x1="12" y1="17" x2="12.01" y2="17"></line>
</svg>`, Kr = [30, 60, 120], Kh = "https://github.com/dmbutyugin/klipper/tree/generic-cartesian", sn = (t, e = 4) => t == null ? "—" : t.toFixed(e);
class jh extends Ti {
  static styles = Gh;
  static properties = {
    ...Ti.properties,
    command: { state: !0 },
    method: { state: !0 },
    values: { state: !0 },
    chartOpen: { state: !0 },
    chartSeconds: { state: !0 },
    chartPaused: { state: !0 },
    chartFilter: { state: !0 },
    chartFilterMs: { state: !0 },
    chartRaw: { state: !0 },
    chartMains: { state: !0 },
    chartMainsHz: { state: !0 },
    copied: { state: !0 },
    helpOpen: { state: !0 }
  };
  #e = new Vh(this);
  /** Printer whose settings are loaded into the fields. */
  #s = "";
  #t = null;
  #i = null;
  constructor() {
    super(), this.command = "test", this.method = "step_response", this.values = {}, this.chartOpen = !0, this.chartSeconds = 30, this.chartPaused = !1, this.chartFilter = "raw", this.chartFilterMs = cl, this.chartRaw = !1, this.chartMains = !1, this.chartMainsHz = 50, this.copied = null, this.helpOpen = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.#i = this.api?.onThemeChange(() => this.renderRoot.querySelector("tessera-pa-force-chart")?.restyle()) ?? null;
  }
  willUpdate(e) {
    super.willUpdate(e);
    const n = this.#e.printerId;
    this.api && n && n !== this.#s && (this.#s = n, this.#r()), this.#e.setChart(this.chartOpen && this.#o(), this.values.FORCE_SENSOR ?? ""), this.#e.setMains(this.chartMains ? this.chartMainsHz : 0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.#i?.(), this.#i = null, this.#S(!1), this.#s = "", this.#t && clearTimeout(this.#t);
  }
  #r() {
    const e = this.api.settingsFor(this.#s), n = e.get("command");
    this.command = dn.some((r) => r.id === n) ? n : "test";
    const s = e.get("method");
    this.method = s && Ur.includes(s) ? s : "step_response", this.values = e.get("values") ?? {}, this.chartOpen = e.get("chartOpen") ?? !0;
    const i = e.get("chartSeconds");
    this.chartSeconds = Kr.includes(i) ? i : 30, this.chartFilter = Ir(e.get("chartFilter")), this.chartFilterMs = zi(e.get("chartFilterMs")), this.chartRaw = e.get("chartRaw") ?? !1, this.chartMains = e.get("chartMains") ?? !1, this.chartMainsHz = Vr(e.get("chartMainsHz"));
  }
  #n(e, n) {
    this.api && this.#s && this.api.settingsFor(this.#s).set(e, n);
  }
  #o() {
    const e = this.#e.state.config;
    return !!(e?.hasPaTester && Nn(e, this.values.FORCE_SENSOR ?? ""));
  }
  // ---------------------------------------------------------------- actions
  #l(e) {
    this.command = e, this.#n("command", e);
  }
  #a(e) {
    this.method = e, this.#n("method", e);
  }
  #c(e, n) {
    this.values = { ...this.values, [e]: n }, this.#n("values", this.values);
  }
  #u() {
    this.chartOpen = !this.chartOpen, this.#n("chartOpen", this.chartOpen);
  }
  #f(e) {
    this.chartSeconds = e, this.#n("chartSeconds", e);
  }
  #h(e) {
    this.chartFilter = e, this.#n("chartFilter", e);
  }
  #v(e) {
    Number.isFinite(e) && (this.chartFilterMs = zi(e), this.#n("chartFilterMs", this.chartFilterMs));
  }
  #p(e) {
    this.chartRaw = e, this.#n("chartRaw", e);
  }
  #b(e) {
    this.chartMains = e, this.#n("chartMains", e);
  }
  #_(e) {
    this.chartMainsHz = e, this.#n("chartMainsHz", e);
  }
  /** Memo of the filtered extremes: the tab renders on every batch, the filter should not rerun for that. */
  #d = null;
  /**
   * Min / max of the drawn trace: the raw window, or the filtered curve (for the envelope
   * its lower and upper lines). Null when there is nothing to show.
   */
  #m() {
    const e = this.#e.buffer;
    if (this.chartFilter === "raw") return e.range();
    if (e.length === 0) return null;
    const n = `${this.#e.version}|${this.#e.printerId}|${this.chartFilter}|${this.chartFilterMs}`;
    if (this.#d?.key !== n) {
      const s = Ko(this.chartFilter, this.chartFilterMs, e.times(), e.values()).cols, i = s[0], r = s[s.length - 1];
      let o = 1 / 0, u = -1 / 0;
      for (let h = 0; h < i.length; h++)
        i[h] < o && (o = i[h]), r[h] > u && (u = r[h]);
      this.#d = { key: n, min: o, max: u };
    }
    return this.#d;
  }
  #x(e) {
    return this.t(`patester.chart.filter_${e}`);
  }
  #$() {
    const e = en(this.command), n = tn(e, this.method, this.values);
    n.invalid.length || this.#w() || (e.applies ? this.renderRoot.querySelector("dialog")?.showModal() : this.#e.run(n.script));
  }
  #E() {
    const e = tn(en(this.command), this.method, this.values);
    this.renderRoot.querySelector("dialog")?.close(), !(e.invalid.length || this.#w()) && this.#e.run(e.script);
  }
  async #A() {
    const e = Wr(this.#e.state.result.value, this.#e.activeExtruder || null);
    e && await this.#e.send(e);
  }
  async #y(e, n) {
    try {
      await navigator.clipboard.writeText(e);
    } catch {
      window.prompt(this.t("patester.common.copyManually"), e);
      return;
    }
    this.copied = n, this.#t && clearTimeout(this.#t), this.#t = setTimeout(() => this.copied = null, 1500);
  }
  // ------------------------------------------------------------------ help
  /**
   * The help popover lives in the browser's TOP LAYER (Popover API): our panel
   * clips its content and the Calibrations page is a size container, so a
   * positioned div of ours could not leave the page area. `popover="auto"`
   * brings light dismiss for free; we place it next to the button like the
   * host's HeaderHelp does.
   */
  #g = () => {
    const e = this.renderRoot.querySelector(".help-btn"), n = this.renderRoot.querySelector(".help-menu");
    if (!e || !n) return;
    const s = e.getBoundingClientRect(), i = n.offsetHeight, r = n.offsetWidth, o = window.innerHeight - s.bottom - 4, u = i <= o ? s.bottom + 4 : i <= s.top - 4 ? s.top - 4 - i : Math.max(8, window.innerHeight - i - 8);
    if (n.style.top = `${u}px`, document.documentElement.getAttribute("dir") === "rtl")
      n.style.left = `${Math.min(Math.max(8, s.left), Math.max(8, window.innerWidth - r - 8))}px`, n.style.right = "auto";
    else {
      const h = Math.min(Math.max(8, window.innerWidth - s.right), Math.max(8, window.innerWidth - r - 8));
      n.style.right = `${h}px`, n.style.left = "auto";
    }
  };
  #S(e) {
    window.removeEventListener("resize", this.#g), document.removeEventListener("scroll", this.#g, !0), e && (window.addEventListener("resize", this.#g), document.addEventListener("scroll", this.#g, !0));
  }
  #k(e) {
    this.helpOpen = e.newState === "open", this.helpOpen && this.#g(), this.#S(this.helpOpen);
  }
  /** Why Run is not possible now, or null. Our own requests skip our guard (see guard.ts), so we check here. */
  #w() {
    const e = this.#e, n = e.state.config;
    return e.klippyReady ? e.state.busy || e.state.result.running ? this.t("patester.block.running") : e.isPrinting ? this.t("patester.block.printing") : e.isHomed ? n && !Nn(n, this.values.FORCE_SENSOR ?? "") ? n.loadCells.length === 0 ? this.t("patester.block.noSensor") : this.t("patester.block.ambiguous") : e.extruder?.canExtrude === !1 ? this.t("patester.block.cold") : null : this.t("patester.block.homing") : this.t("patester.block.klippy");
  }
  // ---------------------------------------------------------------- render
  render() {
    const e = this.#e.state;
    return !this.api || !this.#e.printerId ? I`<p class="muted">${this.t("patester.common.noPrinter")}</p>` : e.config ? e.config.hasPaTester ? I`${this.#C()}${this.#L()}${this.#N()}` : this.#T(e.config.loadCells.length > 0) : I`<section class="panel"><div class="panel-body">
        <p class="muted">${e.configError ? this.t("patester.common.configError") : this.t("patester.common.loading")}</p>
      </div></section>`;
  }
  /**
   * No `[pa_tester]` section. The tab is always shown (no `available` export),
   * so this is what the user finds: where the module lives and what to add.
   * The config is re-read on `notify_klippy_ready` / `notify_config_changed`
   * (PaController), and by the button for the impatient.
   */
  #T(e) {
    return I`<section class="panel">
      <div class="panel-header">
        <span class="panel-title">${this.t("patester.install.title")}</span>
        <button type="button" class="btn" @click=${() => void this.#e.recheck()}>${this.t("patester.install.recheck")}</button>
      </div>
      <div class="panel-body">
        <p>${this.t("patester.install.intro")}</p>
        ${e ? B : I`<p class="warn">${this.t("patester.install.noLoadCell")}</p>`}
        <ol class="steps">
          <li>
            ${this.t("patester.install.stepModule")}
            <a href=${Kh} target="_blank" rel="noopener noreferrer">dmbutyugin/klipper (generic-cartesian)</a>
          </li>
          <li>${this.t("patester.install.stepNumpy")}</li>
          <li>
            ${this.t("patester.install.stepConfig")}
            <code class="gcode">[pa_tester]
force_sensor: load_cell
high_flow: 12
purge_length: 30</code>
          </li>
          <li>${this.t("patester.install.stepExtruder")}</li>
          <li>${this.t("patester.install.stepRestart")}</li>
        </ol>
      </div>
    </section>`;
  }
  #R() {
    const e = this.t("patester.help.title");
    return I`
      <button
        class="icon-btn help-btn ${this.helpOpen ? "active" : ""}"
        popovertarget="pa-help"
        title=${e}
        aria-label=${e}
      >${Bh}</button>
      <div id="pa-help" class="help-menu" popover="auto" role="dialog" aria-label=${e} @toggle=${this.#k}>
        <div class="help-title">${e}</div>
        <div class="help-body">
          <h4>${this.t("patester.help.runTitle")}</h4>
          <p>${this.t("patester.help.run")}</p>
          <h4>${this.t("patester.help.applyTitle")}</h4>
          <p>${this.t("patester.help.apply")}</p>
          <h4>${this.t("patester.help.chartTitle")}</h4>
          <p>${this.t("patester.help.chart")}</p>
        </div>
      </div>
    `;
  }
  #M(e) {
    const n = Ii(this.method).find((g) => g.key === e), s = this.#e.state.config, i = this.values[e] ?? "", o = tn(en(this.command), this.method, this.values).invalid.includes(e), u = this.#e.state.busy, h = (g) => this.#c(e, g.target.value);
    let p;
    if (n.type === "sensor" || n.type === "extruder") {
      const g = n.type === "sensor" ? s.loadCells.map((d) => d.section) : s.extruders;
      p = I`<select .value=${i} ?disabled=${u} @change=${h}>
        <option value="">${this.t("patester.common.default")}</option>
        ${g.map((d) => I`<option value=${d} ?selected=${d === i}>${d}</option>`)}
      </select>`;
    } else if (n.type === "sign")
      p = I`<select .value=${i} ?disabled=${u} @change=${h}>
        <option value="">${this.t("patester.common.default")}</option>
        ${["-1", "0", "1"].map((g) => I`<option value=${g} ?selected=${g === i}>${g}</option>`)}
      </select>`;
    else {
      const g = s.options[e.toLowerCase()];
      p = I`<input
        type=${n.type === "range" ? "text" : "number"}
        inputmode="decimal"
        step=${n.type === "int" ? "1" : "any"}
        placeholder=${g ?? n.placeholder ?? "—"}
        .value=${i}
        ?disabled=${u}
        @input=${h}
      />`;
    }
    return I`<label class="field ${o ? "invalid" : ""}" title=${this.t(`patester.param.${e}`)}>
      <span class="field-label mono">${e}</span>
      ${p}
    </label>`;
  }
  #C() {
    const e = this.#e, n = e.state, s = n.result, i = en(this.command), r = tn(i, this.method, this.values), o = this.#w(), u = n.busy || s.running, h = e.extruder?.pressureAdvance ?? null, p = Wr(s.value, e.activeExtruder || null);
    return I`
      <section class="panel">
        <header class="panel-header">
          <span class="panel-title">${this.t("patester.title")}</span>
          ${h !== null ? I`<span class="chip mono" title=${this.t("patester.result.current")}>PA ${sn(h, 4)}</span>` : B}
          ${this.#R()}
        </header>
        <div class="panel-body">
          <div class="sel-row" role="radiogroup" aria-label=${this.t("patester.command.label")}>
            ${dn.map(
      (g) => I`<button
                class="sel-btn ${g.id === this.command ? "active" : ""}"
                role="radio"
                aria-checked=${g.id === this.command}
                ?disabled=${n.busy}
                title=${g.gcode}
                @click=${() => this.#l(g.id)}
              >${this.t(`patester.command.${g.id}`)}</button>`
    )}
          </div>
          <p class="muted">${this.t(`patester.command.${this.command}Hint`)}</p>

          <div class="sel-row" role="radiogroup" aria-label=${this.t("patester.method.label")}>
            ${Ur.map(
      (g) => I`<button
                class="sel-btn ${g === this.method ? "active" : ""}"
                role="radio"
                aria-checked=${g === this.method}
                ?disabled=${n.busy}
                @click=${() => this.#a(g)}
              >${this.t(`patester.method.${g}`)}</button>`
    )}
          </div>
          <p class="muted">${this.t(`patester.method.${this.method}Hint`)}</p>

          <div class="fields">${Ii(this.method).map((g) => this.#M(g.key))}</div>

          ${r.invalid.length ? I`<p class="error">${this.t("patester.block.invalid", { fields: r.invalid.join(", ") })}</p>` : B}
          ${o && !u ? I`<p class="warn">${o}</p>` : B}

          <div class="gcode-row">
            <code class="gcode mono">${r.script}</code>
            <button class="btn" @click=${() => void this.#y(r.script, "gcode")}>
              ${this.copied === "gcode" ? this.t("patester.common.copied") : this.t("patester.common.copy")}
            </button>
          </div>
          <div class="row">
            <button class="btn primary" ?disabled=${!!o || r.invalid.length > 0} @click=${() => this.#$()}>
              ${u ? I`<span class="spinner"></span> ${this.t("patester.run.running")}` : this.t(`patester.run.${this.command}`)}
            </button>
            ${!e.isHomed && e.klippyReady && !u && !e.isPrinting ? I`<button class="btn" @click=${() => void e.send("G28")}>${this.t("patester.run.home")}</button>` : B}
          </div>

          ${u ? I`<p class="row muted">
                <span class="spinner"></span>
                ${n.external ? I`<span class="chip">${this.t("patester.run.external")}</span>` : B}
                ${this.t("patester.run.started")}
              </p>` : B}
          ${s.error ? I`<p class="error">${s.error}</p>` : B}

          ${this.#P(p, u)}

          ${n.lines.length ? I`<details class="log">
                <summary>${this.t("patester.run.log", { count: n.lines.length })}</summary>
                <pre class="mono">${n.lines.map((g) => I`<span class=${g.startsWith("!!") ? "err" : ""}>${g}\n</span>`)}</pre>
              </details>` : B}
        </div>
      </section>
    `;
  }
  #P(e, n) {
    const s = this.#e.state.result, i = this.#e.paStatus;
    return s.perFlow.length || s.search.length || s.overall !== null || s.found !== null ? I`
      <div class="card">
        <h4>${this.t("patester.result.title")}</h4>
        ${s.perFlow.length ? I`<table>
              <thead><tr><th>${this.t("patester.result.flow")}</th><th>${this.t("patester.result.pa")}</th></tr></thead>
              <tbody>${s.perFlow.map(
      (o) => I`<tr><td class="mono">${o.flow.toFixed(2)}</td><td class="mono">${o.pa.toFixed(3)}</td></tr>`
    )}</tbody>
            </table>` : B}
        ${s.search.length ? I`<table>
              <thead><tr><th>${this.t("patester.result.tested")}</th><th></th></tr></thead>
              <tbody>${s.search.map(
      (o) => I`<tr>
                  <td class="mono">${o.pa.toFixed(4)}</td>
                  <td>${o.overshoot ? this.t("patester.result.overshoot") : this.t("patester.result.noOvershoot")}</td>
                </tr>`
    )}</tbody>
            </table>` : B}
        ${s.overall !== null ? I`<p class="ok">${this.t("patester.result.overall")}: <b class="mono">${sn(s.overall, 3)}</b></p>` : B}
        ${s.found !== null ? I`<p class="ok">${this.t("patester.result.found")}: <b class="mono">${sn(s.found)}</b></p>` : B}
        ${s.corrected !== null ? I`<p class="ok">${this.t("patester.result.corrected")}: <b class="mono">${sn(s.corrected)}</b></p>` : B}
        ${s.forceSign !== null ? I`<p class="muted">${this.t("patester.result.forceSign", { sign: s.forceSign })}</p>` : B}
        ${s.warnings.map((o) => I`<p class="warn">${o}</p>`)}
        ${e && !n && this.command === "test" && this.#e.klippyReady ? I`<div class="row">
              <button class="btn" @click=${() => void this.#A()}>${this.t("patester.run.applyMeasured")}</button>
              <button class="btn" @click=${() => void this.#y(e, "apply")}>
                ${this.copied === "apply" ? this.t("patester.common.copied") : this.t("patester.common.copy")}
              </button>
              <code class="mono muted">${e}</code>
            </div>
            <p class="muted">${this.t("patester.run.saveHint")}</p>` : B}
      </div>
    ` : i?.pa !== null && i?.pa !== void 0 ? I`<p class="muted">${this.t("patester.result.lastKlipper", { test: i.test ?? "—", pa: sn(i.pa) })}</p>` : B;
  }
  #N() {
    const e = tn(en(this.command), this.method, this.values);
    return I`<dialog class="confirm" @click=${(n) => n.target === n.currentTarget && n.currentTarget.close()}>
      <div class="confirm-body">
        <h3>${this.t("patester.confirm.title")}</h3>
        <p>${this.t("patester.confirm.body")}</p>
        <code class="gcode mono">${e.script}</code>
        <div class="row end">
          <button class="btn" @click=${(n) => n.currentTarget.closest("dialog").close()}>
            ${this.t("patester.confirm.cancel")}
          </button>
          <button class="btn primary" @click=${() => this.#E()}>${this.t("patester.confirm.ok")}</button>
        </div>
      </div>
    </dialog>`;
  }
  #L() {
    const e = this.#e, n = e.state.config, s = Nn(n, this.values.FORCE_SENSOR ?? ""), i = e.buffer.last(), r = this.#m(), o = e.chart.unit === "g" ? "g" : this.t("patester.chart.counts"), u = e.chart.unit === "g" ? 2 : 0, h = (d) => d === void 0 ? "—" : `${d.toFixed(u)} ${o}`;
    let p = B;
    e.chart.kind === "stream" && e.chart.state === "live" ? p = I`<span class="chip">${this.t("patester.chart.sourceStream")}</span>` : e.chart.kind === "status" && (p = I`<span class="chip" title=${this.t("patester.chart.sourceStatusHint")}>${this.t("patester.chart.sourceStatus")}</span>`);
    let g = this.t("patester.chart.noData");
    return s ? this.chartOpen ? e.chart.state === "connecting" && (g = this.t("patester.chart.connecting")) : g = "" : g = n.loadCells.length ? this.t("patester.block.ambiguous") : this.t("patester.block.noSensor"), I`
      <section class="panel">
        <header class="panel-header">
          <span class="panel-title">${this.t("patester.chart.title")}</span>
          ${s ? I`<span class="chip mono" title=${s.section}>${s.section}</span>` : B}
          ${this.chartOpen ? p : B}
          <button class="btn" @click=${() => this.#u()}>
            ${this.chartOpen ? this.t("patester.chart.hide") : this.t("patester.chart.show")}
          </button>
        </header>
        ${this.chartOpen ? I`<div class="panel-body">
              <div class="row">
                <span class="chip mono">${this.t("patester.chart.now")} ${h(i?.value)}</span>
                <span class="chip mono">${this.t("patester.chart.min")} ${h(r?.min)}</span>
                <span class="chip mono">${this.t("patester.chart.max")} ${h(r?.max)}</span>
              </div>
              <tessera-pa-force-chart
                .buffer=${e.buffer}
                .version=${e.version}
                .unit=${e.chart.unit}
                .seconds=${this.chartSeconds}
                .paused=${this.chartPaused}
                .filter=${this.chartFilter}
                .filterMs=${this.chartFilterMs}
                .showRaw=${this.chartRaw}
                .emptyText=${g}
              ></tessera-pa-force-chart>
              <div class="row">
                <div class="sel-row" role="radiogroup" aria-label=${this.t("patester.chart.window")}>
                  ${Kr.map(
      (d) => I`<button
                      class="sel-btn ${d === this.chartSeconds ? "active" : ""}"
                      role="radio"
                      aria-checked=${d === this.chartSeconds}
                      @click=${() => this.#f(d)}
                    >${d} ${this.t("patester.chart.sec")}</button>`
    )}
                </div>
                <button class="btn" @click=${() => this.chartPaused = !this.chartPaused}>
                  ${this.chartPaused ? this.t("patester.chart.resume") : this.t("patester.chart.pause")}
                </button>
                <button class="btn" @click=${() => e.clearChart()}>${this.t("patester.chart.clear")}</button>
              </div>
              <div class="row">
                <label class="field">
                  <span class="field-label">${this.t("patester.chart.filter")}</span>
                  <select @change=${(d) => this.#h(Ir(d.target.value))}>
                    ${Vo.map(
      (d) => I`<option value=${d} ?selected=${d === this.chartFilter}>${this.#x(d)}</option>`
    )}
                  </select>
                </label>
                ${this.chartFilter !== "raw" ? I`<label class="field">
                        <span class="field-label">${this.t("patester.chart.filterMs")}, ${this.t("patester.chart.ms")}</span>
                        <input
                          class="num"
                          type="number"
                          dir="ltr"
                          inputmode="numeric"
                          min=${Go}
                          max=${Bo}
                          step="10"
                          .value=${String(this.chartFilterMs)}
                          @change=${(d) => this.#v(d.target.valueAsNumber)}
                        />
                      </label>
                      <label class="check">
                        <input type="checkbox" .checked=${this.chartRaw} @change=${(d) => this.#p(d.target.checked)} />
                        <span>${this.t("patester.chart.showRaw")}</span>
                      </label>` : B}
                <label class="check">
                  <input type="checkbox" .checked=${this.chartMains} @change=${(d) => this.#b(d.target.checked)} />
                  <span>${this.t("patester.chart.mains")}</span>
                </label>
                ${this.chartMains ? I`<select
                        class="end"
                        aria-label=${this.t("patester.chart.mainsHz")}
                        @change=${(d) => this.#_(Vr(Number(d.target.value)))}
                      >
                        ${oh.map((d) => I`<option value=${d} ?selected=${d === this.chartMainsHz}>${d} ${this.t("patester.chart.hz")}</option>`)}
                      </select>
                      ${e.chart.mainsActive ? B : I`<span class="chip warn-chip end">${this.t("patester.chart.mainsLowRate")}</span>`}` : B}
              </div>
              <p class="muted">${this.t("patester.chart.tare")}</p>
            </div>` : B}
      </section>
    `;
  }
}
const qh = 3e3;
async function Yh(t) {
  const e = Za();
  if (!e) return null;
  const n = e.moonrakerFor(t);
  try {
    const s = async () => {
      const r = (await n.request("printer.objects.query", {
        objects: { print_stats: ["state"], toolhead: ["homed_axes", "extruder"], configfile: ["settings"] }
      }))?.status ?? {}, o = String(r.toolhead?.extruder ?? "");
      let u = null;
      if (o) {
        const h = r.configfile?.settings ?? {}, p = Number(h[o]?.min_extrude_temp), d = (await n.request("printer.objects.query", {
          objects: { [o]: ["temperature"] }
        }))?.status?.[o]?.temperature;
        Number.isFinite(p) && typeof d == "number" && (u = d < p);
      }
      return {
        printState: String(r.print_stats?.state ?? ""),
        homedAxes: String(r.toolhead?.homed_axes ?? ""),
        cold: u
      };
    };
    return await Promise.race([
      s(),
      new Promise((i) => setTimeout(() => i(null), qh))
    ]);
  } catch {
    return null;
  }
}
async function Qh(t, e, n) {
  if (t.method !== "printer.gcode.script") return { action: "allow" };
  const s = String(t.params?.script ?? "");
  if (!rh(s).some((r) => lh.has(r))) return { action: "allow" };
  const i = await Yh(n.targetPrinterId);
  return i ? i.printState === "printing" || i.printState === "paused" ? { action: "deny", reasonKey: "patester.guard.printing" } : i.homedAxes !== "xyz" ? { action: "deny", reasonKey: "patester.guard.homing" } : i.cold === !0 ? { action: "deny", reasonKey: "patester.guard.cold" } : { action: "allow" } : { action: "allow" };
}
qi("tessera-pa-tester-tab", jh);
qi("tessera-pa-tester-bridge", ec);
qi("tessera-pa-force-chart", Xu);
const Xh = { en: Qa, ru: Xa };
export {
  Qh as guardPaTester,
  Xh as locales
};
