var we, h, yt, bt, L, Xe, kt, wt, Ne, ue, Q, xt, Re, Fe, Le, St, _e = {}, me = [], un = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i, xe = Array.isArray;
function E(t, e) {
  for (var n in e) t[n] = e[n];
  return t;
}
function We(t) {
  t && t.parentNode && t.parentNode.removeChild(t);
}
function he(t, e, n) {
  var o, r, i, s = {};
  for (i in e) i == "key" ? o = e[i] : i == "ref" ? r = e[i] : s[i] = e[i];
  if (arguments.length > 2 && (s.children = arguments.length > 3 ? we.call(arguments, 2) : n), typeof t == "function" && t.defaultProps != null) for (i in t.defaultProps) s[i] === void 0 && (s[i] = t.defaultProps[i]);
  return pe(t, s, o, r, null);
}
function pe(t, e, n, o, r) {
  var i = { type: t, props: e, key: n, ref: o, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: r ?? ++yt, __i: -1, __u: 0 };
  return r == null && h.vnode != null && h.vnode(i), i;
}
function D(t) {
  return t.children;
}
function Z(t, e) {
  this.props = t, this.context = e;
}
function j(t, e) {
  if (e == null) return t.__ ? j(t.__, t.__i + 1) : null;
  for (var n; e < t.__k.length; e++) if ((n = t.__k[e]) != null && n.__e != null) return n.__e;
  return typeof t.type == "function" ? j(t) : null;
}
function pn(t) {
  if (t.__P && t.__d) {
    var e = t.__v, n = e.__e, o = [], r = [], i = E({}, e);
    i.__v = e.__v + 1, h.vnode && h.vnode(i), ze(t.__P, i, e, t.__n, t.__P.namespaceURI, 32 & e.__u ? [n] : null, o, n ?? j(e), !!(32 & e.__u), r), i.__v = e.__v, i.__.__k[i.__i] = i, Nt(o, i, r), e.__e = e.__ = null, i.__e != n && $t(i);
  }
}
function $t(t) {
  if ((t = t.__) != null && t.__c != null) return t.__e = t.__c.base = null, t.__k.some(function(e) {
    if (e != null && e.__e != null) return t.__e = t.__c.base = e.__e;
  }), $t(t);
}
function He(t) {
  (!t.__d && (t.__d = !0) && L.push(t) && !ve.__r++ || Xe != h.debounceRendering) && ((Xe = h.debounceRendering) || kt)(ve);
}
function ve() {
  try {
    for (var t, e = 1; L.length; ) L.length > e && L.sort(wt), t = L.shift(), e = L.length, pn(t);
  } finally {
    L.length = ve.__r = 0;
  }
}
function Ct(t, e, n, o, r, i, s, c, p, l, f) {
  var _, a, d, g, T, w, b = o && o.__k || me, m = e.length;
  for (p = fn(n, e, b, p, m), _ = 0; _ < m; _++) (d = n.__k[_]) != null && (a = d.__i != -1 && b[d.__i] || _e, d.__i = _, w = ze(t, d, a, r, i, s, c, p, l, f), g = d.__e, d.ref && a.ref != d.ref && (a.ref && Be(a.ref, null, d), f.push(d.ref, d.__c || g, d)), T == null && g != null && (T = g), 4 & d.__u ? (p = Tt(d, p, t), a.__e && (a.__e = null)) : typeof d.type == "function" && w !== void 0 ? p = w : g && (p = g.nextSibling), d.__u &= -7);
  return n.__e = T, p;
}
function fn(t, e, n, o, r) {
  var i, s, c, p, l, f = n.length, _ = f, a = 0;
  for (t.__k = new Array(r), i = 0; i < r; i++) (s = e[i]) != null && typeof s != "boolean" && typeof s != "function" ? (typeof s == "string" || typeof s == "number" || typeof s == "bigint" || s.constructor == String ? s = t.__k[i] = pe(null, s, null, null, null) : xe(s) ? s = t.__k[i] = pe(D, { children: s }, null, null, null) : s.constructor === void 0 && s.__b > 0 ? s = t.__k[i] = pe(s.type, s.props, s.key, s.ref ? s.ref : null, s.__v) : t.__k[i] = s, p = i + a, s.__ = t, s.__b = t.__b + 1, c = null, (l = s.__i = dn(s, n, p, _)) != -1 && (_--, (c = n[l]) && (c.__u |= 2)), c == null || c.__v == null ? (l == -1 && (r > f ? a-- : r < f && a++), typeof s.type != "function" && (s.__u |= 4)) : l != p && (l == p - 1 ? a-- : l == p + 1 ? a++ : (l > p ? a-- : a++, s.__u |= 4))) : t.__k[i] = null;
  if (_) for (i = 0; i < f; i++) (c = n[i]) != null && (2 & c.__u) == 0 && (c.__e == o && (o = j(c)), Et(c, c));
  return o;
}
function Tt(t, e, n) {
  var o, r;
  if (typeof t.type == "function") {
    for (o = t.__k, r = 0; o && r < o.length; r++) o[r] && (o[r].__ = t, e = Tt(o[r], e, n));
    return e;
  }
  t.__e != e && (e && t.type && !e.parentNode && (e = j(t)), e = n.insertBefore(t.__e, e || null));
  do
    e = e && e.nextSibling;
  while (e != null && e.nodeType == 8);
  return e;
}
function dn(t, e, n, o) {
  var r, i, s, c = t.key, p = t.type, l = e[n], f = l != null && (2 & l.__u) == 0;
  if (l === null && c == null || f && c == l.key && p == l.type) return n;
  if (o > (f ? 1 : 0)) {
    for (r = n - 1, i = n + 1; r >= 0 || i < e.length; ) if ((l = e[s = r >= 0 ? r-- : i++]) != null && (2 & l.__u) == 0 && c == l.key && p == l.type) return s;
  }
  return -1;
}
function Ye(t, e, n) {
  e[0] == "-" ? t.setProperty(e, n ?? "") : t[e] = n == null ? "" : typeof n != "number" || un.test(e) ? n : n + "px";
}
function le(t, e, n, o, r) {
  var i, s;
  e: if (e == "style") if (typeof n == "string") t.style.cssText = n;
  else {
    if (typeof o == "string" && (t.style.cssText = o = ""), o) for (e in o) n && e in n || Ye(t.style, e, "");
    if (n) for (e in n) o && n[e] == o[e] || Ye(t.style, e, n[e]);
  }
  else if (e[0] == "o" && e[1] == "n") i = e != (e = e.replace(xt, "$1")), s = e.toLowerCase(), e = s in t || e == "onFocusOut" || e == "onFocusIn" ? s.slice(2) : e.slice(2), t.l || (t.l = {}), t.l[e + i] = n, n ? o ? n[Q] = o[Q] : (n[Q] = Re, t.addEventListener(e, i ? Le : Fe, i)) : t.removeEventListener(e, i ? Le : Fe, i);
  else {
    if (r == "http://www.w3.org/2000/svg") e = e.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
    else if (e != "width" && e != "height" && e != "href" && e != "list" && e != "form" && e != "tabIndex" && e != "download" && e != "rowSpan" && e != "colSpan" && e != "role" && e != "popover" && e in t) try {
      t[e] = n ?? "";
      break e;
    } catch {
    }
    typeof n == "function" || (n == null || n === !1 && e[4] != "-" ? t.removeAttribute(e) : t.setAttribute(e, e == "popover" && n == 1 ? "" : n));
  }
}
function et(t) {
  return function(e) {
    if (this.l) {
      var n = this.l[e.type + t];
      if (e[ue] == null) e[ue] = Re++;
      else if (e[ue] < n[Q]) return;
      return n(h.event ? h.event(e) : e);
    }
  };
}
function ze(t, e, n, o, r, i, s, c, p, l) {
  var f, _, a, d, g, T, w, b, m, v, S, P, C, B, ae, Pe, A = e.type;
  if (e.constructor !== void 0) return null;
  128 & n.__u && (p = !!(32 & n.__u), i = [c = e.__e = n.__e]), (f = h.__b) && f(e);
  e: if (typeof A == "function") {
    _ = s.length;
    try {
      if (m = e.props, v = A.prototype && A.prototype.render, S = (f = A.contextType) && o[f.__c], P = f ? S ? S.props.value : f.__ : o, n.__c ? b = (a = e.__c = n.__c).__ = a.__E : (v ? e.__c = a = new A(m, P) : (e.__c = a = new Z(m, P), a.constructor = A, a.render = mn), S && S.sub(a), a.state || (a.state = {}), a.__n = o, d = a.__d = !0, a.__h = [], a._sb = []), v && a.__s == null && (a.__s = a.state), v && A.getDerivedStateFromProps != null && (a.__s == a.state && (a.__s = E({}, a.__s)), E(a.__s, A.getDerivedStateFromProps(m, a.__s))), g = a.props, T = a.state, a.__v = e, d) v && A.getDerivedStateFromProps == null && a.componentWillMount != null && a.componentWillMount(), v && a.componentDidMount != null && a.__h.push(a.componentDidMount);
      else {
        if (v && A.getDerivedStateFromProps == null && m !== g && a.componentWillReceiveProps != null && a.componentWillReceiveProps(m, P), e.__v == n.__v || !a.__e && a.shouldComponentUpdate != null && a.shouldComponentUpdate(m, a.__s, P) === !1) {
          e.__v != n.__v && (a.props = m, a.state = a.__s, a.__d = !1), e.__e = n.__e, e.__k = n.__k, e.__k.some(function(I) {
            I && (I.__ = e);
          }), me.push.apply(a.__h, a._sb), a._sb = [], a.__h.length && s.push(a), c = j(n);
          break e;
        }
        a.componentWillUpdate != null && a.componentWillUpdate(m, a.__s, P), v && a.componentDidUpdate != null && a.__h.push(function() {
          a.componentDidUpdate(g, T, w);
        });
      }
      if (a.context = P, a.props = m, a.__P = t, a.__e = !1, C = h.__r, B = 0, v) a.state = a.__s, a.__d = !1, C && C(e), f = a.render(a.props, a.state, a.context), me.push.apply(a.__h, a._sb), a._sb = [];
      else do
        a.__d = !1, C && C(e), f = a.render(a.props, a.state, a.context), a.state = a.__s;
      while (a.__d && ++B < 25);
      a.state = a.__s, a.getChildContext != null && (o = E(E({}, o), a.getChildContext())), v && !d && a.getSnapshotBeforeUpdate != null && (w = a.getSnapshotBeforeUpdate(g, T)), ae = f != null && f.type === D && f.key == null ? At(f.props.children) : f, c = Ct(t, xe(ae) ? ae : [ae], e, n, o, r, i, s, c, p, l), a.base = e.__e, e.__u &= -161, a.__h.length && s.push(a), b && (a.__E = a.__ = null);
    } catch (I) {
      if (s.length = _, e.__v = null, p || i != null) {
        if (I.then) {
          for (e.__u |= p ? 160 : 128; c && c.nodeType == 8 && c.nextSibling; ) c = c.nextSibling;
          i != null && (i[i.indexOf(c)] = null), e.__e = c;
        } else if (i != null) for (Pe = i.length; Pe--; ) We(i[Pe]);
      } else e.__e = n.__e;
      e.__k == null && (e.__k = n.__k || []), I.then || Pt(e), h.__e(I, e, n);
    }
  } else i == null && e.__v == n.__v ? (e.__k = n.__k, e.__e = n.__e) : c = e.__e = _n(n.__e, e, n, o, r, i, s, p, l);
  return (f = h.diffed) && f(e), 128 & e.__u ? void 0 : c;
}
function Pt(t) {
  t && (t.__c && (t.__c.__e = !0), t.__k && t.__k.some(Pt));
}
function Nt(t, e, n) {
  for (var o = 0; o < n.length; o++) Be(n[o], n[++o], n[++o]);
  h.__c && h.__c(e, t), t.some(function(r) {
    try {
      t = r.__h, r.__h = [], t.some(function(i) {
        i.call(r);
      });
    } catch (i) {
      h.__e(i, r.__v);
    }
  });
}
function At(t) {
  return typeof t != "object" || t == null || t.__b > 0 ? t : xe(t) ? t.map(At) : t.constructor !== void 0 ? null : E({}, t);
}
function _n(t, e, n, o, r, i, s, c, p) {
  var l, f, _, a, d, g, T, w = n.props || _e, b = e.props, m = e.type;
  if (m == "svg" ? r = "http://www.w3.org/2000/svg" : m == "math" ? r = "http://www.w3.org/1998/Math/MathML" : r || (r = "http://www.w3.org/1999/xhtml"), i != null) {
    for (l = 0; l < i.length; l++) if ((d = i[l]) && "setAttribute" in d == !!m && (m ? d.localName == m : d.nodeType == 3)) {
      t = d, i[l] = null;
      break;
    }
  }
  if (t == null) {
    if (m == null) return document.createTextNode(b);
    t = document.createElementNS(r, m, b.is && b), c && (h.__m && h.__m(e, i), c = !1), i = null;
  }
  if (m == null) w === b || c && t.data == b || (t.data = b);
  else {
    if (i = m == "textarea" && b.defaultValue != null ? null : i && we.call(t.childNodes), !c && i != null) for (w = {}, l = 0; l < t.attributes.length; l++) w[(d = t.attributes[l]).name] = d.value;
    for (l in w) d = w[l], l == "dangerouslySetInnerHTML" ? _ = d : l == "children" || l in b || l == "value" && "defaultValue" in b || l == "checked" && "defaultChecked" in b || le(t, l, null, d, r);
    for (l in b) d = b[l], l == "children" ? a = d : l == "dangerouslySetInnerHTML" ? f = d : l == "value" ? g = d : l == "checked" ? T = d : c && typeof d != "function" || w[l] === d || le(t, l, d, w[l], r);
    if (f) c || _ && (f.__html == _.__html || f.__html == t.innerHTML) || (t.innerHTML = f.__html), e.__k = [];
    else if (_ && (t.innerHTML = ""), Ct(e.type == "template" ? t.content : t, xe(a) ? a : [a], e, n, o, m == "foreignObject" ? "http://www.w3.org/1999/xhtml" : r, i, s, i ? i[0] : n.__k && j(n, 0), c, p), i != null) for (l = i.length; l--; ) We(i[l]);
    c && m != "textarea" || (l = "value", m == "progress" && g == null ? t.removeAttribute("value") : g != null && (g !== t[l] || m == "progress" && !g || m == "option" && g != w[l]) && le(t, l, g, w[l], r), l = "checked", T != null && T != t[l] && le(t, l, T, w[l], r));
  }
  return t;
}
function Be(t, e, n) {
  try {
    if (typeof t == "function") {
      var o = typeof t.__u == "function";
      o && t.__u(), o && e == null || (t.__u = t(e));
    } else t.current = e;
  } catch (r) {
    h.__e(r, n);
  }
}
function Et(t, e, n) {
  var o, r;
  if (h.unmount && h.unmount(t), (o = t.ref) && (o.current && o.current != t.__e || Be(o, null, e)), (o = t.__c) != null) {
    if (o.componentWillUnmount) try {
      o.componentWillUnmount();
    } catch (i) {
      h.__e(i, e);
    }
    o.base = o.__P = o.__n = null;
  }
  if (o = t.__k) for (r = 0; r < o.length; r++) o[r] && Et(o[r], e, n || typeof t.type != "function");
  n || We(t.__e), t.__c = t.__ = t.__e = void 0;
}
function mn(t, e, n) {
  return this.constructor(t, n);
}
function tt(t, e, n) {
  var o, r, i, s;
  e == document && (e = document.documentElement), h.__ && h.__(t, e), r = (o = !1) ? null : e.__k, i = [], s = [], ze(e, t = e.__k = he(D, null, [t]), r || _e, _e, e.namespaceURI, r ? null : e.firstChild ? we.call(e.childNodes) : null, i, r ? r.__e : e.firstChild, o, s), Nt(i, t, s), t.props.children = null;
}
function hn(t) {
  function e(n) {
    var o, r;
    return this.getChildContext || (o = /* @__PURE__ */ new Set(), (r = {})[e.__c] = this, this.getChildContext = function() {
      return r;
    }, this.componentWillUnmount = function() {
      o = null;
    }, this.shouldComponentUpdate = function(i) {
      this.props.value != i.value && o.forEach(function(s) {
        s.__e = !0, He(s);
      });
    }, this.sub = function(i) {
      o.add(i);
      var s = i.componentWillUnmount;
      i.componentWillUnmount = function() {
        o && o.delete(i), s && s.call(i);
      };
    }), n.children;
  }
  return e.__c = "__cC" + St++, e.__ = t, e.Provider = e.__l = (e.Consumer = function(n, o) {
    return n.children(o);
  }).contextType = e, e;
}
we = me.slice, h = { __e: function(t, e, n, o) {
  for (var r, i, s; e = e.__; ) if ((r = e.__c) && !r.__) try {
    if ((i = r.constructor) && i.getDerivedStateFromError != null && (r.setState(i.getDerivedStateFromError(t)), s = r.__d), r.componentDidCatch != null && (r.componentDidCatch(t, o || {}), s = r.__d), s) return r.__E = r;
  } catch (c) {
    t = c;
  }
  throw t;
} }, yt = 0, bt = function(t) {
  return t != null && t.constructor === void 0;
}, Z.prototype.setState = function(t, e) {
  var n;
  n = this.__s != null && this.__s != this.state ? this.__s : this.__s = E({}, this.state), typeof t == "function" && (t = t(E({}, n), this.props)), t && E(n, t), t != null && this.__v && (e && this._sb.push(e), He(this));
}, Z.prototype.forceUpdate = function(t) {
  this.__v && (this.__e = !0, t && this.__h.push(t), He(this));
}, Z.prototype.render = D, L = [], kt = typeof Promise == "function" ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, wt = function(t, e) {
  return t.__v.__b - e.__v.__b;
}, ve.__r = 0, Ne = Math.random().toString(8), ue = "__d" + Ne, Q = "__a" + Ne, xt = /(PointerCapture)$|Capture$/i, Re = 0, Fe = et(!1), Le = et(!0), St = 0;
var te, k, Ae, nt, qe = 0, Mt = [], x = h, ot = x.__b, rt = x.__r, it = x.diffed, st = x.__c, at = x.unmount, lt = x.__;
function Ie(t, e) {
  x.__h && x.__h(k, t, qe || e), qe = 0;
  var n = k.__H || (k.__H = { __: [], __h: [] });
  return t >= n.__.length && n.__.push({}), n.__[t];
}
function N(t) {
  return qe = 1, vn(Ft, t);
}
function vn(t, e, n) {
  var o = Ie(te++, 2);
  if (o.t = t, !o.__c && (o.__ = [Ft(void 0, e), function(c) {
    var p = o.__N ? o.__N[0] : o.__[0], l = o.t(p, c);
    p !== l && (o.__N = [l, o.__[1]], o.__c.setState({}));
  }], o.__c = k, !k.__f)) {
    var r = function(c, p, l) {
      if (!o.__c.__H) return !0;
      var f = !1, _ = o.__c.props !== c;
      if (o.__c.__H.__.some(function(d) {
        if (d.__N) {
          f = !0;
          var g = d.__[0];
          d.__ = d.__N, d.__N = void 0, g !== d.__[0] && (_ = !0);
        }
      }), i) {
        var a = i.call(this, c, p, l);
        return f ? a || _ : a;
      }
      return !f || _;
    };
    k.__f = !0;
    var i = k.shouldComponentUpdate, s = k.componentWillUpdate;
    k.componentWillUpdate = function(c, p, l) {
      if (this.__e) {
        var f = i;
        i = void 0, r(c, p, l), i = f;
      }
      s && s.call(this, c, p, l);
    }, k.shouldComponentUpdate = r;
  }
  return o.__N || o.__;
}
function Se(t, e) {
  var n = Ie(te++, 3);
  !x.__s && Ut(n.__H, e) && (n.__ = t, n.u = e, k.__H.__h.push(n));
}
function Ge(t, e) {
  var n = Ie(te++, 7);
  return Ut(n.__H, e) && (n.__ = t(), n.__H = e, n.__h = t), n.__;
}
function gn() {
  for (var t; t = Mt.shift(); ) {
    var e = t.__H;
    if (t.__P && e) try {
      e.__h.some(fe), e.__h.some(Oe), e.__h = [];
    } catch (n) {
      e.__h = [], x.__e(n, t.__v);
    }
  }
}
x.__b = function(t) {
  k = null, ot && ot(t);
}, x.__ = function(t, e) {
  t && e.__k && e.__k.__m && (t.__m = e.__k.__m), lt && lt(t, e);
}, x.__r = function(t) {
  rt && rt(t), te = 0;
  var e = (k = t.__c).__H;
  e && (Ae === k ? (e.__h = [], k.__h = [], e.__.some(function(n) {
    n.__N && (n.__ = n.__N), n.u = n.__N = void 0;
  })) : (e.__h.some(fe), e.__h.some(Oe), e.__h = [], te = 0)), Ae = k;
}, x.diffed = function(t) {
  it && it(t);
  var e = t.__c;
  e && e.__H && (e.__H.__h.length && (Mt.push(e) !== 1 && nt === x.requestAnimationFrame || ((nt = x.requestAnimationFrame) || yn)(gn)), e.__H.__.some(function(n) {
    n.u && (n.__H = n.u, n.u = void 0);
  })), Ae = k = null;
}, x.__c = function(t, e) {
  e.some(function(n) {
    try {
      n.__h.some(fe), n.__h = n.__h.filter(function(o) {
        return !o.__ || Oe(o);
      });
    } catch (o) {
      e.some(function(r) {
        r.__h && (r.__h = []);
      }), e = [], x.__e(o, n.__v);
    }
  }), st && st(t, e);
}, x.unmount = function(t) {
  at && at(t);
  var e, n = t.__c;
  n && n.__H && (n.__H.__.some(function(o) {
    try {
      fe(o);
    } catch (r) {
      e = r;
    }
  }), n.__H = void 0, e && x.__e(e, n.__v));
};
var ct = typeof requestAnimationFrame == "function";
function yn(t) {
  var e, n = function() {
    clearTimeout(o), ct && cancelAnimationFrame(e), setTimeout(t);
  }, o = setTimeout(n, 35);
  ct && (e = requestAnimationFrame(n));
}
function fe(t) {
  var e = k, n = t.__c;
  typeof n == "function" && (t.__c = void 0, n()), k = e;
}
function Oe(t) {
  var e = k;
  t.__c = t.__(), k = e;
}
function Ut(t, e) {
  return !t || t.length !== e.length || e.some(function(n, o) {
    return n !== t[o];
  });
}
function Ft(t, e) {
  return typeof e == "function" ? e(t) : e;
}
var bn = Symbol.for("preact-signals");
function $e() {
  if (M > 1)
    M--;
  else {
    var t, e = !1;
    for ((function() {
      var r = ye;
      for (ye = void 0; r !== void 0; ) {
        var i = r.S;
        if (i.v === r.v) for (var s = i.t; s !== void 0; s = s.x) s.i === r.i && (s.i = i.i);
        r = r.o;
      }
    })(); Y !== void 0; ) {
      var n = Y;
      for (Y = void 0, ge++; n !== void 0; ) {
        var o = n.u;
        if (n.u = void 0, n.f &= -3, !(8 & n.f) && Ht(n)) try {
          n.c();
        } catch (r) {
          e || (t = r, e = !0);
        }
        n = o;
      }
    }
    if (ge = 0, M--, e) throw t;
  }
}
function kn(t) {
  if (M > 0) return t();
  je = ++wn, M++;
  try {
    return t();
  } finally {
    $e();
  }
}
var X, y = void 0;
function Ce(t) {
  var e = y, n = X;
  y = void 0, X = void 0;
  try {
    return t();
  } finally {
    y = e, X = n;
  }
}
var Y = void 0, M = 0, ge = 0, wn = 0, je = 0, ye = void 0, be = 0;
function Lt(t) {
  if (y !== void 0) {
    var e = t.n;
    if (e === void 0 || e.t !== y)
      return e = { i: 0, S: t, p: y.s, n: void 0, t: y, e: void 0, x: void 0, r: e }, y.s !== void 0 && (y.s.n = e), y.s = e, t.n = e, 32 & y.f && t.S(e), e;
    if (e.i === -1)
      return e.i = 0, e.n !== void 0 && (e.n.p = e.p, e.p !== void 0 && (e.p.n = e.n), e.p = y.s, e.n = void 0, y.s.n = e, y.s = e), e;
  }
}
function $(t, e) {
  this.v = t, this.i = 0, this.n = void 0, this.t = void 0, this.l = 0, this.W = e?.watched, this.Z = e?.unwatched, this.name = e?.name;
}
$.prototype.brand = bn;
$.prototype.h = function() {
  return !0;
};
$.prototype.S = function(t) {
  var e = this, n = this.t;
  n !== t && t.e === void 0 && (t.x = n, this.t = t, n !== void 0 ? n.e = t : Ce(function() {
    var o;
    (o = e.W) == null || o.call(e);
  }));
};
$.prototype.U = function(t) {
  var e = this;
  if (this.t !== void 0) {
    var n = t.e, o = t.x;
    n !== void 0 && (n.x = o, t.e = void 0), o !== void 0 && (o.e = n, t.x = void 0), t === this.t && (this.t = o, o === void 0 && Ce(function() {
      var r;
      (r = e.Z) == null || r.call(e);
    }));
  }
};
$.prototype.subscribe = function(t) {
  var e = this;
  return re(function() {
    var n = e.value;
    Ce(function() {
      return t(n);
    });
  }, { name: "sub" });
};
$.prototype.valueOf = function() {
  return this.value;
};
$.prototype.toString = function() {
  return this.value + "";
};
$.prototype.toJSON = function() {
  return this.value;
};
$.prototype.peek = function() {
  var t = this;
  return Ce(function() {
    return t.value;
  });
};
Object.defineProperty($.prototype, "value", { get: function() {
  var t = Lt(this);
  return t !== void 0 && (t.i = this.i), this.v;
}, set: function(t) {
  if (t !== this.v) {
    if (ge > 100) throw new Error("Cycle detected");
    (function(n) {
      M !== 0 && ge === 0 && n.l !== je && (n.l = je, ye = { S: n, v: n.v, i: n.i, o: ye });
    })(this), this.v = t, this.i++, be++, M++;
    try {
      for (var e = this.t; e !== void 0; e = e.x) e.t.N();
    } finally {
      $e();
    }
  }
} });
function R(t, e) {
  return new $(t, e);
}
function Ht(t) {
  for (var e = t.s; e !== void 0; e = e.n) if (e.S.i !== e.i || !e.S.h() || e.S.i !== e.i) return !0;
  return !1;
}
function qt(t) {
  for (var e = t.s; e !== void 0; e = e.n) {
    var n = e.S.n;
    if (n !== void 0 && (e.r = n), e.S.n = e, e.i = -1, e.n === void 0) {
      t.s = e;
      break;
    }
  }
}
function Ot(t) {
  for (var e = t.s, n = void 0; e !== void 0; ) {
    var o = e.p;
    e.i === -1 ? (e.S.U(e), o !== void 0 && (o.n = e.n), e.n !== void 0 && (e.n.p = o)) : n = e, e.S.n = e.r, e.r !== void 0 && (e.r = void 0), e = o;
  }
  t.s = n;
}
function W(t, e) {
  $.call(this, void 0, e), this.x = t, this.s = void 0, this.g = be - 1, this.f = 4;
}
W.prototype = new $();
W.prototype.h = function() {
  if (this.f &= -3, 1 & this.f) return !1;
  if ((36 & this.f) == 32 || (this.f &= -5, this.g === be)) return !0;
  if (this.g = be, this.f |= 1, this.i > 0 && !Ht(this))
    return this.f &= -2, !0;
  var t = y;
  try {
    qt(this), y = this;
    var e = this.x();
    (16 & this.f || this.v !== e || this.i === 0) && (this.v = e, this.f &= -17, this.i++);
  } catch (n) {
    this.v = n, this.f |= 16, this.i++;
  }
  return y = t, Ot(this), this.f &= -2, !0;
};
W.prototype.S = function(t) {
  if (this.t === void 0) {
    this.f |= 36;
    for (var e = this.s; e !== void 0; e = e.n) e.S.S(e);
  }
  $.prototype.S.call(this, t);
};
W.prototype.U = function(t) {
  if (this.t !== void 0 && ($.prototype.U.call(this, t), this.t === void 0)) {
    this.f &= -33;
    for (var e = this.s; e !== void 0; e = e.n) e.S.U(e);
  }
};
W.prototype.N = function() {
  if (!(2 & this.f)) {
    this.f |= 6;
    for (var t = this.t; t !== void 0; t = t.x) t.t.N();
  }
};
Object.defineProperty(W.prototype, "value", { get: function() {
  if (1 & this.f) throw new Error("Cycle detected");
  var t = Lt(this);
  if (this.h(), t !== void 0 && (t.i = this.i), 16 & this.f) throw this.v;
  return this.v;
} });
function ut(t, e) {
  return new W(t, e);
}
function jt(t) {
  var e = t.j;
  if (t.j = void 0, typeof e == "function") {
    M++;
    var n = y;
    y = void 0;
    try {
      e();
    } catch (o) {
      throw t.f &= -2, t.f |= 8, Ke(t), o;
    } finally {
      y = n, $e();
    }
  }
}
function Ke(t) {
  for (var e = t.s; e !== void 0; e = e.n) e.S.U(e);
  t.x = void 0, t.s = void 0, jt(t);
}
function xn(t) {
  if (y !== this) throw new Error("Out-of-order effect");
  Ot(this), y = t, this.f &= -2;
  try {
    8 & this.f && Ke(this);
  } finally {
    $e();
  }
}
function K(t, e) {
  this.x = t, this.j = void 0, this.s = void 0, this.u = void 0, this.f = 32, this.name = e?.name, X && X.push(this);
}
K.prototype.c = function() {
  var t = this.S();
  try {
    if (8 & this.f || this.x === void 0) return;
    var e = this.x();
    typeof e == "function" && (this.j = e);
  } finally {
    t();
  }
};
K.prototype.S = function() {
  if (1 & this.f) throw new Error("Cycle detected");
  this.f |= 1, this.f &= -9, jt(this), qt(this), M++;
  var t = y;
  return y = this, xn.bind(this, t);
};
K.prototype.N = function() {
  2 & this.f || (this.f |= 2, this.u = Y, Y = this);
};
K.prototype.d = function() {
  this.f |= 8, 1 & this.f || Ke(this);
};
K.prototype.dispose = function() {
  this.d();
};
function re(t, e) {
  var n = new K(t, e);
  try {
    n.c();
  } catch (r) {
    throw n.d(), r;
  }
  var o = n.d.bind(n);
  return o[Symbol.dispose] = o, o;
}
var Vt, ce, Sn = typeof window < "u" && !!window.__PREACT_SIGNALS_DEVTOOLS__, Dt = [];
re(function() {
  Vt = this.N;
})();
function J(t, e) {
  h[t] = e.bind(null, h[t] || function() {
  });
}
function ne(t) {
  if (ce) {
    var e = ce;
    ce = void 0, e();
  }
  ce = t && t.S();
}
function Rt(t) {
  var e = this, n = t.data, o = Cn(n);
  o.name = "ReactiveDom", o.value = n;
  var r = Ge(function() {
    for (var c = e, p = e.__v; p = p.__; ) if (p.__c) {
      p.__c.__$f |= 4;
      break;
    }
    var l = ut(function() {
      var d = o.value.value;
      return d === 0 ? 0 : d === !0 ? "" : d || "";
    }), f = ut(function() {
      return !Array.isArray(l.value) && !bt(l.value);
    }), _ = re(function() {
      if (this.N = Wt, f.value) {
        var d = l.value;
        c.__v && c.__v.__e && c.__v.__e.nodeType === 3 && (c.__v.__e.data = d);
      }
    }), a = e.__$u.d;
    return e.__$u.d = function() {
      _(), a.call(this);
    }, [f, l];
  }, []), i = r[0], s = r[1];
  return i.value ? s.peek() : s.value;
}
Rt.displayName = "ReactiveTextNode";
Object.defineProperties($.prototype, { constructor: { configurable: !0, value: he(D, null).constructor }, type: { configurable: !0, value: Rt }, props: { configurable: !0, get: function() {
  var t = this;
  return { data: { get value() {
    return t.value;
  } } };
} }, __b: { configurable: !0, value: 1 } });
J("__b", function(t, e) {
  if (ne(), typeof e.type == "string") {
    var n, o = e.props;
    for (var r in o) if (r !== "children") {
      var i = o[r];
      i instanceof $ && (n || (e.__np = n = {}), n[r] = i, o[r] = i.peek());
    }
  }
  t(e);
});
J("__r", function(t, e) {
  if (t(e), e.type !== D) {
    ne();
    var n, o = e.__c;
    o && (o.__$f &= -2, (n = o.__$u) === void 0 && (o.__$u = n = (function(r, i) {
      var s;
      return re(function() {
        s = this;
      }, { name: i }), s.c = r, s;
    })(/* @__PURE__ */ (function(r) {
      return function() {
        var i;
        Sn && ((i = this.y) == null || i.call(this)), r.__$f |= 1, r.setState({});
      };
    })(o), typeof e.type == "function" ? e.type.displayName || e.type.name : ""))), ne(n);
  }
});
J("__e", function(t, e, n, o) {
  ne(), t(e, n, o);
});
J("diffed", function(t, e) {
  ne();
  var n;
  if (typeof e.type == "string" && (n = e.__e)) {
    var o = e.__np, r = e.props, i = n.U;
    if (i) for (var s in i) {
      var c = i[s];
      c === void 0 || o && s in o || (c.d(), i[s] = void 0);
    }
    if (o) {
      i || (i = {}, n.U = i);
      for (var p in o) {
        var l = i[p], f = o[p];
        l === void 0 ? (l = $n(n, p, f, r), i[p] = l) : l.o(f, r);
      }
    }
  }
  t(e);
});
function $n(t, e, n, o) {
  var r = e in t && t.ownerSVGElement === void 0, i = R(n);
  return { o: function(s, c) {
    i.value = s, o = c;
  }, d: re(function() {
    this.N = Wt;
    var s = i.value.value;
    o[e] !== s && (o[e] = s, r ? t[e] = s : s != null && (s !== !1 || e[4] === "-") ? t.setAttribute(e, s) : t.removeAttribute(e));
  }) };
}
J("unmount", function(t, e) {
  if (typeof e.type == "string") {
    var n = e.__e;
    if (n) {
      var o = n.U;
      if (o) {
        n.U = void 0;
        for (var r in o) {
          var i = o[r];
          i && i.d();
        }
      }
    }
    var s = e.__np;
    if (s) {
      var c = e.props;
      for (var p in s) c[p] = s[p];
    }
    e.__np = void 0;
  } else {
    var l = e.__c;
    if (l) {
      l.__$f |= 8;
      var f = l.__$u;
      f && (l.__$u = void 0, f.d());
    }
  }
  t(e);
});
J("__h", function(t, e, n, o) {
  o < 3 && (e.__$f |= 2), t(e, n, o);
});
Z.prototype.shouldComponentUpdate = function(t, e) {
  if (this.__R) return !0;
  var n = this.__$u, o = n && n.s !== void 0;
  for (var r in e) return !0;
  if (this.__f || typeof this.u == "boolean" && this.u === !0) {
    var i = 2 & this.__$f;
    if (!(o || i || 4 & this.__$f) || 1 & this.__$f) return !0;
  } else if (!(o || 4 & this.__$f) || 3 & this.__$f) return !0;
  for (var s in t) if (s !== "__source" && t[s] !== this.props[s]) return !0;
  for (var c in this.props) if (!(c in t)) return !0;
  return !1;
};
function Cn(t, e) {
  return Ge(function() {
    return R(t, e);
  }, []);
}
var Tn = function(t) {
  queueMicrotask(function() {
    queueMicrotask(t);
  });
};
function Pn() {
  kn(function() {
    for (var t; t = Dt.shift(); ) Vt.call(t);
  });
}
function Wt() {
  Dt.push(this) === 1 && (h.requestAnimationFrame || Tn)(Pn);
}
const V = R(null), zt = /* @__PURE__ */ new Set();
function Nn(t) {
  const e = V.peek() === null;
  if (V.value = t, e) for (const n of zt) n(t);
}
function An(t) {
  const e = V.peek();
  e ? t(e) : zt.add(t);
}
const En = hn(null);
function Te(t, e) {
  if (customElements.get(t)) return;
  class n extends HTMLElement {
    #e = null;
    #n = {};
    #t = !1;
    constructor() {
      super();
      for (const r of ["api", "params"])
        if (Object.prototype.hasOwnProperty.call(this, r)) {
          const i = this[r];
          delete this[r], this[r] = i;
        }
    }
    set api(r) {
      this.#e = r, r && Nn(r), this.#t && this.#o();
    }
    get api() {
      return this.#e;
    }
    set params(r) {
      this.#n = r ?? {}, this.#t && this.#o();
    }
    get params() {
      return this.#n;
    }
    connectedCallback() {
      this.#t = !0, this.#o();
    }
    disconnectedCallback() {
      this.#t = !1, tt(null, this);
    }
    #o() {
      if (!this.#e) {
        console.error(`[spoolman] <${t}> connected without api — host contract violated`);
        return;
      }
      tt(
        he(En.Provider, { value: this.#e }, he(e, { api: this.#e, params: this.#n })),
        this
      );
    }
  }
  customElements.define(t, n);
}
const Mn = {
  spoolman: {
    title: "Spoolman",
    common: {
      loading: "Loading…",
      refresh: "Refresh",
      close: "Close",
      noPrinter: "No active printer",
      notConfigured: "Spoolman is not configured in Moonraker (no [spoolman] section in moonraker.conf).",
      disconnected: "Moonraker cannot reach Spoolman.",
      grams: "{value} g",
      metres: "{value} m"
    },
    widget: {
      title: "Spools",
      change: "Change",
      empty: "No spool",
      left: "{value} left",
      openPage: "Open Spoolman"
    },
    check: {
      title: "Filament check",
      printer: "Printer: {name}",
      file: "File: {name}",
      ok: "Loaded spools match the file.",
      checking: "Checking…",
      print: "Print",
      printAnyway: "Print anyway",
      cancel: "Cancel print",
      queued: "More print starts are waiting: {count}"
    },
    issue: {
      noSpool: "No spool selected",
      material: "File needs {expected}, loaded {actual}",
      insufficient: "Not enough filament: needs {required}, left {remaining}",
      unavailable: "Spools could not be checked: {message}"
    },
    picker: {
      title: "Spool for {tool}",
      search: "Search by name, vendor, material, #id",
      empty: "No spools found",
      error: "Cannot load spools: {message}",
      clear: "Unload spool",
      needsSaveVars: "Per-tool spools need [save_variables] in the Klipper config.",
      saveFailed: "Spool was not saved: {message}"
    },
    page: {
      unknownUrl: "Spoolman address is unknown. Enter it below.",
      url: "Spoolman address",
      save: "Save",
      reset: "Use Moonraker setting",
      openTab: "Open in new tab",
      frameHint: "Blank page? Spoolman is not reachable from this browser, or the page is served over HTTPS and Spoolman over HTTP. Open it in a new tab."
    },
    guard: {
      cancelled: "Print cancelled after the spool check"
    }
  }
}, Un = {
  spoolman: {
    title: "Spoolman",
    common: {
      loading: "Загрузка…",
      refresh: "Обновить",
      close: "Закрыть",
      noPrinter: "Нет активного принтера",
      notConfigured: "Spoolman не настроен в Moonraker (нет секции [spoolman] в moonraker.conf).",
      disconnected: "Moonraker не может подключиться к Spoolman.",
      grams: "{value} г",
      metres: "{value} м"
    },
    widget: {
      title: "Катушки",
      change: "Сменить",
      empty: "Катушка не выбрана",
      left: "осталось {value}",
      openPage: "Открыть Spoolman"
    },
    check: {
      title: "Проверка филамента",
      printer: "Принтер: {name}",
      file: "Файл: {name}",
      ok: "Загруженные катушки подходят к файлу.",
      checking: "Проверка…",
      print: "Печатать",
      printAnyway: "Печатать всё равно",
      cancel: "Отменить печать",
      queued: "Ждут ещё запусков печати: {count}"
    },
    issue: {
      noSpool: "Катушка не выбрана",
      material: "Файлу нужен {expected}, загружен {actual}",
      insufficient: "Не хватит филамента: нужно {required}, осталось {remaining}",
      unavailable: "Не удалось проверить катушки: {message}"
    },
    picker: {
      title: "Катушка для {tool}",
      search: "Поиск по имени, производителю, материалу, #id",
      empty: "Катушки не найдены",
      error: "Не удалось загрузить катушки: {message}",
      clear: "Снять катушку",
      needsSaveVars: "Для катушек по инструментам нужен [save_variables] в конфиге Klipper.",
      saveFailed: "Катушка не сохранена: {message}"
    },
    page: {
      unknownUrl: "Адрес Spoolman неизвестен. Укажите его ниже.",
      url: "Адрес Spoolman",
      save: "Сохранить",
      reset: "Как в Moonraker",
      openTab: "Открыть в новой вкладке",
      frameHint: "Пустая страница? Spoolman недоступен из этого браузера, либо интерфейс открыт по HTTPS, а Spoolman — по HTTP. Откройте его в новой вкладке."
    },
    guard: {
      cancelled: "Печать отменена после проверки катушек"
    }
  }
};
class Bt extends Error {
  constructor(e, n) {
    super(e), this.status = n, this.name = "SpoolmanError";
  }
}
async function It(t, e, n, o) {
  const r = await t.request("server.spoolman.proxy", {
    use_v2_response: !0,
    request_method: e,
    path: n
  });
  if (r?.error) throw new Bt(r.error.message, r.error.status_code ?? null);
  return r.response;
}
async function Fn(t, e) {
  try {
    return await It(t, "GET", `/v1/spool/${e}`);
  } catch (n) {
    if (n instanceof Bt && n.status === 404) return null;
    throw n;
  }
}
function Ln(t) {
  return It(t, "GET", "/v1/spool");
}
async function Hn(t) {
  const e = await t.request("server.spoolman.get_spool_id"), n = Number(e?.spool_id);
  return Number.isFinite(n) && n > 0 ? n : null;
}
function qn(t, e) {
  return t.request("server.spoolman.post_spool_id", { spool_id: e });
}
async function On(t) {
  return (await t.request("server.spoolman.status"))?.spoolman_connected === !0;
}
async function jn(t) {
  return (await t.request("server.config"))?.config?.spoolman?.server;
}
function Vn(t, e, n) {
  const o = `${e.toLowerCase()}__spool_id`;
  return t.request("printer.gcode.script", {
    script: `SAVE_VARIABLE VARIABLE=${o} VALUE=${n ?? "None"}`
  });
}
function Dn(t, e) {
  return t.request("server.files.metadata", { filename: e });
}
function Rn(t) {
  return t.filter((e) => e.startsWith("gcode_macro ")).map((e) => e.slice(12)).filter((e) => /^T\d+$/i.test(e)).map((e) => e.toUpperCase()).sort((e, n) => Number(e.slice(1)) - Number(n.slice(1)));
}
function Wn(t) {
  const e = Number(t);
  return Number.isFinite(e) && e > 0 ? Math.round(e) : null;
}
function zn(t, e) {
  const n = {};
  for (const o of e) n[o] = Wn(t[`${o.toLowerCase()}__spool_id`]);
  return n;
}
function Bn(t) {
  const e = t.active_tool;
  if (e == null || e === "") return null;
  const n = /^T?(\d+)$/i.exec(String(e).trim());
  return n ? `T${Number(n[1])}` : null;
}
function Gt(t) {
  return t.tools.length > 0 ? t.tools : ["T0"];
}
function ie(t, e) {
  const n = t.toolSpools[e];
  return n ?? (t.tools.length <= 1 ? t.activeSpoolId : null);
}
function In(t, e, n) {
  const o = t?.trim();
  if (o) return o;
  const r = e?.trim();
  if (!r) return null;
  try {
    const i = new URL(r);
    if (["localhost", "127.0.0.1", "[::1]", "0.0.0.0"].includes(i.hostname)) {
      let s = "";
      try {
        s = new URL(/^[a-z]+:\/\//i.test(n) ? n : `http://${n}`).hostname;
      } catch {
        s = "";
      }
      i.hostname = s || (typeof location < "u" ? location.hostname : i.hostname);
    }
    return i.href;
  } catch {
    return null;
  }
}
function se() {
  return {
    ready: !1,
    hasSpoolman: !1,
    connected: null,
    hasSaveVars: !1,
    tools: [],
    toolSpools: {},
    activeSpoolId: null,
    activeTool: null
  };
}
const U = R({}), q = /* @__PURE__ */ new Map();
let G = null, pt = null;
function ft(t, e) {
  H(t, e);
}
function H(t, e) {
  const n = U.peek();
  U.value = { ...n, [t]: { ...n[t] ?? se(), ...e } };
}
function O(t) {
  return U.peek()[t] ?? se();
}
function ee(t, e) {
  const n = q.get(e);
  if (!n) return Promise.resolve();
  if (n.loading) return n.loading;
  const o = async () => {
    const r = t.moonrakerFor(e);
    try {
      const i = await r.request("server.info"), s = Array.isArray(i?.components) && i.components.includes("spoolman"), c = await r.request("printer.objects.list").then((f) => f?.objects ?? []).catch(() => []), p = Rn(c), l = c.includes("save_variables");
      if (H(e, { hasSpoolman: s, tools: p, hasSaveVars: l }), s) {
        const [f, _] = await Promise.all([
          Hn(r).catch(() => null),
          On(r).catch(() => !1)
        ]);
        H(e, { activeSpoolId: f, connected: _ });
      }
      Gn(t, e, l);
    } catch (i) {
      console.warn(`[spoolman] cannot load state of printer ${e}:`, i);
    } finally {
      H(e, { ready: !0 });
    }
  };
  return n.loading = o().finally(() => {
    n.loading = null;
  }), n.loading;
}
function Gn(t, e, n) {
  const o = q.get(e);
  o && (o.offVars?.(), o.offVars = null, n && (o.offVars = t.moonrakerFor(e).subscribe(
    { save_variables: ["variables"] },
    (r) => {
      const i = r?.save_variables?.variables;
      if (!i || typeof i != "object") return;
      const s = O(e).tools;
      H(e, {
        toolSpools: zn(i, s),
        activeTool: Bn(i)
      });
    },
    // immediate: get the current snapshot from the host cache right away,
    // not only the next change.
    { immediate: !0 }
  )));
}
function Kt(t, e) {
  if (q.has(e)) return;
  const n = { offs: [], offVars: null, loading: null };
  q.set(e, n), H(e, {});
  const o = t.moonrakerFor(e);
  n.offs.push(
    o.onNotify("notify_active_spool_set", (r) => {
      const i = Array.isArray(r) ? r[0] : r, s = Number(i?.spool_id);
      H(e, { activeSpoolId: Number.isFinite(s) && s > 0 ? s : null });
    }),
    o.onNotify("notify_spoolman_status_changed", (r) => {
      const i = Array.isArray(r) ? r[0] : r;
      H(e, { connected: i?.spoolman_connected === !0 });
    }),
    // Klipper restart may change macros / save_variables availability.
    o.onNotify("notify_klippy_ready", () => void ee(t, e)),
    // Fires on every (re)connect to Moonraker.
    o.onReady(() => void ee(t, e))
  ), o.readyState === "open" && ee(t, e);
}
function Kn(t) {
  const e = q.get(t);
  if (!e) return;
  for (const r of e.offs) r();
  e.offVars?.(), q.delete(t);
  const { [t]: n, ...o } = U.peek();
  U.value = o;
}
function dt(t, e) {
  const n = new Set(e);
  for (const o of Array.from(q.keys())) n.has(o) || Kn(o);
  for (const o of n) Kt(t, o);
}
function Jn(t) {
  G = t, !pt && (dt(t, t.printers.map((e) => e.id)), pt = t.onPrintersChange((e) => {
    G && dt(G, e.map((n) => n.id));
  }));
}
async function Qn(t) {
  const e = G;
  return e && (q.has(t) || Kt(e, t), O(t).ready || await ee(e, t)), O(t);
}
function Zn(t) {
  return G ? ee(G, t) : Promise.resolve();
}
var Xn = 0;
function u(t, e, n, o, r, i) {
  e || (e = {});
  var s, c, p = e;
  if ("ref" in p) for (c in p = {}, e) c == "ref" ? s = e[c] : p[c] = e[c];
  var l = { type: t, props: p, key: n, ref: s, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: --Xn, __i: -1, __u: 0, __source: r, __self: i };
  if (typeof t == "function" && (s = t.defaultProps)) for (c in s) p[c] === void 0 && (p[c] = s[c]);
  return h.vnode && h.vnode(l), l;
}
function Jt(t) {
  const e = Number(t);
  return t != null && t !== "" && Number.isFinite(e) && e > 0 ? e : void 0;
}
function ke(t) {
  if (Array.isArray(t)) return t;
  if (typeof t == "number") return [t];
  if (typeof t != "string") return [];
  const e = t.trim();
  if (e.startsWith("["))
    try {
      const n = JSON.parse(e);
      return Array.isArray(n) ? n : [];
    } catch {
      return [];
    }
  return e ? e.split(";") : [];
}
const Yn = (t) => ke(t).map((e) => e == null ? "" : String(e).trim()), Ee = (t) => ke(t).map(Jt);
function _t(t) {
  const e = t ?? {}, n = Yn(e.filament_type), o = Ee(e.filament_weight), r = Ee(e.filament_total), i = ke(e.filament_total).length > 1, s = e.filament_length != null ? Ee(e.filament_length) : i ? r : [], c = i ? r.reduce((l, f) => l + (f ?? 0), 0) || void 0 : r[0];
  let p = ke(e.referenced_tools).map(Number).filter((l) => Number.isInteger(l) && l >= 0);
  return p.length === 0 && (p = (o.length >= s.length ? o : s).flatMap((f, _) => f !== void 0 ? [_] : [])), {
    tools: p.length > 0 ? p : [0],
    types: n,
    weights: o,
    lengths: s,
    totalWeight: Jt(e.filament_weight_total),
    totalLength: c
  };
}
function Qt(t, e) {
  const n = (o) => o.trim().replace(/\s+/g, " ").toUpperCase();
  return n(t) === n(e);
}
function Zt(t, e) {
  return (t.types[e] ?? (t.types.length === 1 ? t.types[0] : "") ?? "").trim();
}
function eo(t, e) {
  const n = [], o = t.tools.length === 1;
  for (const r of t.tools) {
    const i = `T${r}`, s = e(r);
    if (!s) {
      n.push({ kind: "no-spool", tool: i });
      continue;
    }
    const c = Zt(t, r), p = s.filament.material?.trim() ?? "";
    c && p && !Qt(c, p) && n.push({ kind: "material", tool: i, expected: c, actual: p });
    const l = t.weights[r] ?? (o ? t.totalWeight : void 0), f = t.lengths[r] ?? (o ? t.totalLength : void 0);
    l !== void 0 && s.remaining_weight !== void 0 ? s.remaining_weight < l && n.push({ kind: "insufficient", tool: i, unit: "g", required: l, remaining: s.remaining_weight }) : f !== void 0 && s.remaining_length !== void 0 && s.remaining_length < f && n.push({ kind: "insufficient", tool: i, unit: "mm", required: f, remaining: s.remaining_length });
  }
  return n;
}
const de = R({}), Xt = 6e4, oe = /* @__PURE__ */ new Map(), Me = /* @__PURE__ */ new Map(), Yt = (t, e) => `${t}:${e}`;
function Je(t, e, n = !1) {
  const o = Yt(t, e), r = Me.get(o);
  if (r) return r;
  const i = de.peek()[o];
  if (!n && i !== void 0 && Date.now() - (oe.get(o) ?? 0) < Xt)
    return Promise.resolve(i);
  const s = V.peek();
  if (!s) return Promise.resolve(null);
  const c = Fn(s.moonrakerFor(t), e).then((p) => (de.value = { ...de.peek(), [o]: p }, oe.set(o, Date.now()), p)).finally(() => Me.delete(o));
  return Me.set(o, c), c;
}
function en(t, e) {
  if (e == null) return null;
  const n = Yt(t, e), o = de.value[n];
  return (o === void 0 || Date.now() - (oe.get(n) ?? 0) >= Xt) && Je(t, e).catch((r) => console.warn(`[spoolman] spool ${e}:`, r)), o;
}
function tn(t) {
  for (const e of Array.from(oe.keys()))
    e.startsWith(`${t}:`) && oe.delete(e);
}
const nn = 6e3, F = R([]), Ve = R(null);
function on(t, e) {
  return new Promise((n, o) => {
    const r = setTimeout(() => o(new Error("timeout")), e);
    t.then(
      (i) => {
        clearTimeout(r), n(i);
      },
      (i) => {
        clearTimeout(r), o(i);
      }
    );
  });
}
async function rn(t, e, n) {
  const o = V.peek();
  if (!o) return { skip: !0 };
  const r = await Qn(t);
  if (!r.hasSpoolman) return { skip: !0 };
  const i = o.moonrakerFor(t);
  let s = null;
  try {
    s = _t(await Dn(i, e));
  } catch (l) {
    console.warn(`[spoolman] no metadata for ${e}:`, l);
  }
  const c = s ?? _t(null), p = /* @__PURE__ */ new Map();
  return await Promise.all(
    c.tools.map(async (l) => {
      const f = ie(r, `T${l}`);
      p.set(l, f == null ? null : await Je(t, f, n));
    })
  ), { skip: !1, file: s, issues: eo(c, (l) => p.get(l) ?? null) };
}
function sn(t) {
  return { skip: !1, file: null, issues: [{ kind: "unavailable", message: t instanceof Error ? t.message : String(t) }] };
}
const mo = async (t, e, n) => {
  if (t.method !== "printer.print.start") return { action: "allow" };
  if (!V.peek())
    return console.warn("[spoolman] guard called before the plugin received its api — allowing"), { action: "allow" };
  const o = t.params?.filename;
  if (typeof o != "string" || !o) return { action: "allow" };
  const r = n.targetPrinterId;
  let i;
  try {
    i = await on(rn(r, o, !0), nn);
  } catch (s) {
    i = sn(s);
  }
  return i.skip || i.issues.length === 0 ? { action: "allow" } : (F.value = [
    ...F.peek(),
    { token: e, printerId: r, filename: o, file: i.file, issues: i.issues, checking: !1 }
  ], { action: "freeze" });
};
function mt(t, e) {
  F.value = F.peek().map((n) => n.token === t ? { ...n, ...e } : n);
}
async function to(t) {
  const e = F.peek().find((o) => o.token === t);
  if (!e) return;
  mt(t, { checking: !0 });
  let n;
  try {
    n = await on(rn(e.printerId, e.filename, !0), nn);
  } catch (o) {
    n = sn(o);
  }
  mt(t, n.skip ? { issues: [], checking: !1 } : { file: n.file, issues: n.issues, checking: !1 });
}
function ht(t, e) {
  const n = V.peek();
  F.value = F.peek().filter((o) => o.token !== t), n?.guards.resume(t, e, e === "deny" ? "spoolman.guard.cancelled" : void 0);
}
async function no(t, e, n, o) {
  const r = O(e), i = t.moonrakerFor(e), s = r.tools.length > 1;
  if (s && !r.hasSaveVars)
    throw new Error("save_variables");
  r.hasSaveVars && r.tools.length > 0 && (await Vn(i, n, o), ft(e, { toolSpools: { ...O(e).toolSpools, [n]: o } })), (!s || r.activeTool === n) && (await qn(i, o), ft(e, { activeSpoolId: o })), tn(e);
}
function z(t) {
  const [, e] = N(0);
  return Se(() => t.onLocaleChange(() => e((n) => n + 1)), [t]), (n, o) => t.i18n.t(n, o);
}
function Qe(t) {
  const [e, n] = N(t.printer);
  return Se(() => {
    const o = t.onPrinterChange(() => n(t.printer)), r = t.onPrintersChange(() => n(t.printer));
    return () => {
      o(), r();
    };
  }, [t]), e;
}
function an(t, e) {
  return t("spoolman.common.grams", { value: Math.round(e) });
}
function vt(t, e, n) {
  return e === "g" ? an(t, n) : t("spoolman.common.metres", { value: (n / 1e3).toFixed(1) });
}
function ln(t, e) {
  switch (e.kind) {
    case "no-spool":
      return t("spoolman.issue.noSpool");
    case "material":
      return t("spoolman.issue.material", { expected: e.expected, actual: e.actual });
    case "insufficient":
      return t("spoolman.issue.insufficient", {
        required: vt(t, e.unit, e.required),
        remaining: vt(t, e.unit, e.remaining)
      });
    case "unavailable":
      return t("spoolman.issue.unavailable", { message: e.message });
  }
}
function De(t) {
  const e = [t.filament.vendor?.name, t.filament.name].filter(Boolean);
  return `#${t.id} ${e.join(" ") || t.filament.material || ""}`.trim();
}
function Ze({ t, spool: e, loading: n }) {
  if (e === void 0 || n)
    return /* @__PURE__ */ u("div", { class: "spm-spool", children: [
      /* @__PURE__ */ u("span", { class: "spm-swatch spm-swatch-empty" }),
      /* @__PURE__ */ u("span", { class: "spm-muted", children: t("spoolman.common.loading") })
    ] });
  if (e === null)
    return /* @__PURE__ */ u("div", { class: "spm-spool", children: [
      /* @__PURE__ */ u("span", { class: "spm-swatch spm-swatch-empty" }),
      /* @__PURE__ */ u("span", { class: "spm-muted", children: t("spoolman.widget.empty") })
    ] });
  const o = e.filament.color_hex ? `#${e.filament.color_hex.replace(/^#/, "")}` : void 0, r = e.filament.weight, i = e.remaining_weight, s = r && i !== void 0 ? Math.max(0, Math.min(1, i / r)) : null;
  return /* @__PURE__ */ u("div", { class: "spm-spool", children: [
    /* @__PURE__ */ u("span", { class: o ? "spm-swatch" : "spm-swatch spm-swatch-empty", style: o ? { background: o } : void 0 }),
    /* @__PURE__ */ u("div", { class: "spm-spool-text", children: [
      /* @__PURE__ */ u("span", { class: "spm-spool-name", title: De(e), children: De(e) }),
      /* @__PURE__ */ u("span", { class: "spm-muted", children: [e.filament.material, i !== void 0 ? t("spoolman.widget.left", { value: an(t, i) }) : null].filter(Boolean).join(" · ") }),
      s !== null && /* @__PURE__ */ u("div", { class: s < 0.15 ? "spm-bar low" : "spm-bar", children: /* @__PURE__ */ u("span", { style: { width: `${(s * 100).toFixed(1)}%` } }) })
    ] })
  ] });
}
function cn({ api: t, printerId: e, tool: n, currentId: o, expectedMaterial: r, onDone: i }) {
  const s = (v, S) => t.i18n.t(v, S), [c, p] = N(null), [l, f] = N(null), [_, a] = N(null), [d, g] = N(""), [T, w] = N(!1);
  Se(() => {
    let v = !0;
    return Ln(t.moonrakerFor(e)).then((S) => v && p(S.filter((P) => !P.archived))).catch((S) => v && f(S instanceof Error ? S.message : String(S))), () => {
      v = !1;
    };
  }, [t, e]);
  const b = Ge(() => {
    const v = d.trim().toLowerCase(), S = (c ?? []).filter((C) => v ? `#${C.id} ${De(C)} ${C.filament.material ?? ""} ${C.location ?? ""}`.toLowerCase().includes(v) : !0), P = (C) => r && C.filament.material ? Qt(r, C.filament.material) : !1;
    return S.sort((C, B) => Number(P(B)) - Number(P(C)) || C.id - B.id);
  }, [c, d, r]);
  async function m(v) {
    w(!0), a(null);
    try {
      await no(t, e, n, v), i();
    } catch (S) {
      const P = S instanceof Error ? S.message : String(S);
      a(P === "save_variables" ? s("spoolman.picker.needsSaveVars") : s("spoolman.picker.saveFailed", { message: P }));
    } finally {
      w(!1);
    }
  }
  return /* @__PURE__ */ u("div", { class: "spm-picker", children: [
    /* @__PURE__ */ u(
      "input",
      {
        class: "spm-input",
        type: "search",
        placeholder: s("spoolman.picker.search"),
        value: d,
        onInput: (v) => g(v.currentTarget.value)
      }
    ),
    l && /* @__PURE__ */ u("p", { class: "spm-error", children: s("spoolman.picker.error", { message: l }) }),
    _ && /* @__PURE__ */ u("p", { class: "spm-error", children: _ }),
    c === null && !l && /* @__PURE__ */ u("p", { class: "spm-muted", children: s("spoolman.common.loading") }),
    c !== null && b.length === 0 && /* @__PURE__ */ u("p", { class: "spm-muted", children: s("spoolman.picker.empty") }),
    /* @__PURE__ */ u("div", { class: "spm-picker-list", children: b.map((v) => /* @__PURE__ */ u(
      "button",
      {
        type: "button",
        class: v.id === o ? "spm-picker-item current" : "spm-picker-item",
        disabled: T,
        onClick: () => m(v.id),
        children: /* @__PURE__ */ u(Ze, { t: s, spool: v })
      },
      v.id
    )) }),
    o !== null && /* @__PURE__ */ u("div", { children: /* @__PURE__ */ u("button", { type: "button", class: "spm-btn", disabled: T, onClick: () => m(null), children: s("spoolman.picker.clear") }) })
  ] });
}
function oo({ api: t }) {
  const e = z(t), n = F.value[0], o = Ve.value;
  if (n)
    return /* @__PURE__ */ u(ro, { api: t, check: n, queued: F.value.length - 1 }, n.token);
  if (o) {
    const r = U.value[o.printerId] ?? se(), i = () => Ve.value = null;
    return /* @__PURE__ */ u("div", { class: "spm-backdrop", onClick: (s) => s.target === s.currentTarget && i(), children: /* @__PURE__ */ u("div", { class: "spm-dialog", role: "dialog", "aria-modal": "true", children: [
      /* @__PURE__ */ u("div", { class: "spm-dialog-header", children: /* @__PURE__ */ u("h3", { children: e("spoolman.picker.title", { tool: o.tool }) }) }),
      /* @__PURE__ */ u("div", { class: "spm-dialog-body", children: /* @__PURE__ */ u(
        cn,
        {
          api: t,
          printerId: o.printerId,
          tool: o.tool,
          currentId: ie(r, o.tool),
          onDone: i
        }
      ) }),
      /* @__PURE__ */ u("div", { class: "spm-dialog-footer", children: /* @__PURE__ */ u("button", { type: "button", class: "spm-btn", onClick: i, children: e("spoolman.common.close") }) })
    ] }) });
  }
  return null;
}
function ro({ api: t, check: e, queued: n }) {
  const o = z(t), [r, i] = N(null), s = U.value[e.printerId] ?? se(), c = t.printers.find((_) => _.id === e.printerId)?.name ?? e.printerId, p = (e.file?.tools ?? [0]).map((_) => `T${_}`), l = e.issues.filter((_) => _.kind === "unavailable"), f = e.issues.length > 0;
  return /* @__PURE__ */ u("div", { class: "spm-backdrop", children: /* @__PURE__ */ u("div", { class: "spm-dialog", role: "dialog", "aria-modal": "true", "aria-labelledby": "spm-check-title", children: [
    /* @__PURE__ */ u("div", { class: "spm-dialog-header", children: [
      /* @__PURE__ */ u("h3", { id: "spm-check-title", children: o("spoolman.check.title") }),
      /* @__PURE__ */ u("div", { class: "spm-muted", children: o("spoolman.check.file", { name: e.filename }) }),
      t.printers.length > 1 && /* @__PURE__ */ u("div", { class: "spm-muted", children: o("spoolman.check.printer", { name: c }) })
    ] }),
    /* @__PURE__ */ u("div", { class: "spm-dialog-body", children: [
      l.map((_, a) => /* @__PURE__ */ u("p", { class: "spm-error", children: ln(o, _) }, a)),
      p.map((_) => /* @__PURE__ */ u(
        io,
        {
          api: t,
          check: e,
          tool: _,
          showLabel: p.length > 1 || s.tools.length > 1,
          issues: e.issues.filter((a) => a.kind !== "unavailable" && a.tool === _),
          pickerOpen: r === _,
          onTogglePicker: () => i(r === _ ? null : _),
          onPicked: () => {
            i(null), to(e.token);
          }
        },
        _
      )),
      e.checking && /* @__PURE__ */ u("p", { class: "spm-muted", children: o("spoolman.check.checking") }),
      !e.checking && !f && /* @__PURE__ */ u("p", { class: "spm-ok", children: o("spoolman.check.ok") }),
      n > 0 && /* @__PURE__ */ u("p", { class: "spm-muted", children: o("spoolman.check.queued", { count: n }) })
    ] }),
    /* @__PURE__ */ u("div", { class: "spm-dialog-footer", children: [
      /* @__PURE__ */ u("button", { type: "button", class: "spm-btn", onClick: () => ht(e.token, "deny"), children: o("spoolman.check.cancel") }),
      /* @__PURE__ */ u(
        "button",
        {
          type: "button",
          class: f ? "spm-btn spm-btn-danger" : "spm-btn spm-btn-primary",
          disabled: e.checking,
          onClick: () => ht(e.token, "accept"),
          children: o(f ? "spoolman.check.printAnyway" : "spoolman.check.print")
        }
      )
    ] })
  ] }) });
}
function io({ api: t, check: e, tool: n, showLabel: o, issues: r, pickerOpen: i, onTogglePicker: s, onPicked: c }) {
  const p = z(t), l = U.value[e.printerId] ?? se(), f = ie(l, n), _ = en(e.printerId, f), a = e.file ? Zt(e.file, Number(n.slice(1))) : "";
  return /* @__PURE__ */ u("div", { class: r.length > 0 ? "spm-check-tool has-issue" : "spm-check-tool", children: [
    /* @__PURE__ */ u("div", { class: "spm-tool", style: { border: "none", padding: 0 }, children: [
      o && /* @__PURE__ */ u("span", { class: "spm-tool-label", children: n }),
      /* @__PURE__ */ u(Ze, { t: p, spool: _ }),
      /* @__PURE__ */ u("button", { type: "button", class: "spm-btn", onClick: s, children: p("spoolman.widget.change") })
    ] }),
    r.map((d, g) => /* @__PURE__ */ u("span", { class: "spm-warn", children: ln(p, d) }, g)),
    i && /* @__PURE__ */ u(
      cn,
      {
        api: t,
        printerId: e.printerId,
        tool: n,
        currentId: f,
        expectedMaterial: a || void 0,
        onDone: c
      }
    )
  ] });
}
const Ue = "spoolmanUrl";
function so({ api: t }) {
  const e = z(t), n = Qe(t), [o, r] = N(void 0), [i, s] = N(""), [c, p] = N(void 0);
  if (Se(() => {
    if (!n.id) return;
    const a = t.settings.get(Ue) || void 0;
    r(a), s(a ?? "");
    let d = !0;
    return jn(t.moonrakerFor(n.id)).then((g) => d && p(g)).catch(() => d && p(void 0)), () => {
      d = !1;
    };
  }, [t, n.id]), !n.id) return /* @__PURE__ */ u("div", { class: "spm-page", children: /* @__PURE__ */ u("p", { class: "spm-muted", children: e("spoolman.common.noPrinter") }) });
  const l = In(o, c, n.url);
  function f() {
    const a = i.trim();
    t.settings.set(Ue, a || null), r(a || void 0);
  }
  function _() {
    t.settings.set(Ue, null), r(void 0), s("");
  }
  return /* @__PURE__ */ u("div", { class: "spm-page spm-root", children: [
    /* @__PURE__ */ u("div", { class: "spm-page-bar", children: [
      /* @__PURE__ */ u(
        "input",
        {
          class: "spm-input",
          type: "url",
          "aria-label": e("spoolman.page.url"),
          placeholder: l ?? "http://printer.local:7912",
          value: i,
          onInput: (a) => s(a.currentTarget.value),
          onKeyDown: (a) => a.key === "Enter" && f()
        }
      ),
      /* @__PURE__ */ u("button", { type: "button", class: "spm-btn spm-btn-primary", onClick: f, children: e("spoolman.page.save") }),
      o && /* @__PURE__ */ u("button", { type: "button", class: "spm-btn", onClick: _, children: e("spoolman.page.reset") }),
      l && /* @__PURE__ */ u("a", { class: "spm-btn", href: l, target: "_blank", rel: "noopener noreferrer", children: e("spoolman.page.openTab") })
    ] }),
    l ? /* @__PURE__ */ u(D, { children: [
      /* @__PURE__ */ u("iframe", { class: "spm-frame", src: l, title: "Spoolman" }),
      /* @__PURE__ */ u("p", { class: "spm-muted", children: e("spoolman.page.frameHint") })
    ] }) : /* @__PURE__ */ u("p", { class: "spm-muted", children: e("spoolman.page.unknownUrl") })
  ] });
}
const ao = `
.spm-root { display: flex; flex-direction: column; gap: var(--space-sm); min-height: 0; height: 100%;
  color: var(--text-primary); font-family: var(--font-family); font-size: var(--font-size-md); }
.spm-muted { color: var(--text-muted); font-size: var(--font-size-sm); }
.spm-warn { color: var(--warning); font-size: var(--font-size-sm); }
.spm-error { color: var(--danger); font-size: var(--font-size-sm); }
.spm-ok { color: var(--success); font-size: var(--font-size-sm); }

.spm-btn { padding: var(--space-xs) var(--space-md); border: none; border-radius: var(--radius-md);
  background: var(--bg-surface-hover-no-override); color: var(--text-primary);
  font: inherit; font-size: var(--font-size-sm); cursor: pointer; white-space: nowrap; }
.spm-btn:hover { background: var(--bg-surface-hover); }
.spm-btn:focus-visible, .spm-input:focus-visible { outline: 2px solid var(--accent-ring); outline-offset: 1px; }
.spm-btn:disabled { opacity: 0.5; cursor: not-allowed; }
.spm-btn-primary { background: var(--accent); color: var(--accent-text); }
.spm-btn-primary:hover { background: var(--accent-hover); }
.spm-btn-danger { background: var(--danger); color: #fff; }
.spm-icon-btn { padding: var(--space-xs); background: transparent; color: var(--text-secondary); line-height: 0; }
.spm-icon-btn svg { width: 18px; height: 18px; }

.spm-input { padding: var(--space-xs) var(--space-sm); border: 1px solid var(--border-color);
  border-radius: var(--radius-md); background: var(--bg-surface); color: var(--text-primary); font: inherit; min-width: 0; }

.spm-swatch { width: 28px; height: 28px; border-radius: 50%; flex-shrink: 0;
  border: 1px solid var(--border-color); box-shadow: inset 0 0 0 4px var(--bg-surface); }
.spm-swatch-empty { background: repeating-linear-gradient(45deg, transparent 0 4px, var(--border-color) 4px 5px); }

.spm-spool { display: flex; align-items: center; gap: var(--space-sm); min-width: 0; }
.spm-spool-text { display: flex; flex-direction: column; min-width: 0; flex: 1; }
.spm-spool-name { font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.spm-bar { height: 4px; border-radius: 2px; background: var(--bg-surface-hover-no-override); overflow: hidden; margin-top: 2px; }
.spm-bar > span { display: block; height: 100%; background: var(--accent); }
.spm-bar.low > span { background: var(--warning); }

.spm-tools { display: flex; flex-direction: column; gap: var(--space-sm); overflow: auto; min-height: 0; }
.spm-tool { display: flex; align-items: center; gap: var(--space-sm); padding: var(--space-xs) var(--space-sm);
  border: 1px solid var(--border-color); border-radius: var(--radius-md); }
.spm-tool-label { font-weight: 600; color: var(--text-secondary); min-width: 2.2em; }
.spm-tool .spm-spool { flex: 1; }

.spm-header { display: flex; gap: var(--space-xs); align-items: center; }

/* Overlay: the host layer is pointer-events:none and full-screen; we draw our
   own backdrop + dialog and render NOTHING while closed (see Overlay.tsx). */
.spm-backdrop { position: fixed; inset: 0; background: var(--bg-overlay);
  display: flex; align-items: center; justify-content: center; padding: var(--space-md); }
.spm-dialog { width: min(560px, 100%); max-height: min(720px, 100%); display: flex; flex-direction: column;
  background: var(--bg-surface); border-radius: var(--radius-lg); box-shadow: var(--shadow-lg); overflow: hidden;
  color: var(--text-primary); font-family: var(--font-family); }
.spm-dialog-header { padding: var(--space-md) var(--space-lg); border-bottom: 1px solid var(--border-color); }
.spm-dialog-header h3 { margin: 0; font-size: var(--font-size-lg); font-weight: 600; }
.spm-dialog-body { padding: var(--space-md) var(--space-lg); display: flex; flex-direction: column;
  gap: var(--space-sm); overflow: auto; min-height: 0; }
.spm-dialog-footer { display: flex; justify-content: flex-end; gap: var(--space-sm); flex-wrap: wrap;
  padding: var(--space-md) var(--space-lg); border-top: 1px solid var(--border-color); }
.spm-check-tool { display: flex; flex-direction: column; gap: var(--space-xs); padding: var(--space-sm);
  border: 1px solid var(--border-color); border-radius: var(--radius-md); }
.spm-check-tool.has-issue { border-color: var(--warning); }

.spm-picker { display: flex; flex-direction: column; gap: var(--space-sm); min-height: 0; }
.spm-picker-list { display: flex; flex-direction: column; gap: 2px; overflow: auto; max-height: 320px; }
.spm-picker-item { display: block; width: 100%; text-align: start; padding: var(--space-xs) var(--space-sm);
  border: 1px solid transparent; border-radius: var(--radius-md); background: transparent;
  color: inherit; font: inherit; cursor: pointer; }
.spm-picker-item:hover { background: var(--bg-surface-hover); }
.spm-picker-item.current { border-color: var(--accent); background: var(--bg-surface-active); }

.spm-page { display: flex; flex-direction: column; gap: var(--space-sm); padding: var(--space-md); }
.spm-page-bar { display: flex; gap: var(--space-sm); align-items: center; flex-wrap: wrap; }
.spm-page-bar .spm-input { flex: 1; min-width: 200px; }
.spm-frame { width: 100%; height: calc(100dvh - 180px); min-height: 420px; border: 1px solid var(--border-color);
  border-radius: var(--radius-md); background: var(--bg-surface); }

@media (pointer: coarse) {
  .spm-btn { padding: var(--space-sm) var(--space-md); }
  .spm-picker-item { padding: var(--space-sm); }
}
`;
let gt = !1;
function lo() {
  if (gt || typeof document > "u") return;
  gt = !0;
  const t = document.createElement("style");
  t.dataset.plugin = "tessera/spoolman", t.textContent = ao, document.head.append(t);
}
function co({ api: t }) {
  const e = z(t), n = Qe(t);
  if (!n.id) return /* @__PURE__ */ u("div", { class: "spm-root", children: /* @__PURE__ */ u("p", { class: "spm-muted", children: e("spoolman.common.noPrinter") }) });
  const o = U.value[n.id];
  if (!o?.ready) return /* @__PURE__ */ u("div", { class: "spm-root", children: /* @__PURE__ */ u("p", { class: "spm-muted", children: e("spoolman.common.loading") }) });
  if (!o.hasSpoolman) return /* @__PURE__ */ u("div", { class: "spm-root", children: /* @__PURE__ */ u("p", { class: "spm-muted", children: e("spoolman.common.notConfigured") }) });
  const r = Gt(o);
  return /* @__PURE__ */ u("div", { class: "spm-root", children: [
    o.connected === !1 && /* @__PURE__ */ u("p", { class: "spm-warn", children: e("spoolman.common.disconnected") }),
    /* @__PURE__ */ u("div", { class: "spm-tools", children: r.map((i) => /* @__PURE__ */ u(uo, { api: t, printerId: n.id, state: o, tool: i, showLabel: o.tools.length > 1 }, i)) })
  ] });
}
function uo(t) {
  const { api: e, printerId: n, state: o, tool: r, showLabel: i } = t, s = z(e), c = en(n, ie(o, r));
  return /* @__PURE__ */ u("div", { class: "spm-tool", children: [
    i && /* @__PURE__ */ u("span", { class: "spm-tool-label", children: r }),
    /* @__PURE__ */ u(Ze, { t: s, spool: c }),
    /* @__PURE__ */ u("button", { type: "button", class: "spm-btn", onClick: () => Ve.value = { printerId: n, tool: r }, children: s("spoolman.widget.change") })
  ] });
}
const po = /* @__PURE__ */ u("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round", children: [
  /* @__PURE__ */ u("path", { d: "M21 12a9 9 0 1 1-3-6.7L21 8" }),
  /* @__PURE__ */ u("path", { d: "M21 3v5h-5" })
] }), fo = /* @__PURE__ */ u("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round", children: [
  /* @__PURE__ */ u("path", { d: "M15 3h6v6" }),
  /* @__PURE__ */ u("path", { d: "M10 14 21 3" }),
  /* @__PURE__ */ u("path", { d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" })
] });
function _o({ api: t }) {
  const e = z(t), n = Qe(t);
  if (!n.id) return null;
  async function o() {
    await Zn(n.id), tn(n.id);
    const r = O(n.id);
    for (const i of Gt(r)) {
      const s = ie(r, i);
      s != null && Je(n.id, s, !0).catch(() => {
      });
    }
  }
  return /* @__PURE__ */ u("div", { class: "spm-header", children: [
    /* @__PURE__ */ u("button", { type: "button", class: "spm-btn spm-icon-btn", title: e("spoolman.common.refresh"), "aria-label": e("spoolman.common.refresh"), onClick: o, children: po }),
    /* @__PURE__ */ u("a", { class: "spm-btn spm-icon-btn", href: `#/p/${encodeURIComponent(n.id)}/spoolman`, title: e("spoolman.widget.openPage"), "aria-label": e("spoolman.widget.openPage"), children: fo })
  ] });
}
lo();
Te("tessera-spoolman-page", so);
Te("tessera-spoolman-widget", co);
Te("tessera-spoolman-widget-header", _o);
Te("tessera-spoolman-overlay", oo);
An(Jn);
const ho = { en: Mn, ru: Un }, vo = {
  spool: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/><path d="M12 3v4"/><path d="M12 17v4"/></svg>'
};
export {
  mo as guardPrintStart,
  ho as locales,
  vo as pageIcons
};
