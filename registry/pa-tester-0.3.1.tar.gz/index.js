/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Cn = globalThis, Vi = Cn.ShadowRoot && (Cn.ShadyCSS === void 0 || Cn.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, Gi = Symbol(), Vl = /* @__PURE__ */ new WeakMap();
let Kr = class {
  constructor(e, n, s) {
    if (this._$cssResult$ = !0, s !== Gi) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = e, this.t = n;
  }
  get styleSheet() {
    let e = this.o;
    const n = this.t;
    if (Vi && e === void 0) {
      const s = n !== void 0 && n.length === 1;
      s && (e = Vl.get(n)), e === void 0 && ((this.o = e = new CSSStyleSheet()).replaceSync(this.cssText), s && Vl.set(n, e));
    }
    return e;
  }
  toString() {
    return this.cssText;
  }
};
const jr = (t) => new Kr(typeof t == "string" ? t : t + "", void 0, Gi), qr = (t, ...e) => {
  const n = t.length === 1 ? t[0] : e.reduce((s, i, r) => s + ((a) => {
    if (a._$cssResult$ === !0) return a.cssText;
    if (typeof a == "number") return a;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + a + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(i) + t[r + 1], t[0]);
  return new Kr(n, t, Gi);
}, Ta = (t, e) => {
  if (Vi) t.adoptedStyleSheets = e.map((n) => n instanceof CSSStyleSheet ? n : n.styleSheet);
  else for (const n of e) {
    const s = document.createElement("style"), i = Cn.litNonce;
    i !== void 0 && s.setAttribute("nonce", i), s.textContent = n.cssText, t.appendChild(s);
  }
}, Gl = Vi ? (t) => t : (t) => t instanceof CSSStyleSheet ? ((e) => {
  let n = "";
  for (const s of e.cssRules) n += s.cssText;
  return jr(n);
})(t) : t;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: Ma, defineProperty: Ra, getOwnPropertyDescriptor: Ca, getOwnPropertyNames: Pa, getOwnPropertySymbols: Na, getPrototypeOf: La } = Object, Fn = globalThis, Bl = Fn.trustedTypes, Oa = Bl ? Bl.emptyScript : "", Da = Fn.reactiveElementPolyfillSupport, on = (t, e) => t, ki = { toAttribute(t, e) {
  switch (e) {
    case Boolean:
      t = t ? Oa : null;
      break;
    case Object:
    case Array:
      t = t == null ? t : JSON.stringify(t);
  }
  return t;
}, fromAttribute(t, e) {
  let n = t;
  switch (e) {
    case Boolean:
      n = t !== null;
      break;
    case Number:
      n = t === null ? null : Number(t);
      break;
    case Object:
    case Array:
      try {
        n = JSON.parse(t);
      } catch {
        n = null;
      }
  }
  return n;
} }, Yr = (t, e) => !Ma(t, e), Kl = { attribute: !0, type: String, converter: ki, reflect: !1, useDefault: !1, hasChanged: Yr };
Symbol.metadata ??= Symbol("metadata"), Fn.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
let Rs = class extends HTMLElement {
  static addInitializer(e) {
    this._$Ei(), (this.l ??= []).push(e);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(e, n = Kl) {
    if (n.state && (n.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(e) && ((n = Object.create(n)).wrapped = !0), this.elementProperties.set(e, n), !n.noAccessor) {
      const s = Symbol(), i = this.getPropertyDescriptor(e, s, n);
      i !== void 0 && Ra(this.prototype, e, i);
    }
  }
  static getPropertyDescriptor(e, n, s) {
    const { get: i, set: r } = Ca(this.prototype, e) ?? { get() {
      return this[n];
    }, set(a) {
      this[n] = a;
    } };
    return { get: i, set(a) {
      const h = i?.call(this);
      r?.call(this, a), this.requestUpdate(e, h, s);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(e) {
    return this.elementProperties.get(e) ?? Kl;
  }
  static _$Ei() {
    if (this.hasOwnProperty(on("elementProperties"))) return;
    const e = La(this);
    e.finalize(), e.l !== void 0 && (this.l = [...e.l]), this.elementProperties = new Map(e.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(on("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(on("properties"))) {
      const n = this.properties, s = [...Pa(n), ...Na(n)];
      for (const i of s) this.createProperty(i, n[i]);
    }
    const e = this[Symbol.metadata];
    if (e !== null) {
      const n = litPropertyMetadata.get(e);
      if (n !== void 0) for (const [s, i] of n) this.elementProperties.set(s, i);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [n, s] of this.elementProperties) {
      const i = this._$Eu(n, s);
      i !== void 0 && this._$Eh.set(i, n);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(e) {
    const n = [];
    if (Array.isArray(e)) {
      const s = new Set(e.flat(1 / 0).reverse());
      for (const i of s) n.unshift(Gl(i));
    } else e !== void 0 && n.push(Gl(e));
    return n;
  }
  static _$Eu(e, n) {
    const s = n.attribute;
    return s === !1 ? void 0 : typeof s == "string" ? s : typeof e == "string" ? e.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise((e) => this.enableUpdating = e), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((e) => e(this));
  }
  addController(e) {
    (this._$EO ??= /* @__PURE__ */ new Set()).add(e), this.renderRoot !== void 0 && this.isConnected && e.hostConnected?.();
  }
  removeController(e) {
    this._$EO?.delete(e);
  }
  _$E_() {
    const e = /* @__PURE__ */ new Map(), n = this.constructor.elementProperties;
    for (const s of n.keys()) this.hasOwnProperty(s) && (e.set(s, this[s]), delete this[s]);
    e.size > 0 && (this._$Ep = e);
  }
  createRenderRoot() {
    const e = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return Ta(e, this.constructor.elementStyles), e;
  }
  connectedCallback() {
    this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$EO?.forEach((e) => e.hostConnected?.());
  }
  enableUpdating(e) {
  }
  disconnectedCallback() {
    this._$EO?.forEach((e) => e.hostDisconnected?.());
  }
  attributeChangedCallback(e, n, s) {
    this._$AK(e, s);
  }
  _$ET(e, n) {
    const s = this.constructor.elementProperties.get(e), i = this.constructor._$Eu(e, s);
    if (i !== void 0 && s.reflect === !0) {
      const r = (s.converter?.toAttribute !== void 0 ? s.converter : ki).toAttribute(n, s.type);
      this._$Em = e, r == null ? this.removeAttribute(i) : this.setAttribute(i, r), this._$Em = null;
    }
  }
  _$AK(e, n) {
    const s = this.constructor, i = s._$Eh.get(e);
    if (i !== void 0 && this._$Em !== i) {
      const r = s.getPropertyOptions(i), a = typeof r.converter == "function" ? { fromAttribute: r.converter } : r.converter?.fromAttribute !== void 0 ? r.converter : ki;
      this._$Em = i;
      const h = a.fromAttribute(n, r.type);
      this[i] = h ?? this._$Ej?.get(i) ?? h, this._$Em = null;
    }
  }
  requestUpdate(e, n, s, i = !1, r) {
    if (e !== void 0) {
      const a = this.constructor;
      if (i === !1 && (r = this[e]), s ??= a.getPropertyOptions(e), !((s.hasChanged ?? Yr)(r, n) || s.useDefault && s.reflect && r === this._$Ej?.get(e) && !this.hasAttribute(a._$Eu(e, s)))) return;
      this.C(e, n, s);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(e, n, { useDefault: s, reflect: i, wrapped: r }, a) {
    s && !(this._$Ej ??= /* @__PURE__ */ new Map()).has(e) && (this._$Ej.set(e, a ?? n ?? this[e]), r !== !0 || a !== void 0) || (this._$AL.has(e) || (this.hasUpdated || s || (n = void 0), this._$AL.set(e, n)), i === !0 && this._$Em !== e && (this._$Eq ??= /* @__PURE__ */ new Set()).add(e));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (n) {
      Promise.reject(n);
    }
    const e = this.scheduleUpdate();
    return e != null && await e, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
        for (const [i, r] of this._$Ep) this[i] = r;
        this._$Ep = void 0;
      }
      const s = this.constructor.elementProperties;
      if (s.size > 0) for (const [i, r] of s) {
        const { wrapped: a } = r, h = this[i];
        a !== !0 || this._$AL.has(i) || h === void 0 || this.C(i, void 0, r, h);
      }
    }
    let e = !1;
    const n = this._$AL;
    try {
      e = this.shouldUpdate(n), e ? (this.willUpdate(n), this._$EO?.forEach((s) => s.hostUpdate?.()), this.update(n)) : this._$EM();
    } catch (s) {
      throw e = !1, this._$EM(), s;
    }
    e && this._$AE(n);
  }
  willUpdate(e) {
  }
  _$AE(e) {
    this._$EO?.forEach((n) => n.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(e)), this.updated(e);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(e) {
    return !0;
  }
  update(e) {
    this._$Eq &&= this._$Eq.forEach((n) => this._$ET(n, this[n])), this._$EM();
  }
  updated(e) {
  }
  firstUpdated(e) {
  }
};
Rs.elementStyles = [], Rs.shadowRootOptions = { mode: "open" }, Rs[on("elementProperties")] = /* @__PURE__ */ new Map(), Rs[on("finalized")] = /* @__PURE__ */ new Map(), Da?.({ ReactiveElement: Rs }), (Fn.reactiveElementVersions ??= []).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Bi = globalThis, jl = (t) => t, Ln = Bi.trustedTypes, ql = Ln ? Ln.createPolicy("lit-html", { createHTML: (t) => t }) : void 0, Jr = "$lit$", Wt = `lit$${Math.random().toFixed(9).slice(2)}$`, Zr = "?" + Wt, za = `<${Zr}>`, rs = document, un = () => rs.createComment(""), hn = (t) => t === null || typeof t != "object" && typeof t != "function", Ki = Array.isArray, Ha = (t) => Ki(t) || typeof t?.[Symbol.iterator] == "function", bi = `[ 	
\f\r]`, Zs = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Yl = /-->/g, Jl = />/g, es = RegExp(`>|${bi}(?:([^\\s"'>=/]+)(${bi}*=${bi}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Zl = /'/g, Ql = /"/g, Qr = /^(?:script|style|textarea|title)$/i, Fa = (t) => (e, ...n) => ({ _$litType$: t, strings: e, values: n }), F = Fa(1), Ls = Symbol.for("lit-noChange"), B = Symbol.for("lit-nothing"), Xl = /* @__PURE__ */ new WeakMap(), is = rs.createTreeWalker(rs, 129);
function Xr(t, e) {
  if (!Ki(t) || !t.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return ql !== void 0 ? ql.createHTML(e) : e;
}
const Ia = (t, e) => {
  const n = t.length - 1, s = [];
  let i, r = e === 2 ? "<svg>" : e === 3 ? "<math>" : "", a = Zs;
  for (let h = 0; h < n; h++) {
    const f = t[h];
    let p, g, d = -1, b = 0;
    for (; b < f.length && (a.lastIndex = b, g = a.exec(f), g !== null); ) b = a.lastIndex, a === Zs ? g[1] === "!--" ? a = Yl : g[1] !== void 0 ? a = Jl : g[2] !== void 0 ? (Qr.test(g[2]) && (i = RegExp("</" + g[2], "g")), a = es) : g[3] !== void 0 && (a = es) : a === es ? g[0] === ">" ? (a = i ?? Zs, d = -1) : g[1] === void 0 ? d = -2 : (d = a.lastIndex - g[2].length, p = g[1], a = g[3] === void 0 ? es : g[3] === '"' ? Ql : Zl) : a === Ql || a === Zl ? a = es : a === Yl || a === Jl ? a = Zs : (a = es, i = void 0);
    const S = a === es && t[h + 1].startsWith("/>") ? " " : "";
    r += a === Zs ? f + za : d >= 0 ? (s.push(p), f.slice(0, d) + Jr + f.slice(d) + Wt + S) : f + Wt + (d === -2 ? h : S);
  }
  return [Xr(t, r + (t[n] || "<?>") + (e === 2 ? "</svg>" : e === 3 ? "</math>" : "")), s];
};
class fn {
  constructor({ strings: e, _$litType$: n }, s) {
    let i;
    this.parts = [];
    let r = 0, a = 0;
    const h = e.length - 1, f = this.parts, [p, g] = Ia(e, n);
    if (this.el = fn.createElement(p, s), is.currentNode = this.el.content, n === 2 || n === 3) {
      const d = this.el.content.firstChild;
      d.replaceWith(...d.childNodes);
    }
    for (; (i = is.nextNode()) !== null && f.length < h; ) {
      if (i.nodeType === 1) {
        if (i.hasAttributes()) for (const d of i.getAttributeNames()) if (d.endsWith(Jr)) {
          const b = g[a++], S = i.getAttribute(d).split(Wt), $ = /([.?@])?(.*)/.exec(b);
          f.push({ type: 1, index: r, name: $[2], strings: S, ctor: $[1] === "." ? Wa : $[1] === "?" ? Va : $[1] === "@" ? Ga : In }), i.removeAttribute(d);
        } else d.startsWith(Wt) && (f.push({ type: 6, index: r }), i.removeAttribute(d));
        if (Qr.test(i.tagName)) {
          const d = i.textContent.split(Wt), b = d.length - 1;
          if (b > 0) {
            i.textContent = Ln ? Ln.emptyScript : "";
            for (let S = 0; S < b; S++) i.append(d[S], un()), is.nextNode(), f.push({ type: 2, index: ++r });
            i.append(d[b], un());
          }
        }
      } else if (i.nodeType === 8) if (i.data === Zr) f.push({ type: 2, index: r });
      else {
        let d = -1;
        for (; (d = i.data.indexOf(Wt, d + 1)) !== -1; ) f.push({ type: 7, index: r }), d += Wt.length - 1;
      }
      r++;
    }
  }
  static createElement(e, n) {
    const s = rs.createElement("template");
    return s.innerHTML = e, s;
  }
}
function Os(t, e, n = t, s) {
  if (e === Ls) return e;
  let i = s !== void 0 ? n._$Co?.[s] : n._$Cl;
  const r = hn(e) ? void 0 : e._$litDirective$;
  return i?.constructor !== r && (i?._$AO?.(!1), r === void 0 ? i = void 0 : (i = new r(t), i._$AT(t, n, s)), s !== void 0 ? (n._$Co ??= [])[s] = i : n._$Cl = i), i !== void 0 && (e = Os(t, i._$AS(t, e.values), i, s)), e;
}
class Ua {
  constructor(e, n) {
    this._$AV = [], this._$AN = void 0, this._$AD = e, this._$AM = n;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(e) {
    const { el: { content: n }, parts: s } = this._$AD, i = (e?.creationScope ?? rs).importNode(n, !0);
    is.currentNode = i;
    let r = is.nextNode(), a = 0, h = 0, f = s[0];
    for (; f !== void 0; ) {
      if (a === f.index) {
        let p;
        f.type === 2 ? p = new gn(r, r.nextSibling, this, e) : f.type === 1 ? p = new f.ctor(r, f.name, f.strings, this, e) : f.type === 6 && (p = new Ba(r, this, e)), this._$AV.push(p), f = s[++h];
      }
      a !== f?.index && (r = is.nextNode(), a++);
    }
    return is.currentNode = rs, i;
  }
  p(e) {
    let n = 0;
    for (const s of this._$AV) s !== void 0 && (s.strings !== void 0 ? (s._$AI(e, s, n), n += s.strings.length - 2) : s._$AI(e[n])), n++;
  }
}
class gn {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(e, n, s, i) {
    this.type = 2, this._$AH = B, this._$AN = void 0, this._$AA = e, this._$AB = n, this._$AM = s, this.options = i, this._$Cv = i?.isConnected ?? !0;
  }
  get parentNode() {
    let e = this._$AA.parentNode;
    const n = this._$AM;
    return n !== void 0 && e?.nodeType === 11 && (e = n.parentNode), e;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(e, n = this) {
    e = Os(this, e, n), hn(e) ? e === B || e == null || e === "" ? (this._$AH !== B && this._$AR(), this._$AH = B) : e !== this._$AH && e !== Ls && this._(e) : e._$litType$ !== void 0 ? this.$(e) : e.nodeType !== void 0 ? this.T(e) : Ha(e) ? this.k(e) : this._(e);
  }
  O(e) {
    return this._$AA.parentNode.insertBefore(e, this._$AB);
  }
  T(e) {
    this._$AH !== e && (this._$AR(), this._$AH = this.O(e));
  }
  _(e) {
    this._$AH !== B && hn(this._$AH) ? this._$AA.nextSibling.data = e : this.T(rs.createTextNode(e)), this._$AH = e;
  }
  $(e) {
    const { values: n, _$litType$: s } = e, i = typeof s == "number" ? this._$AC(e) : (s.el === void 0 && (s.el = fn.createElement(Xr(s.h, s.h[0]), this.options)), s);
    if (this._$AH?._$AD === i) this._$AH.p(n);
    else {
      const r = new Ua(i, this), a = r.u(this.options);
      r.p(n), this.T(a), this._$AH = r;
    }
  }
  _$AC(e) {
    let n = Xl.get(e.strings);
    return n === void 0 && Xl.set(e.strings, n = new fn(e)), n;
  }
  k(e) {
    Ki(this._$AH) || (this._$AH = [], this._$AR());
    const n = this._$AH;
    let s, i = 0;
    for (const r of e) i === n.length ? n.push(s = new gn(this.O(un()), this.O(un()), this, this.options)) : s = n[i], s._$AI(r), i++;
    i < n.length && (this._$AR(s && s._$AB.nextSibling, i), n.length = i);
  }
  _$AR(e = this._$AA.nextSibling, n) {
    for (this._$AP?.(!1, !0, n); e !== this._$AB; ) {
      const s = jl(e).nextSibling;
      jl(e).remove(), e = s;
    }
  }
  setConnected(e) {
    this._$AM === void 0 && (this._$Cv = e, this._$AP?.(e));
  }
}
class In {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(e, n, s, i, r) {
    this.type = 1, this._$AH = B, this._$AN = void 0, this.element = e, this.name = n, this._$AM = i, this.options = r, s.length > 2 || s[0] !== "" || s[1] !== "" ? (this._$AH = Array(s.length - 1).fill(new String()), this.strings = s) : this._$AH = B;
  }
  _$AI(e, n = this, s, i) {
    const r = this.strings;
    let a = !1;
    if (r === void 0) e = Os(this, e, n, 0), a = !hn(e) || e !== this._$AH && e !== Ls, a && (this._$AH = e);
    else {
      const h = e;
      let f, p;
      for (e = r[0], f = 0; f < r.length - 1; f++) p = Os(this, h[s + f], n, f), p === Ls && (p = this._$AH[f]), a ||= !hn(p) || p !== this._$AH[f], p === B ? e = B : e !== B && (e += (p ?? "") + r[f + 1]), this._$AH[f] = p;
    }
    a && !i && this.j(e);
  }
  j(e) {
    e === B ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, e ?? "");
  }
}
class Wa extends In {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(e) {
    this.element[this.name] = e === B ? void 0 : e;
  }
}
class Va extends In {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(e) {
    this.element.toggleAttribute(this.name, !!e && e !== B);
  }
}
class Ga extends In {
  constructor(e, n, s, i, r) {
    super(e, n, s, i, r), this.type = 5;
  }
  _$AI(e, n = this) {
    if ((e = Os(this, e, n, 0) ?? B) === Ls) return;
    const s = this._$AH, i = e === B && s !== B || e.capture !== s.capture || e.once !== s.once || e.passive !== s.passive, r = e !== B && (s === B || i);
    i && this.element.removeEventListener(this.name, this, s), r && this.element.addEventListener(this.name, this, e), this._$AH = e;
  }
  handleEvent(e) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, e) : this._$AH.handleEvent(e);
  }
}
class Ba {
  constructor(e, n, s) {
    this.element = e, this.type = 6, this._$AN = void 0, this._$AM = n, this.options = s;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(e) {
    Os(this, e);
  }
}
const Ka = Bi.litHtmlPolyfillSupport;
Ka?.(fn, gn), (Bi.litHtmlVersions ??= []).push("3.3.3");
const ja = (t, e, n) => {
  const s = n?.renderBefore ?? e;
  let i = s._$litPart$;
  if (i === void 0) {
    const r = n?.renderBefore ?? null;
    s._$litPart$ = i = new gn(e.insertBefore(un(), r), r, void 0, n ?? {});
  }
  return i._$AI(t), i;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const ji = globalThis;
class Ps extends Rs {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    const e = super.createRenderRoot();
    return this.renderOptions.renderBefore ??= e.firstChild, e;
  }
  update(e) {
    const n = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(e), this._$Do = ja(n, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return Ls;
  }
}
Ps._$litElement$ = !0, Ps.finalized = !0, ji.litElementHydrateSupport?.({ LitElement: Ps });
const qa = ji.litElementPolyfillSupport;
qa?.({ LitElement: Ps });
(ji.litElementVersions ??= []).push("4.2.2");
let eo = null;
function Ya(t) {
  eo = t;
}
function Ja() {
  return eo;
}
class Ti extends Ps {
  static properties = {
    api: { attribute: !1 },
    params: { attribute: !1 }
  };
  #e = [];
  constructor() {
    super(), this.api = null, this.params = {};
  }
  connectedCallback() {
    super.connectedCallback(), this.api && this.#s(this.api);
  }
  willUpdate(e) {
    e.has("api") && this.api && this.#e.length === 0 && this.isConnected && this.#s(this.api);
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    for (const e of this.#e) e();
    this.#e = [];
  }
  #s(e) {
    Ya(e), this.#e.push(e.onLocaleChange(() => this.requestUpdate()));
  }
  /** Translation through the HOST dictionary (our `locales` export is merged into it). */
  t(e, n) {
    return this.api ? this.api.i18n.t(e, n) : e;
  }
}
function qi(t, e) {
  customElements.get(t) || customElements.define(t, e);
}
const Za = {
  patester: {
    tabTitle: "Pressure Advance",
    title: "Pressure Advance",
    common: {
      loading: "Loading…",
      default: "default",
      noPrinter: "No active printer",
      configError: "Cannot read the printer config. Is Klipper ready?",
      copy: "Copy",
      copied: "Copied",
      copyManually: "Copy the text:"
    },
    install: {
      title: "pa_tester is not set up",
      intro: "This tab drives the Klipper module pa_tester, which measures Pressure Advance with a load cell in the nozzle. There is no [pa_tester] section in the printer config.",
      noLoadCell: "No [load_cell] or [load_cell_probe] in the printer config either: the module needs a load cell in the nozzle.",
      recheck: "Check again",
      stepModule: "The module is not in mainline Klipper. It lives in the generic-cartesian branch of the fork:",
      stepNumpy: "It needs NumPy in the Klipper Python environment.",
      stepConfig: "Add the section to printer.cfg (high_flow and purge_length are required; see the module source for the rest):",
      stepExtruder: "In [extruder], max_extrude_cross_section must allow the high flow.",
      stepRestart: "Restart Klipper completely: sudo systemctl restart klipper. The tab picks the module up by itself afterwards."
    },
    help: {
      title: "Help",
      runTitle: "Running a measurement",
      run: "Test only measures and reports. Calibrate also applies the result with SET_PRESSURE_ADVANCE. Empty fields use your [pa_tester] section. Axes must be homed, the extruder hot and the printer not printing. The run takes minutes; you can leave the tab, it keeps running in Klipper and is picked up again when you return.",
      applyTitle: "Apply vs printer.cfg",
      apply: "SET_PRESSURE_ADVANCE works at once but is lost on restart, and SAVE_CONFIG does not store it. Copy the value into the pressure_advance option of your [extruder] section to keep it.",
      chartTitle: "Load cell graph",
      chart: "The trace of the force sensor in the nozzle. It is streamed only while the graph is shown: hide it when you do not need it. Without the raw stream the graph falls back to about 4 samples per second."
    },
    command: {
      label: "Command",
      test: "Test",
      calibrate: "Calibrate",
      testHint: "TEST_PRESSURE_ADVANCE: measures and reports, changes nothing.",
      calibrateHint: "PA_CALIBRATE: measures and applies the result with SET_PRESSURE_ADVANCE."
    },
    method: {
      label: "Method",
      step_response: "Step response",
      search_overshoot: "Search overshoot",
      step_responseHint: "Extrudes at several flows and finds PA from the force response. Result per flow and overall.",
      search_overshootHint: "Searches the PA range for the value without overshoot. Set PA_RANGE to narrow it."
    },
    param: {
      SLOW_FLOW: "Slow flow, mm³/s (above 0)",
      HIGH_FLOW: "High flow, mm³/s: must be greater than slow flow",
      PURGE_LENGTH: "Filament length to purge, mm",
      SEGMENT_TIME: "Duration of one flow segment, s",
      TEST_REPETITIONS: "Repetitions (at least 1)",
      FILTER_WINDOW: "Force filter window, s (above 0, at most 0.04)",
      EXTRUDE_FORCE_SIGN: "Sign of the force while extruding: -1, 0 (auto) or 1",
      PA_RANGE: "min,max of the search: min ≥ 0, max below 2.0, min below max",
      EXTRUDER: "Extruder to test (must be the active one)",
      FORCE_SENSOR: "Load cell to use"
    },
    block: {
      klippy: "Klipper is not ready.",
      running: "A measurement is in progress.",
      printing: "Not available while printing.",
      homing: "Home all axes first.",
      cold: "The extruder is too cold to extrude: heat it up first.",
      noSensor: "No load cell in the printer config.",
      ambiguous: "Several load cells: choose FORCE_SENSOR.",
      invalid: "Invalid values: {fields}"
    },
    run: {
      test: "Run test",
      calibrate: "Calibrate",
      running: "Running…",
      home: "Home all",
      started: "Measuring: the result appears when Klipper finishes the calculation.",
      external: "started elsewhere",
      log: "Console log ({count} lines)",
      applyMeasured: "Apply",
      saveHint: "Applied until restart only. Put the value into [extruder] pressure_advance in printer.cfg to keep it."
    },
    confirm: {
      title: "Calibrate and apply?",
      body: "PA_CALIBRATE changes the pressure advance of the extruder when it finishes. The change is lost on restart unless you save it to printer.cfg.",
      ok: "Calibrate",
      cancel: "Cancel"
    },
    result: {
      title: "Result",
      current: "Current pressure advance of the extruder",
      lastKlipper: "Last result kept by Klipper: {test}, PA {pa}",
      flow: "Flow, mm³/s",
      pa: "Pressure advance",
      overall: "Overall pressure advance",
      tested: "Tested pressure advance",
      overshoot: "overshoot",
      noOvershoot: "no overshoot",
      found: "Found pressure advance",
      corrected: "Corrected for the force filter",
      forceSign: "Detected force sign: {sign}"
    },
    chart: {
      title: "Load cell",
      show: "Show",
      hide: "Hide",
      now: "now",
      min: "min",
      max: "max",
      counts: "counts",
      sec: "s",
      window: "Time window",
      pause: "Pause",
      resume: "Resume",
      clear: "Clear",
      connecting: "Connecting…",
      noData: "Waiting for data…",
      sourceStream: "raw stream",
      sourceStatus: "≈4 Hz",
      sourceStatusHint: "The raw stream is not available: the graph uses the status subscription (about 4 samples per second).",
      filter: "Filter",
      filter_raw: "Raw",
      filter_average: "Average",
      filter_moving: "Moving average",
      filter_median: "Moving median",
      filter_envelope: "Min/max envelope",
      filterMs: "Window",
      ms: "ms",
      showRaw: "Show raw",
      mains: "Mains filter",
      mainsHz: "Mains frequency",
      hz: "Hz",
      mainsLowRate: "Sensor too slow for the mains filter",
      tare: "Without calibration the graph shows counts relative to the tare. Tare the cell (LOAD_CELL_TARE) before a measurement."
    },
    guard: {
      printing: "Pressure advance measurement is not allowed while printing.",
      homing: "Home all axes before the pressure advance measurement.",
      cold: "The extruder is too cold for the pressure advance measurement."
    }
  }
}, Qa = {
  patester: {
    tabTitle: "Pressure Advance",
    title: "Pressure Advance",
    common: {
      loading: "Загрузка…",
      default: "по умолчанию",
      noPrinter: "Нет активного принтера",
      configError: "Не удалось прочитать конфигурацию принтера. Klipper готов?",
      copy: "Копировать",
      copied: "Скопировано",
      copyManually: "Скопируйте текст:"
    },
    install: {
      title: "pa_tester не настроен",
      intro: "Эта вкладка управляет модулем Klipper pa_tester, который измеряет Pressure Advance по датчику усилия в сопле. В конфигурации принтера нет секции [pa_tester].",
      noLoadCell: "Нет и [load_cell] или [load_cell_probe]: модулю нужен датчик усилия в сопле.",
      recheck: "Проверить снова",
      stepModule: "Модуля нет в основной ветке Klipper. Он лежит в ветке generic-cartesian форка:",
      stepNumpy: "Ему нужен NumPy в Python-окружении Klipper.",
      stepConfig: "Добавьте секцию в printer.cfg (high_flow и purge_length обязательны; остальное — в исходниках модуля):",
      stepExtruder: "В [extruder] max_extrude_cross_section должен допускать высокий расход.",
      stepRestart: "Полностью перезапустите Klipper: sudo systemctl restart klipper. После этого вкладка подхватит модуль сама."
    },
    help: {
      title: "Справка",
      runTitle: "Запуск измерения",
      run: "Test только измеряет и показывает результат. Calibrate дополнительно применяет его через SET_PRESSURE_ADVANCE. Пустые поля берутся из секции [pa_tester]. Оси должны быть в исходной позиции, экструдер горячим, принтер не печатает. Измерение идёт минуты; со вкладки можно уйти, оно продолжится в Klipper и подхватится при возвращении.",
      applyTitle: "Применение и printer.cfg",
      apply: "SET_PRESSURE_ADVANCE действует сразу, но пропадает при перезапуске, и SAVE_CONFIG его не сохраняет. Чтобы значение осталось, перенесите его в pressure_advance секции [extruder].",
      chartTitle: "График датчика усилия",
      chart: "Сигнал датчика усилия в сопле. Поток идёт, только пока график показан: скрывайте его, когда он не нужен. Без raw-потока график строится по статусу, около 4 отсчётов в секунду."
    },
    command: {
      label: "Команда",
      test: "Тест",
      calibrate: "Калибровка",
      testHint: "TEST_PRESSURE_ADVANCE: измеряет и показывает результат, ничего не меняет.",
      calibrateHint: "PA_CALIBRATE: измеряет и применяет результат через SET_PRESSURE_ADVANCE."
    },
    method: {
      label: "Метод",
      step_response: "Step response",
      search_overshoot: "Search overshoot",
      step_responseHint: "Экструзия на нескольких расходах, PA находится по отклику усилия. Результат по каждому расходу и общий.",
      search_overshootHint: "Поиск значения PA без перерегулирования в заданном диапазоне. Сузить диапазон можно через PA_RANGE."
    },
    param: {
      SLOW_FLOW: "Медленный расход, мм³/с (больше 0)",
      HIGH_FLOW: "Быстрый расход, мм³/с: должен быть больше медленного",
      PURGE_LENGTH: "Длина прутка для прочистки, мм",
      SEGMENT_TIME: "Длительность сегмента одного расхода, с",
      TEST_REPETITIONS: "Число повторов (не меньше 1)",
      FILTER_WINDOW: "Окно фильтра усилия, с (больше 0, не больше 0.04)",
      EXTRUDE_FORCE_SIGN: "Знак усилия при экструзии: -1, 0 (авто) или 1",
      PA_RANGE: "min,max поиска: min ≥ 0, max меньше 2.0, min меньше max",
      EXTRUDER: "Тестируемый экструдер (должен быть активным)",
      FORCE_SENSOR: "Используемый датчик усилия"
    },
    block: {
      klippy: "Klipper не готов.",
      running: "Измерение уже идёт.",
      printing: "Недоступно во время печати.",
      homing: "Сначала выполните парковку всех осей.",
      cold: "Экструдер слишком холодный для экструзии: сначала прогрейте его.",
      noSensor: "В конфигурации принтера нет датчика усилия.",
      ambiguous: "Несколько датчиков усилия: выберите FORCE_SENSOR.",
      invalid: "Неверные значения: {fields}"
    },
    run: {
      test: "Запустить тест",
      calibrate: "Калибровать",
      running: "Выполняется…",
      home: "Парковка",
      started: "Измерение: результат появится, когда Klipper закончит расчёт.",
      external: "запущено не здесь",
      log: "Лог консоли ({count} строк)",
      applyMeasured: "Применить",
      saveHint: "Действует только до перезапуска. Чтобы сохранить, впишите значение в pressure_advance секции [extruder] в printer.cfg."
    },
    confirm: {
      title: "Откалибровать и применить?",
      body: "По окончании PA_CALIBRATE изменит pressure advance экструдера. Изменение пропадёт при перезапуске, если не сохранить его в printer.cfg.",
      ok: "Калибровать",
      cancel: "Отмена"
    },
    result: {
      title: "Результат",
      current: "Текущий pressure advance экструдера",
      lastKlipper: "Последний результат в Klipper: {test}, PA {pa}",
      flow: "Расход, мм³/с",
      pa: "Pressure advance",
      overall: "Общий pressure advance",
      tested: "Проверенный pressure advance",
      overshoot: "перерегулирование",
      noOvershoot: "без перерегулирования",
      found: "Найденный pressure advance",
      corrected: "С поправкой на фильтр усилия",
      forceSign: "Определённый знак усилия: {sign}"
    },
    chart: {
      title: "Датчик усилия",
      show: "Показать",
      hide: "Скрыть",
      now: "сейчас",
      min: "мин",
      max: "макс",
      counts: "отсчётов",
      sec: "с",
      window: "Окно времени",
      pause: "Пауза",
      resume: "Продолжить",
      clear: "Очистить",
      connecting: "Подключение…",
      noData: "Ожидание данных…",
      sourceStream: "raw-поток",
      sourceStatus: "≈4 Гц",
      sourceStatusHint: "Raw-поток недоступен: график строится по подписке на статус (около 4 отсчётов в секунду).",
      filter: "Фильтр",
      filter_raw: "Сырой",
      filter_average: "Среднее",
      filter_moving: "Скользящее среднее",
      filter_median: "Скользящая медиана",
      filter_envelope: "Огибающая мин/макс",
      filterMs: "Окно",
      ms: "мс",
      showRaw: "Показать сырой",
      mains: "Фильтр сетевой помехи",
      mainsHz: "Частота сети",
      hz: "Гц",
      mainsLowRate: "Датчик слишком медленный для фильтра сети",
      tare: "Без калибровки график показывает отсчёты относительно тары. Перед измерением обнулите датчик (LOAD_CELL_TARE)."
    },
    guard: {
      printing: "Измерение pressure advance недоступно во время печати.",
      homing: "Перед измерением pressure advance выполните парковку всех осей.",
      cold: "Экструдер слишком холодный для измерения pressure advance."
    }
  }
};
class Xa extends Ti {
  render() {
    return B;
  }
}
const ec = !0, Ce = "u-", tc = "uplot", sc = Ce + "hz", nc = Ce + "vt", ic = Ce + "title", lc = Ce + "wrap", rc = Ce + "under", oc = Ce + "over", ac = Ce + "axis", ns = Ce + "off", cc = Ce + "select", uc = Ce + "cursor-x", hc = Ce + "cursor-y", fc = Ce + "cursor-pt", pc = Ce + "legend", dc = Ce + "live", mc = Ce + "inline", gc = Ce + "series", vc = Ce + "marker", er = Ce + "label", bc = Ce + "value", nn = "width", ln = "height", Qs = "top", tr = "bottom", Ms = "left", _i = "right", Yi = "#000", sr = Yi + "0", wi = "mousemove", nr = "mousedown", yi = "mouseup", ir = "mouseenter", lr = "mouseleave", rr = "dblclick", _c = "resize", wc = "scroll", or = "change", On = "dppxchange", Ji = "--", Is = typeof window < "u", Mi = Is ? document : null, Ns = Is ? window : null, yc = Is ? navigator : null;
let oe, kn;
function Ri() {
  let t = devicePixelRatio;
  oe != t && (oe = t, kn && Pi(or, kn, Ri), kn = matchMedia(`(min-resolution: ${oe - 1e-3}dppx) and (max-resolution: ${oe + 1e-3}dppx)`), ls(or, kn, Ri), Ns.dispatchEvent(new CustomEvent(On)));
}
function st(t, e) {
  if (e != null) {
    let n = t.classList;
    !n.contains(e) && n.add(e);
  }
}
function Ci(t, e) {
  let n = t.classList;
  n.contains(e) && n.remove(e);
}
function be(t, e, n) {
  t.style[e] = n + "px";
}
function bt(t, e, n, s) {
  let i = Mi.createElement(t);
  return e != null && st(i, e), n?.insertBefore(i, s), i;
}
function ht(t, e) {
  return bt("div", t, e);
}
const ar = /* @__PURE__ */ new WeakMap();
function Tt(t, e, n, s, i) {
  let r = "translate(" + e + "px," + n + "px)", a = ar.get(t);
  r != a && (t.style.transform = r, ar.set(t, r), e < 0 || n < 0 || e > s || n > i ? st(t, ns) : Ci(t, ns));
}
const cr = /* @__PURE__ */ new WeakMap();
function ur(t, e, n) {
  let s = e + n, i = cr.get(t);
  s != i && (cr.set(t, s), t.style.background = e, t.style.borderColor = n);
}
const hr = /* @__PURE__ */ new WeakMap();
function fr(t, e, n, s) {
  let i = e + "" + n, r = hr.get(t);
  i != r && (hr.set(t, i), t.style.height = n + "px", t.style.width = e + "px", t.style.marginLeft = s ? -e / 2 + "px" : 0, t.style.marginTop = s ? -n / 2 + "px" : 0);
}
const Zi = { passive: !0 }, Sc = { ...Zi, capture: !0 };
function ls(t, e, n, s) {
  e.addEventListener(t, n, s ? Sc : Zi);
}
function Pi(t, e, n, s) {
  e.removeEventListener(t, n, Zi);
}
Is && Ri();
function _t(t, e, n, s) {
  let i;
  n = n || 0, s = s || e.length - 1;
  let r = s <= 2147483647;
  for (; s - n > 1; )
    i = r ? n + s >> 1 : nt((n + s) / 2), e[i] < t ? n = i : s = i;
  return t - e[n] <= e[s] - t ? n : s;
}
function to(t) {
  return (n, s, i) => {
    let r = -1, a = -1;
    for (let h = s; h <= i; h++)
      if (t(n[h])) {
        r = h;
        break;
      }
    for (let h = i; h >= s; h--)
      if (t(n[h])) {
        a = h;
        break;
      }
    return [r, a];
  };
}
const so = (t) => t != null, no = (t) => t != null && t > 0, Un = to(so), xc = to(no);
function $c(t, e, n, s = 0, i = !1) {
  let r = i ? xc : Un, a = i ? no : so;
  [e, n] = r(t, e, n);
  let h = t[e], f = t[e];
  if (e > -1)
    if (s == 1)
      h = t[e], f = t[n];
    else if (s == -1)
      h = t[n], f = t[e];
    else
      for (let p = e; p <= n; p++) {
        let g = t[p];
        a(g) && (g < h ? h = g : g > f && (f = g));
      }
  return [h ?? fe, f ?? -fe];
}
function Wn(t, e, n, s) {
  let i = mr(t), r = mr(e);
  t == e && (i == -1 ? (t *= n, e /= n) : (t /= n, e *= n));
  let a = n == 10 ? Nt : io, h = i == 1 ? nt : ft, f = r == 1 ? ft : nt, p = h(a(Re(t))), g = f(a(Re(e))), d = Ds(n, p), b = Ds(n, g);
  return n == 10 && (p < 0 && (d = pe(d, -p)), g < 0 && (b = pe(b, -g))), s || n == 2 ? (t = d * i, e = b * r) : (t = ao(t, d), e = Vn(e, b)), [t, e];
}
function Qi(t, e, n, s) {
  let i = Wn(t, e, n, s);
  return t == 0 && (i[0] = 0), e == 0 && (i[1] = 0), i;
}
const Xi = 0.1, pr = {
  mode: 3,
  pad: Xi
}, an = {
  pad: 0,
  soft: null,
  mode: 0
}, Ec = {
  min: an,
  max: an
};
function Dn(t, e, n, s) {
  return Gn(n) ? dr(t, e, n) : (an.pad = n, an.soft = s ? 0 : null, an.mode = s ? 3 : 0, dr(t, e, Ec));
}
function le(t, e) {
  return t ?? e;
}
function Ac(t, e, n) {
  for (e = le(e, 0), n = le(n, t.length - 1); e <= n; ) {
    if (t[e] != null)
      return !0;
    e++;
  }
  return !1;
}
function dr(t, e, n) {
  let s = n.min, i = n.max, r = le(s.pad, 0), a = le(i.pad, 0), h = le(s.hard, -fe), f = le(i.hard, fe), p = le(s.soft, fe), g = le(i.soft, -fe), d = le(s.mode, 0), b = le(i.mode, 0), S = e - t, $ = Nt(S), z = je(Re(t), Re(e)), I = Nt(z), W = Re(I - $);
  (S < 1e-24 || W > 10) && (S = 0, (t == 0 || e == 0) && (S = 1e-24, d == 2 && p != fe && (r = 0), b == 2 && g != -fe && (a = 0)));
  let x = S || z || 1e3, H = Nt(x), E = Ds(10, nt(H)), J = x * (S == 0 ? t == 0 ? 0.1 : 1 : r), C = pe(ao(t - J, E / 10), 24), Z = t >= p && (d == 1 || d == 3 && C <= p || d == 2 && C >= p) ? p : fe, j = je(h, C < Z && t >= Z ? Z : wt(Z, C)), ee = x * (S == 0 ? e == 0 ? 0.1 : 1 : a), K = pe(Vn(e + ee, E / 10), 24), A = e <= g && (b == 1 || b == 3 && K >= g || b == 2 && K <= g) ? g : -fe, Y = wt(f, K > A && e <= A ? A : je(A, K));
  return j == Y && j == 0 && (Y = 100), [j, Y];
}
const kc = new Intl.NumberFormat(Is ? yc.language : "en-US"), el = (t) => kc.format(t), it = Math, Pn = it.PI, Re = it.abs, nt = it.floor, Me = it.round, ft = it.ceil, wt = it.min, je = it.max, Ds = it.pow, mr = it.sign, Nt = it.log10, io = it.log2, Tc = (t, e = 1) => it.sinh(t) * e, Si = (t, e = 1) => it.asinh(t / e), fe = 1 / 0;
function gr(t) {
  return (Nt((t ^ t >> 31) - (t >> 31)) | 0) + 1;
}
function Ni(t, e, n) {
  return wt(je(t, e), n);
}
function lo(t) {
  return typeof t == "function";
}
function te(t) {
  return lo(t) ? t : () => t;
}
const Mc = () => {
}, ro = (t) => t, oo = (t, e) => e, Rc = (t) => null, vr = (t) => !0, br = (t, e) => t == e, Cc = /\.\d*?(?=9{6,}|0{6,})/gm, os = (t) => {
  if (uo(t) || Vt.has(t))
    return t;
  const e = `${t}`, n = e.match(Cc);
  if (n == null)
    return t;
  let s = n[0].length - 1;
  if (e.indexOf("e-") != -1) {
    let [i, r] = e.split("e");
    return +`${os(i)}e${r}`;
  }
  return pe(t, s);
};
function ts(t, e) {
  return os(pe(os(t / e)) * e);
}
function Vn(t, e) {
  return os(ft(os(t / e)) * e);
}
function ao(t, e) {
  return os(nt(os(t / e)) * e);
}
function pe(t, e = 0) {
  if (uo(t))
    return t;
  let n = 10 ** e, s = t * n * (1 + Number.EPSILON);
  return Me(s) / n;
}
const Vt = /* @__PURE__ */ new Map();
function co(t) {
  return (("" + t).split(".")[1] || "").length;
}
function pn(t, e, n, s) {
  let i = [], r = s.map(co);
  for (let a = e; a < n; a++) {
    let h = Re(a), f = pe(Ds(t, a), h);
    for (let p = 0; p < s.length; p++) {
      let g = t == 10 ? +`${s[p]}e${a}` : s[p] * f, d = (a >= 0 ? 0 : h) + (a >= r[p] ? 0 : r[p]), b = t == 10 ? g : pe(g, d);
      i.push(b), Vt.set(b, d);
    }
  }
  return i;
}
const cn = {}, tl = [], zs = [null, null], Ut = Array.isArray, uo = Number.isInteger, Pc = (t) => t === void 0;
function _r(t) {
  return typeof t == "string";
}
function Gn(t) {
  let e = !1;
  if (t != null) {
    let n = t.constructor;
    e = n == null || n == Object;
  }
  return e;
}
function Nc(t) {
  return t != null && typeof t == "object";
}
const Lc = Object.getPrototypeOf(Uint8Array), ho = "__proto__";
function Hs(t, e = Gn) {
  let n;
  if (Ut(t)) {
    let s = t.find((i) => i != null);
    if (Ut(s) || e(s)) {
      n = Array(t.length);
      for (let i = 0; i < t.length; i++)
        n[i] = Hs(t[i], e);
    } else
      n = t.slice();
  } else if (t instanceof Lc)
    n = t.slice();
  else if (e(t)) {
    n = {};
    for (let s in t)
      s != ho && (n[s] = Hs(t[s], e));
  } else
    n = t;
  return n;
}
function Ae(t) {
  let e = arguments;
  for (let n = 1; n < e.length; n++) {
    let s = e[n];
    for (let i in s)
      i != ho && (Gn(t[i]) ? Ae(t[i], Hs(s[i])) : t[i] = Hs(s[i]));
  }
  return t;
}
const Oc = 0, Dc = 1, zc = 2;
function Hc(t, e, n) {
  for (let s = 0, i, r = -1; s < e.length; s++) {
    let a = e[s];
    if (a > r) {
      for (i = a - 1; i >= 0 && t[i] == null; )
        t[i--] = null;
      for (i = a + 1; i < n && t[i] == null; )
        t[r = i++] = null;
    }
  }
}
function Fc(t, e) {
  if (Wc(t)) {
    let a = t[0].slice();
    for (let h = 1; h < t.length; h++)
      a.push(...t[h].slice(1));
    return Vc(a[0]) || (a = Uc(a)), a;
  }
  let n = /* @__PURE__ */ new Set();
  for (let a = 0; a < t.length; a++) {
    let f = t[a][0], p = f.length;
    for (let g = 0; g < p; g++)
      n.add(f[g]);
  }
  let s = [Array.from(n).sort((a, h) => a - h)], i = s[0].length, r = /* @__PURE__ */ new Map();
  for (let a = 0; a < i; a++)
    r.set(s[0][a], a);
  for (let a = 0; a < t.length; a++) {
    let h = t[a], f = h[0];
    for (let p = 1; p < h.length; p++) {
      let g = h[p], d = Array(i).fill(void 0), b = e ? e[a][p] : Dc, S = [];
      for (let $ = 0; $ < g.length; $++) {
        let z = g[$], I = r.get(f[$]);
        z === null ? b != Oc && (d[I] = z, b == zc && S.push(I)) : d[I] = z;
      }
      Hc(d, S, i), s.push(d);
    }
  }
  return s;
}
const Ic = typeof queueMicrotask > "u" ? (t) => Promise.resolve().then(t) : queueMicrotask;
function Uc(t) {
  let e = t[0], n = e.length, s = Array(n);
  for (let r = 0; r < s.length; r++)
    s[r] = r;
  s.sort((r, a) => e[r] - e[a]);
  let i = [];
  for (let r = 0; r < t.length; r++) {
    let a = t[r], h = Array(n);
    for (let f = 0; f < n; f++)
      h[f] = a[s[f]];
    i.push(h);
  }
  return i;
}
function Wc(t) {
  let e = t[0][0], n = e.length;
  for (let s = 1; s < t.length; s++) {
    let i = t[s][0];
    if (i.length != n)
      return !1;
    if (i != e) {
      for (let r = 0; r < n; r++)
        if (i[r] != e[r])
          return !1;
    }
  }
  return !0;
}
function Vc(t, e = 100) {
  const n = t.length;
  if (n <= 1)
    return !0;
  let s = 0, i = n - 1;
  for (; s <= i && t[s] == null; )
    s++;
  for (; i >= s && t[i] == null; )
    i--;
  if (i <= s)
    return !0;
  const r = je(1, nt((i - s + 1) / e));
  for (let a = t[s], h = s + r; h <= i; h += r) {
    const f = t[h];
    if (f != null) {
      if (f <= a)
        return !1;
      a = f;
    }
  }
  return !0;
}
const fo = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
], po = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday"
];
function mo(t) {
  return t.slice(0, 3);
}
const Gc = po.map(mo), Bc = fo.map(mo), Kc = {
  MMMM: fo,
  MMM: Bc,
  WWWW: po,
  WWW: Gc
};
function Xs(t) {
  return (t < 10 ? "0" : "") + t;
}
function jc(t) {
  return (t < 10 ? "00" : t < 100 ? "0" : "") + t;
}
const qc = {
  // 2019
  YYYY: (t) => t.getFullYear(),
  // 19
  YY: (t) => (t.getFullYear() + "").slice(2),
  // July
  MMMM: (t, e) => e.MMMM[t.getMonth()],
  // Jul
  MMM: (t, e) => e.MMM[t.getMonth()],
  // 07
  MM: (t) => Xs(t.getMonth() + 1),
  // 7
  M: (t) => t.getMonth() + 1,
  // 09
  DD: (t) => Xs(t.getDate()),
  // 9
  D: (t) => t.getDate(),
  // Monday
  WWWW: (t, e) => e.WWWW[t.getDay()],
  // Mon
  WWW: (t, e) => e.WWW[t.getDay()],
  // 03
  HH: (t) => Xs(t.getHours()),
  // 3
  H: (t) => t.getHours(),
  // 9 (12hr, unpadded)
  h: (t) => {
    let e = t.getHours();
    return e == 0 ? 12 : e > 12 ? e - 12 : e;
  },
  // AM
  AA: (t) => t.getHours() >= 12 ? "PM" : "AM",
  // am
  aa: (t) => t.getHours() >= 12 ? "pm" : "am",
  // a
  a: (t) => t.getHours() >= 12 ? "p" : "a",
  // 09
  mm: (t) => Xs(t.getMinutes()),
  // 9
  m: (t) => t.getMinutes(),
  // 09
  ss: (t) => Xs(t.getSeconds()),
  // 9
  s: (t) => t.getSeconds(),
  // 374
  fff: (t) => jc(t.getMilliseconds())
};
function sl(t, e) {
  e = e || Kc;
  let n = [], s = /\{([a-z]+)\}|[^{]+/gi, i;
  for (; i = s.exec(t); )
    n.push(i[0][0] == "{" ? qc[i[1]] : i[0]);
  return (r) => {
    let a = "";
    for (let h = 0; h < n.length; h++)
      a += typeof n[h] == "string" ? n[h] : n[h](r, e);
    return a;
  };
}
const Yc = new Intl.DateTimeFormat().resolvedOptions().timeZone;
function Jc(t, e) {
  let n;
  return e == "UTC" || e == "Etc/UTC" ? n = new Date(+t + t.getTimezoneOffset() * 6e4) : e == Yc ? n = t : (n = new Date(t.toLocaleString("en-US", { timeZone: e })), n.setMilliseconds(t.getMilliseconds())), n;
}
const go = (t) => t % 1 == 0, zn = [1, 2, 2.5, 5], Zc = pn(10, -32, 0, zn), vo = pn(10, 0, 32, zn), Qc = vo.filter(go), ss = Zc.concat(vo), nl = `
`, bo = "{YYYY}", wr = nl + bo, _o = "{M}/{D}", rn = nl + _o, Tn = rn + "/{YY}", wo = "{aa}", Xc = "{h}:{mm}", Cs = Xc + wo, yr = nl + Cs, Sr = ":{ss}", ce = null;
function yo(t) {
  let e = t * 1e3, n = e * 60, s = n * 60, i = s * 24, r = i * 30, a = i * 365, f = (t == 1 ? pn(10, 0, 3, zn).filter(go) : pn(10, -3, 0, zn)).concat([
    // minute divisors (# of secs)
    e,
    e * 5,
    e * 10,
    e * 15,
    e * 30,
    // hour divisors (# of mins)
    n,
    n * 5,
    n * 10,
    n * 15,
    n * 30,
    // day divisors (# of hrs)
    s,
    s * 2,
    s * 3,
    s * 4,
    s * 6,
    s * 8,
    s * 12,
    // month divisors TODO: need more?
    i,
    i * 2,
    i * 3,
    i * 4,
    i * 5,
    i * 6,
    i * 7,
    i * 8,
    i * 9,
    i * 10,
    i * 15,
    // year divisors (# months, approx)
    r,
    r * 2,
    r * 3,
    r * 4,
    r * 6,
    // century divisors
    a,
    a * 2,
    a * 5,
    a * 10,
    a * 25,
    a * 50,
    a * 100
  ]);
  const p = [
    //   tick incr    default          year                    month   day                   hour    min       sec   mode
    [a, bo, ce, ce, ce, ce, ce, ce, 1],
    [i * 28, "{MMM}", wr, ce, ce, ce, ce, ce, 1],
    [i, _o, wr, ce, ce, ce, ce, ce, 1],
    [s, "{h}" + wo, Tn, ce, rn, ce, ce, ce, 1],
    [n, Cs, Tn, ce, rn, ce, ce, ce, 1],
    [e, Sr, Tn + " " + Cs, ce, rn + " " + Cs, ce, yr, ce, 1],
    [t, Sr + ".{fff}", Tn + " " + Cs, ce, rn + " " + Cs, ce, yr, ce, 1]
  ];
  function g(d) {
    return (b, S, $, z, I, W) => {
      let x = [], H = I >= a, E = I >= r && I < a, J = d($), C = pe(J * t, 3), Z = xi(J.getFullYear(), H ? 0 : J.getMonth(), E || H ? 1 : J.getDate()), j = pe(Z * t, 3);
      if (E || H) {
        let ee = E ? I / r : 0, K = H ? I / a : 0, A = C == j ? C : pe(xi(Z.getFullYear() + K, Z.getMonth() + ee, 1) * t, 3), Y = new Date(Me(A / t)), P = Y.getFullYear(), V = Y.getMonth();
        for (let D = 0; A <= z; D++) {
          let se = xi(P + K * D, V + ee * D, 1), O = se - d(pe(se * t, 3));
          A = pe((+se + O) * t, 3), A <= z && x.push(A);
        }
      } else {
        let ee = I >= i ? i : I, K = nt($) - nt(C), A = j + K + Vn(C - j, ee);
        x.push(A);
        let Y = d(A), P = Y.getHours() + Y.getMinutes() / n + Y.getSeconds() / s, V = I / s, D = b.axes[S]._space, se = W / D;
        for (; A = pe(A + I, t == 1 ? 0 : 3), !(A > z); )
          if (V > 1) {
            let O = nt(pe(P + V, 6)) % 24, ne = d(A).getHours() - O;
            ne > 1 && (ne = -1), A -= ne * s, P = (P + V) % 24;
            let ue = x[x.length - 1];
            pe((A - ue) / I, 3) * se >= 0.7 && x.push(A);
          } else
            x.push(A);
      }
      return x;
    };
  }
  return [
    f,
    p,
    g
  ];
}
const [eu, tu, su] = yo(1), [nu, iu, lu] = yo(1e-3);
pn(2, -53, 53, [1]);
function xr(t, e) {
  return t.map((n) => n.map(
    (s, i) => i == 0 || i == 8 || s == null ? s : e(i == 1 || n[8] == 0 ? s : n[1] + s)
  ));
}
function $r(t, e) {
  return (n, s, i, r, a) => {
    let h = e.find(($) => a >= $[0]) || e[e.length - 1], f, p, g, d, b, S;
    return s.map(($) => {
      let z = t($), I = z.getFullYear(), W = z.getMonth(), x = z.getDate(), H = z.getHours(), E = z.getMinutes(), J = z.getSeconds(), C = I != f && h[2] || W != p && h[3] || x != g && h[4] || H != d && h[5] || E != b && h[6] || J != S && h[7] || h[1];
      return f = I, p = W, g = x, d = H, b = E, S = J, C(z);
    });
  };
}
function ru(t, e) {
  let n = sl(e);
  return (s, i, r, a, h) => i.map((f) => n(t(f)));
}
function xi(t, e, n) {
  return new Date(t, e, n);
}
function Er(t, e) {
  return e(t);
}
const ou = "{YYYY}-{MM}-{DD} {h}:{mm}{aa}";
function Ar(t, e) {
  return (n, s, i, r) => r == null ? Ji : e(t(s));
}
function au(t, e) {
  let n = t.series[e];
  return n.width ? n.stroke(t, e) : n.points.width ? n.points.stroke(t, e) : null;
}
function cu(t, e) {
  return t.series[e].fill(t, e);
}
const uu = {
  show: !0,
  live: !0,
  isolate: !1,
  mount: Mc,
  markers: {
    show: !0,
    width: 2,
    stroke: au,
    fill: cu,
    dash: "solid"
  },
  idx: null,
  idxs: null,
  values: []
};
function hu(t, e) {
  let n = t.cursor.points, s = ht(), i = n.size(t, e);
  be(s, nn, i), be(s, ln, i);
  let r = i / -2;
  be(s, "marginLeft", r), be(s, "marginTop", r);
  let a = n.width(t, e, i);
  return a && be(s, "borderWidth", a), s;
}
function fu(t, e) {
  let n = t.series[e].points;
  return n._fill || n._stroke;
}
function pu(t, e) {
  let n = t.series[e].points;
  return n._stroke || n._fill;
}
function du(t, e) {
  return t.series[e].points.size;
}
const $i = [0, 0];
function mu(t, e, n) {
  return $i[0] = e, $i[1] = n, $i;
}
function Mn(t, e, n, s = !0) {
  return (i) => {
    i.button == 0 && (!s || i.target == e) && n(i);
  };
}
function Ei(t, e, n, s = !0) {
  return (i) => {
    (!s || i.target == e) && n(i);
  };
}
const gu = {
  show: !0,
  x: !0,
  y: !0,
  lock: !1,
  move: mu,
  points: {
    one: !1,
    show: hu,
    size: du,
    width: 0,
    stroke: pu,
    fill: fu
  },
  bind: {
    mousedown: Mn,
    mouseup: Mn,
    click: Mn,
    // legend clicks, not .u-over clicks
    dblclick: Mn,
    mousemove: Ei,
    mouseleave: Ei,
    mouseenter: Ei
  },
  drag: {
    setScale: !0,
    x: !0,
    y: !1,
    dist: 0,
    uni: null,
    click: (t, e) => {
      e.stopPropagation(), e.stopImmediatePropagation();
    },
    _x: !1,
    _y: !1
  },
  focus: {
    dist: (t, e, n, s, i) => s - i,
    prox: -1,
    bias: 0
  },
  hover: {
    skip: [void 0],
    prox: null,
    bias: 0
  },
  left: -10,
  top: -10,
  idx: null,
  dataIdx: null,
  idxs: null,
  event: null
}, So = {
  show: !0,
  stroke: "rgba(0,0,0,0.07)",
  width: 2
  //	dash: [],
}, il = Ae({}, So, {
  filter: oo
}), xo = Ae({}, il, {
  size: 10
}), $o = Ae({}, So, {
  show: !1
}), ll = '12px system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"', Eo = "bold " + ll, Ao = 1.5, kr = {
  show: !0,
  scale: "x",
  stroke: Yi,
  space: 50,
  gap: 5,
  alignTo: 1,
  size: 50,
  labelGap: 0,
  labelSize: 30,
  labelFont: Eo,
  side: 2,
  //	class: "x-vals",
  //	incrs: timeIncrs,
  //	values: timeVals,
  //	filter: retArg1,
  grid: il,
  ticks: xo,
  border: $o,
  font: ll,
  lineGap: Ao,
  rotate: 0
}, vu = "Value", bu = "Time", Tr = {
  show: !0,
  scale: "x",
  auto: !1,
  sorted: 1,
  //	label: "Time",
  //	value: v => stamp(new Date(v * 1e3)),
  // internal caches
  min: fe,
  max: -fe,
  idxs: []
};
function _u(t, e, n, s, i) {
  return e.map((r) => r == null ? "" : el(r));
}
function wu(t, e, n, s, i, r, a) {
  let h = [], f = Vt.get(i) || 0;
  n = a ? n : pe(Vn(n, i), f);
  for (let p = n; p <= s; p = pe(p + i, f))
    h.push(Object.is(p, -0) ? 0 : p);
  return h;
}
function Li(t, e, n, s, i, r, a) {
  const h = [], f = t.scales[t.axes[e].scale].log, p = f == 10 ? Nt : io, g = nt(p(n));
  i = Ds(f, g), f == 10 && (i = ss[_t(i, ss)]);
  let d = n, b = i * f;
  f == 10 && (b = ss[_t(b, ss)]);
  do
    h.push(d), d = d + i, f == 10 && !Vt.has(d) && (d = pe(d, Vt.get(i))), d >= b && (i = d, b = i * f, f == 10 && (b = ss[_t(b, ss)]));
  while (d <= s);
  return h;
}
function yu(t, e, n, s, i, r, a) {
  let f = t.scales[t.axes[e].scale].asinh, p = s > f ? Li(t, e, je(f, n), s, i) : [f], g = s >= 0 && n <= 0 ? [0] : [];
  return (n < -f ? Li(t, e, je(f, -s), -n, i) : [f]).reverse().map((b) => -b).concat(g, p);
}
const ko = /./, Su = /[12357]/, xu = /[125]/, Mr = /1/, Oi = (t, e, n, s) => t.map((i, r) => e == 4 && i == 0 || r % s == 0 && n.test(i.toExponential()[i < 0 ? 1 : 0]) ? i : null);
function $u(t, e, n, s, i) {
  let r = t.axes[n], a = r.scale, h = t.scales[a], f = t.valToPos, p = r._space, g = f(10, a), d = f(9, a) - g >= p ? ko : f(7, a) - g >= p ? Su : f(5, a) - g >= p ? xu : Mr;
  if (d == Mr) {
    let b = Re(f(1, a) - g);
    if (b < p)
      return Oi(e.slice().reverse(), h.distr, d, ft(p / b)).reverse();
  }
  return Oi(e, h.distr, d, 1);
}
function Eu(t, e, n, s, i) {
  let r = t.axes[n], a = r.scale, h = r._space, f = t.valToPos, p = Re(f(1, a) - f(2, a));
  return p < h ? Oi(e.slice().reverse(), 3, ko, ft(h / p)).reverse() : e;
}
function Au(t, e, n, s) {
  return s == null ? Ji : e == null ? "" : el(e);
}
const Rr = {
  show: !0,
  scale: "y",
  stroke: Yi,
  space: 30,
  gap: 5,
  alignTo: 1,
  size: 50,
  labelGap: 0,
  labelSize: 30,
  labelFont: Eo,
  side: 3,
  //	class: "y-vals",
  //	incrs: numIncrs,
  //	values: (vals, space) => vals,
  //	filter: retArg1,
  grid: il,
  ticks: xo,
  border: $o,
  font: ll,
  lineGap: Ao,
  rotate: 0
};
function ku(t, e) {
  let n = 3 + (t || 1) * 2;
  return pe(n * e, 3);
}
function Tu(t, e) {
  let { scale: n, idxs: s } = t.series[0], i = t._data[0], r = t.valToPos(i[s[0]], n, !0), a = t.valToPos(i[s[1]], n, !0), h = Re(a - r), f = t.series[e], p = h / (f.points.space * oe);
  return s[1] - s[0] <= p;
}
const Cr = {
  scale: null,
  auto: !0,
  sorted: 0,
  // internal caches
  min: fe,
  max: -fe
}, To = (t, e, n, s, i) => i, Pr = {
  show: !0,
  auto: !0,
  sorted: 0,
  gaps: To,
  alpha: 1,
  facets: [
    Ae({}, Cr, { scale: "x" }),
    Ae({}, Cr, { scale: "y" })
  ]
}, Nr = {
  scale: "y",
  auto: !0,
  sorted: 0,
  show: !0,
  spanGaps: !1,
  gaps: To,
  alpha: 1,
  points: {
    show: Tu,
    filter: null
    //  paths:
    //	stroke: "#000",
    //	fill: "#fff",
    //	width: 1,
    //	size: 10,
  },
  //	label: "Value",
  //	value: v => v,
  values: null,
  // internal caches
  min: fe,
  max: -fe,
  idxs: [],
  path: null,
  clip: null
};
function Mu(t, e, n, s, i) {
  return n / 10;
}
const Mo = {
  time: ec,
  auto: !0,
  distr: 1,
  log: 10,
  asinh: 1,
  min: null,
  max: null,
  dir: 1,
  ori: 0
}, Ru = Ae({}, Mo, {
  time: !1,
  ori: 1
}), Lr = {};
function Ro(t, e) {
  let n = Lr[t];
  return n || (n = {
    key: t,
    plots: [],
    sub(s) {
      n.plots.push(s);
    },
    unsub(s) {
      n.plots = n.plots.filter((i) => i != s);
    },
    pub(s, i, r, a, h, f, p) {
      for (let g = 0; g < n.plots.length; g++)
        n.plots[g] != i && n.plots[g].pub(s, i, r, a, h, f, p);
    }
  }, t != null && (Lr[t] = n)), n;
}
const Fs = 1, Di = 2;
function as(t, e, n) {
  const s = t.mode, i = t.series[e], r = s == 2 ? t._data[e] : t._data, a = t.scales, h = t.bbox;
  let f = r[0], p = s == 2 ? r[1] : r[e], g = s == 2 ? a[i.facets[0].scale] : a[t.series[0].scale], d = s == 2 ? a[i.facets[1].scale] : a[i.scale], b = h.left, S = h.top, $ = h.width, z = h.height, I = t.valToPosH, W = t.valToPosV;
  return g.ori == 0 ? n(
    i,
    f,
    p,
    g,
    d,
    I,
    W,
    b,
    S,
    $,
    z,
    Kn,
    Us,
    qn,
    Po,
    Lo
  ) : n(
    i,
    f,
    p,
    g,
    d,
    W,
    I,
    S,
    b,
    z,
    $,
    jn,
    Ws,
    al,
    No,
    Oo
  );
}
function rl(t, e) {
  let n = 0, s = 0, i = le(t.bands, tl);
  for (let r = 0; r < i.length; r++) {
    let a = i[r];
    a.series[0] == e ? n = a.dir : a.series[1] == e && (a.dir == 1 ? s |= 1 : s |= 2);
  }
  return [
    n,
    s == 1 ? -1 : (
      // neg only
      s == 2 ? 1 : (
        // pos only
        s == 3 ? 2 : (
          // both
          0
        )
      )
    )
  ];
}
function Cu(t, e, n, s, i) {
  let r = t.mode, a = t.series[e], h = r == 2 ? a.facets[1].scale : a.scale, f = t.scales[h];
  return i == -1 ? f.min : i == 1 ? f.max : f.distr == 3 ? f.dir == 1 ? f.min : f.max : 0;
}
function Lt(t, e, n, s, i, r) {
  return as(t, e, (a, h, f, p, g, d, b, S, $, z, I) => {
    let W = a.pxRound;
    const x = p.dir * (p.ori == 0 ? 1 : -1), H = p.ori == 0 ? Us : Ws;
    let E, J;
    x == 1 ? (E = n, J = s) : (E = s, J = n);
    let C = W(d(h[E], p, z, S)), Z = W(b(f[E], g, I, $)), j = W(d(h[J], p, z, S)), ee = W(b(r == 1 ? g.max : g.min, g, I, $)), K = new Path2D(i);
    return H(K, j, ee), H(K, C, ee), H(K, C, Z), K;
  });
}
function Bn(t, e, n, s, i, r) {
  let a = null;
  if (t.length > 0) {
    a = new Path2D();
    const h = e == 0 ? qn : al;
    let f = n;
    for (let d = 0; d < t.length; d++) {
      let b = t[d];
      if (b[1] > b[0]) {
        let S = b[0] - f;
        S > 0 && h(a, f, s, S, s + r), f = b[1];
      }
    }
    let p = n + i - f, g = 10;
    p > 0 && h(a, f, s - g / 2, p, s + r + g);
  }
  return a;
}
function Pu(t, e, n) {
  let s = t[t.length - 1];
  s && s[0] == e ? s[1] = n : t.push([e, n]);
}
function ol(t, e, n, s, i, r, a) {
  let h = [], f = t.length;
  for (let p = i == 1 ? n : s; p >= n && p <= s; p += i)
    if (e[p] === null) {
      let d = p, b = p;
      if (i == 1)
        for (; ++p <= s && e[p] === null; )
          b = p;
      else
        for (; --p >= n && e[p] === null; )
          b = p;
      let S = r(t[d]), $ = b == d ? S : r(t[b]), z = d - i;
      S = a <= 0 && z >= 0 && z < f ? r(t[z]) : S;
      let W = b + i;
      $ = a >= 0 && W >= 0 && W < f ? r(t[W]) : $, $ >= S && h.push([S, $]);
    }
  return h;
}
function Or(t) {
  return t == 0 ? ro : t == 1 ? Me : (e) => ts(e, t);
}
function Co(t) {
  let e = t == 0 ? Kn : jn, n = t == 0 ? (i, r, a, h, f, p) => {
    i.arcTo(r, a, h, f, p);
  } : (i, r, a, h, f, p) => {
    i.arcTo(a, r, f, h, p);
  }, s = t == 0 ? (i, r, a, h, f) => {
    i.rect(r, a, h, f);
  } : (i, r, a, h, f) => {
    i.rect(a, r, f, h);
  };
  return (i, r, a, h, f, p = 0, g = 0) => {
    p == 0 && g == 0 ? s(i, r, a, h, f) : (p = wt(p, h / 2, f / 2), g = wt(g, h / 2, f / 2), e(i, r + p, a), n(i, r + h, a, r + h, a + f, p), n(i, r + h, a + f, r, a + f, g), n(i, r, a + f, r, a, g), n(i, r, a, r + h, a, p), i.closePath());
  };
}
const Kn = (t, e, n) => {
  t.moveTo(e, n);
}, jn = (t, e, n) => {
  t.moveTo(n, e);
}, Us = (t, e, n) => {
  t.lineTo(e, n);
}, Ws = (t, e, n) => {
  t.lineTo(n, e);
}, qn = Co(0), al = Co(1), Po = (t, e, n, s, i, r) => {
  t.arc(e, n, s, i, r);
}, No = (t, e, n, s, i, r) => {
  t.arc(n, e, s, i, r);
}, Lo = (t, e, n, s, i, r, a) => {
  t.bezierCurveTo(e, n, s, i, r, a);
}, Oo = (t, e, n, s, i, r, a) => {
  t.bezierCurveTo(n, e, i, s, a, r);
};
function Do(t) {
  return (e, n, s, i, r) => as(e, n, (a, h, f, p, g, d, b, S, $, z, I) => {
    let { pxRound: W, points: x } = a, H, E;
    p.ori == 0 ? (H = Kn, E = Po) : (H = jn, E = No);
    const J = pe(x.width * oe, 3);
    let C = (x.size - x.width) / 2 * oe, Z = pe(C * 2, 3), j = new Path2D(), ee = new Path2D(), { left: K, top: A, width: Y, height: P } = e.bbox;
    qn(
      ee,
      K - Z,
      A - Z,
      Y + Z * 2,
      P + Z * 2
    );
    const V = (D) => {
      if (f[D] != null) {
        let se = W(d(h[D], p, z, S)), O = W(b(f[D], g, I, $));
        H(j, se + C, O), E(j, se, O, C, 0, Pn * 2);
      }
    };
    if (r)
      r.forEach(V);
    else
      for (let D = s; D <= i; D++)
        V(D);
    return {
      stroke: J > 0 ? j : null,
      fill: j,
      clip: ee,
      flags: Fs | Di
    };
  });
}
function zo(t) {
  return (e, n, s, i, r, a) => {
    s != i && (r != s && a != s && t(e, n, s), r != i && a != i && t(e, n, i), t(e, n, a));
  };
}
const Nu = zo(Us), Lu = zo(Ws);
function Ho(t) {
  const e = le(t?.alignGaps, 0);
  return (n, s, i, r) => as(n, s, (a, h, f, p, g, d, b, S, $, z, I) => {
    [i, r] = Un(f, i, r);
    let W = a.pxRound, x = (P) => W(d(P, p, z, S)), H = (P) => W(b(P, g, I, $)), E, J;
    p.ori == 0 ? (E = Us, J = Nu) : (E = Ws, J = Lu);
    const C = p.dir * (p.ori == 0 ? 1 : -1), Z = { stroke: new Path2D(), fill: null, clip: null, band: null, gaps: null, flags: Fs }, j = Z.stroke;
    let ee = !1;
    if (r - i >= z * 4) {
      let P = (N) => n.posToVal(N, p.key, !0), V = null, D = null, se, O, qe, _e = x(h[C == 1 ? i : r]), ne = x(h[i]), ue = x(h[r]), Q = P(C == 1 ? ne + 1 : ue - 1);
      for (let N = C == 1 ? i : r; N >= i && N <= r; N += C) {
        let ke = h[N], we = (C == 1 ? ke < Q : ke > Q) ? _e : x(ke), ae = f[N];
        we == _e ? ae != null ? (O = ae, V == null ? (E(j, we, H(O)), se = V = D = O) : O < V ? V = O : O > D && (D = O)) : ae === null && (ee = !0) : (V != null && J(j, _e, H(V), H(D), H(se), H(O)), ae != null ? (O = ae, E(j, we, H(O)), V = D = se = O) : (V = D = null, ae === null && (ee = !0)), _e = we, Q = P(_e + C));
      }
      V != null && V != D && qe != _e && J(j, _e, H(V), H(D), H(se), H(O));
    } else
      for (let P = C == 1 ? i : r; P >= i && P <= r; P += C) {
        let V = f[P];
        V === null ? ee = !0 : V != null && E(j, x(h[P]), H(V));
      }
    let [A, Y] = rl(n, s);
    if (a.fill != null || A != 0) {
      let P = Z.fill = new Path2D(j), V = a.fillTo(n, s, a.min, a.max, A), D = H(V), se = x(h[i]), O = x(h[r]);
      C == -1 && ([O, se] = [se, O]), E(P, O, D), E(P, se, D);
    }
    if (!a.spanGaps) {
      let P = [];
      ee && P.push(...ol(h, f, i, r, C, x, e)), Z.gaps = P = a.gaps(n, s, i, r, P), Z.clip = Bn(P, p.ori, S, $, z, I);
    }
    return Y != 0 && (Z.band = Y == 2 ? [
      Lt(n, s, i, r, j, -1),
      Lt(n, s, i, r, j, 1)
    ] : Lt(n, s, i, r, j, Y)), Z;
  });
}
function Ou(t) {
  const e = le(t.align, 1), n = le(t.ascDesc, !1), s = le(t.alignGaps, 0), i = le(t.extend, !1);
  return (r, a, h, f) => as(r, a, (p, g, d, b, S, $, z, I, W, x, H) => {
    [h, f] = Un(d, h, f);
    let E = p.pxRound, { left: J, width: C } = r.bbox, Z = (ne) => E($(ne, b, x, I)), j = (ne) => E(z(ne, S, H, W)), ee = b.ori == 0 ? Us : Ws;
    const K = { stroke: new Path2D(), fill: null, clip: null, band: null, gaps: null, flags: Fs }, A = K.stroke, Y = b.dir * (b.ori == 0 ? 1 : -1);
    let P = j(d[Y == 1 ? h : f]), V = Z(g[Y == 1 ? h : f]), D = V, se = V;
    i && e == -1 && (se = J, ee(A, se, P)), ee(A, V, P);
    for (let ne = Y == 1 ? h : f; ne >= h && ne <= f; ne += Y) {
      let ue = d[ne];
      if (ue == null)
        continue;
      let Q = Z(g[ne]), N = j(ue);
      e == 1 ? ee(A, Q, P) : ee(A, D, N), ee(A, Q, N), P = N, D = Q;
    }
    let O = D;
    i && e == 1 && (O = J + C, ee(A, O, P));
    let [qe, _e] = rl(r, a);
    if (p.fill != null || qe != 0) {
      let ne = K.fill = new Path2D(A), ue = p.fillTo(r, a, p.min, p.max, qe), Q = j(ue);
      ee(ne, O, Q), ee(ne, se, Q);
    }
    if (!p.spanGaps) {
      let ne = [];
      ne.push(...ol(g, d, h, f, Y, Z, s));
      let ue = p.width * oe / 2, Q = n || e == 1 ? ue : -ue, N = n || e == -1 ? -ue : ue;
      ne.forEach((ke) => {
        ke[0] += Q, ke[1] += N;
      }), K.gaps = ne = p.gaps(r, a, h, f, ne), K.clip = Bn(ne, b.ori, I, W, x, H);
    }
    return _e != 0 && (K.band = _e == 2 ? [
      Lt(r, a, h, f, A, -1),
      Lt(r, a, h, f, A, 1)
    ] : Lt(r, a, h, f, A, _e)), K;
  });
}
function Dr(t, e, n, s, i, r, a = fe) {
  if (t.length > 1) {
    let h = null;
    for (let f = 0, p = 1 / 0; f < t.length; f++)
      if (e[f] !== void 0) {
        if (h != null) {
          let g = Re(t[f] - t[h]);
          g < p && (p = g, a = Re(n(t[f], s, i, r) - n(t[h], s, i, r)));
        }
        h = f;
      }
  }
  return a;
}
function Du(t) {
  t = t || cn;
  const e = le(t.size, [0.6, fe, 1]), n = t.align || 0, s = t.gap || 0;
  let i = t.radius;
  i = // [valueRadius, baselineRadius]
  i == null ? [0, 0] : typeof i == "number" ? [i, 0] : i;
  const r = te(i), a = 1 - e[0], h = le(e[1], fe), f = le(e[2], 1), p = le(t.disp, cn), g = le(t.each, (S) => {
  }), { fill: d, stroke: b } = p;
  return (S, $, z, I) => as(S, $, (W, x, H, E, J, C, Z, j, ee, K, A) => {
    let Y = W.pxRound, P = n, V = s * oe, D = h * oe, se = f * oe, O, qe;
    E.ori == 0 ? [O, qe] = r(S, $) : [qe, O] = r(S, $);
    const _e = E.dir * (E.ori == 0 ? 1 : -1);
    let ne = E.ori == 0 ? qn : al, ue = E.ori == 0 ? g : (M, de, Te, ps, Kt, St, jt) => {
      g(M, de, Te, Kt, ps, jt, St);
    }, Q = le(S.bands, tl).find((M) => M.series[0] == $), N = Q != null ? Q.dir : 0, ke = W.fillTo(S, $, W.min, W.max, N), We = Y(Z(ke, J, A, ee)), we, ae, pt, Ze = K, Se = Y(W.width * oe), yt = !1, Rt = null, lt = null, Ot = null, us = null;
    d != null && (Se == 0 || b != null) && (yt = !0, Rt = d.values(S, $, z, I), lt = /* @__PURE__ */ new Map(), new Set(Rt).forEach((M) => {
      M != null && lt.set(M, new Path2D());
    }), Se > 0 && (Ot = b.values(S, $, z, I), us = /* @__PURE__ */ new Map(), new Set(Ot).forEach((M) => {
      M != null && us.set(M, new Path2D());
    })));
    let { x0: hs, size: Vs } = p;
    if (hs != null && Vs != null) {
      P = 1, x = hs.values(S, $, z, I), hs.unit == 2 && (x = x.map((Te) => S.posToVal(j + Te * K, E.key, !0)));
      let M = Vs.values(S, $, z, I);
      Vs.unit == 2 ? ae = M[0] * K : ae = C(M[0], E, K, j) - C(0, E, K, j), Ze = Dr(x, H, C, E, K, j, Ze), pt = Ze - ae + V;
    } else
      Ze = Dr(x, H, C, E, K, j, Ze), pt = Ze * a + V, ae = Ze - pt;
    pt < 1 && (pt = 0), Se >= ae / 2 && (Se = 0), pt < 5 && (Y = ro);
    let vn = pt > 0, Gt = Ze - pt - (vn ? Se : 0);
    ae = Y(Ni(Gt, se, D)), we = (P == 0 ? ae / 2 : P == _e ? 0 : ae) - P * _e * ((P == 0 ? V / 2 : 0) + (vn ? Se / 2 : 0));
    const Ve = { stroke: null, fill: null, clip: null, band: null, gaps: null, flags: 0 }, fs = yt ? null : new Path2D();
    let Ct = null;
    if (Q != null)
      Ct = S.data[Q.series[1]];
    else {
      let { y0: M, y1: de } = p;
      M != null && de != null && (H = de.values(S, $, z, I), Ct = M.values(S, $, z, I));
    }
    let Bt = O * ae, q = qe * ae;
    for (let M = _e == 1 ? z : I; M >= z && M <= I; M += _e) {
      let de = H[M];
      if (de == null)
        continue;
      if (Ct != null) {
        let Ye = Ct[M] ?? 0;
        if (de - Ye == 0)
          continue;
        We = Z(Ye, J, A, ee);
      }
      let Te = E.distr != 2 || p != null ? x[M] : M, ps = C(Te, E, K, j), Kt = Z(le(de, ke), J, A, ee), St = Y(ps - we), jt = Y(je(Kt, We)), Qe = Y(wt(Kt, We)), rt = jt - Qe;
      if (de != null) {
        let Ye = de < 0 ? q : Bt, dt = de < 0 ? Bt : q;
        yt ? (Se > 0 && Ot[M] != null && ne(us.get(Ot[M]), St, Qe + nt(Se / 2), ae, je(0, rt - Se), Ye, dt), Rt[M] != null && ne(lt.get(Rt[M]), St, Qe + nt(Se / 2), ae, je(0, rt - Se), Ye, dt)) : ne(fs, St, Qe + nt(Se / 2), ae, je(0, rt - Se), Ye, dt), ue(
          S,
          $,
          M,
          St - Se / 2,
          Qe,
          ae + Se,
          rt
        );
      }
    }
    return Se > 0 ? Ve.stroke = yt ? us : fs : yt || (Ve._fill = W.width == 0 ? W._fill : W._stroke ?? W._fill, Ve.width = 0), Ve.fill = yt ? lt : fs, Ve;
  });
}
function zu(t, e) {
  const n = le(e?.alignGaps, 0);
  return (s, i, r, a) => as(s, i, (h, f, p, g, d, b, S, $, z, I, W) => {
    [r, a] = Un(p, r, a);
    let x = h.pxRound, H = (O) => x(b(O, g, I, $)), E = (O) => x(S(O, d, W, z)), J, C, Z;
    g.ori == 0 ? (J = Kn, Z = Us, C = Lo) : (J = jn, Z = Ws, C = Oo);
    const j = g.dir * (g.ori == 0 ? 1 : -1);
    let ee = H(f[j == 1 ? r : a]), K = ee, A = [], Y = [];
    for (let O = j == 1 ? r : a; O >= r && O <= a; O += j)
      if (p[O] != null) {
        let _e = f[O], ne = H(_e);
        A.push(K = ne), Y.push(E(p[O]));
      }
    const P = { stroke: t(A, Y, J, Z, C, x), fill: null, clip: null, band: null, gaps: null, flags: Fs }, V = P.stroke;
    let [D, se] = rl(s, i);
    if (h.fill != null || D != 0) {
      let O = P.fill = new Path2D(V), qe = h.fillTo(s, i, h.min, h.max, D), _e = E(qe);
      Z(O, K, _e), Z(O, ee, _e);
    }
    if (!h.spanGaps) {
      let O = [];
      O.push(...ol(f, p, r, a, j, H, n)), P.gaps = O = h.gaps(s, i, r, a, O), P.clip = Bn(O, g.ori, $, z, I, W);
    }
    return se != 0 && (P.band = se == 2 ? [
      Lt(s, i, r, a, V, -1),
      Lt(s, i, r, a, V, 1)
    ] : Lt(s, i, r, a, V, se)), P;
  });
}
function Hu(t) {
  return zu(Fu, t);
}
function Fu(t, e, n, s, i, r) {
  const a = t.length;
  if (a < 2)
    return null;
  const h = new Path2D();
  if (n(h, t[0], e[0]), a == 2)
    s(h, t[1], e[1]);
  else {
    let f = Array(a), p = Array(a - 1), g = Array(a - 1), d = Array(a - 1);
    for (let b = 0; b < a - 1; b++)
      g[b] = e[b + 1] - e[b], d[b] = t[b + 1] - t[b], p[b] = g[b] / d[b];
    f[0] = p[0];
    for (let b = 1; b < a - 1; b++)
      p[b] === 0 || p[b - 1] === 0 || p[b - 1] > 0 != p[b] > 0 ? f[b] = 0 : (f[b] = 3 * (d[b - 1] + d[b]) / ((2 * d[b] + d[b - 1]) / p[b - 1] + (d[b] + 2 * d[b - 1]) / p[b]), isFinite(f[b]) || (f[b] = 0));
    f[a - 1] = p[a - 2];
    for (let b = 0; b < a - 1; b++)
      i(
        h,
        t[b] + d[b] / 3,
        e[b] + f[b] * d[b] / 3,
        t[b + 1] - d[b] / 3,
        e[b + 1] - f[b + 1] * d[b] / 3,
        t[b + 1],
        e[b + 1]
      );
  }
  return h;
}
const zi = /* @__PURE__ */ new Set();
function zr() {
  for (let t of zi)
    t.syncRect(!0);
}
Is && (ls(_c, Ns, zr), ls(wc, Ns, zr, !0), ls(On, Ns, () => {
  Ue.pxRatio = oe;
}));
const Iu = Ho(), Uu = Do();
function Hr(t, e, n, s) {
  return (s ? [t[0], t[1]].concat(t.slice(2)) : [t[0]].concat(t.slice(1))).map((r, a) => Hi(r, a, e, n));
}
function Wu(t, e) {
  return t.map((n, s) => s == 0 ? {} : Ae({}, e, n));
}
function Hi(t, e, n, s) {
  return Ae({}, e == 0 ? n : s, t);
}
function Fo(t, e, n) {
  return e == null ? zs : [e, n];
}
const Vu = Fo;
function Gu(t, e, n) {
  return e == null ? zs : Dn(e, n, Xi, !0);
}
function Io(t, e, n, s) {
  return e == null ? zs : Wn(e, n, t.scales[s].log, !1);
}
const Bu = Io;
function Uo(t, e, n, s) {
  return e == null ? zs : Qi(e, n, t.scales[s].log, !1);
}
const Ku = Uo;
function ju(t, e, n, s, i) {
  let r = je(gr(t), gr(e)), a = e - t, h = _t(i / s * a, n);
  do {
    let f = n[h], p = s * f / a;
    if (p >= i && r + (f < 5 ? Vt.get(f) : 0) <= 17)
      return [f, p];
  } while (++h < n.length);
  return [0, 0];
}
function Fr(t) {
  let e, n;
  return t = t.replace(/(\d+)px/, (s, i) => (e = Me((n = +i) * oe)) + "px"), [t, e, n];
}
function qu(t) {
  t.show && [t.font, t.labelFont].forEach((e) => {
    let n = pe(e[2] * oe, 1);
    e[0] = e[0].replace(/[0-9.]+px/, n + "px"), e[1] = n;
  });
}
function Ue(t, e, n) {
  const s = {
    mode: le(t.mode, 1)
  }, i = s.mode;
  function r(l, o, c, u) {
    let m = o.valToPct(l);
    return u + c * (o.dir == -1 ? 1 - m : m);
  }
  function a(l, o, c, u) {
    let m = o.valToPct(l);
    return u + c * (o.dir == -1 ? m : 1 - m);
  }
  function h(l, o, c, u) {
    return o.ori == 0 ? r(l, o, c, u) : a(l, o, c, u);
  }
  s.valToPosH = r, s.valToPosV = a;
  let f = !1;
  s.status = 0;
  const p = s.root = ht(tc);
  if (t.id != null && (p.id = t.id), st(p, t.class), t.title) {
    let l = ht(ic, p);
    l.textContent = t.title;
  }
  const g = bt("canvas"), d = s.ctx = g.getContext("2d"), b = ht(lc, p);
  ls("click", b, (l) => {
    l.target === $ && (me != $s || ye != Es) && Fe.click(s, l);
  }, !0);
  const S = s.under = ht(rc, b);
  b.appendChild(g);
  const $ = s.over = ht(oc, b);
  t = Hs(t);
  const z = +le(t.pxAlign, 1), I = Or(z);
  (t.plugins || []).forEach((l) => {
    l.opts && (t = l.opts(s, t) || t);
  });
  const W = t.ms || 1e-3, x = s.series = i == 1 ? Hr(t.series || [], Tr, Nr, !1) : Wu(t.series || [null], Pr), H = s.axes = Hr(t.axes || [], kr, Rr, !0), E = s.scales = {}, J = s.bands = t.bands || [];
  J.forEach((l) => {
    l.fill = te(l.fill || null), l.dir = le(l.dir, -1);
  });
  const C = i == 2 ? x[1].facets[0].scale : x[0].scale, Z = {
    axes: pa,
    series: aa
  }, j = (t.drawOrder || ["axes", "series"]).map((l) => Z[l]);
  function ee(l) {
    const o = l.distr == 3 ? (c) => Nt(c > 0 ? c : l.clamp(s, c, l.min, l.max, l.key)) : l.distr == 4 ? (c) => Si(c, l.asinh) : l.distr == 100 ? (c) => l.fwd(c) : (c) => c;
    return (c) => {
      let u = o(c), { _min: m, _max: v } = l, _ = v - m;
      return (u - m) / _;
    };
  }
  function K(l) {
    let o = E[l];
    if (o == null) {
      let c = (t.scales || cn)[l] || cn;
      if (c.from != null) {
        K(c.from);
        let u = Ae({}, E[c.from], c, { key: l });
        u.valToPct = ee(u), E[l] = u;
      } else {
        o = E[l] = Ae({}, l == C ? Mo : Ru, c), o.key = l;
        let u = o.time, m = o.range, v = Ut(m);
        if ((l != C || i == 2 && !u) && (v && (m[0] == null || m[1] == null) && (m = {
          min: m[0] == null ? pr : {
            mode: 1,
            hard: m[0],
            soft: m[0]
          },
          max: m[1] == null ? pr : {
            mode: 1,
            hard: m[1],
            soft: m[1]
          }
        }, v = !1), !v && Gn(m))) {
          let _ = m;
          m = (w, y, k) => y == null ? zs : Dn(y, k, _);
        }
        o.range = te(m || (u ? Vu : l == C ? o.distr == 3 ? Bu : o.distr == 4 ? Ku : Fo : o.distr == 3 ? Io : o.distr == 4 ? Uo : Gu)), o.auto = te(v ? !1 : o.auto), o.clamp = te(o.clamp || Mu), o._min = o._max = null, o.valToPct = ee(o);
      }
    }
  }
  K("x"), K("y"), i == 1 && x.forEach((l) => {
    K(l.scale);
  }), H.forEach((l) => {
    K(l.scale);
  });
  for (let l in t.scales)
    K(l);
  const A = E[C], Y = A.distr;
  let P, V;
  A.ori == 0 ? (st(p, sc), P = r, V = a) : (st(p, nc), P = a, V = r);
  const D = {};
  for (let l in E) {
    let o = E[l];
    (o.min != null || o.max != null) && (D[l] = { min: o.min, max: o.max }, o.min = o.max = null);
  }
  const se = t.tzDate || ((l) => new Date(Me(l / W))), O = t.fmtDate || sl, qe = W == 1 ? su(se) : lu(se), _e = $r(se, xr(W == 1 ? tu : iu, O)), ne = Ar(se, Er(ou, O)), ue = [], Q = s.legend = Ae({}, uu, t.legend), N = s.cursor = Ae({}, gu, { drag: { y: i == 2 } }, t.cursor), ke = Q.show, We = N.show, we = Q.markers;
  Q.idxs = ue, we.width = te(we.width), we.dash = te(we.dash), we.stroke = te(we.stroke), we.fill = te(we.fill);
  let ae, pt, Ze, Se = [], yt = [], Rt, lt = !1, Ot = {};
  if (Q.live) {
    const l = x[1] ? x[1].values : null;
    lt = l != null, Rt = lt ? l(s, 1, 0) : { _: 0 };
    for (let o in Rt)
      Ot[o] = Ji;
  }
  if (ke)
    if (ae = bt("table", pc, p), Ze = bt("tbody", null, ae), Q.mount(s, ae), lt) {
      pt = bt("thead", null, ae, Ze);
      let l = bt("tr", null, pt);
      bt("th", null, l);
      for (var us in Rt)
        bt("th", er, l).textContent = us;
    } else
      st(ae, mc), Q.live && st(ae, dc);
  const hs = { show: !0 }, Vs = { show: !1 };
  function vn(l, o) {
    if (o == 0 && (lt || !Q.live || i == 2))
      return zs;
    let c = [], u = bt("tr", gc, Ze, Ze.childNodes[o]);
    st(u, l.class), l.show || st(u, ns);
    let m = bt("th", null, u);
    if (we.show) {
      let w = ht(vc, m);
      if (o > 0) {
        let y = we.width(s, o);
        y && (w.style.border = y + "px " + we.dash(s, o) + " " + we.stroke(s, o)), w.style.background = we.fill(s, o);
      }
    }
    let v = ht(er, m);
    l.label instanceof HTMLElement ? v.appendChild(l.label) : v.textContent = l.label, o > 0 && (we.show || (v.style.color = l.width > 0 ? we.stroke(s, o) : we.fill(s, o)), Ve("click", m, (w) => {
      if (N._lock)
        return;
      Yt(w);
      let y = x.indexOf(l);
      if ((w.ctrlKey || w.metaKey) != Q.isolate) {
        let k = x.some((T, R) => R > 0 && R != y && T.show);
        x.forEach((T, R) => {
          R > 0 && $t(R, k ? R == y ? hs : Vs : hs, !0, Ee.setSeries);
        });
      } else
        $t(y, { show: !l.show }, !0, Ee.setSeries);
    }, !1), ms && Ve(ir, m, (w) => {
      N._lock || (Yt(w), $t(x.indexOf(l), ks, !0, Ee.setSeries));
    }, !1));
    for (var _ in Rt) {
      let w = bt("td", bc, u);
      w.textContent = "--", c.push(w);
    }
    return [u, c];
  }
  const Gt = /* @__PURE__ */ new Map();
  function Ve(l, o, c, u = !0) {
    const m = Gt.get(o) || {}, v = N.bind[l](s, o, c, u);
    v && (ls(l, o, m[l] = v), Gt.set(o, m));
  }
  function fs(l, o, c) {
    const u = Gt.get(o) || {};
    for (let m in u)
      (l == null || m == l) && (Pi(m, o, u[m]), delete u[m]);
    l == null && Gt.delete(o);
  }
  let Ct = 0, Bt = 0, q = 0, M = 0, de = 0, Te = 0, ps = de, Kt = Te, St = q, jt = M, Qe = 0, rt = 0, Ye = 0, dt = 0;
  s.bbox = {};
  let Yn = !1, bn = !1, ds = !1, qt = !1, _n = !1, ot = !1;
  function Jn(l, o, c) {
    (c || l != s.width || o != s.height) && pl(l, o), ws(!1), ds = !0, bn = !0, ys();
  }
  function pl(l, o) {
    s.width = Ct = q = l, s.height = Bt = M = o, de = Te = 0, ta(), sa();
    let c = s.bbox;
    Qe = c.left = ts(de * oe, 0.5), rt = c.top = ts(Te * oe, 0.5), Ye = c.width = ts(q * oe, 0.5), dt = c.height = ts(M * oe, 0.5);
  }
  const Qo = 3;
  function Xo() {
    let l = !1, o = 0;
    for (; !l; ) {
      o++;
      let c = ha(o), u = fa(o);
      l = o == Qo || c && u, l || (pl(s.width, s.height), bn = !0);
    }
  }
  function ea({ width: l, height: o }) {
    Jn(l, o);
  }
  s.setSize = ea;
  function ta() {
    let l = !1, o = !1, c = !1, u = !1;
    H.forEach((m, v) => {
      if (m.show && m._show) {
        let { side: _, _size: w } = m, y = _ % 2, k = m.label != null ? m.labelSize : 0, T = w + k;
        T > 0 && (y ? (q -= T, _ == 3 ? (de += T, u = !0) : c = !0) : (M -= T, _ == 0 ? (Te += T, l = !0) : o = !0));
      }
    }), Jt[0] = l, Jt[1] = c, Jt[2] = o, Jt[3] = u, q -= Dt[1] + Dt[3], de += Dt[3], M -= Dt[2] + Dt[0], Te += Dt[0];
  }
  function sa() {
    let l = de + q, o = Te + M, c = de, u = Te;
    function m(v, _) {
      switch (v) {
        case 1:
          return l += _, l - _;
        case 2:
          return o += _, o - _;
        case 3:
          return c -= _, c + _;
        case 0:
          return u -= _, u + _;
      }
    }
    H.forEach((v, _) => {
      if (v.show && v._show) {
        let w = v.side;
        v._pos = m(w, v._size), v.label != null && (v._lpos = m(w, v.labelSize));
      }
    });
  }
  if (N.dataIdx == null) {
    let l = N.hover, o = l.skip = new Set(l.skip ?? []);
    o.add(void 0);
    let c = l.prox = te(l.prox), u = l.bias ??= 0;
    N.dataIdx = (m, v, _, w) => {
      if (v == 0)
        return _;
      let y = _, k = c(m, v, _, w) ?? fe, T = k >= 0 && k < fe, R = A.ori == 0 ? q : M, G = N.left, re = e[0], ie = e[v];
      if (o.has(ie[_])) {
        y = null;
        let X = null, U = null, L;
        if (u == 0 || u == -1)
          for (L = _; X == null && L-- > 0; )
            o.has(ie[L]) || (X = L);
        if (u == 0 || u == 1)
          for (L = _; U == null && L++ < ie.length; )
            o.has(ie[L]) || (U = L);
        if (X != null || U != null)
          if (T) {
            let ve = X == null ? -1 / 0 : P(re[X], A, R, 0), xe = U == null ? 1 / 0 : P(re[U], A, R, 0), ze = G - ve, he = xe - G;
            ze <= he ? ze <= k && (y = X) : he <= k && (y = U);
          } else
            y = U == null ? X : X == null ? U : _ - X <= U - _ ? X : U;
      } else T && Re(G - P(re[_], A, R, 0)) > k && (y = null);
      return y;
    };
  }
  const Yt = (l) => {
    N.event = l;
  };
  N.idxs = ue, N._lock = !1;
  let Ie = N.points;
  Ie.show = te(Ie.show), Ie.size = te(Ie.size), Ie.stroke = te(Ie.stroke), Ie.width = te(Ie.width), Ie.fill = te(Ie.fill);
  const xt = s.focus = Ae({}, t.focus || { alpha: 0.3 }, N.focus), ms = xt.prox >= 0, gs = ms && Ie.one;
  let at = [], vs = [], bs = [];
  function dl(l, o) {
    let c = Ie.show(s, o);
    if (c instanceof HTMLElement)
      return st(c, fc), st(c, l.class), Tt(c, -10, -10, q, M), $.insertBefore(c, at[o]), c;
  }
  function ml(l, o) {
    if (i == 1 || o > 0) {
      let c = i == 1 && E[l.scale].time, u = l.value;
      l.value = c ? _r(u) ? Ar(se, Er(u, O)) : u || ne : u || Au, l.label = l.label || (c ? bu : vu);
    }
    if (gs || o > 0) {
      l.width = l.width == null ? 1 : l.width, l.paths = l.paths || Iu || Rc, l.fillTo = te(l.fillTo || Cu), l.pxAlign = +le(l.pxAlign, z), l.pxRound = Or(l.pxAlign), l.stroke = te(l.stroke || null), l.fill = te(l.fill || null), l._stroke = l._fill = l._paths = l._focus = null;
      let c = ku(je(1, l.width), 1), u = l.points = Ae({}, {
        size: c,
        width: je(1, c * 0.2),
        stroke: l.stroke,
        space: c * 2,
        paths: Uu,
        _stroke: null,
        _fill: null
      }, l.points);
      u.show = te(u.show), u.filter = te(u.filter), u.fill = te(u.fill), u.stroke = te(u.stroke), u.paths = te(u.paths), u.pxAlign = l.pxAlign;
    }
    if (ke) {
      let c = vn(l, o);
      Se.splice(o, 0, c[0]), yt.splice(o, 0, c[1]), Q.values.push(null);
    }
    if (We) {
      ue.splice(o, 0, null);
      let c = null;
      gs ? o == 0 && (c = dl(l, o)) : o > 0 && (c = dl(l, o)), at.splice(o, 0, c), vs.splice(o, 0, 0), bs.splice(o, 0, 0);
    }
    De("addSeries", o);
  }
  function na(l, o) {
    o = o ?? x.length, l = i == 1 ? Hi(l, o, Tr, Nr) : Hi(l, o, {}, Pr), x.splice(o, 0, l), ml(x[o], o);
  }
  s.addSeries = na;
  function ia(l) {
    if (x.splice(l, 1), ke) {
      Q.values.splice(l, 1), yt.splice(l, 1);
      let o = Se.splice(l, 1)[0];
      fs(null, o.firstChild), o.remove();
    }
    We && (ue.splice(l, 1), at.splice(l, 1)[0].remove(), vs.splice(l, 1), bs.splice(l, 1)), De("delSeries", l);
  }
  s.delSeries = ia;
  const Jt = [!1, !1, !1, !1];
  function la(l, o) {
    if (l._show = l.show, l.show) {
      let c = l.side % 2, u = E[l.scale];
      u == null && (l.scale = c ? x[1].scale : C, u = E[l.scale]);
      let m = u.time;
      l.size = te(l.size), l.space = te(l.space), l.rotate = te(l.rotate), Ut(l.incrs) && l.incrs.forEach((_) => {
        !Vt.has(_) && Vt.set(_, co(_));
      }), l.incrs = te(l.incrs || (u.distr == 2 ? Qc : m ? W == 1 ? eu : nu : ss)), l.splits = te(l.splits || (m && u.distr == 1 ? qe : u.distr == 3 ? Li : u.distr == 4 ? yu : wu)), l.stroke = te(l.stroke), l.grid.stroke = te(l.grid.stroke), l.ticks.stroke = te(l.ticks.stroke), l.border.stroke = te(l.border.stroke);
      let v = l.values;
      l.values = // static array of tick values
      Ut(v) && !Ut(v[0]) ? te(v) : (
        // temporal
        m ? (
          // config array of fmtDate string tpls
          Ut(v) ? $r(se, xr(v, O)) : (
            // fmtDate string tpl
            _r(v) ? ru(se, v) : v || _e
          )
        ) : v || _u
      ), l.filter = te(l.filter || (u.distr >= 3 && u.log == 10 ? $u : u.distr == 3 && u.log == 2 ? Eu : oo)), l.font = Fr(l.font), l.labelFont = Fr(l.labelFont), l._size = l.size(s, null, o, 0), l._space = l._rotate = l._incrs = l._found = // foundIncrSpace
      l._splits = l._values = null, l._size > 0 && (Jt[o] = !0, l._el = ht(ac, b));
    }
  }
  function Gs(l, o, c, u) {
    let [m, v, _, w] = c, y = o % 2, k = 0;
    return y == 0 && (w || v) && (k = o == 0 && !m || o == 2 && !_ ? Me(kr.size / 3) : 0), y == 1 && (m || _) && (k = o == 1 && !v || o == 3 && !w ? Me(Rr.size / 2) : 0), k;
  }
  const gl = s.padding = (t.padding || [Gs, Gs, Gs, Gs]).map((l) => te(le(l, Gs))), Dt = s._padding = gl.map((l, o) => l(s, o, Jt, 0));
  let He, Pe = null, Ne = null;
  const wn = i == 1 ? x[0].idxs : null;
  let mt = null, Bs = !1;
  function vl(l, o) {
    if (e = l ?? [], s.data = s._data = e, i == 2) {
      He = 0;
      for (let c = 1; c < x.length; c++)
        He += e[c][0].length;
    } else {
      e.length == 0 && (s.data = s._data = e = [[]]), mt = e[0], He = mt.length;
      let c = e;
      if (Y == 2) {
        c = e.slice();
        let u = c[0] = Array(He);
        for (let m = 0; m < He; m++)
          u[m] = m;
      }
      s._data = e = c;
    }
    if (ws(!0), De("setData"), Y == 2 && (ds = !0), o !== !1) {
      let c = A;
      c.auto(s, Bs) ? Zn() : Ht(C, c.min, c.max), qt = qt || N.left >= 0, ot = !0, ys();
    }
  }
  s.setData = vl;
  function Zn() {
    Bs = !0;
    let l, o;
    i == 1 && (He > 0 ? (Pe = wn[0] = 0, Ne = wn[1] = He - 1, l = e[0][Pe], o = e[0][Ne], Y == 2 ? (l = Pe, o = Ne) : l == o && (Y == 3 ? [l, o] = Wn(l, l, A.log, !1) : Y == 4 ? [l, o] = Qi(l, l, A.log, !1) : A.time ? o = l + Me(86400 / W) : [l, o] = Dn(l, o, Xi, !0))) : (Pe = wn[0] = l = null, Ne = wn[1] = o = null)), Ht(C, l, o);
  }
  let yn, _s, Qn, Xn, ei, ti, si, ni, ii, Je;
  function bl(l, o, c, u, m, v) {
    l ??= sr, c ??= tl, u ??= "butt", m ??= sr, v ??= "round", l != yn && (d.strokeStyle = yn = l), m != _s && (d.fillStyle = _s = m), o != Qn && (d.lineWidth = Qn = o), v != ei && (d.lineJoin = ei = v), u != ti && (d.lineCap = ti = u), c != Xn && d.setLineDash(Xn = c);
  }
  function _l(l, o, c, u) {
    o != _s && (d.fillStyle = _s = o), l != si && (d.font = si = l), c != ni && (d.textAlign = ni = c), u != ii && (d.textBaseline = ii = u);
  }
  function li(l, o, c, u, m = 0) {
    if (u.length > 0 && l.auto(s, Bs) && (o == null || o.min == null)) {
      let v = le(Pe, 0), _ = le(Ne, u.length - 1), w = c.min == null ? $c(u, v, _, m, l.distr == 3) : [c.min, c.max];
      l.min = wt(l.min, c.min = w[0]), l.max = je(l.max, c.max = w[1]);
    }
  }
  const wl = { min: null, max: null };
  function ra() {
    for (let u in E) {
      let m = E[u];
      D[u] == null && // scales that have never been set (on init)
      (m.min == null || // or auto scales when the x scale was explicitly set
      D[C] != null && m.auto(s, Bs)) && (D[u] = wl);
    }
    for (let u in E) {
      let m = E[u];
      D[u] == null && m.from != null && D[m.from] != null && (D[u] = wl);
    }
    D[C] != null && ws(!0);
    let l = {};
    for (let u in D) {
      let m = D[u];
      if (m != null) {
        let v = l[u] = Hs(E[u], Nc);
        if (m.min != null)
          Ae(v, m);
        else if (u != C || i == 2)
          if (He == 0 && v.from == null) {
            let _ = v.range(s, null, null, u);
            v.min = _[0], v.max = _[1];
          } else
            v.min = fe, v.max = -fe;
      }
    }
    if (He > 0) {
      x.forEach((u, m) => {
        if (i == 1) {
          let v = u.scale, _ = D[v];
          if (_ == null)
            return;
          let w = l[v];
          if (m == 0) {
            let y = w.range(s, w.min, w.max, v);
            w.min = y[0], w.max = y[1], Pe = _t(w.min, e[0]), Ne = _t(w.max, e[0]), Ne - Pe > 1 && (e[0][Pe] < w.min && Pe++, e[0][Ne] > w.max && Ne--), u.min = mt[Pe], u.max = mt[Ne];
          } else u.show && u.auto && li(w, _, u, e[m], u.sorted);
          u.idxs[0] = Pe, u.idxs[1] = Ne;
        } else if (m > 0 && u.show && u.auto) {
          let [v, _] = u.facets, w = v.scale, y = _.scale, [k, T] = e[m], R = l[w], G = l[y];
          R != null && li(R, D[w], v, k, v.sorted), G != null && li(G, D[y], _, T, _.sorted), u.min = _.min, u.max = _.max;
        }
      });
      for (let u in l) {
        let m = l[u], v = D[u];
        if (m.from == null && (v == null || v.min == null)) {
          let _ = m.range(
            s,
            m.min == fe ? null : m.min,
            m.max == -fe ? null : m.max,
            u
          );
          m.min = _[0], m.max = _[1];
        }
      }
    }
    for (let u in l) {
      let m = l[u];
      if (m.from != null) {
        let v = l[m.from];
        if (v.min == null)
          m.min = m.max = null;
        else {
          let _ = m.range(s, v.min, v.max, u);
          m.min = _[0], m.max = _[1];
        }
      }
    }
    let o = {}, c = !1;
    for (let u in l) {
      let m = l[u], v = E[u];
      if (v.min != m.min || v.max != m.max) {
        v.min = m.min, v.max = m.max;
        let _ = v.distr;
        v._min = _ == 3 ? Nt(v.min) : _ == 4 ? Si(v.min, v.asinh) : _ == 100 ? v.fwd(v.min) : v.min, v._max = _ == 3 ? Nt(v.max) : _ == 4 ? Si(v.max, v.asinh) : _ == 100 ? v.fwd(v.max) : v.max, o[u] = c = !0;
      }
    }
    if (c) {
      x.forEach((u, m) => {
        i == 2 ? m > 0 && o.y && (u._paths = null) : o[u.scale] && (u._paths = null);
      });
      for (let u in o)
        ds = !0, De("setScale", u);
      We && N.left >= 0 && (qt = ot = !0);
    }
    for (let u in D)
      D[u] = null;
  }
  function oa(l) {
    let o = Ni(Pe - 1, 0, He - 1), c = Ni(Ne + 1, 0, He - 1);
    for (; l[o] == null && o > 0; )
      o--;
    for (; l[c] == null && c < He - 1; )
      c++;
    return [o, c];
  }
  function aa() {
    if (He > 0) {
      let l = x.some((o) => o._focus) && Je != xt.alpha;
      l && (d.globalAlpha = Je = xt.alpha), x.forEach((o, c) => {
        if (c > 0 && o.show && (yl(c, !1), yl(c, !0), o._paths == null)) {
          let u = Je;
          Je != o.alpha && (d.globalAlpha = Je = o.alpha);
          let m = i == 2 ? [0, e[c][0].length - 1] : oa(e[c]);
          o._paths = o.paths(s, c, m[0], m[1]), Je != u && (d.globalAlpha = Je = u);
        }
      }), x.forEach((o, c) => {
        if (c > 0 && o.show) {
          let u = Je;
          Je != o.alpha && (d.globalAlpha = Je = o.alpha), o._paths != null && Sl(c, !1);
          {
            let m = o._paths != null ? o._paths.gaps : null, v = o.points.show(s, c, Pe, Ne, m), _ = o.points.filter(s, c, v, m);
            (v || _) && (o.points._paths = o.points.paths(s, c, Pe, Ne, _), Sl(c, !0));
          }
          Je != u && (d.globalAlpha = Je = u), De("drawSeries", c);
        }
      }), l && (d.globalAlpha = Je = 1);
    }
  }
  function yl(l, o) {
    let c = o ? x[l].points : x[l];
    c._stroke = c.stroke(s, l), c._fill = c.fill(s, l);
  }
  function Sl(l, o) {
    let c = o ? x[l].points : x[l], {
      stroke: u,
      fill: m,
      clip: v,
      flags: _,
      _stroke: w = c._stroke,
      _fill: y = c._fill,
      _width: k = c.width
    } = c._paths;
    k = pe(k * oe, 3);
    let T = null, R = k % 2 / 2;
    o && y == null && (y = k > 0 ? "#fff" : w);
    let G = c.pxAlign == 1 && R > 0;
    if (G && d.translate(R, R), !o) {
      let re = Qe - k / 2, ie = rt - k / 2, X = Ye + k, U = dt + k;
      T = new Path2D(), T.rect(re, ie, X, U);
    }
    o ? ri(w, k, c.dash, c.cap, y, u, m, _, v) : ca(l, w, k, c.dash, c.cap, y, u, m, _, T, v), G && d.translate(-R, -R);
  }
  function ca(l, o, c, u, m, v, _, w, y, k, T) {
    let R = !1;
    y != 0 && J.forEach((G, re) => {
      if (G.series[0] == l) {
        let ie = x[G.series[1]], X = e[G.series[1]], U = (ie._paths || cn).band;
        Ut(U) && (U = G.dir == 1 ? U[0] : U[1]);
        let L, ve = null;
        ie.show && U && Ac(X, Pe, Ne) ? (ve = G.fill(s, re) || v, L = ie._paths.clip) : U = null, ri(o, c, u, m, ve, _, w, y, k, T, L, U), R = !0;
      }
    }), R || ri(o, c, u, m, v, _, w, y, k, T);
  }
  const xl = Fs | Di;
  function ri(l, o, c, u, m, v, _, w, y, k, T, R) {
    bl(l, o, c, u, m), (y || k || R) && (d.save(), y && d.clip(y), k && d.clip(k)), R ? (w & xl) == xl ? (d.clip(R), T && d.clip(T), xn(m, _), Sn(l, v, o)) : w & Di ? (xn(m, _), d.clip(R), Sn(l, v, o)) : w & Fs && (d.save(), d.clip(R), T && d.clip(T), xn(m, _), d.restore(), Sn(l, v, o)) : (xn(m, _), Sn(l, v, o)), (y || k || R) && d.restore();
  }
  function Sn(l, o, c) {
    c > 0 && (o instanceof Map ? o.forEach((u, m) => {
      d.strokeStyle = yn = m, d.stroke(u);
    }) : o != null && l && d.stroke(o));
  }
  function xn(l, o) {
    o instanceof Map ? o.forEach((c, u) => {
      d.fillStyle = _s = u, d.fill(c);
    }) : o != null && l && d.fill(o);
  }
  function ua(l, o, c, u) {
    let m = H[l], v;
    if (u <= 0)
      v = [0, 0];
    else {
      let _ = m._space = m.space(s, l, o, c, u), w = m._incrs = m.incrs(s, l, o, c, u, _);
      v = ju(o, c, w, u, _);
    }
    return m._found = v;
  }
  function oi(l, o, c, u, m, v, _, w, y, k) {
    let T = _ % 2 / 2;
    z == 1 && d.translate(T, T), bl(w, _, y, k, w), d.beginPath();
    let R, G, re, ie, X = m + (u == 0 || u == 3 ? -v : v);
    c == 0 ? (G = m, ie = X) : (R = m, re = X);
    for (let U = 0; U < l.length; U++)
      o[U] != null && (c == 0 ? R = re = l[U] : G = ie = l[U], d.moveTo(R, G), d.lineTo(re, ie));
    d.stroke(), z == 1 && d.translate(-T, -T);
  }
  function ha(l) {
    let o = !0;
    return H.forEach((c, u) => {
      if (!c.show)
        return;
      let m = E[c.scale];
      if (m.min == null) {
        c._show && (o = !1, c._show = !1, ws(!1));
        return;
      } else
        c._show || (o = !1, c._show = !0, ws(!1));
      let v = c.side, _ = v % 2, { min: w, max: y } = m, [k, T] = ua(u, w, y, _ == 0 ? q : M);
      if (T == 0)
        return;
      let R = m.distr == 2, G = c._splits = c.splits(s, u, w, y, k, T, R), re = m.distr == 2 ? G.map((L) => mt[L]) : G, ie = m.distr == 2 ? mt[G[1]] - mt[G[0]] : k, X = c._values = c.values(s, c.filter(s, re, u, T, ie), u, T, ie);
      c._rotate = v == 2 ? c.rotate(s, X, u, T) : 0;
      let U = c._size;
      c._size = ft(c.size(s, X, u, l)), U != null && c._size != U && (o = !1);
    }), o;
  }
  function fa(l) {
    let o = !0;
    return gl.forEach((c, u) => {
      let m = c(s, u, Jt, l);
      m != Dt[u] && (o = !1), Dt[u] = m;
    }), o;
  }
  function pa() {
    for (let l = 0; l < H.length; l++) {
      let o = H[l];
      if (!o.show || !o._show)
        continue;
      let c = o.side, u = c % 2, m, v, _ = o.stroke(s, l), w = c == 0 || c == 3 ? -1 : 1, [y, k] = o._found;
      if (o.label != null) {
        let Be = o.labelGap * w, tt = Me((o._lpos + Be) * oe);
        _l(o.labelFont[0], _, "center", c == 2 ? Qs : tr), d.save(), u == 1 ? (m = v = 0, d.translate(
          tt,
          Me(rt + dt / 2)
        ), d.rotate((c == 3 ? -Pn : Pn) / 2)) : (m = Me(Qe + Ye / 2), v = tt);
        let Xt = lo(o.label) ? o.label(s, l, y, k) : o.label;
        d.fillText(Xt, m, v), d.restore();
      }
      if (k == 0)
        continue;
      let T = E[o.scale], R = u == 0 ? Ye : dt, G = u == 0 ? Qe : rt, re = o._splits, ie = T.distr == 2 ? re.map((Be) => mt[Be]) : re, X = T.distr == 2 ? mt[re[1]] - mt[re[0]] : y, U = o.ticks, L = o.border, ve = U.show ? U.size : 0, xe = Me(ve * oe), ze = Me((o.alignTo == 2 ? o._size - ve - o.gap : o.gap) * oe), he = o._rotate * -Pn / 180, $e = I(o._pos * oe), Xe = (xe + ze) * w, Ge = $e + Xe;
      v = u == 0 ? Ge : 0, m = u == 1 ? Ge : 0;
      let ct = o.font[0], gt = o.align == 1 ? Ms : o.align == 2 ? _i : he > 0 ? Ms : he < 0 ? _i : u == 0 ? "center" : c == 3 ? _i : Ms, At = he || u == 1 ? "middle" : c == 2 ? Qs : tr;
      _l(ct, _, gt, At);
      let et = o.font[1] * o.lineGap, ut = re.map((Be) => I(h(Be, T, R, G))), vt = o._values;
      for (let Be = 0; Be < vt.length; Be++) {
        let tt = vt[Be];
        if (tt != null) {
          u == 0 ? m = ut[Be] : v = ut[Be], tt = "" + tt;
          let Xt = tt.indexOf(`
`) == -1 ? [tt] : tt.split(/\n/gm);
          for (let Ke = 0; Ke < Xt.length; Ke++) {
            let Wl = Xt[Ke];
            he ? (d.save(), d.translate(m, v + Ke * et), d.rotate(he), d.fillText(Wl, 0, 0), d.restore()) : d.fillText(Wl, m, v + Ke * et);
          }
        }
      }
      U.show && oi(
        ut,
        U.filter(s, ie, l, k, X),
        u,
        c,
        $e,
        xe,
        pe(U.width * oe, 3),
        U.stroke(s, l),
        U.dash,
        U.cap
      );
      let kt = o.grid;
      kt.show && oi(
        ut,
        kt.filter(s, ie, l, k, X),
        u,
        u == 0 ? 2 : 1,
        u == 0 ? rt : Qe,
        u == 0 ? dt : Ye,
        pe(kt.width * oe, 3),
        kt.stroke(s, l),
        kt.dash,
        kt.cap
      ), L.show && oi(
        [$e],
        [1],
        u == 0 ? 1 : 0,
        u == 0 ? 1 : 2,
        u == 1 ? rt : Qe,
        u == 1 ? dt : Ye,
        pe(L.width * oe, 3),
        L.stroke(s, l),
        L.dash,
        L.cap
      );
    }
    De("drawAxes");
  }
  function ws(l) {
    x.forEach((o, c) => {
      c > 0 && (o._paths = null, l && (i == 1 ? (o.min = null, o.max = null) : o.facets.forEach((u) => {
        u.min = null, u.max = null;
      })));
    });
  }
  let $n = !1, ai = !1, Ks = [];
  function da() {
    ai = !1;
    for (let l = 0; l < Ks.length; l++)
      De(...Ks[l]);
    Ks.length = 0;
  }
  function ys() {
    $n || (Ic($l), $n = !0);
  }
  function ma(l, o = !1) {
    $n = !0, ai = o, l(s), $l(), o && Ks.length > 0 && queueMicrotask(da);
  }
  s.batch = ma;
  function $l() {
    if (Yn && (ra(), Yn = !1), ds && (Xo(), ds = !1), bn) {
      if (be(S, Ms, de), be(S, Qs, Te), be(S, nn, q), be(S, ln, M), be($, Ms, de), be($, Qs, Te), be($, nn, q), be($, ln, M), be(b, nn, Ct), be(b, ln, Bt), g.width = Me(Ct * oe), g.height = Me(Bt * oe), H.forEach(({ _el: l, _show: o, _size: c, _pos: u, side: m }) => {
        if (l != null)
          if (o) {
            let v = m === 3 || m === 0 ? c : 0, _ = m % 2 == 1;
            be(l, _ ? "left" : "top", u - v), be(l, _ ? "width" : "height", c), be(l, _ ? "top" : "left", _ ? Te : de), be(l, _ ? "height" : "width", _ ? M : q), Ci(l, ns);
          } else
            st(l, ns);
      }), yn = _s = Qn = ei = ti = si = ni = ii = Xn = null, Je = 1, Ys(!0), de != ps || Te != Kt || q != St || M != jt) {
        ws(!1);
        let l = q / St, o = M / jt;
        if (We && !qt && N.left >= 0) {
          N.left *= l, N.top *= o, Ss && Tt(Ss, Me(N.left), 0, q, M), xs && Tt(xs, 0, Me(N.top), q, M);
          for (let c = 0; c < at.length; c++) {
            let u = at[c];
            u != null && (vs[c] *= l, bs[c] *= o, Tt(u, ft(vs[c]), ft(bs[c]), q, M));
          }
        }
        if (ge.show && !_n && ge.left >= 0 && ge.width > 0) {
          ge.left *= l, ge.width *= l, ge.top *= o, ge.height *= o;
          for (let c in di)
            be(As, c, ge[c]);
        }
        ps = de, Kt = Te, St = q, jt = M;
      }
      De("setSize"), bn = !1;
    }
    Ct > 0 && Bt > 0 && (d.clearRect(0, 0, g.width, g.height), De("drawClear"), j.forEach((l) => l()), De("draw")), ge.show && _n && (En(ge), _n = !1), We && qt && (Qt(null, !0, !1), qt = !1), Q.show && Q.live && ot && (fi(), ot = !1), f || (f = !0, s.status = 1, De("ready")), Bs = !1, $n = !1;
  }
  s.redraw = (l, o) => {
    ds = o || !1, l !== !1 ? Ht(C, A.min, A.max) : ys();
  };
  function ci(l, o) {
    let c = E[l];
    if (c.from == null) {
      if (He == 0) {
        let u = c.range(s, o.min, o.max, l);
        o.min = u[0], o.max = u[1];
      }
      if (o.min > o.max) {
        let u = o.min;
        o.min = o.max, o.max = u;
      }
      if (He > 1 && o.min != null && o.max != null && o.max - o.min < 1e-16)
        return;
      l == C && c.distr == 2 && He > 0 && (o.min = _t(o.min, e[0]), o.max = _t(o.max, e[0]), o.min == o.max && o.max++), D[l] = o, Yn = !0, ys();
    }
  }
  s.setScale = ci;
  let ui, hi, Ss, xs, El, Al, $s, Es, kl, Tl, me, ye, zt = !1;
  const Fe = N.drag;
  let Le = Fe.x, Oe = Fe.y;
  We && (N.x && (ui = ht(uc, $)), N.y && (hi = ht(hc, $)), A.ori == 0 ? (Ss = ui, xs = hi) : (Ss = hi, xs = ui), me = N.left, ye = N.top);
  const ge = s.select = Ae({
    show: !0,
    over: !0,
    left: 0,
    width: 0,
    top: 0,
    height: 0
  }, t.select), As = ge.show ? ht(cc, ge.over ? $ : S) : null;
  function En(l, o) {
    if (ge.show) {
      for (let c in l)
        ge[c] = l[c], c in di && be(As, c, l[c]);
      o !== !1 && De("setSelect");
    }
  }
  s.setSelect = En;
  function ga(l) {
    if (x[l].show)
      ke && Ci(Se[l], ns);
    else if (ke && st(Se[l], ns), We) {
      let c = gs ? at[0] : at[l];
      c != null && Tt(c, -10, -10, q, M);
    }
  }
  function Ht(l, o, c) {
    ci(l, { min: o, max: c });
  }
  function $t(l, o, c, u) {
    o.focus != null && ya(l), o.show != null && x.forEach((m, v) => {
      v > 0 && (l == v || l == null) && (m.show = o.show, ga(v), i == 2 ? (Ht(m.facets[0].scale, null, null), Ht(m.facets[1].scale, null, null)) : Ht(m.scale, null, null), ys());
    }), c !== !1 && De("setSeries", l, o), u && Js("setSeries", s, l, o);
  }
  s.setSeries = $t;
  function va(l, o) {
    Ae(J[l], o);
  }
  function ba(l, o) {
    l.fill = te(l.fill || null), l.dir = le(l.dir, -1), o = o ?? J.length, J.splice(o, 0, l);
  }
  function _a(l) {
    l == null ? J.length = 0 : J.splice(l, 1);
  }
  s.addBand = ba, s.setBand = va, s.delBand = _a;
  function wa(l, o) {
    x[l].alpha = o, We && at[l] != null && (at[l].style.opacity = o), ke && Se[l] && (Se[l].style.opacity = o);
  }
  let Pt, Ft, Zt;
  const ks = { focus: !0 };
  function ya(l) {
    if (l != Zt) {
      let o = l == null, c = xt.alpha != 1;
      x.forEach((u, m) => {
        if (i == 1 || m > 0) {
          let v = o || m == 0 || m == l;
          u._focus = o ? null : v, c && wa(m, v ? 1 : xt.alpha);
        }
      }), Zt = l, c && ys();
    }
  }
  ke && ms && Ve(lr, ae, (l) => {
    N._lock || (Yt(l), Zt != null && $t(null, ks, !0, Ee.setSeries));
  });
  function Et(l, o, c) {
    let u = E[o];
    c && (l = l / oe - (u.ori == 1 ? Te : de));
    let m = q;
    u.ori == 1 && (m = M, l = m - l), u.dir == -1 && (l = m - l);
    let v = u._min, _ = u._max, w = l / m, y = v + (_ - v) * w, k = u.distr;
    return k == 3 ? Ds(10, y) : k == 4 ? Tc(y, u.asinh) : k == 100 ? u.bwd(y) : y;
  }
  function Sa(l, o) {
    let c = Et(l, C, o);
    return _t(c, e[0], Pe, Ne);
  }
  s.valToIdx = (l) => _t(l, e[0]), s.posToIdx = Sa, s.posToVal = Et, s.valToPos = (l, o, c) => E[o].ori == 0 ? r(
    l,
    E[o],
    c ? Ye : q,
    c ? Qe : 0
  ) : a(
    l,
    E[o],
    c ? dt : M,
    c ? rt : 0
  ), s.setCursor = (l, o, c) => {
    me = l.left, ye = l.top, Qt(null, o, c);
  };
  function Ml(l, o) {
    be(As, Ms, ge.left = l), be(As, nn, ge.width = o);
  }
  function Rl(l, o) {
    be(As, Qs, ge.top = l), be(As, ln, ge.height = o);
  }
  let js = A.ori == 0 ? Ml : Rl, qs = A.ori == 1 ? Ml : Rl;
  function xa() {
    if (ke && Q.live)
      for (let l = i == 2 ? 1 : 0; l < x.length; l++) {
        if (l == 0 && lt)
          continue;
        let o = Q.values[l], c = 0;
        for (let u in o)
          yt[l][c++].firstChild.nodeValue = o[u];
      }
  }
  function fi(l, o) {
    if (l != null && (l.idxs ? l.idxs.forEach((c, u) => {
      ue[u] = c;
    }) : Pc(l.idx) || ue.fill(l.idx), Q.idx = ue[0]), ke && Q.live) {
      for (let c = 0; c < x.length; c++)
        (c > 0 || i == 1 && !lt) && $a(c, ue[c]);
      xa();
    }
    ot = !1, o !== !1 && De("setLegend");
  }
  s.setLegend = fi;
  function $a(l, o) {
    let c = x[l], u = l == 0 && Y == 2 ? mt : e[l], m;
    lt ? m = c.values(s, l, o) ?? Ot : (m = c.value(s, o == null ? null : u[o], l, o), m = m == null ? Ot : { _: m }), Q.values[l] = m;
  }
  function Qt(l, o, c) {
    kl = me, Tl = ye, [me, ye] = N.move(s, me, ye), N.left = me, N.top = ye, We && (Ss && Tt(Ss, Me(me), 0, q, M), xs && Tt(xs, 0, Me(ye), q, M));
    let u, m = Pe > Ne;
    Pt = fe, Ft = null;
    let v = A.ori == 0 ? q : M, _ = A.ori == 1 ? q : M;
    if (me < 0 || He == 0 || m) {
      u = N.idx = null;
      for (let w = 0; w < x.length; w++) {
        let y = at[w];
        y != null && Tt(y, -10, -10, q, M);
      }
      ms && $t(null, ks, !0, l == null && Ee.setSeries), Q.live && (ue.fill(u), ot = !0);
    } else {
      let w, y, k;
      i == 1 && (w = A.ori == 0 ? me : ye, y = Et(w, C), u = N.idx = _t(y, e[0], Pe, Ne), k = P(e[0][u], A, v, 0));
      let T = -10, R = -10, G = 0, re = 0, ie = !0, X = "", U = "";
      for (let L = i == 2 ? 1 : 0; L < x.length; L++) {
        let ve = x[L], xe = ue[L], ze = xe == null ? null : i == 1 ? e[L][xe] : e[L][1][xe], he = N.dataIdx(s, L, u, y), $e = he == null ? null : i == 1 ? e[L][he] : e[L][1][he];
        if (ot = ot || $e != ze || he != xe, ue[L] = he, L > 0 && ve.show) {
          let Xe = he == null ? -10 : he == u ? k : P(i == 1 ? e[0][he] : e[L][0][he], A, v, 0), Ge = $e == null ? -10 : V($e, i == 1 ? E[ve.scale] : E[ve.facets[1].scale], _, 0);
          if (ms && $e != null) {
            let ct = A.ori == 1 ? me : ye, gt = Re(xt.dist(s, L, he, Ge, ct));
            if (gt < Pt) {
              let At = xt.bias;
              if (At != 0) {
                let et = Et(ct, ve.scale), ut = $e >= 0 ? 1 : -1, vt = et >= 0 ? 1 : -1;
                vt == ut && (vt == 1 ? At == 1 ? $e >= et : $e <= et : (
                  // >= 0
                  At == 1 ? $e <= et : $e >= et
                )) && (Pt = gt, Ft = L);
              } else
                Pt = gt, Ft = L;
            }
          }
          if (ot || gs) {
            let ct, gt;
            A.ori == 0 ? (ct = Xe, gt = Ge) : (ct = Ge, gt = Xe);
            let At, et, ut, vt, kt, Be, tt = !0, Xt = Ie.bbox;
            if (Xt != null) {
              tt = !1;
              let Ke = Xt(s, L);
              ut = Ke.left, vt = Ke.top, At = Ke.width, et = Ke.height;
            } else
              ut = ct, vt = gt, At = et = Ie.size(s, L);
            if (Be = Ie.fill(s, L), kt = Ie.stroke(s, L), gs)
              L == Ft && Pt <= xt.prox && (T = ut, R = vt, G = At, re = et, ie = tt, X = Be, U = kt);
            else {
              let Ke = at[L];
              Ke != null && (vs[L] = ut, bs[L] = vt, fr(Ke, At, et, tt), ur(Ke, Be, kt), Tt(Ke, ft(ut), ft(vt), q, M));
            }
          }
        }
      }
      if (gs) {
        let L = xt.prox, ve = Zt == null ? Pt <= L : Pt > L || Ft != Zt;
        if (ot || ve) {
          let xe = at[0];
          xe != null && (vs[0] = T, bs[0] = R, fr(xe, G, re, ie), ur(xe, X, U), Tt(xe, ft(T), ft(R), q, M));
        }
      }
    }
    if (ge.show && zt)
      if (l != null) {
        let [w, y] = Ee.scales, [k, T] = Ee.match, [R, G] = l.cursor.sync.scales, re = l.cursor.drag;
        if (Le = re._x, Oe = re._y, Le || Oe) {
          let { left: ie, top: X, width: U, height: L } = l.select, ve = l.scales[R].ori, xe = l.posToVal, ze, he, $e, Xe, Ge, ct = w != null && k(w, R), gt = y != null && T(y, G);
          ct && Le ? (ve == 0 ? (ze = ie, he = U) : (ze = X, he = L), $e = E[w], Xe = P(xe(ze, R), $e, v, 0), Ge = P(xe(ze + he, R), $e, v, 0), js(wt(Xe, Ge), Re(Ge - Xe))) : js(0, v), gt && Oe ? (ve == 1 ? (ze = ie, he = U) : (ze = X, he = L), $e = E[y], Xe = V(xe(ze, G), $e, _, 0), Ge = V(xe(ze + he, G), $e, _, 0), qs(wt(Xe, Ge), Re(Ge - Xe))) : qs(0, _);
        } else
          mi();
      } else {
        let w = Re(kl - El), y = Re(Tl - Al);
        if (A.ori == 1) {
          let G = w;
          w = y, y = G;
        }
        Le = Fe.x && w >= Fe.dist, Oe = Fe.y && y >= Fe.dist;
        let k = Fe.uni;
        k != null ? Le && Oe && (Le = w >= k, Oe = y >= k, !Le && !Oe && (y > w ? Oe = !0 : Le = !0)) : Fe.x && Fe.y && (Le || Oe) && (Le = Oe = !0);
        let T, R;
        Le && (A.ori == 0 ? (T = $s, R = me) : (T = Es, R = ye), js(wt(T, R), Re(R - T)), Oe || qs(0, _)), Oe && (A.ori == 1 ? (T = $s, R = me) : (T = Es, R = ye), qs(wt(T, R), Re(R - T)), Le || js(0, v)), !Le && !Oe && (js(0, 0), qs(0, 0));
      }
    if (Fe._x = Le, Fe._y = Oe, l == null) {
      if (c) {
        if (Ul != null) {
          let [w, y] = Ee.scales;
          Ee.values[0] = w != null ? Et(A.ori == 0 ? me : ye, w) : null, Ee.values[1] = y != null ? Et(A.ori == 1 ? me : ye, y) : null;
        }
        Js(wi, s, me, ye, q, M, u);
      }
      if (ms) {
        let w = c && Ee.setSeries, y = xt.prox;
        Zt == null ? Pt <= y && $t(Ft, ks, !0, w) : Pt > y ? $t(null, ks, !0, w) : Ft != Zt && $t(Ft, ks, !0, w);
      }
    }
    ot && (Q.idx = u, fi()), o !== !1 && De("setCursor");
  }
  let It = null;
  Object.defineProperty(s, "rect", {
    get() {
      return It == null && Ys(!1), It;
    }
  });
  function Ys(l = !1) {
    l ? It = null : (It = $.getBoundingClientRect(), De("syncRect", It));
  }
  function Cl(l, o, c, u, m, v, _) {
    N._lock || zt && l != null && l.movementX == 0 && l.movementY == 0 || (pi(l, o, c, u, m, v, _, !1, l != null), l != null ? Qt(null, !0, !0) : Qt(o, !0, !1));
  }
  function pi(l, o, c, u, m, v, _, w, y) {
    if (It == null && Ys(!1), Yt(l), l != null)
      c = l.clientX - It.left, u = l.clientY - It.top;
    else {
      if (c < 0 || u < 0) {
        me = -10, ye = -10;
        return;
      }
      let [k, T] = Ee.scales, R = o.cursor.sync, [G, re] = R.values, [ie, X] = R.scales, [U, L] = Ee.match, ve = o.axes[0].side % 2 == 1, xe = A.ori == 0 ? q : M, ze = A.ori == 1 ? q : M, he = ve ? v : m, $e = ve ? m : v, Xe = ve ? u : c, Ge = ve ? c : u;
      if (ie != null ? c = U(k, ie) ? h(G, E[k], xe, 0) : -10 : c = xe * (Xe / he), X != null ? u = L(T, X) ? h(re, E[T], ze, 0) : -10 : u = ze * (Ge / $e), A.ori == 1) {
        let ct = c;
        c = u, u = ct;
      }
    }
    y && (o == null || o.cursor.event.type == wi) && ((c <= 1 || c >= q - 1) && (c = ts(c, q)), (u <= 1 || u >= M - 1) && (u = ts(u, M))), w ? (El = c, Al = u, [$s, Es] = N.move(s, c, u)) : (me = c, ye = u);
  }
  const di = {
    width: 0,
    height: 0,
    left: 0,
    top: 0
  };
  function mi() {
    En(di, !1);
  }
  let Pl, Nl, Ll, Ol;
  function Dl(l, o, c, u, m, v, _) {
    zt = !0, Le = Oe = Fe._x = Fe._y = !1, pi(l, o, c, u, m, v, _, !0, !1), l != null && (Ve(yi, Mi, zl, !1), Js(nr, s, $s, Es, q, M, null));
    let { left: w, top: y, width: k, height: T } = ge;
    Pl = w, Nl = y, Ll = k, Ol = T;
  }
  function zl(l, o, c, u, m, v, _) {
    zt = Fe._x = Fe._y = !1, pi(l, o, c, u, m, v, _, !1, !0);
    let { left: w, top: y, width: k, height: T } = ge, R = k > 0 || T > 0, G = Pl != w || Nl != y || Ll != k || Ol != T;
    if (R && G && En(ge), Fe.setScale && R && G) {
      let re = w, ie = k, X = y, U = T;
      if (A.ori == 1 && (re = y, ie = T, X = w, U = k), Le && Ht(
        C,
        Et(re, C),
        Et(re + ie, C)
      ), Oe)
        for (let L in E) {
          let ve = E[L];
          L != C && ve.from == null && ve.min != fe && Ht(
            L,
            Et(X + U, L),
            Et(X, L)
          );
        }
      mi();
    } else N.lock && (N._lock = !N._lock, Qt(o, !0, l != null));
    l != null && (fs(yi, Mi), Js(yi, s, me, ye, q, M, null));
  }
  function Ea(l, o, c, u, m, v, _) {
    if (N._lock)
      return;
    Yt(l);
    let w = zt;
    if (zt) {
      let y = !0, k = !0, T = 10, R, G;
      A.ori == 0 ? (R = Le, G = Oe) : (R = Oe, G = Le), R && G && (y = me <= T || me >= q - T, k = ye <= T || ye >= M - T), R && y && (me = me < $s ? 0 : q), G && k && (ye = ye < Es ? 0 : M), Qt(null, !0, !0), zt = !1;
    }
    me = -10, ye = -10, ue.fill(null), Qt(null, !0, !0), w && (zt = w);
  }
  function Hl(l, o, c, u, m, v, _) {
    N._lock || (Yt(l), Zn(), mi(), l != null && Js(rr, s, me, ye, q, M, null));
  }
  function Fl() {
    H.forEach(qu), Jn(s.width, s.height, !0);
  }
  ls(On, Ns, Fl);
  const Ts = {};
  Ts.mousedown = Dl, Ts.mousemove = Cl, Ts.mouseup = zl, Ts.dblclick = Hl, Ts.setSeries = (l, o, c, u) => {
    let m = Ee.match[2];
    c = m(s, o, c), c != -1 && $t(c, u, !0, !1);
  }, We && (Ve(nr, $, Dl), Ve(wi, $, Cl), Ve(ir, $, (l) => {
    Yt(l), Ys(!1);
  }), Ve(lr, $, Ea), Ve(rr, $, Hl), zi.add(s), s.syncRect = Ys);
  const An = s.hooks = t.hooks || {};
  function De(l, o, c) {
    ai ? Ks.push([l, o, c]) : l in An && An[l].forEach((u) => {
      u.call(null, s, o, c);
    });
  }
  (t.plugins || []).forEach((l) => {
    for (let o in l.hooks)
      An[o] = (An[o] || []).concat(l.hooks[o]);
  });
  const Il = (l, o, c) => c, Ee = Ae({
    key: null,
    setSeries: !1,
    filters: {
      pub: vr,
      sub: vr
    },
    scales: [C, x[1] ? x[1].scale : null],
    match: [br, br, Il],
    values: [null, null]
  }, N.sync);
  Ee.match.length == 2 && Ee.match.push(Il), N.sync = Ee;
  const Ul = Ee.key, gi = Ro(Ul);
  function Js(l, o, c, u, m, v, _) {
    Ee.filters.pub(l, o, c, u, m, v, _) && gi.pub(l, o, c, u, m, v, _);
  }
  gi.sub(s);
  function Aa(l, o, c, u, m, v, _) {
    Ee.filters.sub(l, o, c, u, m, v, _) && Ts[l](null, o, c, u, m, v, _);
  }
  s.pub = Aa;
  function ka() {
    gi.unsub(s), zi.delete(s), Gt.clear(), Pi(On, Ns, Fl), p.remove(), ae?.remove(), De("destroy");
  }
  s.destroy = ka;
  function vi() {
    De("init", t, e), vl(e || t.data, !1), D[C] ? ci(C, D[C]) : Zn(), _n = ge.show && (ge.width > 0 || ge.height > 0), qt = ot = !0, Jn(t.width, t.height);
  }
  return x.forEach(ml), H.forEach(la), n ? n instanceof HTMLElement ? (n.appendChild(p), vi()) : n(s, vi) : vi(), s;
}
Ue.assign = Ae;
Ue.fmtNum = el;
Ue.rangeNum = Dn;
Ue.rangeLog = Wn;
Ue.rangeAsinh = Qi;
Ue.orient = as;
Ue.pxRatio = oe;
Ue.join = Fc;
Ue.fmtDate = sl, Ue.tzDate = Jc;
Ue.sync = Ro;
{
  Ue.addGap = Pu, Ue.clipGaps = Bn;
  let t = Ue.paths = {
    points: Do
  };
  t.linear = Ho, t.stepped = Ou, t.bars = Du, t.spline = Hu;
}
const Yu = '.uplot,.uplot *,.uplot *:before,.uplot *:after{box-sizing:border-box}.uplot{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";line-height:1.5;width:min-content}.u-title{text-align:center;font-size:18px;font-weight:700}.u-wrap{position:relative;user-select:none}.u-over,.u-under{position:absolute}.u-under{overflow:hidden}.uplot canvas{display:block;position:relative;width:100%;height:100%}.u-axis{position:absolute}.u-legend{font-size:14px;margin:auto;text-align:center}.u-inline{display:block}.u-inline *{display:inline-block}.u-inline tr{margin-right:16px}.u-legend th{font-weight:600}.u-legend th>*{vertical-align:middle;display:inline-block}.u-legend .u-marker{width:1em;height:1em;margin-right:4px;background-clip:padding-box!important}.u-inline.u-live th:after{content:":";vertical-align:middle}.u-inline:not(.u-live) .u-value{display:none}.u-series>*{padding:4px}.u-series th{cursor:pointer}.u-legend .u-off>*{opacity:.3}.u-select{background:#00000012;position:absolute;pointer-events:none}.u-cursor-x,.u-cursor-y{position:absolute;left:0;top:0;pointer-events:none;will-change:transform}.u-hz .u-cursor-x,.u-vt .u-cursor-y{height:100%;border-right:1px dashed #607D8B}.u-hz .u-cursor-y,.u-vt .u-cursor-x{width:100%;border-bottom:1px dashed #607D8B}.u-cursor-pt{position:absolute;top:0;left:0;border-radius:50%;border:0 solid;pointer-events:none;will-change:transform;background-clip:padding-box!important}.u-axis.u-off,.u-select.u-off,.u-cursor-x.u-off,.u-cursor-y.u-off,.u-cursor-pt.u-off{display:none}', Wo = ["raw", "average", "moving", "median", "envelope"], Vo = 20, Go = 2e3, cl = 100;
function Ir(t) {
  return Wo.includes(t) ? t : "raw";
}
function Fi(t) {
  return typeof t != "number" || !Number.isFinite(t) ? cl : Math.min(Go, Math.max(Vo, Math.round(t)));
}
function Bo(t, e, n, s) {
  const i = Math.min(n.length, s.length);
  if (t === "raw" || i === 0) return { xs: n, cols: [s] };
  const r = Fi(e) / 1e3;
  switch (t) {
    case "average":
      return { xs: n, cols: [Ai(n, s, i, r, "mean")] };
    case "envelope":
      return { xs: n, cols: [Ai(n, s, i, r, "min"), Ai(n, s, i, r, "max")] };
    case "moving":
      return { xs: n, cols: [Ju(n, s, i, r)] };
    case "median":
      return { xs: n, cols: [Zu(n, s, i, r)] };
  }
}
function Ai(t, e, n, s, i) {
  const r = new Array(n);
  let a = 0;
  for (; a < n; ) {
    const h = Math.floor(t[a] / s);
    let f = a, p = 0, g = 1 / 0, d = -1 / 0;
    for (; f < n && Math.floor(t[f] / s) === h; ) {
      const S = e[f];
      p += S, S < g && (g = S), S > d && (d = S), f++;
    }
    const b = i === "mean" ? p / (f - a) : i === "min" ? g : d;
    for (let S = a; S < f; S++) r[S] = b;
    a = f;
  }
  return r;
}
function Ju(t, e, n, s) {
  const i = new Array(n);
  let r = 0, a = 0;
  for (let h = 0; h < n; h++) {
    for (a += e[h]; t[h] - t[r] >= s; ) a -= e[r++];
    i[h] = a / (h - r + 1);
  }
  return i;
}
function Zu(t, e, n, s) {
  const i = new Array(n), r = [], a = (f) => {
    let p = 0, g = r.length;
    for (; p < g; ) {
      const d = p + g >> 1;
      r[d] < f ? p = d + 1 : g = d;
    }
    return p;
  };
  let h = 0;
  for (let f = 0; f < n; f++) {
    for (r.splice(a(e[f]), 0, e[f]); t[f] - t[h] >= s; )
      r.splice(a(e[h]), 1), h++;
    const p = r.length >> 1;
    i[f] = r.length % 2 ? r[p] : (r[p - 1] + r[p]) / 2;
  }
  return i;
}
class Qu extends Ps {
  static styles = [
    jr(Yu),
    qr`
      :host { display: block; position: relative; min-width: 0; }
      .wrap { width: 100%; height: var(--pa-chart-height, 220px); }
      .u-legend { display: none; }
      .readout {
        position: absolute;
        top: 4px;
        inset-inline-end: 8px;
        padding: 1px 6px;
        border-radius: var(--radius-sm, 4px);
        background: var(--bg-surface, #fff);
        border: 1px solid var(--border-color, #ccc);
        color: var(--text-primary);
        font-size: var(--font-size-sm, 12px);
        font-variant-numeric: tabular-nums;
        pointer-events: none;
      }
      .empty {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--text-muted);
        font-size: var(--font-size-sm, 12px);
        pointer-events: none;
        text-align: center;
        padding: var(--space-md, 12px);
      }
    `
  ];
  static properties = {
    buffer: { attribute: !1 },
    version: { type: Number },
    unit: { type: String },
    seconds: { type: Number },
    emptyText: { type: String },
    paused: { type: Boolean },
    filter: { type: String },
    filterMs: { type: Number },
    showRaw: { type: Boolean },
    readout: { state: !0 }
  };
  #e = null;
  #s = 0;
  #t = null;
  /** Last data given to uPlot (the cursor readout looks values up in it). */
  #i = [[], []];
  /** Snapshot shown while paused, so a filter change does not pull in newer samples. */
  #l = null;
  /** Series layout of the current plot: the raw trace is drawn only under a filter. */
  #n = !1;
  constructor() {
    super(), this.buffer = null, this.version = 0, this.unit = "g", this.seconds = 30, this.emptyText = "", this.paused = !1, this.filter = "raw", this.filterMs = cl, this.showRaw = !1, this.readout = "";
  }
  connectedCallback() {
    super.connectedCallback(), this.#t = new ResizeObserver(() => this.#c()), this.#t.observe(this);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.#t?.disconnect(), this.#t = null, this.#s && cancelAnimationFrame(this.#s), this.#s = 0, this.#a();
  }
  /** Rebuilds the chart with the current theme colours. */
  restyle() {
    this.#a(), this.#r(!0);
  }
  updated(e) {
    if (e.has("paused")) {
      const n = this.buffer;
      this.#l = this.paused && n ? { t: n.times(), v: n.values() } : null;
    }
    e.has("seconds") || e.has("unit") || e.has("filter") || e.has("showRaw") ? this.restyle() : e.has("filterMs") ? this.#r(!0) : (e.has("version") || e.has("paused")) && this.#r();
  }
  /** `force`: redraw even while paused (a filter change must show on the frozen trace). */
  #r(e = !1) {
    this.#s || this.paused && !e || (this.#s = requestAnimationFrame(() => {
      this.#s = 0, this.#h();
    }));
  }
  #o(e, n) {
    return getComputedStyle(this).getPropertyValue(e).trim() || n;
  }
  #a() {
    this.#e?.destroy(), this.#e = null;
  }
  #c() {
    const e = this.renderRoot.querySelector(".wrap");
    !e || e.clientWidth === 0 || (this.#e ? this.#e.setSize({ width: e.clientWidth, height: e.clientHeight }) : this.#r());
  }
  /** uPlot series for the current filter: [x, raw?, filtered | lower + upper]. */
  #u(e) {
    const n = [{}];
    return this.#n && n.push({ stroke: this.#o("--text-muted", "#888"), width: 1, points: { show: !1 } }), this.filter === "envelope" ? (n.push({ stroke: this.#o("--cool", "#40c4ff"), width: 1.5, points: { show: !1 } }), n.push({ stroke: this.#o("--heat", "#ff6d00"), width: 1.5, points: { show: !1 } })) : n.push({ stroke: e, width: 1.5, points: { show: !1 } }), n;
  }
  #f(e) {
    const n = this.#o("--accent", "#3b82f6"), s = this.#o("--text-muted", "#888"), i = this.#o("--border-color", "#8884"), r = this.unit === "g" ? "g" : "counts", a = this.unit === "g" ? 2 : 25, h = {
      width: Math.max(e.clientWidth, 200),
      height: Math.max(e.clientHeight, 120),
      legend: { show: !1 },
      cursor: { drag: { x: !1, y: !1 }, points: { size: 6 } },
      scales: {
        x: { time: !1, range: () => [-this.seconds, 0] },
        y: {
          range: (f, p, g) => {
            if (!Number.isFinite(p) || !Number.isFinite(g)) return [-1, 1];
            const d = Math.max(g - p, a), b = (g + p) / 2;
            return [b - d * 0.6, b + d * 0.6];
          }
        }
      },
      axes: [
        {
          stroke: s,
          grid: { stroke: i, width: 1 },
          ticks: { stroke: i },
          values: (f, p) => p.map((g) => `${g}s`)
        },
        {
          stroke: s,
          grid: { stroke: i, width: 1 },
          ticks: { stroke: i },
          size: 56,
          label: r,
          labelSize: 14
        }
      ],
      series: this.#u(n),
      hooks: {
        setCursor: [
          (f) => {
            const p = f.cursor.idx;
            if (p == null) {
              this.readout = "";
              return;
            }
            const g = this.unit === "g" ? 2 : 0, d = this.#n ? 2 : 1, S = this.#i.slice(d).map(($) => $[p]);
            this.readout = S.some(($) => $ === void 0) ? "" : `${S.map(($) => $.toFixed(g)).join(" … ")} ${r}`;
          }
        ]
      }
    };
    return new Ue(h, this.#i, e);
  }
  #h() {
    const e = this.renderRoot.querySelector(".wrap"), n = this.buffer;
    if (!e || !n) return;
    const s = this.#l?.t ?? n.times(), i = this.#l?.v ?? n.values(), r = s[s.length - 1] ?? 0, a = s.map((f) => f - r);
    this.#n = this.showRaw && this.filter !== "raw";
    const h = Bo(this.filter, this.filterMs, s, i).cols;
    if (this.#i = [a, ...this.#n ? [i] : [], ...h], !this.#e) {
      if (e.clientWidth === 0) return;
      this.#e = this.#f(e);
      return;
    }
    this.#e.setData(this.#i);
  }
  render() {
    const e = !this.buffer || this.buffer.length === 0;
    return F`
      <div class="wrap"></div>
      ${this.readout ? F`<span class="readout">${this.readout}</span>` : B}
      ${e && this.emptyText ? F`<div class="empty">${this.emptyText}</div>` : B}
    `;
  }
}
const Ur = ["step_response", "search_overshoot"], Xu = 2, dn = [
  { id: "test", gcode: "TEST_PRESSURE_ADVANCE", applies: !1 },
  { id: "calibrate", gcode: "PA_CALIBRATE", applies: !0 }
];
function en(t) {
  return dn.find((e) => e.id === t) ?? dn[0];
}
const eh = [
  { key: "SLOW_FLOW", type: "number", placeholder: "2", above: 0 },
  { key: "HIGH_FLOW", type: "number", above: 0 },
  { key: "PURGE_LENGTH", type: "number", above: 0 },
  { key: "SEGMENT_TIME", type: "number", placeholder: "0.5", above: 0 },
  { key: "TEST_REPETITIONS", type: "int", placeholder: "10", min: 1 },
  { key: "FILTER_WINDOW", type: "number", placeholder: "0.01", above: 0, max: 0.04 },
  { key: "EXTRUDE_FORCE_SIGN", type: "sign", placeholder: "0" },
  { key: "PA_RANGE", type: "range", placeholder: "0,0.2", method: "search_overshoot" },
  { key: "EXTRUDER", type: "extruder" },
  { key: "FORCE_SENSOR", type: "sensor" }
];
function Ii(t) {
  return eh.filter((e) => !e.method || e.method === t);
}
function mn(t) {
  const e = Number(t);
  return t !== "" && Number.isFinite(e) ? e : null;
}
function th(t, e) {
  const n = mn(e);
  return n === null || t.type === "int" && !Number.isInteger(n) || t.type === "sign" && !(Number.isInteger(n) && n >= -1 && n <= 1) || t.above !== void 0 && !(n > t.above) || t.min !== void 0 && n < t.min || t.max !== void 0 && n > t.max ? null : n;
}
function sh(t) {
  const e = t.split(",").map((i) => i.trim());
  if (e.length !== 2) return null;
  const n = mn(e[0]), s = mn(e[1]);
  return n === null || s === null || n < 0 || s >= Xu || n >= s ? null : [n, s];
}
const nh = /^[^\s"'\r\n]+$/;
function tn(t, e, n) {
  const s = [t.gcode, `METHOD=${e}`], i = [];
  for (const h of Ii(e)) {
    const f = (n[h.key] ?? "").trim();
    if (f !== "")
      if (h.type === "range") {
        const p = sh(f);
        p ? s.push(`${h.key}=${p[0]},${p[1]}`) : i.push(h.key);
      } else if (h.type === "sensor" || h.type === "extruder")
        nh.test(f) ? s.push(`${h.key}=${f}`) : i.push(h.key);
      else {
        const p = th(h, f);
        p === null ? i.push(h.key) : s.push(`${h.key}=${p}`);
      }
  }
  const r = mn((n.SLOW_FLOW ?? "").trim()), a = mn((n.HIGH_FLOW ?? "").trim());
  return r !== null && a !== null && r > 0 && a > 0 && a <= r && (i.includes("HIGH_FLOW") || i.push("HIGH_FLOW")), { script: s.join(" "), invalid: i };
}
const ih = new Set(dn.map((t) => t.gcode));
function lh(t) {
  const e = [];
  for (const n of t.split(/\r?\n/)) {
    const s = n.trim();
    !s || s.startsWith(";") || s.startsWith("#") || e.push(s.split(/\s+/)[0].toUpperCase());
  }
  return e;
}
function Wr(t, e) {
  if (t === null || !Number.isFinite(t) || t < 0) return null;
  const n = Number(t.toFixed(4));
  return e && e !== "extruder" ? `SET_PRESSURE_ADVANCE ADVANCE=${n} EXTRUDER=${e}` : `SET_PRESSURE_ADVANCE ADVANCE=${n}`;
}
const rh = [50, 60];
function Vr(t) {
  return t === 60 ? 60 : 50;
}
const oh = 4, ah = 1e-9;
class ch {
  period;
  #e = [];
  #s = [];
  #t = 0;
  #i = 0;
  #l = null;
  /** Smoothed time between samples, seconds; 0 until two samples were seen. */
  #n = 0;
  #r = !0;
  constructor(e) {
    this.period = 1 / e;
  }
  /** False when the sensor is too slow for the filter: samples then pass through as they are. */
  get active() {
    return this.#r;
  }
  /** Filters one batch (ascending times). */
  process(e) {
    if (e.length === 0) return [];
    for (const s of e) {
      if (this.#l !== null) {
        const i = s.time - this.#l;
        i > 0 && i < 1 && (this.#n = this.#n ? this.#n * 0.9 + i * 0.1 : i);
      }
      this.#l = s.time;
    }
    if (this.#r = this.#n === 0 || this.period / this.#n >= oh, !this.#r)
      return this.#o(), e.slice();
    const n = [];
    for (const s of e) {
      for (this.#e.push(s.time), this.#s.push(s.value), this.#i += s.value; s.time - this.#e[this.#t] >= this.period - ah; ) this.#i -= this.#s[this.#t++];
      n.push({ time: s.time, value: this.#i / (this.#e.length - this.#t) });
    }
    return this.#t > 1024 && (this.#e.splice(0, this.#t), this.#s.splice(0, this.#t), this.#t = 0), n;
  }
  #o() {
    this.#e = [], this.#s = [], this.#t = 0, this.#i = 0;
  }
}
const uh = /^load_cell(_probe)?(\s|$)/i, hh = /^extruder\d*$/i;
function Ko(t) {
  const e = t.trim().split(/\s+/);
  return e[e.length - 1];
}
function fh(t) {
  const e = t.pa_tester, n = {};
  for (const [i, r] of Object.entries(e ?? {}))
    r != null && r !== "" && (n[i] = String(r));
  const s = Object.keys(t);
  return {
    hasPaTester: e !== void 0,
    options: n,
    loadCells: s.filter((i) => uh.test(i)).map((i) => ({ section: i, name: Ko(i) })),
    extruders: s.filter((i) => hh.test(i))
  };
}
function Nn(t, e = "") {
  const n = e || t.options.force_sensor || "";
  return n ? t.loadCells.find((s) => s.section === n || s.name === n) ?? {
    section: n,
    name: Ko(n)
  } : t.loadCells.length === 1 ? t.loadCells[0] : null;
}
async function ph(t) {
  const e = await t.request(
    "printer.objects.query",
    { objects: { configfile: ["settings"] } }
  );
  return fh(e?.status?.configfile?.settings ?? {});
}
function Rn(t) {
  return typeof t == "number" && Number.isFinite(t) ? t : null;
}
function dh(t) {
  const e = t?.data;
  if (!Array.isArray(e)) return { unit: "g", samples: [] };
  let n = !0;
  const s = [];
  for (const a of e) {
    if (!Array.isArray(a)) continue;
    const h = Rn(a[0]);
    if (h === null) continue;
    const f = Rn(a[1]);
    f === null && (n = !1), s.push({ time: h, g: f, counts: Rn(a[2]), tare: Rn(a[3]) ?? 0 });
  }
  const i = n ? "g" : "counts", r = [];
  for (const a of s) {
    const h = i === "g" ? a.g : a.counts === null ? null : a.counts - a.tare;
    h !== null && r.push({ time: a.time, value: h });
  }
  return { unit: i, samples: r };
}
function mh(t, e) {
  if (t.length === 0) return t.slice();
  const n = [];
  let s = t[0].time, i = 0, r = 0, a = s;
  for (const h of t)
    h.time - s >= e && r > 0 && (n.push({ time: a, value: i / r }), s = h.time, i = 0, r = 0), i += h.value, r++, a = h.time;
  return r > 0 && n.push({ time: a, value: i / r }), n;
}
const gh = 0.02;
function vh(t, e, n, s = () => performance.now() / 1e3, i = () => 0) {
  let r = null, a = null, h = null, f = !1;
  const p = () => {
    h || f || (n.onSource("status", "connecting"), h = t.subscribe(
      { [e.section]: ["force_g"] },
      (d) => {
        const b = d?.[e.section]?.force_g;
        typeof b != "number" || !Number.isFinite(b) || (n.onSource("status", "live"), n.onMains?.(!1), n.onSamples([{ time: s(), value: b }], "g"));
      },
      { immediate: !0 }
    ));
  }, g = () => {
    h?.(), h = null;
  };
  return typeof t.klippyStream != "function" ? p() : a = t.klippyStream(
    "load_cell/dump_force",
    { sensor: e.name },
    (d) => {
      const b = dh(d);
      if (!b.samples.length) return;
      let S = b.samples;
      const $ = i();
      $ ? ((!r || r.period !== 1 / $) && (r = new ch($)), S = r.process(S), n.onMains?.(r.active)) : r = null, n.onSamples(mh(S, gh), b.unit);
    },
    (d) => {
      f || (d === "unavailable" ? (n.onSource("stream", "unavailable"), p()) : (g(), n.onSource("stream", d)));
    }
  ), () => {
    f = !0, a?.(), a = null, g();
  };
}
function ul() {
  return {
    running: !1,
    method: null,
    perFlow: [],
    overall: null,
    search: [],
    found: null,
    corrected: null,
    forceSign: null,
    warnings: [],
    error: null,
    value: null
  };
}
const hl = /^(TEST_PRESSURE_ADVANCE|PA_CALIBRATE)\b/i, jo = /^Detected extrude_force_sign=(-?\d+)/, qo = /^WARNING: high_flow is less than 2x slow_flow/, Yo = /^Searching for optimal pressure_advance/, bh = /^PA calibration results:/, _h = /^flow=\s*(-?\d+(?:\.\d+)?)\s+pressure_advance=(-?\d+(?:\.\d+)?)/, wh = /^overall pressure_advance=(-?\d+(?:\.\d+)?)/, yh = /^Failed to detect Pressure Advance value/, Sh = /^Tested pressure_advance=(-?\d+(?:\.\d+)?)\s*->\s*(no overshoot|overshoot)/, xh = /^Search complete:\s*(\d+) tests?, pressure_advance=(-?\d+(?:\.\d+)?)/, $h = /^PA correction: pressure_advance=(-?\d+(?:\.\d+)?)/, Gr = /^WARNING:\s*(.+)$/, Eh = /^Test (\d+): pressure_advance=(-?\d+(?:\.\d+)?)/, Ah = /^(Wait for calculations\.\.|\(accounts for force data filtering\)|Check sensor and filament)/;
function kh(t) {
  const e = Array.isArray(t) ? t : [t], n = [];
  for (const s of e)
    if (typeof s == "string")
      for (const i of s.split(/\r?\n/)) {
        const r = i.trim();
        r && n.push(r);
      }
  return n;
}
function fl(t) {
  return t.startsWith("!!") ? { text: t.replace(/^!!\s*/, ""), error: !0 } : { text: t.replace(/^\/\/\s*/, ""), error: !1 };
}
function Jo(t) {
  const { text: e } = fl(t);
  return hl.test(e) || jo.test(e) || qo.test(e) || Yo.test(e);
}
function Th(t) {
  return hl.test(fl(t).text);
}
function Mh(t) {
  for (let e = t.length - 1; e >= 0; e--)
    if (Th(t[e])) return t.slice(e);
  for (let e = t.length - 1; e >= 0; e--)
    if (Jo(t[e])) return t.slice(e);
  return [];
}
function Rh(t) {
  const e = /\bMETHOD=(step_response|search_overshoot)\b/i.exec(t);
  return e ? e[1].toLowerCase() : null;
}
function Hn(t) {
  const e = ul();
  for (const n of t) {
    const { text: s, error: i } = fl(n);
    if (i) {
      e.error = s, e.running = !1;
      continue;
    }
    if (hl.test(s)) {
      e.running = !0, e.error = null;
      const a = Rh(s);
      a && (e.method = a);
      continue;
    }
    let r;
    if (r = jo.exec(s))
      e.running = !0, e.forceSign = Number(r[1]);
    else if (qo.test(s))
      e.running = !0, e.warnings.push(s.replace(/^WARNING:\s*/, ""));
    else if (Yo.test(s))
      e.running = !0, e.method = "search_overshoot";
    else if (r = Eh.exec(s))
      e.running = !0, e.method = "search_overshoot";
    else if (r = Sh.exec(s))
      e.method = "search_overshoot", e.search.push({ pa: Number(r[1]), overshoot: r[2] === "overshoot" });
    else if (r = xh.exec(s))
      e.method = "search_overshoot", e.found = Number(r[2]), e.value = e.found, e.running = !1;
    else if (r = $h.exec(s))
      e.corrected = Number(r[1]), e.value = e.corrected;
    else if (bh.test(s))
      e.method = "step_response", e.running = !0;
    else if (r = _h.exec(s))
      e.method = "step_response", e.perFlow.push({ flow: Number(r[1]), pa: Number(r[2]) });
    else if (r = wh.exec(s))
      e.method = "step_response", e.overall = Number(r[1]), e.value = e.overall, e.running = !1;
    else if (yh.test(s))
      e.error = s, e.running = !1;
    else if (Gr.test(s))
      e.warnings.push(Gr.exec(s)[1]);
    else if (Ah.test(s))
      continue;
  }
  return e.corrected === null && e.found !== null && (e.value = e.found), e;
}
const Zo = 600;
function Ch() {
  return {
    lines: [],
    result: ul(),
    busy: !1,
    external: !1,
    restored: !1,
    lastLineAt: 0,
    config: null,
    configError: !1
  };
}
const Ui = /* @__PURE__ */ new Map(), Wi = /* @__PURE__ */ new Map();
function cs(t) {
  let e = Ui.get(t);
  return e || (e = Ch(), Ui.set(t, e)), e;
}
function Mt(t, e) {
  Ui.set(t, { ...cs(t), ...e });
  for (const n of Wi.get(t) ?? []) n();
}
function Ph(t, e) {
  let n = Wi.get(t);
  return n || (n = /* @__PURE__ */ new Set(), Wi.set(t, n)), n.add(e), () => n.delete(e);
}
function Nh(t) {
  const e = cs(t);
  Mt(t, {
    busy: !1,
    external: !1,
    result: { ...e.result, running: !1 },
    config: null
  });
}
function Lh(t) {
  Mt(t, {
    lines: [],
    result: { ...ul(), running: !0 },
    busy: !0,
    external: !1
  });
}
function Oh(t, e) {
  const n = cs(t), s = e ? [...n.lines, `!! ${e}`].slice(-300) : n.lines, i = Hn(s);
  Mt(t, { busy: !1, lines: s, result: { ...i, running: !1 } });
}
function Dh(t, e, n = Date.now() / 1e3) {
  const s = cs(t);
  let i = s.lines, r = s.external, a = s.busy || s.result.running;
  for (const f of e)
    !s.busy && Jo(f) && !a && (i = [], r = !0, a = !0), a && (i = [...i, f], !s.busy && !Hn(i).running && (a = !1));
  if (i === s.lines) return;
  i = i.slice(-300);
  const h = Hn(i);
  Mt(t, {
    lines: i,
    result: s.busy ? { ...h, running: !0 } : h,
    external: r && h.running,
    lastLineAt: n
  });
}
function zh(t, e, n = Date.now() / 1e3) {
  const s = cs(t);
  if (s.restored || s.busy || s.lines.length > 0) {
    Mt(t, { restored: !0 });
    return;
  }
  const i = e.flatMap((p) => typeof p.message == "string" ? p.message.split(/\r?\n/) : []), r = Mh(i.map((p) => p.trim()).filter(Boolean)).slice(-300), a = Hn(r), h = Number(e[e.length - 1]?.time ?? 0), f = a.running && n - h < Zo;
  Mt(t, {
    restored: !0,
    lines: r,
    result: { ...a, running: f },
    external: f,
    lastLineAt: h
  });
}
function Hh(t, e = Date.now() / 1e3) {
  const n = cs(t);
  !n.external || n.busy || !n.result.running || e - n.lastLineAt < Zo || Mt(t, { external: !1, result: { ...n.result, running: !1 } });
}
class Fh {
  constructor(e = 30, n = 6e3) {
    this.windowSeconds = e, this.maxPoints = n;
  }
  #e = [];
  #s = [];
  /** Index of the first live point; points before it are waiting to be spliced. */
  #t = 0;
  get length() {
    return this.#e.length - this.#t;
  }
  push(e, n) {
    this.#e.push(e), this.#s.push(n);
    const s = e - this.windowSeconds;
    for (; this.#t < this.#e.length && this.#e[this.#t] < s; ) this.#t++;
    const i = this.length - this.maxPoints;
    i > 0 && (this.#t += i), this.#t > 1024 && this.#t > this.length && (this.#e.splice(0, this.#t), this.#s.splice(0, this.#t), this.#t = 0);
  }
  clear() {
    this.#e = [], this.#s = [], this.#t = 0;
  }
  /** Live times (a copy; uPlot keeps the arrays it is given). */
  times() {
    return this.#e.slice(this.#t);
  }
  values() {
    return this.#s.slice(this.#t);
  }
  last() {
    const e = this.#e.length - 1;
    return e >= this.#t ? { time: this.#e[e], value: this.#s[e] } : null;
  }
  /** Min / max of the live window, null when empty. */
  range() {
    if (this.length === 0) return null;
    let e = 1 / 0, n = -1 / 0;
    for (let s = this.#t; s < this.#s.length; s++) {
      const i = this.#s[s];
      i < e && (e = i), i > n && (n = i);
    }
    return { min: e, max: n };
  }
}
const Ih = 120;
class Uh {
  #e;
  #s = "";
  #t = null;
  #i = [];
  #l = null;
  #n = null;
  /** Live printer status for the Run button (re-read on mount, not kept in run-store). */
  printState = "";
  homedAxes = "";
  activeExtruder = "";
  klippyReady = !0;
  extruders = {};
  paStatus = null;
  // ----- live chart
  buffer = new Fh(Ih, 8e3);
  /** Bumped after every push so the chart element redraws. */
  version = 0;
  chart = { kind: null, state: "connecting", unit: "g", mainsActive: !0 };
  #r = !1;
  #o = "";
  #a = null;
  #c = "";
  #u = 0;
  constructor(e) {
    this.#e = e, e.addController(this);
  }
  get printerId() {
    return this.#s;
  }
  get state() {
    return cs(this.#s);
  }
  get isPrinting() {
    return this.printState === "printing" || this.printState === "paused";
  }
  get isHomed() {
    return this.homedAxes === "xyz";
  }
  get extruder() {
    return this.extruders[this.activeExtruder] ?? null;
  }
  get handle() {
    return this.#t;
  }
  hostConnected() {
    document.addEventListener("visibilitychange", this.#f), this.#h();
  }
  hostUpdate() {
    this.#t || this.#h();
  }
  hostDisconnected() {
    document.removeEventListener("visibilitychange", this.#f), this.#v();
  }
  #f = () => this.#m();
  #h() {
    const e = this.#e.api;
    if (!e || this.#t || !this.#e.isConnected || (this.#i.push(
      e.onPrinterChange(() => {
        this.#v(), this.#h(), this.#e.requestUpdate();
      })
    ), !e.printer.id)) return;
    let n;
    try {
      n = e.moonraker();
    } catch {
      return;
    }
    this.#t = n, this.#s = e.printer.id;
    const s = this.#s;
    this.#i.push(Ph(s, () => this.#e.requestUpdate())), this.#i.push(
      n.subscribe(
        { print_stats: ["state"], toolhead: ["homed_axes", "extruder"], webhooks: ["state"] },
        (i) => {
          i?.print_stats?.state !== void 0 && (this.printState = String(i.print_stats.state)), i?.toolhead?.homed_axes !== void 0 && (this.homedAxes = String(i.toolhead.homed_axes)), i?.toolhead?.extruder !== void 0 && (this.activeExtruder = String(i.toolhead.extruder)), i?.webhooks?.state !== void 0 && (this.klippyReady = i.webhooks.state === "ready"), this.#e.requestUpdate();
        },
        { immediate: !0 }
      )
    ), this.#i.push(
      n.subscribe(
        {
          pa_tester: [
            "last_pressure_advance_test",
            "last_pressure_advance",
            "last_measured_pressure_advance",
            "last_corrected_pressure_advance"
          ]
        },
        (i) => {
          const r = i?.pa_tester;
          if (!r) return;
          const a = this.paStatus;
          this.paStatus = {
            test: typeof r.last_pressure_advance_test == "string" ? r.last_pressure_advance_test : a?.test ?? null,
            pa: typeof r.last_pressure_advance == "number" ? r.last_pressure_advance : a?.pa ?? null,
            measured: Array.isArray(r.last_measured_pressure_advance) ? r.last_measured_pressure_advance.filter((h) => typeof h == "number") : a?.measured ?? [],
            corrected: typeof r.last_corrected_pressure_advance == "number" ? r.last_corrected_pressure_advance : a?.corrected ?? null
          }, this.#e.requestUpdate();
        },
        { immediate: !0 }
      )
    ), this.#i.push(n.onNotify("notify_gcode_response", (i) => Dh(s, kh(i)))), this.#i.push(
      n.onNotify("notify_klippy_ready", () => {
        Nh(s), this.#p();
      })
    ), this.#i.push(n.onNotify("notify_config_changed", () => void this.#p())), this.#n = setInterval(() => Hh(s), 3e4), this.state.config ? this.#b() : this.#p(), this.state.restored || this.#_(), this.#m();
  }
  #v() {
    for (const e of this.#i) e();
    this.#i = [], this.#l?.(), this.#l = null, this.#d(), this.#n && clearInterval(this.#n), this.#n = null, this.#t = null;
  }
  /** Reads the printer config again (the "Check again" button of the not-installed panel). */
  recheck() {
    return this.#p();
  }
  async #p() {
    const e = this.#t, n = this.#s;
    if (e)
      try {
        const s = await ph(e);
        Mt(n, { config: s, configError: !1 }), this.#b(), this.#m();
      } catch {
        Mt(n, { configError: !0 });
      }
  }
  #b() {
    this.#l?.(), this.#l = null;
    const e = this.#t, n = this.state.config?.extruders ?? [];
    if (!e || n.length === 0) return;
    const s = ["temperature", "target", "pressure_advance", "can_extrude"];
    this.#l = e.subscribe(
      Object.fromEntries(n.map((i) => [i, s])),
      (i) => {
        for (const r of n) {
          const a = i?.[r];
          if (!a) continue;
          const h = this.extruders[r] ?? { temperature: null, target: null, pressureAdvance: null, canExtrude: null };
          this.extruders = {
            ...this.extruders,
            [r]: {
              temperature: typeof a.temperature == "number" ? a.temperature : h.temperature,
              target: typeof a.target == "number" ? a.target : h.target,
              pressureAdvance: typeof a.pressure_advance == "number" ? a.pressure_advance : h.pressureAdvance,
              canExtrude: typeof a.can_extrude == "boolean" ? a.can_extrude : h.canExtrude
            }
          };
        }
        this.#e.requestUpdate();
      },
      { immediate: !0 }
    );
  }
  async #_() {
    const e = this.#t, n = this.#s;
    if (e)
      try {
        const s = await e.request(
          "server.gcode_store",
          { count: 300 }
        );
        zh(n, s?.gcode_store ?? []);
      } catch {
        Mt(n, { restored: !0 });
      }
  }
  // ---------------------------------------------------------------- chart
  /** Asks for the trace of the load cell `sensor` (a section name, '' — automatic). */
  setChart(e, n = "") {
    this.#r === e && this.#o === n || (this.#r = e, this.#o = n, this.#m());
  }
  /**
   * Switches the mains filter (`hz` 0 = off). It acts on the incoming stream, so samples
   * already in the buffer keep the old setting: start the trace over rather than mix them.
   */
  setMains(e) {
    e !== this.#u && (this.#u = e, this.buffer.clear(), this.chart = { ...this.chart, mainsActive: !0 }, this.version++, this.#e.requestUpdate());
  }
  clearChart() {
    this.buffer.clear(), this.version++, this.#e.requestUpdate();
  }
  #d() {
    this.#a?.(), this.#a = null, this.#c = "";
  }
  #m() {
    const e = this.#t, n = this.state.config, i = this.#r && !document.hidden && e !== null && n !== null && n ? Nn(n, this.#o) : null, r = i ? `${this.#s}|${i.section}` : "";
    r !== this.#c && (this.#d(), !(!i || !e) && (this.#c = r, this.buffer.clear(), this.chart = { kind: null, state: "connecting", unit: this.chart.unit, mainsActive: !0 }, this.#a = vh(
      e,
      i,
      {
        onSamples: (a, h) => {
          h !== this.chart.unit && (this.buffer.clear(), this.chart = { ...this.chart, unit: h });
          for (const f of a) this.buffer.push(f.time, f.value);
          this.version++, this.#e.requestUpdate();
        },
        onSource: (a, h) => {
          this.chart.kind !== null && this.chart.kind !== a && this.buffer.clear(), this.chart = { ...this.chart, kind: a, state: h }, this.#e.requestUpdate();
        },
        onMains: (a) => {
          a !== this.chart.mainsActive && (this.chart = { ...this.chart, mainsActive: a }, this.#e.requestUpdate());
        }
      },
      void 0,
      () => this.#u
    ), this.#e.requestUpdate()));
  }
  // ------------------------------------------------------------- commands
  /**
   * Sends one command and waits for it. `printer.gcode.script` resolves only
   * when Klipper has finished it, i.e. after the whole measurement and the
   * calculation (minutes); the host proxy has no request timeout. Meanwhile
   * the console lines arrive live.
   */
  async run(e) {
    const n = this.#t, s = this.#s;
    if (!n || this.state.busy) return;
    Lh(s);
    let i;
    try {
      await n.request("printer.gcode.script", { script: e });
    } catch (r) {
      i = r instanceof Error ? r.message : String(r);
    } finally {
      Oh(s, i);
    }
  }
  /** A short command that is not a measurement (G28, SET_PRESSURE_ADVANCE): no run state. */
  async send(e) {
    if (!this.#t) return !1;
    try {
      return await this.#t.request("printer.gcode.script", { script: e }), !0;
    } catch (n) {
      return console.warn("[pa-tester] command failed:", e, n), !1;
    }
  }
}
const Wh = qr`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
    min-width: 0;
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    font-size: var(--font-size-md);
    /* Width-based layout: the page area, not the window, decides (sidebars). */
    container-type: inline-size;
  }

  .panel {
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-width: 0;
  }
  .panel-header {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-sm) var(--space-md);
    border-bottom: 1px solid var(--border-color);
  }
  .panel-title {
    flex: 1;
    min-width: 0;
    font-size: var(--font-size-md);
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .panel-body {
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    min-width: 0;
  }

  .row { display: flex; align-items: center; gap: var(--space-sm); flex-wrap: wrap; }
  .muted { color: var(--text-muted); font-size: var(--font-size-sm); margin: 0; }
  .warn { color: var(--warning); font-size: var(--font-size-sm); margin: 0; }
  .error { color: var(--danger); font-size: var(--font-size-sm); margin: 0; }
  .ok { color: var(--success); font-size: var(--font-size-sm); margin: 0; }
  .mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }

  .chip {
    padding: 1px 8px;
    border-radius: 999px;
    border: 1px solid var(--border-color);
    background: var(--bg-surface-hover);
    color: var(--text-secondary);
    font-size: var(--font-size-sm);
    white-space: nowrap;
  }
  .chip.accent { border-color: var(--accent); color: var(--accent); font-weight: 600; }

  /* Command selector + gallery filters: same look as Calibrations' .sel-btn. */
  .sel-row { display: flex; gap: var(--space-xs); flex-wrap: wrap; }
  .sel-btn {
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-secondary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
  }
  .sel-btn:hover:not(:disabled) { background: var(--bg-surface-hover); }
  .sel-btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .sel-btn.active { background: var(--bg-surface-active); color: var(--accent); border-color: var(--accent); }

  .fields {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    gap: var(--space-sm);
  }
  .field { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
  .field-label { font-size: var(--font-size-sm); color: var(--text-secondary); }
  .field.invalid .field-label { color: var(--danger); }
  input, select {
    min-width: 0;
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
  }
  .field.invalid input { border-color: var(--danger); }
  input.num { inline-size: 7rem; }
  /* checkbox rows and uncaptioned controls sit on the baseline of the captioned fields */
  .check {
    display: inline-flex;
    align-items: center;
    gap: var(--space-xs);
    align-self: flex-end;
    min-height: 32px;
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    cursor: pointer;
  }
  .end { align-self: flex-end; }
  .chip.warn-chip { border-color: var(--warning); color: var(--warning); white-space: normal; }

  .gcode {
    display: block;
    padding: var(--space-xs) var(--space-sm);
    background: var(--bg-surface-hover-no-override, var(--bg-surface-hover));
    border: 1px dashed var(--border-color);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    white-space: pre-wrap;
    word-break: break-all;
    user-select: text;
  }

  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-xs);
    padding: var(--space-xs) var(--space-md);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface-hover);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
    white-space: nowrap;
  }
  .btn:hover:not(:disabled) { background: var(--bg-surface-active); }
  .btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .btn.primary { background: var(--accent); border-color: var(--accent); color: var(--accent-text, #fff); }
  .btn:focus-visible, .sel-btn:focus-visible {
    outline: 2px solid var(--accent-ring, var(--accent));
    outline-offset: 1px;
  }
  .icon-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    width: 28px;
    height: 28px;
    padding: 0;
    border: none;
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-muted);
    cursor: pointer;
    font-size: 15px;
    line-height: 1;
  }
  .icon-btn:hover { background: var(--bg-surface-hover); color: var(--text-primary); }
  .icon-btn.active { background: var(--accent); color: var(--accent-text, #fff); }
  .icon-btn svg { display: block; }

  .spinner {
    width: 12px;
    height: 12px;
    border: 2px solid currentColor;
    border-right-color: transparent;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    flex-shrink: 0;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  .card {
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    padding: var(--space-sm);
    display: flex;
    flex-direction: column;
    gap: var(--space-xs);
  }
  .card h4 { margin: 0; font-size: var(--font-size-sm); font-weight: 600; }

  table { width: 100%; border-collapse: collapse; font-size: var(--font-size-sm); }
  th, td { padding: var(--space-xs) var(--space-sm); text-align: start; border-bottom: 1px solid var(--border-color); }
  th { color: var(--text-muted); font-weight: 500; text-transform: uppercase; letter-spacing: 0.04em; }

  details.log summary { cursor: pointer; color: var(--text-secondary); font-size: var(--font-size-sm); }
  details.log pre {
    margin: var(--space-xs) 0 0;
    max-height: 200px;
    overflow: auto;
    padding: var(--space-sm);
    background: var(--bg-surface-hover);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    white-space: pre-wrap;
    word-break: break-word;
  }
  details.log pre .err { color: var(--danger); }

  /*
   * Help popover: same look as the host's HeaderHelp. It is a [popover] in the
   * top layer (see #placeHelp in pa-tab.ts); the UA style centres popovers
   * (inset: 0; margin: auto), we drop that and set top/left/right from JS.
   */
  .help-menu {
    position: fixed;
    inset: auto;
    margin: 0;
    min-width: min(280px, calc(100vw - 16px));
    max-width: min(380px, calc(100vw - 16px));
    max-height: calc(100vh - 16px);
    overflow-y: auto;
    padding: var(--space-sm);
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-md, 0 4px 12px rgba(0, 0, 0, 0.15));
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
  }
  .help-menu:popover-open { display: flex; flex-direction: column; gap: var(--space-sm); }
  .help-title {
    padding: var(--space-xs) var(--space-sm);
    font-size: var(--font-size-sm);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    color: var(--text-muted);
  }
  .help-body {
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    padding: 0 var(--space-sm) var(--space-xs);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    line-height: 1.5;
  }
  .help-body h4 { margin: var(--space-xs) 0 2px; color: var(--text-primary); font-size: var(--font-size-sm); font-weight: 600; }
  .help-body p { margin: 0; }

  .gcode-row { display: flex; gap: var(--space-sm); align-items: stretch; }
  .gcode-row .gcode { flex: 1; min-width: 0; }
  ol.steps { margin: 0; padding-inline-start: 1.4em; display: flex; flex-direction: column; gap: var(--space-xs); }
  ol.steps li { color: var(--text-secondary); font-size: var(--font-size-sm); }
  ol.steps li .gcode { margin-top: 2px; }
  a { color: var(--accent); }
  .row.end { justify-content: flex-end; }
  b { font-weight: 600; }

  /*
   * Confirmation of PA_CALIBRATE: a native <dialog> opened with showModal()
   * lives in the browser's TOP LAYER. The Calibrations page is a size container
   * (container-type), which makes it the containing block of position:fixed
   * descendants, so a fixed div of ours would be clipped to the page area.
   */
  dialog.confirm {
    padding: 0;
    border: 1px solid var(--border-color);
    border-radius: var(--radius-lg);
    background: var(--bg-surface);
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    max-width: min(460px, 94vw);
  }
  dialog.confirm::backdrop { background: var(--bg-overlay, rgba(0, 0, 0, 0.6)); }
  .confirm-body { display: flex; flex-direction: column; gap: var(--space-sm); padding: var(--space-md); }
  .confirm-body h3 { margin: 0; font-size: var(--font-size-md); }
  .confirm-body p { margin: 0; color: var(--text-secondary); font-size: var(--font-size-sm); }

  @container (max-width: 480px) {
    .panel-body { padding: var(--space-sm); }
    .fields { grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); }
  }
  @media (pointer: coarse) {
    .icon-btn { width: 36px; height: 36px; }
    .sel-btn, .btn, .check, select, input.num { min-height: 36px; }
  }
`, Vh = F`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor"
  stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
  <circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
  <line x1="12" y1="17" x2="12.01" y2="17"></line>
</svg>`, Br = [30, 60, 120], Gh = "https://github.com/dmbutyugin/klipper/tree/generic-cartesian", sn = (t, e = 4) => t == null ? "—" : t.toFixed(e);
class Bh extends Ti {
  static styles = Wh;
  static properties = {
    ...Ti.properties,
    command: { state: !0 },
    method: { state: !0 },
    values: { state: !0 },
    chartOpen: { state: !0 },
    chartSeconds: { state: !0 },
    chartPaused: { state: !0 },
    chartFilter: { state: !0 },
    chartFilterMs: { state: !0 },
    chartRaw: { state: !0 },
    chartMains: { state: !0 },
    chartMainsHz: { state: !0 },
    copied: { state: !0 },
    helpOpen: { state: !0 }
  };
  #e = new Uh(this);
  /** Printer whose settings are loaded into the fields. */
  #s = "";
  #t = null;
  #i = null;
  constructor() {
    super(), this.command = "test", this.method = "step_response", this.values = {}, this.chartOpen = !0, this.chartSeconds = 30, this.chartPaused = !1, this.chartFilter = "raw", this.chartFilterMs = cl, this.chartRaw = !1, this.chartMains = !1, this.chartMainsHz = 50, this.copied = null, this.helpOpen = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.#i = this.api?.onThemeChange(() => this.renderRoot.querySelector("tessera-pa-force-chart")?.restyle()) ?? null;
  }
  willUpdate(e) {
    super.willUpdate(e);
    const n = this.#e.printerId;
    this.api && n && n !== this.#s && (this.#s = n, this.#l()), this.#e.setChart(this.chartOpen && this.#r(), this.values.FORCE_SENSOR ?? ""), this.#e.setMains(this.chartMains ? this.chartMainsHz : 0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.#i?.(), this.#i = null, this.#S(!1), this.#s = "", this.#t && clearTimeout(this.#t);
  }
  #l() {
    const e = this.api.settings, n = e.get("command");
    this.command = dn.some((r) => r.id === n) ? n : "test";
    const s = e.get("method");
    this.method = s && Ur.includes(s) ? s : "step_response", this.values = e.get("values") ?? {}, this.chartOpen = e.get("chartOpen") ?? !0;
    const i = e.get("chartSeconds");
    this.chartSeconds = Br.includes(i) ? i : 30, this.chartFilter = Ir(e.get("chartFilter")), this.chartFilterMs = Fi(e.get("chartFilterMs")), this.chartRaw = e.get("chartRaw") ?? !1, this.chartMains = e.get("chartMains") ?? !1, this.chartMainsHz = Vr(e.get("chartMainsHz"));
  }
  #n(e, n) {
    this.api?.settings.set(e, n);
  }
  #r() {
    const e = this.#e.state.config;
    return !!(e?.hasPaTester && Nn(e, this.values.FORCE_SENSOR ?? ""));
  }
  // ---------------------------------------------------------------- actions
  #o(e) {
    this.command = e, this.#n("command", e);
  }
  #a(e) {
    this.method = e, this.#n("method", e);
  }
  #c(e, n) {
    this.values = { ...this.values, [e]: n }, this.#n("values", this.values);
  }
  #u() {
    this.chartOpen = !this.chartOpen, this.#n("chartOpen", this.chartOpen);
  }
  #f(e) {
    this.chartSeconds = e, this.#n("chartSeconds", e);
  }
  #h(e) {
    this.chartFilter = e, this.#n("chartFilter", e);
  }
  #v(e) {
    Number.isFinite(e) && (this.chartFilterMs = Fi(e), this.#n("chartFilterMs", this.chartFilterMs));
  }
  #p(e) {
    this.chartRaw = e, this.#n("chartRaw", e);
  }
  #b(e) {
    this.chartMains = e, this.#n("chartMains", e);
  }
  #_(e) {
    this.chartMainsHz = e, this.#n("chartMainsHz", e);
  }
  /** Memo of the filtered extremes: the tab renders on every batch, the filter should not rerun for that. */
  #d = null;
  /**
   * Min / max of the drawn trace: the raw window, or the filtered curve (for the envelope
   * its lower and upper lines). Null when there is nothing to show.
   */
  #m() {
    const e = this.#e.buffer;
    if (this.chartFilter === "raw") return e.range();
    if (e.length === 0) return null;
    const n = `${this.#e.version}|${this.#e.printerId}|${this.chartFilter}|${this.chartFilterMs}`;
    if (this.#d?.key !== n) {
      const s = Bo(this.chartFilter, this.chartFilterMs, e.times(), e.values()).cols, i = s[0], r = s[s.length - 1];
      let a = 1 / 0, h = -1 / 0;
      for (let f = 0; f < i.length; f++)
        i[f] < a && (a = i[f]), r[f] > h && (h = r[f]);
      this.#d = { key: n, min: a, max: h };
    }
    return this.#d;
  }
  #x(e) {
    return this.t(`patester.chart.filter_${e}`);
  }
  #$() {
    const e = en(this.command), n = tn(e, this.method, this.values);
    n.invalid.length || this.#w() || (e.applies ? this.renderRoot.querySelector("dialog")?.showModal() : this.#e.run(n.script));
  }
  #E() {
    const e = tn(en(this.command), this.method, this.values);
    this.renderRoot.querySelector("dialog")?.close(), !(e.invalid.length || this.#w()) && this.#e.run(e.script);
  }
  async #A() {
    const e = Wr(this.#e.state.result.value, this.#e.activeExtruder || null);
    e && await this.#e.send(e);
  }
  async #y(e, n) {
    try {
      await navigator.clipboard.writeText(e);
    } catch {
      window.prompt(this.t("patester.common.copyManually"), e);
      return;
    }
    this.copied = n, this.#t && clearTimeout(this.#t), this.#t = setTimeout(() => this.copied = null, 1500);
  }
  // ------------------------------------------------------------------ help
  /**
   * The help popover lives in the browser's TOP LAYER (Popover API): our panel
   * clips its content and the Calibrations page is a size container, so a
   * positioned div of ours could not leave the page area. `popover="auto"`
   * brings light dismiss for free; we place it next to the button like the
   * host's HeaderHelp does.
   */
  #g = () => {
    const e = this.renderRoot.querySelector(".help-btn"), n = this.renderRoot.querySelector(".help-menu");
    if (!e || !n) return;
    const s = e.getBoundingClientRect(), i = n.offsetHeight, r = n.offsetWidth, a = window.innerHeight - s.bottom - 4, h = i <= a ? s.bottom + 4 : i <= s.top - 4 ? s.top - 4 - i : Math.max(8, window.innerHeight - i - 8);
    if (n.style.top = `${h}px`, document.documentElement.getAttribute("dir") === "rtl")
      n.style.left = `${Math.min(Math.max(8, s.left), Math.max(8, window.innerWidth - r - 8))}px`, n.style.right = "auto";
    else {
      const f = Math.min(Math.max(8, window.innerWidth - s.right), Math.max(8, window.innerWidth - r - 8));
      n.style.right = `${f}px`, n.style.left = "auto";
    }
  };
  #S(e) {
    window.removeEventListener("resize", this.#g), document.removeEventListener("scroll", this.#g, !0), e && (window.addEventListener("resize", this.#g), document.addEventListener("scroll", this.#g, !0));
  }
  #k(e) {
    this.helpOpen = e.newState === "open", this.helpOpen && this.#g(), this.#S(this.helpOpen);
  }
  /** Why Run is not possible now, or null. Our own requests skip our guard (see guard.ts), so we check here. */
  #w() {
    const e = this.#e, n = e.state.config;
    return e.klippyReady ? e.state.busy || e.state.result.running ? this.t("patester.block.running") : e.isPrinting ? this.t("patester.block.printing") : e.isHomed ? n && !Nn(n, this.values.FORCE_SENSOR ?? "") ? n.loadCells.length === 0 ? this.t("patester.block.noSensor") : this.t("patester.block.ambiguous") : e.extruder?.canExtrude === !1 ? this.t("patester.block.cold") : null : this.t("patester.block.homing") : this.t("patester.block.klippy");
  }
  // ---------------------------------------------------------------- render
  render() {
    const e = this.#e.state;
    return !this.api || !this.#e.printerId ? F`<p class="muted">${this.t("patester.common.noPrinter")}</p>` : e.config ? e.config.hasPaTester ? F`${this.#C()}${this.#L()}${this.#N()}` : this.#T(e.config.loadCells.length > 0) : F`<section class="panel"><div class="panel-body">
        <p class="muted">${e.configError ? this.t("patester.common.configError") : this.t("patester.common.loading")}</p>
      </div></section>`;
  }
  /**
   * No `[pa_tester]` section. The tab is always shown (no `available` export),
   * so this is what the user finds: where the module lives and what to add.
   * The config is re-read on `notify_klippy_ready` / `notify_config_changed`
   * (PaController), and by the button for the impatient.
   */
  #T(e) {
    return F`<section class="panel">
      <div class="panel-header">
        <span class="panel-title">${this.t("patester.install.title")}</span>
        <button type="button" class="btn" @click=${() => void this.#e.recheck()}>${this.t("patester.install.recheck")}</button>
      </div>
      <div class="panel-body">
        <p>${this.t("patester.install.intro")}</p>
        ${e ? B : F`<p class="warn">${this.t("patester.install.noLoadCell")}</p>`}
        <ol class="steps">
          <li>
            ${this.t("patester.install.stepModule")}
            <a href=${Gh} target="_blank" rel="noopener noreferrer">dmbutyugin/klipper (generic-cartesian)</a>
          </li>
          <li>${this.t("patester.install.stepNumpy")}</li>
          <li>
            ${this.t("patester.install.stepConfig")}
            <code class="gcode">[pa_tester]
force_sensor: load_cell
high_flow: 12
purge_length: 30</code>
          </li>
          <li>${this.t("patester.install.stepExtruder")}</li>
          <li>${this.t("patester.install.stepRestart")}</li>
        </ol>
      </div>
    </section>`;
  }
  #M() {
    const e = this.t("patester.help.title");
    return F`
      <button
        class="icon-btn help-btn ${this.helpOpen ? "active" : ""}"
        popovertarget="pa-help"
        title=${e}
        aria-label=${e}
      >${Vh}</button>
      <div id="pa-help" class="help-menu" popover="auto" role="dialog" aria-label=${e} @toggle=${this.#k}>
        <div class="help-title">${e}</div>
        <div class="help-body">
          <h4>${this.t("patester.help.runTitle")}</h4>
          <p>${this.t("patester.help.run")}</p>
          <h4>${this.t("patester.help.applyTitle")}</h4>
          <p>${this.t("patester.help.apply")}</p>
          <h4>${this.t("patester.help.chartTitle")}</h4>
          <p>${this.t("patester.help.chart")}</p>
        </div>
      </div>
    `;
  }
  #R(e) {
    const n = Ii(this.method).find((g) => g.key === e), s = this.#e.state.config, i = this.values[e] ?? "", a = tn(en(this.command), this.method, this.values).invalid.includes(e), h = this.#e.state.busy, f = (g) => this.#c(e, g.target.value);
    let p;
    if (n.type === "sensor" || n.type === "extruder") {
      const g = n.type === "sensor" ? s.loadCells.map((d) => d.section) : s.extruders;
      p = F`<select .value=${i} ?disabled=${h} @change=${f}>
        <option value="">${this.t("patester.common.default")}</option>
        ${g.map((d) => F`<option value=${d} ?selected=${d === i}>${d}</option>`)}
      </select>`;
    } else if (n.type === "sign")
      p = F`<select .value=${i} ?disabled=${h} @change=${f}>
        <option value="">${this.t("patester.common.default")}</option>
        ${["-1", "0", "1"].map((g) => F`<option value=${g} ?selected=${g === i}>${g}</option>`)}
      </select>`;
    else {
      const g = s.options[e.toLowerCase()];
      p = F`<input
        type=${n.type === "range" ? "text" : "number"}
        inputmode="decimal"
        step=${n.type === "int" ? "1" : "any"}
        placeholder=${g ?? n.placeholder ?? "—"}
        .value=${i}
        ?disabled=${h}
        @input=${f}
      />`;
    }
    return F`<label class="field ${a ? "invalid" : ""}" title=${this.t(`patester.param.${e}`)}>
      <span class="field-label mono">${e}</span>
      ${p}
    </label>`;
  }
  #C() {
    const e = this.#e, n = e.state, s = n.result, i = en(this.command), r = tn(i, this.method, this.values), a = this.#w(), h = n.busy || s.running, f = e.extruder?.pressureAdvance ?? null, p = Wr(s.value, e.activeExtruder || null);
    return F`
      <section class="panel">
        <header class="panel-header">
          <span class="panel-title">${this.t("patester.title")}</span>
          ${f !== null ? F`<span class="chip mono" title=${this.t("patester.result.current")}>PA ${sn(f, 4)}</span>` : B}
          ${this.#M()}
        </header>
        <div class="panel-body">
          <div class="sel-row" role="radiogroup" aria-label=${this.t("patester.command.label")}>
            ${dn.map(
      (g) => F`<button
                class="sel-btn ${g.id === this.command ? "active" : ""}"
                role="radio"
                aria-checked=${g.id === this.command}
                ?disabled=${n.busy}
                title=${g.gcode}
                @click=${() => this.#o(g.id)}
              >${this.t(`patester.command.${g.id}`)}</button>`
    )}
          </div>
          <p class="muted">${this.t(`patester.command.${this.command}Hint`)}</p>

          <div class="sel-row" role="radiogroup" aria-label=${this.t("patester.method.label")}>
            ${Ur.map(
      (g) => F`<button
                class="sel-btn ${g === this.method ? "active" : ""}"
                role="radio"
                aria-checked=${g === this.method}
                ?disabled=${n.busy}
                @click=${() => this.#a(g)}
              >${this.t(`patester.method.${g}`)}</button>`
    )}
          </div>
          <p class="muted">${this.t(`patester.method.${this.method}Hint`)}</p>

          <div class="fields">${Ii(this.method).map((g) => this.#R(g.key))}</div>

          ${r.invalid.length ? F`<p class="error">${this.t("patester.block.invalid", { fields: r.invalid.join(", ") })}</p>` : B}
          ${a && !h ? F`<p class="warn">${a}</p>` : B}

          <div class="gcode-row">
            <code class="gcode mono">${r.script}</code>
            <button class="btn" @click=${() => void this.#y(r.script, "gcode")}>
              ${this.copied === "gcode" ? this.t("patester.common.copied") : this.t("patester.common.copy")}
            </button>
          </div>
          <div class="row">
            <button class="btn primary" ?disabled=${!!a || r.invalid.length > 0} @click=${() => this.#$()}>
              ${h ? F`<span class="spinner"></span> ${this.t("patester.run.running")}` : this.t(`patester.run.${this.command}`)}
            </button>
            ${!e.isHomed && e.klippyReady && !h && !e.isPrinting ? F`<button class="btn" @click=${() => void e.send("G28")}>${this.t("patester.run.home")}</button>` : B}
          </div>

          ${h ? F`<p class="row muted">
                <span class="spinner"></span>
                ${n.external ? F`<span class="chip">${this.t("patester.run.external")}</span>` : B}
                ${this.t("patester.run.started")}
              </p>` : B}
          ${s.error ? F`<p class="error">${s.error}</p>` : B}

          ${this.#P(p, h)}

          ${n.lines.length ? F`<details class="log">
                <summary>${this.t("patester.run.log", { count: n.lines.length })}</summary>
                <pre class="mono">${n.lines.map((g) => F`<span class=${g.startsWith("!!") ? "err" : ""}>${g}\n</span>`)}</pre>
              </details>` : B}
        </div>
      </section>
    `;
  }
  #P(e, n) {
    const s = this.#e.state.result, i = this.#e.paStatus;
    return s.perFlow.length || s.search.length || s.overall !== null || s.found !== null ? F`
      <div class="card">
        <h4>${this.t("patester.result.title")}</h4>
        ${s.perFlow.length ? F`<table>
              <thead><tr><th>${this.t("patester.result.flow")}</th><th>${this.t("patester.result.pa")}</th></tr></thead>
              <tbody>${s.perFlow.map(
      (a) => F`<tr><td class="mono">${a.flow.toFixed(2)}</td><td class="mono">${a.pa.toFixed(3)}</td></tr>`
    )}</tbody>
            </table>` : B}
        ${s.search.length ? F`<table>
              <thead><tr><th>${this.t("patester.result.tested")}</th><th></th></tr></thead>
              <tbody>${s.search.map(
      (a) => F`<tr>
                  <td class="mono">${a.pa.toFixed(4)}</td>
                  <td>${a.overshoot ? this.t("patester.result.overshoot") : this.t("patester.result.noOvershoot")}</td>
                </tr>`
    )}</tbody>
            </table>` : B}
        ${s.overall !== null ? F`<p class="ok">${this.t("patester.result.overall")}: <b class="mono">${sn(s.overall, 3)}</b></p>` : B}
        ${s.found !== null ? F`<p class="ok">${this.t("patester.result.found")}: <b class="mono">${sn(s.found)}</b></p>` : B}
        ${s.corrected !== null ? F`<p class="ok">${this.t("patester.result.corrected")}: <b class="mono">${sn(s.corrected)}</b></p>` : B}
        ${s.forceSign !== null ? F`<p class="muted">${this.t("patester.result.forceSign", { sign: s.forceSign })}</p>` : B}
        ${s.warnings.map((a) => F`<p class="warn">${a}</p>`)}
        ${e && !n && this.command === "test" && this.#e.klippyReady ? F`<div class="row">
              <button class="btn" @click=${() => void this.#A()}>${this.t("patester.run.applyMeasured")}</button>
              <button class="btn" @click=${() => void this.#y(e, "apply")}>
                ${this.copied === "apply" ? this.t("patester.common.copied") : this.t("patester.common.copy")}
              </button>
              <code class="mono muted">${e}</code>
            </div>
            <p class="muted">${this.t("patester.run.saveHint")}</p>` : B}
      </div>
    ` : i?.pa !== null && i?.pa !== void 0 ? F`<p class="muted">${this.t("patester.result.lastKlipper", { test: i.test ?? "—", pa: sn(i.pa) })}</p>` : B;
  }
  #N() {
    const e = tn(en(this.command), this.method, this.values);
    return F`<dialog class="confirm" @click=${(n) => n.target === n.currentTarget && n.currentTarget.close()}>
      <div class="confirm-body">
        <h3>${this.t("patester.confirm.title")}</h3>
        <p>${this.t("patester.confirm.body")}</p>
        <code class="gcode mono">${e.script}</code>
        <div class="row end">
          <button class="btn" @click=${(n) => n.currentTarget.closest("dialog").close()}>
            ${this.t("patester.confirm.cancel")}
          </button>
          <button class="btn primary" @click=${() => this.#E()}>${this.t("patester.confirm.ok")}</button>
        </div>
      </div>
    </dialog>`;
  }
  #L() {
    const e = this.#e, n = e.state.config, s = Nn(n, this.values.FORCE_SENSOR ?? ""), i = e.buffer.last(), r = this.#m(), a = e.chart.unit === "g" ? "g" : this.t("patester.chart.counts"), h = e.chart.unit === "g" ? 2 : 0, f = (d) => d === void 0 ? "—" : `${d.toFixed(h)} ${a}`;
    let p = B;
    e.chart.kind === "stream" && e.chart.state === "live" ? p = F`<span class="chip">${this.t("patester.chart.sourceStream")}</span>` : e.chart.kind === "status" && (p = F`<span class="chip" title=${this.t("patester.chart.sourceStatusHint")}>${this.t("patester.chart.sourceStatus")}</span>`);
    let g = this.t("patester.chart.noData");
    return s ? this.chartOpen ? e.chart.state === "connecting" && (g = this.t("patester.chart.connecting")) : g = "" : g = n.loadCells.length ? this.t("patester.block.ambiguous") : this.t("patester.block.noSensor"), F`
      <section class="panel">
        <header class="panel-header">
          <span class="panel-title">${this.t("patester.chart.title")}</span>
          ${s ? F`<span class="chip mono" title=${s.section}>${s.section}</span>` : B}
          ${this.chartOpen ? p : B}
          <button class="btn" @click=${() => this.#u()}>
            ${this.chartOpen ? this.t("patester.chart.hide") : this.t("patester.chart.show")}
          </button>
        </header>
        ${this.chartOpen ? F`<div class="panel-body">
              <div class="row">
                <span class="chip mono">${this.t("patester.chart.now")} ${f(i?.value)}</span>
                <span class="chip mono">${this.t("patester.chart.min")} ${f(r?.min)}</span>
                <span class="chip mono">${this.t("patester.chart.max")} ${f(r?.max)}</span>
              </div>
              <tessera-pa-force-chart
                .buffer=${e.buffer}
                .version=${e.version}
                .unit=${e.chart.unit}
                .seconds=${this.chartSeconds}
                .paused=${this.chartPaused}
                .filter=${this.chartFilter}
                .filterMs=${this.chartFilterMs}
                .showRaw=${this.chartRaw}
                .emptyText=${g}
              ></tessera-pa-force-chart>
              <div class="row">
                <div class="sel-row" role="radiogroup" aria-label=${this.t("patester.chart.window")}>
                  ${Br.map(
      (d) => F`<button
                      class="sel-btn ${d === this.chartSeconds ? "active" : ""}"
                      role="radio"
                      aria-checked=${d === this.chartSeconds}
                      @click=${() => this.#f(d)}
                    >${d} ${this.t("patester.chart.sec")}</button>`
    )}
                </div>
                <button class="btn" @click=${() => this.chartPaused = !this.chartPaused}>
                  ${this.chartPaused ? this.t("patester.chart.resume") : this.t("patester.chart.pause")}
                </button>
                <button class="btn" @click=${() => e.clearChart()}>${this.t("patester.chart.clear")}</button>
              </div>
              <div class="row">
                <label class="field">
                  <span class="field-label">${this.t("patester.chart.filter")}</span>
                  <select @change=${(d) => this.#h(Ir(d.target.value))}>
                    ${Wo.map(
      (d) => F`<option value=${d} ?selected=${d === this.chartFilter}>${this.#x(d)}</option>`
    )}
                  </select>
                </label>
                ${this.chartFilter !== "raw" ? F`<label class="field">
                        <span class="field-label">${this.t("patester.chart.filterMs")}, ${this.t("patester.chart.ms")}</span>
                        <input
                          class="num"
                          type="number"
                          dir="ltr"
                          inputmode="numeric"
                          min=${Vo}
                          max=${Go}
                          step="10"
                          .value=${String(this.chartFilterMs)}
                          @change=${(d) => this.#v(d.target.valueAsNumber)}
                        />
                      </label>
                      <label class="check">
                        <input type="checkbox" .checked=${this.chartRaw} @change=${(d) => this.#p(d.target.checked)} />
                        <span>${this.t("patester.chart.showRaw")}</span>
                      </label>` : B}
                <label class="check">
                  <input type="checkbox" .checked=${this.chartMains} @change=${(d) => this.#b(d.target.checked)} />
                  <span>${this.t("patester.chart.mains")}</span>
                </label>
                ${this.chartMains ? F`<select
                        class="end"
                        aria-label=${this.t("patester.chart.mainsHz")}
                        @change=${(d) => this.#_(Vr(Number(d.target.value)))}
                      >
                        ${rh.map((d) => F`<option value=${d} ?selected=${d === this.chartMainsHz}>${d} ${this.t("patester.chart.hz")}</option>`)}
                      </select>
                      ${e.chart.mainsActive ? B : F`<span class="chip warn-chip end">${this.t("patester.chart.mainsLowRate")}</span>`}` : B}
              </div>
              <p class="muted">${this.t("patester.chart.tare")}</p>
            </div>` : B}
      </section>
    `;
  }
}
const Kh = 3e3;
async function jh(t) {
  const e = Ja();
  if (!e) return null;
  const n = e.moonrakerFor(t);
  try {
    const s = async () => {
      const r = (await n.request("printer.objects.query", {
        objects: { print_stats: ["state"], toolhead: ["homed_axes", "extruder"], configfile: ["settings"] }
      }))?.status ?? {}, a = String(r.toolhead?.extruder ?? "");
      let h = null;
      if (a) {
        const f = r.configfile?.settings ?? {}, p = Number(f[a]?.min_extrude_temp), d = (await n.request("printer.objects.query", {
          objects: { [a]: ["temperature"] }
        }))?.status?.[a]?.temperature;
        Number.isFinite(p) && typeof d == "number" && (h = d < p);
      }
      return {
        printState: String(r.print_stats?.state ?? ""),
        homedAxes: String(r.toolhead?.homed_axes ?? ""),
        cold: h
      };
    };
    return await Promise.race([
      s(),
      new Promise((i) => setTimeout(() => i(null), Kh))
    ]);
  } catch {
    return null;
  }
}
async function Jh(t, e, n) {
  if (t.method !== "printer.gcode.script") return { action: "allow" };
  const s = String(t.params?.script ?? "");
  if (!lh(s).some((r) => ih.has(r))) return { action: "allow" };
  const i = await jh(n.targetPrinterId);
  return i ? i.printState === "printing" || i.printState === "paused" ? { action: "deny", reasonKey: "patester.guard.printing" } : i.homedAxes !== "xyz" ? { action: "deny", reasonKey: "patester.guard.homing" } : i.cold === !0 ? { action: "deny", reasonKey: "patester.guard.cold" } : { action: "allow" } : { action: "allow" };
}
qi("tessera-pa-tester-tab", Bh);
qi("tessera-pa-tester-bridge", Xa);
qi("tessera-pa-force-chart", Qu);
const Zh = { en: Za, ru: Qa };
export {
  Jh as guardPaTester,
  Zh as locales
};
