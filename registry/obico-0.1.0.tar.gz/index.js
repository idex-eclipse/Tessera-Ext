/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const M = globalThis, G = M.ShadowRoot && (M.ShadyCSS === void 0 || M.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, Y = Symbol(), nt = /* @__PURE__ */ new WeakMap();
let At = class {
  constructor(t, e, s) {
    if (this._$cssResult$ = !0, s !== Y) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t, this.t = e;
  }
  get styleSheet() {
    let t = this.o;
    const e = this.t;
    if (G && t === void 0) {
      const s = e !== void 0 && e.length === 1;
      s && (t = nt.get(e)), t === void 0 && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), s && nt.set(e, t));
    }
    return t;
  }
  toString() {
    return this.cssText;
  }
};
const Ut = (r) => new At(typeof r == "string" ? r : r + "", void 0, Y), m = (r, ...t) => {
  const e = r.length === 1 ? r[0] : t.reduce((s, i, n) => s + ((o) => {
    if (o._$cssResult$ === !0) return o.cssText;
    if (typeof o == "number") return o;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + o + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(i) + r[n + 1], r[0]);
  return new At(e, r, Y);
}, Lt = (r, t) => {
  if (G) r.adoptedStyleSheets = t.map((e) => e instanceof CSSStyleSheet ? e : e.styleSheet);
  else for (const e of t) {
    const s = document.createElement("style"), i = M.litNonce;
    i !== void 0 && s.setAttribute("nonce", i), s.textContent = e.cssText, r.appendChild(s);
  }
}, ot = G ? (r) => r : (r) => r instanceof CSSStyleSheet ? ((t) => {
  let e = "";
  for (const s of t.cssRules) e += s.cssText;
  return Ut(e);
})(r) : r;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: zt, defineProperty: It, getOwnPropertyDescriptor: Nt, getOwnPropertyNames: Ft, getOwnPropertySymbols: Mt, getPrototypeOf: Dt } = Object, H = globalThis, at = H.trustedTypes, Ht = at ? at.emptyScript : "", jt = H.reactiveElementPolyfillSupport, P = (r, t) => r, V = { toAttribute(r, t) {
  switch (t) {
    case Boolean:
      r = r ? Ht : null;
      break;
    case Object:
    case Array:
      r = r == null ? r : JSON.stringify(r);
  }
  return r;
}, fromAttribute(r, t) {
  let e = r;
  switch (t) {
    case Boolean:
      e = r !== null;
      break;
    case Number:
      e = r === null ? null : Number(r);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(r);
      } catch {
        e = null;
      }
  }
  return e;
} }, Ot = (r, t) => !zt(r, t), lt = { attribute: !0, type: String, converter: V, reflect: !1, useDefault: !1, hasChanged: Ot };
Symbol.metadata ??= Symbol("metadata"), H.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
let A = class extends HTMLElement {
  static addInitializer(t) {
    this._$Ei(), (this.l ??= []).push(t);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(t, e = lt) {
    if (e.state && (e.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(t) && ((e = Object.create(e)).wrapped = !0), this.elementProperties.set(t, e), !e.noAccessor) {
      const s = Symbol(), i = this.getPropertyDescriptor(t, s, e);
      i !== void 0 && It(this.prototype, t, i);
    }
  }
  static getPropertyDescriptor(t, e, s) {
    const { get: i, set: n } = Nt(this.prototype, t) ?? { get() {
      return this[e];
    }, set(o) {
      this[e] = o;
    } };
    return { get: i, set(o) {
      const l = i?.call(this);
      n?.call(this, o), this.requestUpdate(t, l, s);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(t) {
    return this.elementProperties.get(t) ?? lt;
  }
  static _$Ei() {
    if (this.hasOwnProperty(P("elementProperties"))) return;
    const t = Dt(this);
    t.finalize(), t.l !== void 0 && (this.l = [...t.l]), this.elementProperties = new Map(t.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(P("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(P("properties"))) {
      const e = this.properties, s = [...Ft(e), ...Mt(e)];
      for (const i of s) this.createProperty(i, e[i]);
    }
    const t = this[Symbol.metadata];
    if (t !== null) {
      const e = litPropertyMetadata.get(t);
      if (e !== void 0) for (const [s, i] of e) this.elementProperties.set(s, i);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [e, s] of this.elementProperties) {
      const i = this._$Eu(e, s);
      i !== void 0 && this._$Eh.set(i, e);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(t) {
    const e = [];
    if (Array.isArray(t)) {
      const s = new Set(t.flat(1 / 0).reverse());
      for (const i of s) e.unshift(ot(i));
    } else t !== void 0 && e.push(ot(t));
    return e;
  }
  static _$Eu(t, e) {
    const s = e.attribute;
    return s === !1 ? void 0 : typeof s == "string" ? s : typeof t == "string" ? t.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise((t) => this.enableUpdating = t), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((t) => t(this));
  }
  addController(t) {
    (this._$EO ??= /* @__PURE__ */ new Set()).add(t), this.renderRoot !== void 0 && this.isConnected && t.hostConnected?.();
  }
  removeController(t) {
    this._$EO?.delete(t);
  }
  _$E_() {
    const t = /* @__PURE__ */ new Map(), e = this.constructor.elementProperties;
    for (const s of e.keys()) this.hasOwnProperty(s) && (t.set(s, this[s]), delete this[s]);
    t.size > 0 && (this._$Ep = t);
  }
  createRenderRoot() {
    const t = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return Lt(t, this.constructor.elementStyles), t;
  }
  connectedCallback() {
    this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$EO?.forEach((t) => t.hostConnected?.());
  }
  enableUpdating(t) {
  }
  disconnectedCallback() {
    this._$EO?.forEach((t) => t.hostDisconnected?.());
  }
  attributeChangedCallback(t, e, s) {
    this._$AK(t, s);
  }
  _$ET(t, e) {
    const s = this.constructor.elementProperties.get(t), i = this.constructor._$Eu(t, s);
    if (i !== void 0 && s.reflect === !0) {
      const n = (s.converter?.toAttribute !== void 0 ? s.converter : V).toAttribute(e, s.type);
      this._$Em = t, n == null ? this.removeAttribute(i) : this.setAttribute(i, n), this._$Em = null;
    }
  }
  _$AK(t, e) {
    const s = this.constructor, i = s._$Eh.get(t);
    if (i !== void 0 && this._$Em !== i) {
      const n = s.getPropertyOptions(i), o = typeof n.converter == "function" ? { fromAttribute: n.converter } : n.converter?.fromAttribute !== void 0 ? n.converter : V;
      this._$Em = i;
      const l = o.fromAttribute(e, n.type);
      this[i] = l ?? this._$Ej?.get(i) ?? l, this._$Em = null;
    }
  }
  requestUpdate(t, e, s, i = !1, n) {
    if (t !== void 0) {
      const o = this.constructor;
      if (i === !1 && (n = this[t]), s ??= o.getPropertyOptions(t), !((s.hasChanged ?? Ot)(n, e) || s.useDefault && s.reflect && n === this._$Ej?.get(t) && !this.hasAttribute(o._$Eu(t, s)))) return;
      this.C(t, e, s);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(t, e, { useDefault: s, reflect: i, wrapped: n }, o) {
    s && !(this._$Ej ??= /* @__PURE__ */ new Map()).has(t) && (this._$Ej.set(t, o ?? e ?? this[t]), n !== !0 || o !== void 0) || (this._$AL.has(t) || (this.hasUpdated || s || (e = void 0), this._$AL.set(t, e)), i === !0 && this._$Em !== t && (this._$Eq ??= /* @__PURE__ */ new Set()).add(t));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (e) {
      Promise.reject(e);
    }
    const t = this.scheduleUpdate();
    return t != null && await t, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
        for (const [i, n] of this._$Ep) this[i] = n;
        this._$Ep = void 0;
      }
      const s = this.constructor.elementProperties;
      if (s.size > 0) for (const [i, n] of s) {
        const { wrapped: o } = n, l = this[i];
        o !== !0 || this._$AL.has(i) || l === void 0 || this.C(i, void 0, n, l);
      }
    }
    let t = !1;
    const e = this._$AL;
    try {
      t = this.shouldUpdate(e), t ? (this.willUpdate(e), this._$EO?.forEach((s) => s.hostUpdate?.()), this.update(e)) : this._$EM();
    } catch (s) {
      throw t = !1, this._$EM(), s;
    }
    t && this._$AE(e);
  }
  willUpdate(t) {
  }
  _$AE(t) {
    this._$EO?.forEach((e) => e.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(t) {
    return !0;
  }
  update(t) {
    this._$Eq &&= this._$Eq.forEach((e) => this._$ET(e, this[e])), this._$EM();
  }
  updated(t) {
  }
  firstUpdated(t) {
  }
};
A.elementStyles = [], A.shadowRootOptions = { mode: "open" }, A[P("elementProperties")] = /* @__PURE__ */ new Map(), A[P("finalized")] = /* @__PURE__ */ new Map(), jt?.({ ReactiveElement: A }), (H.reactiveElementVersions ??= []).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const J = globalThis, ct = (r) => r, D = J.trustedTypes, ht = D ? D.createPolicy("lit-html", { createHTML: (r) => r }) : void 0, Tt = "$lit$", $ = `lit$${Math.random().toFixed(9).slice(2)}$`, Et = "?" + $, Bt = `<${Et}>`, w = document, L = () => w.createComment(""), z = (r) => r === null || typeof r != "object" && typeof r != "function", X = Array.isArray, Wt = (r) => X(r) || typeof r?.[Symbol.iterator] == "function", W = `[ 	
\f\r]`, S = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, dt = /-->/g, pt = />/g, k = RegExp(`>|${W}(?:([^\\s"'>=/]+)(${W}*=${W}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), ut = /'/g, ft = /"/g, St = /^(?:script|style|textarea|title)$/i, qt = (r) => (t, ...e) => ({ _$litType$: r, strings: t, values: e }), a = qt(1), O = Symbol.for("lit-noChange"), h = Symbol.for("lit-nothing"), bt = /* @__PURE__ */ new WeakMap(), _ = w.createTreeWalker(w, 129);
function Ct(r, t) {
  if (!X(r) || !r.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return ht !== void 0 ? ht.createHTML(t) : t;
}
const Kt = (r, t) => {
  const e = r.length - 1, s = [];
  let i, n = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", o = S;
  for (let l = 0; l < e; l++) {
    const c = r[l];
    let d, u, p = -1, f = 0;
    for (; f < c.length && (o.lastIndex = f, u = o.exec(c), u !== null); ) f = o.lastIndex, o === S ? u[1] === "!--" ? o = dt : u[1] !== void 0 ? o = pt : u[2] !== void 0 ? (St.test(u[2]) && (i = RegExp("</" + u[2], "g")), o = k) : u[3] !== void 0 && (o = k) : o === k ? u[0] === ">" ? (o = i ?? S, p = -1) : u[1] === void 0 ? p = -2 : (p = o.lastIndex - u[2].length, d = u[1], o = u[3] === void 0 ? k : u[3] === '"' ? ft : ut) : o === ft || o === ut ? o = k : o === dt || o === pt ? o = S : (o = k, i = void 0);
    const v = o === k && r[l + 1].startsWith("/>") ? " " : "";
    n += o === S ? c + Bt : p >= 0 ? (s.push(d), c.slice(0, p) + Tt + c.slice(p) + $ + v) : c + $ + (p === -2 ? l : v);
  }
  return [Ct(r, n + (r[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), s];
};
class I {
  constructor({ strings: t, _$litType$: e }, s) {
    let i;
    this.parts = [];
    let n = 0, o = 0;
    const l = t.length - 1, c = this.parts, [d, u] = Kt(t, e);
    if (this.el = I.createElement(d, s), _.currentNode = this.el.content, e === 2 || e === 3) {
      const p = this.el.content.firstChild;
      p.replaceWith(...p.childNodes);
    }
    for (; (i = _.nextNode()) !== null && c.length < l; ) {
      if (i.nodeType === 1) {
        if (i.hasAttributes()) for (const p of i.getAttributeNames()) if (p.endsWith(Tt)) {
          const f = u[o++], v = i.getAttribute(p).split($), F = /([.?@])?(.*)/.exec(f);
          c.push({ type: 1, index: n, name: F[2], strings: v, ctor: F[1] === "." ? Zt : F[1] === "?" ? Gt : F[1] === "@" ? Yt : j }), i.removeAttribute(p);
        } else p.startsWith($) && (c.push({ type: 6, index: n }), i.removeAttribute(p));
        if (St.test(i.tagName)) {
          const p = i.textContent.split($), f = p.length - 1;
          if (f > 0) {
            i.textContent = D ? D.emptyScript : "";
            for (let v = 0; v < f; v++) i.append(p[v], L()), _.nextNode(), c.push({ type: 2, index: ++n });
            i.append(p[f], L());
          }
        }
      } else if (i.nodeType === 8) if (i.data === Et) c.push({ type: 2, index: n });
      else {
        let p = -1;
        for (; (p = i.data.indexOf($, p + 1)) !== -1; ) c.push({ type: 7, index: n }), p += $.length - 1;
      }
      n++;
    }
  }
  static createElement(t, e) {
    const s = w.createElement("template");
    return s.innerHTML = t, s;
  }
}
function T(r, t, e = r, s) {
  if (t === O) return t;
  let i = s !== void 0 ? e._$Co?.[s] : e._$Cl;
  const n = z(t) ? void 0 : t._$litDirective$;
  return i?.constructor !== n && (i?._$AO?.(!1), n === void 0 ? i = void 0 : (i = new n(r), i._$AT(r, e, s)), s !== void 0 ? (e._$Co ??= [])[s] = i : e._$Cl = i), i !== void 0 && (t = T(r, i._$AS(r, t.values), i, s)), t;
}
class Vt {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: s } = this._$AD, i = (t?.creationScope ?? w).importNode(e, !0);
    _.currentNode = i;
    let n = _.nextNode(), o = 0, l = 0, c = s[0];
    for (; c !== void 0; ) {
      if (o === c.index) {
        let d;
        c.type === 2 ? d = new N(n, n.nextSibling, this, t) : c.type === 1 ? d = new c.ctor(n, c.name, c.strings, this, t) : c.type === 6 && (d = new Jt(n, this, t)), this._$AV.push(d), c = s[++l];
      }
      o !== c?.index && (n = _.nextNode(), o++);
    }
    return _.currentNode = w, i;
  }
  p(t) {
    let e = 0;
    for (const s of this._$AV) s !== void 0 && (s.strings !== void 0 ? (s._$AI(t, s, e), e += s.strings.length - 2) : s._$AI(t[e])), e++;
  }
}
class N {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(t, e, s, i) {
    this.type = 2, this._$AH = h, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = s, this.options = i, this._$Cv = i?.isConnected ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && t?.nodeType === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = T(this, t, e), z(t) ? t === h || t == null || t === "" ? (this._$AH !== h && this._$AR(), this._$AH = h) : t !== this._$AH && t !== O && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : Wt(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== h && z(this._$AH) ? this._$AA.nextSibling.data = t : this.T(w.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    const { values: e, _$litType$: s } = t, i = typeof s == "number" ? this._$AC(t) : (s.el === void 0 && (s.el = I.createElement(Ct(s.h, s.h[0]), this.options)), s);
    if (this._$AH?._$AD === i) this._$AH.p(e);
    else {
      const n = new Vt(i, this), o = n.u(this.options);
      n.p(e), this.T(o), this._$AH = n;
    }
  }
  _$AC(t) {
    let e = bt.get(t.strings);
    return e === void 0 && bt.set(t.strings, e = new I(t)), e;
  }
  k(t) {
    X(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let s, i = 0;
    for (const n of t) i === e.length ? e.push(s = new N(this.O(L()), this.O(L()), this, this.options)) : s = e[i], s._$AI(n), i++;
    i < e.length && (this._$AR(s && s._$AB.nextSibling, i), e.length = i);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    for (this._$AP?.(!1, !0, e); t !== this._$AB; ) {
      const s = ct(t).nextSibling;
      ct(t).remove(), t = s;
    }
  }
  setConnected(t) {
    this._$AM === void 0 && (this._$Cv = t, this._$AP?.(t));
  }
}
class j {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, s, i, n) {
    this.type = 1, this._$AH = h, this._$AN = void 0, this.element = t, this.name = e, this._$AM = i, this.options = n, s.length > 2 || s[0] !== "" || s[1] !== "" ? (this._$AH = Array(s.length - 1).fill(new String()), this.strings = s) : this._$AH = h;
  }
  _$AI(t, e = this, s, i) {
    const n = this.strings;
    let o = !1;
    if (n === void 0) t = T(this, t, e, 0), o = !z(t) || t !== this._$AH && t !== O, o && (this._$AH = t);
    else {
      const l = t;
      let c, d;
      for (t = n[0], c = 0; c < n.length - 1; c++) d = T(this, l[s + c], e, c), d === O && (d = this._$AH[c]), o ||= !z(d) || d !== this._$AH[c], d === h ? t = h : t !== h && (t += (d ?? "") + n[c + 1]), this._$AH[c] = d;
    }
    o && !i && this.j(t);
  }
  j(t) {
    t === h ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}
class Zt extends j {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === h ? void 0 : t;
  }
}
class Gt extends j {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== h);
  }
}
class Yt extends j {
  constructor(t, e, s, i, n) {
    super(t, e, s, i, n), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = T(this, t, e, 0) ?? h) === O) return;
    const s = this._$AH, i = t === h && s !== h || t.capture !== s.capture || t.once !== s.once || t.passive !== s.passive, n = t !== h && (s === h || i);
    i && this.element.removeEventListener(this.name, this, s), n && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, t) : this._$AH.handleEvent(t);
  }
}
class Jt {
  constructor(t, e, s) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = s;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    T(this, t);
  }
}
const Xt = J.litHtmlPolyfillSupport;
Xt?.(I, N), (J.litHtmlVersions ??= []).push("3.3.3");
const Qt = (r, t, e) => {
  const s = e?.renderBefore ?? t;
  let i = s._$litPart$;
  if (i === void 0) {
    const n = e?.renderBefore ?? null;
    s._$litPart$ = i = new N(t.insertBefore(L(), n), n, void 0, e ?? {});
  }
  return i._$AI(r), i;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Q = globalThis;
class R extends A {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    const t = super.createRenderRoot();
    return this.renderOptions.renderBefore ??= t.firstChild, t;
  }
  update(t) {
    const e = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = Qt(e, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return O;
  }
}
R._$litElement$ = !0, R.finalized = !0, Q.litElementHydrateSupport?.({ LitElement: R });
const te = Q.litElementPolyfillSupport;
te?.({ LitElement: R });
(Q.litElementVersions ??= []).push("4.2.2");
function tt(r) {
  return r >= 0.67 ? "failing" : r >= 0.33 ? "fishy" : "good";
}
function ee(r) {
  return !!r?.current_print;
}
function E(r) {
  if (!r?.alerted_at || r.alert_muted_at) return !1;
  const t = Date.parse(r.alerted_at), e = r.alert_acknowledged_at ? Date.parse(r.alert_acknowledged_at) : 0;
  return t > e;
}
function se(r) {
  return `${r.id}@${r.alerted_at ?? ""}`;
}
const ie = {
  "AI failure detection is disabled": "obico.reason.disabled",
  "You have run out of AI Detection Hours": "obico.reason.noHours",
  "Printer is not actively printing": "obico.reason.notPrinting",
  "Alerts are muted for current print": "obico.reason.muted"
};
function re(r) {
  return r ? ie[r] ?? null : null;
}
function mt(r, t) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: t, year: "numeric", month: "2-digit", day: "2-digit" }).format(r);
}
function ne(r, t, e) {
  const s = r === "week" ? 6 : r === "month" ? 29 : 364, i = new Date(t.getTime() - s * 24 * 3600 * 1e3);
  return {
    groupBy: r === "year" ? "month" : "day",
    timeZone: e,
    from: mt(i, e),
    to: mt(t, e)
  };
}
function oe(r) {
  const t = { alerted: 0, failures: 0, falseAlarms: 0, unanswered: 0 };
  for (const e of r)
    e.alerted_at && (t.alerted++, e.alert_overwrite === "FAILED" ? t.failures++ : e.alert_overwrite === "NOT_FAILED" ? t.falseAlarms++ : t.unanswered++);
  return t;
}
function ae(r) {
  if (r.length === 0) return "";
  const t = r[0].t, e = Math.max(1, r[r.length - 1].t - t);
  return r.map((s) => `${((s.t - t) / e * 100).toFixed(1)},${(30 - Math.min(1, Math.max(0, s.p)) * 30).toFixed(1)}`).join(" ");
}
const U = "obico";
class Z extends Error {
  constructor(t, e) {
    super(t), this.status = e, this.name = "ObicoHttpError";
  }
}
const le = ["ERROR", "WARNING", "SUCCESS", "INFO"], ce = [
  "STARTED",
  "ENDED",
  "PAUSED",
  "RESUMED",
  "FAILURE_ALERTED",
  "ALERT_MUTED",
  "ALERT_UNMUTED",
  "FILAMENT_CHANGE",
  "PRINTER_ERROR"
];
function C(r) {
  const t = new URLSearchParams();
  for (const [e, s] of Object.entries(r))
    if (Array.isArray(s)) for (const i of s) t.append(e, i);
    else t.append(e, String(s));
  return t.toString();
}
class he {
  constructor(t) {
    this.services = t;
  }
  async #t(t, e) {
    const s = await this.services.fetch(U, t, {
      method: e?.method ?? "GET",
      headers: e?.body === void 0 ? { Accept: "application/json" } : { Accept: "application/json", "Content-Type": "application/json" },
      body: e?.body === void 0 ? void 0 : JSON.stringify(e.body)
    });
    if (!s.ok) {
      let i = "";
      try {
        const n = await s.json();
        typeof n.detail == "string" && (i = n.detail);
      } catch {
      }
      throw new Z(i || `Obico answered HTTP ${s.status}`, s.status);
    }
    return await s.json();
  }
  /** All printers of the token's user: one request serves every Tessera printer. */
  printers() {
    return this.#t("api/v1/printers/");
  }
  patchPrinter(t, e) {
    return this.#t(`api/v1/printers/${t}/`, { method: "PATCH", body: e });
  }
  /**
   * "It was / was not a failure" for the current alert. It only records the verdict: pausing,
   * resuming and cancelling go through Moonraker, so Tessera's guards see them.
   */
  acknowledge(t, e) {
    return this.#t(`api/v1/printers/${t}/acknowledge_alert/?${C({ alert_overwrite: e })}`, { method: "POST" });
  }
  /** Stops (or resumes) failure detection for the rest of the current print. */
  mute(t, e = !0) {
    return this.#t(`api/v1/printers/${t}/mute_current_print/?${C({ mute_alert: e ? "true" : "false" })}`, {
      method: "POST"
    });
  }
  /**
   * The latest events of the user's printers, newest first. The endpoint has no printer
   * filter, so the caller filters by `printer`.
   */
  events(t = 50) {
    return this.#t(
      `api/v1/printer_events/?${C({
        "filter_by_classes[]": le,
        "filter_by_types[]": ce,
        start: 0,
        limit: t
      })}`
    );
  }
  /** Totals of a period; dates are `YYYY-MM-DD` in `timeZone`. */
  stats(t, e) {
    return this.#t(
      `api/v1/prints/stats/?${C({
        group_by: t.groupBy,
        timezone: t.timeZone,
        from_date: t.from,
        to_date: t.to,
        "filter_by_printer_ids[]": e.map(String)
      })}`
    );
  }
  /** Prints started in a period, newest first, at most `max` (pages of 100). */
  async prints(t, e, s = 500) {
    const i = [];
    for (; i.length < s; ) {
      const n = await this.#t(
        `api/v1/prints/?${C({
          timezone: t.timeZone,
          from_date: t.from,
          to_date: t.to,
          "filter_by_printer_ids[]": e.map(String),
          sorting: "date_desc",
          start: i.length,
          limit: 100
        })}`
      );
      if (i.push(...n), n.length < 100) break;
    }
    return i;
  }
  /**
   * The latest webcam snapshot as an object URL (revoke it when replaced). The server
   * returns a signed absolute URL built from its own site domain, which may not be the
   * address the proxy uses, so only its path and query are taken.
   */
  async image(t) {
    const e = new URL(t), s = await this.services.fetch(U, `${e.pathname.replace(/^\/+/, "")}${e.search}`);
    if (!s.ok) throw new Z(`Obico answered HTTP ${s.status}`, s.status);
    return URL.createObjectURL(await s.blob());
  }
}
const de = 1e4, gt = 6e4, pe = 5 * 6e4, vt = 2e3;
function $t(r) {
  return r instanceof Error && r.name === "ServiceError";
}
class ue {
  client;
  status = "unknown";
  /** Why the last request failed, '' when it did not. */
  error = "";
  /** Saved address of the service, null when not configured. */
  url = null;
  hasSecret = !1;
  /** Printers of the account from the last poll, by Obico id. */
  printers = /* @__PURE__ */ new Map();
  /** Tessera printer id → Obico printer id; null = the agent there is not linked. */
  links = /* @__PURE__ */ new Map();
  lastPoll = 0;
  #t;
  #s = /* @__PURE__ */ new Set();
  #i = null;
  #e = 0;
  /** Failure probability over the current print, per Obico printer. */
  #r = /* @__PURE__ */ new Map();
  /** Alert keys the user closed with "Later" in this session. */
  #n = /* @__PURE__ */ new Set();
  constructor(t) {
    this.#t = t, this.client = new he(t.services), t.onPrintersChange(() => {
      this.#e = 0, this.refresh();
    }), this.refresh();
  }
  subscribe(t) {
    return this.#s.add(t), () => this.#s.delete(t);
  }
  #o() {
    for (const t of this.#s) t();
  }
  /** The Obico printer of a Tessera printer, null when unknown or not in this account. */
  printerFor(t) {
    const e = this.links.get(t);
    return e == null ? null : this.printers.get(e) ?? null;
  }
  /** The Obico id of a Tessera printer: undefined = not read yet, null = not linked. */
  obicoIdFor(t) {
    return this.links.get(t);
  }
  samples(t) {
    return this.#r.get(t)?.samples ?? [];
  }
  /** Unanswered alerts of the Tessera printers, oldest first, without the dismissed ones. */
  pendingAlerts() {
    const t = [];
    for (const [e, s] of this.links) {
      const i = s == null ? null : this.printers.get(s);
      if (!i?.current_print || !E(i.current_print)) continue;
      const n = se(i.current_print);
      this.#n.has(n) || t.push({ key: n, tesseraId: e, printer: i });
    }
    return t.sort((e, s) => Date.parse(e.printer.current_print.alerted_at) - Date.parse(s.printer.current_print.alerted_at));
  }
  /** "Later": the alert stays unanswered on the server, but this page stops asking. */
  dismiss(t) {
    this.#n.add(t), this.#o();
  }
  /** Reads the service config, then polls. Called on start, after a config change and by "retry". */
  async refresh() {
    try {
      const t = await this.#t.services.status(U);
      if (this.url = t.url, this.hasSecret = t.hasSecret, !t.configured) {
        this.status = "unconfigured", this.printers.clear(), this.#a(null), this.#o();
        return;
      }
    } catch (t) {
      this.#l(t);
      return;
    }
    await this.poll();
  }
  /** One poll: links when stale, then the printers of the account. */
  async poll() {
    Date.now() - this.#e > pe && await this.#c();
    try {
      const t = await this.client.printers();
      this.printers = new Map(t.map((e) => [e.id, e])), this.status = "ready", this.error = "", this.lastPoll = Date.now(), this.#d(), [...this.links.values()].some((e) => e != null && !this.printers.has(e)) && (this.#e = 0);
    } catch (t) {
      this.#l(t);
      return;
    }
    this.#o(), this.#a(this.#h() ? de : gt);
  }
  /** Saves the address and the token (omitted: keep the saved one), then reconnects. */
  async configure(t, e) {
    await this.#t.services.configure(U, e === void 0 ? { url: t } : { url: t, secret: e }), await this.refresh();
  }
  async forget() {
    await this.#t.services.remove(U), await this.refresh();
  }
  /** Runs a command against the server and polls at once, so every view shows its effect. */
  async run(t) {
    await t(this.client), await this.poll();
  }
  #l(t) {
    $t(t) && t.unavailable ? (this.status = "unavailable", this.#a(null)) : $t(t) && t.status === 409 ? (this.status = "unconfigured", this.#a(null)) : (this.status = "error", this.#a(gt)), t instanceof Z && (t.status === 401 || t.status === 403) ? this.error = "obico.api.tokenRejected" : this.error = t instanceof Error ? t.message : String(t), this.#o();
  }
  #a(t) {
    this.#i && clearTimeout(this.#i), this.#i = t === null ? null : setTimeout(() => void this.poll(), t);
  }
  #h() {
    for (const t of this.links.values()) if (t != null && ee(this.printers.get(t))) return !0;
    return !1;
  }
  /** Reads `obico/printer_id` from the Moonraker DB of every Tessera printer. */
  async #c() {
    const t = await Promise.all(
      this.#t.printers.map(async (e) => {
        try {
          const s = await this.#t.moonrakerFor(e.id).request("server.database.get_item", { namespace: "obico", key: "printer_id" }), i = Number(s?.value);
          return [e.id, Number.isInteger(i) && i > 0 ? i : null];
        } catch {
          return [e.id, this.links.get(e.id) ?? null];
        }
      })
    );
    this.links = new Map(t), this.#e = Date.now();
  }
  /** Appends the probability of every printing printer; a new print starts a new graph. */
  #d() {
    const t = Date.now();
    for (const e of this.printers.values()) {
      const s = e.current_print;
      if (!s) {
        this.#r.delete(e.id);
        continue;
      }
      let i = this.#r.get(e.id);
      (!i || i.printId !== s.id) && (i = { printId: s.id, samples: [] }, this.#r.set(e.id, i)), i.samples.push({ t, p: e.normalized_p }), i.samples.length > vt && i.samples.splice(0, i.samples.length - vt);
    }
  }
}
let yt = null;
function B(r) {
  return yt ??= new ue(r), yt;
}
class x extends R {
  static properties = {
    api: { attribute: !1 },
    params: { attribute: !1 }
  };
  #t = [];
  constructor() {
    super(), this.api = null, this.params = {};
  }
  connectedCallback() {
    super.connectedCallback(), this.api && this.attachApi(this.api);
  }
  willUpdate(t) {
    t.has("api") && this.api && this.#t.length === 0 && this.isConnected && this.attachApi(this.api);
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    for (const t of this.#t) t();
    this.#t = [];
  }
  /** Subclasses extend this to bind to the api; the returned unsubscribers are released on disconnect. */
  attachApi(t) {
    this.#t.push(t.onLocaleChange(() => this.requestUpdate()));
  }
  track(t) {
    this.#t.push(t);
  }
  /**
   * Translation through the HOST dictionary (our `locales` export is merged into it). An
   * arrow property, not a method: the render helpers in ui/parts.ts receive it detached.
   */
  t = (t, e) => this.api ? this.api.i18n.t(t, e) : t;
}
class b extends x {
  static properties = {
    ...x.properties,
    tick: { state: !0 }
  };
  hub = null;
  constructor() {
    super(), this.tick = 0;
  }
  attachApi(t) {
    super.attachApi(t), this.hub = B(t), this.track(this.hub.subscribe(() => this.tick++)), this.track(t.onPrinterChange(() => this.tick++));
  }
}
function g(r, t) {
  customElements.get(r) || customElements.define(r, t);
}
const fe = {
  obico: {
    tabTitle: "Obico",
    loading: "Waiting for the printer…",
    reload: "Check again",
    missing: {
      title: "Obico is not installed",
      text: 'moonraker-obico was not found on this printer: no moonraker-obico.cfg in the config folder, no service and no Obico macros. Install it on the printer, then press "Check again".',
      docs: "Obico setup guide"
    },
    link: {
      title: "Obico",
      server: "Server",
      cloud: "Obico Cloud",
      selfHosted: "Self-hosted",
      linked: "Linked",
      notLinked: "Not linked",
      unknown: "Link state unknown",
      code: "Link code",
      codeHint: "Enter this code in the Obico app when you add the printer, or open the link page.",
      openCode: "Open the link page",
      waiting: "The agent shows a link code a few seconds after it starts. If no code appears, check the service and its log below.",
      noMacros: "Obico macros are not included in printer.cfg, so the link code is not shown here. Find it in the agent log below.",
      open: "Open in Obico",
      relink: "Re-link",
      relinkConfirm: "The agent forgets its link and restarts. The printer stays offline in Obico until you link it again with a new code. Re-link?",
      relinkDone: "The agent is re-linking. A new code appears here in a few seconds.",
      confirm: "Re-link",
      cancel: "Cancel"
    },
    service: {
      title: "Service",
      restart: "Restart",
      restarted: "The service is restarting.",
      unmanaged: "Moonraker does not manage the moonraker-obico service here: it is not listed in moonraker.asvc, or the agent runs in Docker.",
      showLog: "Show log",
      hideLog: "Hide log",
      refreshLog: "Refresh log",
      logMissing: "The log file was not found.",
      logOutside: "The log is written outside the Moonraker folders ({path}), so it cannot be shown here.",
      logEmpty: "The log is empty."
    },
    tunnel: {
      title: "Remote access through Obico",
      intro: "The Obico app opens the web page of the printer through the Obico tunnel. By default the tunnel leads to port 80, where Mainsail or Fluidd usually live.",
      target: "The tunnel leads to",
      ok: "The tunnel opens Tessera.",
      other: "The tunnel opens another page. To open Tessera remotely, put these lines into moonraker-obico.cfg (replace the [tunnel] section if there is one) and restart the service:",
      unknownPort: "This page was opened over HTTPS, so its HTTP port is unknown. To open Tessera remotely, set dest_port in the [tunnel] section of moonraker-obico.cfg to the HTTP port of Tessera (8000 by default) and restart the service.",
      noConfig: "moonraker-obico.cfg was not found, so the tunnel settings are unknown."
    },
    error: "Failed: {error}",
    openTab: "Open the Obico tab",
    api: {
      title: "Obico API",
      intro: "Failure probability, alerts and statistics come from the Obico server API. Enter the address of your server and an access token; Tessera keeps the token on the printer and never shows it again.",
      cloud: "This printer is linked to Obico Cloud. The cloud has no personal access tokens, so these features work only with a self-hosted Obico server.",
      url: "Server address",
      token: "Access token",
      tokenSaved: "saved (type to replace)",
      tokenHelp: 'In the admin of your Obico server add an access token: pick your user, type a long random token, set a far expiry date and the scope "read write", save, and paste the token here.',
      tokenPage: "Open the token page",
      save: "Save",
      saved: "Saved.",
      check: "Check the connection",
      checked: "Checked.",
      remove: "Forget the server",
      removed: "The address and the token are removed from the printer.",
      connected: 'Connected: {count} printer(s) in the account, this one is "{name}".',
      notSetUp: "The Obico API is not set up.",
      notLinked: "This printer is not linked to Obico.",
      notFound: "This printer was not found in the Obico account of the token.",
      failed: "The Obico server does not answer.",
      tokenRejected: "the Obico server refused the token",
      unavailable: "This Tessera cannot reach the Obico API: its service proxy (the tessera-ext service) is turned off or missing, for example on a development server. The panels above keep working.",
      unavailableShort: "The Obico API is not available on this Tessera.",
      status: {
        unknown: "Checking",
        unavailable: "Unavailable",
        unconfigured: "Not set up",
        ready: "Connected",
        error: "Error"
      }
    },
    reaction: {
      title: "Failure detection",
      watching: "Watch prints for failures",
      onFailure: "When a failure is detected",
      pause: "Pause the print and alert",
      notifyOnly: "Only alert",
      sensitivity: "Sensitivity: {value} (0.8 low … 1.2 high)",
      retract: "Retract on pause, mm",
      liftZ: "Lift Z on pause, mm",
      toolsOff: "Turn the hotends off on pause",
      bedOff: "Turn the bed off on pause",
      saved: "Saved in Obico."
    },
    events: {
      title: "Obico events",
      empty: "No events of this printer yet."
    },
    level: { good: "Looking good", fishy: "Fishy…", failing: "Failing!" },
    meter: { label: "Failure probability", notWatching: "Not watching" },
    reason: {
      disabled: "Failure detection is turned off",
      noHours: "The AI detection hours are used up",
      notPrinting: "Not printing",
      muted: "Not watching the rest of this print"
    },
    snapshot: { alt: "The latest frame Obico analysed", none: "No frame yet" },
    alert: {
      short: "Possible failure",
      title: "Obico: possible failure on {printer}",
      text: "Obico thinks this print may be failing. Look at the frame and decide.",
      textPaused: "Obico thinks this print may be failing and has paused it. Look at the frame and decide.",
      notify: "Obico: possible print failure on {printer}",
      notFailure: "Not a failure",
      notFailureResume: "Not a failure, resume",
      muteToo: "Do not watch the rest of this print",
      cancel: "Cancel print",
      cancelConfirm: "Cancel the print? It cannot be resumed afterwards.",
      cancelYes: "Cancel the print",
      later: "Later",
      mute: "Stop watching this print"
    },
    widget: {
      detection: "Failure detection",
      stats: "Obico stats",
      graph: "Failure probability during this print"
    },
    stats: {
      period: "Period",
      week: "7 days",
      month: "30 days",
      year: "12 months",
      allPrinters: "All printers",
      prints: "Prints",
      succeeded: "Finished",
      cancelled: "Cancelled",
      hours: "Print hours",
      filament: "Filament, m",
      alerted: "Alerts",
      failures: "Real failures",
      falseAlarms: "False alarms",
      unanswered: "Not answered"
    },
    chip: { title: "Obico", placed: "Already on the strip." },
    fleet: { title: "Obico", alertTag: "Obico alert" },
    action: { mute: "Obico: stop watching", muted: "Obico stopped watching this print." }
  }
}, be = {
  obico: {
    tabTitle: "Obico",
    loading: "Ждём принтер…",
    reload: "Проверить снова",
    missing: {
      title: "Obico не установлен",
      text: "На этом принтере не найден moonraker-obico: нет moonraker-obico.cfg в папке конфигурации, нет службы и макросов Obico. Установите его на принтер и нажмите «Проверить снова».",
      docs: "Инструкция по установке Obico"
    },
    link: {
      title: "Obico",
      server: "Сервер",
      cloud: "Obico Cloud",
      selfHosted: "Свой сервер",
      linked: "Привязан",
      notLinked: "Не привязан",
      unknown: "Состояние привязки неизвестно",
      code: "Код привязки",
      codeHint: "Введите этот код в приложении Obico, когда добавляете принтер, или откройте страницу привязки.",
      openCode: "Открыть страницу привязки",
      waiting: "Агент показывает код привязки через несколько секунд после запуска. Если код не появился, проверьте службу и её лог ниже.",
      noMacros: "Макросы Obico не подключены в printer.cfg, поэтому код привязки здесь не виден. Найдите его в логе агента ниже.",
      open: "Открыть в Obico",
      relink: "Перепривязать",
      relinkConfirm: "Агент забудет привязку и перезапустится. Принтер будет офлайн в Obico, пока вы не привяжете его снова новым кодом. Перепривязать?",
      relinkDone: "Агент перепривязывается. Новый код появится здесь через несколько секунд.",
      confirm: "Перепривязать",
      cancel: "Отмена"
    },
    service: {
      title: "Служба",
      restart: "Перезапустить",
      restarted: "Служба перезапускается.",
      unmanaged: "Moonraker не управляет службой moonraker-obico: её нет в moonraker.asvc, или агент работает в Docker.",
      showLog: "Показать лог",
      hideLog: "Скрыть лог",
      refreshLog: "Обновить лог",
      logMissing: "Файл лога не найден.",
      logOutside: "Лог пишется вне папок Moonraker ({path}), поэтому здесь его не показать.",
      logEmpty: "Лог пуст."
    },
    tunnel: {
      title: "Удалённый доступ через Obico",
      intro: "Приложение Obico открывает веб-страницу принтера через туннель Obico. По умолчанию туннель ведёт на порт 80, где обычно Mainsail или Fluidd.",
      target: "Туннель ведёт на",
      ok: "Туннель открывает Tessera.",
      other: "Туннель открывает другую страницу. Чтобы открывать Tessera удалённо, вставьте эти строки в moonraker-obico.cfg (замените раздел [tunnel], если он есть) и перезапустите службу:",
      unknownPort: "Эта страница открыта по HTTPS, поэтому её HTTP-порт неизвестен. Чтобы открывать Tessera удалённо, укажите в разделе [tunnel] файла moonraker-obico.cfg параметр dest_port равным HTTP-порту Tessera (по умолчанию 8000) и перезапустите службу.",
      noConfig: "moonraker-obico.cfg не найден, поэтому настройки туннеля неизвестны."
    },
    error: "Не удалось: {error}",
    openTab: "Открыть вкладку Obico",
    api: {
      title: "API Obico",
      intro: "Вероятность сбоя, тревоги и статистика берутся из API сервера Obico. Укажите адрес своего сервера и токен доступа; Tessera хранит токен на принтере и больше его не показывает.",
      cloud: "Этот принтер привязан к Obico Cloud. В облаке нет личных токенов доступа, поэтому эти возможности работают только со своим сервером Obico.",
      url: "Адрес сервера",
      token: "Токен доступа",
      tokenSaved: "сохранён (введите, чтобы заменить)",
      tokenHelp: "В админке своего сервера Obico добавьте токен доступа: выберите своего пользователя, введите длинный случайный токен, дальний срок действия и scope «read write», сохраните и вставьте токен сюда.",
      tokenPage: "Открыть страницу токенов",
      save: "Сохранить",
      saved: "Сохранено.",
      check: "Проверить подключение",
      checked: "Проверено.",
      remove: "Забыть сервер",
      removed: "Адрес и токен удалены с принтера.",
      connected: "Подключено: принтеров в аккаунте — {count}, этот — «{name}».",
      notSetUp: "API Obico не настроен.",
      notLinked: "Этот принтер не привязан к Obico.",
      notFound: "Этот принтер не найден в аккаунте Obico, которому принадлежит токен.",
      failed: "Сервер Obico не отвечает.",
      tokenRejected: "сервер Obico не принял токен",
      unavailable: "Эта Tessera не может обращаться к API Obico: её прокси сервисов (служба tessera-ext) выключен или отсутствует, например на сервере разработки. Панели выше продолжают работать.",
      unavailableShort: "API Obico недоступен в этой Tessera.",
      status: {
        unknown: "Проверка",
        unavailable: "Недоступен",
        unconfigured: "Не настроен",
        ready: "Подключён",
        error: "Ошибка"
      }
    },
    reaction: {
      title: "Обнаружение сбоев",
      watching: "Следить за печатью",
      onFailure: "При обнаружении сбоя",
      pause: "Поставить на паузу и оповестить",
      notifyOnly: "Только оповестить",
      sensitivity: "Чувствительность: {value} (0.8 низкая … 1.2 высокая)",
      retract: "Ретракт при паузе, мм",
      liftZ: "Подъём Z при паузе, мм",
      toolsOff: "Выключать хотэнды при паузе",
      bedOff: "Выключать стол при паузе",
      saved: "Сохранено в Obico."
    },
    events: {
      title: "События Obico",
      empty: "Событий этого принтера пока нет."
    },
    level: { good: "Всё хорошо", fishy: "Подозрительно…", failing: "Сбой!" },
    meter: { label: "Вероятность сбоя", notWatching: "Не следит" },
    reason: {
      disabled: "Обнаружение сбоев выключено",
      noHours: "Часы ИИ-обнаружения закончились",
      notPrinting: "Не печатает",
      muted: "Не следит до конца этой печати"
    },
    snapshot: { alt: "Последний кадр, который проверил Obico", none: "Кадра пока нет" },
    alert: {
      short: "Возможен сбой",
      title: "Obico: возможен сбой на {printer}",
      text: "Obico считает, что печать, возможно, не удаётся. Посмотрите на кадр и решите.",
      textPaused: "Obico считает, что печать, возможно, не удаётся, и поставил её на паузу. Посмотрите на кадр и решите.",
      notify: "Obico: возможен сбой печати на {printer}",
      notFailure: "Это не сбой",
      notFailureResume: "Это не сбой, продолжить",
      muteToo: "Не следить до конца этой печати",
      cancel: "Отменить печать",
      cancelConfirm: "Отменить печать? Продолжить её потом будет нельзя.",
      cancelYes: "Отменить печать",
      later: "Позже",
      mute: "Не следить за этой печатью"
    },
    widget: {
      detection: "Обнаружение сбоев",
      stats: "Статистика Obico",
      graph: "Вероятность сбоя за эту печать"
    },
    stats: {
      period: "Период",
      week: "7 дней",
      month: "30 дней",
      year: "12 месяцев",
      allPrinters: "Все принтеры",
      prints: "Печати",
      succeeded: "Завершено",
      cancelled: "Отменено",
      hours: "Часы печати",
      filament: "Филамент, м",
      alerted: "Тревоги",
      failures: "Настоящие сбои",
      falseAlarms: "Ложные тревоги",
      unanswered: "Без ответа"
    },
    chip: { title: "Obico", placed: "Уже на панели." },
    fleet: { title: "Obico", alertTag: "Тревога Obico" },
    action: { mute: "Obico: не следить", muted: "Obico больше не следит за этой печатью." }
  }
}, y = m`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
    min-width: 0;
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    font-size: var(--font-size-md);
    container-type: inline-size;
  }

  .panel {
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-width: 0;
  }
  .panel-header {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: var(--space-sm);
    padding: var(--space-sm) var(--space-md);
    border-block-end: 1px solid var(--border-color);
  }
  /* A title never shrinks below ~14em: a long title takes its own line and the chips and
     buttons wrap under it, instead of being squeezed into a column of single letters. */
  .panel-title {
    flex: 1 1 14em;
    min-width: 0;
    font-size: var(--font-size-md);
    font-weight: 600;
    overflow-wrap: anywhere;
  }
  .panel-meta {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--space-sm);
  }
  .panel-body {
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    min-width: 0;
  }

  .row {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    flex-wrap: wrap;
  }
  .label {
    color: var(--text-secondary);
    font-size: var(--font-size-sm);
  }
  p {
    margin: 0;
    overflow-wrap: anywhere;
  }
  .muted {
    color: var(--text-muted);
    font-size: var(--font-size-sm);
  }
  .warn {
    color: var(--warning);
    font-size: var(--font-size-sm);
  }
  .error {
    color: var(--danger);
    font-size: var(--font-size-sm);
  }
  .ok {
    color: var(--success);
    font-size: var(--font-size-sm);
  }
  /* URLs, ports, service names, codes and log lines read left-to-right in any UI direction. */
  .ltr {
    direction: ltr;
    unicode-bidi: isolate;
    overflow-wrap: anywhere;
  }

  /* The link code is typed by hand into another app: large, monospace, easy to read out. */
  .code {
    font-family: ui-monospace, monospace;
    font-size: 1.6em;
    font-weight: 600;
    letter-spacing: 0.15em;
  }

  /* Config snippets and the log: monospace, left-to-right, scrolled inside their own box so
     long lines never widen the page on a narrow screen. */
  pre {
    margin: 0;
    padding: var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface-hover);
    font-family: ui-monospace, monospace;
    font-size: var(--font-size-sm);
    direction: ltr;
    text-align: left;
    unicode-bidi: isolate;
    overflow: auto;
    white-space: pre;
  }
  pre.snippet {
    user-select: all;
  }
  pre.log {
    max-block-size: 320px;
  }

  /* Buttons copy the dashboard edit toolbar of the host (EditToolbar.svelte), like the
     other Tessera-Ext plugins. Links styled as buttons open the Obico web app. */
  button,
  a.button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-xs);
    min-block-size: 32px;
    padding: var(--space-xs) var(--space-md);
    border: none;
    border-radius: var(--radius-md);
    background: var(--bg-surface-hover);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
    text-decoration: none;
    cursor: pointer;
  }
  button:hover:not(:disabled),
  a.button:hover {
    filter: brightness(1.12);
  }
  button:disabled {
    opacity: 0.4;
    cursor: not-allowed;
  }
  button.primary,
  a.button.primary {
    background: var(--accent);
    color: #fff;
  }
  button.danger {
    background: var(--danger);
    color: #fff;
  }
  button:focus-visible,
  a:focus-visible {
    outline: 2px solid var(--border-focus);
    outline-offset: 1px;
  }
  /* Touch targets on narrow widths. */
  @container (max-width: 560px) {
    button,
    a.button {
      min-block-size: var(--touch-target, 44px);
    }
  }
  a:not(.button) {
    color: var(--accent);
  }

  .chip {
    padding: 1px 8px;
    border-radius: 999px;
    border: 1px solid var(--border-color);
    background: var(--bg-surface-hover);
    color: var(--text-secondary);
    font-size: var(--font-size-sm);
    white-space: nowrap;
  }
  .chip.live {
    border-color: var(--success);
    color: var(--success);
  }
  .chip.bad {
    border-color: var(--danger);
    color: var(--danger);
  }
  .chip.warn {
    border-color: var(--warning);
    color: var(--warning);
  }

  /* The inline confirmation of a destructive action, instead of a native confirm() that
     ignores the theme and blocks the page. */
  .confirm {
    padding: var(--space-sm);
    border: 1px solid var(--danger);
    border-radius: var(--radius-sm);
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
  }
`;
function me(r) {
  return `${r}/admin/oauth2_provider/accesstoken/add/`;
}
class ge extends b {
  static styles = [
    y,
    m`
      :host {
        display: contents;
      }
      .fields {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(min(100%, 220px), 1fr));
        gap: var(--space-sm);
      }
      .field {
        display: flex;
        flex-direction: column;
        gap: 2px;
        min-width: 0;
      }
      .field > span {
        font-size: var(--font-size-sm);
        color: var(--text-secondary);
      }
      input,
      select {
        min-width: 0;
        min-block-size: 36px;
        padding: var(--space-xs) var(--space-sm);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        background: var(--bg-surface);
        color: var(--text-primary);
        font: inherit;
        font-size: var(--font-size-sm);
      }
      input[type='checkbox'] {
        min-block-size: 0;
        inline-size: 18px;
        block-size: 18px;
        accent-color: var(--accent);
      }
      input[type='range'] {
        padding: 0;
        accent-color: var(--accent);
      }
      label.check {
        display: flex;
        align-items: center;
        gap: var(--space-sm);
        min-block-size: 32px;
      }
      ol.events {
        list-style: none;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        gap: var(--space-xs);
      }
      ol.events li {
        display: grid;
        grid-template-columns: auto 1fr;
        gap: var(--space-sm);
        align-items: baseline;
        padding-block: var(--space-xs);
        border-block-end: 1px solid var(--border-color);
      }
      ol.events time {
        font-size: var(--font-size-sm);
        color: var(--text-muted);
        white-space: nowrap;
      }
      .ERROR {
        color: var(--danger);
      }
      .WARNING {
        color: var(--warning);
      }
      .SUCCESS {
        color: var(--success);
      }
    `
  ];
  static properties = {
    ...b.properties,
    config: { attribute: !1 },
    urlDraft: { state: !0 },
    secretDraft: { state: !0 },
    busy: { state: !0 },
    notice: { state: !0 },
    draft: { state: !0 },
    events: { state: !0 }
  };
  #t = null;
  constructor() {
    super(), this.config = null, this.urlDraft = null, this.secretDraft = "", this.busy = !1, this.notice = null, this.draft = null, this.events = null;
  }
  async #s(t, e) {
    this.busy = !0, this.notice = null;
    try {
      await t(), this.notice = { kind: "ok", text: this.t(e) };
    } catch (s) {
      this.notice = { kind: "error", text: this.t("obico.error", { error: s instanceof Error ? s.message : String(s) }) };
    } finally {
      this.busy = !1;
    }
  }
  updated() {
    const t = this.#i();
    t && this.#t !== t.id && (this.#t = t.id, this.draft = null, this.#e());
  }
  #i() {
    return this.hub && this.api ? this.hub.printerFor(this.api.printer.id) : null;
  }
  async #e() {
    const t = this.#i();
    if (!(!t || !this.hub))
      try {
        const e = await this.hub.client.events(100);
        this.#i()?.id === t.id && (this.events = e.filter((s) => s.printer === t.id).slice(0, 20));
      } catch {
        this.events = null;
      }
  }
  render() {
    const t = this.hub;
    if (!t || !this.api) return a``;
    if (t.status === "unavailable")
      return a`<section class="panel">
        <div class="panel-header"><span class="panel-title">${this.t("obico.api.title")}</span></div>
        <div class="panel-body"><p class="muted">${this.t("obico.api.unavailable")}</p></div>
      </section>`;
    const e = this.#i();
    return a`${this.#r()} ${e ? this.#n(e) : h} ${e ? this.#o() : h}`;
  }
  #r() {
    const t = this.hub, e = this.api, s = this.config?.serverUrl ?? "", i = this.urlDraft ?? t.url ?? s, n = this.config?.isCloud ?? !1, o = t.obicoIdFor(e.printer.id), l = this.#i();
    let c;
    return t.status === "ready" ? c = l ? a`<p class="ok">${this.t("obico.api.connected", { count: t.printers.size, name: l.name })}</p>` : o === null ? a`<p class="warn">${this.t("obico.api.notLinked")}</p>` : a`<p class="warn">${this.t("obico.api.notFound")}</p>` : t.status === "error" ? c = a`<p class="error">${this.t("obico.error", { error: t.error.startsWith("obico.") ? this.t(t.error) : t.error })}</p>` : c = a`<p class="muted">${this.t("obico.api.intro")}</p>`, a`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title">${this.t("obico.api.title")}</span>
          <div class="panel-meta">
            <span class="chip ${t.status === "ready" ? "live" : t.status === "error" ? "bad" : ""}">
              ${this.t(`obico.api.status.${t.status}`)}
            </span>
          </div>
        </div>
        <div class="panel-body">
          ${c}
          ${n ? a`<p class="warn">${this.t("obico.api.cloud")}</p>` : h}
          <div class="fields">
            <label class="field">
              <span>${this.t("obico.api.url")}</span>
              <input
                class="ltr"
                dir="ltr"
                type="url"
                inputmode="url"
                autocomplete="off"
                placeholder="http://192.168.1.20:3334"
                .value=${i}
                @input=${(d) => this.urlDraft = d.target.value}
              />
            </label>
            <label class="field">
              <span>${this.t("obico.api.token")}</span>
              <input
                class="ltr"
                dir="ltr"
                type="password"
                autocomplete="new-password"
                placeholder=${t.hasSecret ? this.t("obico.api.tokenSaved") : ""}
                .value=${this.secretDraft}
                @input=${(d) => this.secretDraft = d.target.value}
              />
            </label>
          </div>
          <p class="muted">
            ${this.t("obico.api.tokenHelp")}
            ${i ? a`<a class="ltr" dir="ltr" href=${me(i.replace(/\/+$/, ""))} target="_blank" rel="noopener noreferrer">${this.t("obico.api.tokenPage")}</a>` : h}
          </p>
          <div class="row">
            <button
              class="primary"
              ?disabled=${this.busy || !i}
              @click=${() => void this.#s(async () => {
      if (await t.configure(i.trim(), this.secretDraft ? this.secretDraft : void 0), this.secretDraft = "", this.urlDraft = null, t.status === "error") throw new Error(t.error.startsWith("obico.") ? this.t(t.error) : t.error);
    }, "obico.api.saved")}
            >
              ${this.t("obico.api.save")}
            </button>
            <button ?disabled=${this.busy || t.status === "unconfigured"} @click=${() => void this.#s(() => t.refresh(), "obico.api.checked")}>
              ${this.t("obico.api.check")}
            </button>
            ${t.url ? a`<button ?disabled=${this.busy} @click=${() => void this.#s(() => t.forget(), "obico.api.removed")}>
                  ${this.t("obico.api.remove")}
                </button>` : h}
          </div>
          ${this.notice ? a`<p class=${this.notice.kind} role="status">${this.notice.text}</p>` : h}
        </div>
      </section>
    `;
  }
  #n(t) {
    const e = this.hub, s = { ...t, ...this.draft }, i = (l) => this.draft = { ...this.draft, ...l }, n = (l) => Number(l.target.value), o = (l) => l.target.checked;
    return a`
      <section class="panel">
        <div class="panel-header"><span class="panel-title">${this.t("obico.reaction.title")}</span></div>
        <div class="panel-body">
          <label class="check">
            <input type="checkbox" .checked=${s.watching_enabled} @change=${(l) => i({ watching_enabled: o(l) })} />
            <span>${this.t("obico.reaction.watching")}</span>
          </label>
          <div class="fields">
            <label class="field">
              <span>${this.t("obico.reaction.onFailure")}</span>
              <select @change=${(l) => i({ action_on_failure: l.target.value })}>
                <option value="PAUSE" ?selected=${s.action_on_failure === "PAUSE"}>${this.t("obico.reaction.pause")}</option>
                <option value="NONE" ?selected=${s.action_on_failure === "NONE"}>${this.t("obico.reaction.notifyOnly")}</option>
              </select>
            </label>
            <label class="field">
              <span>${this.t("obico.reaction.sensitivity", { value: s.detective_sensitivity.toFixed(2) })}</span>
              <input
                type="range"
                min="0.8"
                max="1.2"
                step="0.05"
                .value=${String(s.detective_sensitivity)}
                @input=${(l) => i({ detective_sensitivity: n(l) })}
              />
            </label>
            <label class="field">
              <span>${this.t("obico.reaction.retract")}</span>
              <input type="number" min="0" step="0.5" .value=${String(s.retract_on_pause)} @change=${(l) => i({ retract_on_pause: n(l) })} />
            </label>
            <label class="field">
              <span>${this.t("obico.reaction.liftZ")}</span>
              <input type="number" min="0" step="0.5" .value=${String(s.lift_z_on_pause)} @change=${(l) => i({ lift_z_on_pause: n(l) })} />
            </label>
          </div>
          <label class="check">
            <input type="checkbox" .checked=${s.tools_off_on_pause} @change=${(l) => i({ tools_off_on_pause: o(l) })} />
            <span>${this.t("obico.reaction.toolsOff")}</span>
          </label>
          <label class="check">
            <input type="checkbox" .checked=${s.bed_off_on_pause} @change=${(l) => i({ bed_off_on_pause: o(l) })} />
            <span>${this.t("obico.reaction.bedOff")}</span>
          </label>
          <div class="row">
            <button
              class="primary"
              ?disabled=${this.busy || !this.draft}
              @click=${() => void this.#s(async () => {
      await e.run((l) => l.patchPrinter(t.id, this.draft ?? {})), this.draft = null;
    }, "obico.reaction.saved")}
            >
              ${this.t("obico.api.save")}
            </button>
            ${this.draft ? a`<button ?disabled=${this.busy} @click=${() => this.draft = null}>${this.t("obico.link.cancel")}</button>` : h}
          </div>
        </div>
      </section>
    `;
  }
  #o() {
    const t = new Intl.DateTimeFormat(this.api.i18n.locale, { dateStyle: "short", timeStyle: "short" }), e = this.events;
    return a`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title">${this.t("obico.events.title")}</span>
          <div class="panel-meta"><button @click=${() => void this.#e()}>${this.t("obico.reload")}</button></div>
        </div>
        <div class="panel-body">
          ${e === null ? a`<p class="muted">${this.t("obico.loading")}</p>` : e.length === 0 ? a`<p class="muted">${this.t("obico.events.empty")}</p>` : a`<ol class="events">
                  ${e.map(
      (s) => a`<li>
                      <time datetime=${s.created_at}>${t.format(new Date(s.created_at))}</time>
                      <span>
                        <b class=${s.event_class}>${s.event_title || s.event_type}</b>
                        ${s.event_text ? a`<span class="muted">${ve(s.event_text)}</span>` : h}
                      </span>
                    </li>`
    )}
                </ol>`}
        </div>
      </section>
    `;
  }
}
function ve(r) {
  return r.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
}
function et(r) {
  return `#/p/${encodeURIComponent(r)}/machine?section=${encodeURIComponent("tessera/obico/obico")}`;
}
function $e(r, t) {
  return r(`obico.level.${tt(t)}`);
}
function st(r, t) {
  const e = t.not_watching_reason;
  if (!e) return null;
  const s = re(e);
  return s ? r(s) : e;
}
function it(r, t) {
  const e = Math.min(1, Math.max(0, t.normalized_p || 0)), s = t.watching_enabled && !t.not_watching_reason, i = tt(e);
  return a`
    <div class="meter ${s ? i : "idle"}" role="meter" aria-valuemin="0" aria-valuemax="100" aria-valuenow=${Math.round(e * 100)}
      aria-label=${r("obico.meter.label")}>
      <div class="meter-track"><span style="inline-size: ${(e * 100).toFixed(0)}%"></span></div>
      <div class="meter-text">
        <span class="meter-level">${s ? $e(r, e) : r("obico.meter.notWatching")}</span>
        <span class="ltr" dir="ltr">${Math.round(e * 100)}%</span>
      </div>
    </div>
  `;
}
const rt = m`
  .meter {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }
  .meter-track {
    block-size: 8px;
    border-radius: 4px;
    background: var(--bg-surface-hover);
    overflow: hidden;
  }
  .meter-track > span {
    display: block;
    block-size: 100%;
    background: var(--text-muted);
    transition: inline-size 0.4s ease;
  }
  .meter.good .meter-track > span {
    background: var(--success);
  }
  .meter.fishy .meter-track > span {
    background: var(--warning);
  }
  .meter.failing .meter-track > span {
    background: var(--danger);
  }
  .meter-text {
    display: flex;
    justify-content: space-between;
    gap: var(--space-sm);
    font-size: var(--font-size-sm);
  }
  .meter.good .meter-level {
    color: var(--success);
  }
  .meter.fishy .meter-level {
    color: var(--warning);
  }
  .meter.failing .meter-level {
    color: var(--danger);
    font-weight: 600;
  }
  .meter.idle .meter-level {
    color: var(--text-muted);
  }
  @media (prefers-reduced-motion: reduce) {
    .meter-track > span {
      transition: none;
    }
  }
`;
class ye extends x {
  static styles = m`
    :host {
      display: block;
      min-width: 0;
      min-height: 0;
    }
    img {
      display: block;
      inline-size: 100%;
      block-size: 100%;
      object-fit: contain;
      border-radius: var(--radius-sm);
      background: var(--bg-surface-hover);
    }
    .empty {
      display: grid;
      place-items: center;
      block-size: 100%;
      min-block-size: 60px;
      color: var(--text-muted);
      font-size: var(--font-size-sm);
      background: var(--bg-surface-hover);
      border-radius: var(--radius-sm);
      text-align: center;
      padding: var(--space-sm);
    }
  `;
  static properties = {
    ...x.properties,
    src: { attribute: !1 },
    objectUrl: { state: !0 },
    failed: { state: !0 }
  };
  #t = null;
  constructor() {
    super(), this.src = null, this.objectUrl = null, this.failed = !1;
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.objectUrl && URL.revokeObjectURL(this.objectUrl), this.objectUrl = null, this.#t = null;
  }
  updated() {
    this.src && this.src !== this.#t && this.api && this.isConnected && this.#s(this.src);
  }
  async #s(t) {
    this.#t = t;
    try {
      const e = await B(this.api).client.image(t);
      if (this.#t !== t || !this.isConnected) {
        URL.revokeObjectURL(e);
        return;
      }
      this.objectUrl && URL.revokeObjectURL(this.objectUrl), this.objectUrl = e, this.failed = !1;
    } catch {
      this.failed = !this.objectUrl;
    }
  }
  render() {
    return this.objectUrl ? a`<img src=${this.objectUrl} alt=${this.t("obico.snapshot.alt")} />` : a`<div class="empty">${this.src && !this.failed ? this.t("obico.loading") : this.t("obico.snapshot.none")}</div>`;
  }
}
function Pt(r, t, e) {
  return t === "unknown" ? a`<p class="muted">${r("obico.loading")}</p>` : t === "unavailable" ? a`<p class="muted">${r("obico.api.unavailableShort")}</p>` : t === "unconfigured" ? a`<p class="muted">${r("obico.api.notSetUp")}</p>` : e === null ? a`<p class="muted">${r("obico.api.notLinked")}</p>` : h;
}
const kt = "probability";
class ke extends b {
  static styles = [
    y,
    m`
      :host {
        block-size: 100%;
        gap: 0;
      }
      a {
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: 2px;
        block-size: 100%;
        box-sizing: border-box;
        /* The chip width follows its content but never grows past the strip's taste. */
        max-inline-size: 180px;
        min-inline-size: 90px;
        padding: var(--space-xs) var(--space-md);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-md);
        background: var(--bg-surface);
        color: var(--text-primary);
        text-decoration: none;
      }
      a.missing {
        border-style: dashed;
        color: var(--text-muted);
      }
      a.alert {
        border-color: var(--danger);
        box-shadow: inset 0 0 0 1px var(--danger);
      }
      .name,
      .state {
        font-size: var(--font-size-sm);
        color: var(--text-secondary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .value {
        font-size: 1.3em;
        font-weight: 600;
      }
      .good {
        color: var(--success);
      }
      .fishy {
        color: var(--warning);
      }
      .failing {
        color: var(--danger);
      }
      .idle {
        color: var(--text-muted);
      }
    `
  ];
  render() {
    const t = this.hub, e = this.api;
    if (!t || !e) return a``;
    const s = this.params.edit === "1", i = t.printerFor(e.printer.id), n = et(e.printer.id), o = (p) => {
      s && p.preventDefault();
    };
    if (!i) {
      const p = t.status === "unconfigured" || t.status === "unavailable" ? this.t("obico.api.notSetUp") : t.obicoIdFor(e.printer.id) === null ? this.t("obico.api.notLinked") : this.t("obico.loading");
      return a`<a class="missing" href=${n} @click=${o} title=${p}>
        <span class="name">${this.params.chipLabel || this.t("obico.chip.title")}</span>
        <span class="state">${p}</span>
      </a>`;
    }
    const l = Math.round((i.normalized_p || 0) * 100), c = i.watching_enabled && !i.not_watching_reason, d = E(i.current_print), u = st(this.t, i);
    return a`<a class=${d ? "alert" : ""} href=${n} @click=${o} title=${u ?? this.t("obico.chip.title")}>
      <span class="name">${this.params.chipLabel || this.t("obico.chip.title")}</span>
      <span class="value ltr ${c ? tt(i.normalized_p || 0) : "idle"}" dir="ltr">${l}%</span>
      ${d ? a`<span class="state failing">${this.t("obico.alert.short")}</span>` : c ? h : a`<span class="state">${u ?? this.t("obico.meter.notWatching")}</span>`}
    </a>`;
  }
}
class _e extends x {
  static styles = [y];
  render() {
    let t = [];
    try {
      t = JSON.parse(this.params.placed ?? "[]");
    } catch {
      t = [];
    }
    return Array.isArray(t) && t.includes(kt) ? a`<p class="muted">${this.t("obico.chip.placed")}</p>` : a`<button
      @click=${(e) => e.currentTarget.dispatchEvent(
      new CustomEvent("mpu:chip-pick", { bubbles: !0, composed: !0, detail: { id: kt } })
    )}
    >
      ${this.t("obico.chip.title")}
    </button>`;
  }
}
class we extends b {
  static styles = [
    y,
    rt,
    m`
      :host {
        block-size: 100%;
        gap: var(--space-sm);
        padding: var(--space-sm);
        box-sizing: border-box;
        overflow: auto;
      }
      /* The frame takes the free height; on a short widget it shrinks first. */
      tessera-obico-snapshot {
        flex: 1 1 80px;
      }
      svg {
        inline-size: 100%;
        block-size: 36px;
        display: block;
      }
      polyline {
        fill: none;
        stroke: var(--accent);
        stroke-width: 1.2;
        vector-effect: non-scaling-stroke;
      }
      line {
        stroke: var(--border-color);
        stroke-dasharray: 2 2;
        vector-effect: non-scaling-stroke;
      }
      .alert {
        color: var(--danger);
        font-weight: 600;
      }
    `
  ];
  render() {
    const t = this.hub, e = this.api;
    if (!t || !e) return a``;
    const s = t.obicoIdFor(e.printer.id), i = Pt(this.t, t.status, s);
    if (i !== h) return a`${i}<a href=${et(e.printer.id)}>${this.t("obico.openTab")}</a>`;
    const n = t.printerFor(e.printer.id);
    if (!n)
      return a`<p class="muted">${t.status === "error" ? this.t("obico.api.failed") : this.t("obico.api.notFound")}</p>`;
    const o = n.current_print, l = st(this.t, n), c = t.samples(n.id), d = (u) => void t.run(u).catch(() => {
    });
    return a`
      ${it(this.t, n)}
      ${E(o) ? a`<p class="alert" role="alert">${this.t("obico.alert.short")}</p>` : h}
      ${l ? a`<p class="muted">${l}</p>` : h}
      <tessera-obico-snapshot .api=${e} .src=${n.pic?.img_url ?? null}></tessera-obico-snapshot>
      ${c.length > 1 ? a`<svg viewBox="0 0 100 30" preserveAspectRatio="none" dir="ltr" role="img" aria-label=${this.t("obico.widget.graph")}>
            <line x1="0" x2="100" y1="20.1" y2="20.1"></line>
            <line x1="0" x2="100" y1="9.9" y2="9.9"></line>
            <polyline points=${ae(c)}></polyline>
          </svg>` : h}
      ${o ? a`<div class="row">
            ${E(o) ? a`<button @click=${() => d(() => t.client.acknowledge(n.id, "NOT_FAILED"))}>${this.t("obico.alert.notFailure")}</button>` : h}
            ${!o.alert_muted_at && n.watching_enabled ? a`<button @click=${() => d(() => t.client.mute(n.id))}>${this.t("obico.alert.mute")}</button>` : h}
          </div>` : h}
    `;
  }
}
class xe extends b {
  static styles = [
    y,
    rt,
    m`
      :host {
        gap: var(--space-xs);
        padding: var(--space-xs) var(--space-sm);
      }
      .alert {
        color: var(--danger);
        font-weight: 600;
      }
    `
  ];
  #t = "";
  attachApi(t) {
    super.attachApi(t), this.track(() => {
      this.params.printerId && t.fleet.retract(this.params.printerId), this.#t = "";
    });
  }
  updated() {
    const t = this.api, e = this.params.printerId;
    if (!t || !e || !this.hub) return;
    const s = E(this.hub.printerFor(e)?.current_print), i = s ? "alert" : "ok";
    i !== this.#t && (this.#t = i, t.fleet.publish(e, {
      tags: s ? [{ id: "obico-alert", labelKey: "obico.fleet.alertTag", order: 0 }] : [],
      searchText: s ? this.t("obico.fleet.alertTag") : ""
    }));
  }
  render() {
    const t = this.hub, e = this.params.printerId;
    if (!t || !e) return a``;
    const s = t.printerFor(e);
    if (!s) return a``;
    const i = st(this.t, s);
    return a`
      ${it(this.t, s)}
      ${E(s.current_print) ? a`<p class="alert" role="status">${this.t("obico.alert.short")}</p>` : h}
      ${i && s.current_print ? a`<p class="muted">${i}</p>` : h}
    `;
  }
}
const _t = /* @__PURE__ */ new Set();
class Ae extends b {
  static styles = [
    y,
    rt,
    m`
      :host {
        display: contents;
      }
      .backdrop {
        position: fixed;
        inset: 0;
        background: rgb(0 0 0 / 0.45);
        display: grid;
        place-items: center;
        /* 16px gutter so the dialog never touches the screen edge on a phone. */
        padding: 16px;
      }
      .dialog {
        inline-size: min(520px, 100%);
        max-block-size: calc(100dvh - 32px);
        overflow: auto;
        border-color: var(--danger);
      }
      .dialog .panel-header {
        color: var(--danger);
      }
      tessera-obico-snapshot {
        block-size: min(40dvh, 280px);
      }
      label.check {
        display: flex;
        align-items: center;
        gap: var(--space-sm);
        min-block-size: 32px;
      }
    `
  ];
  static properties = {
    ...b.properties,
    busy: { state: !0 },
    confirmCancel: { state: !0 },
    muteToo: { state: !0 },
    failure: { state: !0 }
  };
  /** The alert the window shows; a new one resets the window's own state. */
  #t = "";
  constructor() {
    super(), this.busy = !1, this.confirmCancel = !1, this.muteToo = !1, this.failure = "";
  }
  attachApi(t) {
    super.attachApi(t);
    const e = (s) => {
      s.key === "Escape" && this.#s() && !this.busy && this.hub?.dismiss(this.#s().key);
    };
    window.addEventListener("keydown", e), this.track(() => window.removeEventListener("keydown", e));
  }
  #s() {
    return this.hub?.pendingAlerts()[0] ?? null;
  }
  #i(t) {
    return this.api?.printers.find((e) => e.id === t)?.name ?? t;
  }
  willUpdate(t) {
    super.willUpdate(t);
    const e = this.api, s = this.hub;
    if (!e || !s) return;
    for (const n of s.pendingAlerts())
      _t.has(n.key) || (_t.add(n.key), e.notifications.push({
        severity: "critical",
        text: this.t("obico.alert.notify", { printer: this.#i(n.tesseraId) }),
        label: this.t("obico.tabTitle"),
        printerId: n.tesseraId
      }));
    const i = this.#s()?.key ?? "";
    i !== this.#t && (this.#t = i, this.confirmCancel = !1, this.muteToo = !1, this.failure = "");
  }
  /** Runs the steps in order; a refused step (a guard, the server) stops and leaves the alert open. */
  async #e(t) {
    if (!this.busy) {
      this.busy = !0, this.failure = "";
      try {
        for (const e of t) await e();
        await this.hub.poll();
      } catch (e) {
        this.failure = e instanceof Error ? e.message : String(e);
      } finally {
        this.busy = !1;
      }
    }
  }
  #r(t) {
    const e = this.api, s = this.hub, i = t.printer.id, n = t.printer.status?.state?.flags?.paused === !0, o = [() => s.client.acknowledge(i, "NOT_FAILED")];
    this.muteToo && o.push(() => s.client.mute(i)), n && o.push(() => e.moonrakerFor(t.tesseraId).request("printer.print.resume")), this.#e(o);
  }
  #n(t) {
    const e = this.api, s = this.hub;
    this.#e([
      () => e.moonrakerFor(t.tesseraId).request("printer.print.cancel"),
      () => s.client.acknowledge(t.printer.id, "FAILED")
    ]);
  }
  render() {
    const t = this.#s(), e = this.api;
    if (!t || !e) return h;
    const s = t.printer, i = s.status?.state?.flags?.paused === !0;
    return a`
      <div class="backdrop">
        <section class="panel dialog" role="alertdialog" aria-modal="true" aria-labelledby="obico-alert-title">
          <div class="panel-header">
            <span class="panel-title" id="obico-alert-title">
              ${this.t("obico.alert.title", { printer: this.#i(t.tesseraId) })}
            </span>
          </div>
          <div class="panel-body">
            <p>${this.t(i ? "obico.alert.textPaused" : "obico.alert.text")}</p>
            ${s.current_print?.filename ? a`<p class="muted ltr" dir="ltr">${s.current_print.filename}</p>` : h}
            ${it(this.t, s)}
            <tessera-obico-snapshot .api=${e} .src=${s.pic?.img_url ?? null}></tessera-obico-snapshot>
            ${this.failure ? a`<p class="error" role="alert">${this.t("obico.error", { error: this.failure })}</p>` : h}
            ${this.confirmCancel ? a`<div class="confirm">
                  <p>${this.t("obico.alert.cancelConfirm")}</p>
                  <div class="row">
                    <button class="danger" ?disabled=${this.busy} @click=${() => this.#n(t)}>
                      ${this.t("obico.alert.cancelYes")}
                    </button>
                    <button ?disabled=${this.busy} @click=${() => this.confirmCancel = !1}>${this.t("obico.link.cancel")}</button>
                  </div>
                </div>` : a`
                  <label class="check">
                    <input type="checkbox" .checked=${this.muteToo} @change=${(n) => this.muteToo = n.target.checked} />
                    <span>${this.t("obico.alert.muteToo")}</span>
                  </label>
                  <div class="row">
                    <button class="primary" ?disabled=${this.busy} @click=${() => this.#r(t)}>
                      ${this.t(i ? "obico.alert.notFailureResume" : "obico.alert.notFailure")}
                    </button>
                    <button class="danger" ?disabled=${this.busy} @click=${() => this.confirmCancel = !0}>
                      ${this.t("obico.alert.cancel")}
                    </button>
                    <button ?disabled=${this.busy} @click=${() => this.hub.dismiss(t.key)}>${this.t("obico.alert.later")}</button>
                  </div>
                `}
          </div>
        </section>
      </div>
    `;
  }
}
const Oe = 5 * 6e4, wt = /* @__PURE__ */ new Map();
class Te extends b {
  static styles = [
    y,
    m`
      :host {
        block-size: 100%;
        gap: var(--space-sm);
        padding: var(--space-sm);
        box-sizing: border-box;
        overflow: auto;
      }
      .tiles {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(min(100%, 110px), 1fr));
        gap: var(--space-sm);
      }
      .tile {
        display: flex;
        flex-direction: column;
        gap: 2px;
        padding: var(--space-xs) var(--space-sm);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        min-width: 0;
      }
      .tile b {
        font-size: 1.2em;
      }
      .seg button[aria-pressed='true'] {
        background: var(--accent);
        color: #fff;
      }
    `
  ];
  static properties = {
    ...b.properties,
    period: { state: !0 },
    all: { state: !0 },
    entry: { state: !0 },
    loading: { state: !0 },
    failed: { state: !0 }
  };
  #t = "";
  constructor() {
    super(), this.period = "month", this.all = !1, this.entry = null, this.loading = !1, this.failed = "";
  }
  // willUpdate, not updated: the synchronous part of #ensure (cached entry, loading flag)
  // then lands in this same render instead of scheduling another one.
  willUpdate(t) {
    super.willUpdate(t), this.#s();
  }
  /** Loads the selected period when the hub is ready and nothing (fresh) is shown for it. */
  async #s(t = !1) {
    const e = this.hub, s = this.api;
    if (!e || !s || e.status !== "ready") return;
    const i = e.obicoIdFor(s.printer.id);
    if (!this.all && i == null) return;
    const n = this.all ? [] : [i], o = `${this.period}:${n.join(",")}`, l = wt.get(o);
    if (!t && l && Date.now() - l.at < Oe) {
      this.entry !== l && (this.entry = l);
      return;
    }
    if (!(this.#t === o && !t)) {
      this.#t = o, this.loading = !0, this.failed = "";
      try {
        const c = ne(this.period, /* @__PURE__ */ new Date(), Intl.DateTimeFormat().resolvedOptions().timeZone), [d, u] = await Promise.all([e.client.stats(c, n), e.client.prints(c, n)]), p = { at: Date.now(), stats: d, alerts: oe(u) };
        wt.set(o, p), this.#t === o && (this.entry = p);
      } catch (c) {
        this.#t === o && (this.failed = c instanceof Error ? c.message : String(c));
      } finally {
        this.#t === o && (this.loading = !1, this.#t = "");
      }
    }
  }
  #i(t) {
    this.period = t, this.entry = null;
  }
  render() {
    const t = this.hub, e = this.api;
    if (!t || !e) return a``;
    const s = t.obicoIdFor(e.printer.id), i = Pt(this.t, t.status, this.all ? 0 : s);
    if (i !== h) return a`${i}<a href=${et(e.printer.id)}>${this.t("obico.openTab")}</a>`;
    const n = ["week", "month", "year"], o = this.entry, l = new Intl.NumberFormat(e.i18n.locale, { maximumFractionDigits: 1 });
    return a`
      <div class="row">
        <div class="row seg" role="group" aria-label=${this.t("obico.stats.period")}>
          ${n.map(
      (c) => a`<button aria-pressed=${this.period === c ? "true" : "false"} @click=${() => this.#i(c)}>
              ${this.t(`obico.stats.${c}`)}
            </button>`
    )}
        </div>
        <label class="row">
          <input
            type="checkbox"
            .checked=${this.all}
            @change=${(c) => {
      this.all = c.target.checked, this.entry = null;
    }}
          />
          <span>${this.t("obico.stats.allPrinters")}</span>
        </label>
      </div>
      ${this.failed ? a`<p class="error">${this.t("obico.error", { error: this.failed })}</p>` : h}
      ${o ? a`<div class="tiles">
            ${this.#e("obico.stats.prints", l.format(o.stats.total_print_count))}
            ${this.#e("obico.stats.succeeded", l.format(o.stats.total_succeeded_print_count))}
            ${this.#e("obico.stats.cancelled", l.format(o.stats.total_cancelled_print_count))}
            ${this.#e("obico.stats.hours", l.format(o.stats.total_print_time / 3600))}
            ${this.#e("obico.stats.filament", l.format(o.stats.total_filament_used / 1e3))}
            ${this.#e("obico.stats.alerted", l.format(o.alerts.alerted))}
            ${this.#e("obico.stats.failures", l.format(o.alerts.failures))}
            ${this.#e("obico.stats.falseAlarms", l.format(o.alerts.falseAlarms))}
            ${this.#e("obico.stats.unanswered", l.format(o.alerts.unanswered))}
          </div>` : a`<p class="muted">${this.loading ? this.t("obico.loading") : ""}</p>`}
    `;
  }
  #e(t, e) {
    return a`<div class="tile"><span class="muted">${this.t(t)}</span><b class="ltr" dir="ltr">${e}</b></div>`;
  }
}
const Ee = "https://app.obico.io", Se = "127.0.0.1", Ce = 80;
function Pe(r) {
  const t = {};
  let e = null;
  for (const s of r.split(/\r?\n/)) {
    const i = s.trim();
    if (!i || i.startsWith("#") || i.startsWith(";")) continue;
    const n = /^\[([^\]]+)\]$/.exec(i);
    if (n) {
      const l = n[1].trim().toLowerCase();
      e = t[l] ??= {};
      continue;
    }
    if (!e) continue;
    const o = i.search(/[=:]/);
    o <= 0 || (e[i.slice(0, o).trim().toLowerCase()] = i.slice(o + 1).trim());
  }
  return t;
}
function Re(r, t) {
  if (r === void 0) return t;
  const e = r.toLowerCase();
  return ["1", "yes", "true", "on"].includes(e) ? !0 : ["0", "no", "false", "off"].includes(e) ? !1 : t;
}
function Ue(r) {
  try {
    const t = new URL(r).hostname.toLowerCase();
    return t === "obico.io" || t.endsWith(".obico.io");
  } catch {
    return !1;
  }
}
function Le(r) {
  const t = r.server ?? {}, e = r.tunnel ?? {}, s = (t.url || Ee).replace(/\/+$/, ""), i = Number.parseInt(e.dest_port ?? "", 10);
  return {
    serverUrl: s,
    isCloud: Ue(s),
    hasToken: !!t.auth_token,
    logPath: r.logging?.path ?? "",
    tunnel: {
      host: e.dest_host || Se,
      port: Number.isFinite(i) && i > 0 ? i : Ce,
      ssl: Re(e.dest_is_ssl, !1)
    }
  };
}
function ze(r, t) {
  return t === null ? `${r}/printers/` : `${r}/printers/${t}/control/`;
}
const Ie = { root: "logs", path: "moonraker-obico.log" };
function Ne(r) {
  if (!r) return Ie;
  const t = /\/[^/]*_data\/(logs|config)\/(.+)$/.exec(r.replace(/\\/g, "/"));
  return t ? { root: t[1], path: t[2] } : null;
}
function Fe(r) {
  if (r.protocol !== "http:") return null;
  const t = Number.parseInt(r.port, 10);
  return Number.isFinite(t) && t > 0 ? t : 80;
}
function Me(r) {
  return `[tunnel]
dest_host = 127.0.0.1
dest_port = ${r}
dest_is_ssl = False`;
}
const q = "gcode_macro OBICO_LINK_STATUS", De = "gcode_macro _OBICO_RELINK", He = "moonraker-obico.cfg";
function je(r) {
  for (const t of r) if (/^moonraker-obico(?:[-_.].*)?$/i.test(t)) return t;
  return null;
}
function xt(r) {
  const t = r?.system_info;
  if (!t) return null;
  const e = t.service_state ?? {}, s = Array.isArray(t.available_services) ? t.available_services.filter((o) => typeof o == "string") : [], i = je([...s, ...Object.keys(e)]);
  if (!i) return null;
  const n = e[i] ?? {};
  return { name: i, active: n.active_state ?? "", sub: n.sub_state ?? "" };
}
function Be(r, t) {
  return r ? {
    linked: r.is_linked === !0,
    passcode: typeof r.one_time_passcode == "string" ? r.one_time_passcode : "",
    passlink: typeof r.one_time_passlink == "string" ? r.one_time_passlink : ""
  } : { linked: t ? t.hasToken : null, passcode: "", passlink: "" };
}
async function We(r) {
  const t = await fetch(`${r.httpBaseUrl}/server/files/config/${He}`, {
    headers: Rt(r),
    cache: "no-store"
  });
  if (t.status === 404) return null;
  if (!t.ok) throw new Error(`HTTP ${t.status}`);
  return t.text();
}
const K = 64 * 1024;
async function qe(r, t) {
  const e = t.path.split("/").map(encodeURIComponent).join("/"), s = await fetch(`${r.httpBaseUrl}/server/files/${t.root}/${e}`, {
    headers: { ...Rt(r), Range: `bytes=-${K}` },
    cache: "no-store"
  });
  if (s.status === 404) return null;
  if (s.status === 416) return "";
  if (!s.ok) throw new Error(`HTTP ${s.status}`);
  const i = await s.text(), n = Number(/bytes (\d+)-/.exec(s.headers.get("Content-Range") ?? "")?.[1] ?? 0);
  if (!(s.status === 206 ? n > 0 : i.length > K)) return i;
  const l = i.slice(-K), c = l.indexOf(`
`);
  return c >= 0 ? l.slice(c + 1) : l;
}
function Rt(r) {
  return r.authToken ? { Authorization: `Bearer ${r.authToken}` } : {};
}
class Ke {
  snapshot = {
    loading: !0,
    installed: !1,
    config: null,
    printerId: null,
    service: null,
    link: { linked: null, passcode: "", passlink: "" },
    canRelink: !1
  };
  #t;
  #s = /* @__PURE__ */ new Set();
  #i = [];
  #e = null;
  #r = null;
  #n = !1;
  #o = !1;
  /** Bumped by every load, so an older answer that arrives late is dropped. */
  #l = 0;
  constructor(t) {
    this.#t = t, this.#i.push(t.onNotify("notify_service_state_changed", () => void this.#a())), this.#i.push(t.onNotify("notify_klippy_ready", () => void this.reload())), this.#i.push(t.onReady(() => void this.reload())), this.reload();
  }
  subscribe(t) {
    return this.#s.add(t), () => this.#s.delete(t);
  }
  dispose() {
    this.#o = !0, this.#e?.();
    for (const t of this.#i) t();
    this.#i = [], this.#s.clear();
  }
  /** Reads everything again. Each source fails on its own: a missing one is just "not there". */
  async reload() {
    const t = ++this.#l, e = this.#t, [s, i, n, o] = await Promise.all([
      e.request("machine.system_info").catch(() => null),
      e.request("printer.objects.list").catch(() => null),
      We(e).catch(() => null),
      e.request("server.database.get_item", { namespace: "obico", key: "printer_id" }).catch(() => null)
    ]);
    if (this.#o || t !== this.#l) return;
    const l = i?.objects ?? [], c = n === null ? null : Le(Pe(n)), d = Number(o?.value);
    this.#n = l.includes(q), this.#h(), this.#c({
      loading: !1,
      config: c,
      printerId: Number.isInteger(d) && d > 0 ? d : null,
      service: xt(s),
      canRelink: l.includes(De)
    });
  }
  /** Restarts the agent's service (Moonraker refuses services missing from moonraker.asvc). */
  async restartService() {
    const t = this.snapshot.service?.name;
    t && await this.#t.request("machine.services.restart", { service: t });
  }
  /** Runs the agent's own re-link macro: it drops the token and restarts the service. */
  async relink() {
    await this.#t.request("printer.gcode.script", { script: "_OBICO_RELINK" });
  }
  async #a() {
    const t = await this.#t.request("machine.system_info").catch(() => null);
    this.#o || this.#c({ service: xt(t) });
  }
  /** Subscribes to the link macro once it exists; its variables change while a code is issued. */
  #h() {
    !this.#n || this.#e || (this.#e = this.#t.subscribe(
      { [q]: ["is_linked", "one_time_passcode", "one_time_passlink"] },
      (t) => {
        const e = t?.[q];
        e && (this.#r = { ...this.#r, ...e }, this.#c({}));
      },
      { immediate: !0 }
    ));
  }
  #c(t) {
    const e = { ...this.snapshot, ...t };
    e.link = Be(this.#n ? this.#r : null, e.config), e.installed = e.config !== null || e.service !== null || this.#n, this.snapshot = e;
    for (const s of this.#s) s();
  }
}
const Ve = "https://www.obico.io/docs/user-guides/klipper-setup/";
class Ze extends x {
  static styles = [y];
  static properties = {
    ...x.properties,
    snap: { state: !0 },
    busy: { state: !0 },
    confirmRelink: { state: !0 },
    notice: { state: !0 },
    log: { state: !0 }
  };
  #t = null;
  #s = null;
  constructor() {
    super(), this.snap = null, this.busy = !1, this.confirmRelink = !1, this.notice = null, this.log = { kind: "hidden" };
  }
  attachApi(t) {
    super.attachApi(t), this.#i(t), this.track(t.onPrinterChange(() => this.#i(t))), this.track(() => this.#e());
  }
  #i(t) {
    this.#e(), this.confirmRelink = !1, this.notice = null, this.log = { kind: "hidden" };
    const e = new Ke(t.moonraker());
    this.#t = e, this.snap = e.snapshot, this.#s = e.subscribe(() => {
      this.snap = e.snapshot;
    });
  }
  #e() {
    this.#s?.(), this.#s = null, this.#t?.dispose(), this.#t = null;
  }
  /** Runs an action with the buttons disabled; its result or error goes to the notice line. */
  async #r(t, e) {
    this.busy = !0, this.notice = null;
    try {
      await t(), this.notice = { kind: "ok", text: this.t(e) };
    } catch (s) {
      this.notice = { kind: "error", text: this.t("obico.error", { error: s instanceof Error ? s.message : String(s) }) };
    } finally {
      this.busy = !1;
    }
  }
  async #n() {
    const t = this.#t, e = this.api;
    if (!t || !e) return;
    const s = t.snapshot.config?.logPath ?? "", i = Ne(s);
    if (!i) {
      this.log = { kind: "message", text: this.t("obico.service.logOutside", { path: s }) };
      return;
    }
    this.log = { kind: "loading" };
    try {
      const n = await qe(e.moonraker(), i);
      if (t !== this.#t) return;
      n === null ? this.log = { kind: "message", text: this.t("obico.service.logMissing") } : n.trim() ? this.log = { kind: "text", text: n } : this.log = { kind: "message", text: this.t("obico.service.logEmpty") };
    } catch (n) {
      this.log = { kind: "message", text: this.t("obico.error", { error: n instanceof Error ? n.message : String(n) }) };
    }
  }
  updated() {
    const t = this.renderRoot.querySelector("pre.log");
    t && (t.scrollTop = t.scrollHeight);
  }
  render() {
    const t = this.snap;
    return !t || t.loading ? a`<p class="muted">${this.t("obico.loading")}</p>` : t.installed ? a`
      ${this.#l(t)}
      <tessera-obico-api .api=${this.api} .config=${t.config}></tessera-obico-api>
      ${this.#h(t)} ${this.#d(t)}
      ${this.notice ? a`<p class=${this.notice.kind} role="status">${this.notice.text}</p>` : h}
    ` : this.#o();
  }
  #o() {
    return a`
      <section class="panel">
        <div class="panel-header"><span class="panel-title">${this.t("obico.missing.title")}</span></div>
        <div class="panel-body">
          <p>${this.t("obico.missing.text")}</p>
          <div class="row">
            <button @click=${() => void this.#t?.reload()}>${this.t("obico.reload")}</button>
            <a class="button" href=${Ve} target="_blank" rel="noopener noreferrer">${this.t("obico.missing.docs")}</a>
          </div>
        </div>
      </section>
    `;
  }
  #l(t) {
    const e = t.config, { linked: s, passcode: i, passlink: n } = t.link, o = s === !0 ? a`<span class="chip live">${this.t("obico.link.linked")}</span>` : s === !1 ? a`<span class="chip warn">${this.t("obico.link.notLinked")}</span>` : a`<span class="chip">${this.t("obico.link.unknown")}</span>`;
    return a`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title">${this.t("obico.link.title")}</span>
          <div class="panel-meta">
            ${e ? a`<span class="chip">${this.t(e.isCloud ? "obico.link.cloud" : "obico.link.selfHosted")}</span>` : h}
            ${o}
          </div>
        </div>
        <div class="panel-body">
          ${e ? a`<div class="row">
                <span class="label">${this.t("obico.link.server")}</span>
                <span class="ltr" dir="ltr">${e.serverUrl}</span>
              </div>` : h}
          ${s === !1 ? this.#a(i, n, t) : h}
          <div class="row">
            ${s === !0 && e ? a`<a class="button primary" href=${ze(e.serverUrl, t.printerId)} target="_blank" rel="noopener noreferrer"
                  >${this.t("obico.link.open")}</a
                >` : h}
            ${s === !0 && t.canRelink && !this.confirmRelink ? a`<button ?disabled=${this.busy} @click=${() => this.confirmRelink = !0}>${this.t("obico.link.relink")}</button>` : h}
            <button ?disabled=${this.busy} @click=${() => void this.#t?.reload()}>${this.t("obico.reload")}</button>
          </div>
          ${this.confirmRelink ? a`<div class="confirm" role="alertdialog">
                <p>${this.t("obico.link.relinkConfirm")}</p>
                <div class="row">
                  <button
                    class="danger"
                    ?disabled=${this.busy}
                    @click=${() => {
      this.confirmRelink = !1, this.#r(() => this.#t.relink(), "obico.link.relinkDone");
    }}
                  >
                    ${this.t("obico.link.confirm")}
                  </button>
                  <button @click=${() => this.confirmRelink = !1}>${this.t("obico.link.cancel")}</button>
                </div>
              </div>` : h}
        </div>
      </section>
    `;
  }
  /** Not linked: the code the agent issued, or why it is not shown. */
  #a(t, e, s) {
    return t ? a`
        <div class="row">
          <span class="label">${this.t("obico.link.code")}</span>
          <span class="code ltr" dir="ltr">${t}</span>
        </div>
        <p class="muted">${this.t("obico.link.codeHint")}</p>
        ${e ? a`<div class="row">
              <a class="button primary" href=${e} target="_blank" rel="noopener noreferrer">${this.t("obico.link.openCode")}</a>
            </div>` : h}
      ` : a`<p class="muted">${this.t(s.canRelink ? "obico.link.waiting" : "obico.link.noMacros")}</p>`;
  }
  #h(t) {
    const e = t.service, s = e?.active === "active", i = this.log.kind !== "hidden";
    return a`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title">${this.t("obico.service.title")}</span>
          ${e ? a`<div class="panel-meta">
                <span class="ltr" dir="ltr">${e.name}</span>
                <span class="chip ${s ? "live" : "bad"}" dir="ltr">${e.sub || e.active || "?"}</span>
              </div>` : h}
        </div>
        <div class="panel-body">
          ${e ? h : a`<p class="muted">${this.t("obico.service.unmanaged")}</p>`}
          <div class="row">
            ${e ? a`<button ?disabled=${this.busy} @click=${() => void this.#r(() => this.#t.restartService(), "obico.service.restarted")}>
                  ${this.t("obico.service.restart")}
                </button>` : h}
            <button
              aria-expanded=${i ? "true" : "false"}
              @click=${() => {
      i ? this.log = { kind: "hidden" } : this.#n();
    }}
            >
              ${this.t(i ? "obico.service.hideLog" : "obico.service.showLog")}
            </button>
            ${i ? a`<button @click=${() => void this.#n()}>${this.t("obico.service.refreshLog")}</button>` : h}
          </div>
          ${this.#c()}
        </div>
      </section>
    `;
  }
  #c() {
    switch (this.log.kind) {
      case "hidden":
        return h;
      case "loading":
        return a`<p class="muted">${this.t("obico.loading")}</p>`;
      case "message":
        return a`<p class="muted">${this.log.text}</p>`;
      case "text":
        return a`<pre class="log" dir="ltr" tabindex="0">${this.log.text}</pre>`;
    }
  }
  #d(t) {
    const e = t.config;
    let s;
    if (!e)
      s = a`<p class="muted">${this.t("obico.tunnel.noConfig")}</p>`;
    else {
      const { host: i, port: n, ssl: o } = e.tunnel, l = `${o ? "https" : "http"}://${i}:${n}`, c = Fe(window.location);
      s = a`
        <p class="muted">${this.t("obico.tunnel.intro")}</p>
        <div class="row">
          <span class="label">${this.t("obico.tunnel.target")}</span>
          <span class="ltr" dir="ltr">${l}</span>
        </div>
        ${c === null ? a`<p class="muted">${this.t("obico.tunnel.unknownPort")}</p>` : n === c && !o ? a`<p class="ok">${this.t("obico.tunnel.ok")}</p>` : a`<p class="warn">${this.t("obico.tunnel.other")}</p>
                <pre class="snippet" dir="ltr">${Me(c)}</pre>`}
      `;
    }
    return a`
      <section class="panel">
        <div class="panel-header"><span class="panel-title">${this.t("obico.tunnel.title")}</span></div>
        <div class="panel-body">${s}</div>
      </section>
    `;
  }
}
async function Je(r) {
  const t = B(r);
  t.status === "unknown" && await t.refresh();
  const e = t.printerFor(r.printer.id);
  return !!(e?.current_print && !e.current_print.alert_muted_at && e.watching_enabled);
}
async function Xe(r) {
  const t = B(r), e = t.printerFor(r.printer.id);
  if (e?.current_print)
    try {
      await t.run((s) => s.mute(e.id)), r.notifications.push({ severity: "info", text: r.i18n.t("obico.action.muted"), label: r.i18n.t("obico.tabTitle") });
    } catch (s) {
      r.notifications.push({
        severity: "error",
        text: r.i18n.t("obico.error", { error: s instanceof Error ? s.message : String(s) }),
        label: r.i18n.t("obico.tabTitle")
      });
    }
}
g("tessera-obico-tab", Ze);
g("tessera-obico-overlay", Ae);
g("tessera-obico-detection-widget", we);
g("tessera-obico-stats-widget", Te);
g("tessera-obico-chip", ke);
g("tessera-obico-chip-picker", _e);
g("tessera-obico-fleet-panel", xe);
g("tessera-obico-api", ge);
g("tessera-obico-snapshot", ye);
const Qe = { en: fe, ru: be };
export {
  Qe as locales,
  Je as obicoMuteAvailable,
  Xe as obicoMuteHandler
};
