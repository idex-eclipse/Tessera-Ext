/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Pn = globalThis, Il = Pn.ShadowRoot && (Pn.ShadyCSS === void 0 || Pn.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, Wl = Symbol(), Ui = /* @__PURE__ */ new WeakMap();
let Ir = class {
  constructor(e, n, s) {
    if (this._$cssResult$ = !0, s !== Wl) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = e, this.t = n;
  }
  get styleSheet() {
    let e = this.o;
    const n = this.t;
    if (Il && e === void 0) {
      const s = n !== void 0 && n.length === 1;
      s && (e = Ui.get(n)), e === void 0 && ((this.o = e = new CSSStyleSheet()).replaceSync(this.cssText), s && Ui.set(n, e));
    }
    return e;
  }
  toString() {
    return this.cssText;
  }
};
const Wr = (t) => new Ir(typeof t == "string" ? t : t + "", void 0, Wl), Vr = (t, ...e) => {
  const n = t.length === 1 ? t[0] : e.reduce((s, l, o) => s + ((a) => {
    if (a._$cssResult$ === !0) return a.cssText;
    if (typeof a == "number") return a;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + a + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(l) + t[o + 1], t[0]);
  return new Ir(n, t, Wl);
}, wa = (t, e) => {
  if (Il) t.adoptedStyleSheets = e.map((n) => n instanceof CSSStyleSheet ? n : n.styleSheet);
  else for (const n of e) {
    const s = document.createElement("style"), l = Pn.litNonce;
    l !== void 0 && s.setAttribute("nonce", l), s.textContent = n.cssText, t.appendChild(s);
  }
}, Ii = Il ? (t) => t : (t) => t instanceof CSSStyleSheet ? ((e) => {
  let n = "";
  for (const s of e.cssRules) n += s.cssText;
  return Wr(n);
})(t) : t;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: Sa, defineProperty: xa, getOwnPropertyDescriptor: $a, getOwnPropertyNames: Ea, getOwnPropertySymbols: Aa, getPrototypeOf: ka } = Object, Fn = globalThis, Wi = Fn.trustedTypes, Ta = Wi ? Wi.emptyScript : "", Ca = Fn.reactiveElementPolyfillSupport, on = (t, e) => t, Al = { toAttribute(t, e) {
  switch (e) {
    case Boolean:
      t = t ? Ta : null;
      break;
    case Object:
    case Array:
      t = t == null ? t : JSON.stringify(t);
  }
  return t;
}, fromAttribute(t, e) {
  let n = t;
  switch (e) {
    case Boolean:
      n = t !== null;
      break;
    case Number:
      n = t === null ? null : Number(t);
      break;
    case Object:
    case Array:
      try {
        n = JSON.parse(t);
      } catch {
        n = null;
      }
  }
  return n;
} }, Gr = (t, e) => !Sa(t, e), Vi = { attribute: !0, type: String, converter: Al, reflect: !1, useDefault: !1, hasChanged: Gr };
Symbol.metadata ??= Symbol("metadata"), Fn.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
let Rs = class extends HTMLElement {
  static addInitializer(e) {
    this._$Ei(), (this.l ??= []).push(e);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(e, n = Vi) {
    if (n.state && (n.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(e) && ((n = Object.create(n)).wrapped = !0), this.elementProperties.set(e, n), !n.noAccessor) {
      const s = Symbol(), l = this.getPropertyDescriptor(e, s, n);
      l !== void 0 && xa(this.prototype, e, l);
    }
  }
  static getPropertyDescriptor(e, n, s) {
    const { get: l, set: o } = $a(this.prototype, e) ?? { get() {
      return this[n];
    }, set(a) {
      this[n] = a;
    } };
    return { get: l, set(a) {
      const h = l?.call(this);
      o?.call(this, a), this.requestUpdate(e, h, s);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(e) {
    return this.elementProperties.get(e) ?? Vi;
  }
  static _$Ei() {
    if (this.hasOwnProperty(on("elementProperties"))) return;
    const e = ka(this);
    e.finalize(), e.l !== void 0 && (this.l = [...e.l]), this.elementProperties = new Map(e.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(on("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(on("properties"))) {
      const n = this.properties, s = [...Ea(n), ...Aa(n)];
      for (const l of s) this.createProperty(l, n[l]);
    }
    const e = this[Symbol.metadata];
    if (e !== null) {
      const n = litPropertyMetadata.get(e);
      if (n !== void 0) for (const [s, l] of n) this.elementProperties.set(s, l);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [n, s] of this.elementProperties) {
      const l = this._$Eu(n, s);
      l !== void 0 && this._$Eh.set(l, n);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(e) {
    const n = [];
    if (Array.isArray(e)) {
      const s = new Set(e.flat(1 / 0).reverse());
      for (const l of s) n.unshift(Ii(l));
    } else e !== void 0 && n.push(Ii(e));
    return n;
  }
  static _$Eu(e, n) {
    const s = n.attribute;
    return s === !1 ? void 0 : typeof s == "string" ? s : typeof e == "string" ? e.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise((e) => this.enableUpdating = e), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((e) => e(this));
  }
  addController(e) {
    (this._$EO ??= /* @__PURE__ */ new Set()).add(e), this.renderRoot !== void 0 && this.isConnected && e.hostConnected?.();
  }
  removeController(e) {
    this._$EO?.delete(e);
  }
  _$E_() {
    const e = /* @__PURE__ */ new Map(), n = this.constructor.elementProperties;
    for (const s of n.keys()) this.hasOwnProperty(s) && (e.set(s, this[s]), delete this[s]);
    e.size > 0 && (this._$Ep = e);
  }
  createRenderRoot() {
    const e = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return wa(e, this.constructor.elementStyles), e;
  }
  connectedCallback() {
    this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$EO?.forEach((e) => e.hostConnected?.());
  }
  enableUpdating(e) {
  }
  disconnectedCallback() {
    this._$EO?.forEach((e) => e.hostDisconnected?.());
  }
  attributeChangedCallback(e, n, s) {
    this._$AK(e, s);
  }
  _$ET(e, n) {
    const s = this.constructor.elementProperties.get(e), l = this.constructor._$Eu(e, s);
    if (l !== void 0 && s.reflect === !0) {
      const o = (s.converter?.toAttribute !== void 0 ? s.converter : Al).toAttribute(n, s.type);
      this._$Em = e, o == null ? this.removeAttribute(l) : this.setAttribute(l, o), this._$Em = null;
    }
  }
  _$AK(e, n) {
    const s = this.constructor, l = s._$Eh.get(e);
    if (l !== void 0 && this._$Em !== l) {
      const o = s.getPropertyOptions(l), a = typeof o.converter == "function" ? { fromAttribute: o.converter } : o.converter?.fromAttribute !== void 0 ? o.converter : Al;
      this._$Em = l;
      const h = a.fromAttribute(n, o.type);
      this[l] = h ?? this._$Ej?.get(l) ?? h, this._$Em = null;
    }
  }
  requestUpdate(e, n, s, l = !1, o) {
    if (e !== void 0) {
      const a = this.constructor;
      if (l === !1 && (o = this[e]), s ??= a.getPropertyOptions(e), !((s.hasChanged ?? Gr)(o, n) || s.useDefault && s.reflect && o === this._$Ej?.get(e) && !this.hasAttribute(a._$Eu(e, s)))) return;
      this.C(e, n, s);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(e, n, { useDefault: s, reflect: l, wrapped: o }, a) {
    s && !(this._$Ej ??= /* @__PURE__ */ new Map()).has(e) && (this._$Ej.set(e, a ?? n ?? this[e]), o !== !0 || a !== void 0) || (this._$AL.has(e) || (this.hasUpdated || s || (n = void 0), this._$AL.set(e, n)), l === !0 && this._$Em !== e && (this._$Eq ??= /* @__PURE__ */ new Set()).add(e));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (n) {
      Promise.reject(n);
    }
    const e = this.scheduleUpdate();
    return e != null && await e, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
        for (const [l, o] of this._$Ep) this[l] = o;
        this._$Ep = void 0;
      }
      const s = this.constructor.elementProperties;
      if (s.size > 0) for (const [l, o] of s) {
        const { wrapped: a } = o, h = this[l];
        a !== !0 || this._$AL.has(l) || h === void 0 || this.C(l, void 0, o, h);
      }
    }
    let e = !1;
    const n = this._$AL;
    try {
      e = this.shouldUpdate(n), e ? (this.willUpdate(n), this._$EO?.forEach((s) => s.hostUpdate?.()), this.update(n)) : this._$EM();
    } catch (s) {
      throw e = !1, this._$EM(), s;
    }
    e && this._$AE(n);
  }
  willUpdate(e) {
  }
  _$AE(e) {
    this._$EO?.forEach((n) => n.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(e)), this.updated(e);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(e) {
    return !0;
  }
  update(e) {
    this._$Eq &&= this._$Eq.forEach((n) => this._$ET(n, this[n])), this._$EM();
  }
  updated(e) {
  }
  firstUpdated(e) {
  }
};
Rs.elementStyles = [], Rs.shadowRootOptions = { mode: "open" }, Rs[on("elementProperties")] = /* @__PURE__ */ new Map(), Rs[on("finalized")] = /* @__PURE__ */ new Map(), Ca?.({ ReactiveElement: Rs }), (Fn.reactiveElementVersions ??= []).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Vl = globalThis, Gi = (t) => t, Ln = Vl.trustedTypes, Bi = Ln ? Ln.createPolicy("lit-html", { createHTML: (t) => t }) : void 0, Br = "$lit$", Wt = `lit$${Math.random().toFixed(9).slice(2)}$`, jr = "?" + Wt, Ra = `<${jr}>`, rs = document, un = () => rs.createComment(""), hn = (t) => t === null || typeof t != "object" && typeof t != "function", Gl = Array.isArray, Pa = (t) => Gl(t) || typeof t?.[Symbol.iterator] == "function", bl = `[ 	
\f\r]`, Zs = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, ji = /-->/g, qi = />/g, es = RegExp(`>|${bl}(?:([^\\s"'>=/]+)(${bl}*=${bl}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Ki = /'/g, Yi = /"/g, qr = /^(?:script|style|textarea|title)$/i, Ma = (t) => (e, ...n) => ({ _$litType$: t, strings: e, values: n }), I = Ma(1), Ls = Symbol.for("lit-noChange"), K = Symbol.for("lit-nothing"), Ji = /* @__PURE__ */ new WeakMap(), ls = rs.createTreeWalker(rs, 129);
function Kr(t, e) {
  if (!Gl(t) || !t.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return Bi !== void 0 ? Bi.createHTML(e) : e;
}
const Na = (t, e) => {
  const n = t.length - 1, s = [];
  let l, o = e === 2 ? "<svg>" : e === 3 ? "<math>" : "", a = Zs;
  for (let h = 0; h < n; h++) {
    const f = t[h];
    let p, g, m = -1, b = 0;
    for (; b < f.length && (a.lastIndex = b, g = a.exec(f), g !== null); ) b = a.lastIndex, a === Zs ? g[1] === "!--" ? a = ji : g[1] !== void 0 ? a = qi : g[2] !== void 0 ? (qr.test(g[2]) && (l = RegExp("</" + g[2], "g")), a = es) : g[3] !== void 0 && (a = es) : a === es ? g[0] === ">" ? (a = l ?? Zs, m = -1) : g[1] === void 0 ? m = -2 : (m = a.lastIndex - g[2].length, p = g[1], a = g[3] === void 0 ? es : g[3] === '"' ? Yi : Ki) : a === Yi || a === Ki ? a = es : a === ji || a === qi ? a = Zs : (a = es, l = void 0);
    const A = a === es && t[h + 1].startsWith("/>") ? " " : "";
    o += a === Zs ? f + Ra : m >= 0 ? (s.push(p), f.slice(0, m) + Br + f.slice(m) + Wt + A) : f + Wt + (m === -2 ? h : A);
  }
  return [Kr(t, o + (t[n] || "<?>") + (e === 2 ? "</svg>" : e === 3 ? "</math>" : "")), s];
};
class fn {
  constructor({ strings: e, _$litType$: n }, s) {
    let l;
    this.parts = [];
    let o = 0, a = 0;
    const h = e.length - 1, f = this.parts, [p, g] = Na(e, n);
    if (this.el = fn.createElement(p, s), ls.currentNode = this.el.content, n === 2 || n === 3) {
      const m = this.el.content.firstChild;
      m.replaceWith(...m.childNodes);
    }
    for (; (l = ls.nextNode()) !== null && f.length < h; ) {
      if (l.nodeType === 1) {
        if (l.hasAttributes()) for (const m of l.getAttributeNames()) if (m.endsWith(Br)) {
          const b = g[a++], A = l.getAttribute(m).split(Wt), T = /([.?@])?(.*)/.exec(b);
          f.push({ type: 1, index: o, name: T[2], strings: A, ctor: T[1] === "." ? Oa : T[1] === "?" ? Da : T[1] === "@" ? Ha : Un }), l.removeAttribute(m);
        } else m.startsWith(Wt) && (f.push({ type: 6, index: o }), l.removeAttribute(m));
        if (qr.test(l.tagName)) {
          const m = l.textContent.split(Wt), b = m.length - 1;
          if (b > 0) {
            l.textContent = Ln ? Ln.emptyScript : "";
            for (let A = 0; A < b; A++) l.append(m[A], un()), ls.nextNode(), f.push({ type: 2, index: ++o });
            l.append(m[b], un());
          }
        }
      } else if (l.nodeType === 8) if (l.data === jr) f.push({ type: 2, index: o });
      else {
        let m = -1;
        for (; (m = l.data.indexOf(Wt, m + 1)) !== -1; ) f.push({ type: 7, index: o }), m += Wt.length - 1;
      }
      o++;
    }
  }
  static createElement(e, n) {
    const s = rs.createElement("template");
    return s.innerHTML = e, s;
  }
}
function Os(t, e, n = t, s) {
  if (e === Ls) return e;
  let l = s !== void 0 ? n._$Co?.[s] : n._$Cl;
  const o = hn(e) ? void 0 : e._$litDirective$;
  return l?.constructor !== o && (l?._$AO?.(!1), o === void 0 ? l = void 0 : (l = new o(t), l._$AT(t, n, s)), s !== void 0 ? (n._$Co ??= [])[s] = l : n._$Cl = l), l !== void 0 && (e = Os(t, l._$AS(t, e.values), l, s)), e;
}
class La {
  constructor(e, n) {
    this._$AV = [], this._$AN = void 0, this._$AD = e, this._$AM = n;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(e) {
    const { el: { content: n }, parts: s } = this._$AD, l = (e?.creationScope ?? rs).importNode(n, !0);
    ls.currentNode = l;
    let o = ls.nextNode(), a = 0, h = 0, f = s[0];
    for (; f !== void 0; ) {
      if (a === f.index) {
        let p;
        f.type === 2 ? p = new gn(o, o.nextSibling, this, e) : f.type === 1 ? p = new f.ctor(o, f.name, f.strings, this, e) : f.type === 6 && (p = new za(o, this, e)), this._$AV.push(p), f = s[++h];
      }
      a !== f?.index && (o = ls.nextNode(), a++);
    }
    return ls.currentNode = rs, l;
  }
  p(e) {
    let n = 0;
    for (const s of this._$AV) s !== void 0 && (s.strings !== void 0 ? (s._$AI(e, s, n), n += s.strings.length - 2) : s._$AI(e[n])), n++;
  }
}
class gn {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(e, n, s, l) {
    this.type = 2, this._$AH = K, this._$AN = void 0, this._$AA = e, this._$AB = n, this._$AM = s, this.options = l, this._$Cv = l?.isConnected ?? !0;
  }
  get parentNode() {
    let e = this._$AA.parentNode;
    const n = this._$AM;
    return n !== void 0 && e?.nodeType === 11 && (e = n.parentNode), e;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(e, n = this) {
    e = Os(this, e, n), hn(e) ? e === K || e == null || e === "" ? (this._$AH !== K && this._$AR(), this._$AH = K) : e !== this._$AH && e !== Ls && this._(e) : e._$litType$ !== void 0 ? this.$(e) : e.nodeType !== void 0 ? this.T(e) : Pa(e) ? this.k(e) : this._(e);
  }
  O(e) {
    return this._$AA.parentNode.insertBefore(e, this._$AB);
  }
  T(e) {
    this._$AH !== e && (this._$AR(), this._$AH = this.O(e));
  }
  _(e) {
    this._$AH !== K && hn(this._$AH) ? this._$AA.nextSibling.data = e : this.T(rs.createTextNode(e)), this._$AH = e;
  }
  $(e) {
    const { values: n, _$litType$: s } = e, l = typeof s == "number" ? this._$AC(e) : (s.el === void 0 && (s.el = fn.createElement(Kr(s.h, s.h[0]), this.options)), s);
    if (this._$AH?._$AD === l) this._$AH.p(n);
    else {
      const o = new La(l, this), a = o.u(this.options);
      o.p(n), this.T(a), this._$AH = o;
    }
  }
  _$AC(e) {
    let n = Ji.get(e.strings);
    return n === void 0 && Ji.set(e.strings, n = new fn(e)), n;
  }
  k(e) {
    Gl(this._$AH) || (this._$AH = [], this._$AR());
    const n = this._$AH;
    let s, l = 0;
    for (const o of e) l === n.length ? n.push(s = new gn(this.O(un()), this.O(un()), this, this.options)) : s = n[l], s._$AI(o), l++;
    l < n.length && (this._$AR(s && s._$AB.nextSibling, l), n.length = l);
  }
  _$AR(e = this._$AA.nextSibling, n) {
    for (this._$AP?.(!1, !0, n); e !== this._$AB; ) {
      const s = Gi(e).nextSibling;
      Gi(e).remove(), e = s;
    }
  }
  setConnected(e) {
    this._$AM === void 0 && (this._$Cv = e, this._$AP?.(e));
  }
}
class Un {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(e, n, s, l, o) {
    this.type = 1, this._$AH = K, this._$AN = void 0, this.element = e, this.name = n, this._$AM = l, this.options = o, s.length > 2 || s[0] !== "" || s[1] !== "" ? (this._$AH = Array(s.length - 1).fill(new String()), this.strings = s) : this._$AH = K;
  }
  _$AI(e, n = this, s, l) {
    const o = this.strings;
    let a = !1;
    if (o === void 0) e = Os(this, e, n, 0), a = !hn(e) || e !== this._$AH && e !== Ls, a && (this._$AH = e);
    else {
      const h = e;
      let f, p;
      for (e = o[0], f = 0; f < o.length - 1; f++) p = Os(this, h[s + f], n, f), p === Ls && (p = this._$AH[f]), a ||= !hn(p) || p !== this._$AH[f], p === K ? e = K : e !== K && (e += (p ?? "") + o[f + 1]), this._$AH[f] = p;
    }
    a && !l && this.j(e);
  }
  j(e) {
    e === K ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, e ?? "");
  }
}
class Oa extends Un {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(e) {
    this.element[this.name] = e === K ? void 0 : e;
  }
}
class Da extends Un {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(e) {
    this.element.toggleAttribute(this.name, !!e && e !== K);
  }
}
class Ha extends Un {
  constructor(e, n, s, l, o) {
    super(e, n, s, l, o), this.type = 5;
  }
  _$AI(e, n = this) {
    if ((e = Os(this, e, n, 0) ?? K) === Ls) return;
    const s = this._$AH, l = e === K && s !== K || e.capture !== s.capture || e.once !== s.once || e.passive !== s.passive, o = e !== K && (s === K || l);
    l && this.element.removeEventListener(this.name, this, s), o && this.element.addEventListener(this.name, this, e), this._$AH = e;
  }
  handleEvent(e) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, e) : this._$AH.handleEvent(e);
  }
}
class za {
  constructor(e, n, s) {
    this.element = e, this.type = 6, this._$AN = void 0, this._$AM = n, this.options = s;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(e) {
    Os(this, e);
  }
}
const Fa = Vl.litHtmlPolyfillSupport;
Fa?.(fn, gn), (Vl.litHtmlVersions ??= []).push("3.3.3");
const Ua = (t, e, n) => {
  const s = n?.renderBefore ?? e;
  let l = s._$litPart$;
  if (l === void 0) {
    const o = n?.renderBefore ?? null;
    s._$litPart$ = l = new gn(e.insertBefore(un(), o), o, void 0, n ?? {});
  }
  return l._$AI(t), l;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Bl = globalThis;
class Ms extends Rs {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    const e = super.createRenderRoot();
    return this.renderOptions.renderBefore ??= e.firstChild, e;
  }
  update(e) {
    const n = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(e), this._$Do = Ua(n, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return Ls;
  }
}
Ms._$litElement$ = !0, Ms.finalized = !0, Bl.litElementHydrateSupport?.({ LitElement: Ms });
const Ia = Bl.litElementPolyfillSupport;
Ia?.({ LitElement: Ms });
(Bl.litElementVersions ??= []).push("4.2.2");
let Yr = null;
function Jr(t) {
  Yr = t;
}
function Wa() {
  return Yr;
}
class kl extends Ms {
  static properties = {
    api: { attribute: !1 },
    params: { attribute: !1 }
  };
  #e = [];
  constructor() {
    super(), this.api = null, this.params = {};
  }
  connectedCallback() {
    super.connectedCallback(), this.api && this.#s(this.api);
  }
  willUpdate(e) {
    e.has("api") && this.api && this.#e.length === 0 && this.isConnected && this.#s(this.api);
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    for (const e of this.#e) e();
    this.#e = [];
  }
  #s(e) {
    Jr(e), this.#e.push(e.onLocaleChange(() => this.requestUpdate()));
  }
  /** Translation through the HOST dictionary (our `locales` export is merged into it). */
  t(e, n) {
    return this.api ? this.api.i18n.t(e, n) : e;
  }
}
function jl(t, e) {
  customElements.get(t) || customElements.define(t, e);
}
const Va = {
  patester: {
    tabTitle: "Pressure Advance",
    title: "Pressure Advance",
    common: {
      loading: "Loading…",
      default: "default",
      noPrinter: "No active printer",
      configError: "Cannot read the printer config. Is Klipper ready?",
      notInstalled: "The [pa_tester] section is not in the printer config any more.",
      copy: "Copy",
      copied: "Copied",
      copyManually: "Copy the text:"
    },
    help: {
      title: "Help",
      runTitle: "Running a measurement",
      run: "Test only measures and reports. Calibrate also applies the result with SET_PRESSURE_ADVANCE. Empty fields use your [pa_tester] section. Axes must be homed, the extruder hot and the printer not printing. The run takes minutes; you can leave the tab, it keeps running in Klipper and is picked up again when you return.",
      applyTitle: "Apply vs printer.cfg",
      apply: "SET_PRESSURE_ADVANCE works at once but is lost on restart, and SAVE_CONFIG does not store it. Copy the value into the pressure_advance option of your [extruder] section to keep it.",
      chartTitle: "Load cell graph",
      chart: "The trace of the force sensor in the nozzle. It is streamed only while the graph is shown: hide it when you do not need it. Without the raw stream the graph falls back to about 4 samples per second."
    },
    command: {
      label: "Command",
      test: "Test",
      calibrate: "Calibrate",
      testHint: "TEST_PRESSURE_ADVANCE: measures and reports, changes nothing.",
      calibrateHint: "PA_CALIBRATE: measures and applies the result with SET_PRESSURE_ADVANCE."
    },
    method: {
      label: "Method",
      step_response: "Step response",
      search_overshoot: "Search overshoot",
      step_responseHint: "Extrudes at several flows and finds PA from the force response. Result per flow and overall.",
      search_overshootHint: "Searches the PA range for the value without overshoot. Set PA_RANGE to narrow it."
    },
    param: {
      SLOW_FLOW: "Slow flow, mm³/s (above 0)",
      HIGH_FLOW: "High flow, mm³/s: must be greater than slow flow",
      PURGE_LENGTH: "Filament length to purge, mm",
      SEGMENT_TIME: "Duration of one flow segment, s",
      TEST_REPETITIONS: "Repetitions (at least 1)",
      FILTER_WINDOW: "Force filter window, s (above 0, at most 0.04)",
      EXTRUDE_FORCE_SIGN: "Sign of the force while extruding: -1, 0 (auto) or 1",
      PA_RANGE: "min,max of the search: min ≥ 0, max below 2.0, min below max",
      EXTRUDER: "Extruder to test (must be the active one)",
      FORCE_SENSOR: "Load cell to use"
    },
    block: {
      klippy: "Klipper is not ready.",
      running: "A measurement is in progress.",
      printing: "Not available while printing.",
      homing: "Home all axes first.",
      cold: "The extruder is too cold to extrude: heat it up first.",
      noSensor: "No load cell in the printer config.",
      ambiguous: "Several load cells: choose FORCE_SENSOR.",
      invalid: "Invalid values: {fields}"
    },
    run: {
      test: "Run test",
      calibrate: "Calibrate",
      running: "Running…",
      home: "Home all",
      started: "Measuring: the result appears when Klipper finishes the calculation.",
      external: "started elsewhere",
      log: "Console log ({count} lines)",
      applyMeasured: "Apply",
      saveHint: "Applied until restart only. Put the value into [extruder] pressure_advance in printer.cfg to keep it."
    },
    confirm: {
      title: "Calibrate and apply?",
      body: "PA_CALIBRATE changes the pressure advance of the extruder when it finishes. The change is lost on restart unless you save it to printer.cfg.",
      ok: "Calibrate",
      cancel: "Cancel"
    },
    result: {
      title: "Result",
      current: "Current pressure advance of the extruder",
      lastKlipper: "Last result kept by Klipper: {test}, PA {pa}",
      flow: "Flow, mm³/s",
      pa: "Pressure advance",
      overall: "Overall pressure advance",
      tested: "Tested pressure advance",
      overshoot: "overshoot",
      noOvershoot: "no overshoot",
      found: "Found pressure advance",
      corrected: "Corrected for the force filter",
      forceSign: "Detected force sign: {sign}"
    },
    chart: {
      title: "Load cell",
      show: "Show",
      hide: "Hide",
      now: "now",
      min: "min",
      max: "max",
      counts: "counts",
      sec: "s",
      window: "Time window",
      pause: "Pause",
      resume: "Resume",
      clear: "Clear",
      connecting: "Connecting…",
      noData: "Waiting for data…",
      sourceStream: "raw stream",
      sourceStatus: "≈4 Hz",
      sourceStatusHint: "The raw stream is not available: the graph uses the status subscription (about 4 samples per second).",
      tare: "Without calibration the graph shows counts relative to the tare. Tare the cell (LOAD_CELL_TARE) before a measurement."
    },
    guard: {
      printing: "Pressure advance measurement is not allowed while printing.",
      homing: "Home all axes before the pressure advance measurement.",
      cold: "The extruder is too cold for the pressure advance measurement."
    }
  }
}, Ga = {
  patester: {
    tabTitle: "Pressure Advance",
    title: "Pressure Advance",
    common: {
      loading: "Загрузка…",
      default: "по умолчанию",
      noPrinter: "Нет активного принтера",
      configError: "Не удалось прочитать конфигурацию принтера. Klipper готов?",
      notInstalled: "Секции [pa_tester] больше нет в конфигурации принтера.",
      copy: "Копировать",
      copied: "Скопировано",
      copyManually: "Скопируйте текст:"
    },
    help: {
      title: "Справка",
      runTitle: "Запуск измерения",
      run: "Test только измеряет и показывает результат. Calibrate дополнительно применяет его через SET_PRESSURE_ADVANCE. Пустые поля берутся из секции [pa_tester]. Оси должны быть в исходной позиции, экструдер горячим, принтер не печатает. Измерение идёт минуты; со вкладки можно уйти, оно продолжится в Klipper и подхватится при возвращении.",
      applyTitle: "Применение и printer.cfg",
      apply: "SET_PRESSURE_ADVANCE действует сразу, но пропадает при перезапуске, и SAVE_CONFIG его не сохраняет. Чтобы значение осталось, перенесите его в pressure_advance секции [extruder].",
      chartTitle: "График датчика усилия",
      chart: "Сигнал датчика усилия в сопле. Поток идёт, только пока график показан: скрывайте его, когда он не нужен. Без raw-потока график строится по статусу, около 4 отсчётов в секунду."
    },
    command: {
      label: "Команда",
      test: "Тест",
      calibrate: "Калибровка",
      testHint: "TEST_PRESSURE_ADVANCE: измеряет и показывает результат, ничего не меняет.",
      calibrateHint: "PA_CALIBRATE: измеряет и применяет результат через SET_PRESSURE_ADVANCE."
    },
    method: {
      label: "Метод",
      step_response: "Step response",
      search_overshoot: "Search overshoot",
      step_responseHint: "Экструзия на нескольких расходах, PA находится по отклику усилия. Результат по каждому расходу и общий.",
      search_overshootHint: "Поиск значения PA без перерегулирования в заданном диапазоне. Сузить диапазон можно через PA_RANGE."
    },
    param: {
      SLOW_FLOW: "Медленный расход, мм³/с (больше 0)",
      HIGH_FLOW: "Быстрый расход, мм³/с: должен быть больше медленного",
      PURGE_LENGTH: "Длина прутка для прочистки, мм",
      SEGMENT_TIME: "Длительность сегмента одного расхода, с",
      TEST_REPETITIONS: "Число повторов (не меньше 1)",
      FILTER_WINDOW: "Окно фильтра усилия, с (больше 0, не больше 0.04)",
      EXTRUDE_FORCE_SIGN: "Знак усилия при экструзии: -1, 0 (авто) или 1",
      PA_RANGE: "min,max поиска: min ≥ 0, max меньше 2.0, min меньше max",
      EXTRUDER: "Тестируемый экструдер (должен быть активным)",
      FORCE_SENSOR: "Используемый датчик усилия"
    },
    block: {
      klippy: "Klipper не готов.",
      running: "Измерение уже идёт.",
      printing: "Недоступно во время печати.",
      homing: "Сначала выполните парковку всех осей.",
      cold: "Экструдер слишком холодный для экструзии: сначала прогрейте его.",
      noSensor: "В конфигурации принтера нет датчика усилия.",
      ambiguous: "Несколько датчиков усилия: выберите FORCE_SENSOR.",
      invalid: "Неверные значения: {fields}"
    },
    run: {
      test: "Запустить тест",
      calibrate: "Калибровать",
      running: "Выполняется…",
      home: "Парковка",
      started: "Измерение: результат появится, когда Klipper закончит расчёт.",
      external: "запущено не здесь",
      log: "Лог консоли ({count} строк)",
      applyMeasured: "Применить",
      saveHint: "Действует только до перезапуска. Чтобы сохранить, впишите значение в pressure_advance секции [extruder] в printer.cfg."
    },
    confirm: {
      title: "Откалибровать и применить?",
      body: "По окончании PA_CALIBRATE изменит pressure advance экструдера. Изменение пропадёт при перезапуске, если не сохранить его в printer.cfg.",
      ok: "Калибровать",
      cancel: "Отмена"
    },
    result: {
      title: "Результат",
      current: "Текущий pressure advance экструдера",
      lastKlipper: "Последний результат в Klipper: {test}, PA {pa}",
      flow: "Расход, мм³/с",
      pa: "Pressure advance",
      overall: "Общий pressure advance",
      tested: "Проверенный pressure advance",
      overshoot: "перерегулирование",
      noOvershoot: "без перерегулирования",
      found: "Найденный pressure advance",
      corrected: "С поправкой на фильтр усилия",
      forceSign: "Определённый знак усилия: {sign}"
    },
    chart: {
      title: "Датчик усилия",
      show: "Показать",
      hide: "Скрыть",
      now: "сейчас",
      min: "мин",
      max: "макс",
      counts: "отсчётов",
      sec: "с",
      window: "Окно времени",
      pause: "Пауза",
      resume: "Продолжить",
      clear: "Очистить",
      connecting: "Подключение…",
      noData: "Ожидание данных…",
      sourceStream: "raw-поток",
      sourceStatus: "≈4 Гц",
      sourceStatusHint: "Raw-поток недоступен: график строится по подписке на статус (около 4 отсчётов в секунду).",
      tare: "Без калибровки график показывает отсчёты относительно тары. Перед измерением обнулите датчик (LOAD_CELL_TARE)."
    },
    guard: {
      printing: "Измерение pressure advance недоступно во время печати.",
      homing: "Перед измерением pressure advance выполните парковку всех осей.",
      cold: "Экструдер слишком холодный для измерения pressure advance."
    }
  }
};
class Ba extends kl {
  render() {
    return K;
  }
}
const ja = !0, Pe = "u-", qa = "uplot", Ka = Pe + "hz", Ya = Pe + "vt", Ja = Pe + "title", Za = Pe + "wrap", Qa = Pe + "under", Xa = Pe + "over", ec = Pe + "axis", ns = Pe + "off", tc = Pe + "select", sc = Pe + "cursor-x", nc = Pe + "cursor-y", lc = Pe + "cursor-pt", ic = Pe + "legend", rc = Pe + "live", oc = Pe + "inline", ac = Pe + "series", cc = Pe + "marker", Zi = Pe + "label", uc = Pe + "value", nn = "width", ln = "height", Qs = "top", Qi = "bottom", Cs = "left", yl = "right", ql = "#000", Xi = ql + "0", _l = "mousemove", er = "mousedown", wl = "mouseup", tr = "mouseenter", sr = "mouseleave", nr = "dblclick", hc = "resize", fc = "scroll", lr = "change", On = "dppxchange", Kl = "--", Us = typeof window < "u", Tl = Us ? document : null, Ns = Us ? window : null, pc = Us ? navigator : null;
let oe, kn;
function Cl() {
  let t = devicePixelRatio;
  oe != t && (oe = t, kn && Pl(lr, kn, Cl), kn = matchMedia(`(min-resolution: ${oe - 1e-3}dppx) and (max-resolution: ${oe + 1e-3}dppx)`), is(lr, kn, Cl), Ns.dispatchEvent(new CustomEvent(On)));
}
function st(t, e) {
  if (e != null) {
    let n = t.classList;
    !n.contains(e) && n.add(e);
  }
}
function Rl(t, e) {
  let n = t.classList;
  n.contains(e) && n.remove(e);
}
function be(t, e, n) {
  t.style[e] = n + "px";
}
function bt(t, e, n, s) {
  let l = Tl.createElement(t);
  return e != null && st(l, e), n?.insertBefore(l, s), l;
}
function ht(t, e) {
  return bt("div", t, e);
}
const ir = /* @__PURE__ */ new WeakMap();
function Tt(t, e, n, s, l) {
  let o = "translate(" + e + "px," + n + "px)", a = ir.get(t);
  o != a && (t.style.transform = o, ir.set(t, o), e < 0 || n < 0 || e > s || n > l ? st(t, ns) : Rl(t, ns));
}
const rr = /* @__PURE__ */ new WeakMap();
function or(t, e, n) {
  let s = e + n, l = rr.get(t);
  s != l && (rr.set(t, s), t.style.background = e, t.style.borderColor = n);
}
const ar = /* @__PURE__ */ new WeakMap();
function cr(t, e, n, s) {
  let l = e + "" + n, o = ar.get(t);
  l != o && (ar.set(t, l), t.style.height = n + "px", t.style.width = e + "px", t.style.marginLeft = s ? -e / 2 + "px" : 0, t.style.marginTop = s ? -n / 2 + "px" : 0);
}
const Yl = { passive: !0 }, dc = { ...Yl, capture: !0 };
function is(t, e, n, s) {
  e.addEventListener(t, n, s ? dc : Yl);
}
function Pl(t, e, n, s) {
  e.removeEventListener(t, n, Yl);
}
Us && Cl();
function yt(t, e, n, s) {
  let l;
  n = n || 0, s = s || e.length - 1;
  let o = s <= 2147483647;
  for (; s - n > 1; )
    l = o ? n + s >> 1 : nt((n + s) / 2), e[l] < t ? n = l : s = l;
  return t - e[n] <= e[s] - t ? n : s;
}
function Zr(t) {
  return (n, s, l) => {
    let o = -1, a = -1;
    for (let h = s; h <= l; h++)
      if (t(n[h])) {
        o = h;
        break;
      }
    for (let h = l; h >= s; h--)
      if (t(n[h])) {
        a = h;
        break;
      }
    return [o, a];
  };
}
const Qr = (t) => t != null, Xr = (t) => t != null && t > 0, In = Zr(Qr), mc = Zr(Xr);
function gc(t, e, n, s = 0, l = !1) {
  let o = l ? mc : In, a = l ? Xr : Qr;
  [e, n] = o(t, e, n);
  let h = t[e], f = t[e];
  if (e > -1)
    if (s == 1)
      h = t[e], f = t[n];
    else if (s == -1)
      h = t[n], f = t[e];
    else
      for (let p = e; p <= n; p++) {
        let g = t[p];
        a(g) && (g < h ? h = g : g > f && (f = g));
      }
  return [h ?? fe, f ?? -fe];
}
function Wn(t, e, n, s) {
  let l = fr(t), o = fr(e);
  t == e && (l == -1 ? (t *= n, e /= n) : (t /= n, e *= n));
  let a = n == 10 ? Nt : eo, h = l == 1 ? nt : ft, f = o == 1 ? ft : nt, p = h(a(Re(t))), g = f(a(Re(e))), m = Ds(n, p), b = Ds(n, g);
  return n == 10 && (p < 0 && (m = pe(m, -p)), g < 0 && (b = pe(b, -g))), s || n == 2 ? (t = m * l, e = b * o) : (t = lo(t, m), e = Vn(e, b)), [t, e];
}
function Jl(t, e, n, s) {
  let l = Wn(t, e, n, s);
  return t == 0 && (l[0] = 0), e == 0 && (l[1] = 0), l;
}
const Zl = 0.1, ur = {
  mode: 3,
  pad: Zl
}, an = {
  pad: 0,
  soft: null,
  mode: 0
}, vc = {
  min: an,
  max: an
};
function Dn(t, e, n, s) {
  return Gn(n) ? hr(t, e, n) : (an.pad = n, an.soft = s ? 0 : null, an.mode = s ? 3 : 0, hr(t, e, vc));
}
function ie(t, e) {
  return t ?? e;
}
function bc(t, e, n) {
  for (e = ie(e, 0), n = ie(n, t.length - 1); e <= n; ) {
    if (t[e] != null)
      return !0;
    e++;
  }
  return !1;
}
function hr(t, e, n) {
  let s = n.min, l = n.max, o = ie(s.pad, 0), a = ie(l.pad, 0), h = ie(s.hard, -fe), f = ie(l.hard, fe), p = ie(s.soft, fe), g = ie(l.soft, -fe), m = ie(s.mode, 0), b = ie(l.mode, 0), A = e - t, T = Nt(A), H = qe(Re(t), Re(e)), F = Nt(H), W = Re(F - T);
  (A < 1e-24 || W > 10) && (A = 0, (t == 0 || e == 0) && (A = 1e-24, m == 2 && p != fe && (o = 0), b == 2 && g != -fe && (a = 0)));
  let S = A || H || 1e3, z = Nt(S), x = Ds(10, nt(z)), J = S * (A == 0 ? t == 0 ? 0.1 : 1 : o), P = pe(lo(t - J, x / 10), 24), Z = t >= p && (m == 1 || m == 3 && P <= p || m == 2 && P >= p) ? p : fe, j = qe(h, P < Z && t >= Z ? Z : _t(Z, P)), ee = S * (A == 0 ? e == 0 ? 0.1 : 1 : a), B = pe(Vn(e + ee, x / 10), 24), $ = e <= g && (b == 1 || b == 3 && B >= g || b == 2 && B <= g) ? g : -fe, Y = _t(f, B > $ && e <= $ ? $ : qe($, B));
  return j == Y && j == 0 && (Y = 100), [j, Y];
}
const yc = new Intl.NumberFormat(Us ? pc.language : "en-US"), Ql = (t) => yc.format(t), lt = Math, Mn = lt.PI, Re = lt.abs, nt = lt.floor, Ce = lt.round, ft = lt.ceil, _t = lt.min, qe = lt.max, Ds = lt.pow, fr = lt.sign, Nt = lt.log10, eo = lt.log2, _c = (t, e = 1) => lt.sinh(t) * e, Sl = (t, e = 1) => lt.asinh(t / e), fe = 1 / 0;
function pr(t) {
  return (Nt((t ^ t >> 31) - (t >> 31)) | 0) + 1;
}
function Ml(t, e, n) {
  return _t(qe(t, e), n);
}
function to(t) {
  return typeof t == "function";
}
function te(t) {
  return to(t) ? t : () => t;
}
const wc = () => {
}, so = (t) => t, no = (t, e) => e, Sc = (t) => null, dr = (t) => !0, mr = (t, e) => t == e, xc = /\.\d*?(?=9{6,}|0{6,})/gm, os = (t) => {
  if (ro(t) || Vt.has(t))
    return t;
  const e = `${t}`, n = e.match(xc);
  if (n == null)
    return t;
  let s = n[0].length - 1;
  if (e.indexOf("e-") != -1) {
    let [l, o] = e.split("e");
    return +`${os(l)}e${o}`;
  }
  return pe(t, s);
};
function ts(t, e) {
  return os(pe(os(t / e)) * e);
}
function Vn(t, e) {
  return os(ft(os(t / e)) * e);
}
function lo(t, e) {
  return os(nt(os(t / e)) * e);
}
function pe(t, e = 0) {
  if (ro(t))
    return t;
  let n = 10 ** e, s = t * n * (1 + Number.EPSILON);
  return Ce(s) / n;
}
const Vt = /* @__PURE__ */ new Map();
function io(t) {
  return (("" + t).split(".")[1] || "").length;
}
function pn(t, e, n, s) {
  let l = [], o = s.map(io);
  for (let a = e; a < n; a++) {
    let h = Re(a), f = pe(Ds(t, a), h);
    for (let p = 0; p < s.length; p++) {
      let g = t == 10 ? +`${s[p]}e${a}` : s[p] * f, m = (a >= 0 ? 0 : h) + (a >= o[p] ? 0 : o[p]), b = t == 10 ? g : pe(g, m);
      l.push(b), Vt.set(b, m);
    }
  }
  return l;
}
const cn = {}, Xl = [], Hs = [null, null], It = Array.isArray, ro = Number.isInteger, $c = (t) => t === void 0;
function gr(t) {
  return typeof t == "string";
}
function Gn(t) {
  let e = !1;
  if (t != null) {
    let n = t.constructor;
    e = n == null || n == Object;
  }
  return e;
}
function Ec(t) {
  return t != null && typeof t == "object";
}
const Ac = Object.getPrototypeOf(Uint8Array), oo = "__proto__";
function zs(t, e = Gn) {
  let n;
  if (It(t)) {
    let s = t.find((l) => l != null);
    if (It(s) || e(s)) {
      n = Array(t.length);
      for (let l = 0; l < t.length; l++)
        n[l] = zs(t[l], e);
    } else
      n = t.slice();
  } else if (t instanceof Ac)
    n = t.slice();
  else if (e(t)) {
    n = {};
    for (let s in t)
      s != oo && (n[s] = zs(t[s], e));
  } else
    n = t;
  return n;
}
function Ae(t) {
  let e = arguments;
  for (let n = 1; n < e.length; n++) {
    let s = e[n];
    for (let l in s)
      l != oo && (Gn(t[l]) ? Ae(t[l], zs(s[l])) : t[l] = zs(s[l]));
  }
  return t;
}
const kc = 0, Tc = 1, Cc = 2;
function Rc(t, e, n) {
  for (let s = 0, l, o = -1; s < e.length; s++) {
    let a = e[s];
    if (a > o) {
      for (l = a - 1; l >= 0 && t[l] == null; )
        t[l--] = null;
      for (l = a + 1; l < n && t[l] == null; )
        t[o = l++] = null;
    }
  }
}
function Pc(t, e) {
  if (Lc(t)) {
    let a = t[0].slice();
    for (let h = 1; h < t.length; h++)
      a.push(...t[h].slice(1));
    return Oc(a[0]) || (a = Nc(a)), a;
  }
  let n = /* @__PURE__ */ new Set();
  for (let a = 0; a < t.length; a++) {
    let f = t[a][0], p = f.length;
    for (let g = 0; g < p; g++)
      n.add(f[g]);
  }
  let s = [Array.from(n).sort((a, h) => a - h)], l = s[0].length, o = /* @__PURE__ */ new Map();
  for (let a = 0; a < l; a++)
    o.set(s[0][a], a);
  for (let a = 0; a < t.length; a++) {
    let h = t[a], f = h[0];
    for (let p = 1; p < h.length; p++) {
      let g = h[p], m = Array(l).fill(void 0), b = e ? e[a][p] : Tc, A = [];
      for (let T = 0; T < g.length; T++) {
        let H = g[T], F = o.get(f[T]);
        H === null ? b != kc && (m[F] = H, b == Cc && A.push(F)) : m[F] = H;
      }
      Rc(m, A, l), s.push(m);
    }
  }
  return s;
}
const Mc = typeof queueMicrotask > "u" ? (t) => Promise.resolve().then(t) : queueMicrotask;
function Nc(t) {
  let e = t[0], n = e.length, s = Array(n);
  for (let o = 0; o < s.length; o++)
    s[o] = o;
  s.sort((o, a) => e[o] - e[a]);
  let l = [];
  for (let o = 0; o < t.length; o++) {
    let a = t[o], h = Array(n);
    for (let f = 0; f < n; f++)
      h[f] = a[s[f]];
    l.push(h);
  }
  return l;
}
function Lc(t) {
  let e = t[0][0], n = e.length;
  for (let s = 1; s < t.length; s++) {
    let l = t[s][0];
    if (l.length != n)
      return !1;
    if (l != e) {
      for (let o = 0; o < n; o++)
        if (l[o] != e[o])
          return !1;
    }
  }
  return !0;
}
function Oc(t, e = 100) {
  const n = t.length;
  if (n <= 1)
    return !0;
  let s = 0, l = n - 1;
  for (; s <= l && t[s] == null; )
    s++;
  for (; l >= s && t[l] == null; )
    l--;
  if (l <= s)
    return !0;
  const o = qe(1, nt((l - s + 1) / e));
  for (let a = t[s], h = s + o; h <= l; h += o) {
    const f = t[h];
    if (f != null) {
      if (f <= a)
        return !1;
      a = f;
    }
  }
  return !0;
}
const ao = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
], co = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday"
];
function uo(t) {
  return t.slice(0, 3);
}
const Dc = co.map(uo), Hc = ao.map(uo), zc = {
  MMMM: ao,
  MMM: Hc,
  WWWW: co,
  WWW: Dc
};
function Xs(t) {
  return (t < 10 ? "0" : "") + t;
}
function Fc(t) {
  return (t < 10 ? "00" : t < 100 ? "0" : "") + t;
}
const Uc = {
  // 2019
  YYYY: (t) => t.getFullYear(),
  // 19
  YY: (t) => (t.getFullYear() + "").slice(2),
  // July
  MMMM: (t, e) => e.MMMM[t.getMonth()],
  // Jul
  MMM: (t, e) => e.MMM[t.getMonth()],
  // 07
  MM: (t) => Xs(t.getMonth() + 1),
  // 7
  M: (t) => t.getMonth() + 1,
  // 09
  DD: (t) => Xs(t.getDate()),
  // 9
  D: (t) => t.getDate(),
  // Monday
  WWWW: (t, e) => e.WWWW[t.getDay()],
  // Mon
  WWW: (t, e) => e.WWW[t.getDay()],
  // 03
  HH: (t) => Xs(t.getHours()),
  // 3
  H: (t) => t.getHours(),
  // 9 (12hr, unpadded)
  h: (t) => {
    let e = t.getHours();
    return e == 0 ? 12 : e > 12 ? e - 12 : e;
  },
  // AM
  AA: (t) => t.getHours() >= 12 ? "PM" : "AM",
  // am
  aa: (t) => t.getHours() >= 12 ? "pm" : "am",
  // a
  a: (t) => t.getHours() >= 12 ? "p" : "a",
  // 09
  mm: (t) => Xs(t.getMinutes()),
  // 9
  m: (t) => t.getMinutes(),
  // 09
  ss: (t) => Xs(t.getSeconds()),
  // 9
  s: (t) => t.getSeconds(),
  // 374
  fff: (t) => Fc(t.getMilliseconds())
};
function ei(t, e) {
  e = e || zc;
  let n = [], s = /\{([a-z]+)\}|[^{]+/gi, l;
  for (; l = s.exec(t); )
    n.push(l[0][0] == "{" ? Uc[l[1]] : l[0]);
  return (o) => {
    let a = "";
    for (let h = 0; h < n.length; h++)
      a += typeof n[h] == "string" ? n[h] : n[h](o, e);
    return a;
  };
}
const Ic = new Intl.DateTimeFormat().resolvedOptions().timeZone;
function Wc(t, e) {
  let n;
  return e == "UTC" || e == "Etc/UTC" ? n = new Date(+t + t.getTimezoneOffset() * 6e4) : e == Ic ? n = t : (n = new Date(t.toLocaleString("en-US", { timeZone: e })), n.setMilliseconds(t.getMilliseconds())), n;
}
const ho = (t) => t % 1 == 0, Hn = [1, 2, 2.5, 5], Vc = pn(10, -32, 0, Hn), fo = pn(10, 0, 32, Hn), Gc = fo.filter(ho), ss = Vc.concat(fo), ti = `
`, po = "{YYYY}", vr = ti + po, mo = "{M}/{D}", rn = ti + mo, Tn = rn + "/{YY}", go = "{aa}", Bc = "{h}:{mm}", Ps = Bc + go, br = ti + Ps, yr = ":{ss}", ce = null;
function vo(t) {
  let e = t * 1e3, n = e * 60, s = n * 60, l = s * 24, o = l * 30, a = l * 365, f = (t == 1 ? pn(10, 0, 3, Hn).filter(ho) : pn(10, -3, 0, Hn)).concat([
    // minute divisors (# of secs)
    e,
    e * 5,
    e * 10,
    e * 15,
    e * 30,
    // hour divisors (# of mins)
    n,
    n * 5,
    n * 10,
    n * 15,
    n * 30,
    // day divisors (# of hrs)
    s,
    s * 2,
    s * 3,
    s * 4,
    s * 6,
    s * 8,
    s * 12,
    // month divisors TODO: need more?
    l,
    l * 2,
    l * 3,
    l * 4,
    l * 5,
    l * 6,
    l * 7,
    l * 8,
    l * 9,
    l * 10,
    l * 15,
    // year divisors (# months, approx)
    o,
    o * 2,
    o * 3,
    o * 4,
    o * 6,
    // century divisors
    a,
    a * 2,
    a * 5,
    a * 10,
    a * 25,
    a * 50,
    a * 100
  ]);
  const p = [
    //   tick incr    default          year                    month   day                   hour    min       sec   mode
    [a, po, ce, ce, ce, ce, ce, ce, 1],
    [l * 28, "{MMM}", vr, ce, ce, ce, ce, ce, 1],
    [l, mo, vr, ce, ce, ce, ce, ce, 1],
    [s, "{h}" + go, Tn, ce, rn, ce, ce, ce, 1],
    [n, Ps, Tn, ce, rn, ce, ce, ce, 1],
    [e, yr, Tn + " " + Ps, ce, rn + " " + Ps, ce, br, ce, 1],
    [t, yr + ".{fff}", Tn + " " + Ps, ce, rn + " " + Ps, ce, br, ce, 1]
  ];
  function g(m) {
    return (b, A, T, H, F, W) => {
      let S = [], z = F >= a, x = F >= o && F < a, J = m(T), P = pe(J * t, 3), Z = xl(J.getFullYear(), z ? 0 : J.getMonth(), x || z ? 1 : J.getDate()), j = pe(Z * t, 3);
      if (x || z) {
        let ee = x ? F / o : 0, B = z ? F / a : 0, $ = P == j ? P : pe(xl(Z.getFullYear() + B, Z.getMonth() + ee, 1) * t, 3), Y = new Date(Ce($ / t)), M = Y.getFullYear(), V = Y.getMonth();
        for (let D = 0; $ <= H; D++) {
          let se = xl(M + B * D, V + ee * D, 1), O = se - m(pe(se * t, 3));
          $ = pe((+se + O) * t, 3), $ <= H && S.push($);
        }
      } else {
        let ee = F >= l ? l : F, B = nt(T) - nt(P), $ = j + B + Vn(P - j, ee);
        S.push($);
        let Y = m($), M = Y.getHours() + Y.getMinutes() / n + Y.getSeconds() / s, V = F / s, D = b.axes[A]._space, se = W / D;
        for (; $ = pe($ + F, t == 1 ? 0 : 3), !($ > H); )
          if (V > 1) {
            let O = nt(pe(M + V, 6)) % 24, ne = m($).getHours() - O;
            ne > 1 && (ne = -1), $ -= ne * s, M = (M + V) % 24;
            let ue = S[S.length - 1];
            pe(($ - ue) / F, 3) * se >= 0.7 && S.push($);
          } else
            S.push($);
      }
      return S;
    };
  }
  return [
    f,
    p,
    g
  ];
}
const [jc, qc, Kc] = vo(1), [Yc, Jc, Zc] = vo(1e-3);
pn(2, -53, 53, [1]);
function _r(t, e) {
  return t.map((n) => n.map(
    (s, l) => l == 0 || l == 8 || s == null ? s : e(l == 1 || n[8] == 0 ? s : n[1] + s)
  ));
}
function wr(t, e) {
  return (n, s, l, o, a) => {
    let h = e.find((T) => a >= T[0]) || e[e.length - 1], f, p, g, m, b, A;
    return s.map((T) => {
      let H = t(T), F = H.getFullYear(), W = H.getMonth(), S = H.getDate(), z = H.getHours(), x = H.getMinutes(), J = H.getSeconds(), P = F != f && h[2] || W != p && h[3] || S != g && h[4] || z != m && h[5] || x != b && h[6] || J != A && h[7] || h[1];
      return f = F, p = W, g = S, m = z, b = x, A = J, P(H);
    });
  };
}
function Qc(t, e) {
  let n = ei(e);
  return (s, l, o, a, h) => l.map((f) => n(t(f)));
}
function xl(t, e, n) {
  return new Date(t, e, n);
}
function Sr(t, e) {
  return e(t);
}
const Xc = "{YYYY}-{MM}-{DD} {h}:{mm}{aa}";
function xr(t, e) {
  return (n, s, l, o) => o == null ? Kl : e(t(s));
}
function eu(t, e) {
  let n = t.series[e];
  return n.width ? n.stroke(t, e) : n.points.width ? n.points.stroke(t, e) : null;
}
function tu(t, e) {
  return t.series[e].fill(t, e);
}
const su = {
  show: !0,
  live: !0,
  isolate: !1,
  mount: wc,
  markers: {
    show: !0,
    width: 2,
    stroke: eu,
    fill: tu,
    dash: "solid"
  },
  idx: null,
  idxs: null,
  values: []
};
function nu(t, e) {
  let n = t.cursor.points, s = ht(), l = n.size(t, e);
  be(s, nn, l), be(s, ln, l);
  let o = l / -2;
  be(s, "marginLeft", o), be(s, "marginTop", o);
  let a = n.width(t, e, l);
  return a && be(s, "borderWidth", a), s;
}
function lu(t, e) {
  let n = t.series[e].points;
  return n._fill || n._stroke;
}
function iu(t, e) {
  let n = t.series[e].points;
  return n._stroke || n._fill;
}
function ru(t, e) {
  return t.series[e].points.size;
}
const $l = [0, 0];
function ou(t, e, n) {
  return $l[0] = e, $l[1] = n, $l;
}
function Cn(t, e, n, s = !0) {
  return (l) => {
    l.button == 0 && (!s || l.target == e) && n(l);
  };
}
function El(t, e, n, s = !0) {
  return (l) => {
    (!s || l.target == e) && n(l);
  };
}
const au = {
  show: !0,
  x: !0,
  y: !0,
  lock: !1,
  move: ou,
  points: {
    one: !1,
    show: nu,
    size: ru,
    width: 0,
    stroke: iu,
    fill: lu
  },
  bind: {
    mousedown: Cn,
    mouseup: Cn,
    click: Cn,
    // legend clicks, not .u-over clicks
    dblclick: Cn,
    mousemove: El,
    mouseleave: El,
    mouseenter: El
  },
  drag: {
    setScale: !0,
    x: !0,
    y: !1,
    dist: 0,
    uni: null,
    click: (t, e) => {
      e.stopPropagation(), e.stopImmediatePropagation();
    },
    _x: !1,
    _y: !1
  },
  focus: {
    dist: (t, e, n, s, l) => s - l,
    prox: -1,
    bias: 0
  },
  hover: {
    skip: [void 0],
    prox: null,
    bias: 0
  },
  left: -10,
  top: -10,
  idx: null,
  dataIdx: null,
  idxs: null,
  event: null
}, bo = {
  show: !0,
  stroke: "rgba(0,0,0,0.07)",
  width: 2
  //	dash: [],
}, si = Ae({}, bo, {
  filter: no
}), yo = Ae({}, si, {
  size: 10
}), _o = Ae({}, bo, {
  show: !1
}), ni = '12px system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"', wo = "bold " + ni, So = 1.5, $r = {
  show: !0,
  scale: "x",
  stroke: ql,
  space: 50,
  gap: 5,
  alignTo: 1,
  size: 50,
  labelGap: 0,
  labelSize: 30,
  labelFont: wo,
  side: 2,
  //	class: "x-vals",
  //	incrs: timeIncrs,
  //	values: timeVals,
  //	filter: retArg1,
  grid: si,
  ticks: yo,
  border: _o,
  font: ni,
  lineGap: So,
  rotate: 0
}, cu = "Value", uu = "Time", Er = {
  show: !0,
  scale: "x",
  auto: !1,
  sorted: 1,
  //	label: "Time",
  //	value: v => stamp(new Date(v * 1e3)),
  // internal caches
  min: fe,
  max: -fe,
  idxs: []
};
function hu(t, e, n, s, l) {
  return e.map((o) => o == null ? "" : Ql(o));
}
function fu(t, e, n, s, l, o, a) {
  let h = [], f = Vt.get(l) || 0;
  n = a ? n : pe(Vn(n, l), f);
  for (let p = n; p <= s; p = pe(p + l, f))
    h.push(Object.is(p, -0) ? 0 : p);
  return h;
}
function Nl(t, e, n, s, l, o, a) {
  const h = [], f = t.scales[t.axes[e].scale].log, p = f == 10 ? Nt : eo, g = nt(p(n));
  l = Ds(f, g), f == 10 && (l = ss[yt(l, ss)]);
  let m = n, b = l * f;
  f == 10 && (b = ss[yt(b, ss)]);
  do
    h.push(m), m = m + l, f == 10 && !Vt.has(m) && (m = pe(m, Vt.get(l))), m >= b && (l = m, b = l * f, f == 10 && (b = ss[yt(b, ss)]));
  while (m <= s);
  return h;
}
function pu(t, e, n, s, l, o, a) {
  let f = t.scales[t.axes[e].scale].asinh, p = s > f ? Nl(t, e, qe(f, n), s, l) : [f], g = s >= 0 && n <= 0 ? [0] : [];
  return (n < -f ? Nl(t, e, qe(f, -s), -n, l) : [f]).reverse().map((b) => -b).concat(g, p);
}
const xo = /./, du = /[12357]/, mu = /[125]/, Ar = /1/, Ll = (t, e, n, s) => t.map((l, o) => e == 4 && l == 0 || o % s == 0 && n.test(l.toExponential()[l < 0 ? 1 : 0]) ? l : null);
function gu(t, e, n, s, l) {
  let o = t.axes[n], a = o.scale, h = t.scales[a], f = t.valToPos, p = o._space, g = f(10, a), m = f(9, a) - g >= p ? xo : f(7, a) - g >= p ? du : f(5, a) - g >= p ? mu : Ar;
  if (m == Ar) {
    let b = Re(f(1, a) - g);
    if (b < p)
      return Ll(e.slice().reverse(), h.distr, m, ft(p / b)).reverse();
  }
  return Ll(e, h.distr, m, 1);
}
function vu(t, e, n, s, l) {
  let o = t.axes[n], a = o.scale, h = o._space, f = t.valToPos, p = Re(f(1, a) - f(2, a));
  return p < h ? Ll(e.slice().reverse(), 3, xo, ft(h / p)).reverse() : e;
}
function bu(t, e, n, s) {
  return s == null ? Kl : e == null ? "" : Ql(e);
}
const kr = {
  show: !0,
  scale: "y",
  stroke: ql,
  space: 30,
  gap: 5,
  alignTo: 1,
  size: 50,
  labelGap: 0,
  labelSize: 30,
  labelFont: wo,
  side: 3,
  //	class: "y-vals",
  //	incrs: numIncrs,
  //	values: (vals, space) => vals,
  //	filter: retArg1,
  grid: si,
  ticks: yo,
  border: _o,
  font: ni,
  lineGap: So,
  rotate: 0
};
function yu(t, e) {
  let n = 3 + (t || 1) * 2;
  return pe(n * e, 3);
}
function _u(t, e) {
  let { scale: n, idxs: s } = t.series[0], l = t._data[0], o = t.valToPos(l[s[0]], n, !0), a = t.valToPos(l[s[1]], n, !0), h = Re(a - o), f = t.series[e], p = h / (f.points.space * oe);
  return s[1] - s[0] <= p;
}
const Tr = {
  scale: null,
  auto: !0,
  sorted: 0,
  // internal caches
  min: fe,
  max: -fe
}, $o = (t, e, n, s, l) => l, Cr = {
  show: !0,
  auto: !0,
  sorted: 0,
  gaps: $o,
  alpha: 1,
  facets: [
    Ae({}, Tr, { scale: "x" }),
    Ae({}, Tr, { scale: "y" })
  ]
}, Rr = {
  scale: "y",
  auto: !0,
  sorted: 0,
  show: !0,
  spanGaps: !1,
  gaps: $o,
  alpha: 1,
  points: {
    show: _u,
    filter: null
    //  paths:
    //	stroke: "#000",
    //	fill: "#fff",
    //	width: 1,
    //	size: 10,
  },
  //	label: "Value",
  //	value: v => v,
  values: null,
  // internal caches
  min: fe,
  max: -fe,
  idxs: [],
  path: null,
  clip: null
};
function wu(t, e, n, s, l) {
  return n / 10;
}
const Eo = {
  time: ja,
  auto: !0,
  distr: 1,
  log: 10,
  asinh: 1,
  min: null,
  max: null,
  dir: 1,
  ori: 0
}, Su = Ae({}, Eo, {
  time: !1,
  ori: 1
}), Pr = {};
function Ao(t, e) {
  let n = Pr[t];
  return n || (n = {
    key: t,
    plots: [],
    sub(s) {
      n.plots.push(s);
    },
    unsub(s) {
      n.plots = n.plots.filter((l) => l != s);
    },
    pub(s, l, o, a, h, f, p) {
      for (let g = 0; g < n.plots.length; g++)
        n.plots[g] != l && n.plots[g].pub(s, l, o, a, h, f, p);
    }
  }, t != null && (Pr[t] = n)), n;
}
const Fs = 1, Ol = 2;
function as(t, e, n) {
  const s = t.mode, l = t.series[e], o = s == 2 ? t._data[e] : t._data, a = t.scales, h = t.bbox;
  let f = o[0], p = s == 2 ? o[1] : o[e], g = s == 2 ? a[l.facets[0].scale] : a[t.series[0].scale], m = s == 2 ? a[l.facets[1].scale] : a[l.scale], b = h.left, A = h.top, T = h.width, H = h.height, F = t.valToPosH, W = t.valToPosV;
  return g.ori == 0 ? n(
    l,
    f,
    p,
    g,
    m,
    F,
    W,
    b,
    A,
    T,
    H,
    jn,
    Is,
    Kn,
    To,
    Ro
  ) : n(
    l,
    f,
    p,
    g,
    m,
    W,
    F,
    A,
    b,
    H,
    T,
    qn,
    Ws,
    ri,
    Co,
    Po
  );
}
function li(t, e) {
  let n = 0, s = 0, l = ie(t.bands, Xl);
  for (let o = 0; o < l.length; o++) {
    let a = l[o];
    a.series[0] == e ? n = a.dir : a.series[1] == e && (a.dir == 1 ? s |= 1 : s |= 2);
  }
  return [
    n,
    s == 1 ? -1 : (
      // neg only
      s == 2 ? 1 : (
        // pos only
        s == 3 ? 2 : (
          // both
          0
        )
      )
    )
  ];
}
function xu(t, e, n, s, l) {
  let o = t.mode, a = t.series[e], h = o == 2 ? a.facets[1].scale : a.scale, f = t.scales[h];
  return l == -1 ? f.min : l == 1 ? f.max : f.distr == 3 ? f.dir == 1 ? f.min : f.max : 0;
}
function Lt(t, e, n, s, l, o) {
  return as(t, e, (a, h, f, p, g, m, b, A, T, H, F) => {
    let W = a.pxRound;
    const S = p.dir * (p.ori == 0 ? 1 : -1), z = p.ori == 0 ? Is : Ws;
    let x, J;
    S == 1 ? (x = n, J = s) : (x = s, J = n);
    let P = W(m(h[x], p, H, A)), Z = W(b(f[x], g, F, T)), j = W(m(h[J], p, H, A)), ee = W(b(o == 1 ? g.max : g.min, g, F, T)), B = new Path2D(l);
    return z(B, j, ee), z(B, P, ee), z(B, P, Z), B;
  });
}
function Bn(t, e, n, s, l, o) {
  let a = null;
  if (t.length > 0) {
    a = new Path2D();
    const h = e == 0 ? Kn : ri;
    let f = n;
    for (let m = 0; m < t.length; m++) {
      let b = t[m];
      if (b[1] > b[0]) {
        let A = b[0] - f;
        A > 0 && h(a, f, s, A, s + o), f = b[1];
      }
    }
    let p = n + l - f, g = 10;
    p > 0 && h(a, f, s - g / 2, p, s + o + g);
  }
  return a;
}
function $u(t, e, n) {
  let s = t[t.length - 1];
  s && s[0] == e ? s[1] = n : t.push([e, n]);
}
function ii(t, e, n, s, l, o, a) {
  let h = [], f = t.length;
  for (let p = l == 1 ? n : s; p >= n && p <= s; p += l)
    if (e[p] === null) {
      let m = p, b = p;
      if (l == 1)
        for (; ++p <= s && e[p] === null; )
          b = p;
      else
        for (; --p >= n && e[p] === null; )
          b = p;
      let A = o(t[m]), T = b == m ? A : o(t[b]), H = m - l;
      A = a <= 0 && H >= 0 && H < f ? o(t[H]) : A;
      let W = b + l;
      T = a >= 0 && W >= 0 && W < f ? o(t[W]) : T, T >= A && h.push([A, T]);
    }
  return h;
}
function Mr(t) {
  return t == 0 ? so : t == 1 ? Ce : (e) => ts(e, t);
}
function ko(t) {
  let e = t == 0 ? jn : qn, n = t == 0 ? (l, o, a, h, f, p) => {
    l.arcTo(o, a, h, f, p);
  } : (l, o, a, h, f, p) => {
    l.arcTo(a, o, f, h, p);
  }, s = t == 0 ? (l, o, a, h, f) => {
    l.rect(o, a, h, f);
  } : (l, o, a, h, f) => {
    l.rect(a, o, f, h);
  };
  return (l, o, a, h, f, p = 0, g = 0) => {
    p == 0 && g == 0 ? s(l, o, a, h, f) : (p = _t(p, h / 2, f / 2), g = _t(g, h / 2, f / 2), e(l, o + p, a), n(l, o + h, a, o + h, a + f, p), n(l, o + h, a + f, o, a + f, g), n(l, o, a + f, o, a, g), n(l, o, a, o + h, a, p), l.closePath());
  };
}
const jn = (t, e, n) => {
  t.moveTo(e, n);
}, qn = (t, e, n) => {
  t.moveTo(n, e);
}, Is = (t, e, n) => {
  t.lineTo(e, n);
}, Ws = (t, e, n) => {
  t.lineTo(n, e);
}, Kn = ko(0), ri = ko(1), To = (t, e, n, s, l, o) => {
  t.arc(e, n, s, l, o);
}, Co = (t, e, n, s, l, o) => {
  t.arc(n, e, s, l, o);
}, Ro = (t, e, n, s, l, o, a) => {
  t.bezierCurveTo(e, n, s, l, o, a);
}, Po = (t, e, n, s, l, o, a) => {
  t.bezierCurveTo(n, e, l, s, a, o);
};
function Mo(t) {
  return (e, n, s, l, o) => as(e, n, (a, h, f, p, g, m, b, A, T, H, F) => {
    let { pxRound: W, points: S } = a, z, x;
    p.ori == 0 ? (z = jn, x = To) : (z = qn, x = Co);
    const J = pe(S.width * oe, 3);
    let P = (S.size - S.width) / 2 * oe, Z = pe(P * 2, 3), j = new Path2D(), ee = new Path2D(), { left: B, top: $, width: Y, height: M } = e.bbox;
    Kn(
      ee,
      B - Z,
      $ - Z,
      Y + Z * 2,
      M + Z * 2
    );
    const V = (D) => {
      if (f[D] != null) {
        let se = W(m(h[D], p, H, A)), O = W(b(f[D], g, F, T));
        z(j, se + P, O), x(j, se, O, P, 0, Mn * 2);
      }
    };
    if (o)
      o.forEach(V);
    else
      for (let D = s; D <= l; D++)
        V(D);
    return {
      stroke: J > 0 ? j : null,
      fill: j,
      clip: ee,
      flags: Fs | Ol
    };
  });
}
function No(t) {
  return (e, n, s, l, o, a) => {
    s != l && (o != s && a != s && t(e, n, s), o != l && a != l && t(e, n, l), t(e, n, a));
  };
}
const Eu = No(Is), Au = No(Ws);
function Lo(t) {
  const e = ie(t?.alignGaps, 0);
  return (n, s, l, o) => as(n, s, (a, h, f, p, g, m, b, A, T, H, F) => {
    [l, o] = In(f, l, o);
    let W = a.pxRound, S = (M) => W(m(M, p, H, A)), z = (M) => W(b(M, g, F, T)), x, J;
    p.ori == 0 ? (x = Is, J = Eu) : (x = Ws, J = Au);
    const P = p.dir * (p.ori == 0 ? 1 : -1), Z = { stroke: new Path2D(), fill: null, clip: null, band: null, gaps: null, flags: Fs }, j = Z.stroke;
    let ee = !1;
    if (o - l >= H * 4) {
      let M = (N) => n.posToVal(N, p.key, !0), V = null, D = null, se, O, Ke, ye = S(h[P == 1 ? l : o]), ne = S(h[l]), ue = S(h[o]), Q = M(P == 1 ? ne + 1 : ue - 1);
      for (let N = P == 1 ? l : o; N >= l && N <= o; N += P) {
        let ke = h[N], _e = (P == 1 ? ke < Q : ke > Q) ? ye : S(ke), ae = f[N];
        _e == ye ? ae != null ? (O = ae, V == null ? (x(j, _e, z(O)), se = V = D = O) : O < V ? V = O : O > D && (D = O)) : ae === null && (ee = !0) : (V != null && J(j, ye, z(V), z(D), z(se), z(O)), ae != null ? (O = ae, x(j, _e, z(O)), V = D = se = O) : (V = D = null, ae === null && (ee = !0)), ye = _e, Q = M(ye + P));
      }
      V != null && V != D && Ke != ye && J(j, ye, z(V), z(D), z(se), z(O));
    } else
      for (let M = P == 1 ? l : o; M >= l && M <= o; M += P) {
        let V = f[M];
        V === null ? ee = !0 : V != null && x(j, S(h[M]), z(V));
      }
    let [$, Y] = li(n, s);
    if (a.fill != null || $ != 0) {
      let M = Z.fill = new Path2D(j), V = a.fillTo(n, s, a.min, a.max, $), D = z(V), se = S(h[l]), O = S(h[o]);
      P == -1 && ([O, se] = [se, O]), x(M, O, D), x(M, se, D);
    }
    if (!a.spanGaps) {
      let M = [];
      ee && M.push(...ii(h, f, l, o, P, S, e)), Z.gaps = M = a.gaps(n, s, l, o, M), Z.clip = Bn(M, p.ori, A, T, H, F);
    }
    return Y != 0 && (Z.band = Y == 2 ? [
      Lt(n, s, l, o, j, -1),
      Lt(n, s, l, o, j, 1)
    ] : Lt(n, s, l, o, j, Y)), Z;
  });
}
function ku(t) {
  const e = ie(t.align, 1), n = ie(t.ascDesc, !1), s = ie(t.alignGaps, 0), l = ie(t.extend, !1);
  return (o, a, h, f) => as(o, a, (p, g, m, b, A, T, H, F, W, S, z) => {
    [h, f] = In(m, h, f);
    let x = p.pxRound, { left: J, width: P } = o.bbox, Z = (ne) => x(T(ne, b, S, F)), j = (ne) => x(H(ne, A, z, W)), ee = b.ori == 0 ? Is : Ws;
    const B = { stroke: new Path2D(), fill: null, clip: null, band: null, gaps: null, flags: Fs }, $ = B.stroke, Y = b.dir * (b.ori == 0 ? 1 : -1);
    let M = j(m[Y == 1 ? h : f]), V = Z(g[Y == 1 ? h : f]), D = V, se = V;
    l && e == -1 && (se = J, ee($, se, M)), ee($, V, M);
    for (let ne = Y == 1 ? h : f; ne >= h && ne <= f; ne += Y) {
      let ue = m[ne];
      if (ue == null)
        continue;
      let Q = Z(g[ne]), N = j(ue);
      e == 1 ? ee($, Q, M) : ee($, D, N), ee($, Q, N), M = N, D = Q;
    }
    let O = D;
    l && e == 1 && (O = J + P, ee($, O, M));
    let [Ke, ye] = li(o, a);
    if (p.fill != null || Ke != 0) {
      let ne = B.fill = new Path2D($), ue = p.fillTo(o, a, p.min, p.max, Ke), Q = j(ue);
      ee(ne, O, Q), ee(ne, se, Q);
    }
    if (!p.spanGaps) {
      let ne = [];
      ne.push(...ii(g, m, h, f, Y, Z, s));
      let ue = p.width * oe / 2, Q = n || e == 1 ? ue : -ue, N = n || e == -1 ? -ue : ue;
      ne.forEach((ke) => {
        ke[0] += Q, ke[1] += N;
      }), B.gaps = ne = p.gaps(o, a, h, f, ne), B.clip = Bn(ne, b.ori, F, W, S, z);
    }
    return ye != 0 && (B.band = ye == 2 ? [
      Lt(o, a, h, f, $, -1),
      Lt(o, a, h, f, $, 1)
    ] : Lt(o, a, h, f, $, ye)), B;
  });
}
function Nr(t, e, n, s, l, o, a = fe) {
  if (t.length > 1) {
    let h = null;
    for (let f = 0, p = 1 / 0; f < t.length; f++)
      if (e[f] !== void 0) {
        if (h != null) {
          let g = Re(t[f] - t[h]);
          g < p && (p = g, a = Re(n(t[f], s, l, o) - n(t[h], s, l, o)));
        }
        h = f;
      }
  }
  return a;
}
function Tu(t) {
  t = t || cn;
  const e = ie(t.size, [0.6, fe, 1]), n = t.align || 0, s = t.gap || 0;
  let l = t.radius;
  l = // [valueRadius, baselineRadius]
  l == null ? [0, 0] : typeof l == "number" ? [l, 0] : l;
  const o = te(l), a = 1 - e[0], h = ie(e[1], fe), f = ie(e[2], 1), p = ie(t.disp, cn), g = ie(t.each, (A) => {
  }), { fill: m, stroke: b } = p;
  return (A, T, H, F) => as(A, T, (W, S, z, x, J, P, Z, j, ee, B, $) => {
    let Y = W.pxRound, M = n, V = s * oe, D = h * oe, se = f * oe, O, Ke;
    x.ori == 0 ? [O, Ke] = o(A, T) : [Ke, O] = o(A, T);
    const ye = x.dir * (x.ori == 0 ? 1 : -1);
    let ne = x.ori == 0 ? Kn : ri, ue = x.ori == 0 ? g : (C, de, Te, ps, jt, St, qt) => {
      g(C, de, Te, jt, ps, qt, St);
    }, Q = ie(A.bands, Xl).find((C) => C.series[0] == T), N = Q != null ? Q.dir : 0, ke = W.fillTo(A, T, W.min, W.max, N), We = Y(Z(ke, J, $, ee)), _e, ae, pt, Ze = B, Se = Y(W.width * oe), wt = !1, Rt = null, it = null, Ot = null, us = null;
    m != null && (Se == 0 || b != null) && (wt = !0, Rt = m.values(A, T, H, F), it = /* @__PURE__ */ new Map(), new Set(Rt).forEach((C) => {
      C != null && it.set(C, new Path2D());
    }), Se > 0 && (Ot = b.values(A, T, H, F), us = /* @__PURE__ */ new Map(), new Set(Ot).forEach((C) => {
      C != null && us.set(C, new Path2D());
    })));
    let { x0: hs, size: Vs } = p;
    if (hs != null && Vs != null) {
      M = 1, S = hs.values(A, T, H, F), hs.unit == 2 && (S = S.map((Te) => A.posToVal(j + Te * B, x.key, !0)));
      let C = Vs.values(A, T, H, F);
      Vs.unit == 2 ? ae = C[0] * B : ae = P(C[0], x, B, j) - P(0, x, B, j), Ze = Nr(S, z, P, x, B, j, Ze), pt = Ze - ae + V;
    } else
      Ze = Nr(S, z, P, x, B, j, Ze), pt = Ze * a + V, ae = Ze - pt;
    pt < 1 && (pt = 0), Se >= ae / 2 && (Se = 0), pt < 5 && (Y = so);
    let vn = pt > 0, Gt = Ze - pt - (vn ? Se : 0);
    ae = Y(Ml(Gt, se, D)), _e = (M == 0 ? ae / 2 : M == ye ? 0 : ae) - M * ye * ((M == 0 ? V / 2 : 0) + (vn ? Se / 2 : 0));
    const Ve = { stroke: null, fill: null, clip: null, band: null, gaps: null, flags: 0 }, fs = wt ? null : new Path2D();
    let Pt = null;
    if (Q != null)
      Pt = A.data[Q.series[1]];
    else {
      let { y0: C, y1: de } = p;
      C != null && de != null && (z = de.values(A, T, H, F), Pt = C.values(A, T, H, F));
    }
    let Bt = O * ae, q = Ke * ae;
    for (let C = ye == 1 ? H : F; C >= H && C <= F; C += ye) {
      let de = z[C];
      if (de == null)
        continue;
      if (Pt != null) {
        let Ye = Pt[C] ?? 0;
        if (de - Ye == 0)
          continue;
        We = Z(Ye, J, $, ee);
      }
      let Te = x.distr != 2 || p != null ? S[C] : C, ps = P(Te, x, B, j), jt = Z(ie(de, ke), J, $, ee), St = Y(ps - _e), qt = Y(qe(jt, We)), Qe = Y(_t(jt, We)), rt = qt - Qe;
      if (de != null) {
        let Ye = de < 0 ? q : Bt, dt = de < 0 ? Bt : q;
        wt ? (Se > 0 && Ot[C] != null && ne(us.get(Ot[C]), St, Qe + nt(Se / 2), ae, qe(0, rt - Se), Ye, dt), Rt[C] != null && ne(it.get(Rt[C]), St, Qe + nt(Se / 2), ae, qe(0, rt - Se), Ye, dt)) : ne(fs, St, Qe + nt(Se / 2), ae, qe(0, rt - Se), Ye, dt), ue(
          A,
          T,
          C,
          St - Se / 2,
          Qe,
          ae + Se,
          rt
        );
      }
    }
    return Se > 0 ? Ve.stroke = wt ? us : fs : wt || (Ve._fill = W.width == 0 ? W._fill : W._stroke ?? W._fill, Ve.width = 0), Ve.fill = wt ? it : fs, Ve;
  });
}
function Cu(t, e) {
  const n = ie(e?.alignGaps, 0);
  return (s, l, o, a) => as(s, l, (h, f, p, g, m, b, A, T, H, F, W) => {
    [o, a] = In(p, o, a);
    let S = h.pxRound, z = (O) => S(b(O, g, F, T)), x = (O) => S(A(O, m, W, H)), J, P, Z;
    g.ori == 0 ? (J = jn, Z = Is, P = Ro) : (J = qn, Z = Ws, P = Po);
    const j = g.dir * (g.ori == 0 ? 1 : -1);
    let ee = z(f[j == 1 ? o : a]), B = ee, $ = [], Y = [];
    for (let O = j == 1 ? o : a; O >= o && O <= a; O += j)
      if (p[O] != null) {
        let ye = f[O], ne = z(ye);
        $.push(B = ne), Y.push(x(p[O]));
      }
    const M = { stroke: t($, Y, J, Z, P, S), fill: null, clip: null, band: null, gaps: null, flags: Fs }, V = M.stroke;
    let [D, se] = li(s, l);
    if (h.fill != null || D != 0) {
      let O = M.fill = new Path2D(V), Ke = h.fillTo(s, l, h.min, h.max, D), ye = x(Ke);
      Z(O, B, ye), Z(O, ee, ye);
    }
    if (!h.spanGaps) {
      let O = [];
      O.push(...ii(f, p, o, a, j, z, n)), M.gaps = O = h.gaps(s, l, o, a, O), M.clip = Bn(O, g.ori, T, H, F, W);
    }
    return se != 0 && (M.band = se == 2 ? [
      Lt(s, l, o, a, V, -1),
      Lt(s, l, o, a, V, 1)
    ] : Lt(s, l, o, a, V, se)), M;
  });
}
function Ru(t) {
  return Cu(Pu, t);
}
function Pu(t, e, n, s, l, o) {
  const a = t.length;
  if (a < 2)
    return null;
  const h = new Path2D();
  if (n(h, t[0], e[0]), a == 2)
    s(h, t[1], e[1]);
  else {
    let f = Array(a), p = Array(a - 1), g = Array(a - 1), m = Array(a - 1);
    for (let b = 0; b < a - 1; b++)
      g[b] = e[b + 1] - e[b], m[b] = t[b + 1] - t[b], p[b] = g[b] / m[b];
    f[0] = p[0];
    for (let b = 1; b < a - 1; b++)
      p[b] === 0 || p[b - 1] === 0 || p[b - 1] > 0 != p[b] > 0 ? f[b] = 0 : (f[b] = 3 * (m[b - 1] + m[b]) / ((2 * m[b] + m[b - 1]) / p[b - 1] + (m[b] + 2 * m[b - 1]) / p[b]), isFinite(f[b]) || (f[b] = 0));
    f[a - 1] = p[a - 2];
    for (let b = 0; b < a - 1; b++)
      l(
        h,
        t[b] + m[b] / 3,
        e[b] + f[b] * m[b] / 3,
        t[b + 1] - m[b] / 3,
        e[b + 1] - f[b + 1] * m[b] / 3,
        t[b + 1],
        e[b + 1]
      );
  }
  return h;
}
const Dl = /* @__PURE__ */ new Set();
function Lr() {
  for (let t of Dl)
    t.syncRect(!0);
}
Us && (is(hc, Ns, Lr), is(fc, Ns, Lr, !0), is(On, Ns, () => {
  Ie.pxRatio = oe;
}));
const Mu = Lo(), Nu = Mo();
function Or(t, e, n, s) {
  return (s ? [t[0], t[1]].concat(t.slice(2)) : [t[0]].concat(t.slice(1))).map((o, a) => Hl(o, a, e, n));
}
function Lu(t, e) {
  return t.map((n, s) => s == 0 ? {} : Ae({}, e, n));
}
function Hl(t, e, n, s) {
  return Ae({}, e == 0 ? n : s, t);
}
function Oo(t, e, n) {
  return e == null ? Hs : [e, n];
}
const Ou = Oo;
function Du(t, e, n) {
  return e == null ? Hs : Dn(e, n, Zl, !0);
}
function Do(t, e, n, s) {
  return e == null ? Hs : Wn(e, n, t.scales[s].log, !1);
}
const Hu = Do;
function Ho(t, e, n, s) {
  return e == null ? Hs : Jl(e, n, t.scales[s].log, !1);
}
const zu = Ho;
function Fu(t, e, n, s, l) {
  let o = qe(pr(t), pr(e)), a = e - t, h = yt(l / s * a, n);
  do {
    let f = n[h], p = s * f / a;
    if (p >= l && o + (f < 5 ? Vt.get(f) : 0) <= 17)
      return [f, p];
  } while (++h < n.length);
  return [0, 0];
}
function Dr(t) {
  let e, n;
  return t = t.replace(/(\d+)px/, (s, l) => (e = Ce((n = +l) * oe)) + "px"), [t, e, n];
}
function Uu(t) {
  t.show && [t.font, t.labelFont].forEach((e) => {
    let n = pe(e[2] * oe, 1);
    e[0] = e[0].replace(/[0-9.]+px/, n + "px"), e[1] = n;
  });
}
function Ie(t, e, n) {
  const s = {
    mode: ie(t.mode, 1)
  }, l = s.mode;
  function o(i, r, c, u) {
    let d = r.valToPct(i);
    return u + c * (r.dir == -1 ? 1 - d : d);
  }
  function a(i, r, c, u) {
    let d = r.valToPct(i);
    return u + c * (r.dir == -1 ? d : 1 - d);
  }
  function h(i, r, c, u) {
    return r.ori == 0 ? o(i, r, c, u) : a(i, r, c, u);
  }
  s.valToPosH = o, s.valToPosV = a;
  let f = !1;
  s.status = 0;
  const p = s.root = ht(qa);
  if (t.id != null && (p.id = t.id), st(p, t.class), t.title) {
    let i = ht(Ja, p);
    i.textContent = t.title;
  }
  const g = bt("canvas"), m = s.ctx = g.getContext("2d"), b = ht(Za, p);
  is("click", b, (i) => {
    i.target === T && (me != $s || we != Es) && Fe.click(s, i);
  }, !0);
  const A = s.under = ht(Qa, b);
  b.appendChild(g);
  const T = s.over = ht(Xa, b);
  t = zs(t);
  const H = +ie(t.pxAlign, 1), F = Mr(H);
  (t.plugins || []).forEach((i) => {
    i.opts && (t = i.opts(s, t) || t);
  });
  const W = t.ms || 1e-3, S = s.series = l == 1 ? Or(t.series || [], Er, Rr, !1) : Lu(t.series || [null], Cr), z = s.axes = Or(t.axes || [], $r, kr, !0), x = s.scales = {}, J = s.bands = t.bands || [];
  J.forEach((i) => {
    i.fill = te(i.fill || null), i.dir = ie(i.dir, -1);
  });
  const P = l == 2 ? S[1].facets[0].scale : S[0].scale, Z = {
    axes: ra,
    series: ta
  }, j = (t.drawOrder || ["axes", "series"]).map((i) => Z[i]);
  function ee(i) {
    const r = i.distr == 3 ? (c) => Nt(c > 0 ? c : i.clamp(s, c, i.min, i.max, i.key)) : i.distr == 4 ? (c) => Sl(c, i.asinh) : i.distr == 100 ? (c) => i.fwd(c) : (c) => c;
    return (c) => {
      let u = r(c), { _min: d, _max: v } = i, y = v - d;
      return (u - d) / y;
    };
  }
  function B(i) {
    let r = x[i];
    if (r == null) {
      let c = (t.scales || cn)[i] || cn;
      if (c.from != null) {
        B(c.from);
        let u = Ae({}, x[c.from], c, { key: i });
        u.valToPct = ee(u), x[i] = u;
      } else {
        r = x[i] = Ae({}, i == P ? Eo : Su, c), r.key = i;
        let u = r.time, d = r.range, v = It(d);
        if ((i != P || l == 2 && !u) && (v && (d[0] == null || d[1] == null) && (d = {
          min: d[0] == null ? ur : {
            mode: 1,
            hard: d[0],
            soft: d[0]
          },
          max: d[1] == null ? ur : {
            mode: 1,
            hard: d[1],
            soft: d[1]
          }
        }, v = !1), !v && Gn(d))) {
          let y = d;
          d = (_, w, E) => w == null ? Hs : Dn(w, E, y);
        }
        r.range = te(d || (u ? Ou : i == P ? r.distr == 3 ? Hu : r.distr == 4 ? zu : Oo : r.distr == 3 ? Do : r.distr == 4 ? Ho : Du)), r.auto = te(v ? !1 : r.auto), r.clamp = te(r.clamp || wu), r._min = r._max = null, r.valToPct = ee(r);
      }
    }
  }
  B("x"), B("y"), l == 1 && S.forEach((i) => {
    B(i.scale);
  }), z.forEach((i) => {
    B(i.scale);
  });
  for (let i in t.scales)
    B(i);
  const $ = x[P], Y = $.distr;
  let M, V;
  $.ori == 0 ? (st(p, Ka), M = o, V = a) : (st(p, Ya), M = a, V = o);
  const D = {};
  for (let i in x) {
    let r = x[i];
    (r.min != null || r.max != null) && (D[i] = { min: r.min, max: r.max }, r.min = r.max = null);
  }
  const se = t.tzDate || ((i) => new Date(Ce(i / W))), O = t.fmtDate || ei, Ke = W == 1 ? Kc(se) : Zc(se), ye = wr(se, _r(W == 1 ? qc : Jc, O)), ne = xr(se, Sr(Xc, O)), ue = [], Q = s.legend = Ae({}, su, t.legend), N = s.cursor = Ae({}, au, { drag: { y: l == 2 } }, t.cursor), ke = Q.show, We = N.show, _e = Q.markers;
  Q.idxs = ue, _e.width = te(_e.width), _e.dash = te(_e.dash), _e.stroke = te(_e.stroke), _e.fill = te(_e.fill);
  let ae, pt, Ze, Se = [], wt = [], Rt, it = !1, Ot = {};
  if (Q.live) {
    const i = S[1] ? S[1].values : null;
    it = i != null, Rt = it ? i(s, 1, 0) : { _: 0 };
    for (let r in Rt)
      Ot[r] = Kl;
  }
  if (ke)
    if (ae = bt("table", ic, p), Ze = bt("tbody", null, ae), Q.mount(s, ae), it) {
      pt = bt("thead", null, ae, Ze);
      let i = bt("tr", null, pt);
      bt("th", null, i);
      for (var us in Rt)
        bt("th", Zi, i).textContent = us;
    } else
      st(ae, oc), Q.live && st(ae, rc);
  const hs = { show: !0 }, Vs = { show: !1 };
  function vn(i, r) {
    if (r == 0 && (it || !Q.live || l == 2))
      return Hs;
    let c = [], u = bt("tr", ac, Ze, Ze.childNodes[r]);
    st(u, i.class), i.show || st(u, ns);
    let d = bt("th", null, u);
    if (_e.show) {
      let _ = ht(cc, d);
      if (r > 0) {
        let w = _e.width(s, r);
        w && (_.style.border = w + "px " + _e.dash(s, r) + " " + _e.stroke(s, r)), _.style.background = _e.fill(s, r);
      }
    }
    let v = ht(Zi, d);
    i.label instanceof HTMLElement ? v.appendChild(i.label) : v.textContent = i.label, r > 0 && (_e.show || (v.style.color = i.width > 0 ? _e.stroke(s, r) : _e.fill(s, r)), Ve("click", d, (_) => {
      if (N._lock)
        return;
      Yt(_);
      let w = S.indexOf(i);
      if ((_.ctrlKey || _.metaKey) != Q.isolate) {
        let E = S.some((k, R) => R > 0 && R != w && k.show);
        S.forEach((k, R) => {
          R > 0 && $t(R, E ? R == w ? hs : Vs : hs, !0, Ee.setSeries);
        });
      } else
        $t(w, { show: !i.show }, !0, Ee.setSeries);
    }, !1), ms && Ve(tr, d, (_) => {
      N._lock || (Yt(_), $t(S.indexOf(i), ks, !0, Ee.setSeries));
    }, !1));
    for (var y in Rt) {
      let _ = bt("td", uc, u);
      _.textContent = "--", c.push(_);
    }
    return [u, c];
  }
  const Gt = /* @__PURE__ */ new Map();
  function Ve(i, r, c, u = !0) {
    const d = Gt.get(r) || {}, v = N.bind[i](s, r, c, u);
    v && (is(i, r, d[i] = v), Gt.set(r, d));
  }
  function fs(i, r, c) {
    const u = Gt.get(r) || {};
    for (let d in u)
      (i == null || d == i) && (Pl(d, r, u[d]), delete u[d]);
    i == null && Gt.delete(r);
  }
  let Pt = 0, Bt = 0, q = 0, C = 0, de = 0, Te = 0, ps = de, jt = Te, St = q, qt = C, Qe = 0, rt = 0, Ye = 0, dt = 0;
  s.bbox = {};
  let Yn = !1, bn = !1, ds = !1, Kt = !1, yn = !1, ot = !1;
  function Jn(i, r, c) {
    (c || i != s.width || r != s.height) && ui(i, r), _s(!1), ds = !0, bn = !0, ws();
  }
  function ui(i, r) {
    s.width = Pt = q = i, s.height = Bt = C = r, de = Te = 0, Ko(), Yo();
    let c = s.bbox;
    Qe = c.left = ts(de * oe, 0.5), rt = c.top = ts(Te * oe, 0.5), Ye = c.width = ts(q * oe, 0.5), dt = c.height = ts(C * oe, 0.5);
  }
  const Bo = 3;
  function jo() {
    let i = !1, r = 0;
    for (; !i; ) {
      r++;
      let c = la(r), u = ia(r);
      i = r == Bo || c && u, i || (ui(s.width, s.height), bn = !0);
    }
  }
  function qo({ width: i, height: r }) {
    Jn(i, r);
  }
  s.setSize = qo;
  function Ko() {
    let i = !1, r = !1, c = !1, u = !1;
    z.forEach((d, v) => {
      if (d.show && d._show) {
        let { side: y, _size: _ } = d, w = y % 2, E = d.label != null ? d.labelSize : 0, k = _ + E;
        k > 0 && (w ? (q -= k, y == 3 ? (de += k, u = !0) : c = !0) : (C -= k, y == 0 ? (Te += k, i = !0) : r = !0));
      }
    }), Jt[0] = i, Jt[1] = c, Jt[2] = r, Jt[3] = u, q -= Dt[1] + Dt[3], de += Dt[3], C -= Dt[2] + Dt[0], Te += Dt[0];
  }
  function Yo() {
    let i = de + q, r = Te + C, c = de, u = Te;
    function d(v, y) {
      switch (v) {
        case 1:
          return i += y, i - y;
        case 2:
          return r += y, r - y;
        case 3:
          return c -= y, c + y;
        case 0:
          return u -= y, u + y;
      }
    }
    z.forEach((v, y) => {
      if (v.show && v._show) {
        let _ = v.side;
        v._pos = d(_, v._size), v.label != null && (v._lpos = d(_, v.labelSize));
      }
    });
  }
  if (N.dataIdx == null) {
    let i = N.hover, r = i.skip = new Set(i.skip ?? []);
    r.add(void 0);
    let c = i.prox = te(i.prox), u = i.bias ??= 0;
    N.dataIdx = (d, v, y, _) => {
      if (v == 0)
        return y;
      let w = y, E = c(d, v, y, _) ?? fe, k = E >= 0 && E < fe, R = $.ori == 0 ? q : C, G = N.left, re = e[0], le = e[v];
      if (r.has(le[y])) {
        w = null;
        let X = null, U = null, L;
        if (u == 0 || u == -1)
          for (L = y; X == null && L-- > 0; )
            r.has(le[L]) || (X = L);
        if (u == 0 || u == 1)
          for (L = y; U == null && L++ < le.length; )
            r.has(le[L]) || (U = L);
        if (X != null || U != null)
          if (k) {
            let ve = X == null ? -1 / 0 : M(re[X], $, R, 0), xe = U == null ? 1 / 0 : M(re[U], $, R, 0), He = G - ve, he = xe - G;
            He <= he ? He <= E && (w = X) : he <= E && (w = U);
          } else
            w = U == null ? X : X == null ? U : y - X <= U - y ? X : U;
      } else k && Re(G - M(re[y], $, R, 0)) > E && (w = null);
      return w;
    };
  }
  const Yt = (i) => {
    N.event = i;
  };
  N.idxs = ue, N._lock = !1;
  let Ue = N.points;
  Ue.show = te(Ue.show), Ue.size = te(Ue.size), Ue.stroke = te(Ue.stroke), Ue.width = te(Ue.width), Ue.fill = te(Ue.fill);
  const xt = s.focus = Ae({}, t.focus || { alpha: 0.3 }, N.focus), ms = xt.prox >= 0, gs = ms && Ue.one;
  let at = [], vs = [], bs = [];
  function hi(i, r) {
    let c = Ue.show(s, r);
    if (c instanceof HTMLElement)
      return st(c, lc), st(c, i.class), Tt(c, -10, -10, q, C), T.insertBefore(c, at[r]), c;
  }
  function fi(i, r) {
    if (l == 1 || r > 0) {
      let c = l == 1 && x[i.scale].time, u = i.value;
      i.value = c ? gr(u) ? xr(se, Sr(u, O)) : u || ne : u || bu, i.label = i.label || (c ? uu : cu);
    }
    if (gs || r > 0) {
      i.width = i.width == null ? 1 : i.width, i.paths = i.paths || Mu || Sc, i.fillTo = te(i.fillTo || xu), i.pxAlign = +ie(i.pxAlign, H), i.pxRound = Mr(i.pxAlign), i.stroke = te(i.stroke || null), i.fill = te(i.fill || null), i._stroke = i._fill = i._paths = i._focus = null;
      let c = yu(qe(1, i.width), 1), u = i.points = Ae({}, {
        size: c,
        width: qe(1, c * 0.2),
        stroke: i.stroke,
        space: c * 2,
        paths: Nu,
        _stroke: null,
        _fill: null
      }, i.points);
      u.show = te(u.show), u.filter = te(u.filter), u.fill = te(u.fill), u.stroke = te(u.stroke), u.paths = te(u.paths), u.pxAlign = i.pxAlign;
    }
    if (ke) {
      let c = vn(i, r);
      Se.splice(r, 0, c[0]), wt.splice(r, 0, c[1]), Q.values.push(null);
    }
    if (We) {
      ue.splice(r, 0, null);
      let c = null;
      gs ? r == 0 && (c = hi(i, r)) : r > 0 && (c = hi(i, r)), at.splice(r, 0, c), vs.splice(r, 0, 0), bs.splice(r, 0, 0);
    }
    De("addSeries", r);
  }
  function Jo(i, r) {
    r = r ?? S.length, i = l == 1 ? Hl(i, r, Er, Rr) : Hl(i, r, {}, Cr), S.splice(r, 0, i), fi(S[r], r);
  }
  s.addSeries = Jo;
  function Zo(i) {
    if (S.splice(i, 1), ke) {
      Q.values.splice(i, 1), wt.splice(i, 1);
      let r = Se.splice(i, 1)[0];
      fs(null, r.firstChild), r.remove();
    }
    We && (ue.splice(i, 1), at.splice(i, 1)[0].remove(), vs.splice(i, 1), bs.splice(i, 1)), De("delSeries", i);
  }
  s.delSeries = Zo;
  const Jt = [!1, !1, !1, !1];
  function Qo(i, r) {
    if (i._show = i.show, i.show) {
      let c = i.side % 2, u = x[i.scale];
      u == null && (i.scale = c ? S[1].scale : P, u = x[i.scale]);
      let d = u.time;
      i.size = te(i.size), i.space = te(i.space), i.rotate = te(i.rotate), It(i.incrs) && i.incrs.forEach((y) => {
        !Vt.has(y) && Vt.set(y, io(y));
      }), i.incrs = te(i.incrs || (u.distr == 2 ? Gc : d ? W == 1 ? jc : Yc : ss)), i.splits = te(i.splits || (d && u.distr == 1 ? Ke : u.distr == 3 ? Nl : u.distr == 4 ? pu : fu)), i.stroke = te(i.stroke), i.grid.stroke = te(i.grid.stroke), i.ticks.stroke = te(i.ticks.stroke), i.border.stroke = te(i.border.stroke);
      let v = i.values;
      i.values = // static array of tick values
      It(v) && !It(v[0]) ? te(v) : (
        // temporal
        d ? (
          // config array of fmtDate string tpls
          It(v) ? wr(se, _r(v, O)) : (
            // fmtDate string tpl
            gr(v) ? Qc(se, v) : v || ye
          )
        ) : v || hu
      ), i.filter = te(i.filter || (u.distr >= 3 && u.log == 10 ? gu : u.distr == 3 && u.log == 2 ? vu : no)), i.font = Dr(i.font), i.labelFont = Dr(i.labelFont), i._size = i.size(s, null, r, 0), i._space = i._rotate = i._incrs = i._found = // foundIncrSpace
      i._splits = i._values = null, i._size > 0 && (Jt[r] = !0, i._el = ht(ec, b));
    }
  }
  function Gs(i, r, c, u) {
    let [d, v, y, _] = c, w = r % 2, E = 0;
    return w == 0 && (_ || v) && (E = r == 0 && !d || r == 2 && !y ? Ce($r.size / 3) : 0), w == 1 && (d || y) && (E = r == 1 && !v || r == 3 && !_ ? Ce(kr.size / 2) : 0), E;
  }
  const pi = s.padding = (t.padding || [Gs, Gs, Gs, Gs]).map((i) => te(ie(i, Gs))), Dt = s._padding = pi.map((i, r) => i(s, r, Jt, 0));
  let ze, Me = null, Ne = null;
  const _n = l == 1 ? S[0].idxs : null;
  let mt = null, Bs = !1;
  function di(i, r) {
    if (e = i ?? [], s.data = s._data = e, l == 2) {
      ze = 0;
      for (let c = 1; c < S.length; c++)
        ze += e[c][0].length;
    } else {
      e.length == 0 && (s.data = s._data = e = [[]]), mt = e[0], ze = mt.length;
      let c = e;
      if (Y == 2) {
        c = e.slice();
        let u = c[0] = Array(ze);
        for (let d = 0; d < ze; d++)
          u[d] = d;
      }
      s._data = e = c;
    }
    if (_s(!0), De("setData"), Y == 2 && (ds = !0), r !== !1) {
      let c = $;
      c.auto(s, Bs) ? Zn() : zt(P, c.min, c.max), Kt = Kt || N.left >= 0, ot = !0, ws();
    }
  }
  s.setData = di;
  function Zn() {
    Bs = !0;
    let i, r;
    l == 1 && (ze > 0 ? (Me = _n[0] = 0, Ne = _n[1] = ze - 1, i = e[0][Me], r = e[0][Ne], Y == 2 ? (i = Me, r = Ne) : i == r && (Y == 3 ? [i, r] = Wn(i, i, $.log, !1) : Y == 4 ? [i, r] = Jl(i, i, $.log, !1) : $.time ? r = i + Ce(86400 / W) : [i, r] = Dn(i, r, Zl, !0))) : (Me = _n[0] = i = null, Ne = _n[1] = r = null)), zt(P, i, r);
  }
  let wn, ys, Qn, Xn, el, tl, sl, nl, ll, Je;
  function mi(i, r, c, u, d, v) {
    i ??= Xi, c ??= Xl, u ??= "butt", d ??= Xi, v ??= "round", i != wn && (m.strokeStyle = wn = i), d != ys && (m.fillStyle = ys = d), r != Qn && (m.lineWidth = Qn = r), v != el && (m.lineJoin = el = v), u != tl && (m.lineCap = tl = u), c != Xn && m.setLineDash(Xn = c);
  }
  function gi(i, r, c, u) {
    r != ys && (m.fillStyle = ys = r), i != sl && (m.font = sl = i), c != nl && (m.textAlign = nl = c), u != ll && (m.textBaseline = ll = u);
  }
  function il(i, r, c, u, d = 0) {
    if (u.length > 0 && i.auto(s, Bs) && (r == null || r.min == null)) {
      let v = ie(Me, 0), y = ie(Ne, u.length - 1), _ = c.min == null ? gc(u, v, y, d, i.distr == 3) : [c.min, c.max];
      i.min = _t(i.min, c.min = _[0]), i.max = qe(i.max, c.max = _[1]);
    }
  }
  const vi = { min: null, max: null };
  function Xo() {
    for (let u in x) {
      let d = x[u];
      D[u] == null && // scales that have never been set (on init)
      (d.min == null || // or auto scales when the x scale was explicitly set
      D[P] != null && d.auto(s, Bs)) && (D[u] = vi);
    }
    for (let u in x) {
      let d = x[u];
      D[u] == null && d.from != null && D[d.from] != null && (D[u] = vi);
    }
    D[P] != null && _s(!0);
    let i = {};
    for (let u in D) {
      let d = D[u];
      if (d != null) {
        let v = i[u] = zs(x[u], Ec);
        if (d.min != null)
          Ae(v, d);
        else if (u != P || l == 2)
          if (ze == 0 && v.from == null) {
            let y = v.range(s, null, null, u);
            v.min = y[0], v.max = y[1];
          } else
            v.min = fe, v.max = -fe;
      }
    }
    if (ze > 0) {
      S.forEach((u, d) => {
        if (l == 1) {
          let v = u.scale, y = D[v];
          if (y == null)
            return;
          let _ = i[v];
          if (d == 0) {
            let w = _.range(s, _.min, _.max, v);
            _.min = w[0], _.max = w[1], Me = yt(_.min, e[0]), Ne = yt(_.max, e[0]), Ne - Me > 1 && (e[0][Me] < _.min && Me++, e[0][Ne] > _.max && Ne--), u.min = mt[Me], u.max = mt[Ne];
          } else u.show && u.auto && il(_, y, u, e[d], u.sorted);
          u.idxs[0] = Me, u.idxs[1] = Ne;
        } else if (d > 0 && u.show && u.auto) {
          let [v, y] = u.facets, _ = v.scale, w = y.scale, [E, k] = e[d], R = i[_], G = i[w];
          R != null && il(R, D[_], v, E, v.sorted), G != null && il(G, D[w], y, k, y.sorted), u.min = y.min, u.max = y.max;
        }
      });
      for (let u in i) {
        let d = i[u], v = D[u];
        if (d.from == null && (v == null || v.min == null)) {
          let y = d.range(
            s,
            d.min == fe ? null : d.min,
            d.max == -fe ? null : d.max,
            u
          );
          d.min = y[0], d.max = y[1];
        }
      }
    }
    for (let u in i) {
      let d = i[u];
      if (d.from != null) {
        let v = i[d.from];
        if (v.min == null)
          d.min = d.max = null;
        else {
          let y = d.range(s, v.min, v.max, u);
          d.min = y[0], d.max = y[1];
        }
      }
    }
    let r = {}, c = !1;
    for (let u in i) {
      let d = i[u], v = x[u];
      if (v.min != d.min || v.max != d.max) {
        v.min = d.min, v.max = d.max;
        let y = v.distr;
        v._min = y == 3 ? Nt(v.min) : y == 4 ? Sl(v.min, v.asinh) : y == 100 ? v.fwd(v.min) : v.min, v._max = y == 3 ? Nt(v.max) : y == 4 ? Sl(v.max, v.asinh) : y == 100 ? v.fwd(v.max) : v.max, r[u] = c = !0;
      }
    }
    if (c) {
      S.forEach((u, d) => {
        l == 2 ? d > 0 && r.y && (u._paths = null) : r[u.scale] && (u._paths = null);
      });
      for (let u in r)
        ds = !0, De("setScale", u);
      We && N.left >= 0 && (Kt = ot = !0);
    }
    for (let u in D)
      D[u] = null;
  }
  function ea(i) {
    let r = Ml(Me - 1, 0, ze - 1), c = Ml(Ne + 1, 0, ze - 1);
    for (; i[r] == null && r > 0; )
      r--;
    for (; i[c] == null && c < ze - 1; )
      c++;
    return [r, c];
  }
  function ta() {
    if (ze > 0) {
      let i = S.some((r) => r._focus) && Je != xt.alpha;
      i && (m.globalAlpha = Je = xt.alpha), S.forEach((r, c) => {
        if (c > 0 && r.show && (bi(c, !1), bi(c, !0), r._paths == null)) {
          let u = Je;
          Je != r.alpha && (m.globalAlpha = Je = r.alpha);
          let d = l == 2 ? [0, e[c][0].length - 1] : ea(e[c]);
          r._paths = r.paths(s, c, d[0], d[1]), Je != u && (m.globalAlpha = Je = u);
        }
      }), S.forEach((r, c) => {
        if (c > 0 && r.show) {
          let u = Je;
          Je != r.alpha && (m.globalAlpha = Je = r.alpha), r._paths != null && yi(c, !1);
          {
            let d = r._paths != null ? r._paths.gaps : null, v = r.points.show(s, c, Me, Ne, d), y = r.points.filter(s, c, v, d);
            (v || y) && (r.points._paths = r.points.paths(s, c, Me, Ne, y), yi(c, !0));
          }
          Je != u && (m.globalAlpha = Je = u), De("drawSeries", c);
        }
      }), i && (m.globalAlpha = Je = 1);
    }
  }
  function bi(i, r) {
    let c = r ? S[i].points : S[i];
    c._stroke = c.stroke(s, i), c._fill = c.fill(s, i);
  }
  function yi(i, r) {
    let c = r ? S[i].points : S[i], {
      stroke: u,
      fill: d,
      clip: v,
      flags: y,
      _stroke: _ = c._stroke,
      _fill: w = c._fill,
      _width: E = c.width
    } = c._paths;
    E = pe(E * oe, 3);
    let k = null, R = E % 2 / 2;
    r && w == null && (w = E > 0 ? "#fff" : _);
    let G = c.pxAlign == 1 && R > 0;
    if (G && m.translate(R, R), !r) {
      let re = Qe - E / 2, le = rt - E / 2, X = Ye + E, U = dt + E;
      k = new Path2D(), k.rect(re, le, X, U);
    }
    r ? rl(_, E, c.dash, c.cap, w, u, d, y, v) : sa(i, _, E, c.dash, c.cap, w, u, d, y, k, v), G && m.translate(-R, -R);
  }
  function sa(i, r, c, u, d, v, y, _, w, E, k) {
    let R = !1;
    w != 0 && J.forEach((G, re) => {
      if (G.series[0] == i) {
        let le = S[G.series[1]], X = e[G.series[1]], U = (le._paths || cn).band;
        It(U) && (U = G.dir == 1 ? U[0] : U[1]);
        let L, ve = null;
        le.show && U && bc(X, Me, Ne) ? (ve = G.fill(s, re) || v, L = le._paths.clip) : U = null, rl(r, c, u, d, ve, y, _, w, E, k, L, U), R = !0;
      }
    }), R || rl(r, c, u, d, v, y, _, w, E, k);
  }
  const _i = Fs | Ol;
  function rl(i, r, c, u, d, v, y, _, w, E, k, R) {
    mi(i, r, c, u, d), (w || E || R) && (m.save(), w && m.clip(w), E && m.clip(E)), R ? (_ & _i) == _i ? (m.clip(R), k && m.clip(k), xn(d, y), Sn(i, v, r)) : _ & Ol ? (xn(d, y), m.clip(R), Sn(i, v, r)) : _ & Fs && (m.save(), m.clip(R), k && m.clip(k), xn(d, y), m.restore(), Sn(i, v, r)) : (xn(d, y), Sn(i, v, r)), (w || E || R) && m.restore();
  }
  function Sn(i, r, c) {
    c > 0 && (r instanceof Map ? r.forEach((u, d) => {
      m.strokeStyle = wn = d, m.stroke(u);
    }) : r != null && i && m.stroke(r));
  }
  function xn(i, r) {
    r instanceof Map ? r.forEach((c, u) => {
      m.fillStyle = ys = u, m.fill(c);
    }) : r != null && i && m.fill(r);
  }
  function na(i, r, c, u) {
    let d = z[i], v;
    if (u <= 0)
      v = [0, 0];
    else {
      let y = d._space = d.space(s, i, r, c, u), _ = d._incrs = d.incrs(s, i, r, c, u, y);
      v = Fu(r, c, _, u, y);
    }
    return d._found = v;
  }
  function ol(i, r, c, u, d, v, y, _, w, E) {
    let k = y % 2 / 2;
    H == 1 && m.translate(k, k), mi(_, y, w, E, _), m.beginPath();
    let R, G, re, le, X = d + (u == 0 || u == 3 ? -v : v);
    c == 0 ? (G = d, le = X) : (R = d, re = X);
    for (let U = 0; U < i.length; U++)
      r[U] != null && (c == 0 ? R = re = i[U] : G = le = i[U], m.moveTo(R, G), m.lineTo(re, le));
    m.stroke(), H == 1 && m.translate(-k, -k);
  }
  function la(i) {
    let r = !0;
    return z.forEach((c, u) => {
      if (!c.show)
        return;
      let d = x[c.scale];
      if (d.min == null) {
        c._show && (r = !1, c._show = !1, _s(!1));
        return;
      } else
        c._show || (r = !1, c._show = !0, _s(!1));
      let v = c.side, y = v % 2, { min: _, max: w } = d, [E, k] = na(u, _, w, y == 0 ? q : C);
      if (k == 0)
        return;
      let R = d.distr == 2, G = c._splits = c.splits(s, u, _, w, E, k, R), re = d.distr == 2 ? G.map((L) => mt[L]) : G, le = d.distr == 2 ? mt[G[1]] - mt[G[0]] : E, X = c._values = c.values(s, c.filter(s, re, u, k, le), u, k, le);
      c._rotate = v == 2 ? c.rotate(s, X, u, k) : 0;
      let U = c._size;
      c._size = ft(c.size(s, X, u, i)), U != null && c._size != U && (r = !1);
    }), r;
  }
  function ia(i) {
    let r = !0;
    return pi.forEach((c, u) => {
      let d = c(s, u, Jt, i);
      d != Dt[u] && (r = !1), Dt[u] = d;
    }), r;
  }
  function ra() {
    for (let i = 0; i < z.length; i++) {
      let r = z[i];
      if (!r.show || !r._show)
        continue;
      let c = r.side, u = c % 2, d, v, y = r.stroke(s, i), _ = c == 0 || c == 3 ? -1 : 1, [w, E] = r._found;
      if (r.label != null) {
        let Be = r.labelGap * _, tt = Ce((r._lpos + Be) * oe);
        gi(r.labelFont[0], y, "center", c == 2 ? Qs : Qi), m.save(), u == 1 ? (d = v = 0, m.translate(
          tt,
          Ce(rt + dt / 2)
        ), m.rotate((c == 3 ? -Mn : Mn) / 2)) : (d = Ce(Qe + Ye / 2), v = tt);
        let Xt = to(r.label) ? r.label(s, i, w, E) : r.label;
        m.fillText(Xt, d, v), m.restore();
      }
      if (E == 0)
        continue;
      let k = x[r.scale], R = u == 0 ? Ye : dt, G = u == 0 ? Qe : rt, re = r._splits, le = k.distr == 2 ? re.map((Be) => mt[Be]) : re, X = k.distr == 2 ? mt[re[1]] - mt[re[0]] : w, U = r.ticks, L = r.border, ve = U.show ? U.size : 0, xe = Ce(ve * oe), He = Ce((r.alignTo == 2 ? r._size - ve - r.gap : r.gap) * oe), he = r._rotate * -Mn / 180, $e = F(r._pos * oe), Xe = (xe + He) * _, Ge = $e + Xe;
      v = u == 0 ? Ge : 0, d = u == 1 ? Ge : 0;
      let ct = r.font[0], gt = r.align == 1 ? Cs : r.align == 2 ? yl : he > 0 ? Cs : he < 0 ? yl : u == 0 ? "center" : c == 3 ? yl : Cs, At = he || u == 1 ? "middle" : c == 2 ? Qs : Qi;
      gi(ct, y, gt, At);
      let et = r.font[1] * r.lineGap, ut = re.map((Be) => F(h(Be, k, R, G))), vt = r._values;
      for (let Be = 0; Be < vt.length; Be++) {
        let tt = vt[Be];
        if (tt != null) {
          u == 0 ? d = ut[Be] : v = ut[Be], tt = "" + tt;
          let Xt = tt.indexOf(`
`) == -1 ? [tt] : tt.split(/\n/gm);
          for (let je = 0; je < Xt.length; je++) {
            let Fi = Xt[je];
            he ? (m.save(), m.translate(d, v + je * et), m.rotate(he), m.fillText(Fi, 0, 0), m.restore()) : m.fillText(Fi, d, v + je * et);
          }
        }
      }
      U.show && ol(
        ut,
        U.filter(s, le, i, E, X),
        u,
        c,
        $e,
        xe,
        pe(U.width * oe, 3),
        U.stroke(s, i),
        U.dash,
        U.cap
      );
      let kt = r.grid;
      kt.show && ol(
        ut,
        kt.filter(s, le, i, E, X),
        u,
        u == 0 ? 2 : 1,
        u == 0 ? rt : Qe,
        u == 0 ? dt : Ye,
        pe(kt.width * oe, 3),
        kt.stroke(s, i),
        kt.dash,
        kt.cap
      ), L.show && ol(
        [$e],
        [1],
        u == 0 ? 1 : 0,
        u == 0 ? 1 : 2,
        u == 1 ? rt : Qe,
        u == 1 ? dt : Ye,
        pe(L.width * oe, 3),
        L.stroke(s, i),
        L.dash,
        L.cap
      );
    }
    De("drawAxes");
  }
  function _s(i) {
    S.forEach((r, c) => {
      c > 0 && (r._paths = null, i && (l == 1 ? (r.min = null, r.max = null) : r.facets.forEach((u) => {
        u.min = null, u.max = null;
      })));
    });
  }
  let $n = !1, al = !1, js = [];
  function oa() {
    al = !1;
    for (let i = 0; i < js.length; i++)
      De(...js[i]);
    js.length = 0;
  }
  function ws() {
    $n || (Mc(wi), $n = !0);
  }
  function aa(i, r = !1) {
    $n = !0, al = r, i(s), wi(), r && js.length > 0 && queueMicrotask(oa);
  }
  s.batch = aa;
  function wi() {
    if (Yn && (Xo(), Yn = !1), ds && (jo(), ds = !1), bn) {
      if (be(A, Cs, de), be(A, Qs, Te), be(A, nn, q), be(A, ln, C), be(T, Cs, de), be(T, Qs, Te), be(T, nn, q), be(T, ln, C), be(b, nn, Pt), be(b, ln, Bt), g.width = Ce(Pt * oe), g.height = Ce(Bt * oe), z.forEach(({ _el: i, _show: r, _size: c, _pos: u, side: d }) => {
        if (i != null)
          if (r) {
            let v = d === 3 || d === 0 ? c : 0, y = d % 2 == 1;
            be(i, y ? "left" : "top", u - v), be(i, y ? "width" : "height", c), be(i, y ? "top" : "left", y ? Te : de), be(i, y ? "height" : "width", y ? C : q), Rl(i, ns);
          } else
            st(i, ns);
      }), wn = ys = Qn = el = tl = sl = nl = ll = Xn = null, Je = 1, Ys(!0), de != ps || Te != jt || q != St || C != qt) {
        _s(!1);
        let i = q / St, r = C / qt;
        if (We && !Kt && N.left >= 0) {
          N.left *= i, N.top *= r, Ss && Tt(Ss, Ce(N.left), 0, q, C), xs && Tt(xs, 0, Ce(N.top), q, C);
          for (let c = 0; c < at.length; c++) {
            let u = at[c];
            u != null && (vs[c] *= i, bs[c] *= r, Tt(u, ft(vs[c]), ft(bs[c]), q, C));
          }
        }
        if (ge.show && !yn && ge.left >= 0 && ge.width > 0) {
          ge.left *= i, ge.width *= i, ge.top *= r, ge.height *= r;
          for (let c in dl)
            be(As, c, ge[c]);
        }
        ps = de, jt = Te, St = q, qt = C;
      }
      De("setSize"), bn = !1;
    }
    Pt > 0 && Bt > 0 && (m.clearRect(0, 0, g.width, g.height), De("drawClear"), j.forEach((i) => i()), De("draw")), ge.show && yn && (En(ge), yn = !1), We && Kt && (Qt(null, !0, !1), Kt = !1), Q.show && Q.live && ot && (fl(), ot = !1), f || (f = !0, s.status = 1, De("ready")), Bs = !1, $n = !1;
  }
  s.redraw = (i, r) => {
    ds = r || !1, i !== !1 ? zt(P, $.min, $.max) : ws();
  };
  function cl(i, r) {
    let c = x[i];
    if (c.from == null) {
      if (ze == 0) {
        let u = c.range(s, r.min, r.max, i);
        r.min = u[0], r.max = u[1];
      }
      if (r.min > r.max) {
        let u = r.min;
        r.min = r.max, r.max = u;
      }
      if (ze > 1 && r.min != null && r.max != null && r.max - r.min < 1e-16)
        return;
      i == P && c.distr == 2 && ze > 0 && (r.min = yt(r.min, e[0]), r.max = yt(r.max, e[0]), r.min == r.max && r.max++), D[i] = r, Yn = !0, ws();
    }
  }
  s.setScale = cl;
  let ul, hl, Ss, xs, Si, xi, $s, Es, $i, Ei, me, we, Ht = !1;
  const Fe = N.drag;
  let Le = Fe.x, Oe = Fe.y;
  We && (N.x && (ul = ht(sc, T)), N.y && (hl = ht(nc, T)), $.ori == 0 ? (Ss = ul, xs = hl) : (Ss = hl, xs = ul), me = N.left, we = N.top);
  const ge = s.select = Ae({
    show: !0,
    over: !0,
    left: 0,
    width: 0,
    top: 0,
    height: 0
  }, t.select), As = ge.show ? ht(tc, ge.over ? T : A) : null;
  function En(i, r) {
    if (ge.show) {
      for (let c in i)
        ge[c] = i[c], c in dl && be(As, c, i[c]);
      r !== !1 && De("setSelect");
    }
  }
  s.setSelect = En;
  function ca(i) {
    if (S[i].show)
      ke && Rl(Se[i], ns);
    else if (ke && st(Se[i], ns), We) {
      let c = gs ? at[0] : at[i];
      c != null && Tt(c, -10, -10, q, C);
    }
  }
  function zt(i, r, c) {
    cl(i, { min: r, max: c });
  }
  function $t(i, r, c, u) {
    r.focus != null && da(i), r.show != null && S.forEach((d, v) => {
      v > 0 && (i == v || i == null) && (d.show = r.show, ca(v), l == 2 ? (zt(d.facets[0].scale, null, null), zt(d.facets[1].scale, null, null)) : zt(d.scale, null, null), ws());
    }), c !== !1 && De("setSeries", i, r), u && Js("setSeries", s, i, r);
  }
  s.setSeries = $t;
  function ua(i, r) {
    Ae(J[i], r);
  }
  function ha(i, r) {
    i.fill = te(i.fill || null), i.dir = ie(i.dir, -1), r = r ?? J.length, J.splice(r, 0, i);
  }
  function fa(i) {
    i == null ? J.length = 0 : J.splice(i, 1);
  }
  s.addBand = ha, s.setBand = ua, s.delBand = fa;
  function pa(i, r) {
    S[i].alpha = r, We && at[i] != null && (at[i].style.opacity = r), ke && Se[i] && (Se[i].style.opacity = r);
  }
  let Mt, Ft, Zt;
  const ks = { focus: !0 };
  function da(i) {
    if (i != Zt) {
      let r = i == null, c = xt.alpha != 1;
      S.forEach((u, d) => {
        if (l == 1 || d > 0) {
          let v = r || d == 0 || d == i;
          u._focus = r ? null : v, c && pa(d, v ? 1 : xt.alpha);
        }
      }), Zt = i, c && ws();
    }
  }
  ke && ms && Ve(sr, ae, (i) => {
    N._lock || (Yt(i), Zt != null && $t(null, ks, !0, Ee.setSeries));
  });
  function Et(i, r, c) {
    let u = x[r];
    c && (i = i / oe - (u.ori == 1 ? Te : de));
    let d = q;
    u.ori == 1 && (d = C, i = d - i), u.dir == -1 && (i = d - i);
    let v = u._min, y = u._max, _ = i / d, w = v + (y - v) * _, E = u.distr;
    return E == 3 ? Ds(10, w) : E == 4 ? _c(w, u.asinh) : E == 100 ? u.bwd(w) : w;
  }
  function ma(i, r) {
    let c = Et(i, P, r);
    return yt(c, e[0], Me, Ne);
  }
  s.valToIdx = (i) => yt(i, e[0]), s.posToIdx = ma, s.posToVal = Et, s.valToPos = (i, r, c) => x[r].ori == 0 ? o(
    i,
    x[r],
    c ? Ye : q,
    c ? Qe : 0
  ) : a(
    i,
    x[r],
    c ? dt : C,
    c ? rt : 0
  ), s.setCursor = (i, r, c) => {
    me = i.left, we = i.top, Qt(null, r, c);
  };
  function Ai(i, r) {
    be(As, Cs, ge.left = i), be(As, nn, ge.width = r);
  }
  function ki(i, r) {
    be(As, Qs, ge.top = i), be(As, ln, ge.height = r);
  }
  let qs = $.ori == 0 ? Ai : ki, Ks = $.ori == 1 ? Ai : ki;
  function ga() {
    if (ke && Q.live)
      for (let i = l == 2 ? 1 : 0; i < S.length; i++) {
        if (i == 0 && it)
          continue;
        let r = Q.values[i], c = 0;
        for (let u in r)
          wt[i][c++].firstChild.nodeValue = r[u];
      }
  }
  function fl(i, r) {
    if (i != null && (i.idxs ? i.idxs.forEach((c, u) => {
      ue[u] = c;
    }) : $c(i.idx) || ue.fill(i.idx), Q.idx = ue[0]), ke && Q.live) {
      for (let c = 0; c < S.length; c++)
        (c > 0 || l == 1 && !it) && va(c, ue[c]);
      ga();
    }
    ot = !1, r !== !1 && De("setLegend");
  }
  s.setLegend = fl;
  function va(i, r) {
    let c = S[i], u = i == 0 && Y == 2 ? mt : e[i], d;
    it ? d = c.values(s, i, r) ?? Ot : (d = c.value(s, r == null ? null : u[r], i, r), d = d == null ? Ot : { _: d }), Q.values[i] = d;
  }
  function Qt(i, r, c) {
    $i = me, Ei = we, [me, we] = N.move(s, me, we), N.left = me, N.top = we, We && (Ss && Tt(Ss, Ce(me), 0, q, C), xs && Tt(xs, 0, Ce(we), q, C));
    let u, d = Me > Ne;
    Mt = fe, Ft = null;
    let v = $.ori == 0 ? q : C, y = $.ori == 1 ? q : C;
    if (me < 0 || ze == 0 || d) {
      u = N.idx = null;
      for (let _ = 0; _ < S.length; _++) {
        let w = at[_];
        w != null && Tt(w, -10, -10, q, C);
      }
      ms && $t(null, ks, !0, i == null && Ee.setSeries), Q.live && (ue.fill(u), ot = !0);
    } else {
      let _, w, E;
      l == 1 && (_ = $.ori == 0 ? me : we, w = Et(_, P), u = N.idx = yt(w, e[0], Me, Ne), E = M(e[0][u], $, v, 0));
      let k = -10, R = -10, G = 0, re = 0, le = !0, X = "", U = "";
      for (let L = l == 2 ? 1 : 0; L < S.length; L++) {
        let ve = S[L], xe = ue[L], He = xe == null ? null : l == 1 ? e[L][xe] : e[L][1][xe], he = N.dataIdx(s, L, u, w), $e = he == null ? null : l == 1 ? e[L][he] : e[L][1][he];
        if (ot = ot || $e != He || he != xe, ue[L] = he, L > 0 && ve.show) {
          let Xe = he == null ? -10 : he == u ? E : M(l == 1 ? e[0][he] : e[L][0][he], $, v, 0), Ge = $e == null ? -10 : V($e, l == 1 ? x[ve.scale] : x[ve.facets[1].scale], y, 0);
          if (ms && $e != null) {
            let ct = $.ori == 1 ? me : we, gt = Re(xt.dist(s, L, he, Ge, ct));
            if (gt < Mt) {
              let At = xt.bias;
              if (At != 0) {
                let et = Et(ct, ve.scale), ut = $e >= 0 ? 1 : -1, vt = et >= 0 ? 1 : -1;
                vt == ut && (vt == 1 ? At == 1 ? $e >= et : $e <= et : (
                  // >= 0
                  At == 1 ? $e <= et : $e >= et
                )) && (Mt = gt, Ft = L);
              } else
                Mt = gt, Ft = L;
            }
          }
          if (ot || gs) {
            let ct, gt;
            $.ori == 0 ? (ct = Xe, gt = Ge) : (ct = Ge, gt = Xe);
            let At, et, ut, vt, kt, Be, tt = !0, Xt = Ue.bbox;
            if (Xt != null) {
              tt = !1;
              let je = Xt(s, L);
              ut = je.left, vt = je.top, At = je.width, et = je.height;
            } else
              ut = ct, vt = gt, At = et = Ue.size(s, L);
            if (Be = Ue.fill(s, L), kt = Ue.stroke(s, L), gs)
              L == Ft && Mt <= xt.prox && (k = ut, R = vt, G = At, re = et, le = tt, X = Be, U = kt);
            else {
              let je = at[L];
              je != null && (vs[L] = ut, bs[L] = vt, cr(je, At, et, tt), or(je, Be, kt), Tt(je, ft(ut), ft(vt), q, C));
            }
          }
        }
      }
      if (gs) {
        let L = xt.prox, ve = Zt == null ? Mt <= L : Mt > L || Ft != Zt;
        if (ot || ve) {
          let xe = at[0];
          xe != null && (vs[0] = k, bs[0] = R, cr(xe, G, re, le), or(xe, X, U), Tt(xe, ft(k), ft(R), q, C));
        }
      }
    }
    if (ge.show && Ht)
      if (i != null) {
        let [_, w] = Ee.scales, [E, k] = Ee.match, [R, G] = i.cursor.sync.scales, re = i.cursor.drag;
        if (Le = re._x, Oe = re._y, Le || Oe) {
          let { left: le, top: X, width: U, height: L } = i.select, ve = i.scales[R].ori, xe = i.posToVal, He, he, $e, Xe, Ge, ct = _ != null && E(_, R), gt = w != null && k(w, G);
          ct && Le ? (ve == 0 ? (He = le, he = U) : (He = X, he = L), $e = x[_], Xe = M(xe(He, R), $e, v, 0), Ge = M(xe(He + he, R), $e, v, 0), qs(_t(Xe, Ge), Re(Ge - Xe))) : qs(0, v), gt && Oe ? (ve == 1 ? (He = le, he = U) : (He = X, he = L), $e = x[w], Xe = V(xe(He, G), $e, y, 0), Ge = V(xe(He + he, G), $e, y, 0), Ks(_t(Xe, Ge), Re(Ge - Xe))) : Ks(0, y);
        } else
          ml();
      } else {
        let _ = Re($i - Si), w = Re(Ei - xi);
        if ($.ori == 1) {
          let G = _;
          _ = w, w = G;
        }
        Le = Fe.x && _ >= Fe.dist, Oe = Fe.y && w >= Fe.dist;
        let E = Fe.uni;
        E != null ? Le && Oe && (Le = _ >= E, Oe = w >= E, !Le && !Oe && (w > _ ? Oe = !0 : Le = !0)) : Fe.x && Fe.y && (Le || Oe) && (Le = Oe = !0);
        let k, R;
        Le && ($.ori == 0 ? (k = $s, R = me) : (k = Es, R = we), qs(_t(k, R), Re(R - k)), Oe || Ks(0, y)), Oe && ($.ori == 1 ? (k = $s, R = me) : (k = Es, R = we), Ks(_t(k, R), Re(R - k)), Le || qs(0, v)), !Le && !Oe && (qs(0, 0), Ks(0, 0));
      }
    if (Fe._x = Le, Fe._y = Oe, i == null) {
      if (c) {
        if (zi != null) {
          let [_, w] = Ee.scales;
          Ee.values[0] = _ != null ? Et($.ori == 0 ? me : we, _) : null, Ee.values[1] = w != null ? Et($.ori == 1 ? me : we, w) : null;
        }
        Js(_l, s, me, we, q, C, u);
      }
      if (ms) {
        let _ = c && Ee.setSeries, w = xt.prox;
        Zt == null ? Mt <= w && $t(Ft, ks, !0, _) : Mt > w ? $t(null, ks, !0, _) : Ft != Zt && $t(Ft, ks, !0, _);
      }
    }
    ot && (Q.idx = u, fl()), r !== !1 && De("setCursor");
  }
  let Ut = null;
  Object.defineProperty(s, "rect", {
    get() {
      return Ut == null && Ys(!1), Ut;
    }
  });
  function Ys(i = !1) {
    i ? Ut = null : (Ut = T.getBoundingClientRect(), De("syncRect", Ut));
  }
  function Ti(i, r, c, u, d, v, y) {
    N._lock || Ht && i != null && i.movementX == 0 && i.movementY == 0 || (pl(i, r, c, u, d, v, y, !1, i != null), i != null ? Qt(null, !0, !0) : Qt(r, !0, !1));
  }
  function pl(i, r, c, u, d, v, y, _, w) {
    if (Ut == null && Ys(!1), Yt(i), i != null)
      c = i.clientX - Ut.left, u = i.clientY - Ut.top;
    else {
      if (c < 0 || u < 0) {
        me = -10, we = -10;
        return;
      }
      let [E, k] = Ee.scales, R = r.cursor.sync, [G, re] = R.values, [le, X] = R.scales, [U, L] = Ee.match, ve = r.axes[0].side % 2 == 1, xe = $.ori == 0 ? q : C, He = $.ori == 1 ? q : C, he = ve ? v : d, $e = ve ? d : v, Xe = ve ? u : c, Ge = ve ? c : u;
      if (le != null ? c = U(E, le) ? h(G, x[E], xe, 0) : -10 : c = xe * (Xe / he), X != null ? u = L(k, X) ? h(re, x[k], He, 0) : -10 : u = He * (Ge / $e), $.ori == 1) {
        let ct = c;
        c = u, u = ct;
      }
    }
    w && (r == null || r.cursor.event.type == _l) && ((c <= 1 || c >= q - 1) && (c = ts(c, q)), (u <= 1 || u >= C - 1) && (u = ts(u, C))), _ ? (Si = c, xi = u, [$s, Es] = N.move(s, c, u)) : (me = c, we = u);
  }
  const dl = {
    width: 0,
    height: 0,
    left: 0,
    top: 0
  };
  function ml() {
    En(dl, !1);
  }
  let Ci, Ri, Pi, Mi;
  function Ni(i, r, c, u, d, v, y) {
    Ht = !0, Le = Oe = Fe._x = Fe._y = !1, pl(i, r, c, u, d, v, y, !0, !1), i != null && (Ve(wl, Tl, Li, !1), Js(er, s, $s, Es, q, C, null));
    let { left: _, top: w, width: E, height: k } = ge;
    Ci = _, Ri = w, Pi = E, Mi = k;
  }
  function Li(i, r, c, u, d, v, y) {
    Ht = Fe._x = Fe._y = !1, pl(i, r, c, u, d, v, y, !1, !0);
    let { left: _, top: w, width: E, height: k } = ge, R = E > 0 || k > 0, G = Ci != _ || Ri != w || Pi != E || Mi != k;
    if (R && G && En(ge), Fe.setScale && R && G) {
      let re = _, le = E, X = w, U = k;
      if ($.ori == 1 && (re = w, le = k, X = _, U = E), Le && zt(
        P,
        Et(re, P),
        Et(re + le, P)
      ), Oe)
        for (let L in x) {
          let ve = x[L];
          L != P && ve.from == null && ve.min != fe && zt(
            L,
            Et(X + U, L),
            Et(X, L)
          );
        }
      ml();
    } else N.lock && (N._lock = !N._lock, Qt(r, !0, i != null));
    i != null && (fs(wl, Tl), Js(wl, s, me, we, q, C, null));
  }
  function ba(i, r, c, u, d, v, y) {
    if (N._lock)
      return;
    Yt(i);
    let _ = Ht;
    if (Ht) {
      let w = !0, E = !0, k = 10, R, G;
      $.ori == 0 ? (R = Le, G = Oe) : (R = Oe, G = Le), R && G && (w = me <= k || me >= q - k, E = we <= k || we >= C - k), R && w && (me = me < $s ? 0 : q), G && E && (we = we < Es ? 0 : C), Qt(null, !0, !0), Ht = !1;
    }
    me = -10, we = -10, ue.fill(null), Qt(null, !0, !0), _ && (Ht = _);
  }
  function Oi(i, r, c, u, d, v, y) {
    N._lock || (Yt(i), Zn(), ml(), i != null && Js(nr, s, me, we, q, C, null));
  }
  function Di() {
    z.forEach(Uu), Jn(s.width, s.height, !0);
  }
  is(On, Ns, Di);
  const Ts = {};
  Ts.mousedown = Ni, Ts.mousemove = Ti, Ts.mouseup = Li, Ts.dblclick = Oi, Ts.setSeries = (i, r, c, u) => {
    let d = Ee.match[2];
    c = d(s, r, c), c != -1 && $t(c, u, !0, !1);
  }, We && (Ve(er, T, Ni), Ve(_l, T, Ti), Ve(tr, T, (i) => {
    Yt(i), Ys(!1);
  }), Ve(sr, T, ba), Ve(nr, T, Oi), Dl.add(s), s.syncRect = Ys);
  const An = s.hooks = t.hooks || {};
  function De(i, r, c) {
    al ? js.push([i, r, c]) : i in An && An[i].forEach((u) => {
      u.call(null, s, r, c);
    });
  }
  (t.plugins || []).forEach((i) => {
    for (let r in i.hooks)
      An[r] = (An[r] || []).concat(i.hooks[r]);
  });
  const Hi = (i, r, c) => c, Ee = Ae({
    key: null,
    setSeries: !1,
    filters: {
      pub: dr,
      sub: dr
    },
    scales: [P, S[1] ? S[1].scale : null],
    match: [mr, mr, Hi],
    values: [null, null]
  }, N.sync);
  Ee.match.length == 2 && Ee.match.push(Hi), N.sync = Ee;
  const zi = Ee.key, gl = Ao(zi);
  function Js(i, r, c, u, d, v, y) {
    Ee.filters.pub(i, r, c, u, d, v, y) && gl.pub(i, r, c, u, d, v, y);
  }
  gl.sub(s);
  function ya(i, r, c, u, d, v, y) {
    Ee.filters.sub(i, r, c, u, d, v, y) && Ts[i](null, r, c, u, d, v, y);
  }
  s.pub = ya;
  function _a() {
    gl.unsub(s), Dl.delete(s), Gt.clear(), Pl(On, Ns, Di), p.remove(), ae?.remove(), De("destroy");
  }
  s.destroy = _a;
  function vl() {
    De("init", t, e), di(e || t.data, !1), D[P] ? cl(P, D[P]) : Zn(), yn = ge.show && (ge.width > 0 || ge.height > 0), Kt = ot = !0, Jn(t.width, t.height);
  }
  return S.forEach(fi), z.forEach(Qo), n ? n instanceof HTMLElement ? (n.appendChild(p), vl()) : n(s, vl) : vl(), s;
}
Ie.assign = Ae;
Ie.fmtNum = Ql;
Ie.rangeNum = Dn;
Ie.rangeLog = Wn;
Ie.rangeAsinh = Jl;
Ie.orient = as;
Ie.pxRatio = oe;
Ie.join = Pc;
Ie.fmtDate = ei, Ie.tzDate = Wc;
Ie.sync = Ao;
{
  Ie.addGap = $u, Ie.clipGaps = Bn;
  let t = Ie.paths = {
    points: Mo
  };
  t.linear = Lo, t.stepped = ku, t.bars = Tu, t.spline = Ru;
}
const Iu = '.uplot,.uplot *,.uplot *:before,.uplot *:after{box-sizing:border-box}.uplot{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";line-height:1.5;width:min-content}.u-title{text-align:center;font-size:18px;font-weight:700}.u-wrap{position:relative;user-select:none}.u-over,.u-under{position:absolute}.u-under{overflow:hidden}.uplot canvas{display:block;position:relative;width:100%;height:100%}.u-axis{position:absolute}.u-legend{font-size:14px;margin:auto;text-align:center}.u-inline{display:block}.u-inline *{display:inline-block}.u-inline tr{margin-right:16px}.u-legend th{font-weight:600}.u-legend th>*{vertical-align:middle;display:inline-block}.u-legend .u-marker{width:1em;height:1em;margin-right:4px;background-clip:padding-box!important}.u-inline.u-live th:after{content:":";vertical-align:middle}.u-inline:not(.u-live) .u-value{display:none}.u-series>*{padding:4px}.u-series th{cursor:pointer}.u-legend .u-off>*{opacity:.3}.u-select{background:#00000012;position:absolute;pointer-events:none}.u-cursor-x,.u-cursor-y{position:absolute;left:0;top:0;pointer-events:none;will-change:transform}.u-hz .u-cursor-x,.u-vt .u-cursor-y{height:100%;border-right:1px dashed #607D8B}.u-hz .u-cursor-y,.u-vt .u-cursor-x{width:100%;border-bottom:1px dashed #607D8B}.u-cursor-pt{position:absolute;top:0;left:0;border-radius:50%;border:0 solid;pointer-events:none;will-change:transform;background-clip:padding-box!important}.u-axis.u-off,.u-select.u-off,.u-cursor-x.u-off,.u-cursor-y.u-off,.u-cursor-pt.u-off{display:none}';
class Wu extends Ms {
  static styles = [
    Wr(Iu),
    Vr`
      :host { display: block; position: relative; min-width: 0; }
      .wrap { width: 100%; height: var(--pa-chart-height, 220px); }
      .u-legend { display: none; }
      .readout {
        position: absolute;
        top: 4px;
        inset-inline-end: 8px;
        padding: 1px 6px;
        border-radius: var(--radius-sm, 4px);
        background: var(--bg-surface, #fff);
        border: 1px solid var(--border-color, #ccc);
        color: var(--text-primary);
        font-size: var(--font-size-sm, 12px);
        font-variant-numeric: tabular-nums;
        pointer-events: none;
      }
      .empty {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--text-muted);
        font-size: var(--font-size-sm, 12px);
        pointer-events: none;
        text-align: center;
        padding: var(--space-md, 12px);
      }
    `
  ];
  static properties = {
    buffer: { attribute: !1 },
    version: { type: Number },
    unit: { type: String },
    seconds: { type: Number },
    emptyText: { type: String },
    paused: { type: Boolean },
    readout: { state: !0 }
  };
  #e = null;
  #s = 0;
  #t = null;
  /** Last data given to uPlot (the cursor readout looks values up in it). */
  #n = [[], []];
  constructor() {
    super(), this.buffer = null, this.version = 0, this.unit = "g", this.seconds = 30, this.emptyText = "", this.paused = !1, this.readout = "";
  }
  connectedCallback() {
    super.connectedCallback(), this.#t = new ResizeObserver(() => this.#a()), this.#t.observe(this);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.#t?.disconnect(), this.#t = null, this.#s && cancelAnimationFrame(this.#s), this.#s = 0, this.#r();
  }
  /** Rebuilds the chart with the current theme colours. */
  restyle() {
    this.#r(), this.#i();
  }
  updated(e) {
    e.has("seconds") || e.has("unit") ? this.restyle() : (e.has("version") || e.has("paused")) && this.#i();
  }
  #i() {
    this.#s || this.paused || (this.#s = requestAnimationFrame(() => {
      this.#s = 0, this.#u();
    }));
  }
  #l(e, n) {
    return getComputedStyle(this).getPropertyValue(e).trim() || n;
  }
  #r() {
    this.#e?.destroy(), this.#e = null;
  }
  #a() {
    const e = this.renderRoot.querySelector(".wrap");
    !e || e.clientWidth === 0 || (this.#e ? this.#e.setSize({ width: e.clientWidth, height: e.clientHeight }) : this.#i());
  }
  #c(e) {
    const n = this.#l("--accent", "#3b82f6"), s = this.#l("--text-muted", "#888"), l = this.#l("--border-color", "#8884"), o = this.unit === "g" ? "g" : "counts", a = this.unit === "g" ? 2 : 25, h = {
      width: Math.max(e.clientWidth, 200),
      height: Math.max(e.clientHeight, 120),
      legend: { show: !1 },
      cursor: { drag: { x: !1, y: !1 }, points: { size: 6 } },
      scales: {
        x: { time: !1, range: () => [-this.seconds, 0] },
        y: {
          range: (f, p, g) => {
            if (!Number.isFinite(p) || !Number.isFinite(g)) return [-1, 1];
            const m = Math.max(g - p, a), b = (g + p) / 2;
            return [b - m * 0.6, b + m * 0.6];
          }
        }
      },
      axes: [
        {
          stroke: s,
          grid: { stroke: l, width: 1 },
          ticks: { stroke: l },
          values: (f, p) => p.map((g) => `${g}s`)
        },
        {
          stroke: s,
          grid: { stroke: l, width: 1 },
          ticks: { stroke: l },
          size: 56,
          label: o,
          labelSize: 14
        }
      ],
      series: [{}, { stroke: n, width: 1.5, points: { show: !1 } }],
      hooks: {
        setCursor: [
          (f) => {
            const p = f.cursor.idx, g = p == null ? void 0 : this.#n[1][p];
            this.readout = g === void 0 ? "" : `${g.toFixed(this.unit === "g" ? 2 : 0)} ${o}`;
          }
        ]
      }
    };
    return new Ie(h, this.#n, e);
  }
  #u() {
    const e = this.renderRoot.querySelector(".wrap"), n = this.buffer;
    if (!e || !n) return;
    const s = n.times(), l = s[s.length - 1] ?? 0;
    if (this.#n = [s.map((o) => o - l), n.values()], !this.#e) {
      if (e.clientWidth === 0) return;
      this.#e = this.#c(e);
    }
    this.#e.setData(this.#n);
  }
  render() {
    const e = !this.buffer || this.buffer.length === 0;
    return I`
      <div class="wrap"></div>
      ${this.readout ? I`<span class="readout">${this.readout}</span>` : K}
      ${e && this.emptyText ? I`<div class="empty">${this.emptyText}</div>` : K}
    `;
  }
}
const Hr = ["step_response", "search_overshoot"], Vu = 2, dn = [
  { id: "test", gcode: "TEST_PRESSURE_ADVANCE", applies: !1 },
  { id: "calibrate", gcode: "PA_CALIBRATE", applies: !0 }
];
function en(t) {
  return dn.find((e) => e.id === t) ?? dn[0];
}
const Gu = [
  { key: "SLOW_FLOW", type: "number", placeholder: "2", above: 0 },
  { key: "HIGH_FLOW", type: "number", above: 0 },
  { key: "PURGE_LENGTH", type: "number", above: 0 },
  { key: "SEGMENT_TIME", type: "number", placeholder: "0.5", above: 0 },
  { key: "TEST_REPETITIONS", type: "int", placeholder: "10", min: 1 },
  { key: "FILTER_WINDOW", type: "number", placeholder: "0.01", above: 0, max: 0.04 },
  { key: "EXTRUDE_FORCE_SIGN", type: "sign", placeholder: "0" },
  { key: "PA_RANGE", type: "range", placeholder: "0,0.2", method: "search_overshoot" },
  { key: "EXTRUDER", type: "extruder" },
  { key: "FORCE_SENSOR", type: "sensor" }
];
function zl(t) {
  return Gu.filter((e) => !e.method || e.method === t);
}
function mn(t) {
  const e = Number(t);
  return t !== "" && Number.isFinite(e) ? e : null;
}
function Bu(t, e) {
  const n = mn(e);
  return n === null || t.type === "int" && !Number.isInteger(n) || t.type === "sign" && !(Number.isInteger(n) && n >= -1 && n <= 1) || t.above !== void 0 && !(n > t.above) || t.min !== void 0 && n < t.min || t.max !== void 0 && n > t.max ? null : n;
}
function ju(t) {
  const e = t.split(",").map((l) => l.trim());
  if (e.length !== 2) return null;
  const n = mn(e[0]), s = mn(e[1]);
  return n === null || s === null || n < 0 || s >= Vu || n >= s ? null : [n, s];
}
const qu = /^[^\s"'\r\n]+$/;
function tn(t, e, n) {
  const s = [t.gcode, `METHOD=${e}`], l = [];
  for (const h of zl(e)) {
    const f = (n[h.key] ?? "").trim();
    if (f !== "")
      if (h.type === "range") {
        const p = ju(f);
        p ? s.push(`${h.key}=${p[0]},${p[1]}`) : l.push(h.key);
      } else if (h.type === "sensor" || h.type === "extruder")
        qu.test(f) ? s.push(`${h.key}=${f}`) : l.push(h.key);
      else {
        const p = Bu(h, f);
        p === null ? l.push(h.key) : s.push(`${h.key}=${p}`);
      }
  }
  const o = mn((n.SLOW_FLOW ?? "").trim()), a = mn((n.HIGH_FLOW ?? "").trim());
  return o !== null && a !== null && o > 0 && a > 0 && a <= o && (l.includes("HIGH_FLOW") || l.push("HIGH_FLOW")), { script: s.join(" "), invalid: l };
}
const Ku = new Set(dn.map((t) => t.gcode));
function Yu(t) {
  const e = [];
  for (const n of t.split(/\r?\n/)) {
    const s = n.trim();
    !s || s.startsWith(";") || s.startsWith("#") || e.push(s.split(/\s+/)[0].toUpperCase());
  }
  return e;
}
function zr(t, e) {
  if (t === null || !Number.isFinite(t) || t < 0) return null;
  const n = Number(t.toFixed(4));
  return e && e !== "extruder" ? `SET_PRESSURE_ADVANCE ADVANCE=${n} EXTRUDER=${e}` : `SET_PRESSURE_ADVANCE ADVANCE=${n}`;
}
const Ju = /^load_cell(_probe)?(\s|$)/i, Zu = /^extruder\d*$/i;
function zo(t) {
  const e = t.trim().split(/\s+/);
  return e[e.length - 1];
}
function Qu(t) {
  const e = t.pa_tester, n = {};
  for (const [l, o] of Object.entries(e ?? {}))
    o != null && o !== "" && (n[l] = String(o));
  const s = Object.keys(t);
  return {
    hasPaTester: e !== void 0,
    options: n,
    loadCells: s.filter((l) => Ju.test(l)).map((l) => ({ section: l, name: zo(l) })),
    extruders: s.filter((l) => Zu.test(l))
  };
}
function Nn(t, e = "") {
  const n = e || t.options.force_sensor || "";
  return n ? t.loadCells.find((s) => s.section === n || s.name === n) ?? {
    section: n,
    name: zo(n)
  } : t.loadCells.length === 1 ? t.loadCells[0] : null;
}
async function Fo(t) {
  const e = await t.request(
    "printer.objects.query",
    { objects: { configfile: ["settings"] } }
  );
  return Qu(e?.status?.configfile?.settings ?? {});
}
function Rn(t) {
  return typeof t == "number" && Number.isFinite(t) ? t : null;
}
function Xu(t) {
  const e = t?.data;
  if (!Array.isArray(e)) return { unit: "g", samples: [] };
  let n = !0;
  const s = [];
  for (const a of e) {
    if (!Array.isArray(a)) continue;
    const h = Rn(a[0]);
    if (h === null) continue;
    const f = Rn(a[1]);
    f === null && (n = !1), s.push({ time: h, g: f, counts: Rn(a[2]), tare: Rn(a[3]) ?? 0 });
  }
  const l = n ? "g" : "counts", o = [];
  for (const a of s) {
    const h = l === "g" ? a.g : a.counts === null ? null : a.counts - a.tare;
    h !== null && o.push({ time: a.time, value: h });
  }
  return { unit: l, samples: o };
}
function eh(t, e) {
  if (t.length === 0) return t.slice();
  const n = [];
  let s = t[0].time, l = 0, o = 0, a = s;
  for (const h of t)
    h.time - s >= e && o > 0 && (n.push({ time: a, value: l / o }), s = h.time, l = 0, o = 0), l += h.value, o++, a = h.time;
  return o > 0 && n.push({ time: a, value: l / o }), n;
}
const th = 0.02;
function sh(t, e, n, s = () => performance.now() / 1e3) {
  let l = null, o = null, a = !1;
  const h = () => {
    o || a || (n.onSource("status", "connecting"), o = t.subscribe(
      { [e.section]: ["force_g"] },
      (p) => {
        const g = p?.[e.section]?.force_g;
        typeof g != "number" || !Number.isFinite(g) || (n.onSource("status", "live"), n.onSamples([{ time: s(), value: g }], "g"));
      },
      { immediate: !0 }
    ));
  }, f = () => {
    o?.(), o = null;
  };
  return typeof t.klippyStream != "function" ? h() : l = t.klippyStream(
    "load_cell/dump_force",
    { load_cell: e.name },
    (p) => {
      const g = Xu(p);
      g.samples.length && n.onSamples(eh(g.samples, th), g.unit);
    },
    (p) => {
      a || (p === "unavailable" ? (n.onSource("stream", "unavailable"), h()) : (f(), n.onSource("stream", p)));
    }
  ), () => {
    a = !0, l?.(), l = null, f();
  };
}
function oi() {
  return {
    running: !1,
    method: null,
    perFlow: [],
    overall: null,
    search: [],
    found: null,
    corrected: null,
    forceSign: null,
    warnings: [],
    error: null,
    value: null
  };
}
const ai = /^(TEST_PRESSURE_ADVANCE|PA_CALIBRATE)\b/i, Uo = /^Detected extrude_force_sign=(-?\d+)/, Io = /^WARNING: high_flow is less than 2x slow_flow/, Wo = /^Searching for optimal pressure_advance/, nh = /^PA calibration results:/, lh = /^flow=\s*(-?\d+(?:\.\d+)?)\s+pressure_advance=(-?\d+(?:\.\d+)?)/, ih = /^overall pressure_advance=(-?\d+(?:\.\d+)?)/, rh = /^Failed to detect Pressure Advance value/, oh = /^Tested pressure_advance=(-?\d+(?:\.\d+)?)\s*->\s*(no overshoot|overshoot)/, ah = /^Search complete:\s*(\d+) tests?, pressure_advance=(-?\d+(?:\.\d+)?)/, ch = /^PA correction: pressure_advance=(-?\d+(?:\.\d+)?)/, Fr = /^WARNING:\s*(.+)$/, uh = /^Test (\d+): pressure_advance=(-?\d+(?:\.\d+)?)/, hh = /^(Wait for calculations\.\.|\(accounts for force data filtering\)|Check sensor and filament)/;
function fh(t) {
  const e = Array.isArray(t) ? t : [t], n = [];
  for (const s of e)
    if (typeof s == "string")
      for (const l of s.split(/\r?\n/)) {
        const o = l.trim();
        o && n.push(o);
      }
  return n;
}
function ci(t) {
  return t.startsWith("!!") ? { text: t.replace(/^!!\s*/, ""), error: !0 } : { text: t.replace(/^\/\/\s*/, ""), error: !1 };
}
function Vo(t) {
  const { text: e } = ci(t);
  return ai.test(e) || Uo.test(e) || Io.test(e) || Wo.test(e);
}
function ph(t) {
  return ai.test(ci(t).text);
}
function dh(t) {
  for (let e = t.length - 1; e >= 0; e--)
    if (ph(t[e])) return t.slice(e);
  for (let e = t.length - 1; e >= 0; e--)
    if (Vo(t[e])) return t.slice(e);
  return [];
}
function mh(t) {
  const e = /\bMETHOD=(step_response|search_overshoot)\b/i.exec(t);
  return e ? e[1].toLowerCase() : null;
}
function zn(t) {
  const e = oi();
  for (const n of t) {
    const { text: s, error: l } = ci(n);
    if (l) {
      e.error = s, e.running = !1;
      continue;
    }
    if (ai.test(s)) {
      e.running = !0, e.error = null;
      const a = mh(s);
      a && (e.method = a);
      continue;
    }
    let o;
    if (o = Uo.exec(s))
      e.running = !0, e.forceSign = Number(o[1]);
    else if (Io.test(s))
      e.running = !0, e.warnings.push(s.replace(/^WARNING:\s*/, ""));
    else if (Wo.test(s))
      e.running = !0, e.method = "search_overshoot";
    else if (o = uh.exec(s))
      e.running = !0, e.method = "search_overshoot";
    else if (o = oh.exec(s))
      e.method = "search_overshoot", e.search.push({ pa: Number(o[1]), overshoot: o[2] === "overshoot" });
    else if (o = ah.exec(s))
      e.method = "search_overshoot", e.found = Number(o[2]), e.value = e.found, e.running = !1;
    else if (o = ch.exec(s))
      e.corrected = Number(o[1]), e.value = e.corrected;
    else if (nh.test(s))
      e.method = "step_response", e.running = !0;
    else if (o = lh.exec(s))
      e.method = "step_response", e.perFlow.push({ flow: Number(o[1]), pa: Number(o[2]) });
    else if (o = ih.exec(s))
      e.method = "step_response", e.overall = Number(o[1]), e.value = e.overall, e.running = !1;
    else if (rh.test(s))
      e.error = s, e.running = !1;
    else if (Fr.test(s))
      e.warnings.push(Fr.exec(s)[1]);
    else if (hh.test(s))
      continue;
  }
  return e.corrected === null && e.found !== null && (e.value = e.found), e;
}
const Go = 600;
function gh() {
  return {
    lines: [],
    result: oi(),
    busy: !1,
    external: !1,
    restored: !1,
    lastLineAt: 0,
    config: null,
    configError: !1
  };
}
const Fl = /* @__PURE__ */ new Map(), Ul = /* @__PURE__ */ new Map();
function cs(t) {
  let e = Fl.get(t);
  return e || (e = gh(), Fl.set(t, e)), e;
}
function Ct(t, e) {
  Fl.set(t, { ...cs(t), ...e });
  for (const n of Ul.get(t) ?? []) n();
}
function vh(t, e) {
  let n = Ul.get(t);
  return n || (n = /* @__PURE__ */ new Set(), Ul.set(t, n)), n.add(e), () => n.delete(e);
}
function bh(t) {
  const e = cs(t);
  Ct(t, {
    busy: !1,
    external: !1,
    result: { ...e.result, running: !1 },
    config: null
  });
}
function yh(t) {
  Ct(t, {
    lines: [],
    result: { ...oi(), running: !0 },
    busy: !0,
    external: !1
  });
}
function _h(t, e) {
  const n = cs(t), s = e ? [...n.lines, `!! ${e}`].slice(-300) : n.lines, l = zn(s);
  Ct(t, { busy: !1, lines: s, result: { ...l, running: !1 } });
}
function wh(t, e, n = Date.now() / 1e3) {
  const s = cs(t);
  let l = s.lines, o = s.external, a = s.busy || s.result.running;
  for (const f of e)
    !s.busy && Vo(f) && !a && (l = [], o = !0, a = !0), a && (l = [...l, f], !s.busy && !zn(l).running && (a = !1));
  if (l === s.lines) return;
  l = l.slice(-300);
  const h = zn(l);
  Ct(t, {
    lines: l,
    result: s.busy ? { ...h, running: !0 } : h,
    external: o && h.running,
    lastLineAt: n
  });
}
function Sh(t, e, n = Date.now() / 1e3) {
  const s = cs(t);
  if (s.restored || s.busy || s.lines.length > 0) {
    Ct(t, { restored: !0 });
    return;
  }
  const l = e.flatMap((p) => typeof p.message == "string" ? p.message.split(/\r?\n/) : []), o = dh(l.map((p) => p.trim()).filter(Boolean)).slice(-300), a = zn(o), h = Number(e[e.length - 1]?.time ?? 0), f = a.running && n - h < Go;
  Ct(t, {
    restored: !0,
    lines: o,
    result: { ...a, running: f },
    external: f,
    lastLineAt: h
  });
}
function xh(t, e = Date.now() / 1e3) {
  const n = cs(t);
  !n.external || n.busy || !n.result.running || e - n.lastLineAt < Go || Ct(t, { external: !1, result: { ...n.result, running: !1 } });
}
class $h {
  constructor(e = 30, n = 6e3) {
    this.windowSeconds = e, this.maxPoints = n;
  }
  #e = [];
  #s = [];
  /** Index of the first live point; points before it are waiting to be spliced. */
  #t = 0;
  get length() {
    return this.#e.length - this.#t;
  }
  push(e, n) {
    this.#e.push(e), this.#s.push(n);
    const s = e - this.windowSeconds;
    for (; this.#t < this.#e.length && this.#e[this.#t] < s; ) this.#t++;
    const l = this.length - this.maxPoints;
    l > 0 && (this.#t += l), this.#t > 1024 && this.#t > this.length && (this.#e.splice(0, this.#t), this.#s.splice(0, this.#t), this.#t = 0);
  }
  clear() {
    this.#e = [], this.#s = [], this.#t = 0;
  }
  /** Live times (a copy; uPlot keeps the arrays it is given). */
  times() {
    return this.#e.slice(this.#t);
  }
  values() {
    return this.#s.slice(this.#t);
  }
  last() {
    const e = this.#e.length - 1;
    return e >= this.#t ? { time: this.#e[e], value: this.#s[e] } : null;
  }
  /** Min / max of the live window, null when empty. */
  range() {
    if (this.length === 0) return null;
    let e = 1 / 0, n = -1 / 0;
    for (let s = this.#t; s < this.#s.length; s++) {
      const l = this.#s[s];
      l < e && (e = l), l > n && (n = l);
    }
    return { min: e, max: n };
  }
}
const Eh = 120;
class Ah {
  #e;
  #s = "";
  #t = null;
  #n = [];
  #i = null;
  #l = null;
  /** Live printer status for the Run button (re-read on mount, not kept in run-store). */
  printState = "";
  homedAxes = "";
  activeExtruder = "";
  klippyReady = !0;
  extruders = {};
  paStatus = null;
  // ----- live chart
  buffer = new $h(Eh, 8e3);
  /** Bumped after every push so the chart element redraws. */
  version = 0;
  chart = { kind: null, state: "connecting", unit: "g" };
  #r = !1;
  #a = "";
  #c = null;
  #u = "";
  constructor(e) {
    this.#e = e, e.addController(this);
  }
  get printerId() {
    return this.#s;
  }
  get state() {
    return cs(this.#s);
  }
  get isPrinting() {
    return this.printState === "printing" || this.printState === "paused";
  }
  get isHomed() {
    return this.homedAxes === "xyz";
  }
  get extruder() {
    return this.extruders[this.activeExtruder] ?? null;
  }
  get handle() {
    return this.#t;
  }
  hostConnected() {
    document.addEventListener("visibilitychange", this.#d), this.#f();
  }
  hostUpdate() {
    this.#t || this.#f();
  }
  hostDisconnected() {
    document.removeEventListener("visibilitychange", this.#d), this.#m();
  }
  #d = () => this.#h();
  #f() {
    const e = this.#e.api;
    if (!e || this.#t || !this.#e.isConnected || (this.#n.push(
      e.onPrinterChange(() => {
        this.#m(), this.#f(), this.#e.requestUpdate();
      })
    ), !e.printer.id)) return;
    let n;
    try {
      n = e.moonraker();
    } catch {
      return;
    }
    this.#t = n, this.#s = e.printer.id;
    const s = this.#s;
    this.#n.push(vh(s, () => this.#e.requestUpdate())), this.#n.push(
      n.subscribe(
        { print_stats: ["state"], toolhead: ["homed_axes", "extruder"], webhooks: ["state"] },
        (l) => {
          l?.print_stats?.state !== void 0 && (this.printState = String(l.print_stats.state)), l?.toolhead?.homed_axes !== void 0 && (this.homedAxes = String(l.toolhead.homed_axes)), l?.toolhead?.extruder !== void 0 && (this.activeExtruder = String(l.toolhead.extruder)), l?.webhooks?.state !== void 0 && (this.klippyReady = l.webhooks.state === "ready"), this.#e.requestUpdate();
        },
        { immediate: !0 }
      )
    ), this.#n.push(
      n.subscribe(
        {
          pa_tester: [
            "last_pressure_advance_test",
            "last_pressure_advance",
            "last_measured_pressure_advance",
            "last_corrected_pressure_advance"
          ]
        },
        (l) => {
          const o = l?.pa_tester;
          if (!o) return;
          const a = this.paStatus;
          this.paStatus = {
            test: typeof o.last_pressure_advance_test == "string" ? o.last_pressure_advance_test : a?.test ?? null,
            pa: typeof o.last_pressure_advance == "number" ? o.last_pressure_advance : a?.pa ?? null,
            measured: Array.isArray(o.last_measured_pressure_advance) ? o.last_measured_pressure_advance.filter((h) => typeof h == "number") : a?.measured ?? [],
            corrected: typeof o.last_corrected_pressure_advance == "number" ? o.last_corrected_pressure_advance : a?.corrected ?? null
          }, this.#e.requestUpdate();
        },
        { immediate: !0 }
      )
    ), this.#n.push(n.onNotify("notify_gcode_response", (l) => wh(s, fh(l)))), this.#n.push(
      n.onNotify("notify_klippy_ready", () => {
        bh(s), this.#p();
      })
    ), this.#n.push(n.onNotify("notify_config_changed", () => void this.#p())), this.#l = setInterval(() => xh(s), 3e4), this.state.config ? this.#g() : this.#p(), this.state.restored || this.#v(), this.#h();
  }
  #m() {
    for (const e of this.#n) e();
    this.#n = [], this.#i?.(), this.#i = null, this.#o(), this.#l && clearInterval(this.#l), this.#l = null, this.#t = null;
  }
  async #p() {
    const e = this.#t, n = this.#s;
    if (e)
      try {
        const s = await Fo(e);
        Ct(n, { config: s, configError: !1 }), this.#g(), this.#h();
      } catch {
        Ct(n, { configError: !0 });
      }
  }
  #g() {
    this.#i?.(), this.#i = null;
    const e = this.#t, n = this.state.config?.extruders ?? [];
    if (!e || n.length === 0) return;
    const s = ["temperature", "target", "pressure_advance", "can_extrude"];
    this.#i = e.subscribe(
      Object.fromEntries(n.map((l) => [l, s])),
      (l) => {
        for (const o of n) {
          const a = l?.[o];
          if (!a) continue;
          const h = this.extruders[o] ?? { temperature: null, target: null, pressureAdvance: null, canExtrude: null };
          this.extruders = {
            ...this.extruders,
            [o]: {
              temperature: typeof a.temperature == "number" ? a.temperature : h.temperature,
              target: typeof a.target == "number" ? a.target : h.target,
              pressureAdvance: typeof a.pressure_advance == "number" ? a.pressure_advance : h.pressureAdvance,
              canExtrude: typeof a.can_extrude == "boolean" ? a.can_extrude : h.canExtrude
            }
          };
        }
        this.#e.requestUpdate();
      },
      { immediate: !0 }
    );
  }
  async #v() {
    const e = this.#t, n = this.#s;
    if (e)
      try {
        const s = await e.request(
          "server.gcode_store",
          { count: 300 }
        );
        Sh(n, s?.gcode_store ?? []);
      } catch {
        Ct(n, { restored: !0 });
      }
  }
  // ---------------------------------------------------------------- chart
  /** Asks for the trace of the load cell `sensor` (a section name, '' — automatic). */
  setChart(e, n = "") {
    this.#r === e && this.#a === n || (this.#r = e, this.#a = n, this.#h());
  }
  clearChart() {
    this.buffer.clear(), this.version++, this.#e.requestUpdate();
  }
  #o() {
    this.#c?.(), this.#c = null, this.#u = "";
  }
  #h() {
    const e = this.#t, n = this.state.config, l = this.#r && !document.hidden && e !== null && n !== null && n ? Nn(n, this.#a) : null, o = l ? `${this.#s}|${l.section}` : "";
    o !== this.#u && (this.#o(), !(!l || !e) && (this.#u = o, this.buffer.clear(), this.chart = { kind: null, state: "connecting", unit: this.chart.unit }, this.#c = sh(e, l, {
      onSamples: (a, h) => {
        h !== this.chart.unit && (this.buffer.clear(), this.chart = { ...this.chart, unit: h });
        for (const f of a) this.buffer.push(f.time, f.value);
        this.version++, this.#e.requestUpdate();
      },
      onSource: (a, h) => {
        this.chart.kind !== null && this.chart.kind !== a && this.buffer.clear(), this.chart = { ...this.chart, kind: a, state: h }, this.#e.requestUpdate();
      }
    }), this.#e.requestUpdate()));
  }
  // ------------------------------------------------------------- commands
  /**
   * Sends one command and waits for it. `printer.gcode.script` resolves only
   * when Klipper has finished it, i.e. after the whole measurement and the
   * calculation (minutes); the host proxy has no request timeout. Meanwhile
   * the console lines arrive live.
   */
  async run(e) {
    const n = this.#t, s = this.#s;
    if (!n || this.state.busy) return;
    yh(s);
    let l;
    try {
      await n.request("printer.gcode.script", { script: e });
    } catch (o) {
      l = o instanceof Error ? o.message : String(o);
    } finally {
      _h(s, l);
    }
  }
  /** A short command that is not a measurement (G28, SET_PRESSURE_ADVANCE): no run state. */
  async send(e) {
    if (!this.#t) return !1;
    try {
      return await this.#t.request("printer.gcode.script", { script: e }), !0;
    } catch (n) {
      return console.warn("[pa-tester] command failed:", e, n), !1;
    }
  }
}
const kh = Vr`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
    min-width: 0;
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    font-size: var(--font-size-md);
    /* Width-based layout: the page area, not the window, decides (sidebars). */
    container-type: inline-size;
  }

  .panel {
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-width: 0;
  }
  .panel-header {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-sm) var(--space-md);
    border-bottom: 1px solid var(--border-color);
  }
  .panel-title {
    flex: 1;
    min-width: 0;
    font-size: var(--font-size-md);
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .panel-body {
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    min-width: 0;
  }

  .row { display: flex; align-items: center; gap: var(--space-sm); flex-wrap: wrap; }
  .muted { color: var(--text-muted); font-size: var(--font-size-sm); margin: 0; }
  .warn { color: var(--warning); font-size: var(--font-size-sm); margin: 0; }
  .error { color: var(--danger); font-size: var(--font-size-sm); margin: 0; }
  .ok { color: var(--success); font-size: var(--font-size-sm); margin: 0; }
  .mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }

  .chip {
    padding: 1px 8px;
    border-radius: 999px;
    border: 1px solid var(--border-color);
    background: var(--bg-surface-hover);
    color: var(--text-secondary);
    font-size: var(--font-size-sm);
    white-space: nowrap;
  }
  .chip.accent { border-color: var(--accent); color: var(--accent); font-weight: 600; }

  /* Command selector + gallery filters: same look as Calibrations' .sel-btn. */
  .sel-row { display: flex; gap: var(--space-xs); flex-wrap: wrap; }
  .sel-btn {
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-secondary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
  }
  .sel-btn:hover:not(:disabled) { background: var(--bg-surface-hover); }
  .sel-btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .sel-btn.active { background: var(--bg-surface-active); color: var(--accent); border-color: var(--accent); }

  .fields {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    gap: var(--space-sm);
  }
  .field { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
  .field-label { font-size: var(--font-size-sm); color: var(--text-secondary); }
  .field.invalid .field-label { color: var(--danger); }
  input, select {
    min-width: 0;
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
  }
  .field.invalid input { border-color: var(--danger); }

  .gcode {
    display: block;
    padding: var(--space-xs) var(--space-sm);
    background: var(--bg-surface-hover-no-override, var(--bg-surface-hover));
    border: 1px dashed var(--border-color);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    white-space: pre-wrap;
    word-break: break-all;
    user-select: text;
  }

  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-xs);
    padding: var(--space-xs) var(--space-md);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface-hover);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
    white-space: nowrap;
  }
  .btn:hover:not(:disabled) { background: var(--bg-surface-active); }
  .btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .btn.primary { background: var(--accent); border-color: var(--accent); color: var(--accent-text, #fff); }
  .btn:focus-visible, .sel-btn:focus-visible {
    outline: 2px solid var(--accent-ring, var(--accent));
    outline-offset: 1px;
  }
  .icon-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    width: 28px;
    height: 28px;
    padding: 0;
    border: none;
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-muted);
    cursor: pointer;
    font-size: 15px;
    line-height: 1;
  }
  .icon-btn:hover { background: var(--bg-surface-hover); color: var(--text-primary); }
  .icon-btn.active { background: var(--accent); color: var(--accent-text, #fff); }
  .icon-btn svg { display: block; }

  .spinner {
    width: 12px;
    height: 12px;
    border: 2px solid currentColor;
    border-right-color: transparent;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    flex-shrink: 0;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  .card {
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    padding: var(--space-sm);
    display: flex;
    flex-direction: column;
    gap: var(--space-xs);
  }
  .card h4 { margin: 0; font-size: var(--font-size-sm); font-weight: 600; }

  table { width: 100%; border-collapse: collapse; font-size: var(--font-size-sm); }
  th, td { padding: var(--space-xs) var(--space-sm); text-align: start; border-bottom: 1px solid var(--border-color); }
  th { color: var(--text-muted); font-weight: 500; text-transform: uppercase; letter-spacing: 0.04em; }

  details.log summary { cursor: pointer; color: var(--text-secondary); font-size: var(--font-size-sm); }
  details.log pre {
    margin: var(--space-xs) 0 0;
    max-height: 200px;
    overflow: auto;
    padding: var(--space-sm);
    background: var(--bg-surface-hover);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    white-space: pre-wrap;
    word-break: break-word;
  }
  details.log pre .err { color: var(--danger); }

  /*
   * Help popover: same look as the host's HeaderHelp. It is a [popover] in the
   * top layer (see #placeHelp in pa-tab.ts); the UA style centres popovers
   * (inset: 0; margin: auto), we drop that and set top/left/right from JS.
   */
  .help-menu {
    position: fixed;
    inset: auto;
    margin: 0;
    min-width: min(280px, calc(100vw - 16px));
    max-width: min(380px, calc(100vw - 16px));
    max-height: calc(100vh - 16px);
    overflow-y: auto;
    padding: var(--space-sm);
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-md, 0 4px 12px rgba(0, 0, 0, 0.15));
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
  }
  .help-menu:popover-open { display: flex; flex-direction: column; gap: var(--space-sm); }
  .help-title {
    padding: var(--space-xs) var(--space-sm);
    font-size: var(--font-size-sm);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    color: var(--text-muted);
  }
  .help-body {
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    padding: 0 var(--space-sm) var(--space-xs);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    line-height: 1.5;
  }
  .help-body h4 { margin: var(--space-xs) 0 2px; color: var(--text-primary); font-size: var(--font-size-sm); font-weight: 600; }
  .help-body p { margin: 0; }

  .gcode-row { display: flex; gap: var(--space-sm); align-items: stretch; }
  .gcode-row .gcode { flex: 1; min-width: 0; }
  .row.end { justify-content: flex-end; }
  b { font-weight: 600; }

  /*
   * Confirmation of PA_CALIBRATE: a native <dialog> opened with showModal()
   * lives in the browser's TOP LAYER. The Calibrations page is a size container
   * (container-type), which makes it the containing block of position:fixed
   * descendants, so a fixed div of ours would be clipped to the page area.
   */
  dialog.confirm {
    padding: 0;
    border: 1px solid var(--border-color);
    border-radius: var(--radius-lg);
    background: var(--bg-surface);
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    max-width: min(460px, 94vw);
  }
  dialog.confirm::backdrop { background: var(--bg-overlay, rgba(0, 0, 0, 0.6)); }
  .confirm-body { display: flex; flex-direction: column; gap: var(--space-sm); padding: var(--space-md); }
  .confirm-body h3 { margin: 0; font-size: var(--font-size-md); }
  .confirm-body p { margin: 0; color: var(--text-secondary); font-size: var(--font-size-sm); }

  @container (max-width: 480px) {
    .panel-body { padding: var(--space-sm); }
    .fields { grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); }
  }
  @media (pointer: coarse) {
    .icon-btn { width: 36px; height: 36px; }
    .sel-btn, .btn { min-height: 36px; }
  }
`, Th = I`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor"
  stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
  <circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
  <line x1="12" y1="17" x2="12.01" y2="17"></line>
</svg>`, Ur = [30, 60, 120], sn = (t, e = 4) => t == null ? "—" : t.toFixed(e);
class Ch extends kl {
  static styles = kh;
  static properties = {
    ...kl.properties,
    command: { state: !0 },
    method: { state: !0 },
    values: { state: !0 },
    chartOpen: { state: !0 },
    chartSeconds: { state: !0 },
    chartPaused: { state: !0 },
    copied: { state: !0 },
    helpOpen: { state: !0 }
  };
  #e = new Ah(this);
  /** Printer whose settings are loaded into the fields. */
  #s = "";
  #t = null;
  #n = null;
  constructor() {
    super(), this.command = "test", this.method = "step_response", this.values = {}, this.chartOpen = !0, this.chartSeconds = 30, this.chartPaused = !1, this.copied = null, this.helpOpen = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.#n = this.api?.onThemeChange(() => this.renderRoot.querySelector("tessera-pa-force-chart")?.restyle()) ?? null;
  }
  willUpdate(e) {
    super.willUpdate(e);
    const n = this.#e.printerId;
    this.api && n && n !== this.#s && (this.#s = n, this.#i()), this.#e.setChart(this.chartOpen && this.#r(), this.values.FORCE_SENSOR ?? "");
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.#n?.(), this.#n = null, this.#h(!1), this.#s = "", this.#t && clearTimeout(this.#t);
  }
  #i() {
    const e = this.api.settings, n = e.get("command");
    this.command = dn.some((o) => o.id === n) ? n : "test";
    const s = e.get("method");
    this.method = s && Hr.includes(s) ? s : "step_response", this.values = e.get("values") ?? {}, this.chartOpen = e.get("chartOpen") ?? !0;
    const l = e.get("chartSeconds");
    this.chartSeconds = Ur.includes(l) ? l : 30;
  }
  #l(e, n) {
    this.api?.settings.set(e, n);
  }
  #r() {
    const e = this.#e.state.config;
    return !!(e && Nn(e, this.values.FORCE_SENSOR ?? ""));
  }
  // ---------------------------------------------------------------- actions
  #a(e) {
    this.command = e, this.#l("command", e);
  }
  #c(e) {
    this.method = e, this.#l("method", e);
  }
  #u(e, n) {
    this.values = { ...this.values, [e]: n }, this.#l("values", this.values);
  }
  #d() {
    this.chartOpen = !this.chartOpen, this.#l("chartOpen", this.chartOpen);
  }
  #f(e) {
    this.chartSeconds = e, this.#l("chartSeconds", e);
  }
  #m() {
    const e = en(this.command), n = tn(e, this.method, this.values);
    n.invalid.length || this.#b() || (e.applies ? this.renderRoot.querySelector("dialog")?.showModal() : this.#e.run(n.script));
  }
  #p() {
    const e = tn(en(this.command), this.method, this.values);
    this.renderRoot.querySelector("dialog")?.close(), !(e.invalid.length || this.#b()) && this.#e.run(e.script);
  }
  async #g() {
    const e = zr(this.#e.state.result.value, this.#e.activeExtruder || null);
    e && await this.#e.send(e);
  }
  async #v(e, n) {
    try {
      await navigator.clipboard.writeText(e);
    } catch {
      window.prompt(this.t("patester.common.copyManually"), e);
      return;
    }
    this.copied = n, this.#t && clearTimeout(this.#t), this.#t = setTimeout(() => this.copied = null, 1500);
  }
  // ------------------------------------------------------------------ help
  /**
   * The help popover lives in the browser's TOP LAYER (Popover API): our panel
   * clips its content and the Calibrations page is a size container, so a
   * positioned div of ours could not leave the page area. `popover="auto"`
   * brings light dismiss for free; we place it next to the button like the
   * host's HeaderHelp does.
   */
  #o = () => {
    const e = this.renderRoot.querySelector(".help-btn"), n = this.renderRoot.querySelector(".help-menu");
    if (!e || !n) return;
    const s = e.getBoundingClientRect(), l = n.offsetHeight, o = n.offsetWidth, a = window.innerHeight - s.bottom - 4, h = l <= a ? s.bottom + 4 : l <= s.top - 4 ? s.top - 4 - l : Math.max(8, window.innerHeight - l - 8);
    if (n.style.top = `${h}px`, document.documentElement.getAttribute("dir") === "rtl")
      n.style.left = `${Math.min(Math.max(8, s.left), Math.max(8, window.innerWidth - o - 8))}px`, n.style.right = "auto";
    else {
      const f = Math.min(Math.max(8, window.innerWidth - s.right), Math.max(8, window.innerWidth - o - 8));
      n.style.right = `${f}px`, n.style.left = "auto";
    }
  };
  #h(e) {
    window.removeEventListener("resize", this.#o), document.removeEventListener("scroll", this.#o, !0), e && (window.addEventListener("resize", this.#o), document.addEventListener("scroll", this.#o, !0));
  }
  #y(e) {
    this.helpOpen = e.newState === "open", this.helpOpen && this.#o(), this.#h(this.helpOpen);
  }
  /** Why Run is not possible now, or null. Our own requests skip our guard (see guard.ts), so we check here. */
  #b() {
    const e = this.#e, n = e.state.config;
    return e.klippyReady ? e.state.busy || e.state.result.running ? this.t("patester.block.running") : e.isPrinting ? this.t("patester.block.printing") : e.isHomed ? n && !Nn(n, this.values.FORCE_SENSOR ?? "") ? n.loadCells.length === 0 ? this.t("patester.block.noSensor") : this.t("patester.block.ambiguous") : e.extruder?.canExtrude === !1 ? this.t("patester.block.cold") : null : this.t("patester.block.homing") : this.t("patester.block.klippy");
  }
  // ---------------------------------------------------------------- render
  render() {
    const e = this.#e.state;
    return !this.api || !this.#e.printerId ? I`<p class="muted">${this.t("patester.common.noPrinter")}</p>` : e.config ? e.config.hasPaTester ? I`${this.#S()}${this.#E()}${this.#$()}` : I`<section class="panel"><div class="panel-body">
        <p class="warn">${this.t("patester.common.notInstalled")}</p>
      </div></section>` : I`<section class="panel"><div class="panel-body">
        <p class="muted">${e.configError ? this.t("patester.common.configError") : this.t("patester.common.loading")}</p>
      </div></section>`;
  }
  #_() {
    const e = this.t("patester.help.title");
    return I`
      <button
        class="icon-btn help-btn ${this.helpOpen ? "active" : ""}"
        popovertarget="pa-help"
        title=${e}
        aria-label=${e}
      >${Th}</button>
      <div id="pa-help" class="help-menu" popover="auto" role="dialog" aria-label=${e} @toggle=${this.#y}>
        <div class="help-title">${e}</div>
        <div class="help-body">
          <h4>${this.t("patester.help.runTitle")}</h4>
          <p>${this.t("patester.help.run")}</p>
          <h4>${this.t("patester.help.applyTitle")}</h4>
          <p>${this.t("patester.help.apply")}</p>
          <h4>${this.t("patester.help.chartTitle")}</h4>
          <p>${this.t("patester.help.chart")}</p>
        </div>
      </div>
    `;
  }
  #w(e) {
    const n = zl(this.method).find((g) => g.key === e), s = this.#e.state.config, l = this.values[e] ?? "", a = tn(en(this.command), this.method, this.values).invalid.includes(e), h = this.#e.state.busy, f = (g) => this.#u(e, g.target.value);
    let p;
    if (n.type === "sensor" || n.type === "extruder") {
      const g = n.type === "sensor" ? s.loadCells.map((m) => m.section) : s.extruders;
      p = I`<select .value=${l} ?disabled=${h} @change=${f}>
        <option value="">${this.t("patester.common.default")}</option>
        ${g.map((m) => I`<option value=${m} ?selected=${m === l}>${m}</option>`)}
      </select>`;
    } else if (n.type === "sign")
      p = I`<select .value=${l} ?disabled=${h} @change=${f}>
        <option value="">${this.t("patester.common.default")}</option>
        ${["-1", "0", "1"].map((g) => I`<option value=${g} ?selected=${g === l}>${g}</option>`)}
      </select>`;
    else {
      const g = s.options[e.toLowerCase()];
      p = I`<input
        type=${n.type === "range" ? "text" : "number"}
        inputmode="decimal"
        step=${n.type === "int" ? "1" : "any"}
        placeholder=${g ?? n.placeholder ?? "—"}
        .value=${l}
        ?disabled=${h}
        @input=${f}
      />`;
    }
    return I`<label class="field ${a ? "invalid" : ""}" title=${this.t(`patester.param.${e}`)}>
      <span class="field-label mono">${e}</span>
      ${p}
    </label>`;
  }
  #S() {
    const e = this.#e, n = e.state, s = n.result, l = en(this.command), o = tn(l, this.method, this.values), a = this.#b(), h = n.busy || s.running, f = e.extruder?.pressureAdvance ?? null, p = zr(s.value, e.activeExtruder || null);
    return I`
      <section class="panel">
        <header class="panel-header">
          <span class="panel-title">${this.t("patester.title")}</span>
          ${f !== null ? I`<span class="chip mono" title=${this.t("patester.result.current")}>PA ${sn(f, 4)}</span>` : K}
          ${this.#_()}
        </header>
        <div class="panel-body">
          <div class="sel-row" role="radiogroup" aria-label=${this.t("patester.command.label")}>
            ${dn.map(
      (g) => I`<button
                class="sel-btn ${g.id === this.command ? "active" : ""}"
                role="radio"
                aria-checked=${g.id === this.command}
                ?disabled=${n.busy}
                title=${g.gcode}
                @click=${() => this.#a(g.id)}
              >${this.t(`patester.command.${g.id}`)}</button>`
    )}
          </div>
          <p class="muted">${this.t(`patester.command.${this.command}Hint`)}</p>

          <div class="sel-row" role="radiogroup" aria-label=${this.t("patester.method.label")}>
            ${Hr.map(
      (g) => I`<button
                class="sel-btn ${g === this.method ? "active" : ""}"
                role="radio"
                aria-checked=${g === this.method}
                ?disabled=${n.busy}
                @click=${() => this.#c(g)}
              >${this.t(`patester.method.${g}`)}</button>`
    )}
          </div>
          <p class="muted">${this.t(`patester.method.${this.method}Hint`)}</p>

          <div class="fields">${zl(this.method).map((g) => this.#w(g.key))}</div>

          ${o.invalid.length ? I`<p class="error">${this.t("patester.block.invalid", { fields: o.invalid.join(", ") })}</p>` : K}
          ${a && !h ? I`<p class="warn">${a}</p>` : K}

          <div class="gcode-row">
            <code class="gcode mono">${o.script}</code>
            <button class="btn" @click=${() => void this.#v(o.script, "gcode")}>
              ${this.copied === "gcode" ? this.t("patester.common.copied") : this.t("patester.common.copy")}
            </button>
          </div>
          <div class="row">
            <button class="btn primary" ?disabled=${!!a || o.invalid.length > 0} @click=${() => this.#m()}>
              ${h ? I`<span class="spinner"></span> ${this.t("patester.run.running")}` : this.t(`patester.run.${this.command}`)}
            </button>
            ${!e.isHomed && e.klippyReady && !h && !e.isPrinting ? I`<button class="btn" @click=${() => void e.send("G28")}>${this.t("patester.run.home")}</button>` : K}
          </div>

          ${h ? I`<p class="row muted">
                <span class="spinner"></span>
                ${n.external ? I`<span class="chip">${this.t("patester.run.external")}</span>` : K}
                ${this.t("patester.run.started")}
              </p>` : K}
          ${s.error ? I`<p class="error">${s.error}</p>` : K}

          ${this.#x(p, h)}

          ${n.lines.length ? I`<details class="log">
                <summary>${this.t("patester.run.log", { count: n.lines.length })}</summary>
                <pre class="mono">${n.lines.map((g) => I`<span class=${g.startsWith("!!") ? "err" : ""}>${g}\n</span>`)}</pre>
              </details>` : K}
        </div>
      </section>
    `;
  }
  #x(e, n) {
    const s = this.#e.state.result, l = this.#e.paStatus;
    return s.perFlow.length || s.search.length || s.overall !== null || s.found !== null ? I`
      <div class="card">
        <h4>${this.t("patester.result.title")}</h4>
        ${s.perFlow.length ? I`<table>
              <thead><tr><th>${this.t("patester.result.flow")}</th><th>${this.t("patester.result.pa")}</th></tr></thead>
              <tbody>${s.perFlow.map(
      (a) => I`<tr><td class="mono">${a.flow.toFixed(2)}</td><td class="mono">${a.pa.toFixed(3)}</td></tr>`
    )}</tbody>
            </table>` : K}
        ${s.search.length ? I`<table>
              <thead><tr><th>${this.t("patester.result.tested")}</th><th></th></tr></thead>
              <tbody>${s.search.map(
      (a) => I`<tr>
                  <td class="mono">${a.pa.toFixed(4)}</td>
                  <td>${a.overshoot ? this.t("patester.result.overshoot") : this.t("patester.result.noOvershoot")}</td>
                </tr>`
    )}</tbody>
            </table>` : K}
        ${s.overall !== null ? I`<p class="ok">${this.t("patester.result.overall")}: <b class="mono">${sn(s.overall, 3)}</b></p>` : K}
        ${s.found !== null ? I`<p class="ok">${this.t("patester.result.found")}: <b class="mono">${sn(s.found)}</b></p>` : K}
        ${s.corrected !== null ? I`<p class="ok">${this.t("patester.result.corrected")}: <b class="mono">${sn(s.corrected)}</b></p>` : K}
        ${s.forceSign !== null ? I`<p class="muted">${this.t("patester.result.forceSign", { sign: s.forceSign })}</p>` : K}
        ${s.warnings.map((a) => I`<p class="warn">${a}</p>`)}
        ${e && !n && this.command === "test" && this.#e.klippyReady ? I`<div class="row">
              <button class="btn" @click=${() => void this.#g()}>${this.t("patester.run.applyMeasured")}</button>
              <button class="btn" @click=${() => void this.#v(e, "apply")}>
                ${this.copied === "apply" ? this.t("patester.common.copied") : this.t("patester.common.copy")}
              </button>
              <code class="mono muted">${e}</code>
            </div>
            <p class="muted">${this.t("patester.run.saveHint")}</p>` : K}
      </div>
    ` : l?.pa !== null && l?.pa !== void 0 ? I`<p class="muted">${this.t("patester.result.lastKlipper", { test: l.test ?? "—", pa: sn(l.pa) })}</p>` : K;
  }
  #$() {
    const e = tn(en(this.command), this.method, this.values);
    return I`<dialog class="confirm" @click=${(n) => n.target === n.currentTarget && n.currentTarget.close()}>
      <div class="confirm-body">
        <h3>${this.t("patester.confirm.title")}</h3>
        <p>${this.t("patester.confirm.body")}</p>
        <code class="gcode mono">${e.script}</code>
        <div class="row end">
          <button class="btn" @click=${(n) => n.currentTarget.closest("dialog").close()}>
            ${this.t("patester.confirm.cancel")}
          </button>
          <button class="btn primary" @click=${() => this.#p()}>${this.t("patester.confirm.ok")}</button>
        </div>
      </div>
    </dialog>`;
  }
  #E() {
    const e = this.#e, n = e.state.config, s = Nn(n, this.values.FORCE_SENSOR ?? ""), l = e.buffer.last(), o = e.buffer.range(), a = e.chart.unit === "g" ? "g" : this.t("patester.chart.counts"), h = e.chart.unit === "g" ? 2 : 0, f = (m) => m === void 0 ? "—" : `${m.toFixed(h)} ${a}`;
    let p = K;
    e.chart.kind === "stream" && e.chart.state === "live" ? p = I`<span class="chip">${this.t("patester.chart.sourceStream")}</span>` : e.chart.kind === "status" && (p = I`<span class="chip" title=${this.t("patester.chart.sourceStatusHint")}>${this.t("patester.chart.sourceStatus")}</span>`);
    let g = this.t("patester.chart.noData");
    return s ? this.chartOpen ? e.chart.state === "connecting" && (g = this.t("patester.chart.connecting")) : g = "" : g = n.loadCells.length ? this.t("patester.block.ambiguous") : this.t("patester.block.noSensor"), I`
      <section class="panel">
        <header class="panel-header">
          <span class="panel-title">${this.t("patester.chart.title")}</span>
          ${s ? I`<span class="chip mono" title=${s.section}>${s.section}</span>` : K}
          ${this.chartOpen ? p : K}
          <button class="btn" @click=${() => this.#d()}>
            ${this.chartOpen ? this.t("patester.chart.hide") : this.t("patester.chart.show")}
          </button>
        </header>
        ${this.chartOpen ? I`<div class="panel-body">
              <div class="row">
                <span class="chip mono">${this.t("patester.chart.now")} ${f(l?.value)}</span>
                <span class="chip mono">${this.t("patester.chart.min")} ${f(o?.min)}</span>
                <span class="chip mono">${this.t("patester.chart.max")} ${f(o?.max)}</span>
              </div>
              <tessera-pa-force-chart
                .buffer=${e.buffer}
                .version=${e.version}
                .unit=${e.chart.unit}
                .seconds=${this.chartSeconds}
                .paused=${this.chartPaused}
                .emptyText=${g}
              ></tessera-pa-force-chart>
              <div class="row">
                <div class="sel-row" role="radiogroup" aria-label=${this.t("patester.chart.window")}>
                  ${Ur.map(
      (m) => I`<button
                      class="sel-btn ${m === this.chartSeconds ? "active" : ""}"
                      role="radio"
                      aria-checked=${m === this.chartSeconds}
                      @click=${() => this.#f(m)}
                    >${m} ${this.t("patester.chart.sec")}</button>`
    )}
                </div>
                <button class="btn" @click=${() => this.chartPaused = !this.chartPaused}>
                  ${this.chartPaused ? this.t("patester.chart.resume") : this.t("patester.chart.pause")}
                </button>
                <button class="btn" @click=${() => e.clearChart()}>${this.t("patester.chart.clear")}</button>
              </div>
              <p class="muted">${this.t("patester.chart.tare")}</p>
            </div>` : K}
      </section>
    `;
  }
}
async function Lh(t, e) {
  Jr(t);
  try {
    return (await Fo(t.moonraker())).hasPaTester;
  } catch {
    return !1;
  }
}
const Rh = 3e3;
async function Ph(t) {
  const e = Wa();
  if (!e) return null;
  const n = e.moonrakerFor(t);
  try {
    const s = async () => {
      const o = (await n.request("printer.objects.query", {
        objects: { print_stats: ["state"], toolhead: ["homed_axes", "extruder"], configfile: ["settings"] }
      }))?.status ?? {}, a = String(o.toolhead?.extruder ?? "");
      let h = null;
      if (a) {
        const f = o.configfile?.settings ?? {}, p = Number(f[a]?.min_extrude_temp), m = (await n.request("printer.objects.query", {
          objects: { [a]: ["temperature"] }
        }))?.status?.[a]?.temperature;
        Number.isFinite(p) && typeof m == "number" && (h = m < p);
      }
      return {
        printState: String(o.print_stats?.state ?? ""),
        homedAxes: String(o.toolhead?.homed_axes ?? ""),
        cold: h
      };
    };
    return await Promise.race([
      s(),
      new Promise((l) => setTimeout(() => l(null), Rh))
    ]);
  } catch {
    return null;
  }
}
async function Oh(t, e, n) {
  if (t.method !== "printer.gcode.script") return { action: "allow" };
  const s = String(t.params?.script ?? "");
  if (!Yu(s).some((o) => Ku.has(o))) return { action: "allow" };
  const l = await Ph(n.targetPrinterId);
  return l ? l.printState === "printing" || l.printState === "paused" ? { action: "deny", reasonKey: "patester.guard.printing" } : l.homedAxes !== "xyz" ? { action: "deny", reasonKey: "patester.guard.homing" } : l.cold === !0 ? { action: "deny", reasonKey: "patester.guard.cold" } : { action: "allow" } : { action: "allow" };
}
jl("tessera-pa-tester-tab", Ch);
jl("tessera-pa-tester-bridge", Ba);
jl("tessera-pa-force-chart", Wu);
const Dh = { en: Va, ru: Ga };
export {
  Oh as guardPaTester,
  Lh as hasPaTester,
  Dh as locales
};
