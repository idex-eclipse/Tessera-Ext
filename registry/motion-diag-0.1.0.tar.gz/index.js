/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const sn = globalThis, To = sn.ShadowRoot && (sn.ShadyCSS === void 0 || sn.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, Eo = Symbol(), kr = /* @__PURE__ */ new WeakMap();
let Gl = class {
  constructor(t, e, i) {
    if (this._$cssResult$ = !0, i !== Eo) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t, this.t = e;
  }
  get styleSheet() {
    let t = this.o;
    const e = this.t;
    if (To && t === void 0) {
      const i = e !== void 0 && e.length === 1;
      i && (t = kr.get(e)), t === void 0 && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), i && kr.set(e, t));
    }
    return t;
  }
  toString() {
    return this.cssText;
  }
};
const Yl = (s) => new Gl(typeof s == "string" ? s : s + "", void 0, Eo), ri = (s, ...t) => {
  const e = s.length === 1 ? s[0] : t.reduce((i, n, o) => i + ((r) => {
    if (r._$cssResult$ === !0) return r.cssText;
    if (typeof r == "number") return r;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + r + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(n) + s[o + 1], s[0]);
  return new Gl(e, s, Eo);
}, Cc = (s, t) => {
  if (To) s.adoptedStyleSheets = t.map((e) => e instanceof CSSStyleSheet ? e : e.styleSheet);
  else for (const e of t) {
    const i = document.createElement("style"), n = sn.litNonce;
    n !== void 0 && i.setAttribute("nonce", n), i.textContent = e.cssText, s.appendChild(i);
  }
}, Ar = To ? (s) => s : (s) => s instanceof CSSStyleSheet ? ((t) => {
  let e = "";
  for (const i of t.cssRules) e += i.cssText;
  return Yl(e);
})(s) : s;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: zc, defineProperty: Nc, getOwnPropertyDescriptor: Rc, getOwnPropertyNames: Lc, getOwnPropertySymbols: Oc, getPrototypeOf: Fc } = Object, wn = globalThis, Mr = wn.trustedTypes, Hc = Mr ? Mr.emptyScript : "", Uc = wn.reactiveElementPolyfillSupport, Di = (s, t) => s, fo = { toAttribute(s, t) {
  switch (t) {
    case Boolean:
      s = s ? Hc : null;
      break;
    case Object:
    case Array:
      s = s == null ? s : JSON.stringify(s);
  }
  return s;
}, fromAttribute(s, t) {
  let e = s;
  switch (t) {
    case Boolean:
      e = s !== null;
      break;
    case Number:
      e = s === null ? null : Number(s);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(s);
      } catch {
        e = null;
      }
  }
  return e;
} }, Zl = (s, t) => !zc(s, t), Tr = { attribute: !0, type: String, converter: fo, reflect: !1, useDefault: !1, hasChanged: Zl };
Symbol.metadata ??= Symbol("metadata"), wn.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
let Ys = class extends HTMLElement {
  static addInitializer(t) {
    this._$Ei(), (this.l ??= []).push(t);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(t, e = Tr) {
    if (e.state && (e.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(t) && ((e = Object.create(e)).wrapped = !0), this.elementProperties.set(t, e), !e.noAccessor) {
      const i = Symbol(), n = this.getPropertyDescriptor(t, i, e);
      n !== void 0 && Nc(this.prototype, t, n);
    }
  }
  static getPropertyDescriptor(t, e, i) {
    const { get: n, set: o } = Rc(this.prototype, t) ?? { get() {
      return this[e];
    }, set(r) {
      this[e] = r;
    } };
    return { get: n, set(r) {
      const c = n?.call(this);
      o?.call(this, r), this.requestUpdate(t, c, i);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(t) {
    return this.elementProperties.get(t) ?? Tr;
  }
  static _$Ei() {
    if (this.hasOwnProperty(Di("elementProperties"))) return;
    const t = Fc(this);
    t.finalize(), t.l !== void 0 && (this.l = [...t.l]), this.elementProperties = new Map(t.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(Di("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(Di("properties"))) {
      const e = this.properties, i = [...Lc(e), ...Oc(e)];
      for (const n of i) this.createProperty(n, e[n]);
    }
    const t = this[Symbol.metadata];
    if (t !== null) {
      const e = litPropertyMetadata.get(t);
      if (e !== void 0) for (const [i, n] of e) this.elementProperties.set(i, n);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [e, i] of this.elementProperties) {
      const n = this._$Eu(e, i);
      n !== void 0 && this._$Eh.set(n, e);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(t) {
    const e = [];
    if (Array.isArray(t)) {
      const i = new Set(t.flat(1 / 0).reverse());
      for (const n of i) e.unshift(Ar(n));
    } else t !== void 0 && e.push(Ar(t));
    return e;
  }
  static _$Eu(t, e) {
    const i = e.attribute;
    return i === !1 ? void 0 : typeof i == "string" ? i : typeof t == "string" ? t.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise((t) => this.enableUpdating = t), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((t) => t(this));
  }
  addController(t) {
    (this._$EO ??= /* @__PURE__ */ new Set()).add(t), this.renderRoot !== void 0 && this.isConnected && t.hostConnected?.();
  }
  removeController(t) {
    this._$EO?.delete(t);
  }
  _$E_() {
    const t = /* @__PURE__ */ new Map(), e = this.constructor.elementProperties;
    for (const i of e.keys()) this.hasOwnProperty(i) && (t.set(i, this[i]), delete this[i]);
    t.size > 0 && (this._$Ep = t);
  }
  createRenderRoot() {
    const t = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return Cc(t, this.constructor.elementStyles), t;
  }
  connectedCallback() {
    this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$EO?.forEach((t) => t.hostConnected?.());
  }
  enableUpdating(t) {
  }
  disconnectedCallback() {
    this._$EO?.forEach((t) => t.hostDisconnected?.());
  }
  attributeChangedCallback(t, e, i) {
    this._$AK(t, i);
  }
  _$ET(t, e) {
    const i = this.constructor.elementProperties.get(t), n = this.constructor._$Eu(t, i);
    if (n !== void 0 && i.reflect === !0) {
      const o = (i.converter?.toAttribute !== void 0 ? i.converter : fo).toAttribute(e, i.type);
      this._$Em = t, o == null ? this.removeAttribute(n) : this.setAttribute(n, o), this._$Em = null;
    }
  }
  _$AK(t, e) {
    const i = this.constructor, n = i._$Eh.get(t);
    if (n !== void 0 && this._$Em !== n) {
      const o = i.getPropertyOptions(n), r = typeof o.converter == "function" ? { fromAttribute: o.converter } : o.converter?.fromAttribute !== void 0 ? o.converter : fo;
      this._$Em = n;
      const c = r.fromAttribute(e, o.type);
      this[n] = c ?? this._$Ej?.get(n) ?? c, this._$Em = null;
    }
  }
  requestUpdate(t, e, i, n = !1, o) {
    if (t !== void 0) {
      const r = this.constructor;
      if (n === !1 && (o = this[t]), i ??= r.getPropertyOptions(t), !((i.hasChanged ?? Zl)(o, e) || i.useDefault && i.reflect && o === this._$Ej?.get(t) && !this.hasAttribute(r._$Eu(t, i)))) return;
      this.C(t, e, i);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(t, e, { useDefault: i, reflect: n, wrapped: o }, r) {
    i && !(this._$Ej ??= /* @__PURE__ */ new Map()).has(t) && (this._$Ej.set(t, r ?? e ?? this[t]), o !== !0 || r !== void 0) || (this._$AL.has(t) || (this.hasUpdated || i || (e = void 0), this._$AL.set(t, e)), n === !0 && this._$Em !== t && (this._$Eq ??= /* @__PURE__ */ new Set()).add(t));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (e) {
      Promise.reject(e);
    }
    const t = this.scheduleUpdate();
    return t != null && await t, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
        for (const [n, o] of this._$Ep) this[n] = o;
        this._$Ep = void 0;
      }
      const i = this.constructor.elementProperties;
      if (i.size > 0) for (const [n, o] of i) {
        const { wrapped: r } = o, c = this[n];
        r !== !0 || this._$AL.has(n) || c === void 0 || this.C(n, void 0, o, c);
      }
    }
    let t = !1;
    const e = this._$AL;
    try {
      t = this.shouldUpdate(e), t ? (this.willUpdate(e), this._$EO?.forEach((i) => i.hostUpdate?.()), this.update(e)) : this._$EM();
    } catch (i) {
      throw t = !1, this._$EM(), i;
    }
    t && this._$AE(e);
  }
  willUpdate(t) {
  }
  _$AE(t) {
    this._$EO?.forEach((e) => e.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(t) {
    return !0;
  }
  update(t) {
    this._$Eq &&= this._$Eq.forEach((e) => this._$ET(e, this[e])), this._$EM();
  }
  updated(t) {
  }
  firstUpdated(t) {
  }
};
Ys.elementStyles = [], Ys.shadowRootOptions = { mode: "open" }, Ys[Di("elementProperties")] = /* @__PURE__ */ new Map(), Ys[Di("finalized")] = /* @__PURE__ */ new Map(), Uc?.({ ReactiveElement: Ys }), (wn.reactiveElementVersions ??= []).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Po = globalThis, Er = (s) => s, hn = Po.trustedTypes, Pr = hn ? hn.createPolicy("lit-html", { createHTML: (s) => s }) : void 0, Jl = "$lit$", Ze = `lit$${Math.random().toFixed(9).slice(2)}$`, Ql = "?" + Ze, Kc = `<${Ql}>`, vs = document, Fi = () => vs.createComment(""), Hi = (s) => s === null || typeof s != "object" && typeof s != "function", Do = Array.isArray, qc = (s) => Do(s) || typeof s?.[Symbol.iterator] == "function", Xn = `[ 	
\f\r]`, $i = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Dr = /-->/g, Cr = />/g, cs = RegExp(`>|${Xn}(?:([^\\s"'>=/]+)(${Xn}*=${Xn}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), zr = /'/g, Nr = /"/g, Xl = /^(?:script|style|textarea|title)$/i, Ic = (s) => (t, ...e) => ({ _$litType$: s, strings: t, values: e }), I = Ic(1), $s = Symbol.for("lit-noChange"), tt = Symbol.for("lit-nothing"), Rr = /* @__PURE__ */ new WeakMap(), ys = vs.createTreeWalker(vs, 129);
function ta(s, t) {
  if (!Do(s) || !s.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return Pr !== void 0 ? Pr.createHTML(t) : t;
}
const Vc = (s, t) => {
  const e = s.length - 1, i = [];
  let n, o = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", r = $i;
  for (let c = 0; c < e; c++) {
    const a = s[c];
    let h, b, d = -1, m = 0;
    for (; m < a.length && (r.lastIndex = m, b = r.exec(a), b !== null); ) m = r.lastIndex, r === $i ? b[1] === "!--" ? r = Dr : b[1] !== void 0 ? r = Cr : b[2] !== void 0 ? (Xl.test(b[2]) && (n = RegExp("</" + b[2], "g")), r = cs) : b[3] !== void 0 && (r = cs) : r === cs ? b[0] === ">" ? (r = n ?? $i, d = -1) : b[1] === void 0 ? d = -2 : (d = r.lastIndex - b[2].length, h = b[1], r = b[3] === void 0 ? cs : b[3] === '"' ? Nr : zr) : r === Nr || r === zr ? r = cs : r === Dr || r === Cr ? r = $i : (r = cs, n = void 0);
    const w = r === cs && s[c + 1].startsWith("/>") ? " " : "";
    o += r === $i ? a + Kc : d >= 0 ? (i.push(h), a.slice(0, d) + Jl + a.slice(d) + Ze + w) : a + Ze + (d === -2 ? c : w);
  }
  return [ta(s, o + (s[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), i];
};
class Ui {
  constructor({ strings: t, _$litType$: e }, i) {
    let n;
    this.parts = [];
    let o = 0, r = 0;
    const c = t.length - 1, a = this.parts, [h, b] = Vc(t, e);
    if (this.el = Ui.createElement(h, i), ys.currentNode = this.el.content, e === 2 || e === 3) {
      const d = this.el.content.firstChild;
      d.replaceWith(...d.childNodes);
    }
    for (; (n = ys.nextNode()) !== null && a.length < c; ) {
      if (n.nodeType === 1) {
        if (n.hasAttributes()) for (const d of n.getAttributeNames()) if (d.endsWith(Jl)) {
          const m = b[r++], w = n.getAttribute(d).split(Ze), v = /([.?@])?(.*)/.exec(m);
          a.push({ type: 1, index: o, name: v[2], strings: w, ctor: v[1] === "." ? Bc : v[1] === "?" ? Wc : v[1] === "@" ? Gc : vn }), n.removeAttribute(d);
        } else d.startsWith(Ze) && (a.push({ type: 6, index: o }), n.removeAttribute(d));
        if (Xl.test(n.tagName)) {
          const d = n.textContent.split(Ze), m = d.length - 1;
          if (m > 0) {
            n.textContent = hn ? hn.emptyScript : "";
            for (let w = 0; w < m; w++) n.append(d[w], Fi()), ys.nextNode(), a.push({ type: 2, index: ++o });
            n.append(d[m], Fi());
          }
        }
      } else if (n.nodeType === 8) if (n.data === Ql) a.push({ type: 2, index: o });
      else {
        let d = -1;
        for (; (d = n.data.indexOf(Ze, d + 1)) !== -1; ) a.push({ type: 7, index: o }), d += Ze.length - 1;
      }
      o++;
    }
  }
  static createElement(t, e) {
    const i = vs.createElement("template");
    return i.innerHTML = t, i;
  }
}
function ei(s, t, e = s, i) {
  if (t === $s) return t;
  let n = i !== void 0 ? e._$Co?.[i] : e._$Cl;
  const o = Hi(t) ? void 0 : t._$litDirective$;
  return n?.constructor !== o && (n?._$AO?.(!1), o === void 0 ? n = void 0 : (n = new o(s), n._$AT(s, e, i)), i !== void 0 ? (e._$Co ??= [])[i] = n : e._$Cl = n), n !== void 0 && (t = ei(s, n._$AS(s, t.values), n, i)), t;
}
class jc {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: i } = this._$AD, n = (t?.creationScope ?? vs).importNode(e, !0);
    ys.currentNode = n;
    let o = ys.nextNode(), r = 0, c = 0, a = i[0];
    for (; a !== void 0; ) {
      if (r === a.index) {
        let h;
        a.type === 2 ? h = new li(o, o.nextSibling, this, t) : a.type === 1 ? h = new a.ctor(o, a.name, a.strings, this, t) : a.type === 6 && (h = new Yc(o, this, t)), this._$AV.push(h), a = i[++c];
      }
      r !== a?.index && (o = ys.nextNode(), r++);
    }
    return ys.currentNode = vs, n;
  }
  p(t) {
    let e = 0;
    for (const i of this._$AV) i !== void 0 && (i.strings !== void 0 ? (i._$AI(t, i, e), e += i.strings.length - 2) : i._$AI(t[e])), e++;
  }
}
class li {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(t, e, i, n) {
    this.type = 2, this._$AH = tt, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = i, this.options = n, this._$Cv = n?.isConnected ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && t?.nodeType === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = ei(this, t, e), Hi(t) ? t === tt || t == null || t === "" ? (this._$AH !== tt && this._$AR(), this._$AH = tt) : t !== this._$AH && t !== $s && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : qc(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== tt && Hi(this._$AH) ? this._$AA.nextSibling.data = t : this.T(vs.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    const { values: e, _$litType$: i } = t, n = typeof i == "number" ? this._$AC(t) : (i.el === void 0 && (i.el = Ui.createElement(ta(i.h, i.h[0]), this.options)), i);
    if (this._$AH?._$AD === n) this._$AH.p(e);
    else {
      const o = new jc(n, this), r = o.u(this.options);
      o.p(e), this.T(r), this._$AH = o;
    }
  }
  _$AC(t) {
    let e = Rr.get(t.strings);
    return e === void 0 && Rr.set(t.strings, e = new Ui(t)), e;
  }
  k(t) {
    Do(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let i, n = 0;
    for (const o of t) n === e.length ? e.push(i = new li(this.O(Fi()), this.O(Fi()), this, this.options)) : i = e[n], i._$AI(o), n++;
    n < e.length && (this._$AR(i && i._$AB.nextSibling, n), e.length = n);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    for (this._$AP?.(!1, !0, e); t !== this._$AB; ) {
      const i = Er(t).nextSibling;
      Er(t).remove(), t = i;
    }
  }
  setConnected(t) {
    this._$AM === void 0 && (this._$Cv = t, this._$AP?.(t));
  }
}
class vn {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, i, n, o) {
    this.type = 1, this._$AH = tt, this._$AN = void 0, this.element = t, this.name = e, this._$AM = n, this.options = o, i.length > 2 || i[0] !== "" || i[1] !== "" ? (this._$AH = Array(i.length - 1).fill(new String()), this.strings = i) : this._$AH = tt;
  }
  _$AI(t, e = this, i, n) {
    const o = this.strings;
    let r = !1;
    if (o === void 0) t = ei(this, t, e, 0), r = !Hi(t) || t !== this._$AH && t !== $s, r && (this._$AH = t);
    else {
      const c = t;
      let a, h;
      for (t = o[0], a = 0; a < o.length - 1; a++) h = ei(this, c[i + a], e, a), h === $s && (h = this._$AH[a]), r ||= !Hi(h) || h !== this._$AH[a], h === tt ? t = tt : t !== tt && (t += (h ?? "") + o[a + 1]), this._$AH[a] = h;
    }
    r && !n && this.j(t);
  }
  j(t) {
    t === tt ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}
class Bc extends vn {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === tt ? void 0 : t;
  }
}
class Wc extends vn {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== tt);
  }
}
class Gc extends vn {
  constructor(t, e, i, n, o) {
    super(t, e, i, n, o), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = ei(this, t, e, 0) ?? tt) === $s) return;
    const i = this._$AH, n = t === tt && i !== tt || t.capture !== i.capture || t.once !== i.once || t.passive !== i.passive, o = t !== tt && (i === tt || n);
    n && this.element.removeEventListener(this.name, this, i), o && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, t) : this._$AH.handleEvent(t);
  }
}
class Yc {
  constructor(t, e, i) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = i;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    ei(this, t);
  }
}
const Zc = { I: li }, Jc = Po.litHtmlPolyfillSupport;
Jc?.(Ui, li), (Po.litHtmlVersions ??= []).push("3.3.3");
const Qc = (s, t, e) => {
  const i = e?.renderBefore ?? t;
  let n = i._$litPart$;
  if (n === void 0) {
    const o = e?.renderBefore ?? null;
    i._$litPart$ = n = new li(t.insertBefore(Fi(), o), o, void 0, e ?? {});
  }
  return n._$AI(s), n;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Co = globalThis;
let Ci = class extends Ys {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    const t = super.createRenderRoot();
    return this.renderOptions.renderBefore ??= t.firstChild, t;
  }
  update(t) {
    const e = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = Qc(e, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return $s;
  }
};
Ci._$litElement$ = !0, Ci.finalized = !0, Co.litElementHydrateSupport?.({ LitElement: Ci });
const Xc = Co.litElementPolyfillSupport;
Xc?.({ LitElement: Ci });
(Co.litElementVersions ??= []).push("4.2.2");
class pn extends Ci {
  static properties = {
    api: { attribute: !1 },
    params: { attribute: !1 }
  };
  #t = [];
  constructor() {
    super(), this.api = null, this.params = {};
  }
  connectedCallback() {
    super.connectedCallback(), this.api && this.attachApi(this.api);
  }
  willUpdate(t) {
    t.has("api") && this.api && this.#t.length === 0 && this.isConnected && this.attachApi(this.api);
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    for (const t of this.#t) t();
    this.#t = [];
  }
  /** Subclasses extend this to bind to the api; the returned unsubscribers are released on disconnect. */
  attachApi(t) {
    this.#t.push(t.onLocaleChange(() => this.requestUpdate()));
  }
  track(t) {
    this.#t.push(t);
  }
  /** Translation through the HOST dictionary (our `locales` export is merged into it). */
  t(t, e) {
    return this.api ? this.api.i18n.t(t, e) : t;
  }
}
class xs extends pn {
  static properties = {
    ...pn.properties,
    store: { attribute: !1 }
  };
  #t = null;
  constructor() {
    super(), this.store = null;
  }
  connectedCallback() {
    super.connectedCallback(), this.bindStore();
  }
  willUpdate(t) {
    super.willUpdate(t), t.has("store") && this.bindStore();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.#t?.(), this.#t = null;
  }
  bindStore() {
    this.#t?.(), this.#t = this.store && this.isConnected ? this.store.subscribe(() => this.requestUpdate()) : null;
  }
}
function ai(s, t) {
  customElements.get(s) || customElements.define(s, t);
}
const tu = {
  motiondiag: {
    tabTitle: "Motion diagnostics",
    help: {
      title: "What is this?",
      record: "Record: pick the data to capture (motion, steppers, accelerometers, load cell, TMC stallguard) and press Record while the printer moves. Data stays in this browser.",
      graphs: "Graphs: choose a ready-made layout or build your own from the captured data, including calculated series (derivative, filters, deviation). This is what Klipper's motan does, without its command line. Drag on a graph to zoom, Shift + wheel zooms around the cursor, double-click resets.",
      bridge: "Recording needs the Klippy bridge (/klippysocket) of Moonraker; Klipper must be ready."
    },
    kind: {
      trapq: "Toolhead motion (trapq)",
      stepq: "Stepper step queues",
      accelerometer: "Accelerometers",
      angle: "Angle sensors",
      ldc1612: "Eddy current probes",
      loadcell: "Load cells",
      stallguard: "TMC stallguard"
    },
    capture: {
      title: "Record",
      refresh: "Refresh",
      open: "Open a log…",
      openError: "Cannot open the log: {reason}",
      loading: "Asking Klipper what can be recorded…",
      discoverError: "Cannot read the sources: {reason}",
      noSources: "Klipper reports nothing that can be recorded.",
      maxSeconds: "Stop after, s",
      start: "Record",
      again: "Record again",
      stop: "Stop",
      discard: "Discard",
      hint: "Choose the data and press Record, then run the move you want to examine. Or open a log saved earlier.",
      state: {
        idle: "Idle",
        starting: "Starting…",
        recording: "Recording",
        stopped: "Stopped",
        failed: "Failed"
      }
    },
    graphs: {
      title: "Analyse",
      chartsTitle: "Graphs",
      captured: "Captured: {sec} s",
      skip: "Start at, s",
      duration: "Length, s",
      step: "Time step",
      tooMany: "This is {n} points per series; at most {max} are computed. Lengthen the step or shorten the window.",
      preset: "Layout",
      presetCustom: "Custom",
      rowTitle: "Graph {n}",
      addSeries: "Add series",
      removeRow: "Remove graph",
      addRow: "Add graph",
      removeSeries: "Remove series",
      color: "Color",
      opacity: "Opacity",
      build: "Build graphs",
      rebuild: "Rebuild",
      cancel: "Cancel",
      outdated: "Settings changed",
      notBuilt: "Press Build graphs to compute and draw them.",
      time: "Time (s)"
    },
    save: {
      title: "Save",
      motan: "Download motan log (.tar.gz)",
      motanHint: "The capture in the format of Klipper's data_logger.py: unpack it and run motan_graph.py dump. This tab opens it again.",
      csv: "Download CSV",
      csvHint: "The data of the graphs as a table, like motan's data_export.py.",
      png: "Download PNG",
      pngHint: "All graphs in one picture with axes, titles and legends, as you see them (a zoom is kept).",
      pngSubtitle: "{date} · from {from} s, length {len} s, step {step} ms",
      csvNeedsGraphs: "Build the graphs first."
    },
    color: {
      auto: "Auto",
      accent: "Accent",
      heat: "Orange",
      cool: "Blue",
      success: "Green",
      danger: "Red",
      warning: "Yellow",
      "text-secondary": "Gray"
    },
    dialog: {
      title: "Add a series",
      kind: "Data",
      groupRaw: "Recorded data",
      groupDerived: "Calculated from other data",
      result: "Result:",
      add: "Add",
      cancel: "Cancel",
      default: "(default)"
    },
    fn: {
      trapq: "Requested motion",
      stepq: "Stepper position",
      step_phase: "Stepper phase",
      accelerometer: "Accelerometer",
      angle: "Angle sensor position",
      ldc1612: "Eddy current probe",
      loadcell: "Load cell",
      stallguard: "TMC stallguard",
      status: "Printer status field",
      derivative: "Derivative",
      integral: "Integral",
      norm2: "Vector length",
      smooth: "Smoothing",
      sos: "Filter",
      kin: "Expected stepper position",
      corexy: "CoreXY toolhead position",
      deviation: "Difference"
    },
    fnDesc: {
      trapq: "What the toolhead was commanded to do: position, velocity or acceleration, in total or per axis.",
      stepq: "Where the stepper was commanded to be, reconstructed from its step queue.",
      step_phase: "The position of the stepper within its motor phase cycle, or its microstep.",
      accelerometer: "Acceleration measured on one axis.",
      angle: "Position of a stepper measured by a magnetic angle sensor.",
      ldc1612: "Eddy current probe: coil frequency, its period or the estimated height.",
      loadcell: "Force from a load cell, or its raw ADC counts.",
      stallguard: "TMC driver stallguard result or the current level.",
      status: "Any numeric field of the printer status, as it changed during the capture.",
      derivative: "Rate of change: position becomes velocity, velocity becomes acceleration.",
      integral: "Accumulated value: acceleration becomes velocity, velocity becomes position. A reference limits the drift.",
      norm2: "Length of the vector of two or three series (for example speed from its x and y parts).",
      smooth: "Moving weighted average over a time window.",
      sos: "Low-pass, high-pass, band-pass or notch filter, with or without phase shift.",
      kin: "Where a stepper should be according to the toolhead motion and the kinematics.",
      corexy: "The toolhead x or y position computed from the two CoreXY stepper positions.",
      deviation: "The first series minus the second, for example commanded minus expected position."
    },
    param: {
      source: "Source",
      sensor: "Sensor",
      stepper: "Stepper",
      driver: "Driver",
      axis: "Axis",
      quantity: "Quantity",
      input: "Input",
      reference: "Reference",
      minuend: "From",
      subtrahend: "Minus",
      stepperA: "Stepper A (x + y)",
      stepperB: "Stepper B (x - y)",
      smoothSec: "Time, s",
      halfLife: "Half-life, s",
      statusField: "Field (object.field)",
      sosMode: "Mode",
      sosType: "Filter",
      order: "Order",
      cutoffHz: "Cutoff, Hz",
      lowHz: "Low edge, Hz",
      highHz: "High edge, Hz",
      notchHz: "Frequency, Hz",
      quality: "Quality (Q)"
    },
    choice: {
      velocity: "Velocity",
      accel: "Acceleration",
      x: "X",
      y: "Y",
      z: "Z",
      x_velocity: "X velocity",
      y_velocity: "Y velocity",
      z_velocity: "Z velocity",
      x_accel: "X acceleration",
      y_accel: "Y acceleration",
      z_accel: "Z acceleration",
      microstep: "Microstep",
      period: "Period",
      counts: "Raw ADC counts",
      sg_result: "Stallguard result",
      cs_actual: "Current level",
      filt: "Causal (adds delay)",
      filtfilt: "Zero phase (forward and back)",
      lowpass: "Low-pass",
      highpass: "High-pass",
      bandpass: "Band-pass",
      notch: "Notch"
    },
    preset: {
      motion: "Velocity and acceleration",
      stepperDeviation: "Stepper deviation from the toolhead motion",
      accelerometer: "Accelerometer, three axes",
      accelerometerFiltered: "Accelerometer with a band-pass filter",
      loadcell: "Load cell: force and counts",
      stallguard: "TMC stallguard",
      angle: "Angle sensors",
      eddy: "Eddy current probe",
      phase: "Stepper phase"
    },
    presetDesc: {
      motion: "Toolhead velocity and acceleration.",
      stepperDeviation: "The default set of motan: velocity, acceleration and how far each stepper was from where the motion put it.",
      accelerometer: "One graph for each axis.",
      accelerometerFiltered: "Raw and zero-phase band-passed 20-200 Hz, for X and Y.",
      loadcell: "Force in grams and the raw sensor counts.",
      stallguard: "Stallguard result and current level of each driver.",
      angle: "Position from each angle sensor.",
      eddy: "Coil frequency and estimated height.",
      phase: "Where in the motor phase cycle the stepper is."
    }
  }
}, eu = {
  motiondiag: {
    tabTitle: "Диагностика движения",
    help: {
      title: "Что это?",
      record: "Запись: выберите данные (движение, шаговые двигатели, акселерометры, тензодатчик, stallguard TMC) и нажмите «Записать», пока принтер двигается. Данные остаются в этом браузере.",
      graphs: "Графики: возьмите готовую раскладку или соберите свою из записанных данных, в том числе из вычисляемых рядов (производная, фильтры, отклонение). Это то, что делает motan из Klipper, без его командной строки. Выделите область на графике, чтобы увеличить; Shift + колесо масштабирует вокруг курсора, двойной щелчок сбрасывает.",
      bridge: "Для записи нужен мост Klippy (/klippysocket) в Moonraker; Klipper должен быть готов."
    },
    kind: {
      trapq: "Движение головы (trapq)",
      stepq: "Очереди шагов моторов",
      accelerometer: "Акселерометры",
      angle: "Датчики угла",
      ldc1612: "Вихретоковые датчики",
      loadcell: "Тензодатчики",
      stallguard: "Stallguard TMC"
    },
    capture: {
      title: "Запись",
      refresh: "Обновить",
      open: "Открыть лог…",
      openError: "Не удалось открыть лог: {reason}",
      loading: "Спрашиваю у Klipper, что можно записать…",
      discoverError: "Не удалось получить источники: {reason}",
      noSources: "Klipper не сообщает ничего, что можно записать.",
      maxSeconds: "Остановить через, с",
      start: "Записать",
      again: "Записать заново",
      stop: "Остановить",
      discard: "Сбросить",
      hint: "Выберите данные, нажмите «Записать» и выполните движение, которое хотите изучить. Или откройте ранее сохранённый лог.",
      state: {
        idle: "Ожидание",
        starting: "Запуск…",
        recording: "Идёт запись",
        stopped: "Остановлено",
        failed: "Сбой"
      }
    },
    graphs: {
      title: "Анализ",
      chartsTitle: "Графики",
      captured: "Записано: {sec} с",
      skip: "Начало, с",
      duration: "Длина, с",
      step: "Шаг по времени",
      tooMany: "Это {n} точек на ряд, считается не более {max}. Увеличьте шаг или сократите окно.",
      preset: "Раскладка",
      presetCustom: "Свой вариант",
      rowTitle: "График {n}",
      addSeries: "Добавить ряд",
      removeRow: "Удалить график",
      addRow: "Добавить график",
      removeSeries: "Убрать ряд",
      color: "Цвет",
      opacity: "Прозрачность",
      build: "Построить графики",
      rebuild: "Перестроить",
      cancel: "Отмена",
      outdated: "Настройки изменены",
      notBuilt: "Нажмите «Построить графики», чтобы посчитать и нарисовать их.",
      time: "Время (с)"
    },
    save: {
      title: "Сохранение",
      motan: "Скачать лог motan (.tar.gz)",
      motanHint: "Запись в формате data_logger.py из Klipper: распакуйте и запустите motan_graph.py dump. Эта вкладка тоже откроет его обратно.",
      csv: "Скачать CSV",
      csvHint: "Данные графиков таблицей, как у data_export.py из motan.",
      png: "Скачать PNG",
      pngHint: "Все графики одной картинкой с осями, подписями и легендами, как вы их видите (масштаб сохраняется).",
      pngSubtitle: "{date} · с {from} с, длина {len} с, шаг {step} мс",
      csvNeedsGraphs: "Сначала постройте графики."
    },
    color: {
      auto: "Авто",
      accent: "Акцент",
      heat: "Оранжевый",
      cool: "Синий",
      success: "Зелёный",
      danger: "Красный",
      warning: "Жёлтый",
      "text-secondary": "Серый"
    },
    dialog: {
      title: "Добавить ряд",
      kind: "Данные",
      groupRaw: "Записанные данные",
      groupDerived: "Вычисляются из других данных",
      result: "Получится:",
      add: "Добавить",
      cancel: "Отмена",
      default: "(по умолчанию)"
    },
    fn: {
      trapq: "Заданное движение",
      stepq: "Положение мотора",
      step_phase: "Фаза мотора",
      accelerometer: "Акселерометр",
      angle: "Положение по датчику угла",
      ldc1612: "Вихретоковый датчик",
      loadcell: "Тензодатчик",
      stallguard: "Stallguard TMC",
      status: "Поле статуса принтера",
      derivative: "Производная",
      integral: "Интеграл",
      norm2: "Длина вектора",
      smooth: "Сглаживание",
      sos: "Фильтр",
      kin: "Ожидаемое положение мотора",
      corexy: "Положение головы CoreXY",
      deviation: "Разность"
    },
    fnDesc: {
      trapq: "Что было приказано голове: положение, скорость или ускорение, суммарно или по оси.",
      stepq: "Где мотору было приказано быть, восстановлено из очереди его шагов.",
      step_phase: "Положение мотора внутри цикла фаз, либо его микрошаг.",
      accelerometer: "Ускорение, измеренное по одной оси.",
      angle: "Положение мотора по магнитному датчику угла.",
      ldc1612: "Вихретоковый датчик: частота катушки, её период или оценка высоты.",
      loadcell: "Усилие с тензодатчика или его «сырые» отсчёты АЦП.",
      stallguard: "Результат stallguard драйвера TMC или уровень тока.",
      status: "Любое числовое поле статуса принтера в том виде, как оно менялось во время записи.",
      derivative: "Скорость изменения: из положения получается скорость, из скорости ускорение.",
      integral: "Накопленное значение: из ускорения получается скорость, из скорости положение. Опорный ряд ограничивает дрейф.",
      norm2: "Длина вектора из двух или трёх рядов (например, скорость по её x и y).",
      smooth: "Скользящее взвешенное среднее по временному окну.",
      sos: "Фильтр низких, высоких частот, полосовой или режекторный, со сдвигом фазы или без.",
      kin: "Где должен быть мотор по движению головы и кинематике.",
      corexy: "Положение головы x или y, вычисленное по двум моторам CoreXY.",
      deviation: "Первый ряд минус второй, например заданное минус ожидаемое положение."
    },
    param: {
      source: "Источник",
      sensor: "Датчик",
      stepper: "Мотор",
      driver: "Драйвер",
      axis: "Ось",
      quantity: "Величина",
      input: "Вход",
      reference: "Опорный ряд",
      minuend: "Из",
      subtrahend: "Минус",
      stepperA: "Мотор A (x + y)",
      stepperB: "Мотор B (x - y)",
      smoothSec: "Время, с",
      halfLife: "Период полураспада, с",
      statusField: "Поле (объект.поле)",
      sosMode: "Режим",
      sosType: "Фильтр",
      order: "Порядок",
      cutoffHz: "Частота среза, Гц",
      lowHz: "Нижняя граница, Гц",
      highHz: "Верхняя граница, Гц",
      notchHz: "Частота, Гц",
      quality: "Добротность (Q)"
    },
    choice: {
      velocity: "Скорость",
      accel: "Ускорение",
      x: "X",
      y: "Y",
      z: "Z",
      x_velocity: "Скорость по X",
      y_velocity: "Скорость по Y",
      z_velocity: "Скорость по Z",
      x_accel: "Ускорение по X",
      y_accel: "Ускорение по Y",
      z_accel: "Ускорение по Z",
      microstep: "Микрошаг",
      period: "Период",
      counts: "Отсчёты АЦП",
      sg_result: "Результат stallguard",
      cs_actual: "Уровень тока",
      filt: "Причинный (добавляет задержку)",
      filtfilt: "Нулевая фаза (вперёд и назад)",
      lowpass: "Нижних частот",
      highpass: "Верхних частот",
      bandpass: "Полосовой",
      notch: "Режекторный"
    },
    preset: {
      motion: "Скорость и ускорение",
      stepperDeviation: "Отклонение моторов от движения головы",
      accelerometer: "Акселерометр, три оси",
      accelerometerFiltered: "Акселерометр с полосовым фильтром",
      loadcell: "Тензодатчик: усилие и отсчёты",
      stallguard: "Stallguard TMC",
      angle: "Датчики угла",
      eddy: "Вихретоковый датчик",
      phase: "Фаза мотора"
    },
    presetDesc: {
      motion: "Скорость и ускорение головы.",
      stepperDeviation: "Набор motan по умолчанию: скорость, ускорение и то, насколько каждый мотор отстал от заданного движением положения.",
      accelerometer: "Отдельный график для каждой оси.",
      accelerometerFiltered: "Сырой сигнал и полосовой 20-200 Гц без сдвига фазы, для X и Y.",
      loadcell: "Усилие в граммах и сырые отсчёты датчика.",
      stallguard: "Результат stallguard и уровень тока каждого драйвера.",
      angle: "Положение по каждому датчику угла.",
      eddy: "Частота катушки и оценка высоты.",
      phase: "В какой точке цикла фаз находится мотор."
    }
  }
}, ci = ri`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
    min-width: 0;
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    font-size: var(--font-size-md);
    container-type: inline-size;
  }

  .panel {
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-width: 0;
  }
  .panel-header {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: var(--space-sm);
    padding: var(--space-sm) var(--space-md);
    border-block-end: 1px solid var(--border-color);
  }
  .panel-title {
    flex: 1;
    min-width: 0;
    font-size: var(--font-size-md);
    font-weight: 600;
  }
  .panel-body {
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    min-width: 0;
  }

  .row {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    flex-wrap: wrap;
  }
  .grow {
    flex: 1;
    min-width: 0;
  }
  .muted {
    color: var(--text-muted);
    font-size: var(--font-size-sm);
    margin: 0;
  }
  .warn {
    color: var(--warning);
    font-size: var(--font-size-sm);
    margin: 0;
  }
  .error {
    color: var(--danger);
    font-size: var(--font-size-sm);
    margin: 0;
    overflow-wrap: anywhere;
  }
  .ok {
    color: var(--success);
    font-size: var(--font-size-sm);
    margin: 0;
  }
  /* Printer names, datasets and numbers read left-to-right in any UI direction. */
  .ltr {
    direction: ltr;
    unicode-bidi: isolate;
    overflow-wrap: anywhere;
  }

  button {
    min-block-size: var(--touch-target, 44px);
    padding: var(--space-xs) var(--space-md);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-secondary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
  }
  button:hover:not(:disabled) {
    background: var(--bg-surface-hover);
  }
  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  button.primary {
    background: var(--accent);
    border-color: var(--accent);
    color: var(--accent-text);
    font-weight: 600;
  }
  button.primary:hover:not(:disabled) {
    background: var(--accent-hover);
  }
  button.danger {
    border-color: var(--danger);
    color: var(--danger);
  }
  button.small {
    min-block-size: 32px;
    padding: 2px var(--space-sm);
  }
  button.icon {
    min-inline-size: 32px;
    padding: 2px 6px;
  }

  .fields {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
    gap: var(--space-sm);
  }
  .field {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }
  .field-label {
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
  }
  input,
  select {
    min-width: 0;
    min-block-size: 36px;
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
  }
  input[type='checkbox'] {
    min-block-size: 0;
    inline-size: 18px;
    block-size: 18px;
    accent-color: var(--accent);
  }
  input[type='range'] {
    min-block-size: 0;
    padding: 0;
  }
  input:focus-visible,
  select:focus-visible,
  button:focus-visible {
    outline: 2px solid var(--border-focus);
    outline-offset: 1px;
  }

  .chip {
    padding: 1px 8px;
    border-radius: 999px;
    border: 1px solid var(--border-color);
    background: var(--bg-surface-hover);
    color: var(--text-secondary);
    font-size: var(--font-size-sm);
    white-space: nowrap;
  }
  .chip.live {
    border-color: var(--success);
    color: var(--success);
  }
  .chip.bad {
    border-color: var(--danger);
    color: var(--danger);
  }
  .chip.accent {
    border-color: var(--accent);
    color: var(--accent);
    font-weight: 600;
  }

  .bar {
    block-size: 6px;
    border-radius: 3px;
    background: var(--bg-surface-hover);
    overflow: hidden;
  }
  .bar > span {
    display: block;
    block-size: 100%;
    background: var(--accent);
  }
`, su = ["trapq", "stepq", "accelerometer", "angle", "ldc1612", "loadcell", "stallguard"];
function iu(s) {
  return s < 1024 * 1024 ? `${Math.max(1, Math.round(s / 1024))} KB` : `${(s / 1024 / 1024).toFixed(s < 10 * 1024 * 1024 ? 1 : 0)} MB`;
}
class nu extends xs {
  static styles = [
    ci,
    ri`
      /* One bordered box per kind of source; the items wrap by the container width. */
      .group {
        margin: 0;
        padding: var(--space-xs) var(--space-sm) var(--space-sm);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        min-width: 0;
      }
      legend {
        padding-inline: var(--space-xs);
        font-size: var(--font-size-sm);
        font-weight: 600;
      }
      .items {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
        gap: var(--space-xs) var(--space-md);
      }
      .check {
        display: inline-flex;
        align-items: center;
        gap: var(--space-xs);
        min-block-size: 32px;
        font-size: var(--font-size-sm);
        cursor: pointer;
      }
      .item span {
        min-width: 0;
      }
    `
  ];
  attachApi(t) {
    super.attachApi(t);
    const e = this.store;
    e && e.state.discover === "idle" && e.refreshSources();
  }
  async #t(t) {
    const e = t.target, i = [...e.files ?? []];
    if (e.value = "", i.length === 0) return;
    const n = await Promise.all(i.map(async (o) => ({ name: o.name, data: new Uint8Array(await o.arrayBuffer()) })));
    await this.store.openFiles(n);
  }
  render() {
    const t = this.store;
    if (!t) return tt;
    const e = t.state, i = t.recording;
    return I`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title">${this.t("motiondiag.capture.title")}</span>
          <button class="small" ?disabled=${i || e.discover === "loading"} @click=${() => void t.refreshSources()}>
            ${this.t("motiondiag.capture.refresh")}
          </button>
          <button class="small" ?disabled=${i} @click=${() => this.renderRoot.querySelector("#open").click()}>
            ${this.t("motiondiag.capture.open")}
          </button>
          <!-- A saved capture: the .tar.gz of this tab or motan's .json.gz + .index.gz pair (both selected together). -->
          <input id="open" type="file" multiple hidden accept=".gz,.tgz,application/gzip" @change=${(n) => void this.#t(n)} />
        </div>
        <div class="panel-body">
          ${e.openError ? I`<p class="error">${this.t("motiondiag.capture.openError", { reason: e.openError })}</p>` : tt}
          ${this.#e()}
          <div class="row">
            <label class="field">
              <span class="field-label">${this.t("motiondiag.capture.maxSeconds")}</span>
              <input
                class="ltr"
                type="number"
                min="1"
                step="1"
                .value=${String(e.maxSeconds)}
                ?disabled=${i}
                @change=${(n) => t.setMaxSeconds(Number(n.target.value))}
              />
            </label>
            <span class="grow"></span>
            ${i ? I`<button class="danger" @click=${() => t.stopRecording()}>${this.t("motiondiag.capture.stop")}</button>` : I`<button
                  class="primary"
                  ?disabled=${e.selected.size === 0 || e.discover !== "ready"}
                  @click=${() => void t.startRecording()}
                >
                  ${this.t(e.capture ? "motiondiag.capture.again" : "motiondiag.capture.start")}
                </button>`}
          </div>
          ${this.#s()}
        </div>
      </section>
    `;
  }
  #e() {
    const t = this.store, e = t.state;
    if (e.discover === "loading") return I`<p class="muted">${this.t("motiondiag.capture.loading")}</p>`;
    if (e.discover === "error")
      return I`<p class="error">${this.t("motiondiag.capture.discoverError", { reason: e.discoverError })}</p>`;
    if (e.sources.length === 0) return I`<p class="muted">${this.t("motiondiag.capture.noSources")}</p>`;
    const i = t.recording;
    return I`${su.map((n) => {
      const o = e.sources.filter((a) => a.kind === n);
      if (o.length === 0) return tt;
      const r = o.map((a) => a.id), c = r.every((a) => e.selected.has(a));
      return I`
        <fieldset class="group">
          <legend>
            <label class="check">
              <input
                type="checkbox"
                .checked=${c}
                ?disabled=${i}
                @change=${(a) => t.setSelected(r, a.target.checked)}
              />
              ${this.t(`motiondiag.kind.${n}`)}
            </label>
          </legend>
          <div class="items">
            ${o.map(
        (a) => I`<label class="check item" title=${a.section || a.method}>
                <input
                  type="checkbox"
                  .checked=${e.selected.has(a.id)}
                  ?disabled=${i}
                  @change=${(h) => t.setSelected([a.id], h.target.checked)}
                />
                <span class="ltr">${a.name}</span>
              </label>`
      )}
          </div>
        </fieldset>
      `;
    })}`;
  }
  #s() {
    const t = this.store.state, e = t.snapshot;
    if (!e) return I`<p class="muted">${this.t("motiondiag.capture.hint")}</p>`;
    const i = `motiondiag.capture.state.${e.state}`;
    return I`
      <div class="row">
        <span class="chip ${e.state === "recording" ? "live" : e.state === "failed" ? "bad" : ""}">${this.t(i)}</span>
        <span class="muted ltr">${e.elapsed.toFixed(1)} s</span>
        <span class="muted ltr">${iu(e.approxBytes)}</span>
        ${t.capture && !this.store.recording ? I`<span class="grow"></span
              ><button class="small" @click=${() => this.store.discardCapture()}>${this.t("motiondiag.capture.discard")}</button>` : tt}
      </div>
      ${e.reason ? I`<p class=${e.state === "failed" ? "error" : "muted"}>${e.reason}</p>` : tt}
      <div class="row">
        ${e.sources.map(
      (n) => I`<span class="chip ltr ${n.status === "live" ? "live" : n.status === "unavailable" ? "bad" : ""}"
            >${n.id} · ${n.messages}</span
          >`
    )}
      </div>
    `;
  }
}
class V extends Error {
  name = "MotanError";
}
function ou(s) {
  const t = s.initialStatus.toolhead?.estimated_print_time;
  if (typeof t != "number") throw new V("The capture has no toolhead.estimated_print_time");
  return t;
}
function ru(s) {
  const t = [];
  let e = 0, i = 0;
  for (let n = 0; n < s.length; n++) {
    const o = s[n];
    e === 0 && o === "," ? (t.push(s.slice(i, n)), i = n + 1) : o === "(" ? e++ : e > 0 && o === ")" && e--;
  }
  return t.push(s.slice(i)), t;
}
function ea(s) {
  if (!s.includes("(") || !s.endsWith(")")) throw new V(`Malformed dataset name '${s}'`);
  const t = s.indexOf("(");
  return [s.slice(0, t), ...ru(s.slice(t + 1, -1))];
}
function lu(s) {
  const t = s.initialStatus.configfile?.settings ?? {}, e = [];
  for (const [n, o] of Object.entries(s.initialStatus))
    if (n !== "configfile")
      for (const [r, c] of Object.entries(o))
        (typeof c == "number" || typeof c == "boolean") && e.push(`${n}.${r}`);
  const i = t.printer?.kinematics;
  return {
    subscriptions: [...s.subscriptions],
    config: t,
    kinematics: typeof i == "string" ? i : void 0,
    statusFields: e
  };
}
function sa(s, t) {
  const e = `${t}:`;
  return s.subscriptions.filter((i) => i.startsWith(e)).map((i) => i.slice(e.length));
}
const mo = (s) => s.map((t) => ({ value: t, literal: !0 })), Ue = (s) => s.map((t) => ({ value: t })), nn = ["x", "y", "z"], au = [
  "velocity",
  "accel",
  ...nn,
  ...nn.map((s) => `${s}_velocity`),
  ...nn.map((s) => `${s}_accel`)
];
function us(s, t, e = "motiondiag.param.source") {
  const i = mo(sa(s, t));
  return { key: "source", kind: "choice", labelKey: e, choices: i, default: i[0]?.value };
}
const hs = (s) => (t) => sa(t, s).length > 0;
function Lr(s) {
  const t = [];
  for (const e of Object.keys(s.config)) {
    if (!e.startsWith("tmc")) continue;
    const i = e.split(/\s+/).filter(Boolean).slice(1).join(" ");
    i && typeof s.config[i]?.microsteps == "number" && s.subscriptions.includes(`stepq:${i}`) && t.push(e);
  }
  return t;
}
const ge = (s, t, e = !1) => ({ key: s, kind: "dataset", labelKey: t, optional: e });
function cu(s) {
  const t = (n, o, r, c = 0) => ({
    key: n,
    kind: "number",
    labelKey: o,
    default: r,
    min: c,
    step: 1
  }), e = typeof s.type == "string" ? s.type : "lowpass", i = [
    ge("source", "motiondiag.param.input"),
    { key: "mode", kind: "choice", labelKey: "motiondiag.param.sosMode", choices: Ue(["filt", "filtfilt"]), default: "filtfilt" },
    {
      key: "type",
      kind: "choice",
      labelKey: "motiondiag.param.sosType",
      choices: Ue(["lowpass", "highpass", "bandpass", "notch"]),
      default: "lowpass"
    }
  ];
  return e === "notch" ? [...i, t("a", "motiondiag.param.notchHz", "50", 1), t("b", "motiondiag.param.quality", "10", 0.1)] : e === "bandpass" ? [
    ...i,
    t("a", "motiondiag.param.order", "2", 1),
    t("b", "motiondiag.param.lowHz", "20", 0.1),
    t("c", "motiondiag.param.highHz", "100", 0.1)
  ] : [...i, t("a", "motiondiag.param.order", "2", 1), t("b", "motiondiag.param.cutoffHz", "50", 0.1)];
}
const ia = [
  // ---- raw datasets (readlog.py) ----
  {
    fn: "trapq",
    group: "raw",
    labelKey: "motiondiag.fn.trapq",
    descKey: "motiondiag.fnDesc.trapq",
    available: hs("trapq"),
    params: (s, t) => [
      us(t, "trapq"),
      { key: "what", kind: "choice", labelKey: "motiondiag.param.quantity", choices: Ue(au), default: "velocity" }
    ]
  },
  {
    fn: "stepq",
    group: "raw",
    labelKey: "motiondiag.fn.stepq",
    descKey: "motiondiag.fnDesc.stepq",
    available: hs("stepq"),
    params: (s, t) => [
      us(t, "stepq", "motiondiag.param.stepper"),
      { key: "smooth", kind: "number", labelKey: "motiondiag.param.smoothSec", optional: !0, default: "0.01", min: 1e-4, step: 1e-3 }
    ]
  },
  {
    fn: "step_phase",
    group: "raw",
    labelKey: "motiondiag.fn.step_phase",
    descKey: "motiondiag.fnDesc.step_phase",
    available: (s) => Lr(s).length > 0,
    params: (s, t) => {
      const e = mo(Lr(t));
      return [
        { key: "driver", kind: "choice", labelKey: "motiondiag.param.driver", choices: e, default: e[0]?.value },
        { key: "mode", kind: "choice", labelKey: "motiondiag.param.quantity", optional: !0, choices: Ue(["microstep"]), default: "" }
      ];
    }
  },
  {
    fn: "accelerometer",
    group: "raw",
    labelKey: "motiondiag.fn.accelerometer",
    descKey: "motiondiag.fnDesc.accelerometer",
    available: hs("accelerometer"),
    params: (s, t) => [
      us(t, "accelerometer", "motiondiag.param.sensor"),
      { key: "axis", kind: "choice", labelKey: "motiondiag.param.axis", choices: Ue(nn), default: "x" }
    ]
  },
  {
    fn: "angle",
    group: "raw",
    labelKey: "motiondiag.fn.angle",
    descKey: "motiondiag.fnDesc.angle",
    available: hs("angle"),
    params: (s, t) => [us(t, "angle", "motiondiag.param.sensor")]
  },
  {
    fn: "ldc1612",
    group: "raw",
    labelKey: "motiondiag.fn.ldc1612",
    descKey: "motiondiag.fnDesc.ldc1612",
    available: hs("ldc1612"),
    params: (s, t) => [
      us(t, "ldc1612", "motiondiag.param.sensor"),
      { key: "what", kind: "choice", labelKey: "motiondiag.param.quantity", optional: !0, choices: Ue(["period", "z"]), default: "" }
    ]
  },
  {
    fn: "loadcell",
    group: "raw",
    labelKey: "motiondiag.fn.loadcell",
    descKey: "motiondiag.fnDesc.loadcell",
    available: hs("loadcell"),
    params: (s, t) => [
      us(t, "loadcell", "motiondiag.param.sensor"),
      { key: "what", kind: "choice", labelKey: "motiondiag.param.quantity", optional: !0, choices: Ue(["counts"]), default: "" }
    ]
  },
  {
    fn: "stallguard",
    group: "raw",
    labelKey: "motiondiag.fn.stallguard",
    descKey: "motiondiag.fnDesc.stallguard",
    available: hs("stallguard"),
    params: (s, t) => [
      us(t, "stallguard", "motiondiag.param.stepper"),
      { key: "what", kind: "choice", labelKey: "motiondiag.param.quantity", choices: Ue(["sg_result", "cs_actual"]), default: "sg_result" }
    ]
  },
  {
    fn: "status",
    group: "raw",
    labelKey: "motiondiag.fn.status",
    descKey: "motiondiag.fnDesc.status",
    available: () => !0,
    params: (s, t) => [{ key: "field", kind: "text", labelKey: "motiondiag.param.statusField", default: t.statusFields[0] ?? "", suggest: t.statusFields }]
  },
  // ---- derived datasets (analyzers.py) ----
  {
    fn: "derivative",
    group: "derived",
    labelKey: "motiondiag.fn.derivative",
    descKey: "motiondiag.fnDesc.derivative",
    available: () => !0,
    params: () => [ge("source", "motiondiag.param.input")]
  },
  {
    fn: "integral",
    group: "derived",
    labelKey: "motiondiag.fn.integral",
    descKey: "motiondiag.fnDesc.integral",
    available: () => !0,
    params: (s) => {
      const t = [ge("source", "motiondiag.param.input"), ge("ref", "motiondiag.param.reference", !0)];
      return s.ref !== void 0 && s.ref !== "" && t.push({ key: "halfLife", kind: "number", labelKey: "motiondiag.param.halfLife", optional: !0, default: "0.015", min: 1e-3, step: 5e-3 }), t;
    }
  },
  {
    fn: "norm2",
    group: "derived",
    labelKey: "motiondiag.fn.norm2",
    descKey: "motiondiag.fnDesc.norm2",
    available: () => !0,
    params: () => [ge("a", "motiondiag.param.input"), ge("b", "motiondiag.param.input"), ge("c", "motiondiag.param.input", !0)]
  },
  {
    fn: "smooth",
    group: "derived",
    labelKey: "motiondiag.fn.smooth",
    descKey: "motiondiag.fnDesc.smooth",
    available: () => !0,
    params: () => [
      ge("source", "motiondiag.param.input"),
      { key: "time", kind: "number", labelKey: "motiondiag.param.smoothSec", optional: !0, default: "0.01", min: 1e-4, step: 1e-3 }
    ]
  },
  {
    fn: "sos",
    group: "derived",
    labelKey: "motiondiag.fn.sos",
    descKey: "motiondiag.fnDesc.sos",
    available: () => !0,
    params: (s) => cu(s)
  },
  {
    fn: "kin",
    group: "derived",
    labelKey: "motiondiag.fn.kin",
    descKey: "motiondiag.fnDesc.kin",
    available: (s) => (s.kinematics === "cartesian" || s.kinematics === "corexy") && s.subscriptions.includes("trapq:toolhead"),
    params: () => [
      { key: "stepper", kind: "choice", labelKey: "motiondiag.param.stepper", choices: mo(["stepper_x", "stepper_y", "stepper_z"]), default: "stepper_x" }
    ]
  },
  {
    fn: "corexy",
    group: "derived",
    labelKey: "motiondiag.fn.corexy",
    descKey: "motiondiag.fnDesc.corexy",
    available: () => !0,
    params: () => [
      { key: "axis", kind: "choice", labelKey: "motiondiag.param.axis", choices: Ue(["x", "y"]), default: "x" },
      ge("a", "motiondiag.param.stepperA"),
      ge("b", "motiondiag.param.stepperB")
    ]
  },
  {
    fn: "deviation",
    group: "derived",
    labelKey: "motiondiag.fn.deviation",
    descKey: "motiondiag.fnDesc.deviation",
    available: () => !0,
    params: () => [ge("a", "motiondiag.param.minuend"), ge("b", "motiondiag.param.subtrahend")]
  }
];
function zo(s) {
  return ia.find((t) => t.fn === s);
}
function on(s) {
  return ia.filter((t) => t.available(s));
}
function na(s, t, e = 0) {
  const i = zo(s.fn);
  if (!i) throw new V(`Unknown dataset type '${s.fn}'`);
  for (let n = 0; n < 12; n++) {
    let o = !1;
    for (const r of i.params(s.args, t))
      if (!(r.key in s.args)) {
        if (r.optional)
          s.args[r.key] = "";
        else if (r.kind === "dataset") {
          const c = e < 4 ? on(t).find((a) => a.group === "raw") : void 0;
          s.args[r.key] = c ? rn(c.fn, t, e + 1) : "";
        } else
          s.args[r.key] = r.default ?? "";
        o = !0;
      }
    if (!o) break;
  }
  return s;
}
function rn(s, t, e = 0) {
  return na({ fn: s, args: {} }, t, e);
}
function No(s, t) {
  const e = zo(s.fn);
  if (!e) throw new V(`Unknown dataset type '${s.fn}'`);
  const i = [];
  for (const n of e.params(s.args, t)) {
    const o = s.args[n.key];
    if (o === void 0 || o === "") {
      if (!n.optional) throw new V(`'${s.fn}': ${n.key} is required`);
      i.push("");
      continue;
    }
    if (typeof o == "string") {
      if (/[(),]/.test(o)) throw new V(`'${o}' cannot be used in a dataset name`);
      i.push(o);
    } else
      i.push(No(o, t));
  }
  for (; i.length > 0 && i[i.length - 1] === ""; ) i.pop();
  if (i.includes("")) throw new V(`'${s.fn}': an optional argument is empty but a later one is set`);
  return `${s.fn}(${i.join(",")})`;
}
class uu extends xs {
  static styles = [
    ci,
    ri`
      dialog {
        inline-size: min(560px, calc(100vw - 2 * var(--space-md)));
        max-block-size: calc(100vh - 2 * var(--space-md));
        padding: 0;
        border: 1px solid var(--border-color);
        border-radius: var(--radius-md);
        background: var(--bg-surface);
        color: var(--text-primary);
        box-shadow: var(--shadow-lg);
      }
      dialog::backdrop {
        background: var(--bg-overlay);
      }
      .head,
      .foot {
        display: flex;
        align-items: center;
        gap: var(--space-sm);
        padding: var(--space-sm) var(--space-md);
      }
      .head {
        border-block-end: 1px solid var(--border-color);
        font-weight: 600;
      }
      .foot {
        justify-content: flex-end;
        flex-wrap: wrap;
        border-block-start: 1px solid var(--border-color);
      }
      .body {
        padding: var(--space-md);
        display: flex;
        flex-direction: column;
        gap: var(--space-sm);
        overflow: auto;
        max-block-size: calc(100vh - 12rem);
      }
      /* A nested input is indented on the inline-start side, so it mirrors in RTL. */
      .nested {
        margin-inline-start: var(--space-sm);
        padding-inline-start: var(--space-sm);
        border-inline-start: 2px solid var(--accent-subtle-strong, var(--border-color));
        display: flex;
        flex-direction: column;
        gap: var(--space-sm);
      }
      .preview {
        padding: var(--space-xs) var(--space-sm);
        border: 1px dashed var(--border-color);
        border-radius: var(--radius-sm);
        font-size: var(--font-size-sm);
      }
    `
  ];
  static properties = {
    ...xs.properties,
    node: { state: !0 },
    error: { state: !0 }
  };
  #t = null;
  constructor() {
    super(), this.node = null, this.error = "";
  }
  /** Opens the dialog to add a series to `rowId` (null: to a new row). */
  open(t) {
    const e = this.store?.state.info;
    if (!e) return;
    this.#t = t;
    const i = on(e)[0];
    this.node = i ? rn(i.fn, e) : null, this.error = "", this.updateComplete.then(() => this.renderRoot.querySelector("dialog")?.showModal());
  }
  #e() {
    this.renderRoot.querySelector("dialog")?.close();
  }
  #s() {
    if (this.node)
      try {
        this.store.addSeries(this.#t, this.node), this.#e();
      } catch (t) {
        this.error = t instanceof Error ? t.message : String(t);
      }
  }
  render() {
    if (!this.store?.state.info) return tt;
    const e = this.#o();
    return I`
      <dialog @close=${() => this.node = null}>
        <div class="head">${this.t("motiondiag.dialog.title")}</div>
        <div class="body">
          ${this.node ? this.#r(this.node, (i) => this.node = i) : tt}
          ${e}
        </div>
        <div class="foot">
          <button @click=${() => this.#e()}>${this.t("motiondiag.dialog.cancel")}</button>
          <button class="primary" ?disabled=${!this.node || e === null || e.error !== void 0} @click=${() => this.#s()}>
            ${this.t("motiondiag.dialog.add")}
          </button>
        </div>
      </dialog>
    `;
  }
  /** Name and label of what the form describes, or the reason it is not valid yet. */
  #i() {
    const t = this.store.state.info;
    try {
      const e = No(this.node, t), i = this.store.describe([e]).get(e);
      return i instanceof V ? { error: i.message } : { name: e, label: i };
    } catch (e) {
      return { error: e instanceof Error ? e.message : String(e) };
    }
  }
  #o() {
    if (!this.node) return null;
    const t = this.#i();
    return "error" in t ? Object.assign(I`<p class="error">${t.error}</p>`, { error: t.error }) : I`<div class="preview"><span class="muted">${this.t("motiondiag.dialog.result")}</span> <span class="ltr">${t.label.label}</span> <span class="muted ltr">${t.label.units.replace(/\n/g, " ")}</span></div>`;
  }
  #n(t) {
    return t.literal ? t.value : this.t(`motiondiag.choice.${t.value}`);
  }
  #r(t, e) {
    const i = this.store.state.info, n = zo(t.fn), o = on(i), r = (a) => o.filter((h) => h.group === a), c = () => {
      na(t, i), this.error = "", this.requestUpdate();
    };
    return I`
      <label class="field">
        <span class="field-label">${this.t("motiondiag.dialog.kind")}</span>
        <select @change=${(a) => e(rn(a.target.value, i))}>
          <optgroup label=${this.t("motiondiag.dialog.groupRaw")}>
            ${r("raw").map((a) => I`<option value=${a.fn} ?selected=${a.fn === t.fn}>${this.t(a.labelKey)}</option>`)}
          </optgroup>
          <optgroup label=${this.t("motiondiag.dialog.groupDerived")}>
            ${r("derived").map((a) => I`<option value=${a.fn} ?selected=${a.fn === t.fn}>${this.t(a.labelKey)}</option>`)}
          </optgroup>
        </select>
      </label>
      <p class="muted">${this.t(n.descKey)}</p>
      <div class="fields">
        ${n.params(t.args, i).filter((a) => a.kind !== "dataset").map((a) => this.#l(t, a, c))}
      </div>
      ${n.params(t.args, i).filter((a) => a.kind === "dataset").map((a) => this.#a(t, a, c))}
    `;
  }
  #l(t, e, i) {
    const n = String(t.args[e.key] ?? ""), o = (c) => {
      t.args[e.key] = c, i();
    };
    if (e.kind === "choice")
      return I`<label class="field">
        <span class="field-label">${this.t(e.labelKey)}</span>
        <select @change=${(c) => o(c.target.value)}>
          ${e.optional ? I`<option value="" ?selected=${n === ""}>${this.t("motiondiag.dialog.default")}</option>` : tt}
          ${(e.choices ?? []).map((c) => I`<option value=${c.value} ?selected=${c.value === n}>${this.#n(c)}</option>`)}
        </select>
      </label>`;
    if (e.kind === "number")
      return I`<label class="field">
        <span class="field-label">${this.t(e.labelKey)}</span>
        <input
          class="ltr"
          type="number"
          .value=${n}
          min=${e.min ?? tt}
          step=${e.step ?? "any"}
          placeholder=${e.optional ? e.default ?? "" : ""}
          @input=${(c) => o(c.target.value)}
        />
      </label>`;
    const r = `sg-${e.key}`;
    return I`<label class="field">
      <span class="field-label">${this.t(e.labelKey)}</span>
      <input class="ltr" type="text" list=${r} .value=${n} @input=${(c) => o(c.target.value)} />
      <datalist id=${r}>${(e.suggest ?? []).map((c) => I`<option value=${c}></option>`)}</datalist>
    </label>`;
  }
  #a(t, e, i) {
    const n = this.store.state.info, o = t.args[e.key], r = typeof o == "object";
    return I`
      <div class="field">
        <span class="field-label">
          ${e.optional ? I`<label class="check"
                ><input
                  type="checkbox"
                  .checked=${r}
                  @change=${(c) => {
      const a = c.target.checked, h = on(n).find((b) => b.group === "raw");
      t.args[e.key] = a && h ? rn(h.fn, n) : "", i();
    }}
                />
                ${this.t(e.labelKey)}</label
              >` : this.t(e.labelKey)}
        </span>
        ${r ? I`<div class="nested">
              ${this.#r(o, (c) => {
      t.args[e.key] = c, i();
    })}
            </div>` : tt}
      </div>
    `;
  }
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const hu = { CHILD: 2 }, pu = (s) => (...t) => ({ _$litDirective$: s, values: t });
let du = class {
  constructor(t) {
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AT(t, e, i) {
    this._$Ct = t, this._$AM = e, this._$Ci = i;
  }
  _$AS(t, e) {
    return this.update(t, e);
  }
  update(t, e) {
    return this.render(...e);
  }
};
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { I: fu } = Zc, Or = (s) => s, Fr = () => document.createComment(""), xi = (s, t, e) => {
  const i = s._$AA.parentNode, n = t === void 0 ? s._$AB : t._$AA;
  if (e === void 0) {
    const o = i.insertBefore(Fr(), n), r = i.insertBefore(Fr(), n);
    e = new fu(o, r, s, s.options);
  } else {
    const o = e._$AB.nextSibling, r = e._$AM, c = r !== s;
    if (c) {
      let a;
      e._$AQ?.(s), e._$AM = s, e._$AP !== void 0 && (a = s._$AU) !== r._$AU && e._$AP(a);
    }
    if (o !== n || c) {
      let a = e._$AA;
      for (; a !== o; ) {
        const h = Or(a).nextSibling;
        Or(i).insertBefore(a, n), a = h;
      }
    }
  }
  return e;
}, ps = (s, t, e = s) => (s._$AI(t, e), s), mu = {}, gu = (s, t = mu) => s._$AH = t, bu = (s) => s._$AH, to = (s) => {
  s._$AR(), s._$AA.remove();
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Hr = (s, t, e) => {
  const i = /* @__PURE__ */ new Map();
  for (let n = t; n <= e; n++) i.set(s[n], n);
  return i;
}, oa = pu(class extends du {
  constructor(s) {
    if (super(s), s.type !== hu.CHILD) throw Error("repeat() can only be used in text expressions");
  }
  dt(s, t, e) {
    let i;
    e === void 0 ? e = t : t !== void 0 && (i = t);
    const n = [], o = [];
    let r = 0;
    for (const c of s) n[r] = i ? i(c, r) : r, o[r] = e(c, r), r++;
    return { values: o, keys: n };
  }
  render(s, t, e) {
    return this.dt(s, t, e).values;
  }
  update(s, [t, e, i]) {
    const n = bu(s), { values: o, keys: r } = this.dt(t, e, i);
    if (!Array.isArray(n)) return this.ut = r, o;
    const c = this.ut ??= [], a = [];
    let h, b, d = 0, m = n.length - 1, w = 0, v = o.length - 1;
    for (; d <= m && w <= v; ) if (n[d] === null) d++;
    else if (n[m] === null) m--;
    else if (c[d] === r[w]) a[w] = ps(n[d], o[w]), d++, w++;
    else if (c[m] === r[v]) a[v] = ps(n[m], o[v]), m--, v--;
    else if (c[d] === r[v]) a[v] = ps(n[d], o[v]), xi(s, a[v + 1], n[d]), d++, v--;
    else if (c[m] === r[w]) a[w] = ps(n[m], o[w]), xi(s, n[d], n[m]), m--, w++;
    else if (h === void 0 && (h = Hr(r, w, v), b = Hr(c, d, m)), h.has(c[d])) if (h.has(c[m])) {
      const _ = b.get(r[w]), x = _ !== void 0 ? n[_] : null;
      if (x === null) {
        const E = xi(s, n[d]);
        ps(E, o[w]), a[w] = E;
      } else a[w] = ps(x, o[w]), xi(s, n[d], x), n[_] = null;
      w++;
    } else to(n[m]), m--;
    else to(n[d]), d++;
    for (; w <= v; ) {
      const _ = xi(s, a[v + 1]);
      ps(_, o[w]), a[w++] = _;
    }
    for (; d <= m; ) {
      const _ = n[d++];
      _ !== null && to(_);
    }
    return this.ut = r, gu(s, a), $s;
  }
}), yu = 0.8, zi = ["--accent", "--heat", "--cool", "--success", "--danger", "--warning", "--text-secondary"];
let Ur = 0;
function wu(s = "g") {
  return Ur += 1, `${s}${Date.now().toString(36)}${Ur}`;
}
function ra(s, t = "") {
  return { name: s, color: t, alpha: yu };
}
function qt(s = []) {
  return { id: wu(), series: s.map((t) => ra(t)) };
}
function vu(s) {
  let t = null, e = null;
  const i = [];
  for (const n of s)
    t === null ? (t = n.units, i.push("left")) : n.units !== t ? e === null ? (e = n.units, i.push("right")) : n.units === e ? i.push("right") : (t = "Unknown", i.push("left")) : i.push("left");
  return { sides: i, left: t ?? "", right: e };
}
const Ni = (s, t) => s.subscriptions.includes(t), fe = (s, t) => s.subscriptions.filter((e) => e.startsWith(`${t}:`)).map((e) => e.slice(t.length + 1));
function Kr(s) {
  return !Ni(s, "trapq:toolhead") || s.kinematics !== "cartesian" && s.kinematics !== "corexy" ? [] : ["stepper_x", "stepper_y", "stepper_z"].filter((t) => Ni(s, `stepq:${t}`));
}
const $u = [
  {
    id: "motion",
    labelKey: "motiondiag.preset.motion",
    descKey: "motiondiag.presetDesc.motion",
    available: (s) => Ni(s, "trapq:toolhead"),
    build: () => ({ rows: [qt(["trapq(toolhead,velocity)"]), qt(["trapq(toolhead,accel)"])] })
  },
  {
    // motan's own default graph set.
    id: "stepper-deviation",
    labelKey: "motiondiag.preset.stepperDeviation",
    descKey: "motiondiag.presetDesc.stepperDeviation",
    available: (s) => Kr(s).length > 0,
    build: (s) => ({
      rows: [
        qt(["trapq(toolhead,velocity)"]),
        qt(["trapq(toolhead,accel)"]),
        ...Kr(s).filter((t) => t !== "stepper_z").map((t) => qt([`deviation(stepq(${t}),kin(${t}))`]))
      ]
    })
  },
  {
    id: "accelerometer",
    labelKey: "motiondiag.preset.accelerometer",
    descKey: "motiondiag.presetDesc.accelerometer",
    available: (s) => fe(s, "accelerometer").length > 0,
    build: (s) => {
      const t = fe(s, "accelerometer")[0];
      return { rows: ["x", "y", "z"].map((e) => qt([`accelerometer(${t},${e})`])) };
    }
  },
  {
    id: "accelerometer-filtered",
    labelKey: "motiondiag.preset.accelerometerFiltered",
    descKey: "motiondiag.presetDesc.accelerometerFiltered",
    available: (s) => fe(s, "accelerometer").length > 0,
    build: (s) => {
      const t = fe(s, "accelerometer")[0];
      return {
        rows: ["x", "y"].map(
          (e) => qt([`accelerometer(${t},${e})`, `sos(accelerometer(${t},${e}),filtfilt,bandpass,2,20,200)`])
        )
      };
    }
  },
  {
    id: "loadcell",
    labelKey: "motiondiag.preset.loadcell",
    descKey: "motiondiag.presetDesc.loadcell",
    available: (s) => fe(s, "loadcell").length > 0,
    build: (s) => {
      const t = fe(s, "loadcell")[0];
      return { rows: [qt([`loadcell(${t})`]), qt([`loadcell(${t},counts)`])] };
    }
  },
  {
    id: "stallguard",
    labelKey: "motiondiag.preset.stallguard",
    descKey: "motiondiag.presetDesc.stallguard",
    available: (s) => fe(s, "stallguard").length > 0,
    // One dataset per row for each driver, like the other presets: sg_result and cs_actual
    // have different units anyway.
    build: (s) => ({
      rows: fe(s, "stallguard").flatMap((t) => [
        qt([`stallguard(${t},sg_result)`]),
        qt([`stallguard(${t},cs_actual)`])
      ])
    })
  },
  {
    id: "angle-sensor",
    labelKey: "motiondiag.preset.angle",
    descKey: "motiondiag.presetDesc.angle",
    available: (s) => fe(s, "angle").length > 0,
    build: (s) => ({ rows: fe(s, "angle").map((t) => qt([`angle(${t})`])) })
  },
  {
    id: "eddy",
    labelKey: "motiondiag.preset.eddy",
    descKey: "motiondiag.presetDesc.eddy",
    available: (s) => fe(s, "ldc1612").length > 0,
    build: (s) => {
      const t = fe(s, "ldc1612")[0];
      return { rows: [qt([`ldc1612(${t})`]), qt([`ldc1612(${t},z)`])] };
    }
  },
  {
    id: "phase",
    labelKey: "motiondiag.preset.phase",
    descKey: "motiondiag.presetDesc.phase",
    available: (s) => Object.keys(s.config).some((t) => t.startsWith("tmc") && Ni(s, `stepq:${t.split(/\s+/).slice(1).join(" ")}`)),
    build: (s) => {
      const t = Object.keys(s.config).find((e) => e.startsWith("tmc") && Ni(s, `stepq:${e.split(/\s+/).slice(1).join(" ")}`));
      return { rows: [qt([`step_phase(${t})`])] };
    }
  }
];
function go(s) {
  return $u.filter((t) => t.available(s));
}
function xu(s, t, e, i) {
  const n = [];
  let o = !1, r = 0;
  const c = (a) => {
    const h = ++r;
    n.push(
      s.klippyStream(
        t,
        e[a],
        (b) => {
          !o && h === r && i.onData(b);
        },
        (b) => {
          if (!(o || h !== r)) {
            if (b === "unavailable" && a + 1 < e.length) {
              c(a + 1);
              return;
            }
            i.onStatus?.(b);
          }
        },
        (b) => {
          !o && h === r && i.onAck?.(b);
        }
      )
    );
  };
  return c(0), () => {
    o = !0;
    for (const a of n) a();
    n.length = 0;
  };
}
const Su = { maxSeconds: 60, maxBytes: 200 * 1024 * 1024 }, _u = {
  trapq: 360,
  stepq: 100,
  accelerometer: 240,
  angle: 120,
  ldc1612: 180,
  loadcell: 200,
  stallguard: 140
};
function ku(s, t) {
  const e = t?.data;
  return Array.isArray(e) ? 64 + e.length * (_u[s] ?? 200) : 512;
}
class Au {
  constructor(t, e, i = {}) {
    this.handle = t, this.sources = e, this.options = i, this.limits = { ...Su, ...i.limits };
    for (const n of e)
      this.kinds.set(n.id, n.kind), this.progress.set(n.id, { id: n.id, status: "connecting", messages: 0 });
  }
  state = "idle";
  reason;
  limits;
  streams = /* @__PURE__ */ new Map();
  acked = /* @__PURE__ */ new Set();
  progress = /* @__PURE__ */ new Map();
  kinds = /* @__PURE__ */ new Map();
  initialStatus = null;
  startTime = 0;
  latestTime = 0;
  bytes = 0;
  cancels = [];
  result = null;
  snapshot() {
    return {
      state: this.state,
      reason: this.reason,
      elapsed: Math.max(0, this.latestTime - this.startTime),
      approxBytes: this.bytes,
      sources: [...this.progress.values()].map((t) => ({ ...t }))
    };
  }
  /** The recorded data once the capture has stopped or failed (partial data after a failure), else null. */
  getCapture() {
    return this.result;
  }
  changed() {
    this.options.onChange?.(this.snapshot());
  }
  /**
   * Starts recording. Resolves when the status subscription is answered and the stream
   * subscriptions are issued; rejects (and the state becomes `failed`) when Klipper is not
   * ready or does not answer.
   */
  async start() {
    if (this.state !== "idle") throw new V("The capture has already been started");
    if (this.sources.length === 0) throw new V("Choose at least one source to record");
    this.state = "starting", this.changed();
    try {
      const t = await this.handle.klippyRequest("info");
      if (t.state !== "ready") throw new V(`Klipper is not ready (${t.state ?? "unknown state"})`);
      const e = await this.handle.klippyRequest("objects/list"), i = Object.fromEntries((e.objects ?? []).map((n) => [n, null]));
      await this.subscribeStatus(i);
    } catch (t) {
      throw this.fail(t instanceof Error ? t.message : String(t)), t;
    }
    if (this.state === "starting") {
      this.streams.set("status", []);
      for (const t of this.sources) this.openSource(t);
      this.state = "recording", this.changed();
    }
  }
  /** Subscribes to the status of all objects; resolves with the first answer (the initial status). */
  subscribeStatus(t) {
    return new Promise((e, i) => {
      let n = !1;
      this.cancels.push(
        this.handle.klippyStream(
          "objects/subscribe",
          { objects: t },
          (o) => this.onStatusUpdate(o),
          (o) => {
            o === "unavailable" && (n ? this.fail("The connection to Klipper was lost") : (n = !0, i(new V("The Klippy bridge is not reachable"))));
          },
          (o) => {
            if (n) return;
            n = !0;
            const r = o?.status, c = r?.toolhead?.estimated_print_time;
            if (!r || typeof c != "number") {
              i(new V("Klipper did not report toolhead.estimated_print_time"));
              return;
            }
            this.initialStatus = r, this.startTime = this.latestTime = c, e();
          }
        )
      );
    });
  }
  openSource(t) {
    this.streams.set(t.id, []), this.cancels.push(
      xu(this.handle, t.method, t.paramVariants, {
        onData: (e) => this.onSourceData(t.id, e),
        onStatus: (e) => {
          this.progress.get(t.id).status = e, this.changed();
        },
        // Only an acknowledged subscription belongs to the capture (motan does the same).
        onAck: () => {
          this.acked.add(t.id);
        }
      })
    );
  }
  onSourceData(t, e) {
    this.state === "recording" && (this.streams.get(t).push(e), this.progress.get(t).messages += 1, this.bytes += ku(this.kinds.get(t) ?? "", e), this.checkLimits(), this.changed());
  }
  onStatusUpdate(t) {
    if (this.state !== "recording" && this.state !== "starting") return;
    const i = t?.status?.toolhead?.estimated_print_time;
    typeof i == "number" && (this.latestTime = Math.max(this.latestTime, i)), this.state === "recording" && (this.streams.get("status").push(t), this.bytes += 256, this.checkLimits(), this.changed());
  }
  checkLimits() {
    this.latestTime - this.startTime >= this.limits.maxSeconds ? this.finish("stopped", `Stopped at the time limit of ${this.limits.maxSeconds} s`) : this.bytes >= this.limits.maxBytes && this.finish("stopped", "Stopped at the memory limit");
  }
  fail(t) {
    this.state === "failed" || this.state === "stopped" || this.finish("failed", t);
  }
  finish(t, e) {
    for (const i of this.cancels) i();
    this.cancels = [], this.state = t, this.reason = e, this.initialStatus && (this.result = {
      initialStatus: this.initialStatus,
      subscriptions: new Set(this.acked),
      streams: new Map(this.streams)
    }), this.changed();
  }
  /** Stops recording and returns what was recorded. Safe to call in any state. */
  stop() {
    return (this.state === "recording" || this.state === "starting") && this.finish("stopped"), this.result;
  }
}
const Mu = (s) => `${s}/dump_${s}`, Vs = { kind: "accelerometer", prefix: "accelerometer", method: Mu, paramKeys: ["sensor"] }, js = { kind: "stallguard", prefix: "stallguard", method: () => "tmc/stallguard_dump", paramKeys: ["name"] }, qr = {
  kind: "loadcell",
  prefix: "loadcell",
  method: () => "load_cell/dump_force",
  // data_logger.py uses `load_cell`; Klipper's API documentation says `sensor`.
  paramKeys: ["load_cell", "sensor"]
}, Ir = {
  adxl345: Vs,
  lis2dw: Vs,
  // lis3dh is served by the lis2dw endpoint.
  lis3dh: { ...Vs, method: () => "lis2dw/dump_lis2dw" },
  mpu9250: Vs,
  bmi160: Vs,
  icm20948: Vs,
  angle: { kind: "angle", prefix: "angle", method: () => "angle/dump_angle", paramKeys: ["sensor"] },
  probe_eddy_current: { kind: "ldc1612", prefix: "ldc1612", method: () => "ldc1612/dump_ldc1612", paramKeys: ["sensor"] },
  load_cell: qr,
  load_cell_probe: qr,
  tmc2130: js,
  tmc2209: js,
  tmc2260: js,
  tmc2240: js,
  tmc5160: js,
  tmc5262: js
};
function Tu(s) {
  const t = [], e = s.motion_report ?? {};
  for (const n of Array.isArray(e.trapq) ? e.trapq : [])
    t.push({
      id: `trapq:${n}`,
      kind: "trapq",
      name: n,
      section: "",
      method: "motion_report/dump_trapq",
      paramVariants: [{ name: n }],
      byDefault: !0
    });
  for (const n of Array.isArray(e.steppers) ? e.steppers : [])
    t.push({
      id: `stepq:${n}`,
      kind: "stepq",
      name: n,
      section: "",
      method: "motion_report/dump_stepper",
      paramVariants: [{ name: n }],
      byDefault: !0
    });
  const i = s.configfile?.settings ?? {};
  for (const n of Object.keys(i)) {
    const o = n.split(/\s+/).filter(Boolean), r = o[0];
    if (!r || !Object.hasOwn(Ir, r)) continue;
    const c = Ir[r], a = o.length > 1 ? o.slice(1).join(" ") : o[o.length - 1];
    t.push({
      id: `${c.prefix}:${a}`,
      kind: c.kind,
      name: a,
      section: n,
      method: c.method(r),
      paramVariants: c.paramKeys.map((h) => ({ [h]: a })),
      byDefault: !1
    });
  }
  return t;
}
async function Eu(s) {
  const t = await s.klippyRequest("info");
  if (t.state !== "ready")
    throw new V(`Klipper is not ready (${t.state ?? "unknown state"})`);
  const e = await s.klippyRequest("objects/query", {
    objects: { configfile: ["settings"], motion_report: null }
  });
  return Tu(e.status ?? {});
}
const nt = (s, t = 0) => ({ re: s, im: t }), Ri = (s, t) => nt(s.re + t.re, s.im + t.im), Re = (s, t) => nt(s.re - t.re, s.im - t.im), Zs = (s, t) => nt(s.re * t.re - s.im * t.im, s.re * t.im + s.im * t.re), ds = (s, t) => nt(s.re * t, s.im * t), Qs = (s) => nt(s.re, -s.im), Je = (s) => Math.hypot(s.re, s.im);
function Bs(s, t) {
  const e = t.re * t.re + t.im * t.im;
  return nt((s.re * t.re + s.im * t.im) / e, (s.im * t.re - s.re * t.im) / e);
}
function Pu(s) {
  const t = Je(s);
  if (t === 0) return nt(0, 0);
  const e = Math.sqrt((t + s.re) / 2), i = Math.sqrt((t - s.re) / 2);
  return nt(e, s.im < 0 || Object.is(s.im, -0) ? -i : i);
}
const fs = (s) => s.im === 0, Du = 2220446049250313e-31;
function Vr(s) {
  if (s.length === 0) return { zc: [], zr: [] };
  const t = 100 * Du, e = [...s].sort((d, m) => d.re - m.re || Math.abs(d.im) - Math.abs(m.im)), i = e.map((d) => Math.abs(d.im) <= t * Je(d)), n = e.filter((d, m) => i[m]).map((d) => nt(d.re, 0));
  if (n.length === e.length) return { zc: [], zr: n };
  const o = e.filter((d, m) => !i[m]), r = o.filter((d) => d.im > 0), c = o.filter((d) => d.im < 0);
  if (r.length !== c.length) throw new Error("Array contains complex value with no matching conjugate.");
  const a = r.slice(1).map((d, m) => d.re - r[m].re <= t * Je(r[m]));
  let h = 0;
  for (; h < a.length; ) {
    if (!a[h]) {
      h++;
      continue;
    }
    let d = h;
    for (; d < a.length && a[d]; ) d++;
    for (const m of [r, c]) {
      const w = m.slice(h, d + 1).sort((v, _) => Math.abs(v.im) - Math.abs(_.im));
      m.splice(h, w.length, ...w);
    }
    h = d + 1;
  }
  for (let d = 0; d < r.length; d++)
    if (Je(Re(r[d], Qs(c[d]))) > t * Je(c[d]))
      throw new Error("Array contains complex value with no matching conjugate.");
  return { zc: r.map((d, m) => ds(Ri(d, Qs(c[m])), 0.5)), zr: n };
}
function Qi(s, t, e) {
  const i = s.map((o, r) => r).sort((o, r) => Je(Re(s[o], t)) - Je(Re(s[r], t)));
  if (e === "any") return i[0];
  const n = e === "real";
  for (const o of i) if (fs(s[o]) === n) return o;
  throw new Error("no matching root");
}
function jr(s) {
  let t = [nt(1)];
  for (const e of s) {
    const i = new Array(t.length + 1).fill(null).map(() => nt(0));
    for (let n = 0; n < t.length; n++)
      i[n] = Ri(i[n], t[n]), i[n + 1] = Re(i[n + 1], Zs(t[n], e));
    t = i;
  }
  return t.map((e) => e.re);
}
function Ws(s, t, e) {
  const i = [0, 0, 0, 0, 0, 0], n = jr(s).map((r) => r * e), o = jr(t);
  for (let r = 0; r < n.length; r++) i[3 - n.length + r] = n[r];
  for (let r = 0; r < o.length; r++) i[6 - o.length + r] = o[r];
  return i;
}
function Cu(s, t, e) {
  let i = [...s], n = [...t];
  if (i.length === 0 && n.length === 0) return [[e, 0, 0, 1, 0, 0]];
  for (; i.length < n.length; ) i.push(nt(0));
  for (; n.length < i.length; ) n.push(nt(0));
  const o = Math.floor((Math.max(n.length, i.length) + 1) / 2);
  n.length % 2 === 1 && (n.push(nt(0)), i.push(nt(0)));
  const r = Vr(i);
  i = [...r.zc, ...r.zr];
  const c = Vr(n);
  n = [...c.zc, ...c.zr];
  const a = (m) => {
    let w = 0, v = 1 / 0;
    return m.forEach((_, x) => {
      const E = Math.abs(1 - Je(_));
      E < v && (v = E, w = x);
    }), w;
  }, h = (m, w) => m.filter((v, _) => _ !== w), b = (m) => m.filter(fs).length, d = Array.from({ length: o }, () => [0, 0, 0, 0, 0, 0]);
  for (let m = o - 1; m >= 0; m--) {
    const w = a(n), v = n[w];
    if (n = h(n, w), fs(v) && b(n) === 0) {
      const _ = Qi(i, v, "real"), x = i[_];
      i = h(i, _), d[m] = Ws([x, nt(0)], [v, nt(0)], 1);
    } else if (n.length + 1 === i.length && !fs(v) && b(n) === 1 && b(i) === 1) {
      const _ = Qi(i, v, "complex"), x = i[_];
      i = h(i, _), d[m] = Ws([x, Qs(x)], [v, Qs(v)], 1);
    } else {
      let _;
      if (fs(v)) {
        const x = n.map((P, M) => fs(P) ? M : -1).filter((P) => P >= 0), E = x.map((P) => n[P]), $ = x[a(E)];
        _ = n[$], n = h(n, $);
      } else
        _ = Qs(v);
      if (i.length > 0) {
        const x = Qi(i, v, "any"), E = i[x];
        if (i = h(i, x), !fs(E))
          d[m] = Ws([E, Qs(E)], [v, _], 1);
        else if (i.length > 0) {
          const $ = Qi(i, v, "real"), P = i[$];
          i = h(i, $), d[m] = Ws([E, P], [v, _], 1);
        } else
          d[m] = Ws([E], [v, _], 1);
      } else
        d[m] = Ws([], [v, _], 1);
    }
  }
  for (let m = 0; m < 3; m++) d[0][m] = d[0][m] * e;
  return d;
}
function zu(s) {
  const t = [];
  for (let e = -s + 1; e < s; e += 2) {
    const i = Math.PI * e / (2 * s);
    t.push(nt(-Math.cos(i), -Math.sin(i)));
  }
  return t;
}
function Nu(s, t, e, i) {
  if (!Number.isInteger(s) || s < 0) throw new Error("Filter order must be a nonnegative integer");
  const n = (Array.isArray(t) ? t : [t]).map((x) => x / (i / 2));
  if (n.some((x) => x <= 0)) throw new Error("filter critical frequencies must be greater than 0");
  if (n.length > 1 && !(n[0] < n[1])) throw new Error("Wn[0] must be less than Wn[1]");
  if (n.some((x) => x >= 1)) throw new Error(`Digital filter critical frequencies must be 0 < Wn < fs/2 (fs=${i} -> fs/2=${i / 2})`);
  let o = [], r = zu(s), c = 1;
  const a = n.map((x) => 4 * Math.tan(Math.PI * x / 2));
  if (e === "lowpass") {
    const x = a[0], E = r.length - o.length;
    o = o.map(($) => ds($, x)), r = r.map(($) => ds($, x)), c = c * x ** E;
  } else if (e === "highpass") {
    const x = a[0], E = r.length - o.length, $ = o.reduce((M, j) => Zs(M, ds(j, -1)), nt(1)), P = r.reduce((M, j) => Zs(M, ds(j, -1)), nt(1));
    o = [...o.map((M) => Bs(nt(x), M)), ...Array.from({ length: E }, () => nt(0))], r = r.map((M) => Bs(nt(x), M)), c = c * Bs($, P).re;
  } else {
    if (a.length < 2) throw new Error("Wn must specify start and stop frequencies for bandpass or bandstop filter");
    const x = a[1] - a[0], E = Math.sqrt(a[0] * a[1]), $ = r.length - o.length, P = o.map((k) => ds(k, x / 2)), M = r.map((k) => ds(k, x / 2)), j = (k) => {
      const O = k.map((R) => Pu(Re(Zs(R, R), nt(E * E))));
      return [...k.map((R, G) => Ri(R, O[G])), ...k.map((R, G) => Re(R, O[G]))];
    };
    o = [...j(P), ...Array.from({ length: $ }, () => nt(0))], r = j(M), c = c * x ** $;
  }
  const h = 4, b = r.length - o.length, d = o.reduce((x, E) => Zs(x, Re(nt(h), E)), nt(1)), m = r.reduce((x, E) => Zs(x, Re(nt(h), E)), nt(1)), w = [...o.map((x) => Bs(Ri(nt(h), x), Re(nt(h), x))), ...Array.from({ length: b }, () => nt(-1))], v = r.map((x) => Bs(Ri(nt(h), x), Re(nt(h), x))), _ = c * Bs(d, m).re;
  return Cu(w, v, _);
}
function Ru(s, t, e) {
  let i = 2 * s / e;
  if (i > 1 || i < 0) throw new Error("w0 should be such that 0 < w0 < 1");
  const n = i / t * Math.PI;
  i = i * Math.PI;
  const r = 1 / (1 + Math.tan(n / 2));
  return [[r, r * -2 * Math.cos(i), r, 1, -2 * r * Math.cos(i), 2 * r - 1]];
}
function Lu(s) {
  const t = s.slice(0, 3), e = s.slice(3, 6), i = e[0], n = i === 1 ? t : t.map((h) => h / i), o = i === 1 ? e : e.map((h) => h / i), r = o[0] + o[1] + o[2];
  if (r === 0) throw new Error("Filter not stable due to sum(a) == 0, i.e., having a pole at z = 1!");
  const c = (n[0] + n[1] + n[2]) / r, a = n.map((h, b) => h - c * o[b]);
  return [a[1] + a[2], a[2]];
}
function la(s) {
  let t = 1;
  return s.map((e) => {
    const i = Lu(e), n = [t * i[0], t * i[1]];
    return t *= (e[0] + e[1] + e[2]) / (e[3] + e[4] + e[5]), n;
  });
}
function bo(s, t, e) {
  const i = Float64Array.from(t);
  return s.forEach((n, o) => {
    const [r, c, a, , h, b] = n;
    let d = e ? e[o][0] : 0, m = e ? e[o][1] : 0;
    for (let w = 0; w < i.length; w++) {
      const v = i[w], _ = r * v + d;
      d = c * v - h * _ + m, m = a * v - b * _, i[w] = _;
    }
  }), i;
}
function Ou(s, t) {
  let i = 2 * s.length + 1;
  const n = s.filter((x) => x[2] === 0).length, o = s.filter((x) => x[5] === 0).length;
  i -= Math.min(n, o);
  const r = i * 3, c = t.length;
  if (c <= r) throw new Error(`The length of the input vector x must be greater than padlen, which is ${r}.`);
  const a = new Float64Array(c + 2 * r), h = t[0], b = t[c - 1];
  for (let x = 0; x < r; x++)
    a[x] = 2 * h - t[r - x], a[r + c + x] = 2 * b - t[c - 2 - x];
  for (let x = 0; x < c; x++) a[r + x] = t[x];
  const d = la(s), m = a[0], w = bo(
    s,
    a,
    d.map(([x, E]) => [x * m, E * m])
  ), v = w[w.length - 1];
  w.reverse();
  const _ = bo(
    s,
    w,
    d.map(([x, E]) => [x * v, E * v])
  );
  return _.reverse(), _.slice(r, _.length - r);
}
function aa(s) {
  const t = Math.floor(s), e = s - t;
  return e < 0.5 ? t : e > 0.5 ? t + 1 : t % 2 === 0 ? t : t + 1;
}
function Fu(s, t) {
  return (s % t + t) % t;
}
function Si(s, t) {
  const e = s * 10 ** t;
  return Number.isFinite(e) && Math.abs(e) < 2 ** 52 && Math.abs(e - Math.trunc(e)) === 0.5 ? (aa(e) / 10 ** t).toFixed(t) : s.toFixed(t);
}
function dn(s, t) {
  let e = s;
  for (const [i, n] of t)
    e = e.split(i).join(n).split(i.toLowerCase()).join(n.toLowerCase());
  return e;
}
function Xs(s, t) {
  const e = Number(s);
  if (s.trim() === "" || Number.isNaN(e)) throw new V(`${t} '${s}' is not a number`);
  return e;
}
function Hu(s, t) {
  if (!/^\s*[+-]?\d+\s*$/.test(s)) throw new V(`${t} '${s}' is not an integer`);
  return Number(s);
}
class Uu {
  constructor(t, e) {
    this.host = t, this.source = e[1], t.setupDataset(this.source);
  }
  source;
  label() {
    const { label: t, units: e } = this.host.getLabel(this.source);
    let i;
    if (e.includes("(mm)"))
      i = [["Position", "Velocity"], ["(mm)", "(mm/s)"]];
    else if (e.includes("(mm/s)"))
      i = [["Velocity", "Acceleration"], ["(mm/s)", "(mm/s^2)"]];
    else
      return { label: `Derivative of ${t}`, units: "Unknown" };
    return { label: dn(t, i), units: dn(e, i) };
  }
  generate() {
    const t = 1 / this.host.segmentTime, e = this.host.getData(this.source), i = new Float64Array(e.length);
    for (let n = 0; n < e.length - 1; n++) i[n + 1] = (e[n + 1] - e[n]) * t;
    return i[0] = i[1] ?? 0, i;
  }
}
class Ku {
  constructor(t, e) {
    this.host = t, this.source = e[1], t.setupDataset(this.source), this.ref = null, this.halfLife = 0.015, e.length >= 3 && (this.ref = e[2], t.setupDataset(this.ref), e.length === 4 && (this.halfLife = Xs(e[3], "Half-life")));
  }
  source;
  ref;
  halfLife;
  label() {
    const { label: t, units: e } = this.host.getLabel(this.source);
    let i;
    if (e.includes("(mm/s)"))
      i = [["Velocity", "Position"], ["(mm/s)", "(mm)"]];
    else if (e.includes("(mm/s^2)"))
      i = [["Acceleration", "Velocity"], ["(mm/s^2)", "(mm/s)"]];
    else
      return { label: "Integral", units: "Unknown" };
    return { label: dn(t, i), units: dn(e, i) };
  }
  generate() {
    const t = this.host.segmentTime, e = this.host.getData(this.source);
    let i = 0;
    for (const h of e) i += h;
    i /= e.length;
    let n = 0, o = null, r = 1, c = 0;
    this.ref !== null && (o = this.host.getData(this.ref), i -= (o[o.length - 1] - o[0]) / (e.length * t), n = o[0], this.halfLife && (r = Math.exp(Math.log(0.5) * t / this.halfLife)), c = 1 - r);
    const a = new Float64Array(e.length);
    for (let h = 0; h < e.length; h++)
      n += (e[h] - i) * t, o !== null && (n = r * n + c * o[h]), a[h] = n;
    return a;
  }
}
class qu {
  constructor(t, e) {
    this.host = t, this.sources = e.slice(1);
    for (const i of this.sources) t.setupDataset(i);
  }
  sources;
  label() {
    const { label: t, units: e } = this.host.getLabel(this.sources[0]), i = ["position", "velocity", "acceleration"], n = i.find((r) => t.includes(r)) ?? "";
    let o = "";
    for (const r of this.sources) {
      let c = this.host.getLabel(r).label;
      for (const a of i) c = c.split(a).join("").trim();
      o && (o += "+"), o += c;
    }
    return o += ` ${n} norm2`, { label: o, units: e };
  }
  generate() {
    const t = this.sources.map((i) => this.host.getData(i)), e = new Float64Array(t[0].length);
    for (let i = 0; i < e.length; i++) {
      let n = 0;
      for (const o of t) n += o[i] * o[i];
      e[i] = Math.sqrt(n);
    }
    return e;
  }
}
class Iu {
  constructor(t, e) {
    this.host = t, this.source = e[1], t.setupDataset(this.source), this.smoothTime = e.length > 2 ? Xs(e[2], "Smooth time") : 0.01;
  }
  source;
  smoothTime;
  label() {
    const { label: t, units: e } = this.host.getLabel(this.source);
    return { label: `Smoothed ${t}`, units: e };
  }
  generate() {
    const t = this.host.getData(this.source), e = t.length, i = 0.5 * this.smoothTime, n = aa(i / this.host.segmentTime);
    let o = 0;
    for (let a = 0; a < 2 * n; a++) o += Math.min(a + 1, n + n - a);
    if (o === 0) throw new V("The smoothing time is shorter than the sampling step");
    const r = 1 / o, c = new Float64Array(e);
    for (let a = 0; a < e; a++) {
      const h = Math.max(0, a - n), b = Math.min(e, a + n);
      let d = 0;
      for (let m = 0; m < b - h; m++) d += t[h + m] * Math.min(m + 1, n + n - m);
      c[a] = d * r;
    }
    return c;
  }
}
class Vu {
  constructor(t, e) {
    this.host = t, this.source = e[1];
    const i = e[2];
    if (i !== "filt" && i !== "filtfilt") throw new V(`Unknown sos type '${i}'`);
    this.type = i;
    const n = e[3];
    t.setupDataset(this.source);
    const o = 1 / t.segmentTime;
    if (n === "highpass" || n === "lowpass" || n === "bandpass") {
      const r = Hu(e[4], "Filter order");
      let c = Xs(e[5], "Cutoff"), a = `${Si(c, 0)}Hz`;
      if (n === "bandpass") {
        if (e.length < 7) throw new V("A bandpass filter needs a low and a high frequency");
        c = [c, Xs(e[6], "Cutoff")], a = `${Si(c[0], 1)}..${Si(c[1], 1)}Hz`;
      }
      this.sos = Nu(r, c, n, o), this.desc = `${n} ${a} order ${r}`;
    } else if (n === "notch") {
      const r = Xs(e[4], "Frequency"), c = Xs(e[5], "Quality");
      this.sos = Ru(r, c, o), this.desc = `notch ${Si(r, 1)}Hz Q: ${Si(c, 1)}`;
    } else
      throw new V(`Unknown filter type '${n}'`);
  }
  source;
  type;
  sos;
  desc;
  label() {
    const { label: t, units: e } = this.host.getLabel(this.source);
    return { label: `SOS ${this.desc} (${t})`, units: e };
  }
  generate() {
    const t = this.host.getData(this.source);
    if (this.type === "filt") {
      const e = t[0], i = la(this.sos).map(([n, o]) => [n * e, o * e]);
      return bo(this.sos, t, i);
    }
    return Ou(this.sos, t);
  }
}
class ju {
  constructor(t, e) {
    this.host = t;
    const i = e[1], o = t.initialStatus.configfile?.settings?.printer?.kinematics;
    if (o !== "cartesian" && o !== "corexy") throw new V(`Unsupported kinematics '${String(o)}'`);
    if (i !== "stepper_x" && i !== "stepper_y" && i !== "stepper_z")
      throw new V(`Unknown stepper '${i}'`);
    o === "corexy" && (i === "stepper_x" || i === "stepper_y") ? (this.source1 = "trapq(toolhead,x)", this.source2 = "trapq(toolhead,y)", this.mode = i === "stepper_x" ? "plus" : "minus", t.setupDataset(this.source1), t.setupDataset(this.source2)) : (this.source1 = `trapq(toolhead,${i.slice(-1)})`, this.source2 = null, this.mode = "pass", t.setupDataset(this.source1));
  }
  source1;
  source2;
  mode;
  label() {
    return { label: "Position", units: `Position
(mm)` };
  }
  generate() {
    const t = this.host.getData(this.source1);
    if (this.mode === "pass") return t;
    const e = this.host.getData(this.source2), i = new Float64Array(t.length), n = this.mode === "plus" ? 1 : -1;
    for (let o = 0; o < i.length; o++) i[o] = t[o] + n * e[o];
    return i;
  }
}
class Bu {
  constructor(t, e) {
    this.host = t, this.isPlus = e[1] === "x", this.source1 = e[2], this.source2 = e[3], t.setupDataset(this.source1), t.setupDataset(this.source2);
  }
  isPlus;
  source1;
  source2;
  label() {
    return { label: `Derived ${this.isPlus ? "x" : "y"} position`, units: `Position
(mm)` };
  }
  generate() {
    const t = this.host.getData(this.source1), e = this.host.getData(this.source2), i = new Float64Array(t.length);
    for (let n = 0; n < i.length; n++) i[n] = 0.5 * (this.isPlus ? t[n] + e[n] : t[n] - e[n]);
    return i;
  }
}
class Wu {
  constructor(t, e) {
    this.host = t, this.source1 = e[1], this.source2 = e[2], t.setupDataset(this.source1), t.setupDataset(this.source2);
  }
  source1;
  source2;
  label() {
    const t = this.host.getLabel(this.source1), e = this.host.getLabel(this.source2);
    if (t.units !== e.units) return { label: "Deviation", units: "Unknown" };
    const i = t.units.split(`
`);
    return { label: `${t.label} deviation`, units: [i[0], "Deviation", ...i.slice(1)].join(`
`) };
  }
  generate() {
    const t = this.host.getData(this.source1), e = this.host.getData(this.source2), i = new Float64Array(t.length);
    for (let n = 0; n < i.length; n++) i[n] = t[n] - e[n];
    return i;
  }
}
const Br = {
  derivative: { parametersMin: 1, parametersMax: 1, create: (s, t) => new Uu(s, t) },
  integral: { parametersMin: 1, parametersMax: 3, create: (s, t) => new Ku(s, t) },
  norm2: { parametersMin: 2, parametersMax: 3, create: (s, t) => new qu(s, t) },
  smooth: { parametersMin: 1, parametersMax: 2, create: (s, t) => new Iu(s, t) },
  sos: { parametersMin: 5, parametersMax: 6, create: (s, t) => new Vu(s, t) },
  kin: { parametersMin: 1, parametersMax: 1, create: (s, t) => new ju(s, t) },
  corexy: { parametersMin: 3, parametersMax: 3, create: (s, t) => new Bu(s, t) },
  deviation: { parametersMin: 2, parametersMax: 2, create: (s, t) => new Wu(s, t) }
};
function Gu(s, t, e) {
  const i = Object.hasOwn(Br, e[0]) ? Br[e[0]] : void 0;
  if (!i) throw new V(`Unknown dataset '${t}'`);
  const n = e.length - 1;
  if (n < i.parametersMin || n > i.parametersMax)
    throw new V(`Invalid parameters to dataset '${t}'`);
  return i.create(s, e);
}
const $n = Number.NaN;
function ca(s, t, e, i, n) {
  return t + (n - i) * (s - t) / (e - i);
}
const Wr = (s) => typeof s == "number" ? s : $n;
function Yu(s) {
  return typeof s == "number" ? s : typeof s == "boolean" ? s ? 1 : 0 : $n;
}
class Zu {
  tracker;
  fieldName;
  fieldParts;
  nextUpdateTime = 0;
  result = $n;
  hasResult = !1;
  constructor(t, e) {
    this.tracker = t.statusTracker(), this.fieldName = e[1], this.fieldParts = this.fieldName.split(".");
  }
  label() {
    return { label: `${this.fieldName} field`, units: "Unknown" };
  }
  pull(t) {
    if (this.hasResult && t < this.nextUpdateTime) return this.result;
    const { status: e, validUntil: i } = this.tracker.pullStatus(t);
    let n = e;
    for (const r of this.fieldParts.slice(0, -1))
      n = n !== null && typeof n == "object" ? n[r] ?? {} : {};
    const o = n !== null && typeof n == "object" ? n[this.fieldParts.at(-1)] : void 0;
    return this.result = o === void 0 ? 0 : Yu(o), this.hasResult = !0, this.nextUpdateTime = i, this.result;
  }
}
const ln = "xyz";
class Ju {
  cursor;
  cur = [[0, 0, 0, 0, [0, 0, 0], [0, 0, 0]]];
  dataPos = 0;
  lbl;
  axis;
  kind;
  constructor(t, e, i) {
    this.cursor = t.cursor(`${i[0]}:${i[1]}`);
    const n = i[1], o = i[2];
    if (this.axis = 0, o === "velocity")
      this.kind = "velocity", this.lbl = { label: `${n} velocity`, units: `Velocity
(mm/s)` };
    else if (o === "accel")
      this.kind = "accel", this.lbl = { label: `${n} acceleration`, units: `Acceleration
(mm/s^2)` };
    else {
      const r = /^([xyz])(_velocity|_accel)?$/.exec(o);
      if (!r) throw new V(`Unknown trapq data selection '${o}'`);
      this.axis = ln.indexOf(r[1]), r[2] === "_velocity" ? (this.kind = "axis_velocity", this.lbl = { label: `${n} ${r[1]} velocity`, units: `Velocity
(mm/s)` }) : r[2] === "_accel" ? (this.kind = "axis_accel", this.lbl = { label: `${n} ${r[1]} acceleration`, units: `Acceleration
(mm/s^2)` }) : (this.kind = "pos", this.lbl = { label: `${n} ${r[1]} position`, units: `Position
(mm)` });
    }
  }
  label() {
    return this.lbl;
  }
  findMove(t) {
    let e = this.dataPos;
    for (; ; ) {
      const i = this.cur[e], [n, o] = i;
      if (t <= n + o) return { move: i, inRange: t >= n };
      if (e += 1, e < this.cur.length) {
        this.dataPos = e;
        continue;
      }
      const r = this.cursor.pull();
      if (r === null) return { move: i, inRange: !1 };
      if (r.data.length === 0) {
        e -= 1;
        continue;
      }
      this.cur = r.data, this.dataPos = e = 0;
    }
  }
  pull(t) {
    const { move: e, inRange: i } = this.findMove(t), [n, o, r, c, a, h] = e;
    switch (this.kind) {
      case "pos": {
        const b = Math.max(0, Math.min(o, t - n)), d = (r + 0.5 * c * b) * b;
        return a[this.axis] + h[this.axis] * d;
      }
      case "axis_velocity":
        return i ? (r + c * (t - n)) * h[this.axis] : 0;
      case "axis_accel":
        return i ? c * h[this.axis] : 0;
      case "velocity":
        return i ? r + c * (t - n) : 0;
      case "accel":
        return i ? c : 0;
    }
  }
}
function ua(s, t) {
  for (; ; ) {
    const e = s.pull();
    if (e === null) return null;
    if (t <= e.last_step_time) return e;
  }
}
function ha(s) {
  const t = s.last_clock - s.first_clock, e = s.last_step_time - s.first_step_time;
  return t ? e / t : 0;
}
class Qu {
  cursor;
  stepperName;
  smoothTime;
  // Parallel arrays of (time, half position, position) per step, motan's step_data.
  times = [0, 0];
  halves = [0, 0];
  positions = [0, 0];
  dataPos = 0;
  constructor(t, e, i) {
    if (this.stepperName = i[1], this.cursor = t.cursor(`stepq:${this.stepperName}`), this.smoothTime = 0.01, i.length === 3) {
      const n = Number(i[2]);
      if (i[2].trim() === "" || Number.isNaN(n)) throw new V(`Invalid stepq smooth time '${i[2]}'`);
      this.smoothTime = n;
    }
  }
  label() {
    return { label: `${this.stepperName} position`, units: `Position
(mm)` };
  }
  pull(t) {
    const e = this.smoothTime;
    for (; ; ) {
      const i = this.dataPos, n = this.times[i + 1];
      if (t >= n) {
        if (i + 2 < this.times.length) {
          this.dataPos = i + 1;
          continue;
        }
        this.pullBlock(t);
        continue;
      }
      const o = this.halves[i + 1], r = this.times[i], c = this.halves[i], a = this.positions[i];
      let h = t - r, b = n - r;
      if (b <= e) {
        const d = o - c;
        return c + h * d / b;
      }
      if (b = 0.5 * e, h < b) {
        const d = a - c;
        return c + h * d / b;
      }
      if (h = n - t, h < b) {
        const d = a - o;
        return o + h * d / b;
      }
      return a;
    }
  }
  pullBlock(t) {
    const e = this.times.length - 1;
    this.times = [this.times[e]], this.halves = [this.halves[e]], this.positions = [this.positions[e]], this.dataPos = 0;
    const i = ua(this.cursor, t);
    if (i === null) {
      const b = this.positions[0];
      this.times.push(t + 0.1), this.halves.push(b), this.positions.push(b);
      return;
    }
    const n = i.first_step_time, o = i.first_clock;
    let r = o - i.data[0][0];
    const c = ha(i), a = i.step_distance;
    let h = i.start_position;
    this.times[0] || (this.times[0] = 0, this.halves[0] = h, this.positions[0] = h);
    for (const b of i.data) {
      let d = b[0];
      const m = b[1], w = b[2];
      let v = a, _ = m;
      _ < 0 && (v = -v, _ = -_);
      for (let x = 0; x < _; x++)
        r += d, d += w, this.times.push(n + (r - o) * c), this.halves.push(h + 0.5 * v), h += v, this.positions.push(h);
    }
  }
}
class Xu {
  cursor;
  driverName;
  stepperName;
  reportMicrosteps;
  phases;
  tracker;
  times = [0, 0];
  positions = [0, 0];
  dataPos = 0;
  nextStatusTime = 0;
  mcuPhaseOffset = 0;
  constructor(t, e, i) {
    this.driverName = i[1], this.stepperName = this.driverName.split(/\s+/).filter(Boolean).slice(1).join(" ");
    const n = t.config;
    if (!(this.driverName in n) || !(this.stepperName in n))
      throw new V(`Unable to find stepper driver '${this.driverName}' config`);
    if (i.length === 3 && i[2] !== "microstep") throw new V(`Unknown step_phase selection '${i[2]}'`);
    this.reportMicrosteps = i.length === 3;
    const o = n[this.stepperName].microsteps;
    if (typeof o != "number") throw new V(`Stepper '${this.stepperName}' has no microsteps in its config`);
    this.phases = this.reportMicrosteps ? o : o * 4, this.cursor = t.cursor(`stepq:${this.stepperName}`), this.tracker = t.statusTracker();
  }
  label() {
    return this.reportMicrosteps ? { label: `${this.stepperName} microstep`, units: "Microstep" } : { label: `${this.stepperName} phase`, units: "Phase" };
  }
  pullPhaseOffset(t) {
    const { status: e, validUntil: i } = this.tracker.pullStatus(t);
    this.nextStatusTime = i;
    const n = e[this.driverName]?.mcu_phase_offset;
    this.mcuPhaseOffset = typeof n == "number" ? n : 0;
  }
  pull(t) {
    for (t >= this.nextStatusTime && this.pullPhaseOffset(t); ; ) {
      const e = this.dataPos, i = this.times[e + 1];
      if (t >= i) {
        if (e + 2 < this.times.length) {
          this.dataPos = e + 1;
          continue;
        }
        this.pullBlock(t);
        continue;
      }
      return Fu(this.positions[e] + this.mcuPhaseOffset, this.phases);
    }
  }
  pullBlock(t) {
    const e = this.times.length - 1;
    this.times = [this.times[e]], this.positions = [this.positions[e]], this.dataPos = 0;
    const i = ua(this.cursor, t);
    if (i === null) {
      const h = this.positions[0];
      this.times.push(t + 0.1), this.positions.push(h);
      return;
    }
    const n = i.first_step_time, o = i.first_clock;
    let r = o - i.data[0][0];
    const c = ha(i);
    let a = i.start_mcu_position;
    this.times[0] || (this.times[0] = 0, this.positions[0] = a);
    for (const h of i.data) {
      let b = h[0];
      const d = h[1], m = h[2];
      let w = 1, v = d;
      v < 0 && (w = -1, v = -v);
      for (let _ = 0; _ < v; _++)
        r += b, b += m, this.times.push(n + (r - o) * c), a += w, this.positions.push(a);
    }
  }
}
class th {
  cursor;
  stepperName;
  filter;
  driverName = "";
  data = [];
  dataPos = 0;
  ret = null;
  constructor(t, e, i) {
    this.stepperName = i[1];
    const n = i[2];
    if (n !== "sg_result" && n !== "cs_actual") throw new V(`Unknown stallguard selection '${n}'`);
    this.filter = n, this.cursor = t.cursor(`stallguard:${this.stepperName}`);
    for (const o of Object.keys(t.config))
      if (o.startsWith("tmc") && o.endsWith(this.stepperName)) {
        this.driverName = o;
        break;
      }
  }
  label() {
    return { label: `${this.driverName} ${this.stepperName} ${this.filter}`, units: this.filter === "sg_result" ? "Stallguard" : "CS Actual" };
  }
  pull(t) {
    for (; ; ) {
      if (this.dataPos >= this.data.length) {
        const e = this.cursor.pull();
        if (e === null) return $n;
        this.data = e.data, this.dataPos = 0;
      }
      if (this.ret === null && this.dataPos < this.data.length && (this.ret = this.data[this.dataPos++]), this.ret !== null) {
        if (t <= this.ret[0]) return this.filter === "sg_result" ? this.ret[1] : this.ret[2];
        this.ret = null;
      }
    }
  }
}
class Gr {
  cursor;
  accelName;
  axis;
  nextTime = 0;
  lastTime = 0;
  next = [0, 0, 0];
  last = [0, 0, 0];
  cur = [];
  dataPos = 0;
  constructor(t, e, i) {
    this.accelName = i[1], this.cursor = t.cursor(`${i[0]}:${this.accelName}`);
    const n = i[2];
    if (n.length !== 1 || !ln.includes(n)) throw new V(`Unknown accelerometer data selection '${e}'`);
    this.axis = ln.indexOf(n);
  }
  label() {
    return { label: `${this.accelName} ${ln[this.axis]} acceleration`, units: `Acceleration
(mm/s^2)` };
  }
  pull(t) {
    const e = this.axis;
    for (; ; ) {
      if (t <= this.nextTime) {
        const n = this.next[e] - this.last[e], o = this.nextTime - this.lastTime, r = t - this.lastTime;
        return this.last[e] + r * n / o;
      }
      if (this.dataPos >= this.cur.length) {
        const n = this.cursor.pull();
        if (n === null) return 0;
        this.cur = n.data, this.dataPos = 0;
        continue;
      }
      this.last = this.next, this.lastTime = this.nextTime;
      const i = this.cur[this.dataPos++];
      this.nextTime = i[0], this.next = [i[1], i[2], i[3]];
    }
  }
}
function eh(s) {
  return typeof s == "string" ? s.split(",").map((t) => {
    const [e, i] = t.split(":").map((n) => Number(n.trim()));
    return [e, i];
  }) : Array.isArray(s) ? s.map((t) => [Number(t[0]), Number(t[1])]) : [];
}
class sh {
  cursor;
  angleName;
  nextTime = 0;
  lastTime = 0;
  next = 0;
  last = 0;
  cur = [];
  dataPos = 0;
  positionOffset = 0;
  angleDist = 1;
  constructor(t, e, i) {
    this.angleName = i[1], this.cursor = t.cursor(`angle:${this.angleName}`);
    const n = t.config, o = n[`angle ${this.angleName}`]?.stepper;
    if (typeof o == "string") {
      const r = n[o] ?? {};
      let c = typeof r.rotation_distance == "number" ? r.rotation_distance : 1;
      for (const [a, h] of eh(r.gear_ratio)) c *= h / a;
      this.angleDist = c / 65536;
    }
  }
  label() {
    return { label: `${this.angleName} position`, units: `Position
(mm)` };
  }
  pull(t) {
    for (; ; ) {
      if (t <= this.nextTime) {
        const i = this.next - this.last, n = this.nextTime - this.lastTime, r = (t - this.lastTime) * i / n;
        return (this.last + r) * this.angleDist + this.positionOffset;
      }
      if (this.dataPos >= this.cur.length) {
        const i = this.cursor.pull();
        if (i === null) return this.next * this.angleDist + this.positionOffset;
        this.cur = i.data, typeof i.position_offset == "number" && (this.positionOffset = i.position_offset), this.dataPos = 0;
        continue;
      }
      this.last = this.next, this.lastTime = this.nextTime;
      const e = this.cur[this.dataPos++];
      this.nextTime = e[0], this.next = e[1];
    }
  }
}
class ih {
  cursor;
  sensorName;
  reportFrequency;
  reportZ;
  nextSamp = [0, 0, 0];
  prevSamp = [0, 0, 0];
  cur = [];
  dataPos = 0;
  constructor(t, e, i) {
    if (this.sensorName = i[1], this.cursor = t.cursor(`ldc1612:${this.sensorName}`), i.length === 3 && i[2] !== "period" && i[2] !== "z")
      throw new V(`Unknown ldc1612 selection '${i[2]}'`);
    this.reportFrequency = i.length === 2, this.reportZ = i.length === 3 && i[2] === "z";
  }
  label() {
    return this.reportFrequency ? { label: `${this.sensorName} frequency`, units: `Frequency
(Hz)` } : this.reportZ ? { label: `${this.sensorName} height`, units: `Position
(mm)` } : { label: `${this.sensorName} period`, units: `Period
(s)` };
  }
  pull(t) {
    for (; ; ) {
      const [e, i, n] = this.nextSamp;
      if (t <= e) {
        const [o, r, c] = this.prevSamp;
        let a, h;
        return this.reportFrequency ? (a = i, h = r) : this.reportZ ? (a = n, h = c) : (a = 1 / i, h = 1 / r), ca(a, h, e, o, t);
      }
      if (this.dataPos >= this.cur.length) {
        const o = this.cursor.pull();
        if (o === null) return 0;
        this.cur = o.data, this.dataPos = 0;
        continue;
      }
      this.prevSamp = this.nextSamp, this.nextSamp = this.cur[this.dataPos++];
    }
  }
}
class nh {
  cursor;
  sensorName;
  reportCounts;
  nextSamp = [0, 0, 0, 0];
  prevSamp = [0, 0, 0, 0];
  cur = [];
  dataPos = 0;
  constructor(t, e, i) {
    if (this.sensorName = i[1], this.cursor = t.cursor(`loadcell:${this.sensorName}`), i.length === 3 && i[2] !== "counts") throw new V(`Unknown loadcell selection '${i[2]}'`);
    this.reportCounts = i.length === 3;
  }
  label() {
    return this.reportCounts ? { label: `${this.sensorName} counts`, units: "ADC Counts" } : { label: `${this.sensorName} force`, units: `Force
(g)` };
  }
  pull(t) {
    for (; ; ) {
      const e = this.nextSamp[0];
      if (t <= e) {
        const i = this.prevSamp[0], n = this.reportCounts ? this.nextSamp[2] : Wr(this.nextSamp[1]), o = this.reportCounts ? this.prevSamp[2] : Wr(this.prevSamp[1]);
        return ca(n, o, e, i, t);
      }
      if (this.dataPos >= this.cur.length) {
        const i = this.cursor.pull();
        if (i === null) return 0;
        this.cur = i.data, this.dataPos = 0;
        continue;
      }
      this.prevSamp = this.nextSamp, this.nextSamp = this.cur[this.dataPos++];
    }
  }
}
const pa = {
  status: { subscriptionIdParts: 0, parametersMin: 1, parametersMax: 1, create: (s, t, e) => new Zu(s, e) },
  trapq: { subscriptionIdParts: 2, parametersMin: 2, parametersMax: 2, create: (s, t, e) => new Ju(s, t, e) },
  stepq: { subscriptionIdParts: 2, parametersMin: 1, parametersMax: 2, create: (s, t, e) => new Qu(s, t, e) },
  stallguard: { subscriptionIdParts: 2, parametersMin: 2, parametersMax: 2, create: (s, t, e) => new th(s, t, e) },
  step_phase: { subscriptionIdParts: 0, parametersMin: 1, parametersMax: 2, create: (s, t, e) => new Xu(s, t, e) },
  accelerometer: { subscriptionIdParts: 2, parametersMin: 2, parametersMax: 2, create: (s, t, e) => new Gr(s, t, e) },
  // Old capture name of the accelerometer handler, kept by motan for old logs.
  adxl345: { subscriptionIdParts: 2, parametersMin: 2, parametersMax: 2, create: (s, t, e) => new Gr(s, t, e) },
  angle: { subscriptionIdParts: 2, parametersMin: 1, parametersMax: 1, create: (s, t, e) => new sh(s, t, e) },
  ldc1612: { subscriptionIdParts: 2, parametersMin: 1, parametersMax: 2, create: (s, t, e) => new ih(s, t, e) },
  loadcell: { subscriptionIdParts: 2, parametersMin: 1, parametersMax: 2, create: (s, t, e) => new nh(s, t, e) }
};
function oh(s) {
  return Object.hasOwn(pa, s);
}
function rh(s, t) {
  const e = ea(t), i = pa[e[0]];
  if (!i) throw new V(`Unknown dataset '${e[0]}'`);
  const n = e.length - 1;
  if (n < i.parametersMin || n > i.parametersMax)
    throw new V(`Invalid number of parameters for '${t}'`);
  if (i.subscriptionIdParts) {
    const o = e.slice(0, i.subscriptionIdParts).join(":");
    if (!s.hasSubscription(o))
      throw new V(`Dataset '${o}' not in capture`);
  }
  return i.create(s, t, e);
}
class lh {
  constructor(t) {
    this.messages = t;
  }
  pos = 0;
  /** The next message, or null at the end of the capture. */
  pull() {
    return this.pos < this.messages.length ? this.messages[this.pos++] : null;
  }
}
class ah {
  constructor(t, e) {
    this.cursor = e, this.status = {};
    for (const [i, n] of Object.entries(t)) this.status[i] = { ...n };
  }
  status;
  nextStatusTime = 0;
  nextUpdate = {};
  /** Status at `reqTime` and the print time until which it stays valid. */
  pullStatus(t) {
    for (; ; ) {
      if (t < this.nextStatusTime) return { status: this.status, validUntil: this.nextStatusTime };
      for (const [n, o] of Object.entries(this.nextUpdate))
        this.status[n] = Object.assign(this.status[n] ?? {}, o);
      const e = this.cursor.pull();
      if (e === null)
        return this.nextStatusTime = t + 0.1, this.nextUpdate = {}, { status: this.status, validUntil: this.nextStatusTime };
      this.nextUpdate = e.status;
      const i = e.status.toolhead?.estimated_print_time;
      this.nextStatusTime = typeof i == "number" ? i : 0;
    }
  }
}
class ch {
  constructor(t) {
    this.capture = t, this.initialStartTime = ou(t);
  }
  /** `toolhead.estimated_print_time` at the start: the zero of every time axis. */
  initialStartTime;
  tracker = null;
  get initialStatus() {
    return this.capture.initialStatus;
  }
  /** The `configfile.settings` section of the initial status ({} when absent). */
  get config() {
    return this.capture.initialStatus.configfile?.settings ?? {};
  }
  hasSubscription(t) {
    return this.capture.subscriptions.has(t);
  }
  /** A fresh cursor over a subscription's messages (empty when the stream has none). */
  cursor(t) {
    return new lh(this.capture.streams.get(t) ?? []);
  }
  /** The shared status tracker; created on first use like motan's `get_status_tracker`. */
  statusTracker() {
    return this.tracker === null && (this.tracker = new ah(this.capture.initialStatus, this.cursor("status"))), this.tracker;
  }
}
const uh = 1e-4;
function Yr() {
  const s = globalThis.scheduler;
  return s?.yield ? s.yield() : new Promise((t) => setTimeout(t, 0));
}
function Zr() {
  const s = new Error("Generation aborted");
  return s.name = "AbortError", s;
}
class da {
  constructor(t, e) {
    this.segmentTime = e, this.ctx = new ch(t);
  }
  ctx;
  raw = /* @__PURE__ */ new Map();
  gen = /* @__PURE__ */ new Map();
  data = /* @__PURE__ */ new Map();
  get initialStatus() {
    return this.ctx.initialStatus;
  }
  rawDecoders() {
    return this.raw;
  }
  generatedAnalyzers() {
    return this.gen;
  }
  setupDataset(t) {
    const e = t.trim();
    if (this.raw.has(e) || this.gen.has(e)) return;
    const i = ea(e);
    oh(i[0]) ? this.raw.set(e, rh(this.ctx, e)) : this.gen.set(e, Gu(this, e, i));
  }
  getLabel(t) {
    const e = t.trim(), i = this.raw.get(e) ?? this.gen.get(e);
    if (!i) throw new V(`Unknown dataset '${e}'`);
    return i.label();
  }
  getData(t) {
    const e = this.data.get(t.trim());
    if (!e) throw new V(`Dataset '${t}' has not been generated`);
    return e;
  }
  setData(t, e) {
    this.data.set(t, e);
  }
}
async function hh(s, t, e) {
  const { segmentTime: i, skip: n, duration: o, signal: r } = e;
  if (!(i > 0)) throw new V("The time step must be positive");
  if (!(o > 0)) throw new V("The duration must be positive");
  const c = Math.max(1, e.chunk ?? 4e3), a = new da(s, i);
  for (const $ of t) a.setupDataset($);
  const h = a.ctx.initialStartTime, b = h + n, d = b + o, m = [], w = [];
  for (let $ = b; $ < d; )
    $ += i, m.push($), w.push($ - h);
  const v = m.length, _ = [...a.rawDecoders().entries()].map(([$, P]) => ({ name: $, dec: P, out: new Float64Array(v) }));
  for (let $ = 0; $ < v; $++) {
    const P = m[$];
    for (const M of _) M.out[$] = M.dec.pull(P);
    if (($ + 1) % c === 0) {
      if (r?.aborted) throw Zr();
      e.onProgress?.(($ + 1) / v), await Yr();
    }
  }
  for (const $ of _) a.setData($.name, $.out);
  e.onProgress?.(1);
  for (const [$, P] of a.generatedAnalyzers()) {
    if (r?.aborted) throw Zr();
    a.setData($, P.generate()), await Yr();
  }
  const x = /* @__PURE__ */ new Map(), E = /* @__PURE__ */ new Map();
  for (const $ of t)
    x.set($, a.getData($)), E.set($, a.getLabel($));
  return { times: Float64Array.from(w), series: x, labels: E };
}
function eo(s, t, e = uh) {
  const i = new da(s, e), n = /* @__PURE__ */ new Map();
  for (const o of t)
    try {
      i.setupDataset(o), n.set(o, i.getLabel(o));
    } catch (r) {
      n.set(o, r instanceof V ? r : new V(r instanceof Error ? r.message : String(r)));
    }
  return n;
}
function ph(s) {
  const t = s.units.split(`
`).at(-1);
  return t === "Unknown" ? s.label : `${s.label} ${t}`;
}
function dh(s) {
  return /[",\r\n]/.test(s) ? `"${s.replaceAll('"', '""')}"` : s;
}
function fh(s, t) {
  const e = t.filter((o) => s.series.has(o)), i = [["Time (s)", ...e.map((o) => ph(s.labels.get(o)))].map(dh).join(",")], n = e.map((o) => s.series.get(o));
  for (let o = 0; o < s.times.length; o++) {
    let r = String(s.times[o]);
    for (const c of n) {
      const a = c[o];
      r += Number.isNaN(a) ? "," : `,${a}`;
    }
    i.push(r);
  }
  return i.join(`
`) + `
`;
}
async function mh(s, t) {
  const e = [], i = s.getReader();
  try {
    for (; ; ) {
      const { done: c, value: a } = await i.read();
      if (c) break;
      e.push(a);
    }
  } catch (c) {
    if (!t || e.length === 0) throw c;
  }
  const n = e.reduce((c, a) => c + a.length, 0), o = new Uint8Array(n);
  let r = 0;
  for (const c of e)
    o.set(c, r), r += c.length;
  return o;
}
async function fa(s, t, e) {
  const i = t.writable.getWriter(), n = i.write(s).then(() => i.close());
  n.catch(() => {
  });
  const o = await mh(t.readable, e);
  return await n.catch((r) => {
    if (!e) throw r;
  }), o;
}
function so(s) {
  return fa(s, new CompressionStream("gzip"), !1);
}
function io(s, t = !1) {
  return fa(s, new DecompressionStream("gzip"), t);
}
const Le = 512, ma = new TextEncoder(), gh = new TextDecoder();
function Mi(s, t, e, i) {
  s.set(ma.encode(e).subarray(0, i), t);
}
function _i(s, t, e, i) {
  Mi(s, t, e.toString(8).padStart(i - 1, "0"), i - 1);
}
function bh(s, t = Math.floor(Date.now() / 1e3)) {
  const e = [];
  for (const o of s) {
    if (ma.encode(o.name).length > 100) throw new Error(`tar: name too long: ${o.name}`);
    const r = new Uint8Array(Le);
    Mi(r, 0, o.name, 100), _i(r, 100, 420, 8), _i(r, 108, 0, 8), _i(r, 116, 0, 8), _i(r, 124, o.data.length, 12), _i(r, 136, t, 12), r.fill(32, 148, 156), r[156] = 48, Mi(r, 257, "ustar", 6), Mi(r, 263, "00", 2);
    let c = 0;
    for (const a of r) c += a;
    Mi(r, 148, c.toString(8).padStart(6, "0"), 6), r[154] = 0, r[155] = 32, e.push(r, o.data, new Uint8Array((Le - o.data.length % Le) % Le));
  }
  e.push(new Uint8Array(Le * 2));
  const i = new Uint8Array(e.reduce((o, r) => o + r.length, 0));
  let n = 0;
  for (const o of e)
    i.set(o, n), n += o.length;
  return i;
}
function yh(s) {
  const t = [];
  let e = 0;
  for (; e + Le <= s.length; ) {
    const i = s.subarray(e, e + Le);
    if (i.every((h) => h === 0)) break;
    const n = (h, b) => gh.decode(i.subarray(h, h + b)).replace(/\0.*$/s, ""), o = parseInt(n(124, 12).trim() || "0", 8), r = String.fromCharCode(i[156] || 48), c = n(345, 155), a = c ? `${c}/${n(0, 100)}` : n(0, 100);
    if (e += Le, !Number.isFinite(o) || e + o > s.length) throw new Error("tar: the archive is truncated");
    (r === "0" || r === "\0") && t.push({ name: a, data: s.slice(e, e + o) }), e += Math.ceil(o / Le) * Le;
  }
  return t;
}
const fn = "", Jr = new TextEncoder(), Qr = new TextDecoder();
function wh(s) {
  const t = s.initialStatus.toolhead?.estimated_print_time, e = [], i = (c) => {
    e.push(JSON.stringify(c), fn);
  };
  i({ id: "info", result: { state: "ready" } }), i({ id: "list", result: { objects: Object.keys(s.initialStatus) } }), i({ id: "status", result: { eventtime: t, status: s.initialStatus } });
  const n = {};
  for (const c of s.subscriptions)
    n[c] = { header: [] }, i({ id: c, result: { header: [] } });
  const o = [];
  for (const [c, a] of s.streams)
    a.forEach((h, b) => o.push({ at: (b + 0.5) / a.length, q: c, params: h }));
  o.sort((c, a) => c.at - a.at);
  for (const c of o) i({ q: c.q, params: c.params });
  const r = JSON.stringify({ status: s.initialStatus, subscriptions: n, file_position: 0 }) + fn;
  return { json: Jr.encode(e.join("")), index: Jr.encode(r) };
}
function vh(s) {
  const t = Qr.decode(s.index).split(fn).find((n) => n.length > 0);
  if (!t) throw new V("The index file is empty");
  let e;
  try {
    e = JSON.parse(t);
  } catch {
    throw new V("The index file cannot be read");
  }
  if (!e.status?.toolhead || typeof e.status.toolhead.estimated_print_time != "number")
    throw new V("The log has no toolhead.estimated_print_time in its initial status");
  const i = /* @__PURE__ */ new Map();
  for (const n of Qr.decode(s.json).split(fn)) {
    if (n.length === 0) continue;
    let o;
    try {
      o = JSON.parse(n);
    } catch {
      continue;
    }
    if (typeof o.q != "string") continue;
    let r = i.get(o.q);
    r || i.set(o.q, r = []), r.push(o.params);
  }
  return {
    initialStatus: e.status,
    subscriptions: new Set(Object.keys(e.subscriptions ?? {})),
    streams: i
  };
}
async function $h(s, t = "dump") {
  const { json: e, index: i } = wh(s), [n, o] = await Promise.all([so(e), so(i)]);
  return so(
    bh([
      { name: `${t}.json.gz`, data: n },
      { name: `${t}.index.gz`, data: o }
    ])
  );
}
const xh = (s) => /\.(tar\.gz|tgz)$/i.test(s);
async function Sh(s) {
  let t, e;
  const i = (n, o) => {
    /\.index\.gz$/i.test(n) ? e ??= o : /\.json\.gz$/i.test(n) && (t ??= o);
  };
  for (const n of s)
    if (xh(n.name)) {
      let o;
      try {
        o = await io(n.data);
      } catch {
        throw new V(`${n.name} is not a valid archive`);
      }
      for (const r of yh(o)) i(r.name.split("/").pop(), r.data);
    } else
      i(n.name, n.data);
  if (!t || !e) throw new V("Open a .tar.gz, or both the .json.gz and the .index.gz file of the log");
  try {
    const [n, o] = await Promise.all([io(t, !0), io(e, !0)]);
    return vh({ json: n, index: o });
  } catch (n) {
    throw n instanceof V ? n : new V("The log files cannot be decompressed");
  }
}
function _h(s) {
  const t = s.initialStatus.toolhead?.estimated_print_time;
  if (typeof t != "number") return 0;
  let e = t;
  for (const i of s.streams.get("status") ?? []) {
    const n = i.status?.toolhead?.estimated_print_time;
    typeof n == "number" && n > e && (e = n);
  }
  return e - t;
}
const an = [1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 0.01], Xr = 4e5;
function kh(s) {
  for (const t of an) if (s / t <= 15e4) return t;
  return an[an.length - 1];
}
class mn {
  /** `getHandle` returns the Moonraker handle of the active printer. */
  constructor(t) {
    this.getHandle = t;
  }
  listeners = /* @__PURE__ */ new Set();
  session = null;
  abort = null;
  printerId = "";
  state = mn.initial();
  static initial() {
    return {
      discover: "idle",
      discoverError: "",
      sources: [],
      selected: /* @__PURE__ */ new Set(),
      maxSeconds: 60,
      snapshot: null,
      capture: null,
      captureSeconds: 0,
      info: null,
      window: { skip: 0, duration: 5, segmentTime: 1e-4 },
      graphs: { rows: [] },
      preset: "",
      computed: null,
      progress: null,
      computeError: "",
      outdated: !1,
      openError: ""
    };
  }
  subscribe(t) {
    return this.listeners.add(t), () => this.listeners.delete(t);
  }
  emit() {
    for (const t of [...this.listeners]) t();
  }
  /** Forgets everything and releases the bridge (printer switched, or the user asked). */
  reset() {
    this.session?.stop(), this.session = null, this.abort?.abort(), this.abort = null, this.state = mn.initial(), this.emit();
  }
  /** Called by the tab on mount: a different printer means the old capture is not this machine's. */
  bindPrinter(t) {
    this.printerId && this.printerId !== t && this.reset(), this.printerId = t;
  }
  // ---- sources ----
  async refreshSources() {
    this.state.discover = "loading", this.state.discoverError = "", this.emit();
    try {
      const t = await Eu(this.getHandle()), e = new Set(t.map((n) => n.id)), i = new Set([...this.state.selected].filter((n) => e.has(n)));
      if (i.size === 0)
        for (const n of t) n.byDefault && i.add(n.id);
      this.state.sources = t, this.state.selected = i, this.state.discover = "ready";
    } catch (t) {
      this.state.discover = "error", this.state.discoverError = t instanceof Error ? t.message : String(t);
    }
    this.emit();
  }
  setSelected(t, e) {
    for (const i of t)
      e ? this.state.selected.add(i) : this.state.selected.delete(i);
    this.emit();
  }
  setMaxSeconds(t) {
    Number.isFinite(t) && t > 0 && (this.state.maxSeconds = t), this.emit();
  }
  // ---- recording ----
  get recording() {
    const t = this.state.snapshot?.state;
    return t === "starting" || t === "recording";
  }
  async startRecording() {
    if (this.recording) return;
    const t = this.state.sources.filter((i) => this.state.selected.has(i.id)), e = new Au(this.getHandle(), t, {
      limits: { maxSeconds: this.state.maxSeconds },
      onChange: (i) => {
        if (this.session !== e) return;
        this.state.snapshot = i;
        const n = (i.state === "stopped" || i.state === "failed") && !this.state.capture && this.adopt(e, i);
        this.emit(), n && this.state.graphs.rows.length > 0 && this.compute();
      }
    });
    this.session = e, this.state.capture = null, this.state.computed = null, this.state.info = null, this.state.snapshot = e.snapshot(), this.emit();
    try {
      await e.start();
    } catch {
    }
  }
  stopRecording() {
    this.session?.stop();
  }
  /** Takes the finished capture and prepares the analysis settings for it. */
  adopt(t, e) {
    const i = t.getCapture();
    return i ? (this.useCapture(i, e.elapsed), !0) : !1;
  }
  /** Makes `capture` the one being analysed and sets up the window and the first layout for it. */
  useCapture(t, e) {
    this.state.capture = t, this.state.captureSeconds = e, this.state.info = lu(t), this.state.computed = null;
    const i = Math.max(0.1, Math.min(60, Math.ceil(e * 10) / 10));
    this.state.window = { skip: 0, duration: i, segmentTime: kh(i) }, this.state.graphs = { rows: [] }, this.state.preset = "";
    const n = go(this.state.info)[0];
    n && (this.state.graphs = n.build(this.state.info), this.state.preset = n.id), this.state.outdated = this.state.graphs.rows.length > 0;
  }
  /**
   * Opens a capture saved earlier: a motan log pair or the `.tar.gz` of it (also logs made
   * by Klipper's own data_logger.py on the printer).
   */
  async openFiles(t) {
    if (!this.recording) {
      this.state.openError = "", this.emit();
      try {
        const e = await Sh(t);
        this.abort?.abort(), this.session = null;
        const i = _h(e), n = [...e.subscriptions].map((o) => ({
          id: o,
          status: "live",
          messages: e.streams.get(o)?.length ?? 0
        }));
        this.state.snapshot = { state: "stopped", elapsed: i, approxBytes: 0, sources: n }, this.useCapture(e, i);
      } catch (e) {
        this.state.openError = e instanceof Error ? e.message : String(e), this.emit();
        return;
      }
      this.emit(), this.state.graphs.rows.length > 0 && this.compute();
    }
  }
  /** The capture as a `.tar.gz` of a motan log pair; null without a capture. */
  async exportMotan(t = "dump") {
    if (!this.state.capture) return null;
    const e = await $h(this.state.capture, t);
    return new Blob([e], { type: "application/gzip" });
  }
  /** The computed graphs' data as CSV text; null before anything is built. */
  exportCsv() {
    const t = this.state.computed;
    if (!t) return null;
    const e = [...new Set(this.state.graphs.rows.flatMap((i) => i.series.map((n) => n.name)))];
    return fh(t.data, e);
  }
  /** Drops the capture (not the sources or the selection). */
  discardCapture() {
    this.abort?.abort(), this.session = null, this.state.snapshot = null, this.state.capture = null, this.state.info = null, this.state.computed = null, this.state.progress = null, this.state.graphs = { rows: [] }, this.state.preset = "", this.emit();
  }
  // ---- window and graphs ----
  setWindow(t) {
    this.state.window = { ...this.state.window, ...t }, this.state.outdated = !0, this.emit();
  }
  /** The graphs were edited by hand: no longer a ready-made layout. */
  changedGraphs() {
    this.state.preset = "", this.state.outdated = !0, this.emit();
  }
  applyPreset(t) {
    const e = this.state.info;
    if (!e) return;
    const i = go(e).find((n) => n.id === t);
    i && (this.state.graphs = i.build(e), this.state.preset = i.id, this.state.outdated = !0, this.emit(), this.compute());
  }
  addRow(t = []) {
    const e = qt(t);
    return this.state.graphs.rows.push(e), this.changedGraphs(), e;
  }
  removeRow(t) {
    this.state.graphs.rows = this.state.graphs.rows.filter((e) => e.id !== t), this.changedGraphs();
  }
  /** Adds the dataset built in the dialog to a row (a new row when `rowId` is null). */
  addSeries(t, e) {
    const i = this.state.info;
    if (!i) throw new V("No capture");
    const n = No(e, i), r = eo(this.state.capture, [n], this.state.window.segmentTime).get(n);
    if (r instanceof V) throw r;
    const c = t ? this.state.graphs.rows.find((a) => a.id === t) : void 0;
    return c ? c.series.push(ra(n)) : this.state.graphs.rows.push(qt([n])), this.changedGraphs(), n;
  }
  updateSeries(t, e, i) {
    const n = this.state.graphs.rows.find((o) => o.id === t)?.series[e];
    n && (Object.assign(n, i), this.emit());
  }
  removeSeries(t, e) {
    const i = this.state.graphs.rows.find((n) => n.id === t);
    i && (i.series.splice(e, 1), this.state.graphs.rows = this.state.graphs.rows.filter((n) => n.series.length > 0), this.changedGraphs());
  }
  /** Labels (or the reason a dataset cannot be built) for the series editor. */
  describe(t) {
    return this.state.capture ? eo(this.state.capture, t, this.state.window.segmentTime) : /* @__PURE__ */ new Map();
  }
  // ---- computing ----
  get computing() {
    return this.state.progress !== null;
  }
  cancelCompute() {
    this.abort?.abort();
  }
  async compute() {
    const t = this.state.capture;
    if (!t || this.computing) return;
    const e = { ...this.state.window }, i = [...new Set(this.state.graphs.rows.flatMap((c) => c.series.map((a) => a.name)))], n = eo(t, i, e.segmentTime), o = /* @__PURE__ */ new Map(), r = [];
    for (const [c, a] of n)
      a instanceof V ? o.set(c, a.message) : r.push(c);
    if (this.state.computeError = "", r.length === 0) {
      this.state.computed = null, this.state.computeError = o.size > 0 ? [...o.values()][0] : "", this.state.outdated = !1, this.emit();
      return;
    }
    this.abort = new AbortController(), this.state.progress = 0, this.emit();
    try {
      const c = await hh(t, r, {
        ...e,
        signal: this.abort.signal,
        onProgress: (a) => {
          this.state.progress = a, this.emit();
        }
      });
      this.state.computed = { data: c, errors: o, window: e }, this.state.outdated = !1;
    } catch (c) {
      c.name !== "AbortError" && (this.state.computeError = c instanceof Error ? c.message : String(c), this.state.computed = null);
    } finally {
      this.state.progress = null, this.abort = null, this.emit();
    }
  }
}
const Ah = (s) => String(+(s * 1e3).toFixed(4));
class Mh extends xs {
  static styles = [
    ci,
    ri`
      .graph-row {
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        padding: var(--space-sm);
        display: flex;
        flex-direction: column;
        gap: var(--space-xs);
        min-width: 0;
      }
      .series {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: var(--space-sm);
        min-width: 0;
      }
      .series .name {
        flex: 1 1 12rem;
        min-width: 0;
        font-size: var(--font-size-sm);
      }
      .series select {
        inline-size: 7.5rem;
      }
      .series input[type='range'] {
        inline-size: 6rem;
      }
      .swatch {
        inline-size: 14px;
        block-size: 14px;
        border-radius: 3px;
        flex: none;
      }
    `
  ];
  /** The dialog is a sibling in the tab; found by tag when needed. */
  #t() {
    return this.getRootNode().querySelector("tessera-md-dataset-dialog");
  }
  render() {
    const t = this.store, e = t?.state;
    if (!t || !e?.capture || !e.info) return tt;
    const i = go(e.info), n = e.window, o = Math.ceil(n.duration / n.segmentTime), r = o > Xr, c = t.computing;
    return I`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title">${this.t("motiondiag.graphs.title")}</span>
          <span class="muted ltr">${this.t("motiondiag.graphs.captured", { sec: e.captureSeconds.toFixed(1) })}</span>
        </div>
        <div class="panel-body">
          <div class="fields">
            ${this.#e("motiondiag.graphs.skip", String(n.skip), 0, 0.1, (a) => t.setWindow({ skip: Math.max(0, a) }))}
            ${this.#e("motiondiag.graphs.duration", String(n.duration), 1e-3, 0.5, (a) => t.setWindow({ duration: a }))}
            <label class="field">
              <span class="field-label">${this.t("motiondiag.graphs.step")}</span>
              <select class="ltr" @change=${(a) => t.setWindow({ segmentTime: Number(a.target.value) })}>
                ${an.map((a) => I`<option value=${a} ?selected=${a === n.segmentTime}>${Ah(a)} ms</option>`)}
              </select>
            </label>
          </div>
          ${r ? I`<p class="warn">${this.t("motiondiag.graphs.tooMany", { n: o.toLocaleString(), max: Xr.toLocaleString() })}</p>` : tt}

          <div class="row">
            <label class="field grow">
              <span class="field-label">${this.t("motiondiag.graphs.preset")}</span>
              <!-- Choosing a layout applies and draws it at once; editing the rows makes it "custom". -->
              <select
                id="preset"
                ?disabled=${i.length === 0 || c}
                @change=${(a) => {
      const h = a.target.value;
      h && t.applyPreset(h);
    }}
              >
                <option value="" ?selected=${e.preset === ""}>${this.t("motiondiag.graphs.presetCustom")}</option>
                ${i.map(
      (a) => I`<option value=${a.id} title=${this.t(a.descKey)} ?selected=${a.id === e.preset}>${this.t(a.labelKey)}</option>`
    )}
              </select>
            </label>
          </div>

          ${oa(
      e.graphs.rows,
      (a) => a.id,
      (a, h) => I`
              <div class="graph-row">
                <div class="row">
                  <strong class="grow">${this.t("motiondiag.graphs.rowTitle", { n: h + 1 })}</strong>
                  <button class="small" @click=${() => this.#t()?.open(a.id)}>${this.t("motiondiag.graphs.addSeries")}</button>
                  <button class="small danger" @click=${() => t.removeRow(a.id)}>${this.t("motiondiag.graphs.removeRow")}</button>
                </div>
                ${this.#s(a.id)}
              </div>
            `
    )}

          <div class="row">
            <button @click=${() => this.#t()?.open(null)}>${this.t("motiondiag.graphs.addRow")}</button>
            <span class="grow"></span>
            ${c ? I`<button class="danger" @click=${() => t.cancelCompute()}>${this.t("motiondiag.graphs.cancel")}</button>` : I`<button
                  class="primary"
                  ?disabled=${e.graphs.rows.length === 0 || r || !(n.duration > 0)}
                  @click=${() => void t.compute()}
                >
                  ${this.t(e.outdated ? "motiondiag.graphs.build" : "motiondiag.graphs.rebuild")}
                </button>`}
          </div>
          ${e.progress !== null ? I`<div class="bar"><span style="inline-size:${Math.round(e.progress * 100)}%"></span></div>` : tt}
        </div>
      </section>
    `;
  }
  #e(t, e, i, n, o) {
    return I`<label class="field">
      <span class="field-label">${this.t(t)}</span>
      <input
        class="ltr"
        type="number"
        min=${i}
        step=${n}
        .value=${e}
        @change=${(r) => {
      const c = Number(r.target.value);
      Number.isFinite(c) && o(c);
    }}
      />
    </label>`;
  }
  #s(t) {
    const e = this.store, i = e.state.graphs.rows.find((o) => o.id === t), n = e.describe(i.series.map((o) => o.name));
    return I`${i.series.map((o, r) => {
      const c = n.get(o.name), a = o.color || `var(${zi[r % zi.length]})`;
      return I`
        <div class="series">
          <span class="swatch" style="background:${a};opacity:${o.alpha}"></span>
          <span class="name ltr">
            ${c instanceof V ? I`<span class="error">${o.name}: ${c.message}</span>` : I`${c ? c.label : o.name} <span class="muted">${c ? c.units.replace(/\n/g, " ") : ""}</span>`}
          </span>
          <select
            title=${this.t("motiondiag.graphs.color")}
            @change=${(h) => e.updateSeries(t, r, { color: h.target.value })}
          >
            <option value="" ?selected=${o.color === ""}>${this.t("motiondiag.color.auto")}</option>
            ${zi.map(
        (h) => I`<option value="var(${h})" ?selected=${o.color === `var(${h})`}>${this.t(`motiondiag.color.${h.slice(2)}`)}</option>`
      )}
          </select>
          <input
            type="range"
            min="0.2"
            max="1"
            step="0.1"
            title=${this.t("motiondiag.graphs.opacity")}
            .value=${String(o.alpha)}
            @change=${(h) => e.updateSeries(t, r, { alpha: Number(h.target.value) })}
          />
          <button class="small icon" title=${this.t("motiondiag.graphs.removeSeries")} @click=${() => e.removeSeries(t, r)}>✕</button>
        </div>
      `;
    })}`;
  }
}
const Th = !0, zt = "u-", Eh = "uplot", Ph = zt + "hz", Dh = zt + "vt", Ch = zt + "title", zh = zt + "wrap", Nh = zt + "under", Rh = zt + "over", Lh = zt + "axis", bs = zt + "off", Oh = zt + "select", Fh = zt + "cursor-x", Hh = zt + "cursor-y", Uh = zt + "cursor-pt", Kh = zt + "legend", qh = zt + "live", Ih = zt + "inline", Vh = zt + "series", jh = zt + "marker", tl = zt + "label", Bh = zt + "value", Ti = "width", Ei = "height", ki = "top", el = "bottom", Gs = "left", no = "right", Ro = "#000", sl = Ro + "0", oo = "mousemove", il = "mousedown", ro = "mouseup", nl = "mouseenter", ol = "mouseleave", rl = "dblclick", Wh = "resize", Gh = "scroll", ll = "change", gn = "dppxchange", Lo = "--", ui = typeof window < "u", yo = ui ? document : null, ti = ui ? window : null, Yh = ui ? navigator : null;
let ct, Xi;
function wo() {
  let s = devicePixelRatio;
  ct != s && (ct = s, Xi && $o(ll, Xi, wo), Xi = matchMedia(`(min-resolution: ${ct - 1e-3}dppx) and (max-resolution: ${ct + 1e-3}dppx)`), ws(ll, Xi, wo), ti.dispatchEvent(new CustomEvent(gn)));
}
function oe(s, t) {
  if (t != null) {
    let e = s.classList;
    !e.contains(t) && e.add(t);
  }
}
function vo(s, t) {
  let e = s.classList;
  e.contains(t) && e.remove(t);
}
function vt(s, t, e) {
  s.style[t] = e + "px";
}
function _e(s, t, e, i) {
  let n = yo.createElement(s);
  return t != null && oe(n, t), e?.insertBefore(n, i), n;
}
function be(s, t) {
  return _e("div", s, t);
}
const al = /* @__PURE__ */ new WeakMap();
function Ne(s, t, e, i, n) {
  let o = "translate(" + t + "px," + e + "px)", r = al.get(s);
  o != r && (s.style.transform = o, al.set(s, o), t < 0 || e < 0 || t > i || e > n ? oe(s, bs) : vo(s, bs));
}
const cl = /* @__PURE__ */ new WeakMap();
function ul(s, t, e) {
  let i = t + e, n = cl.get(s);
  i != n && (cl.set(s, i), s.style.background = t, s.style.borderColor = e);
}
const hl = /* @__PURE__ */ new WeakMap();
function pl(s, t, e, i) {
  let n = t + "" + e, o = hl.get(s);
  n != o && (hl.set(s, n), s.style.height = e + "px", s.style.width = t + "px", s.style.marginLeft = i ? -t / 2 + "px" : 0, s.style.marginTop = i ? -e / 2 + "px" : 0);
}
const Oo = { passive: !0 }, Zh = { ...Oo, capture: !0 };
function ws(s, t, e, i) {
  t.addEventListener(s, e, i ? Zh : Oo);
}
function $o(s, t, e, i) {
  t.removeEventListener(s, e, Oo);
}
ui && wo();
function ke(s, t, e, i) {
  let n;
  e = e || 0, i = i || t.length - 1;
  let o = i <= 2147483647;
  for (; i - e > 1; )
    n = o ? e + i >> 1 : re((e + i) / 2), t[n] < s ? e = n : i = n;
  return s - t[e] <= t[i] - s ? e : i;
}
function ga(s) {
  return (e, i, n) => {
    let o = -1, r = -1;
    for (let c = i; c <= n; c++)
      if (s(e[c])) {
        o = c;
        break;
      }
    for (let c = n; c >= i; c--)
      if (s(e[c])) {
        r = c;
        break;
      }
    return [o, r];
  };
}
const ba = (s) => s != null, ya = (s) => s != null && s > 0, xn = ga(ba), Jh = ga(ya);
function Qh(s, t, e, i = 0, n = !1) {
  let o = n ? Jh : xn, r = n ? ya : ba;
  [t, e] = o(s, t, e);
  let c = s[t], a = s[t];
  if (t > -1)
    if (i == 1)
      c = s[t], a = s[e];
    else if (i == -1)
      c = s[e], a = s[t];
    else
      for (let h = t; h <= e; h++) {
        let b = s[h];
        r(b) && (b < c ? c = b : b > a && (a = b));
      }
  return [c ?? ft, a ?? -ft];
}
function Sn(s, t, e, i) {
  let n = ml(s), o = ml(t);
  s == t && (n == -1 ? (s *= e, t /= e) : (s /= e, t *= e));
  let r = e == 10 ? Ke : wa, c = n == 1 ? re : ye, a = o == 1 ? ye : re, h = c(r(Ct(s))), b = a(r(Ct(t))), d = si(e, h), m = si(e, b);
  return e == 10 && (h < 0 && (d = mt(d, -h)), b < 0 && (m = mt(m, -b))), i || e == 2 ? (s = d * n, t = m * o) : (s = Sa(s, d), t = _n(t, m)), [s, t];
}
function Fo(s, t, e, i) {
  let n = Sn(s, t, e, i);
  return s == 0 && (n[0] = 0), t == 0 && (n[1] = 0), n;
}
const Ho = 0.1, dl = {
  mode: 3,
  pad: Ho
}, Li = {
  pad: 0,
  soft: null,
  mode: 0
}, Xh = {
  min: Li,
  max: Li
};
function bn(s, t, e, i) {
  return kn(e) ? fl(s, t, e) : (Li.pad = e, Li.soft = i ? 0 : null, Li.mode = i ? 3 : 0, fl(s, t, Xh));
}
function lt(s, t) {
  return s ?? t;
}
function tp(s, t, e) {
  for (t = lt(t, 0), e = lt(e, s.length - 1); t <= e; ) {
    if (s[t] != null)
      return !0;
    t++;
  }
  return !1;
}
function fl(s, t, e) {
  let i = e.min, n = e.max, o = lt(i.pad, 0), r = lt(n.pad, 0), c = lt(i.hard, -ft), a = lt(n.hard, ft), h = lt(i.soft, ft), b = lt(n.soft, -ft), d = lt(i.mode, 0), m = lt(n.mode, 0), w = t - s, v = Ke(w), _ = Zt(Ct(s), Ct(t)), x = Ke(_), E = Ct(x - v);
  (w < 1e-24 || E > 10) && (w = 0, (s == 0 || t == 0) && (w = 1e-24, d == 2 && h != ft && (o = 0), m == 2 && b != -ft && (r = 0)));
  let $ = w || _ || 1e3, P = Ke($), M = si(10, re(P)), j = $ * (w == 0 ? s == 0 ? 0.1 : 1 : o), k = mt(Sa(s - j, M / 10), 24), O = s >= h && (d == 1 || d == 3 && k <= h || d == 2 && k >= h) ? h : ft, R = Zt(c, k < O && s >= O ? O : Ae(O, k)), G = $ * (w == 0 ? t == 0 ? 0.1 : 1 : r), Y = mt(_n(t + G, M / 10), 24), D = t <= b && (m == 1 || m == 3 && Y >= b || m == 2 && Y <= b) ? b : -ft, J = Ae(a, Y > D && t <= D ? D : Zt(D, Y));
  return R == J && R == 0 && (J = 100), [R, J];
}
const ep = new Intl.NumberFormat(ui ? Yh.language : "en-US"), Uo = (s) => ep.format(s), le = Math, cn = le.PI, Ct = le.abs, re = le.floor, Dt = le.round, ye = le.ceil, Ae = le.min, Zt = le.max, si = le.pow, ml = le.sign, Ke = le.log10, wa = le.log2, sp = (s, t = 1) => le.sinh(s) * t, lo = (s, t = 1) => le.asinh(s / t), ft = 1 / 0;
function gl(s) {
  return (Ke((s ^ s >> 31) - (s >> 31)) | 0) + 1;
}
function xo(s, t, e) {
  return Ae(Zt(s, t), e);
}
function va(s) {
  return typeof s == "function";
}
function st(s) {
  return va(s) ? s : () => s;
}
const ip = () => {
}, $a = (s) => s, xa = (s, t) => t, np = (s) => null, bl = (s) => !0, yl = (s, t) => s == t, op = /\.\d*?(?=9{6,}|0{6,})/gm, Ss = (s) => {
  if (ka(s) || Qe.has(s))
    return s;
  const t = `${s}`, e = t.match(op);
  if (e == null)
    return s;
  let i = e[0].length - 1;
  if (t.indexOf("e-") != -1) {
    let [n, o] = t.split("e");
    return +`${Ss(n)}e${o}`;
  }
  return mt(s, i);
};
function ms(s, t) {
  return Ss(mt(Ss(s / t)) * t);
}
function _n(s, t) {
  return Ss(ye(Ss(s / t)) * t);
}
function Sa(s, t) {
  return Ss(re(Ss(s / t)) * t);
}
function mt(s, t = 0) {
  if (ka(s))
    return s;
  let e = 10 ** t, i = s * e * (1 + Number.EPSILON);
  return Dt(i) / e;
}
const Qe = /* @__PURE__ */ new Map();
function _a(s) {
  return (("" + s).split(".")[1] || "").length;
}
function Ki(s, t, e, i) {
  let n = [], o = i.map(_a);
  for (let r = t; r < e; r++) {
    let c = Ct(r), a = mt(si(s, r), c);
    for (let h = 0; h < i.length; h++) {
      let b = s == 10 ? +`${i[h]}e${r}` : i[h] * a, d = (r >= 0 ? 0 : c) + (r >= o[h] ? 0 : o[h]), m = s == 10 ? b : mt(b, d);
      n.push(m), Qe.set(m, d);
    }
  }
  return n;
}
const Oi = {}, Ko = [], ii = [null, null], Ye = Array.isArray, ka = Number.isInteger, rp = (s) => s === void 0;
function wl(s) {
  return typeof s == "string";
}
function kn(s) {
  let t = !1;
  if (s != null) {
    let e = s.constructor;
    t = e == null || e == Object;
  }
  return t;
}
function lp(s) {
  return s != null && typeof s == "object";
}
const ap = Object.getPrototypeOf(Uint8Array), Aa = "__proto__";
function ni(s, t = kn) {
  let e;
  if (Ye(s)) {
    let i = s.find((n) => n != null);
    if (Ye(i) || t(i)) {
      e = Array(s.length);
      for (let n = 0; n < s.length; n++)
        e[n] = ni(s[n], t);
    } else
      e = s.slice();
  } else if (s instanceof ap)
    e = s.slice();
  else if (t(s)) {
    e = {};
    for (let i in s)
      i != Aa && (e[i] = ni(s[i], t));
  } else
    e = s;
  return e;
}
function Tt(s) {
  let t = arguments;
  for (let e = 1; e < t.length; e++) {
    let i = t[e];
    for (let n in i)
      n != Aa && (kn(s[n]) ? Tt(s[n], ni(i[n])) : s[n] = ni(i[n]));
  }
  return s;
}
const cp = 0, up = 1, hp = 2;
function pp(s, t, e) {
  for (let i = 0, n, o = -1; i < t.length; i++) {
    let r = t[i];
    if (r > o) {
      for (n = r - 1; n >= 0 && s[n] == null; )
        s[n--] = null;
      for (n = r + 1; n < e && s[n] == null; )
        s[o = n++] = null;
    }
  }
}
function dp(s, t) {
  if (gp(s)) {
    let r = s[0].slice();
    for (let c = 1; c < s.length; c++)
      r.push(...s[c].slice(1));
    return bp(r[0]) || (r = mp(r)), r;
  }
  let e = /* @__PURE__ */ new Set();
  for (let r = 0; r < s.length; r++) {
    let a = s[r][0], h = a.length;
    for (let b = 0; b < h; b++)
      e.add(a[b]);
  }
  let i = [Array.from(e).sort((r, c) => r - c)], n = i[0].length, o = /* @__PURE__ */ new Map();
  for (let r = 0; r < n; r++)
    o.set(i[0][r], r);
  for (let r = 0; r < s.length; r++) {
    let c = s[r], a = c[0];
    for (let h = 1; h < c.length; h++) {
      let b = c[h], d = Array(n).fill(void 0), m = t ? t[r][h] : up, w = [];
      for (let v = 0; v < b.length; v++) {
        let _ = b[v], x = o.get(a[v]);
        _ === null ? m != cp && (d[x] = _, m == hp && w.push(x)) : d[x] = _;
      }
      pp(d, w, n), i.push(d);
    }
  }
  return i;
}
const fp = typeof queueMicrotask > "u" ? (s) => Promise.resolve().then(s) : queueMicrotask;
function mp(s) {
  let t = s[0], e = t.length, i = Array(e);
  for (let o = 0; o < i.length; o++)
    i[o] = o;
  i.sort((o, r) => t[o] - t[r]);
  let n = [];
  for (let o = 0; o < s.length; o++) {
    let r = s[o], c = Array(e);
    for (let a = 0; a < e; a++)
      c[a] = r[i[a]];
    n.push(c);
  }
  return n;
}
function gp(s) {
  let t = s[0][0], e = t.length;
  for (let i = 1; i < s.length; i++) {
    let n = s[i][0];
    if (n.length != e)
      return !1;
    if (n != t) {
      for (let o = 0; o < e; o++)
        if (n[o] != t[o])
          return !1;
    }
  }
  return !0;
}
function bp(s, t = 100) {
  const e = s.length;
  if (e <= 1)
    return !0;
  let i = 0, n = e - 1;
  for (; i <= n && s[i] == null; )
    i++;
  for (; n >= i && s[n] == null; )
    n--;
  if (n <= i)
    return !0;
  const o = Zt(1, re((n - i + 1) / t));
  for (let r = s[i], c = i + o; c <= n; c += o) {
    const a = s[c];
    if (a != null) {
      if (a <= r)
        return !1;
      r = a;
    }
  }
  return !0;
}
const Ma = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
], Ta = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday"
];
function Ea(s) {
  return s.slice(0, 3);
}
const yp = Ta.map(Ea), wp = Ma.map(Ea), vp = {
  MMMM: Ma,
  MMM: wp,
  WWWW: Ta,
  WWW: yp
};
function Ai(s) {
  return (s < 10 ? "0" : "") + s;
}
function $p(s) {
  return (s < 10 ? "00" : s < 100 ? "0" : "") + s;
}
const xp = {
  // 2019
  YYYY: (s) => s.getFullYear(),
  // 19
  YY: (s) => (s.getFullYear() + "").slice(2),
  // July
  MMMM: (s, t) => t.MMMM[s.getMonth()],
  // Jul
  MMM: (s, t) => t.MMM[s.getMonth()],
  // 07
  MM: (s) => Ai(s.getMonth() + 1),
  // 7
  M: (s) => s.getMonth() + 1,
  // 09
  DD: (s) => Ai(s.getDate()),
  // 9
  D: (s) => s.getDate(),
  // Monday
  WWWW: (s, t) => t.WWWW[s.getDay()],
  // Mon
  WWW: (s, t) => t.WWW[s.getDay()],
  // 03
  HH: (s) => Ai(s.getHours()),
  // 3
  H: (s) => s.getHours(),
  // 9 (12hr, unpadded)
  h: (s) => {
    let t = s.getHours();
    return t == 0 ? 12 : t > 12 ? t - 12 : t;
  },
  // AM
  AA: (s) => s.getHours() >= 12 ? "PM" : "AM",
  // am
  aa: (s) => s.getHours() >= 12 ? "pm" : "am",
  // a
  a: (s) => s.getHours() >= 12 ? "p" : "a",
  // 09
  mm: (s) => Ai(s.getMinutes()),
  // 9
  m: (s) => s.getMinutes(),
  // 09
  ss: (s) => Ai(s.getSeconds()),
  // 9
  s: (s) => s.getSeconds(),
  // 374
  fff: (s) => $p(s.getMilliseconds())
};
function qo(s, t) {
  t = t || vp;
  let e = [], i = /\{([a-z]+)\}|[^{]+/gi, n;
  for (; n = i.exec(s); )
    e.push(n[0][0] == "{" ? xp[n[1]] : n[0]);
  return (o) => {
    let r = "";
    for (let c = 0; c < e.length; c++)
      r += typeof e[c] == "string" ? e[c] : e[c](o, t);
    return r;
  };
}
const Sp = new Intl.DateTimeFormat().resolvedOptions().timeZone;
function _p(s, t) {
  let e;
  return t == "UTC" || t == "Etc/UTC" ? e = new Date(+s + s.getTimezoneOffset() * 6e4) : t == Sp ? e = s : (e = new Date(s.toLocaleString("en-US", { timeZone: t })), e.setMilliseconds(s.getMilliseconds())), e;
}
const Pa = (s) => s % 1 == 0, yn = [1, 2, 2.5, 5], kp = Ki(10, -32, 0, yn), Da = Ki(10, 0, 32, yn), Ap = Da.filter(Pa), gs = kp.concat(Da), Io = `
`, Ca = "{YYYY}", vl = Io + Ca, za = "{M}/{D}", Pi = Io + za, tn = Pi + "/{YY}", Na = "{aa}", Mp = "{h}:{mm}", Js = Mp + Na, $l = Io + Js, xl = ":{ss}", ht = null;
function Ra(s) {
  let t = s * 1e3, e = t * 60, i = e * 60, n = i * 24, o = n * 30, r = n * 365, a = (s == 1 ? Ki(10, 0, 3, yn).filter(Pa) : Ki(10, -3, 0, yn)).concat([
    // minute divisors (# of secs)
    t,
    t * 5,
    t * 10,
    t * 15,
    t * 30,
    // hour divisors (# of mins)
    e,
    e * 5,
    e * 10,
    e * 15,
    e * 30,
    // day divisors (# of hrs)
    i,
    i * 2,
    i * 3,
    i * 4,
    i * 6,
    i * 8,
    i * 12,
    // month divisors TODO: need more?
    n,
    n * 2,
    n * 3,
    n * 4,
    n * 5,
    n * 6,
    n * 7,
    n * 8,
    n * 9,
    n * 10,
    n * 15,
    // year divisors (# months, approx)
    o,
    o * 2,
    o * 3,
    o * 4,
    o * 6,
    // century divisors
    r,
    r * 2,
    r * 5,
    r * 10,
    r * 25,
    r * 50,
    r * 100
  ]);
  const h = [
    //   tick incr    default          year                    month   day                   hour    min       sec   mode
    [r, Ca, ht, ht, ht, ht, ht, ht, 1],
    [n * 28, "{MMM}", vl, ht, ht, ht, ht, ht, 1],
    [n, za, vl, ht, ht, ht, ht, ht, 1],
    [i, "{h}" + Na, tn, ht, Pi, ht, ht, ht, 1],
    [e, Js, tn, ht, Pi, ht, ht, ht, 1],
    [t, xl, tn + " " + Js, ht, Pi + " " + Js, ht, $l, ht, 1],
    [s, xl + ".{fff}", tn + " " + Js, ht, Pi + " " + Js, ht, $l, ht, 1]
  ];
  function b(d) {
    return (m, w, v, _, x, E) => {
      let $ = [], P = x >= r, M = x >= o && x < r, j = d(v), k = mt(j * s, 3), O = ao(j.getFullYear(), P ? 0 : j.getMonth(), M || P ? 1 : j.getDate()), R = mt(O * s, 3);
      if (M || P) {
        let G = M ? x / o : 0, Y = P ? x / r : 0, D = k == R ? k : mt(ao(O.getFullYear() + Y, O.getMonth() + G, 1) * s, 3), J = new Date(Dt(D / s)), F = J.getFullYear(), B = J.getMonth();
        for (let q = 0; D <= _; q++) {
          let it = ao(F + Y * q, B + G * q, 1), K = it - d(mt(it * s, 3));
          D = mt((+it + K) * s, 3), D <= _ && $.push(D);
        }
      } else {
        let G = x >= n ? n : x, Y = re(v) - re(k), D = R + Y + _n(k - R, G);
        $.push(D);
        let J = d(D), F = J.getHours() + J.getMinutes() / e + J.getSeconds() / i, B = x / i, q = m.axes[w]._space, it = E / q;
        for (; D = mt(D + x, s == 1 ? 0 : 3), !(D > _); )
          if (B > 1) {
            let K = re(mt(F + B, 6)) % 24, ot = d(D).getHours() - K;
            ot > 1 && (ot = -1), D -= ot * i, F = (F + B) % 24;
            let pt = $[$.length - 1];
            mt((D - pt) / x, 3) * it >= 0.7 && $.push(D);
          } else
            $.push(D);
      }
      return $;
    };
  }
  return [
    a,
    h,
    b
  ];
}
const [Tp, Ep, Pp] = Ra(1), [Dp, Cp, zp] = Ra(1e-3);
Ki(2, -53, 53, [1]);
function Sl(s, t) {
  return s.map((e) => e.map(
    (i, n) => n == 0 || n == 8 || i == null ? i : t(n == 1 || e[8] == 0 ? i : e[1] + i)
  ));
}
function _l(s, t) {
  return (e, i, n, o, r) => {
    let c = t.find((v) => r >= v[0]) || t[t.length - 1], a, h, b, d, m, w;
    return i.map((v) => {
      let _ = s(v), x = _.getFullYear(), E = _.getMonth(), $ = _.getDate(), P = _.getHours(), M = _.getMinutes(), j = _.getSeconds(), k = x != a && c[2] || E != h && c[3] || $ != b && c[4] || P != d && c[5] || M != m && c[6] || j != w && c[7] || c[1];
      return a = x, h = E, b = $, d = P, m = M, w = j, k(_);
    });
  };
}
function Np(s, t) {
  let e = qo(t);
  return (i, n, o, r, c) => n.map((a) => e(s(a)));
}
function ao(s, t, e) {
  return new Date(s, t, e);
}
function kl(s, t) {
  return t(s);
}
const Rp = "{YYYY}-{MM}-{DD} {h}:{mm}{aa}";
function Al(s, t) {
  return (e, i, n, o) => o == null ? Lo : t(s(i));
}
function Lp(s, t) {
  let e = s.series[t];
  return e.width ? e.stroke(s, t) : e.points.width ? e.points.stroke(s, t) : null;
}
function Op(s, t) {
  return s.series[t].fill(s, t);
}
const Fp = {
  show: !0,
  live: !0,
  isolate: !1,
  mount: ip,
  markers: {
    show: !0,
    width: 2,
    stroke: Lp,
    fill: Op,
    dash: "solid"
  },
  idx: null,
  idxs: null,
  values: []
};
function Hp(s, t) {
  let e = s.cursor.points, i = be(), n = e.size(s, t);
  vt(i, Ti, n), vt(i, Ei, n);
  let o = n / -2;
  vt(i, "marginLeft", o), vt(i, "marginTop", o);
  let r = e.width(s, t, n);
  return r && vt(i, "borderWidth", r), i;
}
function Up(s, t) {
  let e = s.series[t].points;
  return e._fill || e._stroke;
}
function Kp(s, t) {
  let e = s.series[t].points;
  return e._stroke || e._fill;
}
function qp(s, t) {
  return s.series[t].points.size;
}
const co = [0, 0];
function Ip(s, t, e) {
  return co[0] = t, co[1] = e, co;
}
function en(s, t, e, i = !0) {
  return (n) => {
    n.button == 0 && (!i || n.target == t) && e(n);
  };
}
function uo(s, t, e, i = !0) {
  return (n) => {
    (!i || n.target == t) && e(n);
  };
}
const Vp = {
  show: !0,
  x: !0,
  y: !0,
  lock: !1,
  move: Ip,
  points: {
    one: !1,
    show: Hp,
    size: qp,
    width: 0,
    stroke: Kp,
    fill: Up
  },
  bind: {
    mousedown: en,
    mouseup: en,
    click: en,
    // legend clicks, not .u-over clicks
    dblclick: en,
    mousemove: uo,
    mouseleave: uo,
    mouseenter: uo
  },
  drag: {
    setScale: !0,
    x: !0,
    y: !1,
    dist: 0,
    uni: null,
    click: (s, t) => {
      t.stopPropagation(), t.stopImmediatePropagation();
    },
    _x: !1,
    _y: !1
  },
  focus: {
    dist: (s, t, e, i, n) => i - n,
    prox: -1,
    bias: 0
  },
  hover: {
    skip: [void 0],
    prox: null,
    bias: 0
  },
  left: -10,
  top: -10,
  idx: null,
  dataIdx: null,
  idxs: null,
  event: null
}, La = {
  show: !0,
  stroke: "rgba(0,0,0,0.07)",
  width: 2
  //	dash: [],
}, Vo = Tt({}, La, {
  filter: xa
}), Oa = Tt({}, Vo, {
  size: 10
}), Fa = Tt({}, La, {
  show: !1
}), jo = '12px system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"', Ha = "bold " + jo, Ua = 1.5, Ml = {
  show: !0,
  scale: "x",
  stroke: Ro,
  space: 50,
  gap: 5,
  alignTo: 1,
  size: 50,
  labelGap: 0,
  labelSize: 30,
  labelFont: Ha,
  side: 2,
  //	class: "x-vals",
  //	incrs: timeIncrs,
  //	values: timeVals,
  //	filter: retArg1,
  grid: Vo,
  ticks: Oa,
  border: Fa,
  font: jo,
  lineGap: Ua,
  rotate: 0
}, jp = "Value", Bp = "Time", Tl = {
  show: !0,
  scale: "x",
  auto: !1,
  sorted: 1,
  //	label: "Time",
  //	value: v => stamp(new Date(v * 1e3)),
  // internal caches
  min: ft,
  max: -ft,
  idxs: []
};
function Wp(s, t, e, i, n) {
  return t.map((o) => o == null ? "" : Uo(o));
}
function Gp(s, t, e, i, n, o, r) {
  let c = [], a = Qe.get(n) || 0;
  e = r ? e : mt(_n(e, n), a);
  for (let h = e; h <= i; h = mt(h + n, a))
    c.push(Object.is(h, -0) ? 0 : h);
  return c;
}
function So(s, t, e, i, n, o, r) {
  const c = [], a = s.scales[s.axes[t].scale].log, h = a == 10 ? Ke : wa, b = re(h(e));
  n = si(a, b), a == 10 && (n = gs[ke(n, gs)]);
  let d = e, m = n * a;
  a == 10 && (m = gs[ke(m, gs)]);
  do
    c.push(d), d = d + n, a == 10 && !Qe.has(d) && (d = mt(d, Qe.get(n))), d >= m && (n = d, m = n * a, a == 10 && (m = gs[ke(m, gs)]));
  while (d <= i);
  return c;
}
function Yp(s, t, e, i, n, o, r) {
  let a = s.scales[s.axes[t].scale].asinh, h = i > a ? So(s, t, Zt(a, e), i, n) : [a], b = i >= 0 && e <= 0 ? [0] : [];
  return (e < -a ? So(s, t, Zt(a, -i), -e, n) : [a]).reverse().map((m) => -m).concat(b, h);
}
const Ka = /./, Zp = /[12357]/, Jp = /[125]/, El = /1/, _o = (s, t, e, i) => s.map((n, o) => t == 4 && n == 0 || o % i == 0 && e.test(n.toExponential()[n < 0 ? 1 : 0]) ? n : null);
function Qp(s, t, e, i, n) {
  let o = s.axes[e], r = o.scale, c = s.scales[r], a = s.valToPos, h = o._space, b = a(10, r), d = a(9, r) - b >= h ? Ka : a(7, r) - b >= h ? Zp : a(5, r) - b >= h ? Jp : El;
  if (d == El) {
    let m = Ct(a(1, r) - b);
    if (m < h)
      return _o(t.slice().reverse(), c.distr, d, ye(h / m)).reverse();
  }
  return _o(t, c.distr, d, 1);
}
function Xp(s, t, e, i, n) {
  let o = s.axes[e], r = o.scale, c = o._space, a = s.valToPos, h = Ct(a(1, r) - a(2, r));
  return h < c ? _o(t.slice().reverse(), 3, Ka, ye(c / h)).reverse() : t;
}
function td(s, t, e, i) {
  return i == null ? Lo : t == null ? "" : Uo(t);
}
const Pl = {
  show: !0,
  scale: "y",
  stroke: Ro,
  space: 30,
  gap: 5,
  alignTo: 1,
  size: 50,
  labelGap: 0,
  labelSize: 30,
  labelFont: Ha,
  side: 3,
  //	class: "y-vals",
  //	incrs: numIncrs,
  //	values: (vals, space) => vals,
  //	filter: retArg1,
  grid: Vo,
  ticks: Oa,
  border: Fa,
  font: jo,
  lineGap: Ua,
  rotate: 0
};
function ed(s, t) {
  let e = 3 + (s || 1) * 2;
  return mt(e * t, 3);
}
function sd(s, t) {
  let { scale: e, idxs: i } = s.series[0], n = s._data[0], o = s.valToPos(n[i[0]], e, !0), r = s.valToPos(n[i[1]], e, !0), c = Ct(r - o), a = s.series[t], h = c / (a.points.space * ct);
  return i[1] - i[0] <= h;
}
const Dl = {
  scale: null,
  auto: !0,
  sorted: 0,
  // internal caches
  min: ft,
  max: -ft
}, qa = (s, t, e, i, n) => n, Cl = {
  show: !0,
  auto: !0,
  sorted: 0,
  gaps: qa,
  alpha: 1,
  facets: [
    Tt({}, Dl, { scale: "x" }),
    Tt({}, Dl, { scale: "y" })
  ]
}, zl = {
  scale: "y",
  auto: !0,
  sorted: 0,
  show: !0,
  spanGaps: !1,
  gaps: qa,
  alpha: 1,
  points: {
    show: sd,
    filter: null
    //  paths:
    //	stroke: "#000",
    //	fill: "#fff",
    //	width: 1,
    //	size: 10,
  },
  //	label: "Value",
  //	value: v => v,
  values: null,
  // internal caches
  min: ft,
  max: -ft,
  idxs: [],
  path: null,
  clip: null
};
function id(s, t, e, i, n) {
  return e / 10;
}
const Ia = {
  time: Th,
  auto: !0,
  distr: 1,
  log: 10,
  asinh: 1,
  min: null,
  max: null,
  dir: 1,
  ori: 0
}, nd = Tt({}, Ia, {
  time: !1,
  ori: 1
}), Nl = {};
function Va(s, t) {
  let e = Nl[s];
  return e || (e = {
    key: s,
    plots: [],
    sub(i) {
      e.plots.push(i);
    },
    unsub(i) {
      e.plots = e.plots.filter((n) => n != i);
    },
    pub(i, n, o, r, c, a, h) {
      for (let b = 0; b < e.plots.length; b++)
        e.plots[b] != n && e.plots[b].pub(i, n, o, r, c, a, h);
    }
  }, s != null && (Nl[s] = e)), e;
}
const oi = 1, ko = 2;
function _s(s, t, e) {
  const i = s.mode, n = s.series[t], o = i == 2 ? s._data[t] : s._data, r = s.scales, c = s.bbox;
  let a = o[0], h = i == 2 ? o[1] : o[t], b = i == 2 ? r[n.facets[0].scale] : r[s.series[0].scale], d = i == 2 ? r[n.facets[1].scale] : r[n.scale], m = c.left, w = c.top, v = c.width, _ = c.height, x = s.valToPosH, E = s.valToPosV;
  return b.ori == 0 ? e(
    n,
    a,
    h,
    b,
    d,
    x,
    E,
    m,
    w,
    v,
    _,
    Mn,
    hi,
    En,
    Ba,
    Ga
  ) : e(
    n,
    a,
    h,
    b,
    d,
    E,
    x,
    w,
    m,
    _,
    v,
    Tn,
    pi,
    Go,
    Wa,
    Ya
  );
}
function Bo(s, t) {
  let e = 0, i = 0, n = lt(s.bands, Ko);
  for (let o = 0; o < n.length; o++) {
    let r = n[o];
    r.series[0] == t ? e = r.dir : r.series[1] == t && (r.dir == 1 ? i |= 1 : i |= 2);
  }
  return [
    e,
    i == 1 ? -1 : (
      // neg only
      i == 2 ? 1 : (
        // pos only
        i == 3 ? 2 : (
          // both
          0
        )
      )
    )
  ];
}
function od(s, t, e, i, n) {
  let o = s.mode, r = s.series[t], c = o == 2 ? r.facets[1].scale : r.scale, a = s.scales[c];
  return n == -1 ? a.min : n == 1 ? a.max : a.distr == 3 ? a.dir == 1 ? a.min : a.max : 0;
}
function qe(s, t, e, i, n, o) {
  return _s(s, t, (r, c, a, h, b, d, m, w, v, _, x) => {
    let E = r.pxRound;
    const $ = h.dir * (h.ori == 0 ? 1 : -1), P = h.ori == 0 ? hi : pi;
    let M, j;
    $ == 1 ? (M = e, j = i) : (M = i, j = e);
    let k = E(d(c[M], h, _, w)), O = E(m(a[M], b, x, v)), R = E(d(c[j], h, _, w)), G = E(m(o == 1 ? b.max : b.min, b, x, v)), Y = new Path2D(n);
    return P(Y, R, G), P(Y, k, G), P(Y, k, O), Y;
  });
}
function An(s, t, e, i, n, o) {
  let r = null;
  if (s.length > 0) {
    r = new Path2D();
    const c = t == 0 ? En : Go;
    let a = e;
    for (let d = 0; d < s.length; d++) {
      let m = s[d];
      if (m[1] > m[0]) {
        let w = m[0] - a;
        w > 0 && c(r, a, i, w, i + o), a = m[1];
      }
    }
    let h = e + n - a, b = 10;
    h > 0 && c(r, a, i - b / 2, h, i + o + b);
  }
  return r;
}
function rd(s, t, e) {
  let i = s[s.length - 1];
  i && i[0] == t ? i[1] = e : s.push([t, e]);
}
function Wo(s, t, e, i, n, o, r) {
  let c = [], a = s.length;
  for (let h = n == 1 ? e : i; h >= e && h <= i; h += n)
    if (t[h] === null) {
      let d = h, m = h;
      if (n == 1)
        for (; ++h <= i && t[h] === null; )
          m = h;
      else
        for (; --h >= e && t[h] === null; )
          m = h;
      let w = o(s[d]), v = m == d ? w : o(s[m]), _ = d - n;
      w = r <= 0 && _ >= 0 && _ < a ? o(s[_]) : w;
      let E = m + n;
      v = r >= 0 && E >= 0 && E < a ? o(s[E]) : v, v >= w && c.push([w, v]);
    }
  return c;
}
function Rl(s) {
  return s == 0 ? $a : s == 1 ? Dt : (t) => ms(t, s);
}
function ja(s) {
  let t = s == 0 ? Mn : Tn, e = s == 0 ? (n, o, r, c, a, h) => {
    n.arcTo(o, r, c, a, h);
  } : (n, o, r, c, a, h) => {
    n.arcTo(r, o, a, c, h);
  }, i = s == 0 ? (n, o, r, c, a) => {
    n.rect(o, r, c, a);
  } : (n, o, r, c, a) => {
    n.rect(r, o, a, c);
  };
  return (n, o, r, c, a, h = 0, b = 0) => {
    h == 0 && b == 0 ? i(n, o, r, c, a) : (h = Ae(h, c / 2, a / 2), b = Ae(b, c / 2, a / 2), t(n, o + h, r), e(n, o + c, r, o + c, r + a, h), e(n, o + c, r + a, o, r + a, b), e(n, o, r + a, o, r, b), e(n, o, r, o + c, r, h), n.closePath());
  };
}
const Mn = (s, t, e) => {
  s.moveTo(t, e);
}, Tn = (s, t, e) => {
  s.moveTo(e, t);
}, hi = (s, t, e) => {
  s.lineTo(t, e);
}, pi = (s, t, e) => {
  s.lineTo(e, t);
}, En = ja(0), Go = ja(1), Ba = (s, t, e, i, n, o) => {
  s.arc(t, e, i, n, o);
}, Wa = (s, t, e, i, n, o) => {
  s.arc(e, t, i, n, o);
}, Ga = (s, t, e, i, n, o, r) => {
  s.bezierCurveTo(t, e, i, n, o, r);
}, Ya = (s, t, e, i, n, o, r) => {
  s.bezierCurveTo(e, t, n, i, r, o);
};
function Za(s) {
  return (t, e, i, n, o) => _s(t, e, (r, c, a, h, b, d, m, w, v, _, x) => {
    let { pxRound: E, points: $ } = r, P, M;
    h.ori == 0 ? (P = Mn, M = Ba) : (P = Tn, M = Wa);
    const j = mt($.width * ct, 3);
    let k = ($.size - $.width) / 2 * ct, O = mt(k * 2, 3), R = new Path2D(), G = new Path2D(), { left: Y, top: D, width: J, height: F } = t.bbox;
    En(
      G,
      Y - O,
      D - O,
      J + O * 2,
      F + O * 2
    );
    const B = (q) => {
      if (a[q] != null) {
        let it = E(d(c[q], h, _, w)), K = E(m(a[q], b, x, v));
        P(R, it + k, K), M(R, it, K, k, 0, cn * 2);
      }
    };
    if (o)
      o.forEach(B);
    else
      for (let q = i; q <= n; q++)
        B(q);
    return {
      stroke: j > 0 ? R : null,
      fill: R,
      clip: G,
      flags: oi | ko
    };
  });
}
function Ja(s) {
  return (t, e, i, n, o, r) => {
    i != n && (o != i && r != i && s(t, e, i), o != n && r != n && s(t, e, n), s(t, e, r));
  };
}
const ld = Ja(hi), ad = Ja(pi);
function Qa(s) {
  const t = lt(s?.alignGaps, 0);
  return (e, i, n, o) => _s(e, i, (r, c, a, h, b, d, m, w, v, _, x) => {
    [n, o] = xn(a, n, o);
    let E = r.pxRound, $ = (F) => E(d(F, h, _, w)), P = (F) => E(m(F, b, x, v)), M, j;
    h.ori == 0 ? (M = hi, j = ld) : (M = pi, j = ad);
    const k = h.dir * (h.ori == 0 ? 1 : -1), O = { stroke: new Path2D(), fill: null, clip: null, band: null, gaps: null, flags: oi }, R = O.stroke;
    let G = !1;
    if (o - n >= _ * 4) {
      let F = (H) => e.posToVal(H, h.key, !0), B = null, q = null, it, K, Jt, $t = $(c[k == 1 ? n : o]), ot = $(c[n]), pt = $(c[o]), X = F(k == 1 ? ot + 1 : pt - 1);
      for (let H = k == 1 ? n : o; H >= n && H <= o; H += k) {
        let Et = c[H], xt = (k == 1 ? Et < X : Et > X) ? $t : $(Et), ut = a[H];
        xt == $t ? ut != null ? (K = ut, B == null ? (M(R, xt, P(K)), it = B = q = K) : K < B ? B = K : K > q && (q = K)) : ut === null && (G = !0) : (B != null && j(R, $t, P(B), P(q), P(it), P(K)), ut != null ? (K = ut, M(R, xt, P(K)), B = q = it = K) : (B = q = null, ut === null && (G = !0)), $t = xt, X = F($t + k));
      }
      B != null && B != q && Jt != $t && j(R, $t, P(B), P(q), P(it), P(K));
    } else
      for (let F = k == 1 ? n : o; F >= n && F <= o; F += k) {
        let B = a[F];
        B === null ? G = !0 : B != null && M(R, $(c[F]), P(B));
      }
    let [D, J] = Bo(e, i);
    if (r.fill != null || D != 0) {
      let F = O.fill = new Path2D(R), B = r.fillTo(e, i, r.min, r.max, D), q = P(B), it = $(c[n]), K = $(c[o]);
      k == -1 && ([K, it] = [it, K]), M(F, K, q), M(F, it, q);
    }
    if (!r.spanGaps) {
      let F = [];
      G && F.push(...Wo(c, a, n, o, k, $, t)), O.gaps = F = r.gaps(e, i, n, o, F), O.clip = An(F, h.ori, w, v, _, x);
    }
    return J != 0 && (O.band = J == 2 ? [
      qe(e, i, n, o, R, -1),
      qe(e, i, n, o, R, 1)
    ] : qe(e, i, n, o, R, J)), O;
  });
}
function cd(s) {
  const t = lt(s.align, 1), e = lt(s.ascDesc, !1), i = lt(s.alignGaps, 0), n = lt(s.extend, !1);
  return (o, r, c, a) => _s(o, r, (h, b, d, m, w, v, _, x, E, $, P) => {
    [c, a] = xn(d, c, a);
    let M = h.pxRound, { left: j, width: k } = o.bbox, O = (ot) => M(v(ot, m, $, x)), R = (ot) => M(_(ot, w, P, E)), G = m.ori == 0 ? hi : pi;
    const Y = { stroke: new Path2D(), fill: null, clip: null, band: null, gaps: null, flags: oi }, D = Y.stroke, J = m.dir * (m.ori == 0 ? 1 : -1);
    let F = R(d[J == 1 ? c : a]), B = O(b[J == 1 ? c : a]), q = B, it = B;
    n && t == -1 && (it = j, G(D, it, F)), G(D, B, F);
    for (let ot = J == 1 ? c : a; ot >= c && ot <= a; ot += J) {
      let pt = d[ot];
      if (pt == null)
        continue;
      let X = O(b[ot]), H = R(pt);
      t == 1 ? G(D, X, F) : G(D, q, H), G(D, X, H), F = H, q = X;
    }
    let K = q;
    n && t == 1 && (K = j + k, G(D, K, F));
    let [Jt, $t] = Bo(o, r);
    if (h.fill != null || Jt != 0) {
      let ot = Y.fill = new Path2D(D), pt = h.fillTo(o, r, h.min, h.max, Jt), X = R(pt);
      G(ot, K, X), G(ot, it, X);
    }
    if (!h.spanGaps) {
      let ot = [];
      ot.push(...Wo(b, d, c, a, J, O, i));
      let pt = h.width * ct / 2, X = e || t == 1 ? pt : -pt, H = e || t == -1 ? -pt : pt;
      ot.forEach((Et) => {
        Et[0] += X, Et[1] += H;
      }), Y.gaps = ot = h.gaps(o, r, c, a, ot), Y.clip = An(ot, m.ori, x, E, $, P);
    }
    return $t != 0 && (Y.band = $t == 2 ? [
      qe(o, r, c, a, D, -1),
      qe(o, r, c, a, D, 1)
    ] : qe(o, r, c, a, D, $t)), Y;
  });
}
function Ll(s, t, e, i, n, o, r = ft) {
  if (s.length > 1) {
    let c = null;
    for (let a = 0, h = 1 / 0; a < s.length; a++)
      if (t[a] !== void 0) {
        if (c != null) {
          let b = Ct(s[a] - s[c]);
          b < h && (h = b, r = Ct(e(s[a], i, n, o) - e(s[c], i, n, o)));
        }
        c = a;
      }
  }
  return r;
}
function ud(s) {
  s = s || Oi;
  const t = lt(s.size, [0.6, ft, 1]), e = s.align || 0, i = s.gap || 0;
  let n = s.radius;
  n = // [valueRadius, baselineRadius]
  n == null ? [0, 0] : typeof n == "number" ? [n, 0] : n;
  const o = st(n), r = 1 - t[0], c = lt(t[1], ft), a = lt(t[2], 1), h = lt(s.disp, Oi), b = lt(s.each, (w) => {
  }), { fill: d, stroke: m } = h;
  return (w, v, _, x) => _s(w, v, (E, $, P, M, j, k, O, R, G, Y, D) => {
    let J = E.pxRound, F = e, B = i * ct, q = c * ct, it = a * ct, K, Jt;
    M.ori == 0 ? [K, Jt] = o(w, v) : [Jt, K] = o(w, v);
    const $t = M.dir * (M.ori == 0 ? 1 : -1);
    let ot = M.ori == 0 ? En : Go, pt = M.ori == 0 ? b : (N, gt, Pt, Ts, es, Te, ss) => {
      b(N, gt, Pt, es, Ts, ss, Te);
    }, X = lt(w.bands, Ko).find((N) => N.series[0] == v), H = X != null ? X.dir : 0, Et = E.fillTo(w, v, E.min, E.max, H), jt = J(O(Et, j, D, G)), xt, ut, we, te = Y, _t = J(E.width * ct), Me = !1, Oe = null, ae = null, Ie = null, ks = null;
    d != null && (_t == 0 || m != null) && (Me = !0, Oe = d.values(w, v, _, x), ae = /* @__PURE__ */ new Map(), new Set(Oe).forEach((N) => {
      N != null && ae.set(N, new Path2D());
    }), _t > 0 && (Ie = m.values(w, v, _, x), ks = /* @__PURE__ */ new Map(), new Set(Ie).forEach((N) => {
      N != null && ks.set(N, new Path2D());
    })));
    let { x0: As, size: di } = h;
    if (As != null && di != null) {
      F = 1, $ = As.values(w, v, _, x), As.unit == 2 && ($ = $.map((Pt) => w.posToVal(R + Pt * Y, M.key, !0)));
      let N = di.values(w, v, _, x);
      di.unit == 2 ? ut = N[0] * Y : ut = k(N[0], M, Y, R) - k(0, M, Y, R), te = Ll($, P, k, M, Y, R, te), we = te - ut + B;
    } else
      te = Ll($, P, k, M, Y, R, te), we = te * r + B, ut = te - we;
    we < 1 && (we = 0), _t >= ut / 2 && (_t = 0), we < 5 && (J = $a);
    let qi = we > 0, Xe = te - we - (qi ? _t : 0);
    ut = J(xo(Xe, it, q)), xt = (F == 0 ? ut / 2 : F == $t ? 0 : ut) - F * $t * ((F == 0 ? B / 2 : 0) + (qi ? _t / 2 : 0));
    const Bt = { stroke: null, fill: null, clip: null, band: null, gaps: null, flags: 0 }, Ms = Me ? null : new Path2D();
    let Fe = null;
    if (X != null)
      Fe = w.data[X.series[1]];
    else {
      let { y0: N, y1: gt } = h;
      N != null && gt != null && (P = gt.values(w, v, _, x), Fe = N.values(w, v, _, x));
    }
    let ts = K * ut, Q = Jt * ut;
    for (let N = $t == 1 ? _ : x; N >= _ && N <= x; N += $t) {
      let gt = P[N];
      if (gt == null)
        continue;
      if (Fe != null) {
        let Qt = Fe[N] ?? 0;
        if (gt - Qt == 0)
          continue;
        jt = O(Qt, j, D, G);
      }
      let Pt = M.distr != 2 || h != null ? $[N] : N, Ts = k(Pt, M, Y, R), es = O(lt(gt, Et), j, D, G), Te = J(Ts - xt), ss = J(Zt(es, jt)), ee = J(Ae(es, jt)), ce = ss - ee;
      if (gt != null) {
        let Qt = gt < 0 ? Q : ts, ve = gt < 0 ? ts : Q;
        Me ? (_t > 0 && Ie[N] != null && ot(ks.get(Ie[N]), Te, ee + re(_t / 2), ut, Zt(0, ce - _t), Qt, ve), Oe[N] != null && ot(ae.get(Oe[N]), Te, ee + re(_t / 2), ut, Zt(0, ce - _t), Qt, ve)) : ot(Ms, Te, ee + re(_t / 2), ut, Zt(0, ce - _t), Qt, ve), pt(
          w,
          v,
          N,
          Te - _t / 2,
          ee,
          ut + _t,
          ce
        );
      }
    }
    return _t > 0 ? Bt.stroke = Me ? ks : Ms : Me || (Bt._fill = E.width == 0 ? E._fill : E._stroke ?? E._fill, Bt.width = 0), Bt.fill = Me ? ae : Ms, Bt;
  });
}
function hd(s, t) {
  const e = lt(t?.alignGaps, 0);
  return (i, n, o, r) => _s(i, n, (c, a, h, b, d, m, w, v, _, x, E) => {
    [o, r] = xn(h, o, r);
    let $ = c.pxRound, P = (K) => $(m(K, b, x, v)), M = (K) => $(w(K, d, E, _)), j, k, O;
    b.ori == 0 ? (j = Mn, O = hi, k = Ga) : (j = Tn, O = pi, k = Ya);
    const R = b.dir * (b.ori == 0 ? 1 : -1);
    let G = P(a[R == 1 ? o : r]), Y = G, D = [], J = [];
    for (let K = R == 1 ? o : r; K >= o && K <= r; K += R)
      if (h[K] != null) {
        let $t = a[K], ot = P($t);
        D.push(Y = ot), J.push(M(h[K]));
      }
    const F = { stroke: s(D, J, j, O, k, $), fill: null, clip: null, band: null, gaps: null, flags: oi }, B = F.stroke;
    let [q, it] = Bo(i, n);
    if (c.fill != null || q != 0) {
      let K = F.fill = new Path2D(B), Jt = c.fillTo(i, n, c.min, c.max, q), $t = M(Jt);
      O(K, Y, $t), O(K, G, $t);
    }
    if (!c.spanGaps) {
      let K = [];
      K.push(...Wo(a, h, o, r, R, P, e)), F.gaps = K = c.gaps(i, n, o, r, K), F.clip = An(K, b.ori, v, _, x, E);
    }
    return it != 0 && (F.band = it == 2 ? [
      qe(i, n, o, r, B, -1),
      qe(i, n, o, r, B, 1)
    ] : qe(i, n, o, r, B, it)), F;
  });
}
function pd(s) {
  return hd(dd, s);
}
function dd(s, t, e, i, n, o) {
  const r = s.length;
  if (r < 2)
    return null;
  const c = new Path2D();
  if (e(c, s[0], t[0]), r == 2)
    i(c, s[1], t[1]);
  else {
    let a = Array(r), h = Array(r - 1), b = Array(r - 1), d = Array(r - 1);
    for (let m = 0; m < r - 1; m++)
      b[m] = t[m + 1] - t[m], d[m] = s[m + 1] - s[m], h[m] = b[m] / d[m];
    a[0] = h[0];
    for (let m = 1; m < r - 1; m++)
      h[m] === 0 || h[m - 1] === 0 || h[m - 1] > 0 != h[m] > 0 ? a[m] = 0 : (a[m] = 3 * (d[m - 1] + d[m]) / ((2 * d[m] + d[m - 1]) / h[m - 1] + (d[m] + 2 * d[m - 1]) / h[m]), isFinite(a[m]) || (a[m] = 0));
    a[r - 1] = h[r - 2];
    for (let m = 0; m < r - 1; m++)
      n(
        c,
        s[m] + d[m] / 3,
        t[m] + a[m] * d[m] / 3,
        s[m + 1] - d[m] / 3,
        t[m + 1] - a[m + 1] * d[m] / 3,
        s[m + 1],
        t[m + 1]
      );
  }
  return c;
}
const Ao = /* @__PURE__ */ new Set();
function Ol() {
  for (let s of Ao)
    s.syncRect(!0);
}
ui && (ws(Wh, ti, Ol), ws(Gh, ti, Ol, !0), ws(gn, ti, () => {
  Vt.pxRatio = ct;
}));
const fd = Qa(), md = Za();
function Fl(s, t, e, i) {
  return (i ? [s[0], s[1]].concat(s.slice(2)) : [s[0]].concat(s.slice(1))).map((o, r) => Mo(o, r, t, e));
}
function gd(s, t) {
  return s.map((e, i) => i == 0 ? {} : Tt({}, t, e));
}
function Mo(s, t, e, i) {
  return Tt({}, t == 0 ? e : i, s);
}
function Xa(s, t, e) {
  return t == null ? ii : [t, e];
}
const bd = Xa;
function yd(s, t, e) {
  return t == null ? ii : bn(t, e, Ho, !0);
}
function tc(s, t, e, i) {
  return t == null ? ii : Sn(t, e, s.scales[i].log, !1);
}
const wd = tc;
function ec(s, t, e, i) {
  return t == null ? ii : Fo(t, e, s.scales[i].log, !1);
}
const vd = ec;
function $d(s, t, e, i, n) {
  let o = Zt(gl(s), gl(t)), r = t - s, c = ke(n / i * r, e);
  do {
    let a = e[c], h = i * a / r;
    if (h >= n && o + (a < 5 ? Qe.get(a) : 0) <= 17)
      return [a, h];
  } while (++c < e.length);
  return [0, 0];
}
function Hl(s) {
  let t, e;
  return s = s.replace(/(\d+)px/, (i, n) => (t = Dt((e = +n) * ct)) + "px"), [s, t, e];
}
function xd(s) {
  s.show && [s.font, s.labelFont].forEach((t) => {
    let e = mt(t[2] * ct, 1);
    t[0] = t[0].replace(/[0-9.]+px/, e + "px"), t[1] = e;
  });
}
function Vt(s, t, e) {
  const i = {
    mode: lt(s.mode, 1)
  }, n = i.mode;
  function o(l, u, p, f) {
    let g = u.valToPct(l);
    return f + p * (u.dir == -1 ? 1 - g : g);
  }
  function r(l, u, p, f) {
    let g = u.valToPct(l);
    return f + p * (u.dir == -1 ? g : 1 - g);
  }
  function c(l, u, p, f) {
    return u.ori == 0 ? o(l, u, p, f) : r(l, u, p, f);
  }
  i.valToPosH = o, i.valToPosV = r;
  let a = !1;
  i.status = 0;
  const h = i.root = be(Eh);
  if (s.id != null && (h.id = s.id), oe(h, s.class), s.title) {
    let l = be(Ch, h);
    l.textContent = s.title;
  }
  const b = _e("canvas"), d = i.ctx = b.getContext("2d"), m = be(zh, h);
  ws("click", m, (l) => {
    l.target === v && (bt != Hs || St != Us) && Kt.click(i, l);
  }, !0);
  const w = i.under = be(Nh, m);
  m.appendChild(b);
  const v = i.over = be(Rh, m);
  s = ni(s);
  const _ = +lt(s.pxAlign, 1), x = Rl(_);
  (s.plugins || []).forEach((l) => {
    l.opts && (s = l.opts(i, s) || s);
  });
  const E = s.ms || 1e-3, $ = i.series = n == 1 ? Fl(s.series || [], Tl, zl, !1) : gd(s.series || [null], Cl), P = i.axes = Fl(s.axes || [], Ml, Pl, !0), M = i.scales = {}, j = i.bands = s.bands || [];
  j.forEach((l) => {
    l.fill = st(l.fill || null), l.dir = lt(l.dir, -1);
  });
  const k = n == 2 ? $[1].facets[0].scale : $[0].scale, O = {
    axes: bc,
    series: pc
  }, R = (s.drawOrder || ["axes", "series"]).map((l) => O[l]);
  function G(l) {
    const u = l.distr == 3 ? (p) => Ke(p > 0 ? p : l.clamp(i, p, l.min, l.max, l.key)) : l.distr == 4 ? (p) => lo(p, l.asinh) : l.distr == 100 ? (p) => l.fwd(p) : (p) => p;
    return (p) => {
      let f = u(p), { _min: g, _max: y } = l, S = y - g;
      return (f - g) / S;
    };
  }
  function Y(l) {
    let u = M[l];
    if (u == null) {
      let p = (s.scales || Oi)[l] || Oi;
      if (p.from != null) {
        Y(p.from);
        let f = Tt({}, M[p.from], p, { key: l });
        f.valToPct = G(f), M[l] = f;
      } else {
        u = M[l] = Tt({}, l == k ? Ia : nd, p), u.key = l;
        let f = u.time, g = u.range, y = Ye(g);
        if ((l != k || n == 2 && !f) && (y && (g[0] == null || g[1] == null) && (g = {
          min: g[0] == null ? dl : {
            mode: 1,
            hard: g[0],
            soft: g[0]
          },
          max: g[1] == null ? dl : {
            mode: 1,
            hard: g[1],
            soft: g[1]
          }
        }, y = !1), !y && kn(g))) {
          let S = g;
          g = (A, T, C) => T == null ? ii : bn(T, C, S);
        }
        u.range = st(g || (f ? bd : l == k ? u.distr == 3 ? wd : u.distr == 4 ? vd : Xa : u.distr == 3 ? tc : u.distr == 4 ? ec : yd)), u.auto = st(y ? !1 : u.auto), u.clamp = st(u.clamp || id), u._min = u._max = null, u.valToPct = G(u);
      }
    }
  }
  Y("x"), Y("y"), n == 1 && $.forEach((l) => {
    Y(l.scale);
  }), P.forEach((l) => {
    Y(l.scale);
  });
  for (let l in s.scales)
    Y(l);
  const D = M[k], J = D.distr;
  let F, B;
  D.ori == 0 ? (oe(h, Ph), F = o, B = r) : (oe(h, Dh), F = r, B = o);
  const q = {};
  for (let l in M) {
    let u = M[l];
    (u.min != null || u.max != null) && (q[l] = { min: u.min, max: u.max }, u.min = u.max = null);
  }
  const it = s.tzDate || ((l) => new Date(Dt(l / E))), K = s.fmtDate || qo, Jt = E == 1 ? Pp(it) : zp(it), $t = _l(it, Sl(E == 1 ? Ep : Cp, K)), ot = Al(it, kl(Rp, K)), pt = [], X = i.legend = Tt({}, Fp, s.legend), H = i.cursor = Tt({}, Vp, { drag: { y: n == 2 } }, s.cursor), Et = X.show, jt = H.show, xt = X.markers;
  X.idxs = pt, xt.width = st(xt.width), xt.dash = st(xt.dash), xt.stroke = st(xt.stroke), xt.fill = st(xt.fill);
  let ut, we, te, _t = [], Me = [], Oe, ae = !1, Ie = {};
  if (X.live) {
    const l = $[1] ? $[1].values : null;
    ae = l != null, Oe = ae ? l(i, 1, 0) : { _: 0 };
    for (let u in Oe)
      Ie[u] = Lo;
  }
  if (Et)
    if (ut = _e("table", Kh, h), te = _e("tbody", null, ut), X.mount(i, ut), ae) {
      we = _e("thead", null, ut, te);
      let l = _e("tr", null, we);
      _e("th", null, l);
      for (var ks in Oe)
        _e("th", tl, l).textContent = ks;
    } else
      oe(ut, Ih), X.live && oe(ut, qh);
  const As = { show: !0 }, di = { show: !1 };
  function qi(l, u) {
    if (u == 0 && (ae || !X.live || n == 2))
      return ii;
    let p = [], f = _e("tr", Vh, te, te.childNodes[u]);
    oe(f, l.class), l.show || oe(f, bs);
    let g = _e("th", null, f);
    if (xt.show) {
      let A = be(jh, g);
      if (u > 0) {
        let T = xt.width(i, u);
        T && (A.style.border = T + "px " + xt.dash(i, u) + " " + xt.stroke(i, u)), A.style.background = xt.fill(i, u);
      }
    }
    let y = be(tl, g);
    l.label instanceof HTMLElement ? y.appendChild(l.label) : y.textContent = l.label, u > 0 && (xt.show || (y.style.color = l.width > 0 ? xt.stroke(i, u) : xt.fill(i, u)), Bt("click", g, (A) => {
      if (H._lock)
        return;
      ns(A);
      let T = $.indexOf(l);
      if ((A.ctrlKey || A.metaKey) != X.isolate) {
        let C = $.some((z, L) => L > 0 && L != T && z.show);
        $.forEach((z, L) => {
          L > 0 && Pe(L, C ? L == T ? As : di : As, !0, Mt.setSeries);
        });
      } else
        Pe(T, { show: !l.show }, !0, Mt.setSeries);
    }, !1), Ps && Bt(nl, g, (A) => {
      H._lock || (ns(A), Pe($.indexOf(l), qs, !0, Mt.setSeries));
    }, !1));
    for (var S in Oe) {
      let A = _e("td", Bh, f);
      A.textContent = "--", p.push(A);
    }
    return [f, p];
  }
  const Xe = /* @__PURE__ */ new Map();
  function Bt(l, u, p, f = !0) {
    const g = Xe.get(u) || {}, y = H.bind[l](i, u, p, f);
    y && (ws(l, u, g[l] = y), Xe.set(u, g));
  }
  function Ms(l, u, p) {
    const f = Xe.get(u) || {};
    for (let g in f)
      (l == null || g == l) && ($o(g, u, f[g]), delete f[g]);
    l == null && Xe.delete(u);
  }
  let Fe = 0, ts = 0, Q = 0, N = 0, gt = 0, Pt = 0, Ts = gt, es = Pt, Te = Q, ss = N, ee = 0, ce = 0, Qt = 0, ve = 0;
  i.bbox = {};
  let Pn = !1, Ii = !1, Es = !1, is = !1, Vi = !1, ue = !1;
  function Dn(l, u, p) {
    (p || l != i.width || u != i.height) && Yo(l, u), Rs(!1), Es = !0, Ii = !0, Ls();
  }
  function Yo(l, u) {
    i.width = Fe = Q = l, i.height = ts = N = u, gt = Pt = 0, oc(), rc();
    let p = i.bbox;
    ee = p.left = ms(gt * ct, 0.5), ce = p.top = ms(Pt * ct, 0.5), Qt = p.width = ms(Q * ct, 0.5), ve = p.height = ms(N * ct, 0.5);
  }
  const sc = 3;
  function ic() {
    let l = !1, u = 0;
    for (; !l; ) {
      u++;
      let p = mc(u), f = gc(u);
      l = u == sc || p && f, l || (Yo(i.width, i.height), Ii = !0);
    }
  }
  function nc({ width: l, height: u }) {
    Dn(l, u);
  }
  i.setSize = nc;
  function oc() {
    let l = !1, u = !1, p = !1, f = !1;
    P.forEach((g, y) => {
      if (g.show && g._show) {
        let { side: S, _size: A } = g, T = S % 2, C = g.label != null ? g.labelSize : 0, z = A + C;
        z > 0 && (T ? (Q -= z, S == 3 ? (gt += z, f = !0) : p = !0) : (N -= z, S == 0 ? (Pt += z, l = !0) : u = !0));
      }
    }), os[0] = l, os[1] = p, os[2] = u, os[3] = f, Q -= Ve[1] + Ve[3], gt += Ve[3], N -= Ve[2] + Ve[0], Pt += Ve[0];
  }
  function rc() {
    let l = gt + Q, u = Pt + N, p = gt, f = Pt;
    function g(y, S) {
      switch (y) {
        case 1:
          return l += S, l - S;
        case 2:
          return u += S, u - S;
        case 3:
          return p -= S, p + S;
        case 0:
          return f -= S, f + S;
      }
    }
    P.forEach((y, S) => {
      if (y.show && y._show) {
        let A = y.side;
        y._pos = g(A, y._size), y.label != null && (y._lpos = g(A, y.labelSize));
      }
    });
  }
  if (H.dataIdx == null) {
    let l = H.hover, u = l.skip = new Set(l.skip ?? []);
    u.add(void 0);
    let p = l.prox = st(l.prox), f = l.bias ??= 0;
    H.dataIdx = (g, y, S, A) => {
      if (y == 0)
        return S;
      let T = S, C = p(g, y, S, A) ?? ft, z = C >= 0 && C < ft, L = D.ori == 0 ? Q : N, Z = H.left, at = t[0], rt = t[y];
      if (u.has(rt[S])) {
        T = null;
        let et = null, W = null, U;
        if (f == 0 || f == -1)
          for (U = S; et == null && U-- > 0; )
            u.has(rt[U]) || (et = U);
        if (f == 0 || f == 1)
          for (U = S; W == null && U++ < rt.length; )
            u.has(rt[U]) || (W = U);
        if (et != null || W != null)
          if (z) {
            let wt = et == null ? -1 / 0 : F(at[et], D, L, 0), kt = W == null ? 1 / 0 : F(at[W], D, L, 0), Ht = Z - wt, dt = kt - Z;
            Ht <= dt ? Ht <= C && (T = et) : dt <= C && (T = W);
          } else
            T = W == null ? et : et == null ? W : S - et <= W - S ? et : W;
      } else z && Ct(Z - F(at[S], D, L, 0)) > C && (T = null);
      return T;
    };
  }
  const ns = (l) => {
    H.event = l;
  };
  H.idxs = pt, H._lock = !1;
  let It = H.points;
  It.show = st(It.show), It.size = st(It.size), It.stroke = st(It.stroke), It.width = st(It.width), It.fill = st(It.fill);
  const Ee = i.focus = Tt({}, s.focus || { alpha: 0.3 }, H.focus), Ps = Ee.prox >= 0, Ds = Ps && It.one;
  let he = [], Cs = [], zs = [];
  function Zo(l, u) {
    let p = It.show(i, u);
    if (p instanceof HTMLElement)
      return oe(p, Uh), oe(p, l.class), Ne(p, -10, -10, Q, N), v.insertBefore(p, he[u]), p;
  }
  function Jo(l, u) {
    if (n == 1 || u > 0) {
      let p = n == 1 && M[l.scale].time, f = l.value;
      l.value = p ? wl(f) ? Al(it, kl(f, K)) : f || ot : f || td, l.label = l.label || (p ? Bp : jp);
    }
    if (Ds || u > 0) {
      l.width = l.width == null ? 1 : l.width, l.paths = l.paths || fd || np, l.fillTo = st(l.fillTo || od), l.pxAlign = +lt(l.pxAlign, _), l.pxRound = Rl(l.pxAlign), l.stroke = st(l.stroke || null), l.fill = st(l.fill || null), l._stroke = l._fill = l._paths = l._focus = null;
      let p = ed(Zt(1, l.width), 1), f = l.points = Tt({}, {
        size: p,
        width: Zt(1, p * 0.2),
        stroke: l.stroke,
        space: p * 2,
        paths: md,
        _stroke: null,
        _fill: null
      }, l.points);
      f.show = st(f.show), f.filter = st(f.filter), f.fill = st(f.fill), f.stroke = st(f.stroke), f.paths = st(f.paths), f.pxAlign = l.pxAlign;
    }
    if (Et) {
      let p = qi(l, u);
      _t.splice(u, 0, p[0]), Me.splice(u, 0, p[1]), X.values.push(null);
    }
    if (jt) {
      pt.splice(u, 0, null);
      let p = null;
      Ds ? u == 0 && (p = Zo(l, u)) : u > 0 && (p = Zo(l, u)), he.splice(u, 0, p), Cs.splice(u, 0, 0), zs.splice(u, 0, 0);
    }
    Ft("addSeries", u);
  }
  function lc(l, u) {
    u = u ?? $.length, l = n == 1 ? Mo(l, u, Tl, zl) : Mo(l, u, {}, Cl), $.splice(u, 0, l), Jo($[u], u);
  }
  i.addSeries = lc;
  function ac(l) {
    if ($.splice(l, 1), Et) {
      X.values.splice(l, 1), Me.splice(l, 1);
      let u = _t.splice(l, 1)[0];
      Ms(null, u.firstChild), u.remove();
    }
    jt && (pt.splice(l, 1), he.splice(l, 1)[0].remove(), Cs.splice(l, 1), zs.splice(l, 1)), Ft("delSeries", l);
  }
  i.delSeries = ac;
  const os = [!1, !1, !1, !1];
  function cc(l, u) {
    if (l._show = l.show, l.show) {
      let p = l.side % 2, f = M[l.scale];
      f == null && (l.scale = p ? $[1].scale : k, f = M[l.scale]);
      let g = f.time;
      l.size = st(l.size), l.space = st(l.space), l.rotate = st(l.rotate), Ye(l.incrs) && l.incrs.forEach((S) => {
        !Qe.has(S) && Qe.set(S, _a(S));
      }), l.incrs = st(l.incrs || (f.distr == 2 ? Ap : g ? E == 1 ? Tp : Dp : gs)), l.splits = st(l.splits || (g && f.distr == 1 ? Jt : f.distr == 3 ? So : f.distr == 4 ? Yp : Gp)), l.stroke = st(l.stroke), l.grid.stroke = st(l.grid.stroke), l.ticks.stroke = st(l.ticks.stroke), l.border.stroke = st(l.border.stroke);
      let y = l.values;
      l.values = // static array of tick values
      Ye(y) && !Ye(y[0]) ? st(y) : (
        // temporal
        g ? (
          // config array of fmtDate string tpls
          Ye(y) ? _l(it, Sl(y, K)) : (
            // fmtDate string tpl
            wl(y) ? Np(it, y) : y || $t
          )
        ) : y || Wp
      ), l.filter = st(l.filter || (f.distr >= 3 && f.log == 10 ? Qp : f.distr == 3 && f.log == 2 ? Xp : xa)), l.font = Hl(l.font), l.labelFont = Hl(l.labelFont), l._size = l.size(i, null, u, 0), l._space = l._rotate = l._incrs = l._found = // foundIncrSpace
      l._splits = l._values = null, l._size > 0 && (os[u] = !0, l._el = be(Lh, m));
    }
  }
  function fi(l, u, p, f) {
    let [g, y, S, A] = p, T = u % 2, C = 0;
    return T == 0 && (A || y) && (C = u == 0 && !g || u == 2 && !S ? Dt(Ml.size / 3) : 0), T == 1 && (g || S) && (C = u == 1 && !y || u == 3 && !A ? Dt(Pl.size / 2) : 0), C;
  }
  const Qo = i.padding = (s.padding || [fi, fi, fi, fi]).map((l) => st(lt(l, fi))), Ve = i._padding = Qo.map((l, u) => l(i, u, os, 0));
  let Ut, Nt = null, Rt = null;
  const ji = n == 1 ? $[0].idxs : null;
  let $e = null, mi = !1;
  function Xo(l, u) {
    if (t = l ?? [], i.data = i._data = t, n == 2) {
      Ut = 0;
      for (let p = 1; p < $.length; p++)
        Ut += t[p][0].length;
    } else {
      t.length == 0 && (i.data = i._data = t = [[]]), $e = t[0], Ut = $e.length;
      let p = t;
      if (J == 2) {
        p = t.slice();
        let f = p[0] = Array(Ut);
        for (let g = 0; g < Ut; g++)
          f[g] = g;
      }
      i._data = t = p;
    }
    if (Rs(!0), Ft("setData"), J == 2 && (Es = !0), u !== !1) {
      let p = D;
      p.auto(i, mi) ? Cn() : Be(k, p.min, p.max), is = is || H.left >= 0, ue = !0, Ls();
    }
  }
  i.setData = Xo;
  function Cn() {
    mi = !0;
    let l, u;
    n == 1 && (Ut > 0 ? (Nt = ji[0] = 0, Rt = ji[1] = Ut - 1, l = t[0][Nt], u = t[0][Rt], J == 2 ? (l = Nt, u = Rt) : l == u && (J == 3 ? [l, u] = Sn(l, l, D.log, !1) : J == 4 ? [l, u] = Fo(l, l, D.log, !1) : D.time ? u = l + Dt(86400 / E) : [l, u] = bn(l, u, Ho, !0))) : (Nt = ji[0] = l = null, Rt = ji[1] = u = null)), Be(k, l, u);
  }
  let Bi, Ns, zn, Nn, Rn, Ln, On, Fn, Hn, Xt;
  function tr(l, u, p, f, g, y) {
    l ??= sl, p ??= Ko, f ??= "butt", g ??= sl, y ??= "round", l != Bi && (d.strokeStyle = Bi = l), g != Ns && (d.fillStyle = Ns = g), u != zn && (d.lineWidth = zn = u), y != Rn && (d.lineJoin = Rn = y), f != Ln && (d.lineCap = Ln = f), p != Nn && d.setLineDash(Nn = p);
  }
  function er(l, u, p, f) {
    u != Ns && (d.fillStyle = Ns = u), l != On && (d.font = On = l), p != Fn && (d.textAlign = Fn = p), f != Hn && (d.textBaseline = Hn = f);
  }
  function Un(l, u, p, f, g = 0) {
    if (f.length > 0 && l.auto(i, mi) && (u == null || u.min == null)) {
      let y = lt(Nt, 0), S = lt(Rt, f.length - 1), A = p.min == null ? Qh(f, y, S, g, l.distr == 3) : [p.min, p.max];
      l.min = Ae(l.min, p.min = A[0]), l.max = Zt(l.max, p.max = A[1]);
    }
  }
  const sr = { min: null, max: null };
  function uc() {
    for (let f in M) {
      let g = M[f];
      q[f] == null && // scales that have never been set (on init)
      (g.min == null || // or auto scales when the x scale was explicitly set
      q[k] != null && g.auto(i, mi)) && (q[f] = sr);
    }
    for (let f in M) {
      let g = M[f];
      q[f] == null && g.from != null && q[g.from] != null && (q[f] = sr);
    }
    q[k] != null && Rs(!0);
    let l = {};
    for (let f in q) {
      let g = q[f];
      if (g != null) {
        let y = l[f] = ni(M[f], lp);
        if (g.min != null)
          Tt(y, g);
        else if (f != k || n == 2)
          if (Ut == 0 && y.from == null) {
            let S = y.range(i, null, null, f);
            y.min = S[0], y.max = S[1];
          } else
            y.min = ft, y.max = -ft;
      }
    }
    if (Ut > 0) {
      $.forEach((f, g) => {
        if (n == 1) {
          let y = f.scale, S = q[y];
          if (S == null)
            return;
          let A = l[y];
          if (g == 0) {
            let T = A.range(i, A.min, A.max, y);
            A.min = T[0], A.max = T[1], Nt = ke(A.min, t[0]), Rt = ke(A.max, t[0]), Rt - Nt > 1 && (t[0][Nt] < A.min && Nt++, t[0][Rt] > A.max && Rt--), f.min = $e[Nt], f.max = $e[Rt];
          } else f.show && f.auto && Un(A, S, f, t[g], f.sorted);
          f.idxs[0] = Nt, f.idxs[1] = Rt;
        } else if (g > 0 && f.show && f.auto) {
          let [y, S] = f.facets, A = y.scale, T = S.scale, [C, z] = t[g], L = l[A], Z = l[T];
          L != null && Un(L, q[A], y, C, y.sorted), Z != null && Un(Z, q[T], S, z, S.sorted), f.min = S.min, f.max = S.max;
        }
      });
      for (let f in l) {
        let g = l[f], y = q[f];
        if (g.from == null && (y == null || y.min == null)) {
          let S = g.range(
            i,
            g.min == ft ? null : g.min,
            g.max == -ft ? null : g.max,
            f
          );
          g.min = S[0], g.max = S[1];
        }
      }
    }
    for (let f in l) {
      let g = l[f];
      if (g.from != null) {
        let y = l[g.from];
        if (y.min == null)
          g.min = g.max = null;
        else {
          let S = g.range(i, y.min, y.max, f);
          g.min = S[0], g.max = S[1];
        }
      }
    }
    let u = {}, p = !1;
    for (let f in l) {
      let g = l[f], y = M[f];
      if (y.min != g.min || y.max != g.max) {
        y.min = g.min, y.max = g.max;
        let S = y.distr;
        y._min = S == 3 ? Ke(y.min) : S == 4 ? lo(y.min, y.asinh) : S == 100 ? y.fwd(y.min) : y.min, y._max = S == 3 ? Ke(y.max) : S == 4 ? lo(y.max, y.asinh) : S == 100 ? y.fwd(y.max) : y.max, u[f] = p = !0;
      }
    }
    if (p) {
      $.forEach((f, g) => {
        n == 2 ? g > 0 && u.y && (f._paths = null) : u[f.scale] && (f._paths = null);
      });
      for (let f in u)
        Es = !0, Ft("setScale", f);
      jt && H.left >= 0 && (is = ue = !0);
    }
    for (let f in q)
      q[f] = null;
  }
  function hc(l) {
    let u = xo(Nt - 1, 0, Ut - 1), p = xo(Rt + 1, 0, Ut - 1);
    for (; l[u] == null && u > 0; )
      u--;
    for (; l[p] == null && p < Ut - 1; )
      p++;
    return [u, p];
  }
  function pc() {
    if (Ut > 0) {
      let l = $.some((u) => u._focus) && Xt != Ee.alpha;
      l && (d.globalAlpha = Xt = Ee.alpha), $.forEach((u, p) => {
        if (p > 0 && u.show && (ir(p, !1), ir(p, !0), u._paths == null)) {
          let f = Xt;
          Xt != u.alpha && (d.globalAlpha = Xt = u.alpha);
          let g = n == 2 ? [0, t[p][0].length - 1] : hc(t[p]);
          u._paths = u.paths(i, p, g[0], g[1]), Xt != f && (d.globalAlpha = Xt = f);
        }
      }), $.forEach((u, p) => {
        if (p > 0 && u.show) {
          let f = Xt;
          Xt != u.alpha && (d.globalAlpha = Xt = u.alpha), u._paths != null && nr(p, !1);
          {
            let g = u._paths != null ? u._paths.gaps : null, y = u.points.show(i, p, Nt, Rt, g), S = u.points.filter(i, p, y, g);
            (y || S) && (u.points._paths = u.points.paths(i, p, Nt, Rt, S), nr(p, !0));
          }
          Xt != f && (d.globalAlpha = Xt = f), Ft("drawSeries", p);
        }
      }), l && (d.globalAlpha = Xt = 1);
    }
  }
  function ir(l, u) {
    let p = u ? $[l].points : $[l];
    p._stroke = p.stroke(i, l), p._fill = p.fill(i, l);
  }
  function nr(l, u) {
    let p = u ? $[l].points : $[l], {
      stroke: f,
      fill: g,
      clip: y,
      flags: S,
      _stroke: A = p._stroke,
      _fill: T = p._fill,
      _width: C = p.width
    } = p._paths;
    C = mt(C * ct, 3);
    let z = null, L = C % 2 / 2;
    u && T == null && (T = C > 0 ? "#fff" : A);
    let Z = p.pxAlign == 1 && L > 0;
    if (Z && d.translate(L, L), !u) {
      let at = ee - C / 2, rt = ce - C / 2, et = Qt + C, W = ve + C;
      z = new Path2D(), z.rect(at, rt, et, W);
    }
    u ? Kn(A, C, p.dash, p.cap, T, f, g, S, y) : dc(l, A, C, p.dash, p.cap, T, f, g, S, z, y), Z && d.translate(-L, -L);
  }
  function dc(l, u, p, f, g, y, S, A, T, C, z) {
    let L = !1;
    T != 0 && j.forEach((Z, at) => {
      if (Z.series[0] == l) {
        let rt = $[Z.series[1]], et = t[Z.series[1]], W = (rt._paths || Oi).band;
        Ye(W) && (W = Z.dir == 1 ? W[0] : W[1]);
        let U, wt = null;
        rt.show && W && tp(et, Nt, Rt) ? (wt = Z.fill(i, at) || y, U = rt._paths.clip) : W = null, Kn(u, p, f, g, wt, S, A, T, C, z, U, W), L = !0;
      }
    }), L || Kn(u, p, f, g, y, S, A, T, C, z);
  }
  const or = oi | ko;
  function Kn(l, u, p, f, g, y, S, A, T, C, z, L) {
    tr(l, u, p, f, g), (T || C || L) && (d.save(), T && d.clip(T), C && d.clip(C)), L ? (A & or) == or ? (d.clip(L), z && d.clip(z), Gi(g, S), Wi(l, y, u)) : A & ko ? (Gi(g, S), d.clip(L), Wi(l, y, u)) : A & oi && (d.save(), d.clip(L), z && d.clip(z), Gi(g, S), d.restore(), Wi(l, y, u)) : (Gi(g, S), Wi(l, y, u)), (T || C || L) && d.restore();
  }
  function Wi(l, u, p) {
    p > 0 && (u instanceof Map ? u.forEach((f, g) => {
      d.strokeStyle = Bi = g, d.stroke(f);
    }) : u != null && l && d.stroke(u));
  }
  function Gi(l, u) {
    u instanceof Map ? u.forEach((p, f) => {
      d.fillStyle = Ns = f, d.fill(p);
    }) : u != null && l && d.fill(u);
  }
  function fc(l, u, p, f) {
    let g = P[l], y;
    if (f <= 0)
      y = [0, 0];
    else {
      let S = g._space = g.space(i, l, u, p, f), A = g._incrs = g.incrs(i, l, u, p, f, S);
      y = $d(u, p, A, f, S);
    }
    return g._found = y;
  }
  function qn(l, u, p, f, g, y, S, A, T, C) {
    let z = S % 2 / 2;
    _ == 1 && d.translate(z, z), tr(A, S, T, C, A), d.beginPath();
    let L, Z, at, rt, et = g + (f == 0 || f == 3 ? -y : y);
    p == 0 ? (Z = g, rt = et) : (L = g, at = et);
    for (let W = 0; W < l.length; W++)
      u[W] != null && (p == 0 ? L = at = l[W] : Z = rt = l[W], d.moveTo(L, Z), d.lineTo(at, rt));
    d.stroke(), _ == 1 && d.translate(-z, -z);
  }
  function mc(l) {
    let u = !0;
    return P.forEach((p, f) => {
      if (!p.show)
        return;
      let g = M[p.scale];
      if (g.min == null) {
        p._show && (u = !1, p._show = !1, Rs(!1));
        return;
      } else
        p._show || (u = !1, p._show = !0, Rs(!1));
      let y = p.side, S = y % 2, { min: A, max: T } = g, [C, z] = fc(f, A, T, S == 0 ? Q : N);
      if (z == 0)
        return;
      let L = g.distr == 2, Z = p._splits = p.splits(i, f, A, T, C, z, L), at = g.distr == 2 ? Z.map((U) => $e[U]) : Z, rt = g.distr == 2 ? $e[Z[1]] - $e[Z[0]] : C, et = p._values = p.values(i, p.filter(i, at, f, z, rt), f, z, rt);
      p._rotate = y == 2 ? p.rotate(i, et, f, z) : 0;
      let W = p._size;
      p._size = ye(p.size(i, et, f, l)), W != null && p._size != W && (u = !1);
    }), u;
  }
  function gc(l) {
    let u = !0;
    return Qo.forEach((p, f) => {
      let g = p(i, f, os, l);
      g != Ve[f] && (u = !1), Ve[f] = g;
    }), u;
  }
  function bc() {
    for (let l = 0; l < P.length; l++) {
      let u = P[l];
      if (!u.show || !u._show)
        continue;
      let p = u.side, f = p % 2, g, y, S = u.stroke(i, l), A = p == 0 || p == 3 ? -1 : 1, [T, C] = u._found;
      if (u.label != null) {
        let Gt = u.labelGap * A, ne = Dt((u._lpos + Gt) * ct);
        er(u.labelFont[0], S, "center", p == 2 ? ki : el), d.save(), f == 1 ? (g = y = 0, d.translate(
          ne,
          Dt(ce + ve / 2)
        ), d.rotate((p == 3 ? -cn : cn) / 2)) : (g = Dt(ee + Qt / 2), y = ne);
        let as = va(u.label) ? u.label(i, l, T, C) : u.label;
        d.fillText(as, g, y), d.restore();
      }
      if (C == 0)
        continue;
      let z = M[u.scale], L = f == 0 ? Qt : ve, Z = f == 0 ? ee : ce, at = u._splits, rt = z.distr == 2 ? at.map((Gt) => $e[Gt]) : at, et = z.distr == 2 ? $e[at[1]] - $e[at[0]] : T, W = u.ticks, U = u.border, wt = W.show ? W.size : 0, kt = Dt(wt * ct), Ht = Dt((u.alignTo == 2 ? u._size - wt - u.gap : u.gap) * ct), dt = u._rotate * -cn / 180, At = x(u._pos * ct), se = (kt + Ht) * A, Wt = At + se;
      y = f == 0 ? Wt : 0, g = f == 1 ? Wt : 0;
      let pe = u.font[0], xe = u.align == 1 ? Gs : u.align == 2 ? no : dt > 0 ? Gs : dt < 0 ? no : f == 0 ? "center" : p == 3 ? no : Gs, Ce = dt || f == 1 ? "middle" : p == 2 ? ki : el;
      er(pe, S, xe, Ce);
      let ie = u.font[1] * u.lineGap, de = at.map((Gt) => x(c(Gt, z, L, Z))), Se = u._values;
      for (let Gt = 0; Gt < Se.length; Gt++) {
        let ne = Se[Gt];
        if (ne != null) {
          f == 0 ? g = de[Gt] : y = de[Gt], ne = "" + ne;
          let as = ne.indexOf(`
`) == -1 ? [ne] : ne.split(/\n/gm);
          for (let Yt = 0; Yt < as.length; Yt++) {
            let _r = as[Yt];
            dt ? (d.save(), d.translate(g, y + Yt * ie), d.rotate(dt), d.fillText(_r, 0, 0), d.restore()) : d.fillText(_r, g, y + Yt * ie);
          }
        }
      }
      W.show && qn(
        de,
        W.filter(i, rt, l, C, et),
        f,
        p,
        At,
        kt,
        mt(W.width * ct, 3),
        W.stroke(i, l),
        W.dash,
        W.cap
      );
      let ze = u.grid;
      ze.show && qn(
        de,
        ze.filter(i, rt, l, C, et),
        f,
        f == 0 ? 2 : 1,
        f == 0 ? ce : ee,
        f == 0 ? ve : Qt,
        mt(ze.width * ct, 3),
        ze.stroke(i, l),
        ze.dash,
        ze.cap
      ), U.show && qn(
        [At],
        [1],
        f == 0 ? 1 : 0,
        f == 0 ? 1 : 2,
        f == 1 ? ce : ee,
        f == 1 ? ve : Qt,
        mt(U.width * ct, 3),
        U.stroke(i, l),
        U.dash,
        U.cap
      );
    }
    Ft("drawAxes");
  }
  function Rs(l) {
    $.forEach((u, p) => {
      p > 0 && (u._paths = null, l && (n == 1 ? (u.min = null, u.max = null) : u.facets.forEach((f) => {
        f.min = null, f.max = null;
      })));
    });
  }
  let Yi = !1, In = !1, gi = [];
  function yc() {
    In = !1;
    for (let l = 0; l < gi.length; l++)
      Ft(...gi[l]);
    gi.length = 0;
  }
  function Ls() {
    Yi || (fp(rr), Yi = !0);
  }
  function wc(l, u = !1) {
    Yi = !0, In = u, l(i), rr(), u && gi.length > 0 && queueMicrotask(yc);
  }
  i.batch = wc;
  function rr() {
    if (Pn && (uc(), Pn = !1), Es && (ic(), Es = !1), Ii) {
      if (vt(w, Gs, gt), vt(w, ki, Pt), vt(w, Ti, Q), vt(w, Ei, N), vt(v, Gs, gt), vt(v, ki, Pt), vt(v, Ti, Q), vt(v, Ei, N), vt(m, Ti, Fe), vt(m, Ei, ts), b.width = Dt(Fe * ct), b.height = Dt(ts * ct), P.forEach(({ _el: l, _show: u, _size: p, _pos: f, side: g }) => {
        if (l != null)
          if (u) {
            let y = g === 3 || g === 0 ? p : 0, S = g % 2 == 1;
            vt(l, S ? "left" : "top", f - y), vt(l, S ? "width" : "height", p), vt(l, S ? "top" : "left", S ? Pt : gt), vt(l, S ? "height" : "width", S ? N : Q), vo(l, bs);
          } else
            oe(l, bs);
      }), Bi = Ns = zn = Rn = Ln = On = Fn = Hn = Nn = null, Xt = 1, wi(!0), gt != Ts || Pt != es || Q != Te || N != ss) {
        Rs(!1);
        let l = Q / Te, u = N / ss;
        if (jt && !is && H.left >= 0) {
          H.left *= l, H.top *= u, Os && Ne(Os, Dt(H.left), 0, Q, N), Fs && Ne(Fs, 0, Dt(H.top), Q, N);
          for (let p = 0; p < he.length; p++) {
            let f = he[p];
            f != null && (Cs[p] *= l, zs[p] *= u, Ne(f, ye(Cs[p]), ye(zs[p]), Q, N));
          }
        }
        if (yt.show && !Vi && yt.left >= 0 && yt.width > 0) {
          yt.left *= l, yt.width *= l, yt.top *= u, yt.height *= u;
          for (let p in Yn)
            vt(Ks, p, yt[p]);
        }
        Ts = gt, es = Pt, Te = Q, ss = N;
      }
      Ft("setSize"), Ii = !1;
    }
    Fe > 0 && ts > 0 && (d.clearRect(0, 0, b.width, b.height), Ft("drawClear"), R.forEach((l) => l()), Ft("draw")), yt.show && Vi && (Zi(yt), Vi = !1), jt && is && (ls(null, !0, !1), is = !1), X.show && X.live && ue && (Wn(), ue = !1), a || (a = !0, i.status = 1, Ft("ready")), mi = !1, Yi = !1;
  }
  i.redraw = (l, u) => {
    Es = u || !1, l !== !1 ? Be(k, D.min, D.max) : Ls();
  };
  function Vn(l, u) {
    let p = M[l];
    if (p.from == null) {
      if (Ut == 0) {
        let f = p.range(i, u.min, u.max, l);
        u.min = f[0], u.max = f[1];
      }
      if (u.min > u.max) {
        let f = u.min;
        u.min = u.max, u.max = f;
      }
      if (Ut > 1 && u.min != null && u.max != null && u.max - u.min < 1e-16)
        return;
      l == k && p.distr == 2 && Ut > 0 && (u.min = ke(u.min, t[0]), u.max = ke(u.max, t[0]), u.min == u.max && u.max++), q[l] = u, Pn = !0, Ls();
    }
  }
  i.setScale = Vn;
  let jn, Bn, Os, Fs, lr, ar, Hs, Us, cr, ur, bt, St, je = !1;
  const Kt = H.drag;
  let Lt = Kt.x, Ot = Kt.y;
  jt && (H.x && (jn = be(Fh, v)), H.y && (Bn = be(Hh, v)), D.ori == 0 ? (Os = jn, Fs = Bn) : (Os = Bn, Fs = jn), bt = H.left, St = H.top);
  const yt = i.select = Tt({
    show: !0,
    over: !0,
    left: 0,
    width: 0,
    top: 0,
    height: 0
  }, s.select), Ks = yt.show ? be(Oh, yt.over ? v : w) : null;
  function Zi(l, u) {
    if (yt.show) {
      for (let p in l)
        yt[p] = l[p], p in Yn && vt(Ks, p, l[p]);
      u !== !1 && Ft("setSelect");
    }
  }
  i.setSelect = Zi;
  function vc(l) {
    if ($[l].show)
      Et && vo(_t[l], bs);
    else if (Et && oe(_t[l], bs), jt) {
      let p = Ds ? he[0] : he[l];
      p != null && Ne(p, -10, -10, Q, N);
    }
  }
  function Be(l, u, p) {
    Vn(l, { min: u, max: p });
  }
  function Pe(l, u, p, f) {
    u.focus != null && kc(l), u.show != null && $.forEach((g, y) => {
      y > 0 && (l == y || l == null) && (g.show = u.show, vc(y), n == 2 ? (Be(g.facets[0].scale, null, null), Be(g.facets[1].scale, null, null)) : Be(g.scale, null, null), Ls());
    }), p !== !1 && Ft("setSeries", l, u), f && vi("setSeries", i, l, u);
  }
  i.setSeries = Pe;
  function $c(l, u) {
    Tt(j[l], u);
  }
  function xc(l, u) {
    l.fill = st(l.fill || null), l.dir = lt(l.dir, -1), u = u ?? j.length, j.splice(u, 0, l);
  }
  function Sc(l) {
    l == null ? j.length = 0 : j.splice(l, 1);
  }
  i.addBand = xc, i.setBand = $c, i.delBand = Sc;
  function _c(l, u) {
    $[l].alpha = u, jt && he[l] != null && (he[l].style.opacity = u), Et && _t[l] && (_t[l].style.opacity = u);
  }
  let He, We, rs;
  const qs = { focus: !0 };
  function kc(l) {
    if (l != rs) {
      let u = l == null, p = Ee.alpha != 1;
      $.forEach((f, g) => {
        if (n == 1 || g > 0) {
          let y = u || g == 0 || g == l;
          f._focus = u ? null : y, p && _c(g, y ? 1 : Ee.alpha);
        }
      }), rs = l, p && Ls();
    }
  }
  Et && Ps && Bt(ol, ut, (l) => {
    H._lock || (ns(l), rs != null && Pe(null, qs, !0, Mt.setSeries));
  });
  function De(l, u, p) {
    let f = M[u];
    p && (l = l / ct - (f.ori == 1 ? Pt : gt));
    let g = Q;
    f.ori == 1 && (g = N, l = g - l), f.dir == -1 && (l = g - l);
    let y = f._min, S = f._max, A = l / g, T = y + (S - y) * A, C = f.distr;
    return C == 3 ? si(10, T) : C == 4 ? sp(T, f.asinh) : C == 100 ? f.bwd(T) : T;
  }
  function Ac(l, u) {
    let p = De(l, k, u);
    return ke(p, t[0], Nt, Rt);
  }
  i.valToIdx = (l) => ke(l, t[0]), i.posToIdx = Ac, i.posToVal = De, i.valToPos = (l, u, p) => M[u].ori == 0 ? o(
    l,
    M[u],
    p ? Qt : Q,
    p ? ee : 0
  ) : r(
    l,
    M[u],
    p ? ve : N,
    p ? ce : 0
  ), i.setCursor = (l, u, p) => {
    bt = l.left, St = l.top, ls(null, u, p);
  };
  function hr(l, u) {
    vt(Ks, Gs, yt.left = l), vt(Ks, Ti, yt.width = u);
  }
  function pr(l, u) {
    vt(Ks, ki, yt.top = l), vt(Ks, Ei, yt.height = u);
  }
  let bi = D.ori == 0 ? hr : pr, yi = D.ori == 1 ? hr : pr;
  function Mc() {
    if (Et && X.live)
      for (let l = n == 2 ? 1 : 0; l < $.length; l++) {
        if (l == 0 && ae)
          continue;
        let u = X.values[l], p = 0;
        for (let f in u)
          Me[l][p++].firstChild.nodeValue = u[f];
      }
  }
  function Wn(l, u) {
    if (l != null && (l.idxs ? l.idxs.forEach((p, f) => {
      pt[f] = p;
    }) : rp(l.idx) || pt.fill(l.idx), X.idx = pt[0]), Et && X.live) {
      for (let p = 0; p < $.length; p++)
        (p > 0 || n == 1 && !ae) && Tc(p, pt[p]);
      Mc();
    }
    ue = !1, u !== !1 && Ft("setLegend");
  }
  i.setLegend = Wn;
  function Tc(l, u) {
    let p = $[l], f = l == 0 && J == 2 ? $e : t[l], g;
    ae ? g = p.values(i, l, u) ?? Ie : (g = p.value(i, u == null ? null : f[u], l, u), g = g == null ? Ie : { _: g }), X.values[l] = g;
  }
  function ls(l, u, p) {
    cr = bt, ur = St, [bt, St] = H.move(i, bt, St), H.left = bt, H.top = St, jt && (Os && Ne(Os, Dt(bt), 0, Q, N), Fs && Ne(Fs, 0, Dt(St), Q, N));
    let f, g = Nt > Rt;
    He = ft, We = null;
    let y = D.ori == 0 ? Q : N, S = D.ori == 1 ? Q : N;
    if (bt < 0 || Ut == 0 || g) {
      f = H.idx = null;
      for (let A = 0; A < $.length; A++) {
        let T = he[A];
        T != null && Ne(T, -10, -10, Q, N);
      }
      Ps && Pe(null, qs, !0, l == null && Mt.setSeries), X.live && (pt.fill(f), ue = !0);
    } else {
      let A, T, C;
      n == 1 && (A = D.ori == 0 ? bt : St, T = De(A, k), f = H.idx = ke(T, t[0], Nt, Rt), C = F(t[0][f], D, y, 0));
      let z = -10, L = -10, Z = 0, at = 0, rt = !0, et = "", W = "";
      for (let U = n == 2 ? 1 : 0; U < $.length; U++) {
        let wt = $[U], kt = pt[U], Ht = kt == null ? null : n == 1 ? t[U][kt] : t[U][1][kt], dt = H.dataIdx(i, U, f, T), At = dt == null ? null : n == 1 ? t[U][dt] : t[U][1][dt];
        if (ue = ue || At != Ht || dt != kt, pt[U] = dt, U > 0 && wt.show) {
          let se = dt == null ? -10 : dt == f ? C : F(n == 1 ? t[0][dt] : t[U][0][dt], D, y, 0), Wt = At == null ? -10 : B(At, n == 1 ? M[wt.scale] : M[wt.facets[1].scale], S, 0);
          if (Ps && At != null) {
            let pe = D.ori == 1 ? bt : St, xe = Ct(Ee.dist(i, U, dt, Wt, pe));
            if (xe < He) {
              let Ce = Ee.bias;
              if (Ce != 0) {
                let ie = De(pe, wt.scale), de = At >= 0 ? 1 : -1, Se = ie >= 0 ? 1 : -1;
                Se == de && (Se == 1 ? Ce == 1 ? At >= ie : At <= ie : (
                  // >= 0
                  Ce == 1 ? At <= ie : At >= ie
                )) && (He = xe, We = U);
              } else
                He = xe, We = U;
            }
          }
          if (ue || Ds) {
            let pe, xe;
            D.ori == 0 ? (pe = se, xe = Wt) : (pe = Wt, xe = se);
            let Ce, ie, de, Se, ze, Gt, ne = !0, as = It.bbox;
            if (as != null) {
              ne = !1;
              let Yt = as(i, U);
              de = Yt.left, Se = Yt.top, Ce = Yt.width, ie = Yt.height;
            } else
              de = pe, Se = xe, Ce = ie = It.size(i, U);
            if (Gt = It.fill(i, U), ze = It.stroke(i, U), Ds)
              U == We && He <= Ee.prox && (z = de, L = Se, Z = Ce, at = ie, rt = ne, et = Gt, W = ze);
            else {
              let Yt = he[U];
              Yt != null && (Cs[U] = de, zs[U] = Se, pl(Yt, Ce, ie, ne), ul(Yt, Gt, ze), Ne(Yt, ye(de), ye(Se), Q, N));
            }
          }
        }
      }
      if (Ds) {
        let U = Ee.prox, wt = rs == null ? He <= U : He > U || We != rs;
        if (ue || wt) {
          let kt = he[0];
          kt != null && (Cs[0] = z, zs[0] = L, pl(kt, Z, at, rt), ul(kt, et, W), Ne(kt, ye(z), ye(L), Q, N));
        }
      }
    }
    if (yt.show && je)
      if (l != null) {
        let [A, T] = Mt.scales, [C, z] = Mt.match, [L, Z] = l.cursor.sync.scales, at = l.cursor.drag;
        if (Lt = at._x, Ot = at._y, Lt || Ot) {
          let { left: rt, top: et, width: W, height: U } = l.select, wt = l.scales[L].ori, kt = l.posToVal, Ht, dt, At, se, Wt, pe = A != null && C(A, L), xe = T != null && z(T, Z);
          pe && Lt ? (wt == 0 ? (Ht = rt, dt = W) : (Ht = et, dt = U), At = M[A], se = F(kt(Ht, L), At, y, 0), Wt = F(kt(Ht + dt, L), At, y, 0), bi(Ae(se, Wt), Ct(Wt - se))) : bi(0, y), xe && Ot ? (wt == 1 ? (Ht = rt, dt = W) : (Ht = et, dt = U), At = M[T], se = B(kt(Ht, Z), At, S, 0), Wt = B(kt(Ht + dt, Z), At, S, 0), yi(Ae(se, Wt), Ct(Wt - se))) : yi(0, S);
        } else
          Zn();
      } else {
        let A = Ct(cr - lr), T = Ct(ur - ar);
        if (D.ori == 1) {
          let Z = A;
          A = T, T = Z;
        }
        Lt = Kt.x && A >= Kt.dist, Ot = Kt.y && T >= Kt.dist;
        let C = Kt.uni;
        C != null ? Lt && Ot && (Lt = A >= C, Ot = T >= C, !Lt && !Ot && (T > A ? Ot = !0 : Lt = !0)) : Kt.x && Kt.y && (Lt || Ot) && (Lt = Ot = !0);
        let z, L;
        Lt && (D.ori == 0 ? (z = Hs, L = bt) : (z = Us, L = St), bi(Ae(z, L), Ct(L - z)), Ot || yi(0, S)), Ot && (D.ori == 1 ? (z = Hs, L = bt) : (z = Us, L = St), yi(Ae(z, L), Ct(L - z)), Lt || bi(0, y)), !Lt && !Ot && (bi(0, 0), yi(0, 0));
      }
    if (Kt._x = Lt, Kt._y = Ot, l == null) {
      if (p) {
        if (Sr != null) {
          let [A, T] = Mt.scales;
          Mt.values[0] = A != null ? De(D.ori == 0 ? bt : St, A) : null, Mt.values[1] = T != null ? De(D.ori == 1 ? bt : St, T) : null;
        }
        vi(oo, i, bt, St, Q, N, f);
      }
      if (Ps) {
        let A = p && Mt.setSeries, T = Ee.prox;
        rs == null ? He <= T && Pe(We, qs, !0, A) : He > T ? Pe(null, qs, !0, A) : We != rs && Pe(We, qs, !0, A);
      }
    }
    ue && (X.idx = f, Wn()), u !== !1 && Ft("setCursor");
  }
  let Ge = null;
  Object.defineProperty(i, "rect", {
    get() {
      return Ge == null && wi(!1), Ge;
    }
  });
  function wi(l = !1) {
    l ? Ge = null : (Ge = v.getBoundingClientRect(), Ft("syncRect", Ge));
  }
  function dr(l, u, p, f, g, y, S) {
    H._lock || je && l != null && l.movementX == 0 && l.movementY == 0 || (Gn(l, u, p, f, g, y, S, !1, l != null), l != null ? ls(null, !0, !0) : ls(u, !0, !1));
  }
  function Gn(l, u, p, f, g, y, S, A, T) {
    if (Ge == null && wi(!1), ns(l), l != null)
      p = l.clientX - Ge.left, f = l.clientY - Ge.top;
    else {
      if (p < 0 || f < 0) {
        bt = -10, St = -10;
        return;
      }
      let [C, z] = Mt.scales, L = u.cursor.sync, [Z, at] = L.values, [rt, et] = L.scales, [W, U] = Mt.match, wt = u.axes[0].side % 2 == 1, kt = D.ori == 0 ? Q : N, Ht = D.ori == 1 ? Q : N, dt = wt ? y : g, At = wt ? g : y, se = wt ? f : p, Wt = wt ? p : f;
      if (rt != null ? p = W(C, rt) ? c(Z, M[C], kt, 0) : -10 : p = kt * (se / dt), et != null ? f = U(z, et) ? c(at, M[z], Ht, 0) : -10 : f = Ht * (Wt / At), D.ori == 1) {
        let pe = p;
        p = f, f = pe;
      }
    }
    T && (u == null || u.cursor.event.type == oo) && ((p <= 1 || p >= Q - 1) && (p = ms(p, Q)), (f <= 1 || f >= N - 1) && (f = ms(f, N))), A ? (lr = p, ar = f, [Hs, Us] = H.move(i, p, f)) : (bt = p, St = f);
  }
  const Yn = {
    width: 0,
    height: 0,
    left: 0,
    top: 0
  };
  function Zn() {
    Zi(Yn, !1);
  }
  let fr, mr, gr, br;
  function yr(l, u, p, f, g, y, S) {
    je = !0, Lt = Ot = Kt._x = Kt._y = !1, Gn(l, u, p, f, g, y, S, !0, !1), l != null && (Bt(ro, yo, wr, !1), vi(il, i, Hs, Us, Q, N, null));
    let { left: A, top: T, width: C, height: z } = yt;
    fr = A, mr = T, gr = C, br = z;
  }
  function wr(l, u, p, f, g, y, S) {
    je = Kt._x = Kt._y = !1, Gn(l, u, p, f, g, y, S, !1, !0);
    let { left: A, top: T, width: C, height: z } = yt, L = C > 0 || z > 0, Z = fr != A || mr != T || gr != C || br != z;
    if (L && Z && Zi(yt), Kt.setScale && L && Z) {
      let at = A, rt = C, et = T, W = z;
      if (D.ori == 1 && (at = T, rt = z, et = A, W = C), Lt && Be(
        k,
        De(at, k),
        De(at + rt, k)
      ), Ot)
        for (let U in M) {
          let wt = M[U];
          U != k && wt.from == null && wt.min != ft && Be(
            U,
            De(et + W, U),
            De(et, U)
          );
        }
      Zn();
    } else H.lock && (H._lock = !H._lock, ls(u, !0, l != null));
    l != null && (Ms(ro, yo), vi(ro, i, bt, St, Q, N, null));
  }
  function Ec(l, u, p, f, g, y, S) {
    if (H._lock)
      return;
    ns(l);
    let A = je;
    if (je) {
      let T = !0, C = !0, z = 10, L, Z;
      D.ori == 0 ? (L = Lt, Z = Ot) : (L = Ot, Z = Lt), L && Z && (T = bt <= z || bt >= Q - z, C = St <= z || St >= N - z), L && T && (bt = bt < Hs ? 0 : Q), Z && C && (St = St < Us ? 0 : N), ls(null, !0, !0), je = !1;
    }
    bt = -10, St = -10, pt.fill(null), ls(null, !0, !0), A && (je = A);
  }
  function vr(l, u, p, f, g, y, S) {
    H._lock || (ns(l), Cn(), Zn(), l != null && vi(rl, i, bt, St, Q, N, null));
  }
  function $r() {
    P.forEach(xd), Dn(i.width, i.height, !0);
  }
  ws(gn, ti, $r);
  const Is = {};
  Is.mousedown = yr, Is.mousemove = dr, Is.mouseup = wr, Is.dblclick = vr, Is.setSeries = (l, u, p, f) => {
    let g = Mt.match[2];
    p = g(i, u, p), p != -1 && Pe(p, f, !0, !1);
  }, jt && (Bt(il, v, yr), Bt(oo, v, dr), Bt(nl, v, (l) => {
    ns(l), wi(!1);
  }), Bt(ol, v, Ec), Bt(rl, v, vr), Ao.add(i), i.syncRect = wi);
  const Ji = i.hooks = s.hooks || {};
  function Ft(l, u, p) {
    In ? gi.push([l, u, p]) : l in Ji && Ji[l].forEach((f) => {
      f.call(null, i, u, p);
    });
  }
  (s.plugins || []).forEach((l) => {
    for (let u in l.hooks)
      Ji[u] = (Ji[u] || []).concat(l.hooks[u]);
  });
  const xr = (l, u, p) => p, Mt = Tt({
    key: null,
    setSeries: !1,
    filters: {
      pub: bl,
      sub: bl
    },
    scales: [k, $[1] ? $[1].scale : null],
    match: [yl, yl, xr],
    values: [null, null]
  }, H.sync);
  Mt.match.length == 2 && Mt.match.push(xr), H.sync = Mt;
  const Sr = Mt.key, Jn = Va(Sr);
  function vi(l, u, p, f, g, y, S) {
    Mt.filters.pub(l, u, p, f, g, y, S) && Jn.pub(l, u, p, f, g, y, S);
  }
  Jn.sub(i);
  function Pc(l, u, p, f, g, y, S) {
    Mt.filters.sub(l, u, p, f, g, y, S) && Is[l](null, u, p, f, g, y, S);
  }
  i.pub = Pc;
  function Dc() {
    Jn.unsub(i), Ao.delete(i), Xe.clear(), $o(gn, ti, $r), h.remove(), ut?.remove(), Ft("destroy");
  }
  i.destroy = Dc;
  function Qn() {
    Ft("init", s, t), Xo(t || s.data, !1), q[k] ? Vn(k, q[k]) : Cn(), Vi = yt.show && (yt.width > 0 || yt.height > 0), is = ue = !0, Dn(s.width, s.height);
  }
  return $.forEach(Jo), P.forEach(cc), e ? e instanceof HTMLElement ? (e.appendChild(h), Qn()) : e(i, Qn) : Qn(), i;
}
Vt.assign = Tt;
Vt.fmtNum = Uo;
Vt.rangeNum = bn;
Vt.rangeLog = Sn;
Vt.rangeAsinh = Fo;
Vt.orient = _s;
Vt.pxRatio = ct;
Vt.join = dp;
Vt.fmtDate = qo, Vt.tzDate = _p;
Vt.sync = Va;
{
  Vt.addGap = rd, Vt.clipGaps = An;
  let s = Vt.paths = {
    points: Za
  };
  s.linear = Qa, s.stepped = cd, s.bars = ud, s.spline = pd;
}
const Sd = '.uplot,.uplot *,.uplot *:before,.uplot *:after{box-sizing:border-box}.uplot{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";line-height:1.5;width:min-content}.u-title{text-align:center;font-size:18px;font-weight:700}.u-wrap{position:relative;user-select:none}.u-over,.u-under{position:absolute}.u-under{overflow:hidden}.uplot canvas{display:block;position:relative;width:100%;height:100%}.u-axis{position:absolute}.u-legend{font-size:14px;margin:auto;text-align:center}.u-inline{display:block}.u-inline *{display:inline-block}.u-inline tr{margin-right:16px}.u-legend th{font-weight:600}.u-legend th>*{vertical-align:middle;display:inline-block}.u-legend .u-marker{width:1em;height:1em;margin-right:4px;background-clip:padding-box!important}.u-inline.u-live th:after{content:":";vertical-align:middle}.u-inline:not(.u-live) .u-value{display:none}.u-series>*{padding:4px}.u-series th{cursor:pointer}.u-legend .u-off>*{opacity:.3}.u-select{background:#00000012;position:absolute;pointer-events:none}.u-cursor-x,.u-cursor-y{position:absolute;left:0;top:0;pointer-events:none;will-change:transform}.u-hz .u-cursor-x,.u-vt .u-cursor-y{height:100%;border-right:1px dashed #607D8B}.u-hz .u-cursor-y,.u-vt .u-cursor-x{width:100%;border-bottom:1px dashed #607D8B}.u-cursor-pt{position:absolute;top:0;left:0;border-radius:50%;border:0 solid;pointer-events:none;will-change:transform;background-clip:padding-box!important}.u-axis.u-off,.u-select.u-off,.u-cursor-x.u-off,.u-cursor-y.u-off,.u-cursor-pt.u-off{display:none}';
function Ul(s, t) {
  let e = 0, i = s.length;
  for (; e < i; ) {
    const n = e + i >>> 1;
    s[n] < t ? e = n + 1 : i = n;
  }
  return e;
}
function _d(s, t, e, i, n) {
  const o = Math.max(0, Ul(s, e) - 1), r = Math.min(s.length, Ul(s, i) + 1), c = r - o;
  if (c <= n)
    return { x: s.slice(o, r), y: t.map((m) => m.slice(o, r)) };
  const a = Math.max(1, Math.floor(n / 2)), h = c / a, b = new Float64Array(a * 2), d = t.map(() => new Float64Array(a * 2));
  for (let m = 0; m < a; m++) {
    const w = o + Math.floor(m * h), v = Math.min(r, o + Math.floor((m + 1) * h)), _ = Math.max(w, v - 1);
    b[2 * m] = s[w], b[2 * m + 1] = s[w + (_ - w >> 1)], t.forEach((x, E) => {
      let $ = 1 / 0, P = -1 / 0, M = w, j = w;
      for (let O = w; O <= _; O++) {
        const R = x[O];
        Number.isNaN(R) || (R < $ && ($ = R, M = O), R > P && (P = R, j = O));
      }
      const k = d[E];
      $ === 1 / 0 ? (k[2 * m] = Number.NaN, k[2 * m + 1] = Number.NaN) : M <= j ? (k[2 * m] = $, k[2 * m + 1] = P) : (k[2 * m] = P, k[2 * m + 1] = $);
    });
  }
  return { x: b, y: d };
}
const kd = 0.25, Kl = 300;
function Ad(s) {
  return (Math.abs(s.deltaY) >= Math.abs(s.deltaX) ? s.deltaY : s.deltaX) * (s.deltaMode === 1 ? 40 : s.deltaMode === 2 ? 800 : 1);
}
function Md(s, t, e, i, n) {
  const o = Math.exp(Math.max(-Kl, Math.min(Kl, e)) / 100 * kd), r = i.max - i.min, c = Math.min(r, Math.max(Math.min(n, r), (s.max - s.min) * o)), a = s.max > s.min ? (t - s.min) / (s.max - s.min) : 0.5;
  let h = t - a * c, b = h + c;
  return h < i.min && (h = i.min, b = h + c), b > i.max && (b = i.max, h = b - c), { min: h, max: b };
}
const me = 16, ho = 12, ql = 12, Il = 18, un = 12;
function Td(s, t, e) {
  const i = [[]];
  let n = 0;
  for (const o of s) {
    const r = un + 6 + e(o.label);
    n > 0 && n + r > t && (i.push([]), n = 0), i[i.length - 1].push({ item: o, x: n, width: r }), n += r + 16;
  }
  return i;
}
function Vl(s, t, e) {
  if (e) return e(s, t);
  const i = document.createElement("canvas");
  return i.width = s, i.height = t, i;
}
async function Ed(s) {
  if (s.rows.length === 0) throw new Error("Nothing to draw");
  const { pxRatio: t, colors: e } = s, i = Math.max(...s.rows.map((w) => w.cssWidth)) + me * 2, n = Vl(1, 1, s.createCanvas).getContext("2d");
  n.font = `${ql}px ${s.fontFamily}`;
  const o = (w) => n.measureText(w).width, r = s.rows.map((w) => ({ row: w, lines: Td(w.legend, i - me * 2, o) })), c = me + 22 + 18 + ho, a = (w, v) => 18 + w.cssHeight + v * Il + ho, h = c + r.reduce((w, v) => w + a(v.row, v.lines.length), 0) + me, b = Vl(Math.round(i * t), Math.round(h * t), s.createCanvas), d = b.getContext("2d");
  d.scale(t, t), d.fillStyle = e.background, d.fillRect(0, 0, i, h), d.textBaseline = "top", d.fillStyle = e.text, d.font = `600 16px ${s.fontFamily}`, d.fillText(s.title, me, me), d.fillStyle = e.muted, d.font = `12px ${s.fontFamily}`, d.fillText(s.subtitle, me, me + 22);
  let m = c;
  for (const { row: w, lines: v } of r) {
    d.fillStyle = e.text, d.font = `600 13px ${s.fontFamily}`, d.fillText(w.title, me, m), m += 18, d.drawImage(w.canvas, me, m, w.cssWidth, w.cssHeight), m += w.cssHeight, d.font = `${ql}px ${s.fontFamily}`;
    for (const _ of v) {
      for (const { item: x, x: E } of _)
        d.fillStyle = x.color, d.fillRect(me + E, m + 3, un, un), d.fillStyle = e.text, d.fillText(x.label, me + E + un + 6, m + 2);
      m += Il;
    }
    m += ho;
  }
  return "convertToBlob" in b ? b.convertToBlob({ type: "image/png" }) : new Promise((w, v) => {
    b.toBlob((_) => _ ? w(_) : v(new Error("The browser could not encode the PNG")), "image/png");
  });
}
const Pd = "tessera-motion-diag", jl = 260;
function Dd(s) {
  const t = s.trim();
  let e = /^#([0-9a-f]{3})$/i.exec(t);
  return e ? [...e[1]].map((i) => parseInt(i + i, 16)) : (e = /^#([0-9a-f]{6})/i.exec(t), e ? [0, 2, 4].map((i) => parseInt(e[1].slice(i, i + 2), 16)) : (e = /^rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)/i.exec(t), e ? [Number(e[1]), Number(e[2]), Number(e[3])] : null));
}
function Bl(s, t) {
  const e = Dd(s);
  return e ? `rgba(${e[0]}, ${e[1]}, ${e[2]}, ${t})` : s;
}
class Cd extends xs {
  static styles = [
    ci,
    Yl(Sd),
    ri`
      .chart {
        inline-size: 100%;
        min-inline-size: 0;
      }
      .u-legend {
        font-size: var(--font-size-sm);
        text-align: start;
      }
      .u-legend .u-marker {
        inline-size: 14px;
      }
      /* Legend values are numbers: keep them left-to-right in any UI direction. */
      .u-legend .u-value {
        direction: ltr;
        unicode-bidi: isolate;
      }
      .failed {
        display: flex;
        flex-wrap: wrap;
        gap: var(--space-xs);
      }
    `
  ];
  #t = /* @__PURE__ */ new Map();
  #e = null;
  #s = "";
  attachApi(t) {
    super.attachApi(t), this.track(t.onThemeChange(() => this.#i(!0)));
  }
  connectedCallback() {
    super.connectedCallback(), this.#e = new ResizeObserver(() => this.#o()), this.#e.observe(this);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.#e?.disconnect(), this.#e = null, this.#i(!1);
  }
  #i(t) {
    for (const e of this.#t.values()) e.plot.destroy();
    this.#t.clear(), t && this.requestUpdate();
  }
  #o() {
    for (const [t, e] of this.#t) {
      const i = this.renderRoot.querySelector(`[data-row="${t}"]`);
      i && i.clientWidth > 0 && e.plot.setSize({ width: i.clientWidth, height: jl });
    }
  }
  render() {
    const t = this.store;
    if (!t) return tt;
    const e = t.state;
    if (!e.capture) return tt;
    const i = e.computed;
    return I`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title">${this.t("motiondiag.graphs.chartsTitle")}</span>
          ${e.outdated && i ? I`<span class="chip">${this.t("motiondiag.graphs.outdated")}</span>` : tt}
        </div>
        <div class="panel-body">
          ${e.computeError ? I`<p class="error">${e.computeError}</p>` : tt}
          ${!i && !e.computeError ? I`<p class="muted">${this.t("motiondiag.graphs.notBuilt")}</p>` : tt}
          ${i ? oa(
      e.graphs.rows,
      (n) => n.id,
      (n, o) => I`
                  <div>
                    <div class="row">
                      <strong>${this.t("motiondiag.graphs.rowTitle", { n: o + 1 })}</strong>
                      <span class="failed">
                        ${n.series.filter((r) => i.errors.has(r.name)).map((r) => I`<span class="chip bad ltr" title=${i.errors.get(r.name)}>${r.name}: ${i.errors.get(r.name)}</span>`)}
                      </span>
                    </div>
                    <div class="chart" data-row=${n.id}></div>
                  </div>
                `
    ) : tt}
        </div>
      </section>
    `;
  }
  updated(t) {
    const e = this.store?.state, i = e?.computed;
    if (!e || !i) {
      this.#i(!1);
      return;
    }
    const n = getComputedStyle(this).getPropertyValue("--bg-surface");
    n !== this.#s && (this.#s = n, this.#i(!1));
    const o = new Set(e.graphs.rows.map((r) => r.id));
    for (const [r, c] of this.#t)
      o.has(r) || (c.plot.destroy(), this.#t.delete(r));
    e.graphs.rows.forEach((r) => {
      const c = this.renderRoot.querySelector(`[data-row="${r.id}"]`);
      if (!c) return;
      const a = JSON.stringify([r.series, i.data.times.length, i.window]) + String(i.data.series.size), h = this.#t.get(r.id);
      if (h && h.signature === a && h.plot.root.parentElement === c) return;
      h?.plot.destroy(), this.#t.delete(r.id);
      const b = this.#l(c, r);
      b && this.#t.set(r.id, { ...b, signature: a });
    });
  }
  /** Whether there is at least one chart to put into a picture. */
  get canExportPng() {
    return this.#t.size > 0;
  }
  /**
   * All charts as one PNG, as they are on screen (a zoom is kept), with titles and legends.
   * `rowTitle(n)` names the n-th graph (1-based) in the picture's language.
   */
  exportPng(t, e, i) {
    const n = [];
    this.store.state.graphs.rows.forEach((r, c) => {
      const a = this.#t.get(r.id), h = a?.plot.root.querySelector("canvas");
      !a || !h || n.push({
        title: i(c + 1),
        canvas: h,
        cssWidth: a.plot.width,
        cssHeight: a.plot.height,
        legend: a.legend
      });
    });
    const o = getComputedStyle(this);
    return Ed({
      title: t,
      subtitle: e,
      rows: n,
      pxRatio: n[0] ? n[0].canvas.width / n[0].cssWidth : 1,
      colors: {
        background: this.#n("--bg-surface", "#ffffff"),
        text: this.#n("--text-primary", "#1a1a1a"),
        muted: this.#n("--text-muted", "#888888")
      },
      fontFamily: o.fontFamily || "sans-serif"
    });
  }
  #n(t, e) {
    return getComputedStyle(this).getPropertyValue(t).trim() || e;
  }
  /** A series color: a theme token (`var(--accent)`), a literal, or the palette entry for its index. */
  #r(t, e) {
    const i = t || `var(${zi[e % zi.length]})`, n = /^var\((--[\w-]+)\)$/.exec(i);
    return n ? this.#n(n[1], "#888") : i;
  }
  #l(t, e) {
    const i = this.store.state.computed, { times: n, series: o, labels: r } = i.data, c = e.series.filter((k) => o.has(k.name));
    if (c.length === 0 || n.length === 0) return null;
    const a = c.map((k) => o.get(k.name)), h = c.map((k) => r.get(k.name)), b = vu(h), d = Math.max(t.clientWidth, 240), m = Math.max(600, d * 2), w = n[0], v = n[n.length - 1], _ = this.#n("--text-muted", "#888"), x = this.#n("--border-color", "#8884"), E = (k) => k.replace(/\n/g, " "), $ = (k, O) => {
      const R = _d(n, a, k, O, m);
      return [R.x, ...R.y];
    };
    let P = !1;
    const M = {
      width: d,
      height: jl,
      scales: {
        x: { time: !1, range: (k, O, R) => [O, R] },
        y: {},
        y2: {}
      },
      axes: [
        { stroke: _, grid: { stroke: x, width: 1 }, ticks: { stroke: x }, label: this.t("motiondiag.graphs.time") },
        { scale: "y", stroke: _, grid: { stroke: x, width: 1 }, ticks: { stroke: x }, label: E(b.left), size: 70 },
        ...b.right !== null ? [{ scale: "y2", side: 1, stroke: _, grid: { show: !1 }, ticks: { stroke: x }, label: E(b.right), size: 70 }] : []
      ],
      series: [
        {},
        ...c.map((k, O) => ({
          label: h[O].label,
          scale: b.sides[O] === "right" ? "y2" : "y",
          stroke: Bl(this.#r(k.color, O), k.alpha),
          width: 1.2,
          points: { show: !1 },
          spanGaps: !1
        }))
      ],
      cursor: { sync: { key: Pd, scales: ["x", null] }, drag: { x: !0, y: !1 } },
      legend: { live: !0 },
      hooks: {
        // Shift + wheel zooms the time axis around the cursor, in all rows together. Plain
        // wheel is left alone so that the page still scrolls.
        ready: [
          (k) => {
            k.over.addEventListener(
              "wheel",
              (O) => {
                if (!O.shiftKey) return;
                O.preventDefault();
                const { min: R, max: G } = k.scales.x ?? {};
                if (R == null || G == null) return;
                const Y = k.posToVal(O.clientX - k.over.getBoundingClientRect().left, "x"), D = Math.max((v - w) / n.length * 20, 1e-9), J = Md({ min: R, max: G }, Y, Ad(O), { min: w, max: v }, D), F = [k, ...[...this.#t.values()].map((B) => B.plot).filter((B) => B !== k)];
                for (const B of F) B.setScale("x", J);
              },
              { passive: !1 }
            );
          }
        ],
        setScale: [
          (k, O) => {
            if (O !== "x" || P) return;
            const { min: R, max: G } = k.scales.x ?? {};
            R == null || G == null || (P = !0, k.setData($(R, G), !1), P = !1);
          }
        ]
      }
    }, j = c.map((k, O) => ({ color: Bl(this.#r(k.color, O), 1), label: h[O].label }));
    return { plot: new Vt(M, $(w, v), t), legend: j };
  }
}
function po(s, t) {
  const e = URL.createObjectURL(s), i = document.createElement("a");
  i.href = e, i.download = t, i.style.display = "none", document.body.append(i), i.click(), i.remove(), setTimeout(() => URL.revokeObjectURL(e), 1e4);
}
function zd(s, t = /* @__PURE__ */ new Date()) {
  const e = s.normalize("NFKD").replace(/[^\w.-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40), i = (o) => String(o).padStart(2, "0"), n = `${t.getFullYear()}${i(t.getMonth() + 1)}${i(t.getDate())}-${i(t.getHours())}${i(t.getMinutes())}${i(t.getSeconds())}`;
  return ["motion-diag", e, n].filter(Boolean).join("-");
}
class Nd extends xs {
  static styles = [ci];
  static properties = {
    ...xs.properties,
    busy: { state: !0 }
  };
  constructor() {
    super(), this.busy = !1;
  }
  #t() {
    return zd(this.api?.printer.name ?? "");
  }
  async #e() {
    this.busy = !0;
    try {
      const t = await this.store.exportMotan("dump");
      t && po(t, `${this.#t()}.tar.gz`);
    } finally {
      this.busy = !1;
    }
  }
  /** The charts element next to us in the tab. */
  #s() {
    return this.getRootNode().querySelector("tessera-md-graphs");
  }
  async #i() {
    const t = this.#s(), e = this.store.state;
    if (t?.canExportPng) {
      this.busy = !0;
      try {
        const i = e.computed?.window ?? e.window, n = +(i.segmentTime * 1e3).toFixed(4), o = `${this.t("motiondiag.tabTitle")} - ${this.api?.printer.name ?? ""}`.replace(/ - $/, ""), r = this.t("motiondiag.save.pngSubtitle", {
          date: (/* @__PURE__ */ new Date()).toLocaleString(this.api?.i18n.locale),
          from: i.skip,
          len: i.duration,
          step: n
        }), c = await t.exportPng(o, r, (a) => this.t("motiondiag.graphs.rowTitle", { n: a }));
        po(c, `${this.#t()}.png`);
      } finally {
        this.busy = !1;
      }
    }
  }
  #o() {
    const t = this.store.exportCsv();
    t && po(new Blob([t], { type: "text/csv;charset=utf-8" }), `${this.#t()}.csv`);
  }
  render() {
    const t = this.store, e = t?.state;
    return !t || !e?.capture ? tt : I`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title">${this.t("motiondiag.save.title")}</span>
        </div>
        <div class="panel-body">
          <div class="row">
            <button ?disabled=${this.busy} @click=${() => void this.#e()}>${this.t("motiondiag.save.motan")}</button>
            <span class="muted grow">${this.t("motiondiag.save.motanHint")}</span>
          </div>
          <div class="row">
            <button ?disabled=${!e.computed || this.busy} @click=${() => void this.#i()}>${this.t("motiondiag.save.png")}</button>
            <span class="muted grow">${this.t(e.computed ? "motiondiag.save.pngHint" : "motiondiag.save.csvNeedsGraphs")}</span>
          </div>
          <div class="row">
            <button ?disabled=${!e.computed} @click=${() => this.#o()}>${this.t("motiondiag.save.csv")}</button>
            <span class="muted grow">${this.t(e.computed ? "motiondiag.save.csvHint" : "motiondiag.save.csvNeedsGraphs")}</span>
          </div>
        </div>
      </section>
    `;
  }
}
let Wl = null;
function Rd(s) {
  return Wl ??= new mn(() => s.moonraker()), Wl;
}
class Ld extends pn {
  static styles = [
    ci,
    ri`
      details > summary {
        cursor: pointer;
        color: var(--text-secondary);
        font-size: var(--font-size-sm);
      }
      details ul {
        margin: var(--space-xs) 0 0;
        padding-inline-start: var(--space-lg);
        color: var(--text-secondary);
        font-size: var(--font-size-sm);
      }
    `
  ];
  static properties = {
    ...pn.properties,
    store: { state: !0 }
  };
  constructor() {
    super(), this.store = null;
  }
  attachApi(t) {
    super.attachApi(t);
    const e = Rd(t);
    e.bindPrinter(t.printer.id), this.store = e, this.track(t.onPrinterChange((i) => e.bindPrinter(i.id)));
  }
  render() {
    const { api: t, store: e } = this;
    return !t || !e ? I`` : I`
      <details>
        <summary>${this.t("motiondiag.help.title")}</summary>
        <ul>
          <li>${this.t("motiondiag.help.record")}</li>
          <li>${this.t("motiondiag.help.graphs")}</li>
          <li>${this.t("motiondiag.help.bridge")}</li>
        </ul>
      </details>
      <tessera-md-capture .api=${t} .store=${e}></tessera-md-capture>
      <tessera-md-graphs-panel .api=${t} .store=${e}></tessera-md-graphs-panel>
      <tessera-md-graphs .api=${t} .store=${e}></tessera-md-graphs>
      <tessera-md-save .api=${t} .store=${e}></tessera-md-save>
      <tessera-md-dataset-dialog .api=${t} .store=${e}></tessera-md-dataset-dialog>
    `;
  }
}
ai("tessera-motion-diag-tab", Ld);
ai("tessera-md-capture", nu);
ai("tessera-md-graphs-panel", Mh);
ai("tessera-md-graphs", Cd);
ai("tessera-md-save", Nd);
ai("tessera-md-dataset-dialog", uu);
const Kd = { en: tu, ru: eu };
export {
  Kd as locales
};
