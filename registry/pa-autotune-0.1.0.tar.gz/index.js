/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const O = globalThis, j = O.ShadowRoot && (O.ShadyCSS === void 0 || O.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, B = Symbol(), G = /* @__PURE__ */ new WeakMap();
let ot = class {
  constructor(t, e, s) {
    if (this._$cssResult$ = !0, s !== B) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t, this.t = e;
  }
  get styleSheet() {
    let t = this.o;
    const e = this.t;
    if (j && t === void 0) {
      const s = e !== void 0 && e.length === 1;
      s && (t = G.get(e)), t === void 0 && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), s && G.set(e, t));
    }
    return t;
  }
  toString() {
    return this.cssText;
  }
};
const mt = (i) => new ot(typeof i == "string" ? i : i + "", void 0, B), $t = (i, ...t) => {
  const e = i.length === 1 ? i[0] : t.reduce((s, r, n) => s + ((o) => {
    if (o._$cssResult$ === !0) return o.cssText;
    if (typeof o == "number") return o;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + o + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(r) + i[n + 1], i[0]);
  return new ot(e, i, B);
}, vt = (i, t) => {
  if (j) i.adoptedStyleSheets = t.map((e) => e instanceof CSSStyleSheet ? e : e.styleSheet);
  else for (const e of t) {
    const s = document.createElement("style"), r = O.litNonce;
    r !== void 0 && s.setAttribute("nonce", r), s.textContent = e.cssText, i.appendChild(s);
  }
}, J = j ? (i) => i : (i) => i instanceof CSSStyleSheet ? ((t) => {
  let e = "";
  for (const s of t.cssRules) e += s.cssText;
  return mt(e);
})(i) : i;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: gt, defineProperty: bt, getOwnPropertyDescriptor: yt, getOwnPropertyNames: _t, getOwnPropertySymbols: At, getPrototypeOf: wt } = Object, M = globalThis, Z = M.trustedTypes, Et = Z ? Z.emptyScript : "", Pt = M.reactiveElementPolyfillSupport, x = (i, t) => i, D = { toAttribute(i, t) {
  switch (t) {
    case Boolean:
      i = i ? Et : null;
      break;
    case Object:
    case Array:
      i = i == null ? i : JSON.stringify(i);
  }
  return i;
}, fromAttribute(i, t) {
  let e = i;
  switch (t) {
    case Boolean:
      e = i !== null;
      break;
    case Number:
      e = i === null ? null : Number(i);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(i);
      } catch {
        e = null;
      }
  }
  return e;
} }, at = (i, t) => !gt(i, t), X = { attribute: !0, type: String, converter: D, reflect: !1, useDefault: !1, hasChanged: at };
Symbol.metadata ??= Symbol("metadata"), M.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
let y = class extends HTMLElement {
  static addInitializer(t) {
    this._$Ei(), (this.l ??= []).push(t);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(t, e = X) {
    if (e.state && (e.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(t) && ((e = Object.create(e)).wrapped = !0), this.elementProperties.set(t, e), !e.noAccessor) {
      const s = Symbol(), r = this.getPropertyDescriptor(t, s, e);
      r !== void 0 && bt(this.prototype, t, r);
    }
  }
  static getPropertyDescriptor(t, e, s) {
    const { get: r, set: n } = yt(this.prototype, t) ?? { get() {
      return this[e];
    }, set(o) {
      this[e] = o;
    } };
    return { get: r, set(o) {
      const h = r?.call(this);
      n?.call(this, o), this.requestUpdate(t, h, s);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(t) {
    return this.elementProperties.get(t) ?? X;
  }
  static _$Ei() {
    if (this.hasOwnProperty(x("elementProperties"))) return;
    const t = wt(this);
    t.finalize(), t.l !== void 0 && (this.l = [...t.l]), this.elementProperties = new Map(t.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(x("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(x("properties"))) {
      const e = this.properties, s = [..._t(e), ...At(e)];
      for (const r of s) this.createProperty(r, e[r]);
    }
    const t = this[Symbol.metadata];
    if (t !== null) {
      const e = litPropertyMetadata.get(t);
      if (e !== void 0) for (const [s, r] of e) this.elementProperties.set(s, r);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [e, s] of this.elementProperties) {
      const r = this._$Eu(e, s);
      r !== void 0 && this._$Eh.set(r, e);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(t) {
    const e = [];
    if (Array.isArray(t)) {
      const s = new Set(t.flat(1 / 0).reverse());
      for (const r of s) e.unshift(J(r));
    } else t !== void 0 && e.push(J(t));
    return e;
  }
  static _$Eu(t, e) {
    const s = e.attribute;
    return s === !1 ? void 0 : typeof s == "string" ? s : typeof t == "string" ? t.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise((t) => this.enableUpdating = t), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((t) => t(this));
  }
  addController(t) {
    (this._$EO ??= /* @__PURE__ */ new Set()).add(t), this.renderRoot !== void 0 && this.isConnected && t.hostConnected?.();
  }
  removeController(t) {
    this._$EO?.delete(t);
  }
  _$E_() {
    const t = /* @__PURE__ */ new Map(), e = this.constructor.elementProperties;
    for (const s of e.keys()) this.hasOwnProperty(s) && (t.set(s, this[s]), delete this[s]);
    t.size > 0 && (this._$Ep = t);
  }
  createRenderRoot() {
    const t = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return vt(t, this.constructor.elementStyles), t;
  }
  connectedCallback() {
    this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$EO?.forEach((t) => t.hostConnected?.());
  }
  enableUpdating(t) {
  }
  disconnectedCallback() {
    this._$EO?.forEach((t) => t.hostDisconnected?.());
  }
  attributeChangedCallback(t, e, s) {
    this._$AK(t, s);
  }
  _$ET(t, e) {
    const s = this.constructor.elementProperties.get(t), r = this.constructor._$Eu(t, s);
    if (r !== void 0 && s.reflect === !0) {
      const n = (s.converter?.toAttribute !== void 0 ? s.converter : D).toAttribute(e, s.type);
      this._$Em = t, n == null ? this.removeAttribute(r) : this.setAttribute(r, n), this._$Em = null;
    }
  }
  _$AK(t, e) {
    const s = this.constructor, r = s._$Eh.get(t);
    if (r !== void 0 && this._$Em !== r) {
      const n = s.getPropertyOptions(r), o = typeof n.converter == "function" ? { fromAttribute: n.converter } : n.converter?.fromAttribute !== void 0 ? n.converter : D;
      this._$Em = r;
      const h = o.fromAttribute(e, n.type);
      this[r] = h ?? this._$Ej?.get(r) ?? h, this._$Em = null;
    }
  }
  requestUpdate(t, e, s, r = !1, n) {
    if (t !== void 0) {
      const o = this.constructor;
      if (r === !1 && (n = this[t]), s ??= o.getPropertyOptions(t), !((s.hasChanged ?? at)(n, e) || s.useDefault && s.reflect && n === this._$Ej?.get(t) && !this.hasAttribute(o._$Eu(t, s)))) return;
      this.C(t, e, s);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(t, e, { useDefault: s, reflect: r, wrapped: n }, o) {
    s && !(this._$Ej ??= /* @__PURE__ */ new Map()).has(t) && (this._$Ej.set(t, o ?? e ?? this[t]), n !== !0 || o !== void 0) || (this._$AL.has(t) || (this.hasUpdated || s || (e = void 0), this._$AL.set(t, e)), r === !0 && this._$Em !== t && (this._$Eq ??= /* @__PURE__ */ new Set()).add(t));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (e) {
      Promise.reject(e);
    }
    const t = this.scheduleUpdate();
    return t != null && await t, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
        for (const [r, n] of this._$Ep) this[r] = n;
        this._$Ep = void 0;
      }
      const s = this.constructor.elementProperties;
      if (s.size > 0) for (const [r, n] of s) {
        const { wrapped: o } = n, h = this[r];
        o !== !0 || this._$AL.has(r) || h === void 0 || this.C(r, void 0, n, h);
      }
    }
    let t = !1;
    const e = this._$AL;
    try {
      t = this.shouldUpdate(e), t ? (this.willUpdate(e), this._$EO?.forEach((s) => s.hostUpdate?.()), this.update(e)) : this._$EM();
    } catch (s) {
      throw t = !1, this._$EM(), s;
    }
    t && this._$AE(e);
  }
  willUpdate(t) {
  }
  _$AE(t) {
    this._$EO?.forEach((e) => e.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(t) {
    return !0;
  }
  update(t) {
    this._$Eq &&= this._$Eq.forEach((e) => this._$ET(e, this[e])), this._$EM();
  }
  updated(t) {
  }
  firstUpdated(t) {
  }
};
y.elementStyles = [], y.shadowRootOptions = { mode: "open" }, y[x("elementProperties")] = /* @__PURE__ */ new Map(), y[x("finalized")] = /* @__PURE__ */ new Map(), Pt?.({ ReactiveElement: y }), (M.reactiveElementVersions ??= []).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const W = globalThis, Y = (i) => i, I = W.trustedTypes, Q = I ? I.createPolicy("lit-html", { createHTML: (i) => i }) : void 0, lt = "$lit$", $ = `lit$${Math.random().toFixed(9).slice(2)}$`, ct = "?" + $, xt = `<${ct}>`, b = document, T = () => b.createComment(""), S = (i) => i === null || typeof i != "object" && typeof i != "function", q = Array.isArray, kt = (i) => q(i) || typeof i?.[Symbol.iterator] == "function", z = `[ 	
\f\r]`, E = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, tt = /-->/g, et = />/g, v = RegExp(`>|${z}(?:([^\\s"'>=/]+)(${z}*=${z}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), st = /'/g, it = /"/g, ht = /^(?:script|style|textarea|title)$/i, Tt = (i) => (t, ...e) => ({ _$litType$: i, strings: t, values: e }), d = Tt(1), _ = Symbol.for("lit-noChange"), l = Symbol.for("lit-nothing"), rt = /* @__PURE__ */ new WeakMap(), g = b.createTreeWalker(b, 129);
function dt(i, t) {
  if (!q(i) || !i.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return Q !== void 0 ? Q.createHTML(t) : t;
}
const St = (i, t) => {
  const e = i.length - 1, s = [];
  let r, n = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", o = E;
  for (let h = 0; h < e; h++) {
    const a = i[h];
    let p, u, c = -1, f = 0;
    for (; f < a.length && (o.lastIndex = f, u = o.exec(a), u !== null); ) f = o.lastIndex, o === E ? u[1] === "!--" ? o = tt : u[1] !== void 0 ? o = et : u[2] !== void 0 ? (ht.test(u[2]) && (r = RegExp("</" + u[2], "g")), o = v) : u[3] !== void 0 && (o = v) : o === v ? u[0] === ">" ? (o = r ?? E, c = -1) : u[1] === void 0 ? c = -2 : (c = o.lastIndex - u[2].length, p = u[1], o = u[3] === void 0 ? v : u[3] === '"' ? it : st) : o === it || o === st ? o = v : o === tt || o === et ? o = E : (o = v, r = void 0);
    const m = o === v && i[h + 1].startsWith("/>") ? " " : "";
    n += o === E ? a + xt : c >= 0 ? (s.push(p), a.slice(0, c) + lt + a.slice(c) + $ + m) : a + $ + (c === -2 ? h : m);
  }
  return [dt(i, n + (i[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), s];
};
class C {
  constructor({ strings: t, _$litType$: e }, s) {
    let r;
    this.parts = [];
    let n = 0, o = 0;
    const h = t.length - 1, a = this.parts, [p, u] = St(t, e);
    if (this.el = C.createElement(p, s), g.currentNode = this.el.content, e === 2 || e === 3) {
      const c = this.el.content.firstChild;
      c.replaceWith(...c.childNodes);
    }
    for (; (r = g.nextNode()) !== null && a.length < h; ) {
      if (r.nodeType === 1) {
        if (r.hasAttributes()) for (const c of r.getAttributeNames()) if (c.endsWith(lt)) {
          const f = u[o++], m = r.getAttribute(c).split($), R = /([.?@])?(.*)/.exec(f);
          a.push({ type: 1, index: n, name: R[2], strings: m, ctor: R[1] === "." ? Ut : R[1] === "?" ? Rt : R[1] === "@" ? Ot : H }), r.removeAttribute(c);
        } else c.startsWith($) && (a.push({ type: 6, index: n }), r.removeAttribute(c));
        if (ht.test(r.tagName)) {
          const c = r.textContent.split($), f = c.length - 1;
          if (f > 0) {
            r.textContent = I ? I.emptyScript : "";
            for (let m = 0; m < f; m++) r.append(c[m], T()), g.nextNode(), a.push({ type: 2, index: ++n });
            r.append(c[f], T());
          }
        }
      } else if (r.nodeType === 8) if (r.data === ct) a.push({ type: 2, index: n });
      else {
        let c = -1;
        for (; (c = r.data.indexOf($, c + 1)) !== -1; ) a.push({ type: 7, index: n }), c += $.length - 1;
      }
      n++;
    }
  }
  static createElement(t, e) {
    const s = b.createElement("template");
    return s.innerHTML = t, s;
  }
}
function A(i, t, e = i, s) {
  if (t === _) return t;
  let r = s !== void 0 ? e._$Co?.[s] : e._$Cl;
  const n = S(t) ? void 0 : t._$litDirective$;
  return r?.constructor !== n && (r?._$AO?.(!1), n === void 0 ? r = void 0 : (r = new n(i), r._$AT(i, e, s)), s !== void 0 ? (e._$Co ??= [])[s] = r : e._$Cl = r), r !== void 0 && (t = A(i, r._$AS(i, t.values), r, s)), t;
}
class Ct {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: s } = this._$AD, r = (t?.creationScope ?? b).importNode(e, !0);
    g.currentNode = r;
    let n = g.nextNode(), o = 0, h = 0, a = s[0];
    for (; a !== void 0; ) {
      if (o === a.index) {
        let p;
        a.type === 2 ? p = new U(n, n.nextSibling, this, t) : a.type === 1 ? p = new a.ctor(n, a.name, a.strings, this, t) : a.type === 6 && (p = new Nt(n, this, t)), this._$AV.push(p), a = s[++h];
      }
      o !== a?.index && (n = g.nextNode(), o++);
    }
    return g.currentNode = b, r;
  }
  p(t) {
    let e = 0;
    for (const s of this._$AV) s !== void 0 && (s.strings !== void 0 ? (s._$AI(t, s, e), e += s.strings.length - 2) : s._$AI(t[e])), e++;
  }
}
class U {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(t, e, s, r) {
    this.type = 2, this._$AH = l, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = s, this.options = r, this._$Cv = r?.isConnected ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && t?.nodeType === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = A(this, t, e), S(t) ? t === l || t == null || t === "" ? (this._$AH !== l && this._$AR(), this._$AH = l) : t !== this._$AH && t !== _ && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : kt(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== l && S(this._$AH) ? this._$AA.nextSibling.data = t : this.T(b.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    const { values: e, _$litType$: s } = t, r = typeof s == "number" ? this._$AC(t) : (s.el === void 0 && (s.el = C.createElement(dt(s.h, s.h[0]), this.options)), s);
    if (this._$AH?._$AD === r) this._$AH.p(e);
    else {
      const n = new Ct(r, this), o = n.u(this.options);
      n.p(e), this.T(o), this._$AH = n;
    }
  }
  _$AC(t) {
    let e = rt.get(t.strings);
    return e === void 0 && rt.set(t.strings, e = new C(t)), e;
  }
  k(t) {
    q(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let s, r = 0;
    for (const n of t) r === e.length ? e.push(s = new U(this.O(T()), this.O(T()), this, this.options)) : s = e[r], s._$AI(n), r++;
    r < e.length && (this._$AR(s && s._$AB.nextSibling, r), e.length = r);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    for (this._$AP?.(!1, !0, e); t !== this._$AB; ) {
      const s = Y(t).nextSibling;
      Y(t).remove(), t = s;
    }
  }
  setConnected(t) {
    this._$AM === void 0 && (this._$Cv = t, this._$AP?.(t));
  }
}
class H {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, s, r, n) {
    this.type = 1, this._$AH = l, this._$AN = void 0, this.element = t, this.name = e, this._$AM = r, this.options = n, s.length > 2 || s[0] !== "" || s[1] !== "" ? (this._$AH = Array(s.length - 1).fill(new String()), this.strings = s) : this._$AH = l;
  }
  _$AI(t, e = this, s, r) {
    const n = this.strings;
    let o = !1;
    if (n === void 0) t = A(this, t, e, 0), o = !S(t) || t !== this._$AH && t !== _, o && (this._$AH = t);
    else {
      const h = t;
      let a, p;
      for (t = n[0], a = 0; a < n.length - 1; a++) p = A(this, h[s + a], e, a), p === _ && (p = this._$AH[a]), o ||= !S(p) || p !== this._$AH[a], p === l ? t = l : t !== l && (t += (p ?? "") + n[a + 1]), this._$AH[a] = p;
    }
    o && !r && this.j(t);
  }
  j(t) {
    t === l ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}
class Ut extends H {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === l ? void 0 : t;
  }
}
class Rt extends H {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== l);
  }
}
class Ot extends H {
  constructor(t, e, s, r, n) {
    super(t, e, s, r, n), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = A(this, t, e, 0) ?? l) === _) return;
    const s = this._$AH, r = t === l && s !== l || t.capture !== s.capture || t.once !== s.once || t.passive !== s.passive, n = t !== l && (s === l || r);
    r && this.element.removeEventListener(this.name, this, s), n && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, t) : this._$AH.handleEvent(t);
  }
}
class Nt {
  constructor(t, e, s) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = s;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    A(this, t);
  }
}
const It = W.litHtmlPolyfillSupport;
It?.(C, U), (W.litHtmlVersions ??= []).push("3.3.3");
const Mt = (i, t, e) => {
  const s = e?.renderBefore ?? t;
  let r = s._$litPart$;
  if (r === void 0) {
    const n = e?.renderBefore ?? null;
    s._$litPart$ = r = new U(t.insertBefore(T(), n), n, void 0, e ?? {});
  }
  return r._$AI(i), r;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const V = globalThis;
let k = class extends y {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    const t = super.createRenderRoot();
    return this.renderOptions.renderBefore ??= t.firstChild, t;
  }
  update(t) {
    const e = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = Mt(e, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return _;
  }
};
k._$litElement$ = !0, k.finalized = !0, V.litElementHydrateSupport?.({ LitElement: k });
const Ht = V.litElementPolyfillSupport;
Ht?.({ LitElement: k });
(V.litElementVersions ??= []).push("4.2.2");
let pt = null;
function zt(i) {
  pt = i;
}
function Lt() {
  return pt;
}
class K extends k {
  static properties = {
    api: { attribute: !1 },
    params: { attribute: !1 }
  };
  #t = [];
  constructor() {
    super(), this.api = null, this.params = {};
  }
  connectedCallback() {
    super.connectedCallback(), this.api && this.#e(this.api);
  }
  willUpdate(t) {
    t.has("api") && this.api && this.#t.length === 0 && this.isConnected && this.#e(this.api);
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    for (const t of this.#t) t();
    this.#t = [];
  }
  #e(t) {
    zt(t), this.#t.push(t.onLocaleChange(() => this.requestUpdate()));
  }
  /** Translation through the HOST dictionary (our `locales` export is merged into it). */
  t(t, e) {
    return this.api ? this.api.i18n.t(t, e) : t;
  }
}
function ut(i, t) {
  customElements.get(i) || customElements.define(i, t);
}
const Dt = {
  paautotune: {
    tabTitle: "PA Autotune",
    title: "PA Autotune",
    common: {
      loading: "Looking for installed providers…",
      noPrinter: "No active printer",
      klipperNotReady: "Cannot ask the printer which providers are installed. Is Klipper ready?"
    },
    none: {
      title: "No Pressure Advance autotune provider found",
      intro: "This tab embeds the web UI of autopa or KAPAT: both measure Pressure Advance with a load cell in the nozzle. Neither is installed on this printer (AUTOPA_SWEEP and KAPAT_SWEEP are not known to Klipper). Install one of them:",
      noLoadCell: "No [load_cell] or [load_cell_probe] in the printer config. Both providers need a load cell in the nozzle.",
      recheck: "Check again",
      checking: "Checking…",
      repo: "Repository",
      stepClone: "On the printer, download it:",
      stepInstall: "Run the installer:",
      stepConfig: "Add the {section} section to printer.cfg (options: see the repository README) and, in [extruder], max_extrude_cross_section: 200.",
      stepRestart: "Restart Klipper completely: sudo systemctl restart klipper. The RESTART command is not enough for a new module.",
      stepCheck: "Press “Check again”: the tab shows the provider as soon as Klipper knows its command."
    },
    provider: {
      autopa: "Sweeps extrusion and builds Pressure Advance profiles per material and temperature (AUTOPA_SWEEP).",
      kapat: "Searches the K / Pressure Advance value by grid or bisection (KAPAT_SWEEP) and applies it."
    },
    frame: {
      reload: "Reload",
      openTab: "Open in a new tab",
      address: "Address",
      addressLabel: "Address of the web UI",
      addressPlaceholder: "http://printer.local{path}",
      save: "Save",
      reset: "Reset",
      custom: "your address",
      resolving: "Looking for the web UI of {name}…",
      unreachableTitle: "The web UI of {name} does not answer",
      unreachableBody: "Tried: {tried}. The installer puts it on the first nginx site it finds, which may be on another port than Tessera. Check that the web UI of the provider opens in the browser and, if its address differs, type it in “Address”.",
      mixedTitle: "The browser blocks this address",
      mixedBody: "Tessera is opened over HTTPS, the web UI of {name} over HTTP: browsers do not embed HTTP pages into HTTPS ones. Open it in a new tab, or serve it over HTTPS too.",
      hint: "If the frame stays empty, the address is wrong or the site forbids embedding. Use “Open in a new tab” then.",
      kapatChart: "KAPAT draws its live graph over a direct connection to port 7125 (/klippysocket). Behind a reverse proxy that does not forward it, the rest of the UI works but the graph stays empty.",
      guardNote: "Sweeps started inside this web UI go straight to Moonraker: the print-time protection of Tessera applies only to commands typed in the Tessera console."
    },
    guard: {
      printing: "A Pressure Advance sweep is not allowed while printing."
    }
  }
}, Kt = {
  paautotune: {
    tabTitle: "PA Autotune",
    title: "PA Autotune",
    common: {
      loading: "Ищу установленных провайдеров…",
      noPrinter: "Нет активного принтера",
      klipperNotReady: "Не удалось спросить принтер об установленных провайдерах. Klipper готов?"
    },
    none: {
      title: "Провайдер автокалибровки Pressure Advance не найден",
      intro: "Эта вкладка встраивает веб-интерфейс autopa или KAPAT: оба измеряют Pressure Advance по датчику усилия в сопле. На этом принтере ни один не установлен (Klipper не знает команд AUTOPA_SWEEP и KAPAT_SWEEP). Установите любой из них:",
      noLoadCell: "В конфиге принтера нет [load_cell] или [load_cell_probe]. Обоим провайдерам нужен датчик усилия в сопле.",
      recheck: "Проверить снова",
      checking: "Проверяю…",
      repo: "Репозиторий",
      stepClone: "На принтере скачайте его:",
      stepInstall: "Запустите установщик:",
      stepConfig: "Добавьте в printer.cfg секцию {section} (параметры — в README репозитория), а в [extruder] — max_extrude_cross_section: 200.",
      stepRestart: "Полностью перезапустите Klipper: sudo systemctl restart klipper. Команды RESTART для нового модуля недостаточно.",
      stepCheck: "Нажмите «Проверить снова»: вкладка покажет провайдера, как только Klipper узнает его команду."
    },
    provider: {
      autopa: "Прогоняет экструзию и строит профили Pressure Advance по материалу и температуре (AUTOPA_SWEEP).",
      kapat: "Ищет значение K / Pressure Advance сеткой или бисекцией (KAPAT_SWEEP) и применяет его."
    },
    frame: {
      reload: "Перезагрузить",
      openTab: "Открыть в новой вкладке",
      address: "Адрес",
      addressLabel: "Адрес веб-интерфейса",
      addressPlaceholder: "http://printer.local{path}",
      save: "Сохранить",
      reset: "Сбросить",
      custom: "ваш адрес",
      resolving: "Ищу веб-интерфейс {name}…",
      unreachableTitle: "Веб-интерфейс {name} не отвечает",
      unreachableBody: "Пробовал: {tried}. Установщик кладёт его в первый найденный сайт nginx, а он может быть на другом порту, чем Tessera. Проверьте, что веб-интерфейс провайдера открывается в браузере, и, если его адрес другой, введите его в «Адрес».",
      mixedTitle: "Браузер блокирует этот адрес",
      mixedBody: "Tessera открыта по HTTPS, а веб-интерфейс {name} — по HTTP: браузеры не встраивают HTTP-страницы в HTTPS. Откройте его в новой вкладке или отдавайте по HTTPS.",
      hint: "Если рамка пустая, адрес неверен или сайт запрещает встраивание. Тогда используйте «Открыть в новой вкладке».",
      kapatChart: "KAPAT рисует живой график по прямому подключению к порту 7125 (/klippysocket). За обратным прокси, который его не пробрасывает, остальной интерфейс работает, а график пуст.",
      guardNote: "Прогоны, запущенные внутри этого веб-интерфейса, идут прямо в Moonraker: защита Tessera от запуска во время печати действует только на команды из консоли Tessera."
    },
    guard: {
      printing: "Прогон Pressure Advance нельзя запускать во время печати."
    }
  }
};
class jt extends K {
  render() {
    return l;
  }
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Bt = (i) => (...t) => ({ _$litDirective$: i, values: t });
let Wt = class {
  constructor(t) {
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AT(t, e, s) {
    this._$Ct = t, this._$AM = e, this._$Ci = s;
  }
  _$AS(t, e) {
    return this.update(t, e);
  }
  update(t, e) {
    return this.render(...e);
  }
};
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const qt = {}, Vt = (i, t = qt) => i._$AH = t;
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Ft = Bt(class extends Wt {
  constructor() {
    super(...arguments), this.key = l;
  }
  render(i, t) {
    return this.key = i, t;
  }
  update(i, [t, e]) {
    return t !== this.key && (Vt(i), this.key = t), e;
  }
}), w = [
  {
    id: "autopa",
    name: "autopa",
    path: "/autopa/",
    detectCommand: "AUTOPA_SWEEP",
    objectName: "autopa",
    repoUrl: "https://github.com/G0BL1N/autopa",
    cloneUrl: "https://github.com/G0BL1N/autopa.git",
    cloneDir: "autopa",
    section: "[autopa]"
  },
  {
    id: "kapat",
    name: "KAPAT",
    path: "/kapat/",
    detectCommand: "KAPAT_SWEEP",
    objectName: "kapat",
    repoUrl: "https://github.com/vzagranichnyy/KAPAT",
    cloneUrl: "https://github.com/vzagranichnyy/KAPAT.git",
    cloneDir: "KAPAT",
    section: "[kapat]"
  }
];
function N(i) {
  return w.find((t) => t.id === i);
}
const Gt = /* @__PURE__ */ new Set(["AUTOPA_SWEEP", "AUTOPA_DECAY", "KAPAT_SWEEP"]);
function Jt(i) {
  const t = [];
  for (const e of i.split(/\r?\n/)) {
    const s = e.trim();
    !s || s.startsWith(";") || s.startsWith("#") || t.push(s.split(/\s+/)[0].toUpperCase());
  }
  return t;
}
const Zt = /^load_cell(_probe)?(\s|$)/i;
function Xt(i) {
  const t = new Set(Object.keys(i ?? {}).map((e) => e.toUpperCase()));
  return w.filter((e) => t.has(e.detectCommand)).map((e) => e.id);
}
function Yt(i) {
  const t = i ?? [], e = new Set(t.map((s) => s.toLowerCase()));
  return {
    installed: w.filter((s) => e.has(s.objectName)).map((s) => s.id),
    hasLoadCell: t.some((s) => Zt.test(s))
  };
}
async function Qt(i) {
  const [t, e] = await Promise.allSettled([
    i.request("printer.gcode.help"),
    i.request("printer.objects.list")
  ]), s = t.status === "fulfilled" ? Xt(t.value) : [], r = e.status === "fulfilled" ? Yt(e.value?.objects) : { installed: [], hasLoadCell: !1 }, n = /* @__PURE__ */ new Set([...s, ...r.installed]);
  return {
    installed: w.filter((o) => n.has(o.id)).map((o) => o.id),
    hasLoadCell: r.hasLoadCell,
    unknown: t.status === "rejected" && e.status === "rejected"
  };
}
const nt = "provider", P = (i) => `url.${i}`;
function te(i, t) {
  return typeof t == "string" && i.includes(t) ? N(t) ?? null : w.find((s) => i.includes(s.id)) ?? null;
}
function ee(i) {
  try {
    return new URL(i).hostname || null;
  } catch {
    return null;
  }
}
function F(i) {
  const t = (i ?? "").trim();
  if (!t) return null;
  const e = /^[a-z][a-z0-9+.-]*:\/\//i.test(t) ? t : `http://${t}`;
  try {
    const s = new URL(e);
    return s.protocol !== "http:" && s.protocol !== "https:" ? null : s.href;
  } catch {
    return null;
  }
}
function se(i, t) {
  const e = [], s = (o) => {
    o && !e.includes(o) && e.push(o);
  };
  s(F(t.manual));
  let r = "http:";
  try {
    r = new URL(t.pageOrigin).protocol, s(new URL(i.path, t.pageOrigin).href);
  } catch {
  }
  const n = ee(t.printerUrl);
  return n && s(new URL(i.path, `${r}//${n}`).href), e;
}
function ft(i, t) {
  return t === "https:" && /^http:/i.test(i);
}
function ie(i, t) {
  try {
    return new URL(i).origin === t;
  } catch {
    return !1;
  }
}
async function L(i, t) {
  const e = new AbortController(), s = setTimeout(() => e.abort(), t);
  try {
    return await i(e.signal);
  } finally {
    clearTimeout(s);
  }
}
async function re(i, t, e = 4e3, s = (r, n) => fetch(r, n)) {
  try {
    const r = t.startsWith("https:") ? "https:" : "http:";
    if (ft(i, r)) return !1;
    if (!ie(i, t))
      return await L((a) => s(i, { mode: "no-cors", cache: "no-store", signal: a }), e), !0;
    const n = await L((a) => s(i, { cache: "no-store", signal: a }), e);
    if (!n.ok) return !1;
    const [o, h] = await Promise.all([
      n.text(),
      L((a) => s(`${t}/`, { cache: "no-store", signal: a }), e).then(
        (a) => a.ok ? a.text() : ""
      )
    ]);
    return o.trim() !== "" && o !== h;
  } catch {
    return !1;
  }
}
async function ne(i, t, e = (s) => re(s, t.pageOrigin)) {
  const s = F(t.manual);
  if (s) return { url: s, manual: !0, tried: [s] };
  const r = [];
  for (const n of se(i, t))
    if (r.push(n), await e(n)) return { url: n, manual: !1, tried: r };
  return { url: null, manual: !1, tried: r };
}
const oe = $t`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
    min-width: 0;
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    font-size: var(--font-size-md);
    /* Width-based layout: the page area, not the window, decides (sidebars). */
    container-type: inline-size;
  }

  .panel {
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-width: 0;
  }
  .panel-header {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    flex-wrap: wrap;
    padding: var(--space-sm) var(--space-md);
    border-bottom: 1px solid var(--border-color);
  }
  .panel-title {
    flex: 1;
    min-width: 0;
    font-size: var(--font-size-md);
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .panel-body {
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    min-width: 0;
  }

  .row { display: flex; align-items: center; gap: var(--space-sm); flex-wrap: wrap; }
  .row.grow > input { flex: 1; min-width: 160px; }
  .muted { color: var(--text-muted); font-size: var(--font-size-sm); margin: 0; }
  .warn { color: var(--warning); font-size: var(--font-size-sm); margin: 0; }
  .mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
  p { margin: 0; }
  a { color: var(--accent); }
  b { font-weight: 600; }

  .chip {
    padding: 1px 8px;
    border-radius: 999px;
    border: 1px solid var(--border-color);
    background: var(--bg-surface-hover);
    color: var(--text-secondary);
    font-size: var(--font-size-sm);
    white-space: nowrap;
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .chip.accent { border-color: var(--accent); color: var(--accent); font-weight: 600; }

  /* Provider switcher: same look as Calibrations' .sel-btn. */
  .sel-row { display: flex; gap: var(--space-xs); flex-wrap: wrap; }
  .sel-btn {
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-secondary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
  }
  .sel-btn:hover:not(:disabled) { background: var(--bg-surface-hover); }
  .sel-btn.active { background: var(--bg-surface-active); color: var(--accent); border-color: var(--accent); }

  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-xs);
    padding: var(--space-xs) var(--space-md);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface-hover);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
  }
  .btn:hover:not(:disabled) { background: var(--bg-surface-active); }
  .btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .btn.primary { background: var(--accent); border-color: var(--accent); color: var(--accent-text, #fff); }
  .btn:focus-visible, .sel-btn:focus-visible {
    outline: 2px solid var(--accent-ring, var(--accent));
    outline-offset: 1px;
  }

  input {
    min-width: 0;
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
  }

  input.invalid { border-color: var(--danger); }

  .gcode {
    display: block;
    padding: var(--space-xs) var(--space-sm);
    background: var(--bg-surface-hover);
    border: 1px dashed var(--border-color);
    border-radius: var(--radius-sm);
    font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    font-size: var(--font-size-sm);
    white-space: pre-wrap;
    word-break: break-all;
    user-select: text;
  }

  ol.steps { margin: 0; padding-inline-start: 1.4em; display: flex; flex-direction: column; gap: var(--space-xs); }
  ol.steps li { color: var(--text-secondary); font-size: var(--font-size-sm); }
  ol.steps li .gcode { margin-top: 2px; }

  /* The provider's own UI. Its height is ours: the tab body has none. */
  iframe.frame {
    display: block;
    width: 100%;
    height: max(560px, 78dvh);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface-hover);
  }
  .status { padding: var(--space-lg); text-align: center; color: var(--text-muted); }

  @container (max-width: 480px) {
    .panel-body { padding: var(--space-sm); }
    .panel-header { padding: var(--space-xs) var(--space-sm); }
    iframe.frame { height: max(480px, 80dvh); }
  }
  @media (pointer: coarse) {
    .sel-btn, .btn { min-height: 36px; }
  }
`, ae = "allow-scripts allow-same-origin allow-forms allow-downloads allow-popups allow-modals", le = ["notify_klippy_ready", "notify_config_changed"], ce = d`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor"
  stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
  <polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
</svg>`;
class he extends K {
  static styles = oe;
  static properties = {
    ...K.properties,
    detection: { state: !0 },
    checking: { state: !0 },
    providerId: { state: !0 },
    resolved: { state: !0 },
    resolving: { state: !0 },
    editing: { state: !0 },
    draft: { state: !0 },
    draftInvalid: { state: !0 },
    frameKey: { state: !0 }
  };
  #t = !1;
  #e = [];
  #i = [];
  /** Answers of an older query/probe must not overwrite a newer one. */
  #r = 0;
  #n = 0;
  constructor() {
    super(), this.detection = null, this.checking = !1, this.providerId = null, this.resolved = null, this.resolving = !1, this.editing = !1, this.draft = "", this.draftInvalid = !1, this.frameKey = 0;
  }
  connectedCallback() {
    super.connectedCallback(), this.requestUpdate();
  }
  willUpdate(t) {
    super.willUpdate(t), this.api && this.isConnected && !this.#t && this.#h(this.api);
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    for (const t of this.#e) t();
    this.#e = [], this.#l(), this.#t = !1, this.#r++, this.#n++;
  }
  // ------------------------------------------------------------------ state
  #h(t) {
    this.#t = !0, this.#e.push(t.onPrinterChange(() => void this.#a())), this.#a();
  }
  /** Fresh state for the active printer. */
  async #a() {
    this.detection = null, this.providerId = null, this.resolved = null, this.resolving = !1, this.editing = !1, this.#l(), this.api?.printer.id && (this.#d(), await this.#o(!0));
  }
  #d() {
    try {
      const t = this.api.moonraker();
      for (const e of le)
        this.#i.push(t.onNotify(e, () => void this.#o(!1)));
    } catch {
    }
  }
  #l() {
    for (const t of this.#i) t();
    this.#i = [];
  }
  async #o(t) {
    const e = this.api;
    if (!e?.printer.id) return;
    const s = ++this.#r;
    this.checking = !0;
    let r;
    try {
      r = await Qt(e.moonrakerFor(e.printer.id));
    } catch {
      r = { installed: [], hasLoadCell: !1, unknown: !0 };
    }
    if (s !== this.#r || (this.checking = !1, r.unknown && this.detection)) return;
    this.detection = r;
    const n = te(r.installed, e.settings.get(nt));
    (t || (n?.id ?? null) !== this.providerId) && (this.providerId = n?.id ?? null, this.#s());
  }
  async #s() {
    const t = this.api, e = this.providerId ? N(this.providerId) : void 0, s = ++this.#n;
    if (!t || !e) {
      this.resolved = null, this.resolving = !1;
      return;
    }
    this.resolving = !0, this.resolved = null;
    const r = await ne(e, {
      manual: t.settings.get(P(e.id)),
      pageOrigin: window.location.origin,
      printerUrl: t.printer.url
    });
    s === this.#n && (this.resolved = r, this.resolving = !1, this.frameKey++);
  }
  // ---------------------------------------------------------------- actions
  #p(t) {
    t !== this.providerId && (this.api?.settings.set(nt, t), this.providerId = t, this.editing = !1, this.#s());
  }
  #u(t) {
    this.editing = !this.editing, this.editing && (this.draft = this.api?.settings.get(P(t.id)) ?? "", this.draftInvalid = !1);
  }
  #c(t) {
    const e = this.draft.trim();
    if (e && !F(e)) {
      this.draftInvalid = !0;
      return;
    }
    this.api?.settings.set(P(t.id), e || null), this.editing = !1, this.#s();
  }
  #f(t) {
    this.api?.settings.set(P(t.id), null), this.draft = "", this.editing = !1, this.#s();
  }
  // ----------------------------------------------------------------- render
  render() {
    if (!this.api) return l;
    if (!this.api.printer.id) return d`<div class="status">${this.t("paautotune.common.noPrinter")}</div>`;
    if (!this.detection) return d`<div class="status">${this.t("paautotune.common.loading")}</div>`;
    const t = this.providerId ? N(this.providerId) : void 0;
    return t ? this.#v(t, this.detection) : this.#m(this.detection);
  }
  #m(t) {
    return d`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title">${this.t("paautotune.none.title")}</span>
          <button type="button" class="btn" ?disabled=${this.checking} @click=${() => void this.#o(!1)}>
            ${this.checking ? this.t("paautotune.none.checking") : this.t("paautotune.none.recheck")}
          </button>
        </div>
        <div class="panel-body">
          <p>${this.t("paautotune.none.intro")}</p>
          ${t.unknown ? d`<p class="warn">${this.t("paautotune.common.klipperNotReady")}</p>` : l}
          ${!t.unknown && !t.hasLoadCell ? d`<p class="warn">${this.t("paautotune.none.noLoadCell")}</p>` : l}
          <p class="muted">${this.t("paautotune.none.stepCheck")}</p>
        </div>
      </section>
      ${w.map((e) => this.#$(e))}
    `;
  }
  #$(t) {
    return d`
      <section class="panel">
        <div class="panel-header">
          <span class="panel-title">${t.name}</span>
          <a class="btn" href=${t.repoUrl} target="_blank" rel="noopener noreferrer">${this.t("paautotune.none.repo")}</a>
        </div>
        <div class="panel-body">
          <p class="muted">${this.t(`paautotune.provider.${t.id}`)}</p>
          <ol class="steps">
            <li>${this.t("paautotune.none.stepClone")}<code class="gcode">git clone ${t.cloneUrl}</code></li>
            <li>${this.t("paautotune.none.stepInstall")}<code class="gcode">cd ${t.cloneDir} &amp;&amp; ./install.sh</code></li>
            <li>${this.t("paautotune.none.stepConfig", { section: t.section })}</li>
            <li>${this.t("paautotune.none.stepRestart")}</li>
          </ol>
        </div>
      </section>
    `;
  }
  #v(t, e) {
    const s = this.resolved, r = s?.url ?? null, n = e.installed.length > 1;
    return d`
      <section class="panel">
        <div class="panel-header">
          ${n ? d`<div class="sel-row" role="tablist">
                ${e.installed.map((o) => {
      const h = N(o);
      return d`<button
                    type="button"
                    class="sel-btn ${o === t.id ? "active" : ""}"
                    role="tab"
                    aria-selected=${o === t.id}
                    @click=${() => this.#p(o)}
                  >${h.name}</button>`;
    })}
              </div>` : d`<span class="panel-title">${t.name}</span>`}
          ${n ? d`<span class="panel-title"></span>` : l}
          ${s?.manual ? d`<span class="chip accent">${this.t("paautotune.frame.custom")}</span>` : l}
          ${r ? d`<span class="chip mono" title=${r}>${r}</span>` : l}
          <button type="button" class="btn" ?disabled=${this.resolving} @click=${() => void this.#s()}
            title=${this.t("paautotune.frame.reload")} aria-label=${this.t("paautotune.frame.reload")}>${ce}</button>
          <button type="button" class="btn ${this.editing ? "primary" : ""}" @click=${() => this.#u(t)}>
            ${this.t("paautotune.frame.address")}
          </button>
          ${r ? d`<a class="btn" href=${r} target="_blank" rel="noopener noreferrer">${this.t("paautotune.frame.openTab")}</a>` : l}
        </div>
        ${this.editing ? this.#g(t) : l}
        <div class="panel-body">
          ${this.#b(t, s)}
          <p class="muted">${this.t("paautotune.frame.hint")}</p>
          ${t.id === "kapat" ? d`<p class="muted">${this.t("paautotune.frame.kapatChart")}</p>` : l}
          <p class="muted">${this.t("paautotune.frame.guardNote")}</p>
        </div>
      </section>
    `;
  }
  #g(t) {
    const e = !!this.api?.settings.get(P(t.id));
    return d`
      <div class="panel-body">
        <div class="row grow">
          <input
            type="url"
            class=${this.draftInvalid ? "invalid" : ""}
            aria-label=${this.t("paautotune.frame.addressLabel")}
            placeholder=${this.t("paautotune.frame.addressPlaceholder", { path: t.path })}
            .value=${this.draft}
            @input=${(s) => {
      this.draft = s.target.value, this.draftInvalid = !1;
    }}
            @keydown=${(s) => s.key === "Enter" && this.#c(t)}
          />
          <button type="button" class="btn primary" @click=${() => this.#c(t)}>
            ${this.t("paautotune.frame.save")}
          </button>
          ${e ? d`<button type="button" class="btn" @click=${() => this.#f(t)}>${this.t("paautotune.frame.reset")}</button>` : l}
        </div>
      </div>
    `;
  }
  #b(t, e) {
    return this.resolving || !e ? d`<div class="status">${this.t("paautotune.frame.resolving", { name: t.name })}</div>` : e.url ? ft(e.url, window.location.protocol) ? d`<div class="status">
        <p><b>${this.t("paautotune.frame.mixedTitle")}</b></p>
        <p>${this.t("paautotune.frame.mixedBody", { name: t.name })}</p>
      </div>` : Ft(
      this.frameKey,
      d`<iframe
        class="frame"
        title=${t.name}
        src=${e.url}
        sandbox=${ae}
        referrerpolicy="no-referrer"
        allow="clipboard-write"
      ></iframe>`
    ) : d`<div class="status">
        <p><b>${this.t("paautotune.frame.unreachableTitle", { name: t.name })}</b></p>
        <p>${this.t("paautotune.frame.unreachableBody", { tried: e.tried.join(", ") })}</p>
      </div>`;
  }
}
const de = 3e3;
async function pe(i) {
  const t = Lt();
  if (!t) return null;
  try {
    const e = async () => {
      const s = await t.moonrakerFor(i).request("printer.objects.query", {
        objects: { print_stats: ["state"] }
      });
      return String(s?.status?.print_stats?.state ?? "");
    };
    return await Promise.race([
      e(),
      new Promise((s) => setTimeout(() => s(null), de))
    ]);
  } catch {
    return null;
  }
}
async function ve(i, t, e) {
  if (i.method !== "printer.gcode.script") return { action: "allow" };
  const s = String(i.params?.script ?? "");
  if (!Jt(s).some((n) => Gt.has(n))) return { action: "allow" };
  const r = await pe(e.targetPrinterId);
  return r === "printing" || r === "paused" ? { action: "deny", reasonKey: "paautotune.guard.printing" } : { action: "allow" };
}
ut("tessera-pa-autotune-tab", he);
ut("tessera-pa-autotune-bridge", jt);
const ge = { en: Dt, ru: Kt };
export {
  ve as guardPaAutotune,
  ge as locales
};
