/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const L = globalThis, W = L.ShadowRoot && (L.ShadyCSS === void 0 || L.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, Q = Symbol(), le = /* @__PURE__ */ new WeakMap();
let Ee = class {
  constructor(e, t, s) {
    if (this._$cssResult$ = !0, s !== Q) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = e, this.t = t;
  }
  get styleSheet() {
    let e = this.o;
    const t = this.t;
    if (W && e === void 0) {
      const s = t !== void 0 && t.length === 1;
      s && (e = le.get(t)), e === void 0 && ((this.o = e = new CSSStyleSheet()).replaceSync(this.cssText), s && le.set(t, e));
    }
    return e;
  }
  toString() {
    return this.cssText;
  }
};
const Oe = (i) => new Ee(typeof i == "string" ? i : i + "", void 0, Q), Le = (i, ...e) => {
  const t = i.length === 1 ? i[0] : e.reduce((s, n, r) => s + ((a) => {
    if (a._$cssResult$ === !0) return a.cssText;
    if (typeof a == "number") return a;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + a + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(n) + i[r + 1], i[0]);
  return new Ee(t, i, Q);
}, Ue = (i, e) => {
  if (W) i.adoptedStyleSheets = e.map((t) => t instanceof CSSStyleSheet ? t : t.styleSheet);
  else for (const t of e) {
    const s = document.createElement("style"), n = L.litNonce;
    n !== void 0 && s.setAttribute("nonce", n), s.textContent = t.cssText, i.appendChild(s);
  }
}, ce = W ? (i) => i : (i) => i instanceof CSSStyleSheet ? ((e) => {
  let t = "";
  for (const s of e.cssRules) t += s.cssText;
  return Oe(t);
})(i) : i;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: ze, defineProperty: De, getOwnPropertyDescriptor: qe, getOwnPropertyNames: Fe, getOwnPropertySymbols: Xe, getPrototypeOf: Be } = Object, D = globalThis, he = D.trustedTypes, Ve = he ? he.emptyScript : "", je = D.reactiveElementPolyfillSupport, w = (i, e) => i, j = { toAttribute(i, e) {
  switch (e) {
    case Boolean:
      i = i ? Ve : null;
      break;
    case Object:
    case Array:
      i = i == null ? i : JSON.stringify(i);
  }
  return i;
}, fromAttribute(i, e) {
  let t = i;
  switch (e) {
    case Boolean:
      t = i !== null;
      break;
    case Number:
      t = i === null ? null : Number(i);
      break;
    case Object:
    case Array:
      try {
        t = JSON.parse(i);
      } catch {
        t = null;
      }
  }
  return t;
} }, Ae = (i, e) => !ze(i, e), pe = { attribute: !0, type: String, converter: j, reflect: !1, useDefault: !1, hasChanged: Ae };
Symbol.metadata ??= Symbol("metadata"), D.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
let k = class extends HTMLElement {
  static addInitializer(e) {
    this._$Ei(), (this.l ??= []).push(e);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(e, t = pe) {
    if (t.state && (t.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(e) && ((t = Object.create(t)).wrapped = !0), this.elementProperties.set(e, t), !t.noAccessor) {
      const s = Symbol(), n = this.getPropertyDescriptor(e, s, t);
      n !== void 0 && De(this.prototype, e, n);
    }
  }
  static getPropertyDescriptor(e, t, s) {
    const { get: n, set: r } = qe(this.prototype, e) ?? { get() {
      return this[t];
    }, set(a) {
      this[t] = a;
    } };
    return { get: n, set(a) {
      const l = n?.call(this);
      r?.call(this, a), this.requestUpdate(e, l, s);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(e) {
    return this.elementProperties.get(e) ?? pe;
  }
  static _$Ei() {
    if (this.hasOwnProperty(w("elementProperties"))) return;
    const e = Be(this);
    e.finalize(), e.l !== void 0 && (this.l = [...e.l]), this.elementProperties = new Map(e.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(w("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(w("properties"))) {
      const t = this.properties, s = [...Fe(t), ...Xe(t)];
      for (const n of s) this.createProperty(n, t[n]);
    }
    const e = this[Symbol.metadata];
    if (e !== null) {
      const t = litPropertyMetadata.get(e);
      if (t !== void 0) for (const [s, n] of t) this.elementProperties.set(s, n);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [t, s] of this.elementProperties) {
      const n = this._$Eu(t, s);
      n !== void 0 && this._$Eh.set(n, t);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(e) {
    const t = [];
    if (Array.isArray(e)) {
      const s = new Set(e.flat(1 / 0).reverse());
      for (const n of s) t.unshift(ce(n));
    } else e !== void 0 && t.push(ce(e));
    return t;
  }
  static _$Eu(e, t) {
    const s = t.attribute;
    return s === !1 ? void 0 : typeof s == "string" ? s : typeof e == "string" ? e.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise((e) => this.enableUpdating = e), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((e) => e(this));
  }
  addController(e) {
    (this._$EO ??= /* @__PURE__ */ new Set()).add(e), this.renderRoot !== void 0 && this.isConnected && e.hostConnected?.();
  }
  removeController(e) {
    this._$EO?.delete(e);
  }
  _$E_() {
    const e = /* @__PURE__ */ new Map(), t = this.constructor.elementProperties;
    for (const s of t.keys()) this.hasOwnProperty(s) && (e.set(s, this[s]), delete this[s]);
    e.size > 0 && (this._$Ep = e);
  }
  createRenderRoot() {
    const e = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return Ue(e, this.constructor.elementStyles), e;
  }
  connectedCallback() {
    this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$EO?.forEach((e) => e.hostConnected?.());
  }
  enableUpdating(e) {
  }
  disconnectedCallback() {
    this._$EO?.forEach((e) => e.hostDisconnected?.());
  }
  attributeChangedCallback(e, t, s) {
    this._$AK(e, s);
  }
  _$ET(e, t) {
    const s = this.constructor.elementProperties.get(e), n = this.constructor._$Eu(e, s);
    if (n !== void 0 && s.reflect === !0) {
      const r = (s.converter?.toAttribute !== void 0 ? s.converter : j).toAttribute(t, s.type);
      this._$Em = e, r == null ? this.removeAttribute(n) : this.setAttribute(n, r), this._$Em = null;
    }
  }
  _$AK(e, t) {
    const s = this.constructor, n = s._$Eh.get(e);
    if (n !== void 0 && this._$Em !== n) {
      const r = s.getPropertyOptions(n), a = typeof r.converter == "function" ? { fromAttribute: r.converter } : r.converter?.fromAttribute !== void 0 ? r.converter : j;
      this._$Em = n;
      const l = a.fromAttribute(t, r.type);
      this[n] = l ?? this._$Ej?.get(n) ?? l, this._$Em = null;
    }
  }
  requestUpdate(e, t, s, n = !1, r) {
    if (e !== void 0) {
      const a = this.constructor;
      if (n === !1 && (r = this[e]), s ??= a.getPropertyOptions(e), !((s.hasChanged ?? Ae)(r, t) || s.useDefault && s.reflect && r === this._$Ej?.get(e) && !this.hasAttribute(a._$Eu(e, s)))) return;
      this.C(e, t, s);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(e, t, { useDefault: s, reflect: n, wrapped: r }, a) {
    s && !(this._$Ej ??= /* @__PURE__ */ new Map()).has(e) && (this._$Ej.set(e, a ?? t ?? this[e]), r !== !0 || a !== void 0) || (this._$AL.has(e) || (this.hasUpdated || s || (t = void 0), this._$AL.set(e, t)), n === !0 && this._$Em !== e && (this._$Eq ??= /* @__PURE__ */ new Set()).add(e));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (t) {
      Promise.reject(t);
    }
    const e = this.scheduleUpdate();
    return e != null && await e, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
        for (const [n, r] of this._$Ep) this[n] = r;
        this._$Ep = void 0;
      }
      const s = this.constructor.elementProperties;
      if (s.size > 0) for (const [n, r] of s) {
        const { wrapped: a } = r, l = this[n];
        a !== !0 || this._$AL.has(n) || l === void 0 || this.C(n, void 0, r, l);
      }
    }
    let e = !1;
    const t = this._$AL;
    try {
      e = this.shouldUpdate(t), e ? (this.willUpdate(t), this._$EO?.forEach((s) => s.hostUpdate?.()), this.update(t)) : this._$EM();
    } catch (s) {
      throw e = !1, this._$EM(), s;
    }
    e && this._$AE(t);
  }
  willUpdate(e) {
  }
  _$AE(e) {
    this._$EO?.forEach((t) => t.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(e)), this.updated(e);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(e) {
    return !0;
  }
  update(e) {
    this._$Eq &&= this._$Eq.forEach((t) => this._$ET(t, this[t])), this._$EM();
  }
  updated(e) {
  }
  firstUpdated(e) {
  }
};
k.elementStyles = [], k.shadowRootOptions = { mode: "open" }, k[w("elementProperties")] = /* @__PURE__ */ new Map(), k[w("finalized")] = /* @__PURE__ */ new Map(), je?.({ ReactiveElement: k }), (D.reactiveElementVersions ??= []).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const J = globalThis, de = (i) => i, U = J.trustedTypes, ue = U ? U.createPolicy("lit-html", { createHTML: (i) => i }) : void 0, Se = "$lit$", b = `lit$${Math.random().toFixed(9).slice(2)}$`, we = "?" + b, Ge = `<${we}>`, v = document, C = () => v.createComment(""), R = (i) => i === null || typeof i != "object" && typeof i != "function", ee = Array.isArray, Ze = (i) => ee(i) || typeof i?.[Symbol.iterator] == "function", F = `[ 	
\f\r]`, A = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, me = /-->/g, fe = />/g, y = RegExp(`>|${F}(?:([^\\s"'>=/]+)(${F}*=${F}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), ge = /'/g, be = /"/g, Te = /^(?:script|style|textarea|title)$/i, Ke = (i) => (e, ...t) => ({ _$litType$: i, strings: e, values: t }), h = Ke(1), x = Symbol.for("lit-noChange"), d = Symbol.for("lit-nothing"), $e = /* @__PURE__ */ new WeakMap(), _ = v.createTreeWalker(v, 129);
function Ce(i, e) {
  if (!ee(i) || !i.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return ue !== void 0 ? ue.createHTML(e) : e;
}
const Ye = (i, e) => {
  const t = i.length - 1, s = [];
  let n, r = e === 2 ? "<svg>" : e === 3 ? "<math>" : "", a = A;
  for (let l = 0; l < t; l++) {
    const o = i[l];
    let p, u, c = -1, m = 0;
    for (; m < o.length && (a.lastIndex = m, u = a.exec(o), u !== null); ) m = a.lastIndex, a === A ? u[1] === "!--" ? a = me : u[1] !== void 0 ? a = fe : u[2] !== void 0 ? (Te.test(u[2]) && (n = RegExp("</" + u[2], "g")), a = y) : u[3] !== void 0 && (a = y) : a === y ? u[0] === ">" ? (a = n ?? A, c = -1) : u[1] === void 0 ? c = -2 : (c = a.lastIndex - u[2].length, p = u[1], a = u[3] === void 0 ? y : u[3] === '"' ? be : ge) : a === be || a === ge ? a = y : a === me || a === fe ? a = A : (a = y, n = void 0);
    const g = a === y && i[l + 1].startsWith("/>") ? " " : "";
    r += a === A ? o + Ge : c >= 0 ? (s.push(p), o.slice(0, c) + Se + o.slice(c) + b + g) : o + b + (c === -2 ? l : g);
  }
  return [Ce(i, r + (i[t] || "<?>") + (e === 2 ? "</svg>" : e === 3 ? "</math>" : "")), s];
};
class P {
  constructor({ strings: e, _$litType$: t }, s) {
    let n;
    this.parts = [];
    let r = 0, a = 0;
    const l = e.length - 1, o = this.parts, [p, u] = Ye(e, t);
    if (this.el = P.createElement(p, s), _.currentNode = this.el.content, t === 2 || t === 3) {
      const c = this.el.content.firstChild;
      c.replaceWith(...c.childNodes);
    }
    for (; (n = _.nextNode()) !== null && o.length < l; ) {
      if (n.nodeType === 1) {
        if (n.hasAttributes()) for (const c of n.getAttributeNames()) if (c.endsWith(Se)) {
          const m = u[a++], g = n.getAttribute(c).split(b), N = /([.?@])?(.*)/.exec(m);
          o.push({ type: 1, index: r, name: N[2], strings: g, ctor: N[1] === "." ? Qe : N[1] === "?" ? Je : N[1] === "@" ? et : q }), n.removeAttribute(c);
        } else c.startsWith(b) && (o.push({ type: 6, index: r }), n.removeAttribute(c));
        if (Te.test(n.tagName)) {
          const c = n.textContent.split(b), m = c.length - 1;
          if (m > 0) {
            n.textContent = U ? U.emptyScript : "";
            for (let g = 0; g < m; g++) n.append(c[g], C()), _.nextNode(), o.push({ type: 2, index: ++r });
            n.append(c[m], C());
          }
        }
      } else if (n.nodeType === 8) if (n.data === we) o.push({ type: 2, index: r });
      else {
        let c = -1;
        for (; (c = n.data.indexOf(b, c + 1)) !== -1; ) o.push({ type: 7, index: r }), c += b.length - 1;
      }
      r++;
    }
  }
  static createElement(e, t) {
    const s = v.createElement("template");
    return s.innerHTML = e, s;
  }
}
function E(i, e, t = i, s) {
  if (e === x) return e;
  let n = s !== void 0 ? t._$Co?.[s] : t._$Cl;
  const r = R(e) ? void 0 : e._$litDirective$;
  return n?.constructor !== r && (n?._$AO?.(!1), r === void 0 ? n = void 0 : (n = new r(i), n._$AT(i, t, s)), s !== void 0 ? (t._$Co ??= [])[s] = n : t._$Cl = n), n !== void 0 && (e = E(i, n._$AS(i, e.values), n, s)), e;
}
class We {
  constructor(e, t) {
    this._$AV = [], this._$AN = void 0, this._$AD = e, this._$AM = t;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(e) {
    const { el: { content: t }, parts: s } = this._$AD, n = (e?.creationScope ?? v).importNode(t, !0);
    _.currentNode = n;
    let r = _.nextNode(), a = 0, l = 0, o = s[0];
    for (; o !== void 0; ) {
      if (a === o.index) {
        let p;
        o.type === 2 ? p = new H(r, r.nextSibling, this, e) : o.type === 1 ? p = new o.ctor(r, o.name, o.strings, this, e) : o.type === 6 && (p = new tt(r, this, e)), this._$AV.push(p), o = s[++l];
      }
      a !== o?.index && (r = _.nextNode(), a++);
    }
    return _.currentNode = v, n;
  }
  p(e) {
    let t = 0;
    for (const s of this._$AV) s !== void 0 && (s.strings !== void 0 ? (s._$AI(e, s, t), t += s.strings.length - 2) : s._$AI(e[t])), t++;
  }
}
class H {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(e, t, s, n) {
    this.type = 2, this._$AH = d, this._$AN = void 0, this._$AA = e, this._$AB = t, this._$AM = s, this.options = n, this._$Cv = n?.isConnected ?? !0;
  }
  get parentNode() {
    let e = this._$AA.parentNode;
    const t = this._$AM;
    return t !== void 0 && e?.nodeType === 11 && (e = t.parentNode), e;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(e, t = this) {
    e = E(this, e, t), R(e) ? e === d || e == null || e === "" ? (this._$AH !== d && this._$AR(), this._$AH = d) : e !== this._$AH && e !== x && this._(e) : e._$litType$ !== void 0 ? this.$(e) : e.nodeType !== void 0 ? this.T(e) : Ze(e) ? this.k(e) : this._(e);
  }
  O(e) {
    return this._$AA.parentNode.insertBefore(e, this._$AB);
  }
  T(e) {
    this._$AH !== e && (this._$AR(), this._$AH = this.O(e));
  }
  _(e) {
    this._$AH !== d && R(this._$AH) ? this._$AA.nextSibling.data = e : this.T(v.createTextNode(e)), this._$AH = e;
  }
  $(e) {
    const { values: t, _$litType$: s } = e, n = typeof s == "number" ? this._$AC(e) : (s.el === void 0 && (s.el = P.createElement(Ce(s.h, s.h[0]), this.options)), s);
    if (this._$AH?._$AD === n) this._$AH.p(t);
    else {
      const r = new We(n, this), a = r.u(this.options);
      r.p(t), this.T(a), this._$AH = r;
    }
  }
  _$AC(e) {
    let t = $e.get(e.strings);
    return t === void 0 && $e.set(e.strings, t = new P(e)), t;
  }
  k(e) {
    ee(this._$AH) || (this._$AH = [], this._$AR());
    const t = this._$AH;
    let s, n = 0;
    for (const r of e) n === t.length ? t.push(s = new H(this.O(C()), this.O(C()), this, this.options)) : s = t[n], s._$AI(r), n++;
    n < t.length && (this._$AR(s && s._$AB.nextSibling, n), t.length = n);
  }
  _$AR(e = this._$AA.nextSibling, t) {
    for (this._$AP?.(!1, !0, t); e !== this._$AB; ) {
      const s = de(e).nextSibling;
      de(e).remove(), e = s;
    }
  }
  setConnected(e) {
    this._$AM === void 0 && (this._$Cv = e, this._$AP?.(e));
  }
}
class q {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(e, t, s, n, r) {
    this.type = 1, this._$AH = d, this._$AN = void 0, this.element = e, this.name = t, this._$AM = n, this.options = r, s.length > 2 || s[0] !== "" || s[1] !== "" ? (this._$AH = Array(s.length - 1).fill(new String()), this.strings = s) : this._$AH = d;
  }
  _$AI(e, t = this, s, n) {
    const r = this.strings;
    let a = !1;
    if (r === void 0) e = E(this, e, t, 0), a = !R(e) || e !== this._$AH && e !== x, a && (this._$AH = e);
    else {
      const l = e;
      let o, p;
      for (e = r[0], o = 0; o < r.length - 1; o++) p = E(this, l[s + o], t, o), p === x && (p = this._$AH[o]), a ||= !R(p) || p !== this._$AH[o], p === d ? e = d : e !== d && (e += (p ?? "") + r[o + 1]), this._$AH[o] = p;
    }
    a && !n && this.j(e);
  }
  j(e) {
    e === d ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, e ?? "");
  }
}
class Qe extends q {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(e) {
    this.element[this.name] = e === d ? void 0 : e;
  }
}
class Je extends q {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(e) {
    this.element.toggleAttribute(this.name, !!e && e !== d);
  }
}
class et extends q {
  constructor(e, t, s, n, r) {
    super(e, t, s, n, r), this.type = 5;
  }
  _$AI(e, t = this) {
    if ((e = E(this, e, t, 0) ?? d) === x) return;
    const s = this._$AH, n = e === d && s !== d || e.capture !== s.capture || e.once !== s.once || e.passive !== s.passive, r = e !== d && (s === d || n);
    n && this.element.removeEventListener(this.name, this, s), r && this.element.addEventListener(this.name, this, e), this._$AH = e;
  }
  handleEvent(e) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, e) : this._$AH.handleEvent(e);
  }
}
class tt {
  constructor(e, t, s) {
    this.element = e, this.type = 6, this._$AN = void 0, this._$AM = t, this.options = s;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(e) {
    E(this, e);
  }
}
const st = J.litHtmlPolyfillSupport;
st?.(P, H), (J.litHtmlVersions ??= []).push("3.3.3");
const it = (i, e, t) => {
  const s = t?.renderBefore ?? e;
  let n = s._$litPart$;
  if (n === void 0) {
    const r = t?.renderBefore ?? null;
    s._$litPart$ = n = new H(e.insertBefore(C(), r), r, void 0, t ?? {});
  }
  return n._$AI(i), n;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const te = globalThis;
class T extends k {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    const e = super.createRenderRoot();
    return this.renderOptions.renderBefore ??= e.firstChild, e;
  }
  update(e) {
    const t = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(e), this._$Do = it(t, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return x;
  }
}
T._$litElement$ = !0, T.finalized = !0, te.litElementHydrateSupport?.({ LitElement: T });
const nt = te.litElementPolyfillSupport;
nt?.({ LitElement: T });
(te.litElementVersions ??= []).push("4.2.2");
let Re = null;
function Pe(i) {
  Re = i;
}
function rt() {
  return Re;
}
class G extends T {
  static properties = {
    api: { attribute: !1 },
    params: { attribute: !1 }
  };
  #e = [];
  constructor() {
    super(), this.api = null, this.params = {};
  }
  connectedCallback() {
    super.connectedCallback(), this.api && this.#t(this.api);
  }
  willUpdate(e) {
    e.has("api") && this.api && this.#e.length === 0 && this.isConnected && this.#t(this.api);
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    for (const e of this.#e) e();
    this.#e = [];
  }
  #t(e) {
    Pe(e), this.#e.push(e.onLocaleChange(() => this.requestUpdate()));
  }
  /** Translation through the HOST dictionary (our `locales` export is merged into it). */
  t(e, t) {
    return this.api ? this.api.i18n.t(e, t) : e;
  }
}
function Me(i, e) {
  customElements.get(i) || customElements.define(i, e);
}
const at = {
  shaketune: {
    title: "Shake&Tune",
    common: {
      loading: "Loading…",
      refresh: "Refresh",
      default: "default",
      noPrinter: "No active printer",
      configError: "Cannot read the printer config. Is Klipper ready?",
      notInstalled: "The [shaketune] section is not in the printer config any more. Right-click the tab and choose “Original”.",
      copied: "Copied",
      copyManually: "Copy the text:"
    },
    help: {
      title: "Help",
      switchTitle: "Shake&Tune or Klipper",
      switch: "This tab replaces the Input Shaper tab of Calibrations while Shake&Tune is configured on the printer. Right-click the tab (long press on touch) to switch between Shake&Tune and Klipper’s own SHAPER_CALIBRATE tools; the choice is remembered per printer.",
      runTitle: "Running a test",
      run: "Pick a command, fill only the parameters you want to change — empty fields use Shake&Tune’s defaults or your [resonance_tester]. Axes must be homed and the printer must not be printing. A run takes minutes; you can leave the tab, it keeps running in Klipper and is picked up again when you return.",
      applyTitle: "Apply vs printer.cfg",
      apply: "Apply sends SET_INPUT_SHAPER: the new shaper works at once but is lost on restart, and SAVE_CONFIG does not store it. Copy the [input_shaper] block into printer.cfg to keep it.",
      resultsTitle: "Results",
      results: "Graphs are read from Shake&Tune’s result_folder (by default config/ShakeTune_results). Shake&Tune keeps only the last number_of_results_to_keep graphs per type. Graphs of the last run are marked “new”."
    },
    command: {
      label: "Command",
      shaper: "Input shaper",
      belts: "Belts",
      vibrations: "Vibrations",
      axesMap: "Axes map",
      excitate: "Excitate axis"
    },
    commandHint: {
      shaper: "AXES_SHAPER_CALIBRATION — resonances of X and Y, recommended shapers for performance and for low vibrations.",
      belts: "COMPARE_BELTS_RESPONSES — compares the two belts of a CoreXY/CoreXZ machine to check tension.",
      vibrations: "CREATE_VIBRATIONS_PROFILE — vibrations by speed and direction; finds smooth speeds and angles. Needs input shaper configured.",
      axesMap: "AXES_MAP_CALIBRATION — detects the accelerometer orientation (axes_map).",
      excitate: "EXCITATE_AXIS_AT_FREQ — shakes an axis at one frequency to find what resonates."
    },
    param: {
      AXIS: "Axis to test",
      FREQ_START: "Start frequency, Hz",
      FREQ_END: "End frequency, Hz",
      HZ_PER_SEC: "Sweep speed, Hz per second",
      ACCEL_PER_HZ: "Acceleration per Hz, mm/s² (default: [resonance_tester])",
      SCV: "Square corner velocity used for the recommendations",
      MAX_SMOOTHING: "Maximum allowed smoothing of the recommended shaper",
      TRAVEL_SPEED: "Travel speed to the test point, mm/s",
      Z_HEIGHT: "Z of the test point, mm",
      MAX_SCALE: "Fixed energy scale of the graph, to compare runs",
      ACCEL_CHIP: "Accelerometer (default: chosen automatically)",
      SIZE: "Diameter of the test circle, mm",
      MAX_SPEED: "Highest tested speed, mm/s",
      SPEED_INCREMENT: "Speed step, mm/s",
      ACCEL: "Acceleration, mm/s²",
      SPEED: "Speed of the test moves, mm/s",
      FREQUENCY: "Excitation frequency, Hz",
      DURATION: "Duration, s",
      CREATE_GRAPH: "1 — record the accelerometer and create a graph"
    },
    block: {
      klippy: "Klipper is not ready.",
      running: "A Shake&Tune test is running.",
      printing: "The printer is printing.",
      homing: "Axes are not homed (xyz).",
      kinematics: "This test does not support {kinematics} kinematics.",
      invalid: "Invalid values: {fields}"
    },
    run: {
      run: "Run",
      running: "Running…",
      home: "Home all (G28)",
      duration: "usually {minutes} min",
      started: "Started…",
      external: "started elsewhere",
      log: "Console ({count} lines)"
    },
    rec: {
      performance: "Performance",
      lowVibrations: "Low vibrations",
      best: "Best"
    },
    result: {
      shaperTitle: "Recommended shapers",
      axis: "Axis",
      recommendation: "For",
      shaper: "Shaper",
      freq: "Hz",
      damping: "Damping",
      peaks: "peaks {peaks}",
      includeDamping: "Also set the measured damping ratio",
      apply: "Apply",
      copyConfig: "Copy for printer.cfg",
      applyHint: "Apply works until the next restart; SAVE_CONFIG does not keep it.",
      beltsTitle: "Belts",
      similarity: "Similarity",
      health: "Mechanical health",
      beltsHint: "Similar belts give overlapping curves on the graph; adjust the tension and run again.",
      vibrationsTitle: "Vibrations profile",
      symmetry: "Symmetry",
      vibPeaks: "peaks at {peaks}",
      lowSpeeds: "Lowest vibration speeds",
      lowAngles: "Lowest vibration angles",
      motor: "Motor resonance: {value}",
      axesMapTitle: "Accelerometer axes map",
      detected: "Detected",
      axesMapOk: "Your axes_map is already correct.",
      axesMapMismatch: "Your axes_map does not match: update the accelerometer section of printer.cfg.",
      copyAxesMap: "Copy axes_map",
      excitateTitle: "Excitation",
      excitate: "Axis {axis} at {freq} Hz for {seconds} s"
    },
    results: {
      title: "Results",
      empty: "No graphs yet.",
      new: "new",
      outsideConfig: "result_folder is outside Moonraker’s config root: its graphs cannot be shown here."
    },
    folder: {
      all: "All",
      input_shaper: "Shaper",
      belts: "Belts",
      vibrations: "Vibrations",
      axes_map: "Axes map",
      static_freq: "Static freq."
    },
    guard: {
      printing: "Shake&Tune tests cannot run while printing",
      homing: "Home all axes before a Shake&Tune test"
    }
  }
}, ot = {
  shaketune: {
    title: "Shake&Tune",
    common: {
      loading: "Загрузка…",
      refresh: "Обновить",
      default: "по умолчанию",
      noPrinter: "Нет активного принтера",
      configError: "Не удалось прочитать конфиг принтера. Klipper готов?",
      notInstalled: "Секции [shaketune] больше нет в конфиге принтера. Нажмите правой кнопкой на вкладку и выберите «Оригинал».",
      copied: "Скопировано",
      copyManually: "Скопируйте текст:"
    },
    help: {
      title: "Справка",
      switchTitle: "Shake&Tune или Klipper",
      switch: "Эта вкладка заменяет вкладку Input Shaper калибровок, пока на принтере настроен Shake&Tune. Правый клик по вкладке (долгое нажатие на тач-экране) переключает между Shake&Tune и штатными инструментами Klipper (SHAPER_CALIBRATE); выбор запоминается для каждого принтера.",
      runTitle: "Запуск теста",
      run: "Выберите команду и заполните только те параметры, которые хотите изменить — пустые поля берут значения Shake&Tune по умолчанию или из [resonance_tester]. Оси должны быть припаркованы, принтер не должен печатать. Тест идёт минуты; со вкладки можно уйти — он продолжится в Klipper и подхватится, когда вы вернётесь.",
      applyTitle: "Применить или printer.cfg",
      apply: "«Применить» отправляет SET_INPUT_SHAPER: новый шейпер работает сразу, но пропадает после перезапуска, и SAVE_CONFIG его не сохраняет. Чтобы оставить его, скопируйте блок [input_shaper] в printer.cfg.",
      resultsTitle: "Результаты",
      results: "Графики читаются из result_folder Shake&Tune (по умолчанию config/ShakeTune_results). Shake&Tune хранит только последние number_of_results_to_keep графиков каждого типа. Графики последнего прогона помечены «новый»."
    },
    command: {
      label: "Команда",
      shaper: "Шейперы",
      belts: "Ремни",
      vibrations: "Вибрации",
      axesMap: "Оси акселерометра",
      excitate: "Возбуждение оси"
    },
    commandHint: {
      shaper: "AXES_SHAPER_CALIBRATION — резонансы X и Y, рекомендованные шейперы для производительности и для низких вибраций.",
      belts: "COMPARE_BELTS_RESPONSES — сравнивает два ремня CoreXY/CoreXZ для проверки натяжения.",
      vibrations: "CREATE_VIBRATIONS_PROFILE — вибрации по скоростям и направлениям; находит спокойные скорости и углы. Нужен настроенный input shaper.",
      axesMap: "AXES_MAP_CALIBRATION — определяет ориентацию акселерометра (axes_map).",
      excitate: "EXCITATE_AXIS_AT_FREQ — трясёт ось на одной частоте, чтобы найти, что резонирует."
    },
    param: {
      AXIS: "Тестируемая ось",
      FREQ_START: "Начальная частота, Гц",
      FREQ_END: "Конечная частота, Гц",
      HZ_PER_SEC: "Скорость развёртки, Гц в секунду",
      ACCEL_PER_HZ: "Ускорение на Гц, мм/с² (по умолчанию из [resonance_tester])",
      SCV: "Square corner velocity для рекомендаций",
      MAX_SMOOTHING: "Максимально допустимое сглаживание рекомендуемого шейпера",
      TRAVEL_SPEED: "Скорость переезда к точке теста, мм/с",
      Z_HEIGHT: "Z точки теста, мм",
      MAX_SCALE: "Фиксированный масштаб энергии графика, чтобы сравнивать прогоны",
      ACCEL_CHIP: "Акселерометр (по умолчанию выбирается автоматически)",
      SIZE: "Диаметр тестового круга, мм",
      MAX_SPEED: "Максимальная тестируемая скорость, мм/с",
      SPEED_INCREMENT: "Шаг скорости, мм/с",
      ACCEL: "Ускорение, мм/с²",
      SPEED: "Скорость тестовых движений, мм/с",
      FREQUENCY: "Частота возбуждения, Гц",
      DURATION: "Длительность, с",
      CREATE_GRAPH: "1 — записать акселерометр и построить график"
    },
    block: {
      klippy: "Klipper не готов.",
      running: "Идёт тест Shake&Tune.",
      printing: "Принтер печатает.",
      homing: "Оси не припаркованы (xyz).",
      kinematics: "Этот тест не поддерживает кинематику {kinematics}.",
      invalid: "Неверные значения: {fields}"
    },
    run: {
      run: "Запустить",
      running: "Выполняется…",
      home: "Парковка (G28)",
      duration: "обычно {minutes} мин",
      started: "Запущено…",
      external: "запущено не отсюда",
      log: "Консоль ({count} строк)"
    },
    rec: {
      performance: "Производительность",
      lowVibrations: "Низкие вибрации",
      best: "Лучший"
    },
    result: {
      shaperTitle: "Рекомендованные шейперы",
      axis: "Ось",
      recommendation: "Для",
      shaper: "Шейпер",
      freq: "Гц",
      damping: "Демпфирование",
      peaks: "пики {peaks}",
      includeDamping: "Также задать измеренный коэффициент демпфирования",
      apply: "Применить",
      copyConfig: "Копировать для printer.cfg",
      applyHint: "«Применить» действует до перезапуска; SAVE_CONFIG это не сохраняет.",
      beltsTitle: "Ремни",
      similarity: "Сходство",
      health: "Механическое состояние",
      beltsHint: "У одинаково натянутых ремней кривые на графике совпадают; подтяните ремень и запустите снова.",
      vibrationsTitle: "Профиль вибраций",
      symmetry: "Симметрия",
      vibPeaks: "пики на {peaks}",
      lowSpeeds: "Скорости с наименьшими вибрациями",
      lowAngles: "Углы с наименьшими вибрациями",
      motor: "Резонанс моторов: {value}",
      axesMapTitle: "Оси акселерометра (axes_map)",
      detected: "Определено",
      axesMapOk: "axes_map уже настроен правильно.",
      axesMapMismatch: "axes_map не совпадает: обновите секцию акселерометра в printer.cfg.",
      copyAxesMap: "Копировать axes_map",
      excitateTitle: "Возбуждение",
      excitate: "Ось {axis} на {freq} Гц в течение {seconds} с"
    },
    results: {
      title: "Результаты",
      empty: "Графиков пока нет.",
      new: "новый",
      outsideConfig: "result_folder находится вне корня config Moonraker: его графики здесь показать нельзя."
    },
    folder: {
      all: "Все",
      input_shaper: "Шейперы",
      belts: "Ремни",
      vibrations: "Вибрации",
      axes_map: "Оси",
      static_freq: "Стат. частота"
    },
    guard: {
      printing: "Тесты Shake&Tune нельзя запускать во время печати",
      homing: "Перед тестом Shake&Tune припаркуйте все оси"
    }
  }
};
class lt extends G {
  render() {
    return d;
  }
}
const He = [
  "input_shaper",
  "belts",
  "vibrations",
  "axes_map",
  "static_freq"
], ye = { key: "FREQ_START", type: "number", placeholder: "", min: 1 }, _e = { key: "FREQ_END", type: "number", placeholder: "", min: 1 }, ve = { key: "HZ_PER_SEC", type: "number", placeholder: "1", min: 1 }, X = { key: "ACCEL_PER_HZ", type: "number", placeholder: "" }, S = { key: "TRAVEL_SPEED", type: "number", placeholder: "120", min: 20 }, B = { key: "Z_HEIGHT", type: "number", placeholder: "", min: 1 }, ke = { key: "MAX_SCALE", type: "int", placeholder: "", min: 1 }, I = { key: "ACCEL_CHIP", type: "chip" }, ct = /^(adxl345|lis2dw|lis3dh|mpu9250|icm20948|beacon)(\s|$)/i;
function ht(i) {
  return i.filter((e) => ct.test(e));
}
const M = [
  {
    id: "shaper",
    gcode: "AXES_SHAPER_CALIBRATION",
    folder: "input_shaper",
    minutes: "2–5",
    params: [
      { key: "AXIS", type: "select", options: ["all", "x", "y"] },
      ye,
      _e,
      ve,
      X,
      { key: "SCV", type: "number", placeholder: "", min: 0 },
      { key: "MAX_SMOOTHING", type: "number", placeholder: "", min: 0 },
      S,
      B,
      ke,
      I
    ]
  },
  {
    id: "belts",
    gcode: "COMPARE_BELTS_RESPONSES",
    folder: "belts",
    minutes: "2–4",
    kinematics: ["corexy", "corexz", "limited_corexy", "limited_corexz"],
    params: [ye, _e, ve, X, S, B, ke, I]
  },
  {
    id: "vibrations",
    gcode: "CREATE_VIBRATIONS_PROFILE",
    folder: "vibrations",
    minutes: "10–30",
    kinematics: ["cartesian", "corexy", "corexz", "limited_cartesian", "limited_corexy", "limited_corexz"],
    params: [
      { key: "SIZE", type: "number", placeholder: "100", min: 50 },
      { key: "Z_HEIGHT", type: "number", placeholder: "20", min: 1 },
      { key: "MAX_SPEED", type: "number", placeholder: "200", min: 10 },
      { key: "SPEED_INCREMENT", type: "number", placeholder: "2", min: 1 },
      { key: "ACCEL", type: "int", placeholder: "3000", min: 100 },
      S,
      I
    ]
  },
  {
    id: "axesMap",
    gcode: "AXES_MAP_CALIBRATION",
    folder: "axes_map",
    minutes: "1",
    params: [
      { key: "Z_HEIGHT", type: "number", placeholder: "20", min: 1 },
      { key: "SPEED", type: "number", placeholder: "80", min: 20 },
      { key: "ACCEL", type: "int", placeholder: "1500", min: 100 },
      S
    ]
  },
  {
    id: "excitate",
    gcode: "EXCITATE_AXIS_AT_FREQ",
    folder: "static_freq",
    minutes: "1",
    params: [
      { key: "AXIS", type: "select", options: ["x", "y", "a", "b"] },
      { key: "FREQUENCY", type: "number", placeholder: "25", min: 1 },
      { key: "DURATION", type: "int", placeholder: "30", min: 1 },
      { key: "CREATE_GRAPH", type: "select", options: ["0", "1"] },
      X,
      S,
      B,
      I
    ]
  }
];
function O(i) {
  return M.find((e) => e.id === i) ?? M[0];
}
const se = new Set(
  M.flatMap((i) => [i.gcode, `_${i.gcode}`])
);
function V(i, e) {
  const t = [i.gcode], s = [];
  for (const n of i.params) {
    const r = (e[n.key] ?? "").trim();
    if (r === "") continue;
    if (n.type === "select") {
      n.options?.includes(r) ? t.push(`${n.key}=${r}`) : s.push(n.key);
      continue;
    }
    if (n.type === "chip") {
      /["\r\n]/.test(r) ? s.push(n.key) : t.push(/\s/.test(r) ? `${n.key}="${r}"` : `${n.key}=${r}`);
      continue;
    }
    const a = Number(r);
    Number.isFinite(a) && (n.type !== "int" || Number.isInteger(a)) && (n.min === void 0 || a >= n.min) && (n.max === void 0 || a <= n.max) ? t.push(`${n.key}=${a}`) : s.push(n.key);
  }
  return { script: t.join(" "), invalid: s };
}
function pt(i) {
  const e = [];
  for (const t of i.split(/\r?\n/)) {
    const s = t.trim();
    !s || s.startsWith(";") || s.startsWith("#") || e.push(s.split(/\s+/)[0].toUpperCase());
  }
  return e;
}
const dt = "~/printer_data/config/ShakeTune_results";
function ut(i) {
  const e = (i || dt).replace(/\\/g, "/").replace(/\/+$/, ""), t = /(?:^|\/)(?:printer_data\/config|klipper_config)\/(.+)$/.exec(e);
  return t ? t[1] : null;
}
function mt(i) {
  return /\.png$/i.test(i) && !i.startsWith("snt_tmp");
}
function ft(i) {
  const e = /_axis_([XY])\.png$/i.exec(i);
  return e ? e[1].toUpperCase() : null;
}
async function gt(i, e) {
  return (await Promise.all(
    He.map(async (s) => {
      try {
        return ((await i.request("server.files.get_directory", {
          path: `config/${e}/${s}`,
          extended: !1
        }))?.files ?? []).filter((r) => typeof r.filename == "string" && mt(r.filename)).map((r) => ({
          path: `${e}/${s}/${r.filename}`,
          folder: s,
          name: r.filename,
          modified: Number(r.modified ?? 0),
          axis: ft(r.filename)
        }));
      } catch {
        return [];
      }
    })
  )).flat().sort((s, n) => n.modified - s.modified);
}
async function bt(i, e) {
  const t = {};
  i.authToken && (t.Authorization = `Bearer ${i.authToken}`);
  const s = e.split("/").map(encodeURIComponent).join("/"), n = await fetch(`${i.httpBaseUrl}/server/files/config/${s}`, { headers: t, cache: "no-store" });
  if (!n.ok) throw new Error(`HTTP ${n.status}`);
  return URL.createObjectURL(await n.blob());
}
const ie = ["X", "Y"];
function ne(i, e) {
  return i.find((t) => t.kind === e) ?? i.find((t) => t.kind === "performance") ?? i[0] ?? null;
}
function xe(i, e, t) {
  const s = [];
  for (const n of ie) {
    const r = ne(i.shaper[n]?.recs ?? [], e[n]);
    r && (s.push(`SHAPER_TYPE_${n}=${r.name}`, `SHAPER_FREQ_${n}=${r.freq}`), t && r.damping !== null && s.push(`DAMPING_RATIO_${n}=${r.damping}`));
  }
  return s.length ? `SET_INPUT_SHAPER ${s.join(" ")}` : null;
}
function $t(i, e, t) {
  const s = ["[input_shaper]"];
  for (const n of ie) {
    const r = ne(i.shaper[n]?.recs ?? [], e[n]);
    if (!r) continue;
    const a = n.toLowerCase();
    s.push(`shaper_type_${a}: ${r.name}`, `shaper_freq_${a}: ${r.freq}`), t && r.damping !== null && s.push(`damping_ratio_${a}: ${r.damping}`);
  }
  return s.join(`
`);
}
function Ne(i, e, t, s) {
  return h`<button class="btn" @click=${() => i.onCopy(e, t)}>
    ${i.copied === t ? i.t("shaketune.common.copied") : i.t(s)}
  </button>`;
}
function yt(i, e) {
  const t = ie.filter((n) => (i.shaper[n]?.recs.length ?? 0) > 0);
  if (t.length === 0) return d;
  const s = t.some((n) => i.shaper[n].recs.some((r) => r.damping !== null));
  return h`
    <div class="card">
      <h4>${e.t("shaketune.result.shaperTitle")}</h4>
      <table>
        <thead>
          <tr>
            <th>${e.t("shaketune.result.axis")}</th>
            <th>${e.t("shaketune.result.recommendation")}</th>
            <th>${e.t("shaketune.result.shaper")}</th>
            <th>${e.t("shaketune.result.freq")}</th>
            <th>${e.t("shaketune.result.damping")}</th>
          </tr>
        </thead>
        <tbody>
          ${t.flatMap((n) => {
    const r = i.shaper[n].recs, a = ne(r, e.pick[n]);
    return r.map(
      (l) => h`
                <tr>
                  <td>${n}</td>
                  <td>
                    <label class="row">
                      <input
                        type="radio"
                        name=${`pick-${n}`}
                        .checked=${l === a}
                        @change=${() => e.onPick(n, l.kind)}
                      />
                      ${e.t(`shaketune.rec.${l.kind}`)}
                    </label>
                  </td>
                  <td class="mono">${l.name.toUpperCase()}</td>
                  <td class="mono">${l.freq.toFixed(1)}</td>
                  <td class="mono">${l.damping !== null ? l.damping.toFixed(3) : "—"}</td>
                </tr>
              `
    );
  })}
        </tbody>
      </table>
      ${t.map(
    (n) => i.shaper[n].peaks ? h`<p class="muted">${n}: ${e.t("shaketune.result.peaks", { peaks: i.shaper[n].peaks })}</p>` : d
  )}
      <div class="row">
        ${s ? h`<label class="row muted">
              <input type="checkbox" .checked=${e.damping} @change=${(n) => e.onDamping(n.target.checked)} />
              ${e.t("shaketune.result.includeDamping")}
            </label>` : d}
      </div>
      <div class="row">
        <button class="btn primary" ?disabled=${!e.canApply} @click=${e.onApply}>${e.t("shaketune.result.apply")}</button>
        ${Ne(e, $t(i, e.pick, e.damping), "shaper", "shaketune.result.copyConfig")}
      </div>
      <p class="muted">${e.t("shaketune.result.applyHint")}</p>
    </div>
  `;
}
function _t(i, e) {
  return !i.belts || i.belts.similarity === null && !i.belts.health ? d : h`
    <div class="card">
      <h4>${e.t("shaketune.result.beltsTitle")}</h4>
      ${i.belts.similarity !== null ? h`<p>${e.t("shaketune.result.similarity")}: <strong class="mono">${i.belts.similarity.toFixed(1)}%</strong></p>` : d}
      ${i.belts.health ? h`<p>${e.t("shaketune.result.health")}: <strong>${i.belts.health}</strong></p>` : d}
      <p class="muted">${e.t("shaketune.result.beltsHint")}</p>
    </div>
  `;
}
function vt(i, e) {
  const t = i.vibrations;
  return !t || t.symmetry === null && !t.speeds.length && !t.motor ? d : h`
    <div class="card">
      <h4>${e.t("shaketune.result.vibrationsTitle")}</h4>
      ${t.symmetry !== null ? h`<p>${e.t("shaketune.result.symmetry")}: <strong class="mono">${t.symmetry.toFixed(1)}%</strong></p>` : d}
      ${t.peaks ? h`<p class="muted">${e.t("shaketune.result.vibPeaks", { peaks: t.peaks })}</p>` : d}
      ${t.speeds.length ? h`<p>${e.t("shaketune.result.lowSpeeds")}:</p><ul>${t.speeds.map((s) => h`<li class="mono">${s}</li>`)}</ul>` : d}
      ${t.angles.length ? h`<p>${e.t("shaketune.result.lowAngles")}:</p><ul>${t.angles.map((s) => h`<li class="mono">${s}</li>`)}</ul>` : d}
      ${t.motor ? h`<p class="muted">${e.t("shaketune.result.motor", { value: t.motor })}</p>` : d}
    </div>
  `;
}
function kt(i, e) {
  const t = i.axesMap;
  if (!t || !t.detected && t.ok === null) return d;
  const s = t.suggestion ?? t.detected;
  return h`
    <div class="card">
      <h4>${e.t("shaketune.result.axesMapTitle")}</h4>
      ${t.detected ? h`<p>${e.t("shaketune.result.detected")}: <strong class="mono">${t.detected}</strong></p>` : d}
      ${t.ok === !0 ? h`<p class="ok">${e.t("shaketune.result.axesMapOk")}</p>` : d}
      ${t.ok === !1 ? h`<p class="warn">${e.t("shaketune.result.axesMapMismatch")}</p>` : d}
      ${s && t.ok !== !0 ? h`<div class="row">${Ne(e, `axes_map: ${s}`, "axes", "shaketune.result.copyAxesMap")}</div>` : d}
    </div>
  `;
}
function xt(i, e) {
  return i.excitate ? h`
    <div class="card">
      <h4>${e.t("shaketune.result.excitateTitle")}</h4>
      <p class="mono">
        ${e.t("shaketune.result.excitate", { axis: i.excitate.axis.toUpperCase(), freq: i.excitate.freq, seconds: i.excitate.seconds })}
      </p>
    </div>
  ` : d;
}
function Et(i, e) {
  return h`${yt(i, e)}${_t(i, e)}${vt(i, e)}${kt(i, e)}${xt(i, e)}`;
}
function re() {
  return {
    version: null,
    kind: null,
    running: !1,
    graphsCreated: !1,
    error: null,
    progress: null,
    shaper: {},
    belts: null,
    vibrations: null,
    axesMap: null,
    excitate: null
  };
}
const At = {
  "input shaper": "shaper",
  "belts comparison": "belts",
  "vibrations profile": "vibrations",
  "axes map": "axesMap",
  "static frequency": "excitate"
}, ae = /^Shake&Tune version:\s*(\S+)/i, St = /^(.+?) graphs created successfully!?/i, wt = /^Timeout:/i, Tt = /^Error[: ]/i, Ct = /^Measuring axis_([XY])\b|^([XY]) axis frequency profile generation/i, Rt = /(For performance|For low vibrations|Best shaper):\s*(\w+)\s*@\s*([\d.]+)\s*Hz(?:\s*\(with a damping ratio of ([\d.]+)\))?/i, Pt = /^Peaks detected on the graph:\s*(.+)$/i, Mt = /square corner velocity of ([\d.]+)/i, Ht = /^Measuring belt_|kinematics mode$|^Belts comparative/i, Nt = /^Belts estimated similarity:\s*([\d.]+)\s*%/i, It = /^Mechanical health:\s*(.+)$/i, Ot = /^-> Measuring angle|^Current speed:|^Machine vibrations profile generation/i, Lt = /vibration symmetry:\s*([\d.]+)\s*%/i, Ut = /^Vibrations peaks detected:\s*(.+)$/i, zt = /^Lowest vibrations speeds/i, Dt = /^Lowest vibrations angles/i, qt = /^\d+:\s*(.+)$/, Ft = /^Motors have a main resonant frequency at (.+)$/i, Xt = /^Analysis of the movements|^Machine axis /i, Bt = /Detected axes_map:\s*(\S+)/i, Vt = /axes_map configuration is already correct/i, jt = /update your configuration to\s*(\S+?)\.?$/i, Gt = /^Excitating (\w+) axis at ([\d.]+)\s*Hz for (\d+) seconds/i;
function Zt(i) {
  const e = Array.isArray(i) ? i : [i], t = [];
  for (const s of e)
    if (typeof s == "string")
      for (const n of s.split(/\r?\n/)) {
        const r = n.trim();
        r && t.push(r);
      }
  return t;
}
function oe(i) {
  return i.startsWith("!!") ? { text: i.replace(/^!!\s*/, ""), error: !0 } : { text: i.replace(/^\/\/\s*/, ""), error: !1 };
}
function Kt(i) {
  const e = i.toLowerCase();
  return e.includes("performance") ? "performance" : e.includes("low") ? "lowVibrations" : "best";
}
function Z(i) {
  const { text: e } = oe(i);
  if (ae.test(e)) return !0;
  const t = e.split(/\s+/)[0]?.toUpperCase() ?? "";
  return se.has(t);
}
function Yt(i) {
  for (let e = i.length - 1; e >= 0; e--) {
    if (!Z(i[e])) continue;
    let t = e;
    return e > 0 && ae.test(oe(i[e]).text) && Z(i[e - 1]) && (t = e - 1), i.slice(t);
  }
  return [];
}
function z(i) {
  const e = re();
  let t = null, s = null;
  const n = (l) => {
    e.running = !0, e.error = null, l && (e.kind = l);
  }, r = () => e.vibrations ??= { symmetry: null, peaks: null, speeds: [], angles: [], motor: null }, a = (l) => e.shaper[l] ??= { recs: [], peaks: null, scv: null };
  for (const l of i) {
    const { text: o, error: p } = oe(l);
    if (!o) continue;
    const u = o.split(/\s+/)[0]?.toUpperCase() ?? "";
    if (se.has(u)) {
      n(null);
      continue;
    }
    if (p) {
      e.error = o, e.running = !1;
      continue;
    }
    let c;
    if (c = ae.exec(o)) {
      e.version = c[1], n(null);
      continue;
    }
    if (c = St.exec(o)) {
      const m = At[c[1].toLowerCase()];
      m && (e.kind = m), e.graphsCreated = !0, e.running = !1;
      continue;
    }
    if (wt.test(o) || Tt.test(o)) {
      e.error = o, e.running = !1;
      continue;
    }
    if (c = Ct.exec(o)) {
      t = (c[1] ?? c[2]).toUpperCase(), a(t), n("shaper"), e.progress = o;
      continue;
    }
    if (c = Rt.exec(o)) {
      a(t ?? "X").recs.push({
        kind: Kt(c[1]),
        name: c[2].toLowerCase(),
        freq: Number(c[3]),
        damping: c[4] !== void 0 ? Number(c[4]) : null
      }), e.kind ??= "shaper";
      continue;
    }
    if (c = Pt.exec(o)) {
      t && (a(t).peaks = c[1]);
      continue;
    }
    if (c = Mt.exec(o)) {
      t && (a(t).scv = Number(c[1]));
      continue;
    }
    if (Ht.test(o)) {
      n("belts"), e.belts ??= { similarity: null, health: null }, e.progress = o;
      continue;
    }
    if (c = Nt.exec(o)) {
      (e.belts ??= { similarity: null, health: null }).similarity = Number(c[1]), e.kind ??= "belts";
      continue;
    }
    if (c = It.exec(o)) {
      (e.belts ??= { similarity: null, health: null }).health = c[1];
      continue;
    }
    if (Ot.test(o)) {
      n("vibrations"), r(), e.progress = o, s = null;
      continue;
    }
    if (c = Lt.exec(o)) {
      r().symmetry = Number(c[1]), e.kind ??= "vibrations";
      continue;
    }
    if (c = Ut.exec(o)) {
      r().peaks = c[1];
      continue;
    }
    if (zt.test(o)) {
      s = "speeds";
      continue;
    }
    if (Dt.test(o)) {
      s = "angles";
      continue;
    }
    if (s && (c = qt.exec(o))) {
      r()[s].push(c[1]);
      continue;
    }
    if (c = Ft.exec(o)) {
      r().motor = c[1];
      continue;
    }
    if (Xt.test(o)) {
      n("axesMap"), e.axesMap ??= { detected: null, ok: null, suggestion: null }, e.progress = o;
      continue;
    }
    if (c = Bt.exec(o)) {
      (e.axesMap ??= { detected: null, ok: null, suggestion: null }).detected = c[1], e.kind ??= "axesMap";
      continue;
    }
    if (Vt.test(o)) {
      (e.axesMap ??= { detected: null, ok: null, suggestion: null }).ok = !0;
      continue;
    }
    if (c = jt.exec(o)) {
      const m = e.axesMap ??= { detected: null, ok: null, suggestion: null };
      m.ok = !1, m.suggestion = c[1];
      continue;
    }
    if (c = Gt.exec(o)) {
      n("excitate"), e.excitate = { axis: c[1].toLowerCase(), freq: Number(c[2]), seconds: Number(c[3]) }, e.progress = o;
      continue;
    }
    e.running && (e.progress = o);
  }
  return e;
}
function Wt(i) {
  const e = i.shaketune;
  return {
    hasShakeTune: e !== void 0,
    resultsPath: ut(typeof e?.result_folder == "string" ? e.result_folder : null),
    kinematics: String(i.printer?.kinematics ?? "").toLowerCase(),
    chips: ht(Object.keys(i))
  };
}
async function Ie(i) {
  const e = await i.request(
    "printer.objects.query",
    { objects: { configfile: ["settings"] } }
  );
  return Wt(e?.status?.configfile?.settings ?? {});
}
function Qt() {
  return {
    lines: [],
    result: re(),
    busy: !1,
    external: !1,
    restored: !1,
    config: null,
    configError: !1,
    files: [],
    filesLoaded: !1,
    baseline: null,
    fresh: []
  };
}
const K = /* @__PURE__ */ new Map(), Y = /* @__PURE__ */ new Map();
function $(i) {
  let e = K.get(i);
  return e || (e = Qt(), K.set(i, e)), e;
}
function f(i, e) {
  K.set(i, { ...$(i), ...e });
  for (const t of Y.get(i) ?? []) t();
}
function Jt(i, e) {
  let t = Y.get(i);
  return t || (t = /* @__PURE__ */ new Set(), Y.set(i, t)), t.add(e), () => t.delete(e);
}
function es(i) {
  const e = $(i);
  f(i, {
    busy: !1,
    external: !1,
    result: { ...e.result, running: !1 },
    config: null
  });
}
function ts(i) {
  const e = $(i);
  f(i, {
    lines: [],
    result: { ...re(), running: !0 },
    busy: !0,
    external: !1,
    baseline: Object.fromEntries(e.files.map((t) => [t.path, t.modified])),
    fresh: []
  });
}
function ss(i, e) {
  const t = $(i), s = e ? [...t.lines, `!! ${e}`].slice(-300) : t.lines, n = z(s);
  f(i, { busy: !1, lines: s, result: { ...n, running: !1 } });
}
function is(i, e) {
  const t = $(i);
  let s = t.lines, n = t.external, r = t.busy || t.result.running, a = t.baseline, l = t.fresh;
  for (const p of e)
    !t.busy && Z(p) && !r && (s = [], n = !0, r = !0, a = Object.fromEntries(t.files.map((u) => [u.path, u.modified])), l = []), r && (s = [...s, p], !t.busy && !z(s).running && (r = !1));
  if (s === t.lines) return;
  s = s.slice(-300);
  const o = z(s);
  f(i, {
    lines: s,
    result: t.busy ? { ...o, running: !0 } : o,
    external: n && o.running,
    baseline: a,
    fresh: l
  });
}
const ns = 1800;
function rs(i, e, t = Date.now() / 1e3) {
  const s = $(i);
  if (s.restored || s.busy || s.lines.length > 0) {
    f(i, { restored: !0 });
    return;
  }
  const n = e.flatMap((p) => typeof p.message == "string" ? p.message.split(/\r?\n/) : []), r = Yt(n.map((p) => p.trim()).filter(Boolean)).slice(-300), a = z(r), l = Number(e[e.length - 1]?.time ?? 0), o = a.running && t - l < ns;
  f(i, {
    restored: !0,
    lines: r,
    result: { ...a, running: o },
    external: o
  });
}
function as(i, e) {
  const t = $(i), s = t.baseline, n = s ? e.filter((r) => s[r.path] === void 0 || r.modified > s[r.path]).map((r) => r.path) : t.fresh;
  f(i, { files: e, filesLoaded: !0, fresh: n });
}
class os {
  #e;
  #t = "";
  #s = null;
  #n = [];
  #i = null;
  /** Live printer status for the Run button (not kept in run-store: re-read on mount). */
  printState = "";
  homedAxes = "";
  klippyReady = !0;
  constructor(e) {
    this.#e = e, e.addController(this);
  }
  get printerId() {
    return this.#t;
  }
  get state() {
    return $(this.#t);
  }
  get isPrinting() {
    return this.printState === "printing" || this.printState === "paused";
  }
  get isHomed() {
    return this.homedAxes === "xyz";
  }
  hostConnected() {
    this.#r();
  }
  hostUpdate() {
    this.#s || this.#r();
  }
  hostDisconnected() {
    this.#l();
  }
  #r() {
    const e = this.#e.api;
    if (!e || this.#s || !this.#e.isConnected || (this.#n.push(
      e.onPrinterChange(() => {
        this.#l(), this.#r(), this.#e.requestUpdate();
      })
    ), !e.printer.id)) return;
    let t;
    try {
      t = e.moonraker();
    } catch {
      return;
    }
    this.#s = t, this.#t = e.printer.id;
    const s = this.#t;
    this.#n.push(Jt(s, () => this.#e.requestUpdate())), this.#n.push(
      t.subscribe(
        { print_stats: ["state"], toolhead: ["homed_axes"], webhooks: ["state"] },
        (n) => {
          n?.print_stats?.state !== void 0 && (this.printState = String(n.print_stats.state)), n?.toolhead?.homed_axes !== void 0 && (this.homedAxes = String(n.toolhead.homed_axes)), n?.webhooks?.state !== void 0 && (this.klippyReady = n.webhooks.state === "ready"), this.#e.requestUpdate();
        },
        { immediate: !0 }
      )
    ), this.#n.push(t.onNotify("notify_gcode_response", (n) => is(s, Zt(n)))), this.#n.push(
      t.onNotify("notify_filelist_changed", (n) => {
        const r = Array.isArray(n) ? n[0]?.item : void 0, a = this.state.config?.resultsPath;
        (!a || r?.root === "config" && String(r.path ?? "").startsWith(a)) && this.#o();
      })
    ), this.#n.push(
      t.onNotify("notify_klippy_ready", () => {
        es(s), this.#a();
      })
    ), this.#n.push(t.onNotify("notify_config_changed", () => void this.#a())), this.state.config ? this.#o(0) : this.#a(), this.state.restored || this.#c();
  }
  #l() {
    for (const e of this.#n) e();
    this.#n = [], this.#s = null, this.#i && clearTimeout(this.#i), this.#i = null;
  }
  async #a() {
    const e = this.#s, t = this.#t;
    if (e)
      try {
        const s = await Ie(e);
        f(t, { config: s, configError: !1 }), this.#o(0);
      } catch {
        f(t, { configError: !0 });
      }
  }
  async #c() {
    const e = this.#s, t = this.#t;
    if (e)
      try {
        const s = await e.request(
          "server.gcode_store",
          { count: 300 }
        );
        rs(t, s?.gcode_store ?? []);
      } catch {
        f(t, { restored: !0 });
      }
  }
  #o(e = 600) {
    this.#i && clearTimeout(this.#i), this.#i = setTimeout(() => {
      this.#i = null, this.refreshFiles();
    }, e);
  }
  async refreshFiles() {
    const e = this.#s, t = this.#t, s = this.state.config?.resultsPath;
    !e || !s || as(t, await gt(e, s));
  }
  /**
   * Sends one command and waits for it. `printer.gcode.script` resolves only
   * when Klipper has finished it — for Shake&Tune that includes computing the
   * graphs (it waits for its worker process), i.e. minutes; the host proxy has
   * no request timeout. Meanwhile the console lines arrive live.
   */
  async run(e) {
    const t = this.#s, s = this.#t;
    if (!t || this.state.busy) return;
    ts(s);
    let n;
    try {
      await t.request("printer.gcode.script", { script: e });
    } catch (r) {
      n = r instanceof Error ? r.message : String(r);
    } finally {
      ss(s, n), await this.refreshFiles();
    }
  }
  /** A short command that is not a test (SET_INPUT_SHAPER, G28): no run state. */
  async send(e) {
    if (!this.#s) return !1;
    try {
      return await this.#s.request("printer.gcode.script", { script: e }), !0;
    } catch (t) {
      return console.warn("[shaketune] command failed:", e, t), !1;
    }
  }
  get handle() {
    return this.#s;
  }
}
const ls = Le`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
    min-width: 0;
    color: var(--text-primary);
    font-family: var(--font-family, inherit);
    font-size: var(--font-size-md);
    /* Width-based layout: the page area, not the window, decides (sidebars). */
    container-type: inline-size;
  }

  .panel {
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-width: 0;
  }
  .panel-header {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-sm) var(--space-md);
    border-bottom: 1px solid var(--border-color);
  }
  .panel-title {
    flex: 1;
    min-width: 0;
    font-size: var(--font-size-md);
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .panel-body {
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    min-width: 0;
  }

  .row { display: flex; align-items: center; gap: var(--space-sm); flex-wrap: wrap; }
  .muted { color: var(--text-muted); font-size: var(--font-size-sm); margin: 0; }
  .warn { color: var(--warning); font-size: var(--font-size-sm); margin: 0; }
  .error { color: var(--danger); font-size: var(--font-size-sm); margin: 0; }
  .ok { color: var(--success); font-size: var(--font-size-sm); margin: 0; }
  .mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }

  .chip {
    padding: 1px 8px;
    border-radius: 999px;
    border: 1px solid var(--border-color);
    background: var(--bg-surface-hover);
    color: var(--text-secondary);
    font-size: var(--font-size-sm);
    white-space: nowrap;
  }
  .chip.accent { border-color: var(--accent); color: var(--accent); font-weight: 600; }

  /* Command selector + gallery filters: same look as Calibrations' .sel-btn. */
  .sel-row { display: flex; gap: var(--space-xs); flex-wrap: wrap; }
  .sel-btn {
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-secondary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
  }
  .sel-btn:hover:not(:disabled) { background: var(--bg-surface-hover); }
  .sel-btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .sel-btn.active { background: var(--bg-surface-active); color: var(--accent); border-color: var(--accent); }

  .fields {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    gap: var(--space-sm);
  }
  .field { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
  .field-label { font-size: var(--font-size-sm); color: var(--text-secondary); }
  .field.invalid .field-label { color: var(--danger); }
  input, select {
    min-width: 0;
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
  }
  .field.invalid input { border-color: var(--danger); }

  .gcode {
    display: block;
    padding: var(--space-xs) var(--space-sm);
    background: var(--bg-surface-hover-no-override, var(--bg-surface-hover));
    border: 1px dashed var(--border-color);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    white-space: pre-wrap;
    word-break: break-all;
    user-select: text;
  }

  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-xs);
    padding: var(--space-xs) var(--space-md);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: var(--bg-surface-hover);
    color: var(--text-primary);
    font: inherit;
    font-size: var(--font-size-sm);
    cursor: pointer;
    white-space: nowrap;
  }
  .btn:hover:not(:disabled) { background: var(--bg-surface-active); }
  .btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .btn.primary { background: var(--accent); border-color: var(--accent); color: var(--accent-text, #fff); }
  .btn:focus-visible, .sel-btn:focus-visible, .tile:focus-visible {
    outline: 2px solid var(--accent-ring, var(--accent));
    outline-offset: 1px;
  }
  .icon-btn {
    width: 28px;
    height: 28px;
    padding: 0;
    border: none;
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-muted);
    cursor: pointer;
    font-size: 15px;
    line-height: 1;
  }
  .icon-btn:hover { background: var(--bg-surface-hover); color: var(--text-primary); }

  .spinner {
    width: 12px;
    height: 12px;
    border: 2px solid currentColor;
    border-right-color: transparent;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    flex-shrink: 0;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  .card {
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    padding: var(--space-sm);
    display: flex;
    flex-direction: column;
    gap: var(--space-xs);
  }
  .card h4 { margin: 0; font-size: var(--font-size-sm); font-weight: 600; }

  table { width: 100%; border-collapse: collapse; font-size: var(--font-size-sm); }
  th, td { padding: var(--space-xs) var(--space-sm); text-align: start; border-bottom: 1px solid var(--border-color); }
  th { color: var(--text-muted); font-weight: 500; text-transform: uppercase; letter-spacing: 0.04em; }

  details.log summary { cursor: pointer; color: var(--text-secondary); font-size: var(--font-size-sm); }
  details.log pre {
    margin: var(--space-xs) 0 0;
    max-height: 200px;
    overflow: auto;
    padding: var(--space-sm);
    background: var(--bg-surface-hover);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    white-space: pre-wrap;
    word-break: break-word;
  }
  details.log pre .err { color: var(--danger); }

  details.help { position: relative; }
  details.help summary { list-style: none; }
  details.help summary::-webkit-details-marker { display: none; }
  .help-body {
    position: absolute;
    inset-inline-end: 0;
    top: calc(100% + 4px);
    z-index: 5;
    width: min(360px, calc(100cqw - 32px));
    max-height: 60vh;
    overflow: auto;
    padding: var(--space-sm) var(--space-md);
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-md, 0 4px 12px rgba(0, 0, 0, 0.15));
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
  }
  .help-body h4 { margin: var(--space-sm) 0 2px; color: var(--text-primary); font-size: var(--font-size-sm); }
  .help-body p { margin: 0; line-height: 1.45; }

  .gallery { display: flex; gap: var(--space-xs); flex-wrap: wrap; }
  .tile {
    display: flex;
    flex-direction: column;
    gap: 2px;
    align-items: flex-start;
    max-width: 230px;
    padding: var(--space-xs) var(--space-sm);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-secondary);
    font: inherit;
    font-size: 11px;
    cursor: pointer;
  }
  .tile:hover { background: var(--bg-surface-hover); }
  .tile.active { border-color: var(--accent); color: var(--accent); }
  .tile.fresh { border-style: dashed; border-color: var(--accent); }
  .tile-name { max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .tag {
    padding: 0 5px;
    border-radius: 4px;
    background: var(--bg-surface-active);
    color: var(--accent);
    font-size: 10px;
    font-weight: 600;
  }
  .tag.new { background: var(--accent); color: var(--accent-text, #fff); }

  .preview {
    max-width: 100%;
    max-height: min(520px, 70dvh);
    object-fit: contain;
    align-self: flex-start;
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    background: #fff; /* Shake&Tune graphs are drawn on white */
    cursor: zoom-in;
  }

  /*
   * Lightbox: a native <dialog> opened with showModal() lives in the browser's
   * TOP LAYER. That matters here: the Calibrations page is a size container
   * (container-type), which makes it the containing block of position:fixed
   * descendants — a fixed div of ours would be clipped to the page area.
   * The top layer is above everything regardless of ancestors.
   */
  dialog {
    padding: 0;
    border: none;
    border-radius: var(--radius-lg);
    background: #fff;
    max-width: 96vw;
    max-height: 94vh;
    overflow: auto;
  }
  dialog::backdrop { background: var(--bg-overlay, rgba(0, 0, 0, 0.6)); }
  dialog img { display: block; }
  dialog img.fit { max-width: 94vw; max-height: 92vh; object-fit: contain; cursor: zoom-in; }
  dialog img.full { cursor: zoom-out; }

  @container (max-width: 480px) {
    .panel-body { padding: var(--space-sm); }
    .fields { grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); }
  }
  @media (pointer: coarse) {
    .icon-btn { width: 36px; height: 36px; }
    .sel-btn, .btn { min-height: 36px; }
  }
`;
class cs extends G {
  static styles = ls;
  static properties = {
    ...G.properties,
    command: { state: !0 },
    values: { state: !0 },
    filter: { state: !0 },
    damping: { state: !0 },
    pick: { state: !0 },
    selected: { state: !0 },
    previewUrl: { state: !0 },
    full: { state: !0 },
    copied: { state: !0 }
  };
  #e = new os(this);
  /** Printer whose settings are loaded into the fields. */
  #t = "";
  #s = null;
  constructor() {
    super(), this.command = "shaper", this.values = {}, this.filter = "all", this.damping = !1, this.pick = {}, this.selected = null, this.previewUrl = null, this.full = !1, this.copied = null;
  }
  willUpdate(e) {
    super.willUpdate(e);
    const t = this.#e.printerId;
    this.api && t && t !== this.#t && (this.#t = t, this.#n());
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.#h(), this.#t = "";
  }
  #n() {
    const e = this.api.settings, t = e.get("command");
    this.command = M.some((s) => s.id === t) ? t : "shaper", this.values = e.get("values") ?? {}, this.filter = e.get("filter") ?? "all", this.damping = e.get("damping") ?? !1;
  }
  #i(e, t) {
    this.api?.settings.set(e, t);
  }
  // ---------------------------------------------------------------- actions
  #r(e) {
    this.command = e, this.#i("command", e);
  }
  #l(e, t) {
    const s = { ...this.values[this.command] ?? {}, [e]: t };
    this.values = { ...this.values, [this.command]: s }, this.#i("values", this.values);
  }
  #a(e) {
    this.filter = e, this.#i("filter", e);
  }
  async #c() {
    const e = V(O(this.command), this.values[this.command] ?? {});
    e.invalid.length || this.#p() || (this.pick = {}, await this.#e.run(e.script));
  }
  async #o() {
    const e = xe(this.#e.state.result, this.pick, this.damping);
    e && await this.#e.send(e);
  }
  async #d(e, t) {
    try {
      await navigator.clipboard.writeText(e);
    } catch {
      window.prompt(this.t("shaketune.common.copyManually"), e);
      return;
    }
    this.copied = t, this.#s && clearTimeout(this.#s), this.#s = setTimeout(() => this.copied = null, 1500);
  }
  async #u(e) {
    const t = this.#e.handle;
    if (t) {
      this.#h(), this.selected = e.path;
      try {
        const s = await bt(t, e.path);
        this.selected === e.path ? this.previewUrl = s : URL.revokeObjectURL(s);
      } catch (s) {
        console.warn("[shaketune] graph load failed:", e.path, s);
      }
    }
  }
  #h() {
    this.previewUrl && URL.revokeObjectURL(this.previewUrl), this.previewUrl = null;
  }
  #m() {
    this.full = !1, this.renderRoot.querySelector("dialog")?.showModal();
  }
  /** Why Run is not possible now, or null. Our own requests skip our guard (see guard.ts), so we check here. */
  #p() {
    const e = this.#e, t = O(this.command);
    if (!e.klippyReady) return this.t("shaketune.block.klippy");
    if (e.state.busy || e.state.result.running) return this.t("shaketune.block.running");
    if (e.isPrinting) return this.t("shaketune.block.printing");
    if (!e.isHomed) return this.t("shaketune.block.homing");
    const s = e.state.config?.kinematics;
    return t.kinematics && s && !t.kinematics.includes(s) ? this.t("shaketune.block.kinematics", { kinematics: s }) : null;
  }
  // ---------------------------------------------------------------- render
  render() {
    const e = this.#e.state;
    return !this.api || !this.#e.printerId ? h`<p class="muted">${this.t("shaketune.common.noPrinter")}</p>` : e.config ? e.config.hasShakeTune ? h`${this.#b()}${this.#$()}` : h`<section class="panel"><div class="panel-body">
        <p class="warn">${this.t("shaketune.common.notInstalled")}</p>
      </div></section>` : h`<section class="panel"><div class="panel-body">
        <p class="muted">${e.configError ? this.t("shaketune.common.configError") : this.t("shaketune.common.loading")}</p>
      </div></section>`;
  }
  #f() {
    return h`
      <details class="help">
        <summary class="icon-btn" title=${this.t("shaketune.help.title")} aria-label=${this.t("shaketune.help.title")}>?</summary>
        <div class="help-body">
          <h4>${this.t("shaketune.help.switchTitle")}</h4>
          <p>${this.t("shaketune.help.switch")}</p>
          <h4>${this.t("shaketune.help.runTitle")}</h4>
          <p>${this.t("shaketune.help.run")}</p>
          <h4>${this.t("shaketune.help.applyTitle")}</h4>
          <p>${this.t("shaketune.help.apply")}</p>
          <h4>${this.t("shaketune.help.resultsTitle")}</h4>
          <p>${this.t("shaketune.help.results")}</p>
        </div>
      </details>
    `;
  }
  #g(e) {
    const t = O(this.command), s = t.params.find((u) => u.key === e), n = this.values[this.command]?.[e] ?? "", a = V(t, this.values[this.command] ?? {}).invalid.includes(e), l = this.#e.state.busy, o = (u) => this.#l(e, u.target.value);
    let p;
    if (s.type === "select" || s.type === "chip") {
      const u = s.type === "chip" ? this.#e.state.config?.chips ?? [] : s.options ?? [];
      p = h`<select .value=${n} ?disabled=${l} @change=${o}>
        <option value="">${this.t("shaketune.common.default")}</option>
        ${u.filter((c) => c !== "").map((c) => h`<option value=${c} ?selected=${c === n}>${c}</option>`)}
      </select>`;
    } else
      p = h`<input
        type="number"
        inputmode="decimal"
        step=${s.type === "int" ? "1" : "any"}
        min=${s.min ?? d}
        placeholder=${s.placeholder || "—"}
        .value=${n}
        ?disabled=${l}
        @input=${o}
      />`;
    return h`<label class="field ${a ? "invalid" : ""}" title=${this.t(`shaketune.param.${e}`)}>
      <span class="field-label mono">${e}</span>
      ${p}
    </label>`;
  }
  #b() {
    const e = this.#e, t = e.state, s = t.result, n = O(this.command), r = V(n, this.values[this.command] ?? {}), a = this.#p(), l = t.busy || s.running, o = {
      t: (p, u) => this.t(p, u),
      pick: this.pick,
      onPick: (p, u) => this.pick = { ...this.pick, [p]: u },
      damping: this.damping,
      onDamping: (p) => {
        this.damping = p, this.#i("damping", p);
      },
      canApply: !l && e.klippyReady && xe(s, this.pick, this.damping) !== null,
      onApply: () => void this.#o(),
      onCopy: (p, u) => void this.#d(p, u),
      copied: this.copied
    };
    return h`
      <section class="panel">
        <header class="panel-header">
          <span class="panel-title">${this.t("shaketune.title")}</span>
          ${s.version ? h`<span class="chip mono">${s.version}</span>` : d}
          ${this.#f()}
        </header>
        <div class="panel-body">
          <div class="sel-row" role="radiogroup" aria-label=${this.t("shaketune.command.label")}>
            ${M.map(
      (p) => h`<button
                class="sel-btn ${p.id === this.command ? "active" : ""}"
                role="radio"
                aria-checked=${p.id === this.command}
                ?disabled=${t.busy}
                title=${p.gcode}
                @click=${() => this.#r(p.id)}
              >
                ${this.t(`shaketune.command.${p.id}`)}
              </button>`
    )}
          </div>
          <p class="muted">${this.t(`shaketune.commandHint.${n.id}`)}</p>

          <div class="fields">${n.params.map((p) => this.#g(p.key))}</div>

          ${r.invalid.length ? h`<p class="error">${this.t("shaketune.block.invalid", { fields: r.invalid.join(", ") })}</p>` : d}
          ${a && !l ? h`<p class="warn">${a}</p>` : d}

          <code class="gcode mono">${r.script}</code>
          <div class="row">
            <button class="btn primary" ?disabled=${!!a || r.invalid.length > 0} @click=${() => void this.#c()}>
              ${l ? h`<span class="spinner"></span> ${this.t("shaketune.run.running")}` : this.t("shaketune.run.run")}
            </button>
            ${!e.isHomed && e.klippyReady && !l && !e.isPrinting ? h`<button class="btn" @click=${() => void e.send("G28")}>${this.t("shaketune.run.home")}</button>` : d}
            <span class="muted">${this.t("shaketune.run.duration", { minutes: n.minutes })}</span>
          </div>

          ${l ? h`<p class="row muted">
                <span class="spinner"></span>
                ${t.external ? h`<span class="chip">${this.t("shaketune.run.external")}</span>` : d}
                ${s.progress ?? this.t("shaketune.run.started")}
              </p>` : d}
          ${s.error ? h`<p class="error">${s.error}</p>` : d}

          ${Et(s, o)}

          ${t.lines.length ? h`<details class="log">
                <summary>${this.t("shaketune.run.log", { count: t.lines.length })}</summary>
                <pre class="mono">${t.lines.map((p) => h`<span class=${p.startsWith("!!") ? "err" : ""}>${p}\n</span>`)}</pre>
              </details>` : d}
        </div>
      </section>
    `;
  }
  #$() {
    const e = this.#e.state, t = e.config, s = new Set(e.fresh), n = this.filter === "all" ? e.files : e.files.filter((l) => l.folder === this.filter), r = /* @__PURE__ */ new Map([["all", e.files.length]]);
    for (const l of e.files) r.set(l.folder, (r.get(l.folder) ?? 0) + 1);
    let a;
    return t.resultsPath ? e.filesLoaded ? a = h`
        <div class="sel-row">
          ${["all", ...He].map(
      (l) => h`<button class="sel-btn ${this.filter === l ? "active" : ""}" @click=${() => this.#a(l)}>
              ${this.t(`shaketune.folder.${l}`)} (${r.get(l) ?? 0})
            </button>`
    )}
        </div>
        ${n.length === 0 ? h`<p class="muted">${this.t("shaketune.results.empty")}</p>` : h`<div class="gallery">
              ${n.map(
      (l) => h`<button
                  class="tile ${this.selected === l.path ? "active" : ""} ${s.has(l.path) ? "fresh" : ""}"
                  title=${new Date(l.modified * 1e3).toLocaleString()}
                  @click=${() => void this.#u(l)}
                >
                  <span class="tile-name">${l.name}</span>
                  <span class="row">
                    <span class="tag">${this.t(`shaketune.folder.${l.folder}`)}</span>
                    ${l.axis ? h`<span class="tag">${l.axis}</span>` : d}
                    ${s.has(l.path) ? h`<span class="tag new">${this.t("shaketune.results.new")}</span>` : d}
                  </span>
                </button>`
    )}
            </div>`}
        ${this.previewUrl ? h`<img class="preview" src=${this.previewUrl} alt=${this.selected ?? ""} @click=${this.#m} />
              <dialog @click=${(l) => l.target === l.currentTarget && l.currentTarget.close()}>
                <img
                  class=${this.full ? "full" : "fit"}
                  src=${this.previewUrl}
                  alt=${this.selected ?? ""}
                  @click=${() => this.full = !this.full}
                />
              </dialog>` : d}
      ` : a = h`<p class="muted">${this.t("shaketune.common.loading")}</p>` : a = h`<p class="warn">${this.t("shaketune.results.outsideConfig")}</p>`, h`
      <section class="panel">
        <header class="panel-header">
          <span class="panel-title">${this.t("shaketune.results.title")}</span>
          ${t.resultsPath ? h`<span class="chip mono" title=${t.resultsPath}>${t.resultsPath}</span>` : d}
          <button
            class="icon-btn"
            title=${this.t("shaketune.common.refresh")}
            aria-label=${this.t("shaketune.common.refresh")}
            @click=${() => void this.#e.refreshFiles()}
          >⟳</button>
        </header>
        <div class="panel-body">${a}</div>
      </section>
    `;
  }
}
async function ms(i, e) {
  Pe(i);
  try {
    return (await Ie(i.moonraker())).hasShakeTune;
  } catch {
    return !1;
  }
}
const hs = 3e3;
async function ps(i) {
  const e = rt();
  if (!e) return null;
  try {
    const t = e.moonrakerFor(i), s = await Promise.race([
      t.request(
        "printer.objects.query",
        { objects: { print_stats: ["state"], toolhead: ["homed_axes"] } }
      ),
      new Promise((n) => setTimeout(() => n(null), hs))
    ]);
    return s ? {
      printState: String(s.status?.print_stats?.state ?? ""),
      homedAxes: String(s.status?.toolhead?.homed_axes ?? "")
    } : null;
  } catch {
    return null;
  }
}
async function fs(i, e, t) {
  if (i.method !== "printer.gcode.script") return { action: "allow" };
  const s = String(i.params?.script ?? "");
  if (!pt(s).some((r) => se.has(r))) return { action: "allow" };
  const n = await ps(t.targetPrinterId);
  return n ? n.printState === "printing" || n.printState === "paused" ? { action: "deny", reasonKey: "shaketune.guard.printing" } : n.homedAxes !== "xyz" ? { action: "deny", reasonKey: "shaketune.guard.homing" } : { action: "allow" } : { action: "allow" };
}
Me("tessera-shaketune-tab", cs);
Me("tessera-shaketune-bridge", lt);
const gs = { en: at, ru: ot };
export {
  fs as guardShakeTune,
  ms as hasShakeTune,
  gs as locales
};
