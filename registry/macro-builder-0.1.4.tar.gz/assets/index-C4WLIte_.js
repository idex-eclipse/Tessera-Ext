const T = { macroBuilder: {
  title: "Visual macro builder",
  newMacro: "New macro",
  name: "Macro name",
  apply: "Apply to editor",
  cancel: "Cancel",
  loading: "Loading blocks…",
  stale: "The Config buffer changed. Close the builder and open it again.",
  closeReopen: "Close and reopen",
  invalidName: "Use a unique macro name with letters, digits, and underscores.",
  blocks: "Blocks",
  delete: "Delete block",
  moveUp: "Move up",
  moveDown: "Move down",
  rawEdit: "Edit raw text",
  rawSave: "Keep raw text",
  rawCancel: "Cancel raw edit",
  command: "Command",
  call: "Macro call",
  assign: "Set variable",
  comment: "Comment",
  setMacroVar: "Set macro variable",
  saveVar: "Save global variable",
  variables: "Local macro variables",
  variableName: "Variable name",
  initialValue: "Initial value",
  addVariable: "Add variable",
  removeVariable: "Remove variable",
  invalidVariable: "Use unique lowercase variable names and nonempty initial values.",
  raw: "Raw Jinja / text",
  if: "If / elif",
  for: "For loop",
  then: "Then",
  else: "Else",
  do: "Do",
  suggestions: "Commands, macros, parameters and Klipper objects",
  loadError: "Could not load the visual editor."
} }, P = { macroBuilder: {
  title: "Визуальный конструктор макросов",
  newMacro: "Новый макрос",
  name: "Имя макроса",
  apply: "Применить в редакторе",
  cancel: "Отмена",
  loading: "Загрузка блоков…",
  stale: "Буфер Config изменился. Закройте конструктор и откройте его заново.",
  closeReopen: "Закрыть и открыть заново",
  invalidName: "Укажите уникальное имя из букв, цифр и подчёркиваний.",
  blocks: "Блоки",
  delete: "Удалить блок",
  moveUp: "Выше",
  moveDown: "Ниже",
  rawEdit: "Изменить исходный текст",
  rawSave: "Сохранить исходный текст",
  rawCancel: "Отменить правку",
  command: "Команда",
  call: "Вызов макроса",
  assign: "Присвоить переменную",
  comment: "Комментарий",
  setMacroVar: "Задать переменную макроса",
  saveVar: "Сохранить глобальную переменную",
  variables: "Локальные переменные макроса",
  variableName: "Имя переменной",
  initialValue: "Начальное значение",
  addVariable: "Добавить переменную",
  removeVariable: "Удалить переменную",
  invalidVariable: "Нужны уникальные имена переменных в нижнем регистре и непустые начальные значения.",
  raw: "Исходный Jinja / текст",
  if: "Если / иначе если",
  for: "Цикл for",
  then: "Тогда",
  else: "Иначе",
  do: "Выполнить",
  suggestions: "Команды, макросы, параметры и объекты Klipper",
  loadError: "Не удалось загрузить визуальный редактор."
} };
function H(o) {
  return /^[#;]/.test(o.trimStart()) ? o : `# ${o}`;
}
function V(o) {
  const e = [];
  for (const i of o.matchAll(/[^\r\n]*(?:\r\n|\n|\r|$)/g))
    i[0] && e.push({ text: i[0], from: i.index, to: i.index + i[0].length });
  return e;
}
function I(o) {
  const e = /^\s*\{%-?\s*(if|elif|else|endif|for|endfor)\b(.*?)\s*-?%\}\s*(?:\r?\n|\r)?$/i.exec(o);
  return e ? { word: (e[1] ?? "").toLowerCase(), value: (e[2] ?? "").trim() } : null;
}
function B(o, e, i, t, a) {
  return {
    kind: o,
    value: e,
    source: i,
    from: t,
    to: a,
    header: i,
    footer: "",
    children: [],
    elseHeader: "",
    elseChildren: [],
    keyword: "if"
  };
}
function $(o, e) {
  const i = o[e]?.text.indexOf("{") ?? -1;
  if (i < 0) return e;
  for (let t = e; t < o.length; t++)
    if ((o[t]?.text.indexOf("}", t === e ? i + 1 : 0) ?? -1) >= 0) return t;
  return e;
}
function z(o, e, i) {
  const t = V(o);
  let a = 0;
  const l = (n) => {
    const s = [];
    for (; a < t.length; ) {
      const r = t[a], d = I(r.text);
      if (d && n.has(d.word)) break;
      if (d?.word === "if" || d?.word === "for") {
        const c = t[a++], b = B(d.word, d.value, "", e + c.from, e + c.to);
        if (b.header = c.text, b.children = l(new Set(d.word === "if" ? ["elif", "else", "endif"] : ["endfor"])), d.word === "if") {
          let w = b;
          for (; I(t[a]?.text ?? "")?.word === "elif"; ) {
            const y = t[a++], k = B("if", I(y.text).value, "", e + y.from, e + y.to);
            k.keyword = "elif", k.header = y.text, k.children = l(/* @__PURE__ */ new Set(["elif", "else", "endif"])), w.elseChildren = [k], w = k;
          }
          I(t[a]?.text ?? "")?.word === "else" && (w.elseHeader = t[a++].text, w.elseChildren = l(/* @__PURE__ */ new Set(["endif"])));
        }
        const f = d.word === "if" ? "endif" : "endfor";
        if (I(t[a]?.text ?? "")?.word !== f) throw new Error("Unbalanced Jinja");
        b.footer = t[a++].text, b.to = e + t[a - 1].to, b.source = o.slice(c.from, t[a - 1].to), s.push(b);
        continue;
      }
      if (d) throw new Error("Ambiguous Jinja");
      const h = /^\s*[#;]/.test(r.text) ? a : $(t, a);
      if (h > a) {
        const c = t[h], b = o.slice(r.from, c.to);
        s.push(B("raw", b.replace(/(?:\r\n|\n|\r)$/, ""), b, e + r.from, e + c.to)), a = h + 1;
        continue;
      }
      a++;
      const g = r.text, u = g.trim(), m = /^\s*([A-Za-z_][A-Za-z_0-9]*)\b(.*?)(?:\r?\n|\r)?$/.exec(g), S = /^\s*\{%[-]?\s*set\s+(.+?)\s*[-]?%\}\s*(?:\r?\n|\r)?$/.exec(g);
      let A = "raw", x = u;
      if (S)
        A = "assign", x = S[1] ?? "";
      else if (u.startsWith("#") || u.startsWith(";"))
        A = "comment", x = u;
      else if (m) {
        const c = (m[1] ?? "").toUpperCase();
        A = c === "SET_GCODE_VARIABLE" ? "set_macro_var" : c === "SAVE_VARIABLE" ? "save_var" : i.has(c) ? "call" : "command", x = `${m[1] ?? ""}${m[2] ?? ""}`.trimEnd();
      }
      s.push(B(A, x, g, e + r.from, e + r.to));
    }
    return s;
  };
  try {
    const n = l(/* @__PURE__ */ new Set());
    if (a !== t.length) throw new Error("Unmatched Jinja");
    return n;
  } catch {
    const n = [];
    for (let s = 0; s < t.length; ) {
      const r = t[s], d = $(t, s), h = t[d], g = o.slice(r.from, h.to);
      n.push(B(
        "raw",
        g.replace(/(?:\r\n|\n|\r)$/, ""),
        g,
        e + r.from,
        e + h.to
      )), s = d + 1;
    }
    return n;
  }
}
function U(o, e) {
  if (o === null) return { name: "", prefix: "", suffix: "", indent: "    ", eol: `
`, nodes: [], variables: [], source: "", existing: !1 };
  const i = V(o), t = /^\s*\[\s*gcode_macro\s+([^\]\s]+)\s*\]/i.exec(i[0]?.text ?? ""), a = i.findIndex((u, m) => m > 0 && /^\s*gcode\s*[:=]\s*(?:[#;].*)?(?:\r?\n|\r)?$/i.test(u.text));
  if (!t || a < 0) return {
    name: t?.[1] ?? "",
    prefix: o,
    suffix: "",
    indent: "    ",
    eol: o.includes(`\r
`) ? `\r
` : `
`,
    nodes: [],
    variables: [],
    source: o,
    existing: !0
  };
  const l = i[a].to, n = i.findIndex((u, m) => m > a && /^[A-Za-z_][\w]*\s*[:=]/.test(u.text)), s = n < 0 ? o.length : i[n].from, r = o.slice(l, s), d = V(r).find((u) => /^\s+\S/.test(u.text)), h = /^([ \t]+)/.exec(d?.text ?? "")?.[1] ?? "    ", g = i.slice(1, a).flatMap((u) => {
    const m = /^\s*variable_([a-z_][a-z0-9_]*)\s*[:=]\s*(.*?)(?:\r\n|\n|\r)?$/.exec(u.text);
    return m ? [{ name: m[1] ?? "", value: m[2] ?? "", source: u.text, from: u.from }] : [];
  });
  return {
    name: t[1] ?? "",
    prefix: o.slice(0, l),
    suffix: o.slice(s),
    indent: h,
    eol: o.includes(`\r
`) ? `\r
` : `
`,
    variables: g,
    nodes: z(r, l, new Set(e.map((u) => u.toUpperCase()))),
    source: o,
    existing: !0
  };
}
function q(o, e, i) {
  if (!o.existing) {
    const n = i.map((s) => `variable_${s.name}: ${s.value}${o.eol}`).join("");
    return `[gcode_macro ${e}]${o.eol}${n}gcode:${o.eol}`;
  }
  const t = new Map(i.filter((n) => n.from >= 0).map((n) => [n.from, n])), a = i.filter((n) => n.from < 0).map((n) => `variable_${n.name}: ${n.value}${o.eol}`).join("");
  let l = "";
  for (const n of V(o.prefix)) {
    /^\s*gcode\s*[:=]/i.test(n.text) && (l += a);
    const s = o.variables.find((d) => d.from === n.from), r = t.get(n.from);
    s ? r && (l += r.name === s.name && r.value === s.value ? s.source : `variable_${r.name}: ${r.value}${o.eol}`) : l += n.text;
  }
  return l.replace(/^(\s*\[\s*gcode_macro\s+)[^\]\s]+/i, `$1${e}`);
}
function M(o) {
  return /^[a-z_][a-z0-9_]*$/.test(o);
}
function N(o, e, i = "") {
  return /^[A-Za-z_][A-Za-z_0-9]*$/.test(o) && (o.toUpperCase() === i.toUpperCase() || !e.some((t) => t.toUpperCase() === o.toUpperCase()));
}
class K extends HTMLElement {
  modal = null;
  session = null;
  api = null;
  model = null;
  canvas = null;
  builder = null;
  nameInput = null;
  error = null;
  applyButton = null;
  toolboxButton = null;
  variables = [];
  suggestionPanel = null;
  activeField = null;
  suggestionItems = [];
  suggestionIndex = 0;
  loadSequence = 0;
  compact = !1;
  stale = !1;
  stopThemeChange = null;
  connectedCallback() {
    if (this.modal) return;
    const e = document.createElement("style");
    e.textContent = j, this.append(e);
    const i = document.createElement("dialog");
    i.className = "macro-builder-modal", i.setAttribute("aria-modal", "true"), i.dataset.hotkeyEditorOwner = "tessera/macro-builder", i.addEventListener("cancel", (t) => {
      t.preventDefault(), this.close();
    }), i.addEventListener("keydown", this.onInsertShortcut, !0), this.modal = i, this.append(i);
  }
  disconnectedCallback() {
    this.close(), this.modal = null;
  }
  t(e) {
    return this.api?.i18n.t(`macroBuilder.${e}`) ?? e;
  }
  button(e, i, t = "") {
    const a = document.createElement("button");
    return a.type = "button", a.textContent = e, a.className = t, a.setAttribute("aria-label", e), a.addEventListener("click", i), a;
  }
  /** Load Blockly after the first open, keeping the unopened plugin inexpensive. */
  async open(e, i) {
    this.close(), this.session = e, this.api = i, this.stopThemeChange = i.onThemeChange(() => this.builder?.updateTheme()), this.stale = !1;
    const t = ++this.loadSequence;
    this.model = U(e.section?.text ?? null, e.macroNames), this.variables = this.model.variables.map((p) => ({ ...p }));
    const a = this.modal;
    if (!a || !this.model) return;
    a.replaceChildren(), a.dir = document.documentElement.dir === "rtl" ? "rtl" : "ltr", a.setAttribute("aria-label", this.t("title"));
    const l = document.createElement("header"), n = document.createElement("h2");
    n.textContent = `${this.t("title")} · ${e.path}`, n.dir = "auto";
    const s = this.button("×", () => this.close());
    s.setAttribute("aria-label", this.t("cancel")), l.append(n, s), a.append(l);
    const r = document.createElement("div");
    r.className = "mb-name-row";
    const d = document.createElement("label");
    d.textContent = this.t("name");
    const h = document.createElement("input");
    h.type = "text", h.dir = "ltr", h.value = this.model.name, h.setAttribute("aria-label", this.t("name")), h.addEventListener("input", () => this.validate()), this.nameInput = h, d.append(h), r.append(d);
    const g = document.createElement("div");
    g.className = "mb-variables";
    const u = document.createElement("strong");
    u.textContent = this.t("variables");
    const m = document.createElement("div");
    m.className = "mb-variable-rows";
    const S = () => {
      m.replaceChildren();
      for (const p of this.variables) {
        const v = document.createElement("div");
        v.className = "mb-variable-row";
        const E = document.createElement("input");
        E.dir = "ltr", E.value = p.name, E.placeholder = this.t("variableName"), E.setAttribute("aria-label", this.t("variableName")), E.addEventListener("input", () => {
          p.name = E.value, this.validate();
        });
        const C = document.createElement("input");
        C.dir = "ltr", C.value = p.value, C.placeholder = this.t("initialValue"), C.setAttribute("aria-label", this.t("initialValue")), C.addEventListener("input", () => {
          p.value = C.value, this.validate();
        }), v.append(E, C, this.button(this.t("removeVariable"), () => {
          this.variables = this.variables.filter((_) => _ !== p), S(), this.validate();
        })), m.append(v);
      }
    }, A = this.button(this.t("addVariable"), () => {
      this.variables.push({ name: "", value: "", source: "", from: -1 }), S(), m.querySelector(".mb-variable-row:last-child input")?.focus(), this.validate();
    });
    g.append(u, m, A), S(), r.append(g), a.append(r);
    const x = document.createElement("div");
    x.className = "mb-toolbar", this.toolboxButton = this.button(this.t("blocks"), () => this.toggleToolbox()), x.append(
      this.toolboxButton,
      this.button(this.t("moveUp"), () => this.moveSelected(-1)),
      this.button(this.t("moveDown"), () => this.moveSelected(1)),
      this.button(this.t("delete"), () => this.builder?.selected()?.dispose(!0)),
      this.button(this.t("rawEdit"), () => this.showRawEditor())
    );
    const c = document.createElement("input");
    c.setAttribute("aria-label", this.t("suggestions")), c.placeholder = this.t("suggestions"), c.dir = "ltr", c.setAttribute("list", "macro-builder-hints");
    const b = document.createElement("datalist");
    b.id = "macro-builder-hints";
    for (const p of [
      ...e.commands.map((v) => v.name),
      ...e.macroNames,
      ...e.commands.flatMap((v) => v.params),
      ...e.objects
    ]) {
      const v = document.createElement("option");
      v.value = p, b.append(v);
    }
    c.addEventListener("change", () => {
      const p = this.builder?.selected();
      p && c.value && p.setFieldValue(c.value, "VALUE"), c.value = "";
    }), x.append(c, b), a.append(x);
    const f = document.createElement("div");
    f.className = "mb-canvas", f.setAttribute("role", "region"), f.setAttribute("aria-label", this.t("blocks")), f.setAttribute("aria-keyshortcuts", "C M Alt+C L"), f.tabIndex = 0, f.textContent = this.t("loading"), this.canvas = f, a.append(f);
    const w = document.createElement("div");
    w.className = "mb-suggestions", w.hidden = !0, this.suggestionPanel = w, a.append(w);
    const y = document.createElement("p");
    y.className = "mb-error", y.setAttribute("role", "alert"), this.error = y, a.append(y);
    const k = document.createElement("footer");
    this.applyButton = this.button(this.t("apply"), () => this.apply(), "primary"), k.append(this.button(this.t("cancel"), () => this.close()), this.applyButton), a.append(k), a.showModal(), document.addEventListener("input", this.onFieldInput, !0), document.addEventListener("focusin", this.onFieldFocus, !0), document.addEventListener("macro-builder-caret", this.onFieldCaret, !0), document.addEventListener("pointerup", this.onFieldPointerUp, !0), document.addEventListener("keyup", this.onFieldKeyup, !0), document.addEventListener("keydown", this.onFieldKeydown, !0), this.validate();
    try {
      const { MacroWorkspace: p } = await import("./workspace-CO79RxXU.js");
      if (t !== this.loadSequence || !this.modal?.open || !this.model) return;
      f.replaceChildren(), this.builder = new p(f, this.model, e, {
        command: this.t("command"),
        call: this.t("call"),
        assign: this.t("assign"),
        comment: this.t("comment"),
        raw: this.t("raw"),
        if: this.t("if"),
        for: this.t("for"),
        set_macro_var: this.t("setMacroVar"),
        save_var: this.t("saveVar"),
        then: this.t("then"),
        else: this.t("else"),
        do: this.t("do")
      }, a.dir === "rtl"), this.compact = window.matchMedia("(max-width: 768px)").matches, this.builder.setToolboxVisible(!this.compact), (await import("./blockly-Bx50eHQS.js").then((E) => E.h)).svgResize(this.builder.workspace), this.validate();
    } catch (p) {
      console.error("[macro-builder] Blockly could not initialize", p), t === this.loadSequence && this.showError(this.t("loadError"));
    }
  }
  validate() {
    const e = this.nameInput?.value.trim() ?? "", i = !!this.model && !!this.session && N(e, this.session.macroNames, this.model.name), t = this.variables.map((n) => n.name), a = this.variables.every((n) => M(n.name) && n.value.trim() !== "") && new Set(t).size === t.length, l = i && a;
    this.applyButton && (this.applyButton.disabled = !l || !this.builder), i ? a ? this.showError("") : this.showError(this.t("invalidVariable")) : this.showError(this.t("invalidName"));
  }
  /** Keep Blockly's editor and its suggestions readable for long expressions. */
  resizeField(e) {
    const t = document.createElement("canvas").getContext("2d");
    if (!t) return;
    t.font = getComputedStyle(e).font;
    const a = e.value.split(/\r?\n/).reduce((l, n) => Math.max(l, t.measureText(n).width), 0);
    e.style.width = `${Math.min(window.innerWidth - 48, Math.max(120, Math.ceil(a + 32)))}px`, e instanceof HTMLTextAreaElement && (e.style.height = "auto", e.style.height = `${Math.min(window.innerHeight / 2, e.scrollHeight)}px`);
  }
  isBlocklyField(e) {
    return (e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement) && e.classList.contains("blocklyHtmlInput");
  }
  onFieldFocus = (e) => {
    this.isBlocklyField(e.target) && this.updateSuggestions(e.target);
  };
  onFieldInput = (e) => {
    this.isBlocklyField(e.target) && this.updateSuggestions(e.target);
  };
  /** Cursor movement can enter a parameter value without changing the command text. */
  onFieldCaret = (e) => {
    this.isBlocklyField(e.target) && this.updateSuggestions(e.target);
  };
  onFieldPointerUp = (e) => {
    this.isBlocklyField(e.target) && this.updateSuggestions(e.target);
  };
  onFieldKeyup = (e) => {
    this.isBlocklyField(e.target) && ["ArrowLeft", "ArrowRight", "Home", "End"].includes(e.key) && this.updateSuggestions(e.target);
  };
  /** Config returns the same command and Jinja candidates used by its text editor. */
  updateSuggestions(e) {
    this.activeField = e, this.resizeField(e);
    const i = this.suggestionPanel, t = this.session?.suggest;
    if (!(!i || !t)) {
      this.suggestionItems = t(
        e.value,
        e.selectionStart ?? e.value.length,
        this.variables,
        this.nameInput?.value.trim() ?? ""
      ), this.suggestionIndex = 0, i.replaceChildren();
      for (const [a, l] of this.suggestionItems.entries()) {
        const n = this.button(l.label, () => this.acceptSuggestion(a));
        if (n.className = "mb-suggestion", n.addEventListener("pointerdown", (s) => s.preventDefault()), n.setAttribute("aria-selected", String(a === this.suggestionIndex)), l.detail) {
          const s = document.createElement("small");
          s.className = "mb-suggestion-detail", s.dir = "ltr", s.textContent = l.detail, n.append(s);
        }
        i.append(n);
      }
      if (i.hidden = this.suggestionItems.length === 0, !i.hidden) {
        const a = e.getBoundingClientRect(), l = this.modal?.dir === "rtl";
        i.style.insetInlineStart = `${Math.max(8, Math.min(
          window.innerWidth - 300,
          l ? window.innerWidth - a.right : a.left
        ))}px`, i.style.top = `${Math.min(window.innerHeight - 180, a.bottom + 4)}px`;
      }
    }
  }
  acceptSuggestion(e) {
    const i = this.activeField, t = this.suggestionItems[e];
    !i || !t || (i.setRangeText(t.insert, t.from, i.selectionStart ?? i.value.length, "end"), i.dispatchEvent(new Event("input", { bubbles: !0 })), i.focus(), this.suggestionPanel && (this.suggestionPanel.hidden = !0));
  }
  onFieldKeydown = (e) => {
    e.target !== this.activeField || this.suggestionPanel?.hidden || !this.suggestionItems.length || (e.key === "ArrowDown" || e.key === "ArrowUp" ? (e.preventDefault(), e.stopPropagation(), this.suggestionIndex = (this.suggestionIndex + (e.key === "ArrowDown" ? 1 : -1) + this.suggestionItems.length) % this.suggestionItems.length, this.suggestionPanel?.querySelectorAll("button").forEach((i, t) => i.setAttribute("aria-selected", String(t === this.suggestionIndex))), this.suggestionPanel?.querySelectorAll("button")[this.suggestionIndex]?.scrollIntoView({ block: "nearest" })) : e.key === "Tab" || e.key === "Enter" ? (e.preventDefault(), e.stopPropagation(), this.acceptSuggestion(this.suggestionIndex)) : e.key === "Escape" && this.suggestionPanel && (this.suggestionPanel.hidden = !0));
  };
  /** Physical keys work under either keyboard layout and never replace text being edited. */
  onInsertShortcut = (e) => {
    if (!this.modal?.open || !this.builder || e.defaultPrevented || e.repeat || e.isComposing || e.ctrlKey || e.metaKey || e.shiftKey) return;
    const i = e.target;
    if (i instanceof Element && i.closest('input, textarea, select, [contenteditable], [role="textbox"]')) return;
    const t = e.code === "KeyC" ? e.altKey ? "if" : "command" : !e.altKey && e.code === "KeyM" ? "call" : !e.altKey && e.code === "KeyL" ? "for" : null;
    t && (e.preventDefault(), e.stopPropagation(), this.builder.insertBlock(t));
  };
  showError(e) {
    this.error && (this.error.textContent = e);
  }
  toggleToolbox() {
    this.builder && (this.compact = !this.compact, this.builder.setToolboxVisible(!this.compact));
  }
  /** Reconnect a statement chain so touch users can reorder without dragging. */
  moveSelected(e) {
    const i = this.builder?.selected();
    if (!i || !this.builder) return;
    let t = i;
    for (; t.getPreviousBlock(); ) t = t.getPreviousBlock();
    const a = [];
    for (let r = t; r; r = r.getNextBlock()) a.push(r);
    const l = a.indexOf(i), n = l + e;
    if (n < 0 || n >= a.length) return;
    const s = t.previousConnection?.targetConnection ?? null;
    for (const r of a) r.previousConnection?.disconnect();
    [a[l], a[n]] = [a[n], a[l]], s && s.connect(a[0].previousConnection);
    for (let r = 1; r < a.length; r++) a[r - 1].nextConnection?.connect(a[r].previousConnection);
    this.builder.workspace.cleanUp();
  }
  showRawEditor() {
    const e = this.builder?.selected();
    if (!e || e.type !== "mb_raw" || !this.modal) return;
    const i = document.createElement("div");
    i.className = "mb-raw-editor";
    const t = document.createElement("textarea");
    t.dir = "ltr", t.value = String(e.getFieldValue("VALUE") ?? ""), i.append(t, this.button(this.t("rawSave"), () => {
      this.builder?.editSelectedRaw(t.value), i.remove();
    }), this.button(this.t("rawCancel"), () => i.remove())), this.modal.append(i), t.focus();
  }
  apply() {
    if (this.stale) {
      this.close();
      return;
    }
    if (!this.builder || !this.session || !this.model || !this.nameInput) return;
    const e = this.nameInput.value.trim();
    if (!N(e, this.session.macroNames, this.model.name)) {
      this.validate();
      return;
    }
    if (this.variables.some((t) => !M(t.name) || !t.value.trim())) {
      this.validate();
      return;
    }
    this.session.applyEdit(this.builder.serialize(e, this.variables)) === "applied" ? this.close() : (this.stale = !0, this.showError(this.t("stale")), this.applyButton && (this.applyButton.disabled = !1, this.applyButton.textContent = this.t("closeReopen")));
  }
  /** Cancel does not touch Config's buffer. */
  close() {
    document.removeEventListener("input", this.onFieldInput, !0), document.removeEventListener("focusin", this.onFieldFocus, !0), document.removeEventListener("macro-builder-caret", this.onFieldCaret, !0), document.removeEventListener("pointerup", this.onFieldPointerUp, !0), document.removeEventListener("keyup", this.onFieldKeyup, !0), document.removeEventListener("keydown", this.onFieldKeydown, !0), this.activeField = null, this.suggestionPanel = null, this.loadSequence++, this.builder?.dispose(), this.builder = null, this.stopThemeChange?.(), this.stopThemeChange = null, this.session = null, this.model = null, this.modal?.open && this.modal.close();
  }
}
const j = `
.macro-builder-modal { position: fixed; inset-block: 0; inset-inline: 0; width: 100vw; height: 100vh; height: 100dvh; max-width: none; max-height: none; margin: 0; padding: 0; border: 0; border-radius: 0; background: var(--bg-surface); color: var(--text-primary); overflow: hidden; color-scheme: light; }
:root[data-theme="dark"] .macro-builder-modal { color-scheme: dark; }
.macro-builder-modal[open] { display: flex; flex-direction: column; }
.macro-builder-modal::backdrop { background: var(--bg-overlay); }
.macro-builder-modal header, .macro-builder-modal footer { display: flex; align-items: center; justify-content: space-between; gap: var(--space-sm); padding: var(--space-sm) var(--space-md); border-block-end: 1px solid var(--border-color); }
.macro-builder-modal footer { border-block-start: 1px solid var(--border-color); border-block-end: 0; justify-content: flex-end; }
.macro-builder-modal h2 { font-size: var(--font-size-md); min-width: 0; overflow-wrap: anywhere; margin: 0; }
.macro-builder-modal button { min-width: 44px; min-height: 44px; padding: var(--space-xs) var(--space-sm); border: 1px solid var(--border-color); border-radius: var(--radius-sm); background: var(--bg-surface-hover); color: var(--text-primary); cursor: pointer; }
.macro-builder-modal button.primary { background: var(--accent); border-color: var(--accent); color: var(--accent-text); }
.macro-builder-modal button:disabled { opacity: .5; cursor: default; }
.mb-name-row, .mb-toolbar { padding: var(--space-xs) var(--space-md); display: flex; align-items: center; gap: var(--space-xs); flex-wrap: wrap; }
.mb-name-row label { display: flex; align-items: center; gap: var(--space-sm); flex-wrap: wrap; }
/* Variable rows wrap independently so long Python literals do not widen the dialog. */
.mb-variables { display: grid; gap: var(--space-xs); flex: 1 1 360px; min-width: 0; }
.mb-variable-rows { display: grid; gap: var(--space-xs); }
.mb-variable-row { display: flex; gap: var(--space-xs); flex-wrap: wrap; }
.mb-variable-row input:first-child { flex: 1 1 130px; }
.mb-variable-row input:nth-child(2) { flex: 2 1 180px; }
.mb-variables > button { justify-self: start; }
.macro-builder-modal input, .macro-builder-modal textarea { min-height: 40px; min-width: 0; border: 1px solid var(--border-color); border-radius: var(--radius-sm); background: var(--bg-app); color: var(--text-primary); padding: var(--space-xs); font: inherit; }
.mb-toolbar input { flex: 1 1 180px; }
.mb-canvas { flex: 1 1 auto; min-height: 0; position: relative; overflow: hidden; background: var(--bg-app); }
.mb-error { min-height: 1.3em; margin: 0; padding-inline: var(--space-md); color: var(--danger); overflow-wrap: anywhere; }
.mb-suggestions { position: fixed; z-index: 10; width: min(300px, calc(100vw - 16px)); max-height: 180px; overflow: auto; border: 1px solid var(--border-color); border-radius: var(--radius-sm); background: var(--bg-surface); box-shadow: var(--shadow-lg); }
.mb-suggestions[hidden] { display: none; }
.mb-suggestions button { display: block; width: 100%; min-height: 36px; border: 0; border-radius: 0; text-align: start; overflow-wrap: anywhere; }
.mb-suggestions button[aria-selected="true"] { background: var(--bg-surface-active); }
.mb-suggestion-detail { margin-inline-start: var(--space-xs); color: var(--text-muted); font-family: monospace; }
.mb-raw-editor { position: absolute; inset-inline: var(--space-md); inset-block-end: 72px; z-index: 2; padding: var(--space-sm); border: 1px solid var(--border-color); border-radius: var(--radius-sm); background: var(--bg-surface); display: flex; gap: var(--space-xs); flex-wrap: wrap; }
.mb-raw-editor textarea { width: 100%; min-height: 110px; font-family: monospace; resize: vertical; white-space: pre; }
.macro-builder-modal .blocklyText { unicode-bidi: plaintext; }
/* Blockly mounts its active field outside the canvas; keep it in the host's color scheme. */
.macro-builder-modal .blocklyHtmlInput, .macro-builder-widget .blocklyHtmlInput { background: var(--bg-surface); color: var(--text-primary); border-color: var(--border-focus); }
.macro-builder-widget { color-scheme: light; }
:root[data-theme="dark"] .macro-builder-widget { color-scheme: dark; }
/* Blockly's empty SVG layers sit above the editable blocks in this native dialog. */
.macro-builder-modal .blocklyAnimationLayer, .macro-builder-modal .blocklyBlockDragSurface { pointer-events: none; }
@media (max-width: 768px) { .mb-toolbar { gap: 4px; } .mb-toolbar button { flex: 1 1 auto; } .mb-name-row input { width: min(100%, 260px); } }
`;
function R(o) {
  if (!o || typeof o != "object") return !1;
  const e = o;
  return typeof e.printerId == "string" && typeof e.path == "string" && typeof e.applyEdit == "function" && Array.isArray(e.macroNames) && Array.isArray(e.commands) && Array.isArray(e.objects);
}
let F = null, L = null;
function O(o, e) {
  R(e) && (F ? F.open(e, o) : L = { session: e, api: o });
}
class D extends K {
  connectedCallback() {
    if (super.connectedCallback(), F = this, L) {
      const e = L;
      L = null, this.open(e.session, e.api);
    }
  }
  disconnectedCallback() {
    F === this && (F = null), super.disconnectedCallback();
  }
}
customElements.get("tessera-macro-builder-dialog") || customElements.define("tessera-macro-builder-dialog", D);
const W = { en: T, ru: P };
export {
  H as c,
  W as l,
  O as o,
  q as r
};
