import { g as r_, r as K, s as M_, i as C_, E as y, W as E_, a as P_, B as a_, b as l_, c as u_, d as U_, T as c_, e as D_, f as i_, F as d_ } from "./blockly-Bx50eHQS.js";
import { r as g_, c as H_ } from "./index-C4WLIte_.js";
var W = { exports: {} }, B_ = W.exports, e_;
function F_() {
  return e_ || (e_ = 1, (function(g, C) {
    (function(_, s) {
      g.exports = s();
    })(B_, function() {
      var _ = _ || { Msg: /* @__PURE__ */ Object.create(null) };
      return _.Msg.ADD_COMMENT = "Add Comment", _.Msg.ALT_KEY = "Alt", _.Msg.ANNOUNCE_CANT_SCROLL_FURTHER = "Can't scroll further.", _.Msg.ANNOUNCE_MOVE_AFTER = "Moving %1 after %2.", _.Msg.ANNOUNCE_MOVE_AROUND = "Moving %1 around %2.", _.Msg.ANNOUNCE_MOVE_BEFORE = "Moving %1 before %2.", _.Msg.ANNOUNCE_MOVE_CANCELED = "Canceled movement.", _.Msg.ANNOUNCE_MOVE_INSIDE = "Moving %1 inside %2.", _.Msg.ANNOUNCE_MOVE_OF = "%1 of %2", _.Msg.ANNOUNCE_MOVE_TO = "Moving %1 to %2.", _.Msg.ANNOUNCE_MOVE_WORKSPACE = "Moving %1 on workspace.", _.Msg.ANNOUNCE_SCROLLED_DOWN = "Scrolled down.", _.Msg.ANNOUNCE_SCROLLED_LEFT = "Scrolled left.", _.Msg.ANNOUNCE_SCROLLED_RIGHT = "Scrolled right.", _.Msg.ANNOUNCE_SCROLLED_UP = "Scrolled up.", _.Msg.ARIA_LABEL_ADD_ELSE_IF = "Add else if", _.Msg.ARIA_LABEL_ADD_INPUT = "Add input", _.Msg.ARIA_LABEL_ADD_LIST_ITEM = "Add list item", _.Msg.ARIA_LABEL_ADD_TEXT = "Add text", _.Msg.ARIA_LABEL_BUTTON = "button", _.Msg.ARIA_LABEL_COMMENT = "Comment", _.Msg.ARIA_LABEL_COMMENT_COLLAPSE = "Collapse Comment", _.Msg.ARIA_LABEL_COMMENT_EXPAND = "Expand Comment", _.Msg.ARIA_LABEL_FIELD_ANGLE = "%1 degrees", _.Msg.ARIA_LABEL_HEADING = "heading", _.Msg.ARIA_LABEL_REMOVE_ELSE_IF = "Remove else if", _.Msg.ARIA_LABEL_REMOVE_INPUT = "Remove input", _.Msg.ARIA_LABEL_REMOVE_LIST_ITEM = "Remove list item", _.Msg.ARIA_LABEL_REMOVE_TEXT = "Remove text", _.Msg.ARIA_LABEL_TRASH_EMPTY = "Trash, currently empty", _.Msg.ARIA_TYPE_FIELD_ANGLE = "angle", _.Msg.ARIA_TYPE_FIELD_BITMAP = "pixel image", _.Msg.ARIA_TYPE_FIELD_CHECKBOX = "checkbox", _.Msg.ARIA_TYPE_FIELD_COLOUR = "color", _.Msg.ARIA_TYPE_FIELD_DATE = "date", _.Msg.ARIA_TYPE_FIELD_DROPDOWN = "dropdown", _.Msg.ARIA_TYPE_FIELD_GRID = "grid dropdown", _.Msg.ARIA_TYPE_FIELD_IMAGE = "image", _.Msg.ARIA_TYPE_FIELD_INPUT = "input", _.Msg.ARIA_TYPE_FIELD_NUMBER = "number", _.Msg.ARIA_TYPE_FIELD_TEXT_INPUT = "text", _.Msg.ARIA_TYPE_FIELD_TEXT_INPUT_ARGUMENT = "input name", _.Msg.ARIA_TYPE_FIELD_TEXT_INPUT_PROCEDURE = "function name", _.Msg.BACKSPACE_KEY = "Backspace", _.Msg.BLOCK_LABEL_BEGIN_PREFIX = "Begin %1", _.Msg.BLOCK_LABEL_BEGIN_STACK = "Begin stack", _.Msg.BLOCK_LABEL_COLLAPSED = "collapsed", _.Msg.BLOCK_LABEL_CONTAINER = "container", _.Msg.BLOCK_LABEL_DISABLED = "disabled", _.Msg.BLOCK_LABEL_HAS_BRANCHES = "has %1 branches", _.Msg.BLOCK_LABEL_HAS_INPUT = "has input", _.Msg.BLOCK_LABEL_HAS_INPUTS = "has inputs", _.Msg.BLOCK_LABEL_REPLACEABLE = "replaceable", _.Msg.BLOCK_LABEL_STACK_BLOCKS = "%1 stack blocks", _.Msg.BLOCK_LABEL_STATEMENT = "statement", _.Msg.BLOCK_LABEL_TOOLBOX_CATEGORY = "%1 category", _.Msg.BLOCK_LABEL_VALUE = "value", _.Msg.BUBBLE_LABEL_COMMENT = "Comment: %1", _.Msg.BUBBLE_LABEL_DEFAULT = "Bubble", _.Msg.BUBBLE_LABEL_WARNING = "Warning: %1", _.Msg.CANNOT_DELETE_VARIABLE_PROCEDURE = "Can't delete the variable '%1' because it's part of the definition of the function '%2'", _.Msg.CAPS_LOCK_KEY = "Caps Lock", _.Msg.CHANGE_VALUE_TITLE = "Change value:", _.Msg.CHROME_OS = "ChromeOS", _.Msg.CLEAN_UP = "Clean up Blocks", _.Msg.CLOSE = "Close", _.Msg.CLOSE_BACKPACK = "Close backpack", _.Msg.COLLAPSED_WARNINGS_WARNING = "Collapsed blocks contain warnings.", _.Msg.COLLAPSE_ALL = "Collapse Blocks", _.Msg.COLLAPSE_BLOCK = "Collapse Block", _.Msg.COLOUR_BLEND_COLOUR1 = "colour 1", _.Msg.COLOUR_BLEND_COLOUR2 = "colour 2", _.Msg.COLOUR_BLEND_HELPURL = "https://meyerweb.com/eric/tools/color-blend/#:::rgbp", _.Msg.COLOUR_BLEND_RATIO = "ratio", _.Msg.COLOUR_BLEND_TITLE = "blend", _.Msg.COLOUR_BLEND_TOOLTIP = "Blends two colours together with a given ratio (0.0 - 1.0).", _.Msg.COLOUR_PICKER_HELPURL = "https://en.wikipedia.org/wiki/Color", _.Msg.COLOUR_PICKER_TOOLTIP = "Choose a colour from the palette.", _.Msg.COLOUR_RANDOM_HELPURL = "http://randomcolour.com", _.Msg.COLOUR_RANDOM_TITLE = "random colour", _.Msg.COLOUR_RANDOM_TOOLTIP = "Choose a colour at random.", _.Msg.COLOUR_RGB_BLUE = "blue", _.Msg.COLOUR_RGB_GREEN = "green", _.Msg.COLOUR_RGB_HELPURL = "https://www.december.com/html/spec/colorpercompact.html", _.Msg.COLOUR_RGB_RED = "red", _.Msg.COLOUR_RGB_TITLE = "colour with", _.Msg.COLOUR_RGB_TOOLTIP = "Create a colour with the specified amount of red, green, and blue. All values must be between 0 and 100.", _.Msg.COMMAND_KEY = "Command", _.Msg.CONTEXT_MENU_KEY = "≣ Menu", _.Msg.CONTROLS_FLOW_STATEMENTS_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Loops#loop-termination-blocks", _.Msg.CONTROLS_FLOW_STATEMENTS_OPERATOR_BREAK = "break out of loop", _.Msg.CONTROLS_FLOW_STATEMENTS_OPERATOR_CONTINUE = "continue with next iteration of loop", _.Msg.CONTROLS_FLOW_STATEMENTS_TOOLTIP_BREAK = "Break out of the containing loop.", _.Msg.CONTROLS_FLOW_STATEMENTS_TOOLTIP_CONTINUE = "Skip the rest of this loop, and continue with the next iteration.", _.Msg.CONTROLS_FLOW_STATEMENTS_WARNING = "Warning: This block may only be used within a loop.", _.Msg.CONTROLS_FOREACH_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Loops#for-each", _.Msg.CONTROLS_FOREACH_TITLE = "for each item %1 in list %2", _.Msg.CONTROLS_FOREACH_TOOLTIP = "For each item in a list, set the variable '%1' to the item, and then do some statements.", _.Msg.CONTROLS_FOR_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Loops#count-with", _.Msg.CONTROLS_FOR_TITLE = "count with %1 from %2 to %3 by %4", _.Msg.CONTROLS_FOR_TOOLTIP = "Have the variable '%1' take on the values from the start number to the end number, counting by the specified interval, and do the specified blocks.", _.Msg.CONTROLS_IF_ELSEIF_TOOLTIP = "Add a condition to the if block.", _.Msg.CONTROLS_IF_ELSE_TOOLTIP = "Add a final, catch-all condition to the if block.", _.Msg.CONTROLS_IF_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/IfElse", _.Msg.CONTROLS_IF_IF_TOOLTIP = "Add, remove, or reorder sections to reconfigure this if block.", _.Msg.CONTROLS_IF_MSG_ELSE = "else", _.Msg.CONTROLS_IF_MSG_ELSEIF = "else if", _.Msg.CONTROLS_IF_MSG_IF = "if", _.Msg.CONTROLS_IF_TOOLTIP_1 = "If a value is true, then do some statements.", _.Msg.CONTROLS_IF_TOOLTIP_2 = "If a value is true, then do the first block of statements. Otherwise, do the second block of statements.", _.Msg.CONTROLS_IF_TOOLTIP_3 = "If the first value is true, then do the first block of statements. Otherwise, if the second value is true, do the second block of statements.", _.Msg.CONTROLS_IF_TOOLTIP_4 = "If the first value is true, then do the first block of statements. Otherwise, if the second value is true, do the second block of statements. If none of the values are true, do the last block of statements.", _.Msg.CONTROLS_REPEAT_HELPURL = "https://en.wikipedia.org/wiki/For_loop", _.Msg.CONTROLS_REPEAT_INPUT_DO = "do", _.Msg.CONTROLS_REPEAT_TITLE = "repeat %1 times", _.Msg.CONTROLS_REPEAT_TOOLTIP = "Do some statements several times.", _.Msg.CONTROLS_WHILEUNTIL_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Loops#repeat", _.Msg.CONTROLS_WHILEUNTIL_OPERATOR_UNTIL = "repeat until", _.Msg.CONTROLS_WHILEUNTIL_OPERATOR_WHILE = "repeat while", _.Msg.CONTROLS_WHILEUNTIL_TOOLTIP_UNTIL = "While a value is false, then do some statements.", _.Msg.CONTROLS_WHILEUNTIL_TOOLTIP_WHILE = "While a value is true, then do some statements.", _.Msg.CONTROL_KEY = "Control", _.Msg.COPY_ALL_TO_BACKPACK = "Copy All Blocks to Backpack", _.Msg.COPY_SHORTCUT = "Copy", _.Msg.COPY_TO_BACKPACK = "Copy to Backpack", _.Msg.CURRENT_BLOCK_ANNOUNCEMENT = "Current block: %1", _.Msg.CUT_SHORTCUT = "Cut", _.Msg.DELETE_ALL_BLOCKS = "Delete all %1 blocks?", _.Msg.DELETE_BLOCK = "Delete Block", _.Msg.DELETE_KEY = "Delete", _.Msg.DELETE_VARIABLE = "Delete the '%1' variable", _.Msg.DELETE_VARIABLE_CONFIRMATION = "Delete %1 uses of the '%2' variable?", _.Msg.DELETE_X_BLOCKS = "Delete %1 Blocks", _.Msg.DIALOG_CANCEL = "Cancel", _.Msg.DIALOG_OK = "OK", _.Msg.DISABLE_BLOCK = "Disable Block", _.Msg.DUPLICATE_BLOCK = "Duplicate", _.Msg.DUPLICATE_COMMENT = "Duplicate Comment", _.Msg.EDIT_BLOCK_CONTENTS = "Edit Block contents", _.Msg.EMPTY_BACKPACK = "Empty Backpack", _.Msg.ENABLE_BLOCK = "Enable Block", _.Msg.END_KEY = "End", _.Msg.ENTER_KEY = "Enter", _.Msg.ESCAPE = "Escape", _.Msg.EXPAND_ALL = "Expand Blocks", _.Msg.EXPAND_BLOCK = "Expand Block", _.Msg.EXTERNAL_INPUTS = "External Inputs", _.Msg.FIELD_BITMAP_ARIA_VALUE = "%1 by %2, %3 pixels on", _.Msg.FIELD_BITMAP_BUTTON_LABEL_CLEAR = "Clear", _.Msg.FIELD_BITMAP_BUTTON_LABEL_RANDOMIZE = "Randomize", _.Msg.FIELD_BITMAP_PIXEL_LABEL = "%1, row %2, column %3", _.Msg.FIELD_BITMAP_PIXEL_OFF = "off", _.Msg.FIELD_BITMAP_PIXEL_ON = "on", _.Msg.FIELD_LABEL_CHECKBOX_CHECKED = "Checked", _.Msg.FIELD_LABEL_CHECKBOX_UNCHECKED = "Not checked", _.Msg.FIELD_LABEL_EDIT_PREFIX = "Edit %1", _.Msg.FIELD_LABEL_EMPTY = "empty", _.Msg.FIELD_LABEL_OPTION_INDEX = "Option %1", _.Msg.FIELD_LABEL_VARIABLE = "Variable '%1'", _.Msg.FIELD_MULTILINEINPUT_FINISH_EDITING = "Finish editing", _.Msg.FIELD_MULTILINEINPUT_NEW_LINE = "New line", _.Msg.HELP = "Help", _.Msg.HELP_PROMPT = "Press %1 for help on keyboard controls.", _.Msg.HOME_KEY = "Home", _.Msg.ICON_LABEL_COMMENT_CLOSED = "Open Comment", _.Msg.ICON_LABEL_COMMENT_OPEN = "Close Comment", _.Msg.ICON_LABEL_DEFAULT = "Icon", _.Msg.ICON_LABEL_MUTATOR_CLOSED = "Edit this block", _.Msg.ICON_LABEL_MUTATOR_OPEN = "Close block editor", _.Msg.ICON_LABEL_WARNING_CLOSED = "Open Warning", _.Msg.ICON_LABEL_WARNING_OPEN = "Close Warning", _.Msg.INLINE_INPUTS = "Inline Inputs", _.Msg.INPUT_LABEL_CONDITION = "condition", _.Msg.INPUT_LABEL_CONDITION_A = "first condition", _.Msg.INPUT_LABEL_CONDITION_B = "second condition", _.Msg.INPUT_LABEL_EMPTY = "Empty", _.Msg.INPUT_LABEL_END_STATEMENT = "End %1", _.Msg.INPUT_LABEL_INDEX = "input %1", _.Msg.INPUT_LABEL_LISTS_CREATE_WITH_ITEM = "value %1", _.Msg.INPUT_LABEL_LISTS_DELIMITER = "delimiter", _.Msg.INPUT_LABEL_LISTS_END_POSITION = "end position", _.Msg.INPUT_LABEL_LISTS_LIST_FROM_TEXT = "text to split", _.Msg.INPUT_LABEL_LISTS_POSITION = "position within list", _.Msg.INPUT_LABEL_LISTS_REPEAT_ITEM = "value to repeat", _.Msg.INPUT_LABEL_LISTS_REPEAT_NUM = "number of times to repeat", _.Msg.INPUT_LABEL_LISTS_START_POSITION = "start position", _.Msg.INPUT_LABEL_LISTS_TEXT_FROM_LIST = "list to join", _.Msg.INPUT_LABEL_LISTS_TO_CHANGE = "list to change", _.Msg.INPUT_LABEL_LISTS_TO_CHECK = "list to check", _.Msg.INPUT_LABEL_LISTS_VALUE_TO_SET = "value to set", _.Msg.INPUT_LABEL_LOOP_BY = "increment", _.Msg.INPUT_LABEL_LOOP_FROM = "starting number", _.Msg.INPUT_LABEL_LOOP_LIST = "list to iterate over", _.Msg.INPUT_LABEL_LOOP_TIMES = "number of times to repeat", _.Msg.INPUT_LABEL_LOOP_TO = "ending number", _.Msg.INPUT_LABEL_MATH_CHANGE_BY = "amount to change by", _.Msg.INPUT_LABEL_MATH_CONSTRAIN_VALUE = "number to constrain", _.Msg.INPUT_LABEL_MATH_DIVIDEND = "dividend", _.Msg.INPUT_LABEL_MATH_DIVISOR = "divisor", _.Msg.INPUT_LABEL_NUMBER = "number", _.Msg.INPUT_LABEL_NUMBER_A = "first number", _.Msg.INPUT_LABEL_NUMBER_ATAN2_X = "x coordinate", _.Msg.INPUT_LABEL_NUMBER_ATAN2_Y = "y coordinate", _.Msg.INPUT_LABEL_NUMBER_B = "second number", _.Msg.INPUT_LABEL_NUMBER_LIST = "list of numbers", _.Msg.INPUT_LABEL_NUMBER_MAX = "maximum", _.Msg.INPUT_LABEL_NUMBER_MIN = "minimum", _.Msg.INPUT_LABEL_NUMBER_TO_CHECK = "number to check", _.Msg.INPUT_LABEL_STATEMENT = "statement position", _.Msg.INPUT_LABEL_TEXT_APPEND = "value to append", _.Msg.INPUT_LABEL_TEXT_END_POSITION = "end position", _.Msg.INPUT_LABEL_TEXT_JOIN_ITEM = "value %1", _.Msg.INPUT_LABEL_TEXT_POSITION = "letter position", _.Msg.INPUT_LABEL_TEXT_PROMPT_MESSAGE = "message", _.Msg.INPUT_LABEL_TEXT_START_POSITION = "start position", _.Msg.INPUT_LABEL_TEXT_TO_CHANGE = "text to change", _.Msg.INPUT_LABEL_TEXT_TO_CHECK = "text to check", _.Msg.INPUT_LABEL_TEXT_TO_FIND = "text to find", _.Msg.INPUT_LABEL_TEXT_TO_REPLACE = "text to replace", _.Msg.INPUT_LABEL_VALUE = "value position", _.Msg.INPUT_LABEL_VALUE_A = "first value", _.Msg.INPUT_LABEL_VALUE_B = "second value", _.Msg.INPUT_LABEL_VARIABLES_SET = "value to set", _.Msg.INSERT_KEY = "Insert", _.Msg.KEYBOARD_NAV_BLOCK_NAVIGATION_HINT = "Use %1 to navigate inside of blocks.", _.Msg.KEYBOARD_NAV_CONSTRAINED_MOVE_HINT = "Use the arrow keys to move, then %1 to accept the position.", _.Msg.KEYBOARD_NAV_COPIED_HINT = "Copied. Press %1 to paste.", _.Msg.KEYBOARD_NAV_CUT_HINT = "Cut. Press %1 to paste.", _.Msg.KEYBOARD_NAV_FLYOUT_LABEL_HINT = "Use the arrow keys to navigate to a block, or press %1 to go to the next heading.", _.Msg.KEYBOARD_NAV_UNCONSTRAINED_MOVE_HINT = "Hold %1 and use arrow keys to move freely, then %2 to accept the position.", _.Msg.KEYBOARD_NAV_WORKSPACE_NAVIGATION_HINT = "Use the arrow keys to navigate.", _.Msg.LINUX = "Linux", _.Msg.LISTS_CREATE_EMPTY_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#create-empty-list", _.Msg.LISTS_CREATE_EMPTY_TITLE = "create empty list", _.Msg.LISTS_CREATE_EMPTY_TOOLTIP = "Returns a list, of length 0, containing no data records", _.Msg.LISTS_CREATE_WITH_CONTAINER_TITLE_ADD = "list", _.Msg.LISTS_CREATE_WITH_CONTAINER_TOOLTIP = "Add, remove, or reorder sections to reconfigure this list block.", _.Msg.LISTS_CREATE_WITH_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#create-list-with", _.Msg.LISTS_CREATE_WITH_INPUT_WITH = "create list with", _.Msg.LISTS_CREATE_WITH_ITEM_TOOLTIP = "Add an item to the list.", _.Msg.LISTS_CREATE_WITH_TOOLTIP = "Create a list with any number of items.", _.Msg.LISTS_GET_INDEX_FIRST = "first", _.Msg.LISTS_GET_INDEX_FROM_END = "# from end", _.Msg.LISTS_GET_INDEX_FROM_START = "#", _.Msg.LISTS_GET_INDEX_GET = "get", _.Msg.LISTS_GET_INDEX_GET_REMOVE = "get and remove", _.Msg.LISTS_GET_INDEX_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#getting-items-from-a-list", _.Msg.LISTS_GET_INDEX_LAST = "last", _.Msg.LISTS_GET_INDEX_RANDOM = "random", _.Msg.LISTS_GET_INDEX_REMOVE = "remove", _.Msg.LISTS_GET_INDEX_TAIL = "", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_FIRST = "Returns the first item in a list.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_FROM = "Returns the item at the specified position in a list.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_LAST = "Returns the last item in a list.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_RANDOM = "Returns a random item in a list.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_FIRST = "Removes and returns the first item in a list.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_FROM = "Removes and returns the item at the specified position in a list.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_LAST = "Removes and returns the last item in a list.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_RANDOM = "Removes and returns a random item in a list.", _.Msg.LISTS_GET_INDEX_TOOLTIP_REMOVE_FIRST = "Removes the first item in a list.", _.Msg.LISTS_GET_INDEX_TOOLTIP_REMOVE_FROM = "Removes the item at the specified position in a list.", _.Msg.LISTS_GET_INDEX_TOOLTIP_REMOVE_LAST = "Removes the last item in a list.", _.Msg.LISTS_GET_INDEX_TOOLTIP_REMOVE_RANDOM = "Removes a random item in a list.", _.Msg.LISTS_GET_SUBLIST_END_FROM_END = "to # from end", _.Msg.LISTS_GET_SUBLIST_END_FROM_START = "to #", _.Msg.LISTS_GET_SUBLIST_END_LAST = "to last", _.Msg.LISTS_GET_SUBLIST_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#getting-a-sublist", _.Msg.LISTS_GET_SUBLIST_START_FIRST = "get sub-list from first", _.Msg.LISTS_GET_SUBLIST_START_FROM_END = "get sub-list from # from end", _.Msg.LISTS_GET_SUBLIST_START_FROM_START = "get sub-list from #", _.Msg.LISTS_GET_SUBLIST_TAIL = "", _.Msg.LISTS_GET_SUBLIST_TOOLTIP = "Creates a copy of the specified portion of a list.", _.Msg.LISTS_INDEX_FROM_END_TOOLTIP = "%1 is the last item.", _.Msg.LISTS_INDEX_FROM_START_TOOLTIP = "%1 is the first item.", _.Msg.LISTS_INDEX_OF_FIRST = "find first occurrence of item", _.Msg.LISTS_INDEX_OF_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#finding-items-in-a-list", _.Msg.LISTS_INDEX_OF_LAST = "find last occurrence of item", _.Msg.LISTS_INDEX_OF_TOOLTIP = "Returns the index of the first/last occurrence of the item in the list. Returns %1 if item is not found.", _.Msg.LISTS_INLIST = "in list", _.Msg.LISTS_ISEMPTY_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#is-empty", _.Msg.LISTS_ISEMPTY_TITLE = "%1 is empty", _.Msg.LISTS_ISEMPTY_TOOLTIP = "Returns true if the list is empty.", _.Msg.LISTS_LENGTH_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#length-of", _.Msg.LISTS_LENGTH_TITLE = "length of %1", _.Msg.LISTS_LENGTH_TOOLTIP = "Returns the length of a list.", _.Msg.LISTS_REPEAT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#create-list-with", _.Msg.LISTS_REPEAT_TITLE = "create list with item %1 repeated %2 times", _.Msg.LISTS_REPEAT_TOOLTIP = "Creates a list consisting of the given value repeated the specified number of times.", _.Msg.LISTS_REVERSE_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#reversing-a-list", _.Msg.LISTS_REVERSE_MESSAGE0 = "reverse %1", _.Msg.LISTS_REVERSE_TOOLTIP = "Reverse a copy of a list.", _.Msg.LISTS_SET_INDEX_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#in-list--set", _.Msg.LISTS_SET_INDEX_INPUT_TO = "as", _.Msg.LISTS_SET_INDEX_INSERT = "insert at", _.Msg.LISTS_SET_INDEX_SET = "set", _.Msg.LISTS_SET_INDEX_TOOLTIP_INSERT_FIRST = "Inserts the item at the start of a list.", _.Msg.LISTS_SET_INDEX_TOOLTIP_INSERT_FROM = "Inserts the item at the specified position in a list.", _.Msg.LISTS_SET_INDEX_TOOLTIP_INSERT_LAST = "Append the item to the end of a list.", _.Msg.LISTS_SET_INDEX_TOOLTIP_INSERT_RANDOM = "Inserts the item randomly in a list.", _.Msg.LISTS_SET_INDEX_TOOLTIP_SET_FIRST = "Sets the first item in a list.", _.Msg.LISTS_SET_INDEX_TOOLTIP_SET_FROM = "Sets the item at the specified position in a list.", _.Msg.LISTS_SET_INDEX_TOOLTIP_SET_LAST = "Sets the last item in a list.", _.Msg.LISTS_SET_INDEX_TOOLTIP_SET_RANDOM = "Sets a random item in a list.", _.Msg.LISTS_SORT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#sorting-a-list", _.Msg.LISTS_SORT_ORDER_ASCENDING = "ascending", _.Msg.LISTS_SORT_ORDER_DESCENDING = "descending", _.Msg.LISTS_SORT_TITLE = "sort %1 %2 %3", _.Msg.LISTS_SORT_TOOLTIP = "Sort a copy of a list.", _.Msg.LISTS_SORT_TYPE_IGNORECASE = "alphabetic, ignore case", _.Msg.LISTS_SORT_TYPE_NUMERIC = "numeric", _.Msg.LISTS_SORT_TYPE_TEXT = "alphabetic", _.Msg.LISTS_SPLIT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#splitting-strings-and-joining-lists", _.Msg.LISTS_SPLIT_LIST_FROM_TEXT = "make list from text", _.Msg.LISTS_SPLIT_TEXT_FROM_LIST = "make text from list", _.Msg.LISTS_SPLIT_TOOLTIP_JOIN = "Join a list of texts into one text, separated by a delimiter.", _.Msg.LISTS_SPLIT_TOOLTIP_SPLIT = "Split text into a list of texts, breaking at each delimiter.", _.Msg.LISTS_SPLIT_WITH_DELIMITER = "with delimiter", _.Msg.LOGIC_BOOLEAN_FALSE = "false", _.Msg.LOGIC_BOOLEAN_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Logic#values", _.Msg.LOGIC_BOOLEAN_TOOLTIP = "Returns either true or false.", _.Msg.LOGIC_BOOLEAN_TRUE = "true", _.Msg.LOGIC_COMPARE_EQ_ARIA = "equals", _.Msg.LOGIC_COMPARE_GTE_ARIA = "greater than or equal to", _.Msg.LOGIC_COMPARE_GT_ARIA = "greater than", _.Msg.LOGIC_COMPARE_HELPURL = "https://en.wikipedia.org/wiki/Inequality_(mathematics)", _.Msg.LOGIC_COMPARE_LTE_ARIA = "less than or equal to", _.Msg.LOGIC_COMPARE_LT_ARIA = "less than", _.Msg.LOGIC_COMPARE_NEQ_ARIA = "not equals", _.Msg.LOGIC_COMPARE_TOOLTIP_EQ = "Return true if both inputs equal each other.", _.Msg.LOGIC_COMPARE_TOOLTIP_GT = "Return true if the first input is greater than the second input.", _.Msg.LOGIC_COMPARE_TOOLTIP_GTE = "Return true if the first input is greater than or equal to the second input.", _.Msg.LOGIC_COMPARE_TOOLTIP_LT = "Return true if the first input is smaller than the second input.", _.Msg.LOGIC_COMPARE_TOOLTIP_LTE = "Return true if the first input is smaller than or equal to the second input.", _.Msg.LOGIC_COMPARE_TOOLTIP_NEQ = "Return true if both inputs are not equal to each other.", _.Msg.LOGIC_NEGATE_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Logic#not", _.Msg.LOGIC_NEGATE_TITLE = "not %1", _.Msg.LOGIC_NEGATE_TOOLTIP = "Returns true if the input is false. Returns false if the input is true.", _.Msg.LOGIC_NULL = "null", _.Msg.LOGIC_NULL_HELPURL = "https://en.wikipedia.org/wiki/Nullable_type", _.Msg.LOGIC_NULL_TOOLTIP = "Returns null.", _.Msg.LOGIC_OPERATION_AND = "and", _.Msg.LOGIC_OPERATION_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Logic#logical-operations", _.Msg.LOGIC_OPERATION_OR = "or", _.Msg.LOGIC_OPERATION_TOOLTIP_AND = "Return true if both inputs are true.", _.Msg.LOGIC_OPERATION_TOOLTIP_OR = "Return true if at least one of the inputs is true.", _.Msg.LOGIC_TERNARY_CONDITION = "test", _.Msg.LOGIC_TERNARY_HELPURL = "https://en.wikipedia.org/wiki/%3F:", _.Msg.LOGIC_TERNARY_IF_FALSE = "if false", _.Msg.LOGIC_TERNARY_IF_TRUE = "if true", _.Msg.LOGIC_TERNARY_TOOLTIP = "Check the condition in 'test'. If the condition is true, returns the 'if true' value; otherwise returns the 'if false' value.", _.Msg.MAC_OS = "macOS", _.Msg.MATH_ADDITION_SYMBOL = "+", _.Msg.MATH_ADDITION_SYMBOL_ARIA = "plus", _.Msg.MATH_ARITHMETIC_HELPURL = "https://en.wikipedia.org/wiki/Arithmetic", _.Msg.MATH_ARITHMETIC_TOOLTIP_ADD = "Return the sum of the two numbers.", _.Msg.MATH_ARITHMETIC_TOOLTIP_DIVIDE = "Return the quotient of the two numbers.", _.Msg.MATH_ARITHMETIC_TOOLTIP_MINUS = "Return the difference of the two numbers.", _.Msg.MATH_ARITHMETIC_TOOLTIP_MULTIPLY = "Return the product of the two numbers.", _.Msg.MATH_ARITHMETIC_TOOLTIP_POWER = "Return the first number raised to the power of the second number.", _.Msg.MATH_ATAN2_HELPURL = "https://en.wikipedia.org/wiki/Atan2", _.Msg.MATH_ATAN2_TITLE = "atan2 of X:%1 Y:%2", _.Msg.MATH_ATAN2_TOOLTIP = "Return the arctangent of point (X, Y) in degrees from -180 to 180.", _.Msg.MATH_CHANGE_HELPURL = "https://en.wikipedia.org/wiki/Programming_idiom#Incrementing_a_counter", _.Msg.MATH_CHANGE_TITLE = "change %1 by %2", _.Msg.MATH_CHANGE_TOOLTIP = "Add a number to variable '%1'.", _.Msg.MATH_CONSTANT_E_ARIA = "e", _.Msg.MATH_CONSTANT_GOLDEN_RATIO_ARIA = "golden ratio", _.Msg.MATH_CONSTANT_HELPURL = "https://en.wikipedia.org/wiki/Mathematical_constant", _.Msg.MATH_CONSTANT_INFINITY_ARIA = "infinity", _.Msg.MATH_CONSTANT_PI_ARIA = "pi", _.Msg.MATH_CONSTANT_SQRT1_2_ARIA = "square root of 1 over 2", _.Msg.MATH_CONSTANT_SQRT2_ARIA = "square root of 2", _.Msg.MATH_CONSTANT_TOOLTIP = "Return one of the common constants: π (3.141…), e (2.718…), φ (1.618…), sqrt(2) (1.414…), sqrt(½) (0.707…), or ∞ (infinity).", _.Msg.MATH_CONSTRAIN_HELPURL = "https://en.wikipedia.org/wiki/Clamping_(graphics)", _.Msg.MATH_CONSTRAIN_TITLE = "constrain %1 low %2 high %3", _.Msg.MATH_CONSTRAIN_TOOLTIP = "Constrain a number to be between the specified limits (inclusive).", _.Msg.MATH_DIVISION_SYMBOL = "÷", _.Msg.MATH_DIVISION_SYMBOL_ARIA = "divided by", _.Msg.MATH_IS_DIVISIBLE_BY = "is divisible by", _.Msg.MATH_IS_EVEN = "is even", _.Msg.MATH_IS_NEGATIVE = "is negative", _.Msg.MATH_IS_ODD = "is odd", _.Msg.MATH_IS_POSITIVE = "is positive", _.Msg.MATH_IS_PRIME = "is prime", _.Msg.MATH_IS_TOOLTIP = "Check if a number is an even, odd, prime, whole, positive, negative, or if it is divisible by certain number. Returns true or false.", _.Msg.MATH_IS_WHOLE = "is whole", _.Msg.MATH_MODULO_HELPURL = "https://en.wikipedia.org/wiki/Modulo_operation", _.Msg.MATH_MODULO_TITLE = "remainder of %1 ÷ %2", _.Msg.MATH_MODULO_TOOLTIP = "Return the remainder from dividing the two numbers.", _.Msg.MATH_MULTIPLICATION_SYMBOL = "×", _.Msg.MATH_MULTIPLICATION_SYMBOL_ARIA = "times", _.Msg.MATH_NUMBER_HELPURL = "https://en.wikipedia.org/wiki/Number", _.Msg.MATH_NUMBER_TOOLTIP = "A number.", _.Msg.MATH_ONLIST_HELPURL = "", _.Msg.MATH_ONLIST_OPERATOR_AVERAGE = "average of list", _.Msg.MATH_ONLIST_OPERATOR_MAX = "max of list", _.Msg.MATH_ONLIST_OPERATOR_MAX_ARIA = "maximum", _.Msg.MATH_ONLIST_OPERATOR_MEDIAN = "median of list", _.Msg.MATH_ONLIST_OPERATOR_MIN = "min of list", _.Msg.MATH_ONLIST_OPERATOR_MIN_ARIA = "minimum", _.Msg.MATH_ONLIST_OPERATOR_MODE = "modes of list", _.Msg.MATH_ONLIST_OPERATOR_RANDOM = "random item of list", _.Msg.MATH_ONLIST_OPERATOR_STD_DEV = "standard deviation of list", _.Msg.MATH_ONLIST_OPERATOR_SUM = "sum of list", _.Msg.MATH_ONLIST_TOOLTIP_AVERAGE = "Return the average (arithmetic mean) of the numeric values in the list.", _.Msg.MATH_ONLIST_TOOLTIP_MAX = "Return the largest number in the list.", _.Msg.MATH_ONLIST_TOOLTIP_MEDIAN = "Return the median number in the list.", _.Msg.MATH_ONLIST_TOOLTIP_MIN = "Return the smallest number in the list.", _.Msg.MATH_ONLIST_TOOLTIP_MODE = "Return a list of the most common item(s) in the list.", _.Msg.MATH_ONLIST_TOOLTIP_RANDOM = "Return a random element from the list.", _.Msg.MATH_ONLIST_TOOLTIP_STD_DEV = "Return the standard deviation of the list.", _.Msg.MATH_ONLIST_TOOLTIP_SUM = "Return the sum of all the numbers in the list.", _.Msg.MATH_POWER_SYMBOL = "^", _.Msg.MATH_POWER_SYMBOL_ARIA = "to the power of", _.Msg.MATH_RANDOM_FLOAT_HELPURL = "https://en.wikipedia.org/wiki/Random_number_generation", _.Msg.MATH_RANDOM_FLOAT_TITLE_RANDOM = "random fraction", _.Msg.MATH_RANDOM_FLOAT_TOOLTIP = "Return a random fraction between 0.0 (inclusive) and 1.0 (exclusive).", _.Msg.MATH_RANDOM_INT_HELPURL = "https://en.wikipedia.org/wiki/Random_number_generation", _.Msg.MATH_RANDOM_INT_TITLE = "random integer from %1 to %2", _.Msg.MATH_RANDOM_INT_TOOLTIP = "Return a random integer between the two specified limits, inclusive.", _.Msg.MATH_ROUND_HELPURL = "https://en.wikipedia.org/wiki/Rounding", _.Msg.MATH_ROUND_OPERATOR_ROUND = "round", _.Msg.MATH_ROUND_OPERATOR_ROUNDDOWN = "round down", _.Msg.MATH_ROUND_OPERATOR_ROUNDUP = "round up", _.Msg.MATH_ROUND_TOOLTIP = "Round a number up or down.", _.Msg.MATH_SINGLE_HELPURL = "https://en.wikipedia.org/wiki/Square_root", _.Msg.MATH_SINGLE_OP_ABSOLUTE = "absolute", _.Msg.MATH_SINGLE_OP_ABSOLUTE_ARIA = "absolute value", _.Msg.MATH_SINGLE_OP_EXP_ARIA = "e to the power of", _.Msg.MATH_SINGLE_OP_LN_ARIA = "natural logarithm", _.Msg.MATH_SINGLE_OP_LOG10_ARIA = "base 10 logarithm", _.Msg.MATH_SINGLE_OP_NEG_ARIA = "negative", _.Msg.MATH_SINGLE_OP_POW10_ARIA = "10 to the power of", _.Msg.MATH_SINGLE_OP_ROOT = "square root", _.Msg.MATH_SINGLE_TOOLTIP_ABS = "Return the absolute value of a number.", _.Msg.MATH_SINGLE_TOOLTIP_EXP = "Return e to the power of a number.", _.Msg.MATH_SINGLE_TOOLTIP_LN = "Return the natural logarithm of a number.", _.Msg.MATH_SINGLE_TOOLTIP_LOG10 = "Return the base 10 logarithm of a number.", _.Msg.MATH_SINGLE_TOOLTIP_NEG = "Return the negation of a number.", _.Msg.MATH_SINGLE_TOOLTIP_POW10 = "Return 10 to the power of a number.", _.Msg.MATH_SINGLE_TOOLTIP_ROOT = "Return the square root of a number.", _.Msg.MATH_SUBTRACTION_SYMBOL = "-", _.Msg.MATH_SUBTRACTION_SYMBOL_ARIA = "minus", _.Msg.MATH_TRIG_ACOS = "acos", _.Msg.MATH_TRIG_ACOS_ARIA = "inverse cosine", _.Msg.MATH_TRIG_ASIN = "asin", _.Msg.MATH_TRIG_ASIN_ARIA = "inverse sine", _.Msg.MATH_TRIG_ATAN = "atan", _.Msg.MATH_TRIG_ATAN_ARIA = "inverse tangent", _.Msg.MATH_TRIG_COS = "cos", _.Msg.MATH_TRIG_COS_ARIA = "cosine", _.Msg.MATH_TRIG_HELPURL = "https://en.wikipedia.org/wiki/Trigonometric_functions", _.Msg.MATH_TRIG_SIN = "sin", _.Msg.MATH_TRIG_SIN_ARIA = "sine", _.Msg.MATH_TRIG_TAN = "tan", _.Msg.MATH_TRIG_TAN_ARIA = "tangent", _.Msg.MATH_TRIG_TOOLTIP_ACOS = "Return the arccosine of a number.", _.Msg.MATH_TRIG_TOOLTIP_ASIN = "Return the arcsine of a number.", _.Msg.MATH_TRIG_TOOLTIP_ATAN = "Return the arctangent of a number.", _.Msg.MATH_TRIG_TOOLTIP_COS = "Return the cosine of a degree (not radian).", _.Msg.MATH_TRIG_TOOLTIP_SIN = "Return the sine of a degree (not radian).", _.Msg.MATH_TRIG_TOOLTIP_TAN = "Return the tangent of a degree (not radian).", _.Msg.MINIMAP_ARIA_LABEL = "Workspace minimap. Use the arrow keys to pan the workspace.", _.Msg.MOVE_BLOCK = "Move Block", _.Msg.NEW_COLOUR_VARIABLE = "Create colour variable...", _.Msg.NEW_NUMBER_VARIABLE = "Create number variable...", _.Msg.NEW_STRING_VARIABLE = "Create string variable...", _.Msg.NEW_VARIABLE = "Create variable...", _.Msg.NEW_VARIABLE_TITLE = "New variable name:", _.Msg.NEW_VARIABLE_TYPE_TITLE = "New variable type:", _.Msg.NO_PARENT_ANNOUNCEMENT = "Current block has no parent", _.Msg.OPEN_BACKPACK = "Open backpack", _.Msg.OPEN_TRASH = "Open trash", _.Msg.OPTION_KEY = "Option", _.Msg.ORDINAL_NUMBER_SUFFIX = "", _.Msg.PAGE_DOWN_KEY = "Page Down", _.Msg.PAGE_UP_KEY = "Page Up", _.Msg.PARENT_BLOCKS_ANNOUNCEMENT = "Parent blocks: %1", _.Msg.PASTE_ALL_FROM_BACKPACK = "Paste All Blocks from Backpack", _.Msg.PASTE_SHORTCUT = "Paste", _.Msg.PAUSE_KEY = "Pause", _.Msg.PROCEDURES_ALLOW_STATEMENTS = "allow statements", _.Msg.PROCEDURES_BEFORE_PARAMS = "with:", _.Msg.PROCEDURES_CALLNORETURN_HELPURL = "https://en.wikipedia.org/wiki/Subroutine", _.Msg.PROCEDURES_CALLNORETURN_TOOLTIP = "Run the user-defined function '%1'.", _.Msg.PROCEDURES_CALLRETURN_HELPURL = "https://en.wikipedia.org/wiki/Subroutine", _.Msg.PROCEDURES_CALLRETURN_TOOLTIP = "Run the user-defined function '%1' and use its output.", _.Msg.PROCEDURES_CALL_BEFORE_PARAMS = "with:", _.Msg.PROCEDURES_CALL_DISABLED_DEF_WARNING = "Can't run the user-defined function '%1' because the definition block is disabled.", _.Msg.PROCEDURES_CREATE_DO = "Create '%1'", _.Msg.PROCEDURES_DEFNORETURN_COMMENT = "Describe this function...", _.Msg.PROCEDURES_DEFNORETURN_DO = "", _.Msg.PROCEDURES_DEFNORETURN_HELPURL = "https://en.wikipedia.org/wiki/Subroutine", _.Msg.PROCEDURES_DEFNORETURN_PROCEDURE = "do something", _.Msg.PROCEDURES_DEFNORETURN_TITLE = "to", _.Msg.PROCEDURES_DEFNORETURN_TOOLTIP = "Creates a function with no output.", _.Msg.PROCEDURES_DEFRETURN_HELPURL = "https://en.wikipedia.org/wiki/Subroutine", _.Msg.PROCEDURES_DEFRETURN_RETURN = "return", _.Msg.PROCEDURES_DEFRETURN_TOOLTIP = "Creates a function with an output.", _.Msg.PROCEDURES_DEF_DUPLICATE_WARNING = "Warning: This function has duplicate parameters.", _.Msg.PROCEDURES_HIGHLIGHT_DEF = "Highlight function definition", _.Msg.PROCEDURES_IFRETURN_HELPURL = "https://c2.com/cgi/wiki?GuardClause", _.Msg.PROCEDURES_IFRETURN_TOOLTIP = "If a value is true, then return a second value.", _.Msg.PROCEDURES_IFRETURN_WARNING = "Warning: This block may be used only within a function definition.", _.Msg.PROCEDURES_MUTATORARG_TITLE = "input name:", _.Msg.PROCEDURES_MUTATORARG_TOOLTIP = "Add an input to the function.", _.Msg.PROCEDURES_MUTATORCONTAINER_TITLE = "inputs", _.Msg.PROCEDURES_MUTATORCONTAINER_TOOLTIP = "Add, remove, or reorder inputs to this function.", _.Msg.REDO = "Redo", _.Msg.REMOVE_COMMENT = "Remove Comment", _.Msg.REMOVE_FROM_BACKPACK = "Remove from Backpack", _.Msg.RENAME_VARIABLE = "Rename the '%1' variable", _.Msg.RENAME_VARIABLE_TITLE = "Rename all '%1' variables to:", _.Msg.RESET_ZOOM = "Reset zoom", _.Msg.SCREENREADER_HINT = "Use the arrow keys to navigate. Press %1 to toggle screenreader accessibility mode.", _.Msg.SCREENREADER_MODE_DISABLED = "Screenreader mode is off, press %1 to turn it on", _.Msg.SCREENREADER_MODE_ENABLED = "Screenreader mode is on, press %1 to turn it off", _.Msg.SHIFT_KEY = "Shift", _.Msg.SHORTCUTS_ABORT_MOVE = "Abort move", _.Msg.SHORTCUTS_CLEANUP = "Clean up workspace", _.Msg.SHORTCUTS_CODE_NAVIGATION = "Code navigation", _.Msg.SHORTCUTS_DELETE = "Delete", _.Msg.SHORTCUTS_DISCONNECT = "Disconnect block", _.Msg.SHORTCUTS_DUPLICATE = "Duplicate", _.Msg.SHORTCUTS_EDITING = "Editing", _.Msg.SHORTCUTS_ESCAPE = "Exit", _.Msg.SHORTCUTS_EXTENDED_INFORMATION = "Announce detailed information", _.Msg.SHORTCUTS_FINISH_MOVE = "Finish move", _.Msg.SHORTCUTS_FOCUS_TOOLBOX = "Focus toolbox", _.Msg.SHORTCUTS_FOCUS_WORKSPACE = "Focus workspace", _.Msg.SHORTCUTS_GENERAL = "General", _.Msg.SHORTCUTS_INFORMATION = "Announce information", _.Msg.SHORTCUTS_JUMP_BLOCK_END = "Jump to block end", _.Msg.SHORTCUTS_JUMP_BLOCK_START = "Jump to block start", _.Msg.SHORTCUTS_JUMP_BOTTOM_STACK = "Jump to bottom of stack", _.Msg.SHORTCUTS_JUMP_FIRST_BLOCK = "Jump to first block", _.Msg.SHORTCUTS_JUMP_LAST_BLOCK = "Jump to last block", _.Msg.SHORTCUTS_JUMP_NEXT_PAGE = "Jump to next page", _.Msg.SHORTCUTS_JUMP_PREVIOUS_PAGE = "Jump to previous page", _.Msg.SHORTCUTS_JUMP_TOP_STACK = "Jump to top of stack", _.Msg.SHORTCUTS_MOVE_DOWN = "Move down", _.Msg.SHORTCUTS_MOVE_LEFT = "Move left", _.Msg.SHORTCUTS_MOVE_RIGHT = "Move right", _.Msg.SHORTCUTS_MOVE_UP = "Move up", _.Msg.SHORTCUTS_NEXT_HEADING = "Next heading", _.Msg.SHORTCUTS_NEXT_STACK = "Next stack", _.Msg.SHORTCUTS_PERFORM_ACTION = "Edit or confirm", _.Msg.SHORTCUTS_PREVIOUS_HEADING = "Previous heading", _.Msg.SHORTCUTS_PREVIOUS_STACK = "Previous stack", _.Msg.SHORTCUTS_SCROLL_DOWN = "Scroll down", _.Msg.SHORTCUTS_SCROLL_LEFT = "Scroll left", _.Msg.SHORTCUTS_SCROLL_RIGHT = "Scroll right", _.Msg.SHORTCUTS_SCROLL_UP = "Scroll up", _.Msg.SHORTCUTS_SHOW_CONTEXT_MENU = "Show menu", _.Msg.SHORTCUTS_SHOW_TOOLTIP = "Show tooltip", _.Msg.SHORTCUTS_START_MOVE = "Start move", _.Msg.SHORTCUTS_START_MOVE_STACK = "Start move stack", _.Msg.SHORTCUTS_TOGGLE_SCREENREADER_MODE = "Toggle screenreader mode", _.Msg.SPACE_KEY = "Space", _.Msg.TAB_KEY = "Tab", _.Msg.TEXT_APPEND_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#text-modification", _.Msg.TEXT_APPEND_TITLE = "to %1 append text %2", _.Msg.TEXT_APPEND_TOOLTIP = "Append some text to variable '%1'.", _.Msg.TEXT_CHANGECASE_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#adjusting-text-case", _.Msg.TEXT_CHANGECASE_OPERATOR_LOWERCASE = "to lower case", _.Msg.TEXT_CHANGECASE_OPERATOR_TITLECASE = "to Title Case", _.Msg.TEXT_CHANGECASE_OPERATOR_UPPERCASE = "to UPPER CASE", _.Msg.TEXT_CHANGECASE_TOOLTIP = "Return a copy of the text in a different case.", _.Msg.TEXT_CHARAT_FIRST = "get first letter", _.Msg.TEXT_CHARAT_FROM_END = "get letter # from end", _.Msg.TEXT_CHARAT_FROM_START = "get letter #", _.Msg.TEXT_CHARAT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#extracting-text", _.Msg.TEXT_CHARAT_LAST = "get last letter", _.Msg.TEXT_CHARAT_RANDOM = "get random letter", _.Msg.TEXT_CHARAT_TAIL = "", _.Msg.TEXT_CHARAT_TITLE = "in text %1 %2", _.Msg.TEXT_CHARAT_TOOLTIP = "Returns the letter at the specified position.", _.Msg.TEXT_COUNT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#counting-substrings", _.Msg.TEXT_COUNT_MESSAGE0 = "count %1 in %2", _.Msg.TEXT_COUNT_TOOLTIP = "Count how many times some text occurs within some other text.", _.Msg.TEXT_CREATE_JOIN_ITEM_TOOLTIP = "Add an item to the text.", _.Msg.TEXT_CREATE_JOIN_TITLE_JOIN = "join", _.Msg.TEXT_CREATE_JOIN_TOOLTIP = "Add, remove, or reorder sections to reconfigure this text block.", _.Msg.TEXT_FROM_END_ARIA = "letter number from end", _.Msg.TEXT_FROM_START_ARIA = "letter number", _.Msg.TEXT_GET_SUBSTRING_END_FROM_END = "to letter # from end", _.Msg.TEXT_GET_SUBSTRING_END_FROM_START = "to letter #", _.Msg.TEXT_GET_SUBSTRING_END_LAST = "to last letter", _.Msg.TEXT_GET_SUBSTRING_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#extracting-a-region-of-text", _.Msg.TEXT_GET_SUBSTRING_INPUT_IN_TEXT = "in text", _.Msg.TEXT_GET_SUBSTRING_START_FIRST = "get substring from first letter", _.Msg.TEXT_GET_SUBSTRING_START_FROM_END = "get substring from letter # from end", _.Msg.TEXT_GET_SUBSTRING_START_FROM_START = "get substring from letter #", _.Msg.TEXT_GET_SUBSTRING_TAIL = "", _.Msg.TEXT_GET_SUBSTRING_TOOLTIP = "Returns a specified portion of the text.", _.Msg.TEXT_INDEXOF_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#finding-text", _.Msg.TEXT_INDEXOF_OPERATOR_FIRST = "find first occurrence of text", _.Msg.TEXT_INDEXOF_OPERATOR_LAST = "find last occurrence of text", _.Msg.TEXT_INDEXOF_TITLE = "in text %1 %2 %3", _.Msg.TEXT_INDEXOF_TOOLTIP = "Returns the index of the first/last occurrence of the first text in the second text. Returns %1 if text is not found.", _.Msg.TEXT_ISEMPTY_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#checking-for-empty-text", _.Msg.TEXT_ISEMPTY_TITLE = "%1 is empty", _.Msg.TEXT_ISEMPTY_TOOLTIP = "Returns true if the provided text is empty.", _.Msg.TEXT_JOIN_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#text-creation", _.Msg.TEXT_JOIN_TITLE_CREATEWITH = "create text with", _.Msg.TEXT_JOIN_TOOLTIP = "Create a piece of text by joining together any number of items.", _.Msg.TEXT_LENGTH_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#text-modification", _.Msg.TEXT_LENGTH_TITLE = "length of %1", _.Msg.TEXT_LENGTH_TOOLTIP = "Returns the number of letters (including spaces) in the provided text.", _.Msg.TEXT_PRINT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#printing-text", _.Msg.TEXT_PRINT_TITLE = "print %1", _.Msg.TEXT_PRINT_TOOLTIP = "Print the specified text, number or other value.", _.Msg.TEXT_PROMPT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#getting-input-from-the-user", _.Msg.TEXT_PROMPT_TOOLTIP_NUMBER = "Prompt for user for a number.", _.Msg.TEXT_PROMPT_TOOLTIP_TEXT = "Prompt for user for some text.", _.Msg.TEXT_PROMPT_TYPE_NUMBER = "prompt for number with message", _.Msg.TEXT_PROMPT_TYPE_TEXT = "prompt for text with message", _.Msg.TEXT_REPLACE_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#replacing-substrings", _.Msg.TEXT_REPLACE_MESSAGE0 = "replace %1 with %2 in %3", _.Msg.TEXT_REPLACE_TOOLTIP = "Replace all occurances of some text within some other text.", _.Msg.TEXT_REVERSE_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#reversing-text", _.Msg.TEXT_REVERSE_MESSAGE0 = "reverse %1", _.Msg.TEXT_REVERSE_TOOLTIP = "Reverses the order of the characters in the text.", _.Msg.TEXT_TEXT_HELPURL = "https://en.wikipedia.org/wiki/String_(computer_science)", _.Msg.TEXT_TEXT_TOOLTIP = "A letter, word, or line of text.", _.Msg.TEXT_TRIM_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#trimming-removing-spaces", _.Msg.TEXT_TRIM_OPERATOR_BOTH = "trim spaces from both sides of", _.Msg.TEXT_TRIM_OPERATOR_LEFT = "trim spaces from left side of", _.Msg.TEXT_TRIM_OPERATOR_RIGHT = "trim spaces from right side of", _.Msg.TEXT_TRIM_TOOLTIP = "Return a copy of the text with spaces removed from one or both ends.", _.Msg.TODAY = "Today", _.Msg.TOOLBOX_SEARCH_NO_RESULTS = "No matching blocks found", _.Msg.TOOLBOX_SEARCH_PLACEHOLDER = "Search for blocks", _.Msg.TOOLBOX_SEARCH_PROMPT = "Type to search for blocks", _.Msg.TOOLBOX_SEARCH_RESULT_COUNT = "%1 matching blocks", _.Msg.TOOLBOX_SEARCH_RESULT_COUNT_ONE = "1 matching block", _.Msg.UNDO = "Undo", _.Msg.UNKNOWN = "Unknown", _.Msg.UNNAMED_KEY = "unnamed", _.Msg.VARIABLES_DEFAULT_NAME = "item", _.Msg.VARIABLES_GET_CREATE_SET = "Create 'set %1'", _.Msg.VARIABLES_GET_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Variables#get", _.Msg.VARIABLES_GET_TOOLTIP = "Returns the value of this variable.", _.Msg.VARIABLES_SET = "set %1 to %2", _.Msg.VARIABLES_SET_CREATE_GET = "Create 'get %1'", _.Msg.VARIABLES_SET_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Variables#set", _.Msg.VARIABLES_SET_TOOLTIP = "Sets this variable to be equal to the input.", _.Msg.VARIABLE_ALREADY_EXISTS = "A variable named '%1' already exists.", _.Msg.VARIABLE_ALREADY_EXISTS_FOR_ANOTHER_TYPE = "A variable named '%1' already exists for another type: '%2'.", _.Msg.VARIABLE_ALREADY_EXISTS_FOR_A_PARAMETER = "A variable named '%1' already exists as a parameter in the procedure '%2'.", _.Msg.WINDOWS = "Windows", _.Msg.WORKSPACE_COMMENT_DEFAULT_TEXT = "Say something...", _.Msg.WORKSPACE_CONTENTS_BLOCKS_MANY = "%1 stacks of blocks%2 in workspace.", _.Msg.WORKSPACE_CONTENTS_BLOCKS_ONE = "One stack of blocks%2 in workspace.", _.Msg.WORKSPACE_CONTENTS_BLOCKS_ZERO = "No blocks%2 in workspace.", _.Msg.WORKSPACE_CONTENTS_COMMENTS_MANY = " and %1 comments", _.Msg.WORKSPACE_CONTENTS_COMMENTS_ONE = " and one comment", _.Msg.WORKSPACE_LABEL_1_STACK = "1 stack of blocks", _.Msg.WORKSPACE_LABEL_FLYOUT_WORKSPACE = "%1 blocks", _.Msg.WORKSPACE_LABEL_MANY_STACKS = "%1 stacks of blocks", _.Msg.WORKSPACE_LABEL_MUTATOR_WORKSPACE = "Block editor workspace", _.Msg.WORKSPACE_LABEL_PLAIN = "Blocks workspace.", _.Msg.WORKSPACE_ROLEDESCRIPTION = "workspace", _.Msg.WORKSPACE_SEARCH_CLOSE = "Close search bar", _.Msg.WORKSPACE_SEARCH_FIND_NEXT = "Find next", _.Msg.WORKSPACE_SEARCH_FIND_PREVIOUS = "Find previous", _.Msg.WORKSPACE_SEARCH_INPUT_LABEL = "Search workspace. Press Enter for the next match, Shift+Enter for the previous match. Press Escape to close search and focus the current match.", _.Msg.WORKSPACE_SEARCH_MATCH = "Match %1 of %2: %3", _.Msg.WORKSPACE_SEARCH_NO_MATCHES = "No matching blocks", _.Msg.WORKSPACE_SEARCH_PLACEHOLDER = "Search", _.Msg.ZOOM_IN = "Zoom in", _.Msg.ZOOM_OUT = "Zoom out", _.Msg.ZOOM_TO_FIT_ARIA_LABEL = "Zoom to fit", _.Msg.CONTROLS_FOREACH_INPUT_DO = _.Msg.CONTROLS_REPEAT_INPUT_DO, _.Msg.CONTROLS_FOR_INPUT_DO = _.Msg.CONTROLS_REPEAT_INPUT_DO, _.Msg.CONTROLS_IF_ELSEIF_TITLE_ELSEIF = _.Msg.CONTROLS_IF_MSG_ELSEIF, _.Msg.CONTROLS_IF_ELSE_TITLE_ELSE = _.Msg.CONTROLS_IF_MSG_ELSE, _.Msg.CONTROLS_IF_IF_TITLE_IF = _.Msg.CONTROLS_IF_MSG_IF, _.Msg.CONTROLS_IF_MSG_THEN = _.Msg.CONTROLS_REPEAT_INPUT_DO, _.Msg.CONTROLS_WHILEUNTIL_INPUT_DO = _.Msg.CONTROLS_REPEAT_INPUT_DO, _.Msg.LISTS_CREATE_WITH_ITEM_TITLE = _.Msg.VARIABLES_DEFAULT_NAME, _.Msg.LISTS_GET_INDEX_INPUT_IN_LIST = _.Msg.LISTS_INLIST, _.Msg.LISTS_GET_SUBLIST_INPUT_IN_LIST = _.Msg.LISTS_INLIST, _.Msg.LISTS_INDEX_OF_INPUT_IN_LIST = _.Msg.LISTS_INLIST, _.Msg.LISTS_SET_INDEX_INPUT_IN_LIST = _.Msg.LISTS_INLIST, _.Msg.MATH_CHANGE_TITLE_ITEM = _.Msg.VARIABLES_DEFAULT_NAME, _.Msg.PROCEDURES_DEFRETURN_COMMENT = _.Msg.PROCEDURES_DEFNORETURN_COMMENT, _.Msg.PROCEDURES_DEFRETURN_DO = _.Msg.PROCEDURES_DEFNORETURN_DO, _.Msg.PROCEDURES_DEFRETURN_PROCEDURE = _.Msg.PROCEDURES_DEFNORETURN_PROCEDURE, _.Msg.PROCEDURES_DEFRETURN_TITLE = _.Msg.PROCEDURES_DEFNORETURN_TITLE, _.Msg.TEXT_APPEND_VARIABLE = _.Msg.VARIABLES_DEFAULT_NAME, _.Msg.TEXT_CREATE_JOIN_ITEM_TITLE_ITEM = _.Msg.VARIABLES_DEFAULT_NAME, _.Msg.COLOUR_HUE = "20", _.Msg.LISTS_HUE = "260", _.Msg.LOGIC_HUE = "210", _.Msg.LOOPS_HUE = "120", _.Msg.MATH_HUE = "230", _.Msg.PROCEDURES_HUE = "290", _.Msg.TEXTS_HUE = "160", _.Msg.VARIABLES_DYNAMIC_HUE = "310", _.Msg.VARIABLES_HUE = "330", _.Msg;
    });
  })(W)), W.exports;
}
var m_ = F_();
const h_ = /* @__PURE__ */ r_(m_), {
  LOGIC_HUE: p_,
  LOOPS_HUE: f_,
  MATH_HUE: G_,
  TEXTS_HUE: v_,
  LISTS_HUE: X_,
  COLOUR_HUE: V_,
  VARIABLES_HUE: $_,
  VARIABLES_DYNAMIC_HUE: k_,
  PROCEDURES_HUE: x_,
  VARIABLES_DEFAULT_NAME: Y_,
  UNNAMED_KEY: K_,
  TODAY: w_,
  DUPLICATE_BLOCK: y_,
  ADD_COMMENT: W_,
  REMOVE_COMMENT: b_,
  DUPLICATE_COMMENT: j_,
  EXTERNAL_INPUTS: J_,
  INLINE_INPUTS: q_,
  DELETE_BLOCK: z_,
  DELETE_X_BLOCKS: Q_,
  DELETE_ALL_BLOCKS: Z_,
  CLEAN_UP: _T,
  CLOSE: TT,
  COLLAPSE_BLOCK: ET,
  COLLAPSE_ALL: eT,
  EXPAND_BLOCK: tT,
  EXPAND_ALL: OT,
  DISABLE_BLOCK: LT,
  ENABLE_BLOCK: IT,
  HELP: AT,
  UNDO: NT,
  REDO: RT,
  CHANGE_VALUE_TITLE: nT,
  RENAME_VARIABLE: rT,
  RENAME_VARIABLE_TITLE: iT,
  NEW_VARIABLE: sT,
  NEW_STRING_VARIABLE: ST,
  NEW_NUMBER_VARIABLE: oT,
  NEW_COLOUR_VARIABLE: MT,
  NEW_VARIABLE_TYPE_TITLE: CT,
  NEW_VARIABLE_TITLE: PT,
  VARIABLE_ALREADY_EXISTS: aT,
  VARIABLE_ALREADY_EXISTS_FOR_ANOTHER_TYPE: lT,
  VARIABLE_ALREADY_EXISTS_FOR_A_PARAMETER: uT,
  DELETE_VARIABLE_CONFIRMATION: UT,
  CANNOT_DELETE_VARIABLE_PROCEDURE: cT,
  DELETE_VARIABLE: DT,
  COLOUR_PICKER_HELPURL: dT,
  COLOUR_PICKER_TOOLTIP: gT,
  COLOUR_RANDOM_HELPURL: HT,
  COLOUR_RANDOM_TITLE: BT,
  COLOUR_RANDOM_TOOLTIP: FT,
  COLOUR_RGB_HELPURL: mT,
  COLOUR_RGB_TITLE: hT,
  COLOUR_RGB_RED: pT,
  COLOUR_RGB_GREEN: fT,
  COLOUR_RGB_BLUE: GT,
  COLOUR_RGB_TOOLTIP: vT,
  COLOUR_BLEND_HELPURL: XT,
  COLOUR_BLEND_TITLE: VT,
  COLOUR_BLEND_COLOUR1: $T,
  COLOUR_BLEND_COLOUR2: kT,
  COLOUR_BLEND_RATIO: xT,
  COLOUR_BLEND_TOOLTIP: YT,
  CONTROLS_REPEAT_HELPURL: KT,
  CONTROLS_REPEAT_TITLE: wT,
  CONTROLS_REPEAT_INPUT_DO: yT,
  CONTROLS_REPEAT_TOOLTIP: WT,
  CONTROLS_WHILEUNTIL_HELPURL: bT,
  CONTROLS_WHILEUNTIL_INPUT_DO: jT,
  CONTROLS_WHILEUNTIL_OPERATOR_WHILE: JT,
  CONTROLS_WHILEUNTIL_OPERATOR_UNTIL: qT,
  CONTROLS_WHILEUNTIL_TOOLTIP_WHILE: zT,
  CONTROLS_WHILEUNTIL_TOOLTIP_UNTIL: QT,
  CONTROLS_FOR_HELPURL: ZT,
  CONTROLS_FOR_TOOLTIP: _E,
  CONTROLS_FOR_TITLE: TE,
  CONTROLS_FOR_INPUT_DO: EE,
  CONTROLS_FOREACH_HELPURL: eE,
  CONTROLS_FOREACH_TITLE: tE,
  CONTROLS_FOREACH_INPUT_DO: OE,
  CONTROLS_FOREACH_TOOLTIP: LE,
  CONTROLS_FLOW_STATEMENTS_HELPURL: IE,
  CONTROLS_FLOW_STATEMENTS_OPERATOR_BREAK: AE,
  CONTROLS_FLOW_STATEMENTS_OPERATOR_CONTINUE: NE,
  CONTROLS_FLOW_STATEMENTS_TOOLTIP_BREAK: RE,
  CONTROLS_FLOW_STATEMENTS_TOOLTIP_CONTINUE: nE,
  CONTROLS_FLOW_STATEMENTS_WARNING: rE,
  CONTROLS_IF_HELPURL: iE,
  CONTROLS_IF_TOOLTIP_1: sE,
  CONTROLS_IF_TOOLTIP_2: SE,
  CONTROLS_IF_TOOLTIP_3: oE,
  CONTROLS_IF_TOOLTIP_4: ME,
  CONTROLS_IF_MSG_IF: CE,
  CONTROLS_IF_MSG_ELSEIF: PE,
  CONTROLS_IF_MSG_ELSE: aE,
  CONTROLS_IF_MSG_THEN: lE,
  CONTROLS_IF_IF_TITLE_IF: uE,
  CONTROLS_IF_IF_TOOLTIP: UE,
  CONTROLS_IF_ELSEIF_TITLE_ELSEIF: cE,
  CONTROLS_IF_ELSEIF_TOOLTIP: DE,
  CONTROLS_IF_ELSE_TITLE_ELSE: dE,
  CONTROLS_IF_ELSE_TOOLTIP: gE,
  LOGIC_COMPARE_HELPURL: HE,
  LOGIC_COMPARE_EQ_ARIA: BE,
  LOGIC_COMPARE_TOOLTIP_EQ: FE,
  LOGIC_COMPARE_NEQ_ARIA: mE,
  LOGIC_COMPARE_TOOLTIP_NEQ: hE,
  LOGIC_COMPARE_LT_ARIA: pE,
  LOGIC_COMPARE_TOOLTIP_LT: fE,
  LOGIC_COMPARE_LTE_ARIA: GE,
  LOGIC_COMPARE_TOOLTIP_LTE: vE,
  LOGIC_COMPARE_GT_ARIA: XE,
  LOGIC_COMPARE_TOOLTIP_GT: VE,
  LOGIC_COMPARE_GTE_ARIA: $E,
  LOGIC_COMPARE_TOOLTIP_GTE: kE,
  LOGIC_OPERATION_HELPURL: xE,
  LOGIC_OPERATION_TOOLTIP_AND: YE,
  LOGIC_OPERATION_AND: KE,
  LOGIC_OPERATION_TOOLTIP_OR: wE,
  LOGIC_OPERATION_OR: yE,
  LOGIC_NEGATE_HELPURL: WE,
  LOGIC_NEGATE_TITLE: bE,
  LOGIC_NEGATE_TOOLTIP: jE,
  LOGIC_BOOLEAN_HELPURL: JE,
  LOGIC_BOOLEAN_TRUE: qE,
  LOGIC_BOOLEAN_FALSE: zE,
  LOGIC_BOOLEAN_TOOLTIP: QE,
  LOGIC_NULL_HELPURL: ZE,
  LOGIC_NULL: _e,
  LOGIC_NULL_TOOLTIP: Te,
  LOGIC_TERNARY_HELPURL: Ee,
  LOGIC_TERNARY_CONDITION: ee,
  LOGIC_TERNARY_IF_TRUE: te,
  LOGIC_TERNARY_IF_FALSE: Oe,
  LOGIC_TERNARY_TOOLTIP: Le,
  MATH_NUMBER_HELPURL: Ie,
  MATH_NUMBER_TOOLTIP: Ae,
  MATH_ADDITION_SYMBOL: Ne,
  MATH_ADDITION_SYMBOL_ARIA: Re,
  MATH_SUBTRACTION_SYMBOL: ne,
  MATH_SUBTRACTION_SYMBOL_ARIA: re,
  MATH_DIVISION_SYMBOL: ie,
  MATH_DIVISION_SYMBOL_ARIA: se,
  MATH_MULTIPLICATION_SYMBOL: Se,
  MATH_MULTIPLICATION_SYMBOL_ARIA: oe,
  MATH_POWER_SYMBOL: Me,
  MATH_POWER_SYMBOL_ARIA: Ce,
  MATH_TRIG_SIN: Pe,
  MATH_TRIG_SIN_ARIA: ae,
  MATH_TRIG_COS: le,
  MATH_TRIG_COS_ARIA: ue,
  MATH_TRIG_TAN: Ue,
  MATH_TRIG_TAN_ARIA: ce,
  MATH_TRIG_ASIN: De,
  MATH_TRIG_ASIN_ARIA: de,
  MATH_TRIG_ACOS: ge,
  MATH_TRIG_ACOS_ARIA: He,
  MATH_TRIG_ATAN: Be,
  MATH_TRIG_ATAN_ARIA: Fe,
  MATH_CONSTANT_PI_ARIA: me,
  MATH_CONSTANT_E_ARIA: he,
  MATH_CONSTANT_GOLDEN_RATIO_ARIA: pe,
  MATH_CONSTANT_SQRT2_ARIA: fe,
  MATH_CONSTANT_SQRT1_2_ARIA: Ge,
  MATH_CONSTANT_INFINITY_ARIA: ve,
  MATH_ARITHMETIC_HELPURL: Xe,
  MATH_ARITHMETIC_TOOLTIP_ADD: Ve,
  MATH_ARITHMETIC_TOOLTIP_MINUS: $e,
  MATH_ARITHMETIC_TOOLTIP_MULTIPLY: ke,
  MATH_ARITHMETIC_TOOLTIP_DIVIDE: xe,
  MATH_ARITHMETIC_TOOLTIP_POWER: Ye,
  MATH_SINGLE_HELPURL: Ke,
  MATH_SINGLE_OP_ROOT: we,
  MATH_SINGLE_TOOLTIP_ROOT: ye,
  MATH_SINGLE_OP_ABSOLUTE: We,
  MATH_SINGLE_OP_ABSOLUTE_ARIA: be,
  MATH_SINGLE_TOOLTIP_ABS: je,
  MATH_SINGLE_OP_NEG_ARIA: Je,
  MATH_SINGLE_OP_LN_ARIA: qe,
  MATH_SINGLE_OP_LOG10_ARIA: ze,
  MATH_SINGLE_OP_EXP_ARIA: Qe,
  MATH_SINGLE_OP_POW10_ARIA: Ze,
  MATH_SINGLE_TOOLTIP_NEG: _t,
  MATH_SINGLE_TOOLTIP_LN: Tt,
  MATH_SINGLE_TOOLTIP_LOG10: Et,
  MATH_SINGLE_TOOLTIP_EXP: et,
  MATH_SINGLE_TOOLTIP_POW10: tt,
  MATH_TRIG_HELPURL: Ot,
  MATH_TRIG_TOOLTIP_SIN: Lt,
  MATH_TRIG_TOOLTIP_COS: It,
  MATH_TRIG_TOOLTIP_TAN: At,
  MATH_TRIG_TOOLTIP_ASIN: Nt,
  MATH_TRIG_TOOLTIP_ACOS: Rt,
  MATH_TRIG_TOOLTIP_ATAN: nt,
  MATH_CONSTANT_HELPURL: rt,
  MATH_CONSTANT_TOOLTIP: it,
  MATH_IS_EVEN: st,
  MATH_IS_ODD: St,
  MATH_IS_PRIME: ot,
  MATH_IS_WHOLE: Mt,
  MATH_IS_POSITIVE: Ct,
  MATH_IS_NEGATIVE: Pt,
  MATH_IS_DIVISIBLE_BY: at,
  MATH_IS_TOOLTIP: lt,
  MATH_CHANGE_HELPURL: ut,
  MATH_CHANGE_TITLE: Ut,
  MATH_CHANGE_TITLE_ITEM: ct,
  MATH_CHANGE_TOOLTIP: Dt,
  MATH_ROUND_HELPURL: dt,
  MATH_ROUND_TOOLTIP: gt,
  MATH_ROUND_OPERATOR_ROUND: Ht,
  MATH_ROUND_OPERATOR_ROUNDUP: Bt,
  MATH_ROUND_OPERATOR_ROUNDDOWN: Ft,
  MATH_ONLIST_HELPURL: mt,
  MATH_ONLIST_OPERATOR_SUM: ht,
  MATH_ONLIST_TOOLTIP_SUM: pt,
  MATH_ONLIST_OPERATOR_MIN: ft,
  MATH_ONLIST_OPERATOR_MIN_ARIA: Gt,
  MATH_ONLIST_TOOLTIP_MIN: vt,
  MATH_ONLIST_OPERATOR_MAX: Xt,
  MATH_ONLIST_OPERATOR_MAX_ARIA: Vt,
  MATH_ONLIST_TOOLTIP_MAX: $t,
  MATH_ONLIST_OPERATOR_AVERAGE: kt,
  MATH_ONLIST_TOOLTIP_AVERAGE: xt,
  MATH_ONLIST_OPERATOR_MEDIAN: Yt,
  MATH_ONLIST_TOOLTIP_MEDIAN: Kt,
  MATH_ONLIST_OPERATOR_MODE: wt,
  MATH_ONLIST_TOOLTIP_MODE: yt,
  MATH_ONLIST_OPERATOR_STD_DEV: Wt,
  MATH_ONLIST_TOOLTIP_STD_DEV: bt,
  MATH_ONLIST_OPERATOR_RANDOM: jt,
  MATH_ONLIST_TOOLTIP_RANDOM: Jt,
  MATH_MODULO_HELPURL: qt,
  MATH_MODULO_TITLE: zt,
  MATH_MODULO_TOOLTIP: Qt,
  MATH_CONSTRAIN_HELPURL: Zt,
  MATH_CONSTRAIN_TITLE: _O,
  MATH_CONSTRAIN_TOOLTIP: TO,
  MATH_RANDOM_INT_HELPURL: EO,
  MATH_RANDOM_INT_TITLE: eO,
  MATH_RANDOM_INT_TOOLTIP: tO,
  MATH_RANDOM_FLOAT_HELPURL: OO,
  MATH_RANDOM_FLOAT_TITLE_RANDOM: LO,
  MATH_RANDOM_FLOAT_TOOLTIP: IO,
  MATH_ATAN2_HELPURL: AO,
  MATH_ATAN2_TITLE: NO,
  MATH_ATAN2_TOOLTIP: RO,
  TEXT_TEXT_HELPURL: nO,
  TEXT_TEXT_TOOLTIP: rO,
  TEXT_JOIN_HELPURL: iO,
  TEXT_JOIN_TITLE_CREATEWITH: sO,
  TEXT_JOIN_TOOLTIP: SO,
  TEXT_CREATE_JOIN_TITLE_JOIN: oO,
  TEXT_CREATE_JOIN_TOOLTIP: MO,
  TEXT_CREATE_JOIN_ITEM_TITLE_ITEM: CO,
  TEXT_CREATE_JOIN_ITEM_TOOLTIP: PO,
  TEXT_APPEND_HELPURL: aO,
  TEXT_APPEND_TITLE: lO,
  TEXT_APPEND_VARIABLE: uO,
  TEXT_APPEND_TOOLTIP: UO,
  TEXT_LENGTH_HELPURL: cO,
  TEXT_LENGTH_TITLE: DO,
  TEXT_LENGTH_TOOLTIP: dO,
  TEXT_ISEMPTY_HELPURL: gO,
  TEXT_ISEMPTY_TITLE: HO,
  TEXT_ISEMPTY_TOOLTIP: BO,
  TEXT_INDEXOF_HELPURL: FO,
  TEXT_INDEXOF_TOOLTIP: mO,
  TEXT_INDEXOF_TITLE: hO,
  TEXT_INDEXOF_OPERATOR_FIRST: pO,
  TEXT_INDEXOF_OPERATOR_LAST: fO,
  TEXT_FROM_START_ARIA: GO,
  TEXT_FROM_END_ARIA: vO,
  TEXT_CHARAT_HELPURL: XO,
  TEXT_CHARAT_TITLE: VO,
  TEXT_CHARAT_FROM_START: $O,
  TEXT_CHARAT_FROM_END: kO,
  TEXT_CHARAT_FIRST: xO,
  TEXT_CHARAT_LAST: YO,
  TEXT_CHARAT_RANDOM: KO,
  TEXT_CHARAT_TAIL: wO,
  TEXT_CHARAT_TOOLTIP: yO,
  TEXT_GET_SUBSTRING_TOOLTIP: WO,
  TEXT_GET_SUBSTRING_HELPURL: bO,
  TEXT_GET_SUBSTRING_INPUT_IN_TEXT: jO,
  TEXT_GET_SUBSTRING_START_FROM_START: JO,
  TEXT_GET_SUBSTRING_START_FROM_END: qO,
  TEXT_GET_SUBSTRING_START_FIRST: zO,
  TEXT_GET_SUBSTRING_END_FROM_START: QO,
  TEXT_GET_SUBSTRING_END_FROM_END: ZO,
  TEXT_GET_SUBSTRING_END_LAST: _L,
  TEXT_GET_SUBSTRING_TAIL: TL,
  TEXT_CHANGECASE_HELPURL: EL,
  TEXT_CHANGECASE_TOOLTIP: eL,
  TEXT_CHANGECASE_OPERATOR_UPPERCASE: tL,
  TEXT_CHANGECASE_OPERATOR_LOWERCASE: OL,
  TEXT_CHANGECASE_OPERATOR_TITLECASE: LL,
  TEXT_TRIM_HELPURL: IL,
  TEXT_TRIM_TOOLTIP: AL,
  TEXT_TRIM_OPERATOR_BOTH: NL,
  TEXT_TRIM_OPERATOR_LEFT: RL,
  TEXT_TRIM_OPERATOR_RIGHT: nL,
  TEXT_PRINT_HELPURL: rL,
  TEXT_PRINT_TITLE: iL,
  TEXT_PRINT_TOOLTIP: sL,
  TEXT_PROMPT_HELPURL: SL,
  TEXT_PROMPT_TYPE_TEXT: oL,
  TEXT_PROMPT_TYPE_NUMBER: ML,
  TEXT_PROMPT_TOOLTIP_NUMBER: CL,
  TEXT_PROMPT_TOOLTIP_TEXT: PL,
  TEXT_COUNT_MESSAGE0: aL,
  TEXT_COUNT_HELPURL: lL,
  TEXT_COUNT_TOOLTIP: uL,
  TEXT_REPLACE_MESSAGE0: UL,
  TEXT_REPLACE_HELPURL: cL,
  TEXT_REPLACE_TOOLTIP: DL,
  TEXT_REVERSE_MESSAGE0: dL,
  TEXT_REVERSE_HELPURL: gL,
  TEXT_REVERSE_TOOLTIP: HL,
  LISTS_CREATE_EMPTY_HELPURL: BL,
  LISTS_CREATE_EMPTY_TITLE: FL,
  LISTS_CREATE_EMPTY_TOOLTIP: mL,
  LISTS_CREATE_WITH_HELPURL: hL,
  LISTS_CREATE_WITH_TOOLTIP: pL,
  LISTS_CREATE_WITH_INPUT_WITH: fL,
  LISTS_CREATE_WITH_CONTAINER_TITLE_ADD: GL,
  LISTS_CREATE_WITH_CONTAINER_TOOLTIP: vL,
  LISTS_CREATE_WITH_ITEM_TITLE: XL,
  LISTS_CREATE_WITH_ITEM_TOOLTIP: VL,
  LISTS_REPEAT_HELPURL: $L,
  LISTS_REPEAT_TOOLTIP: kL,
  LISTS_REPEAT_TITLE: xL,
  LISTS_LENGTH_HELPURL: YL,
  LISTS_LENGTH_TITLE: KL,
  LISTS_LENGTH_TOOLTIP: wL,
  LISTS_ISEMPTY_HELPURL: yL,
  LISTS_ISEMPTY_TITLE: WL,
  LISTS_ISEMPTY_TOOLTIP: bL,
  LISTS_INLIST: jL,
  LISTS_INDEX_OF_HELPURL: JL,
  LISTS_INDEX_OF_INPUT_IN_LIST: qL,
  LISTS_INDEX_OF_FIRST: zL,
  LISTS_INDEX_OF_LAST: QL,
  LISTS_INDEX_OF_TOOLTIP: ZL,
  LISTS_GET_INDEX_HELPURL: _I,
  LISTS_GET_INDEX_GET: TI,
  LISTS_GET_INDEX_GET_REMOVE: EI,
  LISTS_GET_INDEX_REMOVE: eI,
  LISTS_GET_INDEX_FROM_START: tI,
  LISTS_GET_INDEX_FROM_END: OI,
  LISTS_GET_INDEX_FIRST: LI,
  LISTS_GET_INDEX_LAST: II,
  LISTS_GET_INDEX_RANDOM: AI,
  LISTS_GET_INDEX_TAIL: NI,
  LISTS_GET_INDEX_INPUT_IN_LIST: RI,
  LISTS_INDEX_FROM_START_TOOLTIP: nI,
  LISTS_INDEX_FROM_END_TOOLTIP: rI,
  LISTS_GET_INDEX_TOOLTIP_GET_FROM: iI,
  LISTS_GET_INDEX_TOOLTIP_GET_FIRST: sI,
  LISTS_GET_INDEX_TOOLTIP_GET_LAST: SI,
  LISTS_GET_INDEX_TOOLTIP_GET_RANDOM: oI,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_FROM: MI,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_FIRST: CI,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_LAST: PI,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_RANDOM: aI,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_FROM: lI,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_FIRST: uI,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_LAST: UI,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_RANDOM: cI,
  LISTS_SET_INDEX_HELPURL: DI,
  LISTS_SET_INDEX_INPUT_IN_LIST: dI,
  LISTS_SET_INDEX_SET: gI,
  LISTS_SET_INDEX_INSERT: HI,
  LISTS_SET_INDEX_INPUT_TO: BI,
  LISTS_SET_INDEX_TOOLTIP_SET_FROM: FI,
  LISTS_SET_INDEX_TOOLTIP_SET_FIRST: mI,
  LISTS_SET_INDEX_TOOLTIP_SET_LAST: hI,
  LISTS_SET_INDEX_TOOLTIP_SET_RANDOM: pI,
  LISTS_SET_INDEX_TOOLTIP_INSERT_FROM: fI,
  LISTS_SET_INDEX_TOOLTIP_INSERT_FIRST: GI,
  LISTS_SET_INDEX_TOOLTIP_INSERT_LAST: vI,
  LISTS_SET_INDEX_TOOLTIP_INSERT_RANDOM: XI,
  LISTS_GET_SUBLIST_HELPURL: VI,
  LISTS_GET_SUBLIST_INPUT_IN_LIST: $I,
  LISTS_GET_SUBLIST_START_FROM_START: kI,
  LISTS_GET_SUBLIST_START_FROM_END: xI,
  LISTS_GET_SUBLIST_START_FIRST: YI,
  LISTS_GET_SUBLIST_END_FROM_START: KI,
  LISTS_GET_SUBLIST_END_FROM_END: wI,
  LISTS_GET_SUBLIST_END_LAST: yI,
  LISTS_GET_SUBLIST_TAIL: WI,
  LISTS_GET_SUBLIST_TOOLTIP: bI,
  LISTS_SORT_HELPURL: jI,
  LISTS_SORT_TITLE: JI,
  LISTS_SORT_TOOLTIP: qI,
  LISTS_SORT_ORDER_ASCENDING: zI,
  LISTS_SORT_ORDER_DESCENDING: QI,
  LISTS_SORT_TYPE_NUMERIC: ZI,
  LISTS_SORT_TYPE_TEXT: _A,
  LISTS_SORT_TYPE_IGNORECASE: TA,
  LISTS_SPLIT_HELPURL: EA,
  LISTS_SPLIT_LIST_FROM_TEXT: eA,
  LISTS_SPLIT_TEXT_FROM_LIST: tA,
  LISTS_SPLIT_WITH_DELIMITER: OA,
  LISTS_SPLIT_TOOLTIP_SPLIT: LA,
  LISTS_SPLIT_TOOLTIP_JOIN: IA,
  LISTS_REVERSE_HELPURL: AA,
  LISTS_REVERSE_MESSAGE0: NA,
  LISTS_REVERSE_TOOLTIP: RA,
  ORDINAL_NUMBER_SUFFIX: nA,
  VARIABLES_GET_HELPURL: rA,
  VARIABLES_GET_TOOLTIP: iA,
  VARIABLES_GET_CREATE_SET: sA,
  VARIABLES_SET_HELPURL: SA,
  VARIABLES_SET: oA,
  VARIABLES_SET_TOOLTIP: MA,
  VARIABLES_SET_CREATE_GET: CA,
  PROCEDURES_DEFNORETURN_HELPURL: PA,
  PROCEDURES_DEFNORETURN_TITLE: aA,
  PROCEDURES_DEFNORETURN_PROCEDURE: lA,
  PROCEDURES_BEFORE_PARAMS: uA,
  PROCEDURES_CALL_BEFORE_PARAMS: UA,
  PROCEDURES_CALL_DISABLED_DEF_WARNING: cA,
  PROCEDURES_DEFNORETURN_DO: DA,
  PROCEDURES_DEFNORETURN_TOOLTIP: dA,
  PROCEDURES_DEFNORETURN_COMMENT: gA,
  PROCEDURES_DEFRETURN_HELPURL: HA,
  PROCEDURES_DEFRETURN_TITLE: BA,
  PROCEDURES_DEFRETURN_PROCEDURE: FA,
  PROCEDURES_DEFRETURN_DO: mA,
  PROCEDURES_DEFRETURN_COMMENT: hA,
  PROCEDURES_DEFRETURN_RETURN: pA,
  PROCEDURES_DEFRETURN_TOOLTIP: fA,
  PROCEDURES_ALLOW_STATEMENTS: GA,
  PROCEDURES_DEF_DUPLICATE_WARNING: vA,
  PROCEDURES_CALLNORETURN_HELPURL: XA,
  PROCEDURES_CALLNORETURN_TOOLTIP: VA,
  PROCEDURES_CALLRETURN_HELPURL: $A,
  PROCEDURES_CALLRETURN_TOOLTIP: kA,
  PROCEDURES_MUTATORCONTAINER_TITLE: xA,
  PROCEDURES_MUTATORCONTAINER_TOOLTIP: YA,
  PROCEDURES_MUTATORARG_TITLE: KA,
  PROCEDURES_MUTATORARG_TOOLTIP: wA,
  PROCEDURES_HIGHLIGHT_DEF: yA,
  PROCEDURES_CREATE_DO: WA,
  PROCEDURES_IFRETURN_TOOLTIP: bA,
  PROCEDURES_IFRETURN_HELPURL: jA,
  PROCEDURES_IFRETURN_WARNING: JA,
  WORKSPACE_COMMENT_DEFAULT_TEXT: qA,
  COLLAPSED_WARNINGS_WARNING: zA,
  DIALOG_OK: QA,
  DIALOG_CANCEL: ZA,
  EDIT_BLOCK_CONTENTS: _N,
  MOVE_BLOCK: TN,
  WINDOWS: EN,
  MAC_OS: eN,
  CHROME_OS: tN,
  LINUX: ON,
  UNKNOWN: LN,
  CONTROL_KEY: IN,
  COMMAND_KEY: AN,
  OPTION_KEY: NN,
  ALT_KEY: RN,
  ENTER_KEY: nN,
  BACKSPACE_KEY: rN,
  DELETE_KEY: iN,
  ESCAPE: sN,
  TAB_KEY: SN,
  SHIFT_KEY: oN,
  CAPS_LOCK_KEY: MN,
  SPACE_KEY: CN,
  PAGE_UP_KEY: PN,
  PAGE_DOWN_KEY: aN,
  END_KEY: lN,
  HOME_KEY: uN,
  INSERT_KEY: UN,
  PAUSE_KEY: cN,
  CONTEXT_MENU_KEY: DN,
  CUT_SHORTCUT: dN,
  COPY_SHORTCUT: gN,
  PASTE_SHORTCUT: HN,
  HELP_PROMPT: BN,
  SHORTCUTS_GENERAL: FN,
  SHORTCUTS_EDITING: mN,
  SHORTCUTS_CODE_NAVIGATION: hN,
  SHORTCUTS_ESCAPE: pN,
  SHORTCUTS_DELETE: fN,
  SHORTCUTS_START_MOVE: GN,
  SHORTCUTS_START_MOVE_STACK: vN,
  SHORTCUTS_MOVE_LEFT: XN,
  SHORTCUTS_MOVE_RIGHT: VN,
  SHORTCUTS_MOVE_UP: $N,
  SHORTCUTS_MOVE_DOWN: kN,
  SHORTCUTS_FINISH_MOVE: xN,
  SHORTCUTS_ABORT_MOVE: YN,
  SHORTCUTS_SHOW_CONTEXT_MENU: KN,
  SHORTCUTS_FOCUS_WORKSPACE: wN,
  SHORTCUTS_FOCUS_TOOLBOX: yN,
  SHORTCUTS_INFORMATION: WN,
  SHORTCUTS_EXTENDED_INFORMATION: bN,
  SHORTCUTS_DISCONNECT: jN,
  SHORTCUTS_NEXT_STACK: JN,
  SHORTCUTS_PREVIOUS_STACK: qN,
  SHORTCUTS_NEXT_HEADING: zN,
  SHORTCUTS_PREVIOUS_HEADING: QN,
  SHORTCUTS_PERFORM_ACTION: ZN,
  SHORTCUTS_DUPLICATE: _R,
  SHORTCUTS_CLEANUP: TR,
  SHORTCUTS_SHOW_TOOLTIP: ER,
  SHORTCUTS_TOGGLE_SCREENREADER_MODE: eR,
  SHORTCUTS_JUMP_BLOCK_START: tR,
  SHORTCUTS_JUMP_BLOCK_END: OR,
  SHORTCUTS_JUMP_TOP_STACK: LR,
  SHORTCUTS_JUMP_BOTTOM_STACK: IR,
  SHORTCUTS_JUMP_FIRST_BLOCK: AR,
  SHORTCUTS_JUMP_LAST_BLOCK: NR,
  SHORTCUTS_JUMP_PREVIOUS_PAGE: RR,
  SHORTCUTS_JUMP_NEXT_PAGE: nR,
  SHORTCUTS_SCROLL_LEFT: rR,
  SHORTCUTS_SCROLL_RIGHT: iR,
  SHORTCUTS_SCROLL_UP: sR,
  SHORTCUTS_SCROLL_DOWN: SR,
  ANNOUNCE_SCROLLED_LEFT: oR,
  ANNOUNCE_SCROLLED_RIGHT: MR,
  ANNOUNCE_SCROLLED_UP: CR,
  ANNOUNCE_SCROLLED_DOWN: PR,
  ANNOUNCE_CANT_SCROLL_FURTHER: aR,
  KEYBOARD_NAV_UNCONSTRAINED_MOVE_HINT: lR,
  KEYBOARD_NAV_CONSTRAINED_MOVE_HINT: uR,
  KEYBOARD_NAV_COPIED_HINT: UR,
  KEYBOARD_NAV_CUT_HINT: cR,
  WORKSPACE_LABEL_PLAIN: DR,
  WORKSPACE_ROLEDESCRIPTION: dR,
  WORKSPACE_LABEL_1_STACK: gR,
  WORKSPACE_LABEL_MANY_STACKS: HR,
  WORKSPACE_LABEL_MUTATOR_WORKSPACE: BR,
  WORKSPACE_LABEL_FLYOUT_WORKSPACE: FR,
  WORKSPACE_CONTENTS_BLOCKS_MANY: mR,
  WORKSPACE_CONTENTS_BLOCKS_ONE: hR,
  WORKSPACE_CONTENTS_BLOCKS_ZERO: pR,
  WORKSPACE_CONTENTS_COMMENTS_MANY: fR,
  WORKSPACE_CONTENTS_COMMENTS_ONE: GR,
  KEYBOARD_NAV_BLOCK_NAVIGATION_HINT: vR,
  KEYBOARD_NAV_WORKSPACE_NAVIGATION_HINT: XR,
  KEYBOARD_NAV_FLYOUT_LABEL_HINT: VR,
  BLOCK_LABEL_BEGIN_STACK: $R,
  BLOCK_LABEL_BEGIN_PREFIX: kR,
  BLOCK_LABEL_TOOLBOX_CATEGORY: xR,
  BLOCK_LABEL_DISABLED: YR,
  BLOCK_LABEL_COLLAPSED: KR,
  BLOCK_LABEL_REPLACEABLE: wR,
  BLOCK_LABEL_HAS_INPUT: yR,
  BLOCK_LABEL_HAS_INPUTS: WR,
  BLOCK_LABEL_HAS_BRANCHES: bR,
  BLOCK_LABEL_STATEMENT: jR,
  BLOCK_LABEL_CONTAINER: JR,
  BLOCK_LABEL_VALUE: qR,
  BLOCK_LABEL_STACK_BLOCKS: zR,
  INPUT_LABEL_INDEX: QR,
  INPUT_LABEL_VALUE: ZR,
  INPUT_LABEL_STATEMENT: _n,
  INPUT_LABEL_END_STATEMENT: Tn,
  INPUT_LABEL_EMPTY: En,
  INPUT_LABEL_CONDITION: en,
  INPUT_LABEL_CONDITION_A: tn,
  INPUT_LABEL_CONDITION_B: On,
  INPUT_LABEL_VALUE_A: Ln,
  INPUT_LABEL_VALUE_B: In,
  INPUT_LABEL_NUMBER: An,
  INPUT_LABEL_NUMBER_A: Nn,
  INPUT_LABEL_NUMBER_B: Rn,
  INPUT_LABEL_NUMBER_TO_CHECK: nn,
  INPUT_LABEL_NUMBER_LIST: rn,
  INPUT_LABEL_MATH_DIVIDEND: sn,
  INPUT_LABEL_MATH_DIVISOR: Sn,
  INPUT_LABEL_MATH_CHANGE_BY: on,
  INPUT_LABEL_MATH_CONSTRAIN_VALUE: Mn,
  INPUT_LABEL_NUMBER_MIN: Cn,
  INPUT_LABEL_NUMBER_MAX: Pn,
  INPUT_LABEL_NUMBER_ATAN2_X: an,
  INPUT_LABEL_NUMBER_ATAN2_Y: ln,
  INPUT_LABEL_LOOP_TIMES: un,
  INPUT_LABEL_LOOP_FROM: Un,
  INPUT_LABEL_LOOP_TO: cn,
  INPUT_LABEL_LOOP_BY: Dn,
  INPUT_LABEL_LOOP_LIST: dn,
  INPUT_LABEL_TEXT_JOIN_ITEM: gn,
  INPUT_LABEL_TEXT_APPEND: Hn,
  INPUT_LABEL_TEXT_TO_CHANGE: Bn,
  INPUT_LABEL_TEXT_TO_CHECK: Fn,
  INPUT_LABEL_TEXT_TO_FIND: mn,
  INPUT_LABEL_TEXT_TO_REPLACE: hn,
  INPUT_LABEL_TEXT_POSITION: pn,
  INPUT_LABEL_TEXT_START_POSITION: fn,
  INPUT_LABEL_TEXT_END_POSITION: Gn,
  INPUT_LABEL_TEXT_PROMPT_MESSAGE: vn,
  INPUT_LABEL_VARIABLES_SET: Xn,
  INPUT_LABEL_LISTS_CREATE_WITH_ITEM: Vn,
  INPUT_LABEL_LISTS_REPEAT_ITEM: $n,
  INPUT_LABEL_LISTS_REPEAT_NUM: kn,
  INPUT_LABEL_LISTS_TO_CHECK: xn,
  INPUT_LABEL_LISTS_VALUE_TO_SET: Yn,
  INPUT_LABEL_LISTS_POSITION: Kn,
  INPUT_LABEL_LISTS_START_POSITION: wn,
  INPUT_LABEL_LISTS_END_POSITION: yn,
  INPUT_LABEL_LISTS_LIST_FROM_TEXT: Wn,
  INPUT_LABEL_LISTS_TEXT_FROM_LIST: bn,
  INPUT_LABEL_LISTS_DELIMITER: jn,
  INPUT_LABEL_LISTS_TO_CHANGE: Jn,
  ANNOUNCE_MOVE_WORKSPACE: qn,
  ANNOUNCE_MOVE_BEFORE: zn,
  ANNOUNCE_MOVE_AFTER: Qn,
  ANNOUNCE_MOVE_INSIDE: Zn,
  ANNOUNCE_MOVE_AROUND: _r,
  ANNOUNCE_MOVE_TO: Tr,
  ANNOUNCE_MOVE_OF: Er,
  ANNOUNCE_MOVE_CANCELED: er,
  FIELD_LABEL_EMPTY: tr,
  ARIA_TYPE_FIELD_INPUT: Or,
  ARIA_TYPE_FIELD_TEXT_INPUT: Lr,
  ARIA_TYPE_FIELD_NUMBER: Ir,
  ARIA_TYPE_FIELD_TEXT_INPUT_PROCEDURE: Ar,
  ARIA_TYPE_FIELD_TEXT_INPUT_ARGUMENT: Nr,
  ARIA_TYPE_FIELD_DROPDOWN: Rr,
  ARIA_TYPE_FIELD_IMAGE: nr,
  ARIA_TYPE_FIELD_CHECKBOX: rr,
  FIELD_LABEL_EDIT_PREFIX: ir,
  OPEN_TRASH: sr,
  ZOOM_IN: Sr,
  ZOOM_OUT: or,
  RESET_ZOOM: Mr,
  FIELD_LABEL_OPTION_INDEX: Cr,
  FIELD_LABEL_CHECKBOX_CHECKED: Pr,
  FIELD_LABEL_CHECKBOX_UNCHECKED: ar,
  FIELD_LABEL_VARIABLE: lr,
  ARIA_LABEL_BUTTON: ur,
  ARIA_LABEL_HEADING: Ur,
  BUBBLE_LABEL_DEFAULT: cr,
  BUBBLE_LABEL_COMMENT: Dr,
  BUBBLE_LABEL_WARNING: dr,
  ICON_LABEL_DEFAULT: gr,
  ICON_LABEL_COMMENT_CLOSED: Hr,
  ICON_LABEL_COMMENT_OPEN: Br,
  ICON_LABEL_MUTATOR_CLOSED: Fr,
  ICON_LABEL_MUTATOR_OPEN: mr,
  ICON_LABEL_WARNING_CLOSED: hr,
  ICON_LABEL_WARNING_OPEN: pr,
  ARIA_LABEL_COMMENT: fr,
  ARIA_LABEL_COMMENT_COLLAPSE: Gr,
  ARIA_LABEL_COMMENT_EXPAND: vr,
  SCREENREADER_MODE_ENABLED: Xr,
  SCREENREADER_MODE_DISABLED: Vr,
  CURRENT_BLOCK_ANNOUNCEMENT: $r,
  PARENT_BLOCKS_ANNOUNCEMENT: kr,
  NO_PARENT_ANNOUNCEMENT: xr,
  SCREENREADER_HINT: Yr,
  ARIA_LABEL_ADD_ELSE_IF: Kr,
  ARIA_LABEL_REMOVE_ELSE_IF: wr,
  ARIA_LABEL_ADD_LIST_ITEM: yr,
  ARIA_LABEL_REMOVE_LIST_ITEM: Wr,
  ARIA_LABEL_ADD_TEXT: br,
  ARIA_LABEL_REMOVE_TEXT: jr,
  ARIA_LABEL_ADD_INPUT: Jr,
  ARIA_LABEL_REMOVE_INPUT: qr,
  ARIA_TYPE_FIELD_ANGLE: zr,
  ARIA_LABEL_FIELD_ANGLE: Qr,
  ARIA_TYPE_FIELD_DATE: Zr,
  ARIA_TYPE_FIELD_COLOUR: _i,
  ARIA_TYPE_FIELD_BITMAP: Ti,
  ARIA_TYPE_FIELD_GRID: Ei,
  FIELD_BITMAP_BUTTON_LABEL_RANDOMIZE: ei,
  FIELD_BITMAP_BUTTON_LABEL_CLEAR: ti,
  FIELD_BITMAP_PIXEL_ON: Oi,
  FIELD_BITMAP_PIXEL_OFF: Li,
  FIELD_BITMAP_PIXEL_LABEL: Ii,
  FIELD_BITMAP_ARIA_VALUE: Ai,
  OPEN_BACKPACK: Ni,
  CLOSE_BACKPACK: Ri,
  COPY_ALL_TO_BACKPACK: ni,
  COPY_TO_BACKPACK: ri,
  EMPTY_BACKPACK: ii,
  PASTE_ALL_FROM_BACKPACK: si,
  REMOVE_FROM_BACKPACK: Si,
  FIELD_MULTILINEINPUT_FINISH_EDITING: oi,
  FIELD_MULTILINEINPUT_NEW_LINE: Mi,
  ZOOM_TO_FIT_ARIA_LABEL: Ci,
  MINIMAP_ARIA_LABEL: Pi,
  ARIA_LABEL_TRASH_EMPTY: ai,
  WORKSPACE_SEARCH_PLACEHOLDER: li,
  WORKSPACE_SEARCH_INPUT_LABEL: ui,
  WORKSPACE_SEARCH_FIND_NEXT: Ui,
  WORKSPACE_SEARCH_FIND_PREVIOUS: ci,
  WORKSPACE_SEARCH_CLOSE: Di,
  WORKSPACE_SEARCH_NO_MATCHES: di,
  WORKSPACE_SEARCH_MATCH: gi,
  TOOLBOX_SEARCH_PLACEHOLDER: Hi,
  TOOLBOX_SEARCH_PROMPT: Bi,
  TOOLBOX_SEARCH_NO_RESULTS: Fi,
  TOOLBOX_SEARCH_RESULT_COUNT_ONE: mi,
  TOOLBOX_SEARCH_RESULT_COUNT: hi
} = h_, pi = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ADD_COMMENT: W_,
  ALT_KEY: RN,
  ANNOUNCE_CANT_SCROLL_FURTHER: aR,
  ANNOUNCE_MOVE_AFTER: Qn,
  ANNOUNCE_MOVE_AROUND: _r,
  ANNOUNCE_MOVE_BEFORE: zn,
  ANNOUNCE_MOVE_CANCELED: er,
  ANNOUNCE_MOVE_INSIDE: Zn,
  ANNOUNCE_MOVE_OF: Er,
  ANNOUNCE_MOVE_TO: Tr,
  ANNOUNCE_MOVE_WORKSPACE: qn,
  ANNOUNCE_SCROLLED_DOWN: PR,
  ANNOUNCE_SCROLLED_LEFT: oR,
  ANNOUNCE_SCROLLED_RIGHT: MR,
  ANNOUNCE_SCROLLED_UP: CR,
  ARIA_LABEL_ADD_ELSE_IF: Kr,
  ARIA_LABEL_ADD_INPUT: Jr,
  ARIA_LABEL_ADD_LIST_ITEM: yr,
  ARIA_LABEL_ADD_TEXT: br,
  ARIA_LABEL_BUTTON: ur,
  ARIA_LABEL_COMMENT: fr,
  ARIA_LABEL_COMMENT_COLLAPSE: Gr,
  ARIA_LABEL_COMMENT_EXPAND: vr,
  ARIA_LABEL_FIELD_ANGLE: Qr,
  ARIA_LABEL_HEADING: Ur,
  ARIA_LABEL_REMOVE_ELSE_IF: wr,
  ARIA_LABEL_REMOVE_INPUT: qr,
  ARIA_LABEL_REMOVE_LIST_ITEM: Wr,
  ARIA_LABEL_REMOVE_TEXT: jr,
  ARIA_LABEL_TRASH_EMPTY: ai,
  ARIA_TYPE_FIELD_ANGLE: zr,
  ARIA_TYPE_FIELD_BITMAP: Ti,
  ARIA_TYPE_FIELD_CHECKBOX: rr,
  ARIA_TYPE_FIELD_COLOUR: _i,
  ARIA_TYPE_FIELD_DATE: Zr,
  ARIA_TYPE_FIELD_DROPDOWN: Rr,
  ARIA_TYPE_FIELD_GRID: Ei,
  ARIA_TYPE_FIELD_IMAGE: nr,
  ARIA_TYPE_FIELD_INPUT: Or,
  ARIA_TYPE_FIELD_NUMBER: Ir,
  ARIA_TYPE_FIELD_TEXT_INPUT: Lr,
  ARIA_TYPE_FIELD_TEXT_INPUT_ARGUMENT: Nr,
  ARIA_TYPE_FIELD_TEXT_INPUT_PROCEDURE: Ar,
  BACKSPACE_KEY: rN,
  BLOCK_LABEL_BEGIN_PREFIX: kR,
  BLOCK_LABEL_BEGIN_STACK: $R,
  BLOCK_LABEL_COLLAPSED: KR,
  BLOCK_LABEL_CONTAINER: JR,
  BLOCK_LABEL_DISABLED: YR,
  BLOCK_LABEL_HAS_BRANCHES: bR,
  BLOCK_LABEL_HAS_INPUT: yR,
  BLOCK_LABEL_HAS_INPUTS: WR,
  BLOCK_LABEL_REPLACEABLE: wR,
  BLOCK_LABEL_STACK_BLOCKS: zR,
  BLOCK_LABEL_STATEMENT: jR,
  BLOCK_LABEL_TOOLBOX_CATEGORY: xR,
  BLOCK_LABEL_VALUE: qR,
  BUBBLE_LABEL_COMMENT: Dr,
  BUBBLE_LABEL_DEFAULT: cr,
  BUBBLE_LABEL_WARNING: dr,
  CANNOT_DELETE_VARIABLE_PROCEDURE: cT,
  CAPS_LOCK_KEY: MN,
  CHANGE_VALUE_TITLE: nT,
  CHROME_OS: tN,
  CLEAN_UP: _T,
  CLOSE: TT,
  CLOSE_BACKPACK: Ri,
  COLLAPSED_WARNINGS_WARNING: zA,
  COLLAPSE_ALL: eT,
  COLLAPSE_BLOCK: ET,
  COLOUR_BLEND_COLOUR1: $T,
  COLOUR_BLEND_COLOUR2: kT,
  COLOUR_BLEND_HELPURL: XT,
  COLOUR_BLEND_RATIO: xT,
  COLOUR_BLEND_TITLE: VT,
  COLOUR_BLEND_TOOLTIP: YT,
  COLOUR_HUE: V_,
  COLOUR_PICKER_HELPURL: dT,
  COLOUR_PICKER_TOOLTIP: gT,
  COLOUR_RANDOM_HELPURL: HT,
  COLOUR_RANDOM_TITLE: BT,
  COLOUR_RANDOM_TOOLTIP: FT,
  COLOUR_RGB_BLUE: GT,
  COLOUR_RGB_GREEN: fT,
  COLOUR_RGB_HELPURL: mT,
  COLOUR_RGB_RED: pT,
  COLOUR_RGB_TITLE: hT,
  COLOUR_RGB_TOOLTIP: vT,
  COMMAND_KEY: AN,
  CONTEXT_MENU_KEY: DN,
  CONTROLS_FLOW_STATEMENTS_HELPURL: IE,
  CONTROLS_FLOW_STATEMENTS_OPERATOR_BREAK: AE,
  CONTROLS_FLOW_STATEMENTS_OPERATOR_CONTINUE: NE,
  CONTROLS_FLOW_STATEMENTS_TOOLTIP_BREAK: RE,
  CONTROLS_FLOW_STATEMENTS_TOOLTIP_CONTINUE: nE,
  CONTROLS_FLOW_STATEMENTS_WARNING: rE,
  CONTROLS_FOREACH_HELPURL: eE,
  CONTROLS_FOREACH_INPUT_DO: OE,
  CONTROLS_FOREACH_TITLE: tE,
  CONTROLS_FOREACH_TOOLTIP: LE,
  CONTROLS_FOR_HELPURL: ZT,
  CONTROLS_FOR_INPUT_DO: EE,
  CONTROLS_FOR_TITLE: TE,
  CONTROLS_FOR_TOOLTIP: _E,
  CONTROLS_IF_ELSEIF_TITLE_ELSEIF: cE,
  CONTROLS_IF_ELSEIF_TOOLTIP: DE,
  CONTROLS_IF_ELSE_TITLE_ELSE: dE,
  CONTROLS_IF_ELSE_TOOLTIP: gE,
  CONTROLS_IF_HELPURL: iE,
  CONTROLS_IF_IF_TITLE_IF: uE,
  CONTROLS_IF_IF_TOOLTIP: UE,
  CONTROLS_IF_MSG_ELSE: aE,
  CONTROLS_IF_MSG_ELSEIF: PE,
  CONTROLS_IF_MSG_IF: CE,
  CONTROLS_IF_MSG_THEN: lE,
  CONTROLS_IF_TOOLTIP_1: sE,
  CONTROLS_IF_TOOLTIP_2: SE,
  CONTROLS_IF_TOOLTIP_3: oE,
  CONTROLS_IF_TOOLTIP_4: ME,
  CONTROLS_REPEAT_HELPURL: KT,
  CONTROLS_REPEAT_INPUT_DO: yT,
  CONTROLS_REPEAT_TITLE: wT,
  CONTROLS_REPEAT_TOOLTIP: WT,
  CONTROLS_WHILEUNTIL_HELPURL: bT,
  CONTROLS_WHILEUNTIL_INPUT_DO: jT,
  CONTROLS_WHILEUNTIL_OPERATOR_UNTIL: qT,
  CONTROLS_WHILEUNTIL_OPERATOR_WHILE: JT,
  CONTROLS_WHILEUNTIL_TOOLTIP_UNTIL: QT,
  CONTROLS_WHILEUNTIL_TOOLTIP_WHILE: zT,
  CONTROL_KEY: IN,
  COPY_ALL_TO_BACKPACK: ni,
  COPY_SHORTCUT: gN,
  COPY_TO_BACKPACK: ri,
  CURRENT_BLOCK_ANNOUNCEMENT: $r,
  CUT_SHORTCUT: dN,
  DELETE_ALL_BLOCKS: Z_,
  DELETE_BLOCK: z_,
  DELETE_KEY: iN,
  DELETE_VARIABLE: DT,
  DELETE_VARIABLE_CONFIRMATION: UT,
  DELETE_X_BLOCKS: Q_,
  DIALOG_CANCEL: ZA,
  DIALOG_OK: QA,
  DISABLE_BLOCK: LT,
  DUPLICATE_BLOCK: y_,
  DUPLICATE_COMMENT: j_,
  EDIT_BLOCK_CONTENTS: _N,
  EMPTY_BACKPACK: ii,
  ENABLE_BLOCK: IT,
  END_KEY: lN,
  ENTER_KEY: nN,
  ESCAPE: sN,
  EXPAND_ALL: OT,
  EXPAND_BLOCK: tT,
  EXTERNAL_INPUTS: J_,
  FIELD_BITMAP_ARIA_VALUE: Ai,
  FIELD_BITMAP_BUTTON_LABEL_CLEAR: ti,
  FIELD_BITMAP_BUTTON_LABEL_RANDOMIZE: ei,
  FIELD_BITMAP_PIXEL_LABEL: Ii,
  FIELD_BITMAP_PIXEL_OFF: Li,
  FIELD_BITMAP_PIXEL_ON: Oi,
  FIELD_LABEL_CHECKBOX_CHECKED: Pr,
  FIELD_LABEL_CHECKBOX_UNCHECKED: ar,
  FIELD_LABEL_EDIT_PREFIX: ir,
  FIELD_LABEL_EMPTY: tr,
  FIELD_LABEL_OPTION_INDEX: Cr,
  FIELD_LABEL_VARIABLE: lr,
  FIELD_MULTILINEINPUT_FINISH_EDITING: oi,
  FIELD_MULTILINEINPUT_NEW_LINE: Mi,
  HELP: AT,
  HELP_PROMPT: BN,
  HOME_KEY: uN,
  ICON_LABEL_COMMENT_CLOSED: Hr,
  ICON_LABEL_COMMENT_OPEN: Br,
  ICON_LABEL_DEFAULT: gr,
  ICON_LABEL_MUTATOR_CLOSED: Fr,
  ICON_LABEL_MUTATOR_OPEN: mr,
  ICON_LABEL_WARNING_CLOSED: hr,
  ICON_LABEL_WARNING_OPEN: pr,
  INLINE_INPUTS: q_,
  INPUT_LABEL_CONDITION: en,
  INPUT_LABEL_CONDITION_A: tn,
  INPUT_LABEL_CONDITION_B: On,
  INPUT_LABEL_EMPTY: En,
  INPUT_LABEL_END_STATEMENT: Tn,
  INPUT_LABEL_INDEX: QR,
  INPUT_LABEL_LISTS_CREATE_WITH_ITEM: Vn,
  INPUT_LABEL_LISTS_DELIMITER: jn,
  INPUT_LABEL_LISTS_END_POSITION: yn,
  INPUT_LABEL_LISTS_LIST_FROM_TEXT: Wn,
  INPUT_LABEL_LISTS_POSITION: Kn,
  INPUT_LABEL_LISTS_REPEAT_ITEM: $n,
  INPUT_LABEL_LISTS_REPEAT_NUM: kn,
  INPUT_LABEL_LISTS_START_POSITION: wn,
  INPUT_LABEL_LISTS_TEXT_FROM_LIST: bn,
  INPUT_LABEL_LISTS_TO_CHANGE: Jn,
  INPUT_LABEL_LISTS_TO_CHECK: xn,
  INPUT_LABEL_LISTS_VALUE_TO_SET: Yn,
  INPUT_LABEL_LOOP_BY: Dn,
  INPUT_LABEL_LOOP_FROM: Un,
  INPUT_LABEL_LOOP_LIST: dn,
  INPUT_LABEL_LOOP_TIMES: un,
  INPUT_LABEL_LOOP_TO: cn,
  INPUT_LABEL_MATH_CHANGE_BY: on,
  INPUT_LABEL_MATH_CONSTRAIN_VALUE: Mn,
  INPUT_LABEL_MATH_DIVIDEND: sn,
  INPUT_LABEL_MATH_DIVISOR: Sn,
  INPUT_LABEL_NUMBER: An,
  INPUT_LABEL_NUMBER_A: Nn,
  INPUT_LABEL_NUMBER_ATAN2_X: an,
  INPUT_LABEL_NUMBER_ATAN2_Y: ln,
  INPUT_LABEL_NUMBER_B: Rn,
  INPUT_LABEL_NUMBER_LIST: rn,
  INPUT_LABEL_NUMBER_MAX: Pn,
  INPUT_LABEL_NUMBER_MIN: Cn,
  INPUT_LABEL_NUMBER_TO_CHECK: nn,
  INPUT_LABEL_STATEMENT: _n,
  INPUT_LABEL_TEXT_APPEND: Hn,
  INPUT_LABEL_TEXT_END_POSITION: Gn,
  INPUT_LABEL_TEXT_JOIN_ITEM: gn,
  INPUT_LABEL_TEXT_POSITION: pn,
  INPUT_LABEL_TEXT_PROMPT_MESSAGE: vn,
  INPUT_LABEL_TEXT_START_POSITION: fn,
  INPUT_LABEL_TEXT_TO_CHANGE: Bn,
  INPUT_LABEL_TEXT_TO_CHECK: Fn,
  INPUT_LABEL_TEXT_TO_FIND: mn,
  INPUT_LABEL_TEXT_TO_REPLACE: hn,
  INPUT_LABEL_VALUE: ZR,
  INPUT_LABEL_VALUE_A: Ln,
  INPUT_LABEL_VALUE_B: In,
  INPUT_LABEL_VARIABLES_SET: Xn,
  INSERT_KEY: UN,
  KEYBOARD_NAV_BLOCK_NAVIGATION_HINT: vR,
  KEYBOARD_NAV_CONSTRAINED_MOVE_HINT: uR,
  KEYBOARD_NAV_COPIED_HINT: UR,
  KEYBOARD_NAV_CUT_HINT: cR,
  KEYBOARD_NAV_FLYOUT_LABEL_HINT: VR,
  KEYBOARD_NAV_UNCONSTRAINED_MOVE_HINT: lR,
  KEYBOARD_NAV_WORKSPACE_NAVIGATION_HINT: XR,
  LINUX: ON,
  LISTS_CREATE_EMPTY_HELPURL: BL,
  LISTS_CREATE_EMPTY_TITLE: FL,
  LISTS_CREATE_EMPTY_TOOLTIP: mL,
  LISTS_CREATE_WITH_CONTAINER_TITLE_ADD: GL,
  LISTS_CREATE_WITH_CONTAINER_TOOLTIP: vL,
  LISTS_CREATE_WITH_HELPURL: hL,
  LISTS_CREATE_WITH_INPUT_WITH: fL,
  LISTS_CREATE_WITH_ITEM_TITLE: XL,
  LISTS_CREATE_WITH_ITEM_TOOLTIP: VL,
  LISTS_CREATE_WITH_TOOLTIP: pL,
  LISTS_GET_INDEX_FIRST: LI,
  LISTS_GET_INDEX_FROM_END: OI,
  LISTS_GET_INDEX_FROM_START: tI,
  LISTS_GET_INDEX_GET: TI,
  LISTS_GET_INDEX_GET_REMOVE: EI,
  LISTS_GET_INDEX_HELPURL: _I,
  LISTS_GET_INDEX_INPUT_IN_LIST: RI,
  LISTS_GET_INDEX_LAST: II,
  LISTS_GET_INDEX_RANDOM: AI,
  LISTS_GET_INDEX_REMOVE: eI,
  LISTS_GET_INDEX_TAIL: NI,
  LISTS_GET_INDEX_TOOLTIP_GET_FIRST: sI,
  LISTS_GET_INDEX_TOOLTIP_GET_FROM: iI,
  LISTS_GET_INDEX_TOOLTIP_GET_LAST: SI,
  LISTS_GET_INDEX_TOOLTIP_GET_RANDOM: oI,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_FIRST: CI,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_FROM: MI,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_LAST: PI,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_RANDOM: aI,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_FIRST: uI,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_FROM: lI,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_LAST: UI,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_RANDOM: cI,
  LISTS_GET_SUBLIST_END_FROM_END: wI,
  LISTS_GET_SUBLIST_END_FROM_START: KI,
  LISTS_GET_SUBLIST_END_LAST: yI,
  LISTS_GET_SUBLIST_HELPURL: VI,
  LISTS_GET_SUBLIST_INPUT_IN_LIST: $I,
  LISTS_GET_SUBLIST_START_FIRST: YI,
  LISTS_GET_SUBLIST_START_FROM_END: xI,
  LISTS_GET_SUBLIST_START_FROM_START: kI,
  LISTS_GET_SUBLIST_TAIL: WI,
  LISTS_GET_SUBLIST_TOOLTIP: bI,
  LISTS_HUE: X_,
  LISTS_INDEX_FROM_END_TOOLTIP: rI,
  LISTS_INDEX_FROM_START_TOOLTIP: nI,
  LISTS_INDEX_OF_FIRST: zL,
  LISTS_INDEX_OF_HELPURL: JL,
  LISTS_INDEX_OF_INPUT_IN_LIST: qL,
  LISTS_INDEX_OF_LAST: QL,
  LISTS_INDEX_OF_TOOLTIP: ZL,
  LISTS_INLIST: jL,
  LISTS_ISEMPTY_HELPURL: yL,
  LISTS_ISEMPTY_TITLE: WL,
  LISTS_ISEMPTY_TOOLTIP: bL,
  LISTS_LENGTH_HELPURL: YL,
  LISTS_LENGTH_TITLE: KL,
  LISTS_LENGTH_TOOLTIP: wL,
  LISTS_REPEAT_HELPURL: $L,
  LISTS_REPEAT_TITLE: xL,
  LISTS_REPEAT_TOOLTIP: kL,
  LISTS_REVERSE_HELPURL: AA,
  LISTS_REVERSE_MESSAGE0: NA,
  LISTS_REVERSE_TOOLTIP: RA,
  LISTS_SET_INDEX_HELPURL: DI,
  LISTS_SET_INDEX_INPUT_IN_LIST: dI,
  LISTS_SET_INDEX_INPUT_TO: BI,
  LISTS_SET_INDEX_INSERT: HI,
  LISTS_SET_INDEX_SET: gI,
  LISTS_SET_INDEX_TOOLTIP_INSERT_FIRST: GI,
  LISTS_SET_INDEX_TOOLTIP_INSERT_FROM: fI,
  LISTS_SET_INDEX_TOOLTIP_INSERT_LAST: vI,
  LISTS_SET_INDEX_TOOLTIP_INSERT_RANDOM: XI,
  LISTS_SET_INDEX_TOOLTIP_SET_FIRST: mI,
  LISTS_SET_INDEX_TOOLTIP_SET_FROM: FI,
  LISTS_SET_INDEX_TOOLTIP_SET_LAST: hI,
  LISTS_SET_INDEX_TOOLTIP_SET_RANDOM: pI,
  LISTS_SORT_HELPURL: jI,
  LISTS_SORT_ORDER_ASCENDING: zI,
  LISTS_SORT_ORDER_DESCENDING: QI,
  LISTS_SORT_TITLE: JI,
  LISTS_SORT_TOOLTIP: qI,
  LISTS_SORT_TYPE_IGNORECASE: TA,
  LISTS_SORT_TYPE_NUMERIC: ZI,
  LISTS_SORT_TYPE_TEXT: _A,
  LISTS_SPLIT_HELPURL: EA,
  LISTS_SPLIT_LIST_FROM_TEXT: eA,
  LISTS_SPLIT_TEXT_FROM_LIST: tA,
  LISTS_SPLIT_TOOLTIP_JOIN: IA,
  LISTS_SPLIT_TOOLTIP_SPLIT: LA,
  LISTS_SPLIT_WITH_DELIMITER: OA,
  LOGIC_BOOLEAN_FALSE: zE,
  LOGIC_BOOLEAN_HELPURL: JE,
  LOGIC_BOOLEAN_TOOLTIP: QE,
  LOGIC_BOOLEAN_TRUE: qE,
  LOGIC_COMPARE_EQ_ARIA: BE,
  LOGIC_COMPARE_GTE_ARIA: $E,
  LOGIC_COMPARE_GT_ARIA: XE,
  LOGIC_COMPARE_HELPURL: HE,
  LOGIC_COMPARE_LTE_ARIA: GE,
  LOGIC_COMPARE_LT_ARIA: pE,
  LOGIC_COMPARE_NEQ_ARIA: mE,
  LOGIC_COMPARE_TOOLTIP_EQ: FE,
  LOGIC_COMPARE_TOOLTIP_GT: VE,
  LOGIC_COMPARE_TOOLTIP_GTE: kE,
  LOGIC_COMPARE_TOOLTIP_LT: fE,
  LOGIC_COMPARE_TOOLTIP_LTE: vE,
  LOGIC_COMPARE_TOOLTIP_NEQ: hE,
  LOGIC_HUE: p_,
  LOGIC_NEGATE_HELPURL: WE,
  LOGIC_NEGATE_TITLE: bE,
  LOGIC_NEGATE_TOOLTIP: jE,
  LOGIC_NULL: _e,
  LOGIC_NULL_HELPURL: ZE,
  LOGIC_NULL_TOOLTIP: Te,
  LOGIC_OPERATION_AND: KE,
  LOGIC_OPERATION_HELPURL: xE,
  LOGIC_OPERATION_OR: yE,
  LOGIC_OPERATION_TOOLTIP_AND: YE,
  LOGIC_OPERATION_TOOLTIP_OR: wE,
  LOGIC_TERNARY_CONDITION: ee,
  LOGIC_TERNARY_HELPURL: Ee,
  LOGIC_TERNARY_IF_FALSE: Oe,
  LOGIC_TERNARY_IF_TRUE: te,
  LOGIC_TERNARY_TOOLTIP: Le,
  LOOPS_HUE: f_,
  MAC_OS: eN,
  MATH_ADDITION_SYMBOL: Ne,
  MATH_ADDITION_SYMBOL_ARIA: Re,
  MATH_ARITHMETIC_HELPURL: Xe,
  MATH_ARITHMETIC_TOOLTIP_ADD: Ve,
  MATH_ARITHMETIC_TOOLTIP_DIVIDE: xe,
  MATH_ARITHMETIC_TOOLTIP_MINUS: $e,
  MATH_ARITHMETIC_TOOLTIP_MULTIPLY: ke,
  MATH_ARITHMETIC_TOOLTIP_POWER: Ye,
  MATH_ATAN2_HELPURL: AO,
  MATH_ATAN2_TITLE: NO,
  MATH_ATAN2_TOOLTIP: RO,
  MATH_CHANGE_HELPURL: ut,
  MATH_CHANGE_TITLE: Ut,
  MATH_CHANGE_TITLE_ITEM: ct,
  MATH_CHANGE_TOOLTIP: Dt,
  MATH_CONSTANT_E_ARIA: he,
  MATH_CONSTANT_GOLDEN_RATIO_ARIA: pe,
  MATH_CONSTANT_HELPURL: rt,
  MATH_CONSTANT_INFINITY_ARIA: ve,
  MATH_CONSTANT_PI_ARIA: me,
  MATH_CONSTANT_SQRT1_2_ARIA: Ge,
  MATH_CONSTANT_SQRT2_ARIA: fe,
  MATH_CONSTANT_TOOLTIP: it,
  MATH_CONSTRAIN_HELPURL: Zt,
  MATH_CONSTRAIN_TITLE: _O,
  MATH_CONSTRAIN_TOOLTIP: TO,
  MATH_DIVISION_SYMBOL: ie,
  MATH_DIVISION_SYMBOL_ARIA: se,
  MATH_HUE: G_,
  MATH_IS_DIVISIBLE_BY: at,
  MATH_IS_EVEN: st,
  MATH_IS_NEGATIVE: Pt,
  MATH_IS_ODD: St,
  MATH_IS_POSITIVE: Ct,
  MATH_IS_PRIME: ot,
  MATH_IS_TOOLTIP: lt,
  MATH_IS_WHOLE: Mt,
  MATH_MODULO_HELPURL: qt,
  MATH_MODULO_TITLE: zt,
  MATH_MODULO_TOOLTIP: Qt,
  MATH_MULTIPLICATION_SYMBOL: Se,
  MATH_MULTIPLICATION_SYMBOL_ARIA: oe,
  MATH_NUMBER_HELPURL: Ie,
  MATH_NUMBER_TOOLTIP: Ae,
  MATH_ONLIST_HELPURL: mt,
  MATH_ONLIST_OPERATOR_AVERAGE: kt,
  MATH_ONLIST_OPERATOR_MAX: Xt,
  MATH_ONLIST_OPERATOR_MAX_ARIA: Vt,
  MATH_ONLIST_OPERATOR_MEDIAN: Yt,
  MATH_ONLIST_OPERATOR_MIN: ft,
  MATH_ONLIST_OPERATOR_MIN_ARIA: Gt,
  MATH_ONLIST_OPERATOR_MODE: wt,
  MATH_ONLIST_OPERATOR_RANDOM: jt,
  MATH_ONLIST_OPERATOR_STD_DEV: Wt,
  MATH_ONLIST_OPERATOR_SUM: ht,
  MATH_ONLIST_TOOLTIP_AVERAGE: xt,
  MATH_ONLIST_TOOLTIP_MAX: $t,
  MATH_ONLIST_TOOLTIP_MEDIAN: Kt,
  MATH_ONLIST_TOOLTIP_MIN: vt,
  MATH_ONLIST_TOOLTIP_MODE: yt,
  MATH_ONLIST_TOOLTIP_RANDOM: Jt,
  MATH_ONLIST_TOOLTIP_STD_DEV: bt,
  MATH_ONLIST_TOOLTIP_SUM: pt,
  MATH_POWER_SYMBOL: Me,
  MATH_POWER_SYMBOL_ARIA: Ce,
  MATH_RANDOM_FLOAT_HELPURL: OO,
  MATH_RANDOM_FLOAT_TITLE_RANDOM: LO,
  MATH_RANDOM_FLOAT_TOOLTIP: IO,
  MATH_RANDOM_INT_HELPURL: EO,
  MATH_RANDOM_INT_TITLE: eO,
  MATH_RANDOM_INT_TOOLTIP: tO,
  MATH_ROUND_HELPURL: dt,
  MATH_ROUND_OPERATOR_ROUND: Ht,
  MATH_ROUND_OPERATOR_ROUNDDOWN: Ft,
  MATH_ROUND_OPERATOR_ROUNDUP: Bt,
  MATH_ROUND_TOOLTIP: gt,
  MATH_SINGLE_HELPURL: Ke,
  MATH_SINGLE_OP_ABSOLUTE: We,
  MATH_SINGLE_OP_ABSOLUTE_ARIA: be,
  MATH_SINGLE_OP_EXP_ARIA: Qe,
  MATH_SINGLE_OP_LN_ARIA: qe,
  MATH_SINGLE_OP_LOG10_ARIA: ze,
  MATH_SINGLE_OP_NEG_ARIA: Je,
  MATH_SINGLE_OP_POW10_ARIA: Ze,
  MATH_SINGLE_OP_ROOT: we,
  MATH_SINGLE_TOOLTIP_ABS: je,
  MATH_SINGLE_TOOLTIP_EXP: et,
  MATH_SINGLE_TOOLTIP_LN: Tt,
  MATH_SINGLE_TOOLTIP_LOG10: Et,
  MATH_SINGLE_TOOLTIP_NEG: _t,
  MATH_SINGLE_TOOLTIP_POW10: tt,
  MATH_SINGLE_TOOLTIP_ROOT: ye,
  MATH_SUBTRACTION_SYMBOL: ne,
  MATH_SUBTRACTION_SYMBOL_ARIA: re,
  MATH_TRIG_ACOS: ge,
  MATH_TRIG_ACOS_ARIA: He,
  MATH_TRIG_ASIN: De,
  MATH_TRIG_ASIN_ARIA: de,
  MATH_TRIG_ATAN: Be,
  MATH_TRIG_ATAN_ARIA: Fe,
  MATH_TRIG_COS: le,
  MATH_TRIG_COS_ARIA: ue,
  MATH_TRIG_HELPURL: Ot,
  MATH_TRIG_SIN: Pe,
  MATH_TRIG_SIN_ARIA: ae,
  MATH_TRIG_TAN: Ue,
  MATH_TRIG_TAN_ARIA: ce,
  MATH_TRIG_TOOLTIP_ACOS: Rt,
  MATH_TRIG_TOOLTIP_ASIN: Nt,
  MATH_TRIG_TOOLTIP_ATAN: nt,
  MATH_TRIG_TOOLTIP_COS: It,
  MATH_TRIG_TOOLTIP_SIN: Lt,
  MATH_TRIG_TOOLTIP_TAN: At,
  MINIMAP_ARIA_LABEL: Pi,
  MOVE_BLOCK: TN,
  NEW_COLOUR_VARIABLE: MT,
  NEW_NUMBER_VARIABLE: oT,
  NEW_STRING_VARIABLE: ST,
  NEW_VARIABLE: sT,
  NEW_VARIABLE_TITLE: PT,
  NEW_VARIABLE_TYPE_TITLE: CT,
  NO_PARENT_ANNOUNCEMENT: xr,
  OPEN_BACKPACK: Ni,
  OPEN_TRASH: sr,
  OPTION_KEY: NN,
  ORDINAL_NUMBER_SUFFIX: nA,
  PAGE_DOWN_KEY: aN,
  PAGE_UP_KEY: PN,
  PARENT_BLOCKS_ANNOUNCEMENT: kr,
  PASTE_ALL_FROM_BACKPACK: si,
  PASTE_SHORTCUT: HN,
  PAUSE_KEY: cN,
  PROCEDURES_ALLOW_STATEMENTS: GA,
  PROCEDURES_BEFORE_PARAMS: uA,
  PROCEDURES_CALLNORETURN_HELPURL: XA,
  PROCEDURES_CALLNORETURN_TOOLTIP: VA,
  PROCEDURES_CALLRETURN_HELPURL: $A,
  PROCEDURES_CALLRETURN_TOOLTIP: kA,
  PROCEDURES_CALL_BEFORE_PARAMS: UA,
  PROCEDURES_CALL_DISABLED_DEF_WARNING: cA,
  PROCEDURES_CREATE_DO: WA,
  PROCEDURES_DEFNORETURN_COMMENT: gA,
  PROCEDURES_DEFNORETURN_DO: DA,
  PROCEDURES_DEFNORETURN_HELPURL: PA,
  PROCEDURES_DEFNORETURN_PROCEDURE: lA,
  PROCEDURES_DEFNORETURN_TITLE: aA,
  PROCEDURES_DEFNORETURN_TOOLTIP: dA,
  PROCEDURES_DEFRETURN_COMMENT: hA,
  PROCEDURES_DEFRETURN_DO: mA,
  PROCEDURES_DEFRETURN_HELPURL: HA,
  PROCEDURES_DEFRETURN_PROCEDURE: FA,
  PROCEDURES_DEFRETURN_RETURN: pA,
  PROCEDURES_DEFRETURN_TITLE: BA,
  PROCEDURES_DEFRETURN_TOOLTIP: fA,
  PROCEDURES_DEF_DUPLICATE_WARNING: vA,
  PROCEDURES_HIGHLIGHT_DEF: yA,
  PROCEDURES_HUE: x_,
  PROCEDURES_IFRETURN_HELPURL: jA,
  PROCEDURES_IFRETURN_TOOLTIP: bA,
  PROCEDURES_IFRETURN_WARNING: JA,
  PROCEDURES_MUTATORARG_TITLE: KA,
  PROCEDURES_MUTATORARG_TOOLTIP: wA,
  PROCEDURES_MUTATORCONTAINER_TITLE: xA,
  PROCEDURES_MUTATORCONTAINER_TOOLTIP: YA,
  REDO: RT,
  REMOVE_COMMENT: b_,
  REMOVE_FROM_BACKPACK: Si,
  RENAME_VARIABLE: rT,
  RENAME_VARIABLE_TITLE: iT,
  RESET_ZOOM: Mr,
  SCREENREADER_HINT: Yr,
  SCREENREADER_MODE_DISABLED: Vr,
  SCREENREADER_MODE_ENABLED: Xr,
  SHIFT_KEY: oN,
  SHORTCUTS_ABORT_MOVE: YN,
  SHORTCUTS_CLEANUP: TR,
  SHORTCUTS_CODE_NAVIGATION: hN,
  SHORTCUTS_DELETE: fN,
  SHORTCUTS_DISCONNECT: jN,
  SHORTCUTS_DUPLICATE: _R,
  SHORTCUTS_EDITING: mN,
  SHORTCUTS_ESCAPE: pN,
  SHORTCUTS_EXTENDED_INFORMATION: bN,
  SHORTCUTS_FINISH_MOVE: xN,
  SHORTCUTS_FOCUS_TOOLBOX: yN,
  SHORTCUTS_FOCUS_WORKSPACE: wN,
  SHORTCUTS_GENERAL: FN,
  SHORTCUTS_INFORMATION: WN,
  SHORTCUTS_JUMP_BLOCK_END: OR,
  SHORTCUTS_JUMP_BLOCK_START: tR,
  SHORTCUTS_JUMP_BOTTOM_STACK: IR,
  SHORTCUTS_JUMP_FIRST_BLOCK: AR,
  SHORTCUTS_JUMP_LAST_BLOCK: NR,
  SHORTCUTS_JUMP_NEXT_PAGE: nR,
  SHORTCUTS_JUMP_PREVIOUS_PAGE: RR,
  SHORTCUTS_JUMP_TOP_STACK: LR,
  SHORTCUTS_MOVE_DOWN: kN,
  SHORTCUTS_MOVE_LEFT: XN,
  SHORTCUTS_MOVE_RIGHT: VN,
  SHORTCUTS_MOVE_UP: $N,
  SHORTCUTS_NEXT_HEADING: zN,
  SHORTCUTS_NEXT_STACK: JN,
  SHORTCUTS_PERFORM_ACTION: ZN,
  SHORTCUTS_PREVIOUS_HEADING: QN,
  SHORTCUTS_PREVIOUS_STACK: qN,
  SHORTCUTS_SCROLL_DOWN: SR,
  SHORTCUTS_SCROLL_LEFT: rR,
  SHORTCUTS_SCROLL_RIGHT: iR,
  SHORTCUTS_SCROLL_UP: sR,
  SHORTCUTS_SHOW_CONTEXT_MENU: KN,
  SHORTCUTS_SHOW_TOOLTIP: ER,
  SHORTCUTS_START_MOVE: GN,
  SHORTCUTS_START_MOVE_STACK: vN,
  SHORTCUTS_TOGGLE_SCREENREADER_MODE: eR,
  SPACE_KEY: CN,
  TAB_KEY: SN,
  TEXTS_HUE: v_,
  TEXT_APPEND_HELPURL: aO,
  TEXT_APPEND_TITLE: lO,
  TEXT_APPEND_TOOLTIP: UO,
  TEXT_APPEND_VARIABLE: uO,
  TEXT_CHANGECASE_HELPURL: EL,
  TEXT_CHANGECASE_OPERATOR_LOWERCASE: OL,
  TEXT_CHANGECASE_OPERATOR_TITLECASE: LL,
  TEXT_CHANGECASE_OPERATOR_UPPERCASE: tL,
  TEXT_CHANGECASE_TOOLTIP: eL,
  TEXT_CHARAT_FIRST: xO,
  TEXT_CHARAT_FROM_END: kO,
  TEXT_CHARAT_FROM_START: $O,
  TEXT_CHARAT_HELPURL: XO,
  TEXT_CHARAT_LAST: YO,
  TEXT_CHARAT_RANDOM: KO,
  TEXT_CHARAT_TAIL: wO,
  TEXT_CHARAT_TITLE: VO,
  TEXT_CHARAT_TOOLTIP: yO,
  TEXT_COUNT_HELPURL: lL,
  TEXT_COUNT_MESSAGE0: aL,
  TEXT_COUNT_TOOLTIP: uL,
  TEXT_CREATE_JOIN_ITEM_TITLE_ITEM: CO,
  TEXT_CREATE_JOIN_ITEM_TOOLTIP: PO,
  TEXT_CREATE_JOIN_TITLE_JOIN: oO,
  TEXT_CREATE_JOIN_TOOLTIP: MO,
  TEXT_FROM_END_ARIA: vO,
  TEXT_FROM_START_ARIA: GO,
  TEXT_GET_SUBSTRING_END_FROM_END: ZO,
  TEXT_GET_SUBSTRING_END_FROM_START: QO,
  TEXT_GET_SUBSTRING_END_LAST: _L,
  TEXT_GET_SUBSTRING_HELPURL: bO,
  TEXT_GET_SUBSTRING_INPUT_IN_TEXT: jO,
  TEXT_GET_SUBSTRING_START_FIRST: zO,
  TEXT_GET_SUBSTRING_START_FROM_END: qO,
  TEXT_GET_SUBSTRING_START_FROM_START: JO,
  TEXT_GET_SUBSTRING_TAIL: TL,
  TEXT_GET_SUBSTRING_TOOLTIP: WO,
  TEXT_INDEXOF_HELPURL: FO,
  TEXT_INDEXOF_OPERATOR_FIRST: pO,
  TEXT_INDEXOF_OPERATOR_LAST: fO,
  TEXT_INDEXOF_TITLE: hO,
  TEXT_INDEXOF_TOOLTIP: mO,
  TEXT_ISEMPTY_HELPURL: gO,
  TEXT_ISEMPTY_TITLE: HO,
  TEXT_ISEMPTY_TOOLTIP: BO,
  TEXT_JOIN_HELPURL: iO,
  TEXT_JOIN_TITLE_CREATEWITH: sO,
  TEXT_JOIN_TOOLTIP: SO,
  TEXT_LENGTH_HELPURL: cO,
  TEXT_LENGTH_TITLE: DO,
  TEXT_LENGTH_TOOLTIP: dO,
  TEXT_PRINT_HELPURL: rL,
  TEXT_PRINT_TITLE: iL,
  TEXT_PRINT_TOOLTIP: sL,
  TEXT_PROMPT_HELPURL: SL,
  TEXT_PROMPT_TOOLTIP_NUMBER: CL,
  TEXT_PROMPT_TOOLTIP_TEXT: PL,
  TEXT_PROMPT_TYPE_NUMBER: ML,
  TEXT_PROMPT_TYPE_TEXT: oL,
  TEXT_REPLACE_HELPURL: cL,
  TEXT_REPLACE_MESSAGE0: UL,
  TEXT_REPLACE_TOOLTIP: DL,
  TEXT_REVERSE_HELPURL: gL,
  TEXT_REVERSE_MESSAGE0: dL,
  TEXT_REVERSE_TOOLTIP: HL,
  TEXT_TEXT_HELPURL: nO,
  TEXT_TEXT_TOOLTIP: rO,
  TEXT_TRIM_HELPURL: IL,
  TEXT_TRIM_OPERATOR_BOTH: NL,
  TEXT_TRIM_OPERATOR_LEFT: RL,
  TEXT_TRIM_OPERATOR_RIGHT: nL,
  TEXT_TRIM_TOOLTIP: AL,
  TODAY: w_,
  TOOLBOX_SEARCH_NO_RESULTS: Fi,
  TOOLBOX_SEARCH_PLACEHOLDER: Hi,
  TOOLBOX_SEARCH_PROMPT: Bi,
  TOOLBOX_SEARCH_RESULT_COUNT: hi,
  TOOLBOX_SEARCH_RESULT_COUNT_ONE: mi,
  UNDO: NT,
  UNKNOWN: LN,
  UNNAMED_KEY: K_,
  VARIABLES_DEFAULT_NAME: Y_,
  VARIABLES_DYNAMIC_HUE: k_,
  VARIABLES_GET_CREATE_SET: sA,
  VARIABLES_GET_HELPURL: rA,
  VARIABLES_GET_TOOLTIP: iA,
  VARIABLES_HUE: $_,
  VARIABLES_SET: oA,
  VARIABLES_SET_CREATE_GET: CA,
  VARIABLES_SET_HELPURL: SA,
  VARIABLES_SET_TOOLTIP: MA,
  VARIABLE_ALREADY_EXISTS: aT,
  VARIABLE_ALREADY_EXISTS_FOR_ANOTHER_TYPE: lT,
  VARIABLE_ALREADY_EXISTS_FOR_A_PARAMETER: uT,
  WINDOWS: EN,
  WORKSPACE_COMMENT_DEFAULT_TEXT: qA,
  WORKSPACE_CONTENTS_BLOCKS_MANY: mR,
  WORKSPACE_CONTENTS_BLOCKS_ONE: hR,
  WORKSPACE_CONTENTS_BLOCKS_ZERO: pR,
  WORKSPACE_CONTENTS_COMMENTS_MANY: fR,
  WORKSPACE_CONTENTS_COMMENTS_ONE: GR,
  WORKSPACE_LABEL_1_STACK: gR,
  WORKSPACE_LABEL_FLYOUT_WORKSPACE: FR,
  WORKSPACE_LABEL_MANY_STACKS: HR,
  WORKSPACE_LABEL_MUTATOR_WORKSPACE: BR,
  WORKSPACE_LABEL_PLAIN: DR,
  WORKSPACE_ROLEDESCRIPTION: dR,
  WORKSPACE_SEARCH_CLOSE: Di,
  WORKSPACE_SEARCH_FIND_NEXT: Ui,
  WORKSPACE_SEARCH_FIND_PREVIOUS: ci,
  WORKSPACE_SEARCH_INPUT_LABEL: ui,
  WORKSPACE_SEARCH_MATCH: gi,
  WORKSPACE_SEARCH_NO_MATCHES: di,
  WORKSPACE_SEARCH_PLACEHOLDER: li,
  ZOOM_IN: Sr,
  ZOOM_OUT: or,
  ZOOM_TO_FIT_ARIA_LABEL: Ci
}, Symbol.toStringTag, { value: "Module" }));
var b = { exports: {} }, fi = b.exports, t_;
function Gi() {
  return t_ || (t_ = 1, (function(g, C) {
    (function(_, s) {
      g.exports = s();
    })(fi, function() {
      var _ = _ || { Msg: /* @__PURE__ */ Object.create(null) };
      return _.Msg.ADD_COMMENT = "Добавить комментарий", _.Msg.ALT_KEY = "Alt", _.Msg.ANNOUNCE_CANT_SCROLL_FURTHER = "Can't scroll further.", _.Msg.ANNOUNCE_MOVE_AFTER = "Moving %1 after %2.", _.Msg.ANNOUNCE_MOVE_AROUND = "Moving %1 around %2.", _.Msg.ANNOUNCE_MOVE_BEFORE = "Moving %1 before %2.", _.Msg.ANNOUNCE_MOVE_CANCELED = "Canceled movement.", _.Msg.ANNOUNCE_MOVE_INSIDE = "Moving %1 inside %2.", _.Msg.ANNOUNCE_MOVE_OF = "%1 of %2", _.Msg.ANNOUNCE_MOVE_TO = "Moving %1 to %2.", _.Msg.ANNOUNCE_MOVE_WORKSPACE = "Moving %1 on workspace.", _.Msg.ANNOUNCE_SCROLLED_DOWN = "Scrolled down.", _.Msg.ANNOUNCE_SCROLLED_LEFT = "Scrolled left.", _.Msg.ANNOUNCE_SCROLLED_RIGHT = "Scrolled right.", _.Msg.ANNOUNCE_SCROLLED_UP = "Scrolled up.", _.Msg.ARIA_LABEL_ADD_ELSE_IF = "Add else if", _.Msg.ARIA_LABEL_ADD_INPUT = "Add input", _.Msg.ARIA_LABEL_ADD_LIST_ITEM = "Add list item", _.Msg.ARIA_LABEL_ADD_TEXT = "Add text", _.Msg.ARIA_LABEL_BUTTON = "button", _.Msg.ARIA_LABEL_COMMENT = "Comment", _.Msg.ARIA_LABEL_COMMENT_COLLAPSE = "Collapse Comment", _.Msg.ARIA_LABEL_COMMENT_EXPAND = "Expand Comment", _.Msg.ARIA_LABEL_FIELD_ANGLE = "%1 degrees", _.Msg.ARIA_LABEL_HEADING = "heading", _.Msg.ARIA_LABEL_REMOVE_ELSE_IF = "Remove else if", _.Msg.ARIA_LABEL_REMOVE_INPUT = "Remove input", _.Msg.ARIA_LABEL_REMOVE_LIST_ITEM = "Remove list item", _.Msg.ARIA_LABEL_REMOVE_TEXT = "Remove text", _.Msg.ARIA_LABEL_TRASH_EMPTY = "Trash, currently empty", _.Msg.ARIA_TYPE_FIELD_ANGLE = "angle", _.Msg.ARIA_TYPE_FIELD_BITMAP = "pixel image", _.Msg.ARIA_TYPE_FIELD_CHECKBOX = "checkbox", _.Msg.ARIA_TYPE_FIELD_COLOUR = "color", _.Msg.ARIA_TYPE_FIELD_DATE = "date", _.Msg.ARIA_TYPE_FIELD_DROPDOWN = "dropdown", _.Msg.ARIA_TYPE_FIELD_GRID = "grid dropdown", _.Msg.ARIA_TYPE_FIELD_IMAGE = "image", _.Msg.ARIA_TYPE_FIELD_INPUT = "input", _.Msg.ARIA_TYPE_FIELD_NUMBER = "number", _.Msg.ARIA_TYPE_FIELD_TEXT_INPUT = "text", _.Msg.ARIA_TYPE_FIELD_TEXT_INPUT_ARGUMENT = "input name", _.Msg.ARIA_TYPE_FIELD_TEXT_INPUT_PROCEDURE = "function name", _.Msg.BACKSPACE_KEY = "Backspace", _.Msg.BLOCK_LABEL_BEGIN_PREFIX = "Begin %1", _.Msg.BLOCK_LABEL_BEGIN_STACK = "Begin stack", _.Msg.BLOCK_LABEL_COLLAPSED = "collapsed", _.Msg.BLOCK_LABEL_CONTAINER = "container", _.Msg.BLOCK_LABEL_DISABLED = "disabled", _.Msg.BLOCK_LABEL_HAS_BRANCHES = "has %1 branches", _.Msg.BLOCK_LABEL_HAS_INPUT = "has input", _.Msg.BLOCK_LABEL_HAS_INPUTS = "has inputs", _.Msg.BLOCK_LABEL_REPLACEABLE = "replaceable", _.Msg.BLOCK_LABEL_STACK_BLOCKS = "%1 stack blocks", _.Msg.BLOCK_LABEL_STATEMENT = "statement", _.Msg.BLOCK_LABEL_TOOLBOX_CATEGORY = "%1 category", _.Msg.BLOCK_LABEL_VALUE = "value", _.Msg.BUBBLE_LABEL_COMMENT = "Comment: %1", _.Msg.BUBBLE_LABEL_DEFAULT = "Bubble", _.Msg.BUBBLE_LABEL_WARNING = "Warning: %1", _.Msg.CANNOT_DELETE_VARIABLE_PROCEDURE = "Невозможно удалить переменную '%1', поскольку она является частью определения функции '%2'", _.Msg.CAPS_LOCK_KEY = "Caps Lock", _.Msg.CHANGE_VALUE_TITLE = "Измените значение:", _.Msg.CHROME_OS = "ChromeOS", _.Msg.CLEAN_UP = "Упорядочить блоки", _.Msg.CLOSE = "Закрыть", _.Msg.CLOSE_BACKPACK = "Close backpack", _.Msg.COLLAPSED_WARNINGS_WARNING = "Свёрнутые блоки содержат предупреждения.", _.Msg.COLLAPSE_ALL = "Свернуть блоки", _.Msg.COLLAPSE_BLOCK = "Свернуть блок", _.Msg.COLOUR_BLEND_COLOUR1 = "цвет 1", _.Msg.COLOUR_BLEND_COLOUR2 = "цвет 2", _.Msg.COLOUR_BLEND_HELPURL = "https://meyerweb.com/eric/tools/color-blend/#:::rgbp", _.Msg.COLOUR_BLEND_RATIO = "доля цвета 1", _.Msg.COLOUR_BLEND_TITLE = "смешать", _.Msg.COLOUR_BLEND_TOOLTIP = "Смешивает два цвета в заданном соотношении (0.0 - 1.0).", _.Msg.COLOUR_PICKER_HELPURL = "https://ru.wikipedia.org/wiki/Цвет", _.Msg.COLOUR_PICKER_TOOLTIP = "Выберите цвет из палитры.", _.Msg.COLOUR_RANDOM_HELPURL = "http://randomcolour.com", _.Msg.COLOUR_RANDOM_TITLE = "случайный цвет", _.Msg.COLOUR_RANDOM_TOOLTIP = "Выбирает цвет случайным образом.", _.Msg.COLOUR_RGB_BLUE = "синего", _.Msg.COLOUR_RGB_GREEN = "зелёного", _.Msg.COLOUR_RGB_HELPURL = "https://www.december.com/html/spec/colorpercompact.html", _.Msg.COLOUR_RGB_RED = "красного", _.Msg.COLOUR_RGB_TITLE = "цвет из", _.Msg.COLOUR_RGB_TOOLTIP = "Создаёт цвет с указанной пропорцией красного, зелёного и синего. Все значения должны быть между 0 и 100.", _.Msg.COMMAND_KEY = "Command", _.Msg.CONTEXT_MENU_KEY = "≣ Menu", _.Msg.CONTROLS_FLOW_STATEMENTS_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Loops#loop-termination-blocks", _.Msg.CONTROLS_FLOW_STATEMENTS_OPERATOR_BREAK = "выйти из цикла", _.Msg.CONTROLS_FLOW_STATEMENTS_OPERATOR_CONTINUE = "перейти к следующему шагу цикла", _.Msg.CONTROLS_FLOW_STATEMENTS_TOOLTIP_BREAK = "Прерывает этот цикл.", _.Msg.CONTROLS_FLOW_STATEMENTS_TOOLTIP_CONTINUE = "Пропускает остаток цикла и переходит к следующему шагу.", _.Msg.CONTROLS_FLOW_STATEMENTS_WARNING = "Предупреждение: этот блок может использоваться только внутри цикла.", _.Msg.CONTROLS_FOREACH_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Loops#for-each", _.Msg.CONTROLS_FOREACH_TITLE = "для каждого элемента %1 в списке %2", _.Msg.CONTROLS_FOREACH_TOOLTIP = "Для каждого элемента в списке, присваивает переменной '%1' значение элемента и выполняет указанные команды.", _.Msg.CONTROLS_FOR_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Loops#count-with", _.Msg.CONTROLS_FOR_TITLE = "цикл по %1 от %2 до %3 с шагом %4", _.Msg.CONTROLS_FOR_TOOLTIP = "Присваивает переменной '%1' значения от начального до конечного с заданным шагом и выполняет указанные команды.", _.Msg.CONTROLS_IF_ELSEIF_TOOLTIP = 'Добавляет условие к блоку "если"', _.Msg.CONTROLS_IF_ELSE_TOOLTIP = "Добавить заключительный подблок для случая, когда все условия ложны.", _.Msg.CONTROLS_IF_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/IfElse", _.Msg.CONTROLS_IF_IF_TOOLTIP = 'Добавьте, удалите, переставьте фрагменты для переделки блока "если".', _.Msg.CONTROLS_IF_MSG_ELSE = "иначе", _.Msg.CONTROLS_IF_MSG_ELSEIF = "иначе если", _.Msg.CONTROLS_IF_MSG_IF = "если", _.Msg.CONTROLS_IF_TOOLTIP_1 = "Если условие истинно, выполняет команды.", _.Msg.CONTROLS_IF_TOOLTIP_2 = "Если условие истинно, выполняет первый блок команд. Иначе выполняется второй блок команд.", _.Msg.CONTROLS_IF_TOOLTIP_3 = "Если первое условие истинно, то выполняет первый блок команд. Иначе, если второе условие истинно, выполняет второй блок команд.", _.Msg.CONTROLS_IF_TOOLTIP_4 = "Если первое условие истинно, то выполняет первый блок команд.  В противном случае, если второе условие истинно, выполняет второй блок команд.  Если ни одно из условий не истинно, выполняет последний блок команд.", _.Msg.CONTROLS_REPEAT_HELPURL = "https://ru.wikipedia.org/wiki/Цикл_(программирование)", _.Msg.CONTROLS_REPEAT_INPUT_DO = "выполнить", _.Msg.CONTROLS_REPEAT_TITLE = "повторить %1 раз", _.Msg.CONTROLS_REPEAT_TOOLTIP = "Выполняет некоторые команды несколько раз.", _.Msg.CONTROLS_WHILEUNTIL_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Loops#repeat", _.Msg.CONTROLS_WHILEUNTIL_OPERATOR_UNTIL = "повторять, пока не", _.Msg.CONTROLS_WHILEUNTIL_OPERATOR_WHILE = "повторять, пока", _.Msg.CONTROLS_WHILEUNTIL_TOOLTIP_UNTIL = "Пока значение ложно, выполняет команды", _.Msg.CONTROLS_WHILEUNTIL_TOOLTIP_WHILE = "Пока значение истинно, выполняет команды.", _.Msg.CONTROL_KEY = "Control", _.Msg.COPY_ALL_TO_BACKPACK = "Copy All Blocks to Backpack", _.Msg.COPY_SHORTCUT = "Копировать", _.Msg.COPY_TO_BACKPACK = "Copy to Backpack", _.Msg.CURRENT_BLOCK_ANNOUNCEMENT = "Current block: %1", _.Msg.CUT_SHORTCUT = "Вырезать", _.Msg.DELETE_ALL_BLOCKS = "Удалить все блоки (%1)?", _.Msg.DELETE_BLOCK = "Удалить блок", _.Msg.DELETE_KEY = "Delete", _.Msg.DELETE_VARIABLE = "Удалить переменную '%1'", _.Msg.DELETE_VARIABLE_CONFIRMATION = "Удалить %1 использований переменной '%2'?", _.Msg.DELETE_X_BLOCKS = "Удалить %1 блоков", _.Msg.DIALOG_CANCEL = "Отмена", _.Msg.DIALOG_OK = "OK", _.Msg.DISABLE_BLOCK = "Отключить блок", _.Msg.DUPLICATE_BLOCK = "Дублировать", _.Msg.DUPLICATE_COMMENT = "Дублировать комментарий", _.Msg.EDIT_BLOCK_CONTENTS = "Редактировать содержимое блока", _.Msg.EMPTY_BACKPACK = "Empty Backpack", _.Msg.ENABLE_BLOCK = "Включить блок", _.Msg.END_KEY = "End", _.Msg.ENTER_KEY = "Enter", _.Msg.ESCAPE = "Escape", _.Msg.EXPAND_ALL = "Развернуть блоки", _.Msg.EXPAND_BLOCK = "Развернуть блок", _.Msg.EXTERNAL_INPUTS = "Вставки снаружи", _.Msg.FIELD_BITMAP_ARIA_VALUE = "%1 by %2, %3 pixels on", _.Msg.FIELD_BITMAP_BUTTON_LABEL_CLEAR = "Clear", _.Msg.FIELD_BITMAP_BUTTON_LABEL_RANDOMIZE = "Randomize", _.Msg.FIELD_BITMAP_PIXEL_LABEL = "%1, row %2, column %3", _.Msg.FIELD_BITMAP_PIXEL_OFF = "off", _.Msg.FIELD_BITMAP_PIXEL_ON = "on", _.Msg.FIELD_LABEL_CHECKBOX_CHECKED = "Checked", _.Msg.FIELD_LABEL_CHECKBOX_UNCHECKED = "Not checked", _.Msg.FIELD_LABEL_EDIT_PREFIX = "Edit %1", _.Msg.FIELD_LABEL_EMPTY = "empty", _.Msg.FIELD_LABEL_OPTION_INDEX = "Option %1", _.Msg.FIELD_LABEL_VARIABLE = "Variable '%1'", _.Msg.FIELD_MULTILINEINPUT_FINISH_EDITING = "Finish editing", _.Msg.FIELD_MULTILINEINPUT_NEW_LINE = "New line", _.Msg.HELP = "Справка", _.Msg.HELP_PROMPT = "Нажмите %1 для получения справки по управлению с клавиатуры.", _.Msg.HOME_KEY = "Home", _.Msg.ICON_LABEL_COMMENT_CLOSED = "Open Comment", _.Msg.ICON_LABEL_COMMENT_OPEN = "Close Comment", _.Msg.ICON_LABEL_DEFAULT = "Icon", _.Msg.ICON_LABEL_MUTATOR_CLOSED = "Edit this block", _.Msg.ICON_LABEL_MUTATOR_OPEN = "Close block editor", _.Msg.ICON_LABEL_WARNING_CLOSED = "Open Warning", _.Msg.ICON_LABEL_WARNING_OPEN = "Close Warning", _.Msg.INLINE_INPUTS = "Вставки внутри", _.Msg.INPUT_LABEL_CONDITION = "condition", _.Msg.INPUT_LABEL_CONDITION_A = "first condition", _.Msg.INPUT_LABEL_CONDITION_B = "second condition", _.Msg.INPUT_LABEL_EMPTY = "Empty", _.Msg.INPUT_LABEL_END_STATEMENT = "End %1", _.Msg.INPUT_LABEL_INDEX = "input %1", _.Msg.INPUT_LABEL_LISTS_CREATE_WITH_ITEM = "value %1", _.Msg.INPUT_LABEL_LISTS_DELIMITER = "delimiter", _.Msg.INPUT_LABEL_LISTS_END_POSITION = "end position", _.Msg.INPUT_LABEL_LISTS_LIST_FROM_TEXT = "text to split", _.Msg.INPUT_LABEL_LISTS_POSITION = "position within list", _.Msg.INPUT_LABEL_LISTS_REPEAT_ITEM = "value to repeat", _.Msg.INPUT_LABEL_LISTS_REPEAT_NUM = "number of times to repeat", _.Msg.INPUT_LABEL_LISTS_START_POSITION = "start position", _.Msg.INPUT_LABEL_LISTS_TEXT_FROM_LIST = "list to join", _.Msg.INPUT_LABEL_LISTS_TO_CHANGE = "list to change", _.Msg.INPUT_LABEL_LISTS_TO_CHECK = "list to check", _.Msg.INPUT_LABEL_LISTS_VALUE_TO_SET = "value to set", _.Msg.INPUT_LABEL_LOOP_BY = "increment", _.Msg.INPUT_LABEL_LOOP_FROM = "starting number", _.Msg.INPUT_LABEL_LOOP_LIST = "list to iterate over", _.Msg.INPUT_LABEL_LOOP_TIMES = "number of times to repeat", _.Msg.INPUT_LABEL_LOOP_TO = "ending number", _.Msg.INPUT_LABEL_MATH_CHANGE_BY = "amount to change by", _.Msg.INPUT_LABEL_MATH_CONSTRAIN_VALUE = "number to constrain", _.Msg.INPUT_LABEL_MATH_DIVIDEND = "dividend", _.Msg.INPUT_LABEL_MATH_DIVISOR = "divisor", _.Msg.INPUT_LABEL_NUMBER = "number", _.Msg.INPUT_LABEL_NUMBER_A = "first number", _.Msg.INPUT_LABEL_NUMBER_ATAN2_X = "x coordinate", _.Msg.INPUT_LABEL_NUMBER_ATAN2_Y = "y coordinate", _.Msg.INPUT_LABEL_NUMBER_B = "second number", _.Msg.INPUT_LABEL_NUMBER_LIST = "list of numbers", _.Msg.INPUT_LABEL_NUMBER_MAX = "maximum", _.Msg.INPUT_LABEL_NUMBER_MIN = "minimum", _.Msg.INPUT_LABEL_NUMBER_TO_CHECK = "number to check", _.Msg.INPUT_LABEL_STATEMENT = "statement position", _.Msg.INPUT_LABEL_TEXT_APPEND = "value to append", _.Msg.INPUT_LABEL_TEXT_END_POSITION = "end position", _.Msg.INPUT_LABEL_TEXT_JOIN_ITEM = "value %1", _.Msg.INPUT_LABEL_TEXT_POSITION = "letter position", _.Msg.INPUT_LABEL_TEXT_PROMPT_MESSAGE = "message", _.Msg.INPUT_LABEL_TEXT_START_POSITION = "start position", _.Msg.INPUT_LABEL_TEXT_TO_CHANGE = "text to change", _.Msg.INPUT_LABEL_TEXT_TO_CHECK = "text to check", _.Msg.INPUT_LABEL_TEXT_TO_FIND = "text to find", _.Msg.INPUT_LABEL_TEXT_TO_REPLACE = "text to replace", _.Msg.INPUT_LABEL_VALUE = "value position", _.Msg.INPUT_LABEL_VALUE_A = "first value", _.Msg.INPUT_LABEL_VALUE_B = "second value", _.Msg.INPUT_LABEL_VARIABLES_SET = "value to set", _.Msg.INSERT_KEY = "Insert", _.Msg.KEYBOARD_NAV_BLOCK_NAVIGATION_HINT = "Use %1 to navigate inside of blocks.", _.Msg.KEYBOARD_NAV_CONSTRAINED_MOVE_HINT = "Используйте клавиши со стрелками для перемещения, а затем %1, чтобы утвердить позицию.", _.Msg.KEYBOARD_NAV_COPIED_HINT = "Скопировано. Нажмите %1, чтобы вставить.", _.Msg.KEYBOARD_NAV_CUT_HINT = "Вырезано. Нажмите %1, чтобы вставить.", _.Msg.KEYBOARD_NAV_FLYOUT_LABEL_HINT = "Use the arrow keys to navigate to a block, or press %1 to go to the next heading.", _.Msg.KEYBOARD_NAV_UNCONSTRAINED_MOVE_HINT = "Удерживайте %1 и используйте клавиши со стрелками для свободного перемещения, а затем %2, чтобы утвердить позицию.", _.Msg.KEYBOARD_NAV_WORKSPACE_NAVIGATION_HINT = "Use the arrow keys to navigate.", _.Msg.LINUX = "Linux", _.Msg.LISTS_CREATE_EMPTY_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#create-empty-list", _.Msg.LISTS_CREATE_EMPTY_TITLE = "создать пустой список", _.Msg.LISTS_CREATE_EMPTY_TOOLTIP = "Возвращает список длины 0, не содержащий данных", _.Msg.LISTS_CREATE_WITH_CONTAINER_TITLE_ADD = "список", _.Msg.LISTS_CREATE_WITH_CONTAINER_TOOLTIP = "Добавьте, удалите, переставьте элементы для переделки блока списка.", _.Msg.LISTS_CREATE_WITH_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#create-list-with", _.Msg.LISTS_CREATE_WITH_INPUT_WITH = "создать список из", _.Msg.LISTS_CREATE_WITH_ITEM_TOOLTIP = "Добавляет элемент к списку.", _.Msg.LISTS_CREATE_WITH_TOOLTIP = "Создаёт список с любым числом элементов.", _.Msg.LISTS_GET_INDEX_FIRST = "первый", _.Msg.LISTS_GET_INDEX_FROM_END = "№ с конца", _.Msg.LISTS_GET_INDEX_FROM_START = "№", _.Msg.LISTS_GET_INDEX_GET = "взять", _.Msg.LISTS_GET_INDEX_GET_REMOVE = "взять и удалить", _.Msg.LISTS_GET_INDEX_HELPURL = "https://github.com/google/blockly/wiki/Lists#getting-items-from-a-list", _.Msg.LISTS_GET_INDEX_LAST = "последний", _.Msg.LISTS_GET_INDEX_RANDOM = "произвольный", _.Msg.LISTS_GET_INDEX_REMOVE = "удалить", _.Msg.LISTS_GET_INDEX_TAIL = "", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_FIRST = "Возвращает первый элемент списка.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_FROM = "Возвращает элемент в указанной позиции списка.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_LAST = "Возвращает последний элемент списка.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_RANDOM = "Возвращает случайный элемент списка.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_FIRST = "Удаляет и возвращает первый элемент списка.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_FROM = "Удаляет и возвращает элемент в указанной позиции списка.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_LAST = "Удаляет и возвращает последний элемент списка.", _.Msg.LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_RANDOM = "Удаляет и возвращает случайный элемент списка.", _.Msg.LISTS_GET_INDEX_TOOLTIP_REMOVE_FIRST = "Удаляет первый элемент списка.", _.Msg.LISTS_GET_INDEX_TOOLTIP_REMOVE_FROM = "Удаляет элемент в указанной позиции списка.", _.Msg.LISTS_GET_INDEX_TOOLTIP_REMOVE_LAST = "Удаляет последний элемент списка.", _.Msg.LISTS_GET_INDEX_TOOLTIP_REMOVE_RANDOM = "Удаляет случайный элемент списка.", _.Msg.LISTS_GET_SUBLIST_END_FROM_END = "по № с конца", _.Msg.LISTS_GET_SUBLIST_END_FROM_START = "по №", _.Msg.LISTS_GET_SUBLIST_END_LAST = "по последний", _.Msg.LISTS_GET_SUBLIST_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#getting-a-sublist", _.Msg.LISTS_GET_SUBLIST_START_FIRST = "взять подсписок с первого", _.Msg.LISTS_GET_SUBLIST_START_FROM_END = "взять подсписок с № с конца", _.Msg.LISTS_GET_SUBLIST_START_FROM_START = "взять подсписок с №", _.Msg.LISTS_GET_SUBLIST_TAIL = "", _.Msg.LISTS_GET_SUBLIST_TOOLTIP = "Создаёт копию указанной части списка.", _.Msg.LISTS_INDEX_FROM_END_TOOLTIP = "%1 - последний элемент.", _.Msg.LISTS_INDEX_FROM_START_TOOLTIP = "%1 - первый элемент.", _.Msg.LISTS_INDEX_OF_FIRST = "найти первое вхождение элемента", _.Msg.LISTS_INDEX_OF_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#finding-items-in-a-list", _.Msg.LISTS_INDEX_OF_LAST = "найти последнее вхождение элемента", _.Msg.LISTS_INDEX_OF_TOOLTIP = "Возвращает номер позиции первого/последнего вхождения элемента в списке. Возвращает %1, если элемент не найден.", _.Msg.LISTS_INLIST = "в списке", _.Msg.LISTS_ISEMPTY_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#is-empty", _.Msg.LISTS_ISEMPTY_TITLE = "%1 пуст", _.Msg.LISTS_ISEMPTY_TOOLTIP = "Возвращает значение истина, если список пуст.", _.Msg.LISTS_LENGTH_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#length-of", _.Msg.LISTS_LENGTH_TITLE = "длина %1", _.Msg.LISTS_LENGTH_TOOLTIP = "Возвращает длину списка.", _.Msg.LISTS_REPEAT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#create-list-with", _.Msg.LISTS_REPEAT_TITLE = "создать список из элемента %1, повторяющегося %2 раз", _.Msg.LISTS_REPEAT_TOOLTIP = "Создаёт список, состоящий из заданного числа копий элемента.", _.Msg.LISTS_REVERSE_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#reversing-a-list", _.Msg.LISTS_REVERSE_MESSAGE0 = "изменить порядок на обратный %1", _.Msg.LISTS_REVERSE_TOOLTIP = "Изменить порядок списка на обратный.", _.Msg.LISTS_SET_INDEX_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#in-list--set", _.Msg.LISTS_SET_INDEX_INPUT_TO = "=", _.Msg.LISTS_SET_INDEX_INSERT = "вставить в", _.Msg.LISTS_SET_INDEX_SET = "присвоить", _.Msg.LISTS_SET_INDEX_TOOLTIP_INSERT_FIRST = "Вставляет элемент в начало списка.", _.Msg.LISTS_SET_INDEX_TOOLTIP_INSERT_FROM = "Вставляет элемент в указанной позиции списка.", _.Msg.LISTS_SET_INDEX_TOOLTIP_INSERT_LAST = "Добавляет элемент в конец списка.", _.Msg.LISTS_SET_INDEX_TOOLTIP_INSERT_RANDOM = "Вставляет элемент в случайное место в списке.", _.Msg.LISTS_SET_INDEX_TOOLTIP_SET_FIRST = "Присваивает значение первому элементу списка.", _.Msg.LISTS_SET_INDEX_TOOLTIP_SET_FROM = "Присваивает значение элементу в указанной позиции списка.", _.Msg.LISTS_SET_INDEX_TOOLTIP_SET_LAST = "Присваивает значение последнему элементу списка.", _.Msg.LISTS_SET_INDEX_TOOLTIP_SET_RANDOM = "Присваивает значение случайному элементу списка.", _.Msg.LISTS_SORT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#sorting-a-list", _.Msg.LISTS_SORT_ORDER_ASCENDING = "по возрастанию", _.Msg.LISTS_SORT_ORDER_DESCENDING = "по убыванию", _.Msg.LISTS_SORT_TITLE = "сортировать %1 %2 %3", _.Msg.LISTS_SORT_TOOLTIP = "Сортировать копию списка.", _.Msg.LISTS_SORT_TYPE_IGNORECASE = "по алфавиту, без учёта регистра", _.Msg.LISTS_SORT_TYPE_NUMERIC = "числовая", _.Msg.LISTS_SORT_TYPE_TEXT = "по алфавиту", _.Msg.LISTS_SPLIT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Lists#splitting-strings-and-joining-lists", _.Msg.LISTS_SPLIT_LIST_FROM_TEXT = "сделать список из текста", _.Msg.LISTS_SPLIT_TEXT_FROM_LIST = "собрать текст из списка", _.Msg.LISTS_SPLIT_TOOLTIP_JOIN = "Соединяет список текстов в один текст с разделителями.", _.Msg.LISTS_SPLIT_TOOLTIP_SPLIT = "Разбивает текст в список текстов, по разделителям.", _.Msg.LISTS_SPLIT_WITH_DELIMITER = "с разделителем", _.Msg.LOGIC_BOOLEAN_FALSE = "ложь", _.Msg.LOGIC_BOOLEAN_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Logic#values", _.Msg.LOGIC_BOOLEAN_TOOLTIP = "Возвращает значение истина или ложь.", _.Msg.LOGIC_BOOLEAN_TRUE = "истина", _.Msg.LOGIC_COMPARE_EQ_ARIA = "равно", _.Msg.LOGIC_COMPARE_GTE_ARIA = "больше или равно", _.Msg.LOGIC_COMPARE_GT_ARIA = "больше", _.Msg.LOGIC_COMPARE_HELPURL = "https://ru.wikipedia.org/wiki/Неравенство", _.Msg.LOGIC_COMPARE_LTE_ARIA = "меньше или равно", _.Msg.LOGIC_COMPARE_LT_ARIA = "меньше", _.Msg.LOGIC_COMPARE_NEQ_ARIA = "не равно", _.Msg.LOGIC_COMPARE_TOOLTIP_EQ = "Возвращает положительное значение, если вводы равны.", _.Msg.LOGIC_COMPARE_TOOLTIP_GT = "Возвращает значение истина, если первая вставка больше второй.", _.Msg.LOGIC_COMPARE_TOOLTIP_GTE = "Возвращает значение истина, если первая вставка больше или равна второй.", _.Msg.LOGIC_COMPARE_TOOLTIP_LT = "Возвращает положительное значение, если первый ввод меньше второго.", _.Msg.LOGIC_COMPARE_TOOLTIP_LTE = "Возвращает значение истина, если первая вставка меньше или равна второй.", _.Msg.LOGIC_COMPARE_TOOLTIP_NEQ = "Возвращает положительное значение, если вводы не равны.", _.Msg.LOGIC_NEGATE_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Logic#not", _.Msg.LOGIC_NEGATE_TITLE = "не %1", _.Msg.LOGIC_NEGATE_TOOLTIP = "Возвращает значение истина, если вставка ложна. Возвращает значение ложь, если вставка истинна.", _.Msg.LOGIC_NULL = "ничто", _.Msg.LOGIC_NULL_HELPURL = "https://en.wikipedia.org/wiki/Nullable_type", _.Msg.LOGIC_NULL_TOOLTIP = "Возвращает ничто.", _.Msg.LOGIC_OPERATION_AND = "и", _.Msg.LOGIC_OPERATION_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Logic#logical-operations", _.Msg.LOGIC_OPERATION_OR = "или", _.Msg.LOGIC_OPERATION_TOOLTIP_AND = "Возвращает значение истина, если обе вставки истинны.", _.Msg.LOGIC_OPERATION_TOOLTIP_OR = "Возвращает значение истина, если хотя бы одна из вставок истинна.", _.Msg.LOGIC_TERNARY_CONDITION = "выбрать по", _.Msg.LOGIC_TERNARY_HELPURL = "https://ru.wikipedia.org/wiki/%3F#В_компьютерах", _.Msg.LOGIC_TERNARY_IF_FALSE = "если ложь", _.Msg.LOGIC_TERNARY_IF_TRUE = "если истина", _.Msg.LOGIC_TERNARY_TOOLTIP = "Проверяет условие выбора. Если условие истинно, возвращает первое значение, в противном случае возвращает второе значение.", _.Msg.MAC_OS = "macOS", _.Msg.MATH_ADDITION_SYMBOL = "+", _.Msg.MATH_ADDITION_SYMBOL_ARIA = "плюс", _.Msg.MATH_ARITHMETIC_HELPURL = "https://ru.wikipedia.org/wiki/Арифметика", _.Msg.MATH_ARITHMETIC_TOOLTIP_ADD = "Возвращает сумму двух чисел.", _.Msg.MATH_ARITHMETIC_TOOLTIP_DIVIDE = "Возвращает частное от деления первого числа на второе.", _.Msg.MATH_ARITHMETIC_TOOLTIP_MINUS = "Возвращает разность двух чисел.", _.Msg.MATH_ARITHMETIC_TOOLTIP_MULTIPLY = "Возвращает произведение двух чисел.", _.Msg.MATH_ARITHMETIC_TOOLTIP_POWER = "Возвращает первое число, возведённое в степень второго числа.", _.Msg.MATH_ATAN2_HELPURL = "https://en.wikipedia.org/wiki/Atan2", _.Msg.MATH_ATAN2_TITLE = "atan2 от X:%1 Y:%2", _.Msg.MATH_ATAN2_TOOLTIP = "Возвращает арктангенс точки (X, Y) в градусах от -180 до 180.", _.Msg.MATH_CHANGE_HELPURL = "https://ru.wikipedia.org/wiki/Идиома_(программирование)#Инкремент", _.Msg.MATH_CHANGE_TITLE = "увеличить %1 на %2", _.Msg.MATH_CHANGE_TOOLTIP = "Добавляет число к переменной '%1'.", _.Msg.MATH_CONSTANT_E_ARIA = "e", _.Msg.MATH_CONSTANT_GOLDEN_RATIO_ARIA = "золотое сечение", _.Msg.MATH_CONSTANT_HELPURL = "https://ru.wikipedia.org/wiki/Математическая_константа", _.Msg.MATH_CONSTANT_INFINITY_ARIA = "infinity", _.Msg.MATH_CONSTANT_PI_ARIA = "пи", _.Msg.MATH_CONSTANT_SQRT1_2_ARIA = "square root of 1 over 2", _.Msg.MATH_CONSTANT_SQRT2_ARIA = "квадратный корень из 2", _.Msg.MATH_CONSTANT_TOOLTIP = "Возвращает одну из распространённых констант: π (3.141...), e (2.718...), φ (1.618...), sqrt(2) (1.414...), sqrt(½) (0.707...) или ∞ (бесконечность).", _.Msg.MATH_CONSTRAIN_HELPURL = "https://en.wikipedia.org/wiki/Clamping_(graphics)", _.Msg.MATH_CONSTRAIN_TITLE = "ограничить %1 снизу %2 сверху %3", _.Msg.MATH_CONSTRAIN_TOOLTIP = "Ограничивает число нижней и верхней границами (включительно).", _.Msg.MATH_DIVISION_SYMBOL = "÷", _.Msg.MATH_DIVISION_SYMBOL_ARIA = "разделить на", _.Msg.MATH_IS_DIVISIBLE_BY = "делится на", _.Msg.MATH_IS_EVEN = "чётное", _.Msg.MATH_IS_NEGATIVE = "отрицательное", _.Msg.MATH_IS_ODD = "нечётное", _.Msg.MATH_IS_POSITIVE = "положительное", _.Msg.MATH_IS_PRIME = "простое", _.Msg.MATH_IS_TOOLTIP = "Проверяет, является ли число чётным, нечётным, простым, целым, положительным, отрицательным или оно кратно определённому числу.  Возвращает значение истина или ложь.", _.Msg.MATH_IS_WHOLE = "целое", _.Msg.MATH_MODULO_HELPURL = "https://ru.wikipedia.org/wiki/Деление_с_остатком", _.Msg.MATH_MODULO_TITLE = "остаток от %1 ÷ %2", _.Msg.MATH_MODULO_TOOLTIP = "Возвращает остаток от деления двух чисел.", _.Msg.MATH_MULTIPLICATION_SYMBOL = "×", _.Msg.MATH_MULTIPLICATION_SYMBOL_ARIA = "times", _.Msg.MATH_NUMBER_HELPURL = "https://ru.wikipedia.org/wiki/Число", _.Msg.MATH_NUMBER_TOOLTIP = "Число.", _.Msg.MATH_ONLIST_HELPURL = "", _.Msg.MATH_ONLIST_OPERATOR_AVERAGE = "среднее арифметическое списка", _.Msg.MATH_ONLIST_OPERATOR_MAX = "наибольшее в списке", _.Msg.MATH_ONLIST_OPERATOR_MAX_ARIA = "maximum", _.Msg.MATH_ONLIST_OPERATOR_MEDIAN = "медиана списка", _.Msg.MATH_ONLIST_OPERATOR_MIN = "наименьшее в списке", _.Msg.MATH_ONLIST_OPERATOR_MIN_ARIA = "minimum", _.Msg.MATH_ONLIST_OPERATOR_MODE = "моды списка", _.Msg.MATH_ONLIST_OPERATOR_RANDOM = "случайный элемент списка", _.Msg.MATH_ONLIST_OPERATOR_STD_DEV = "стандартное отклонение списка", _.Msg.MATH_ONLIST_OPERATOR_SUM = "сумма списка", _.Msg.MATH_ONLIST_TOOLTIP_AVERAGE = "Возвращает среднее арифметическое списка.", _.Msg.MATH_ONLIST_TOOLTIP_MAX = "Возвращает наибольшее число списка.", _.Msg.MATH_ONLIST_TOOLTIP_MEDIAN = "Возвращает медиану списка.", _.Msg.MATH_ONLIST_TOOLTIP_MIN = "Возвращает наименьшее число списка.", _.Msg.MATH_ONLIST_TOOLTIP_MODE = "Возвращает список наиболее часто встречающихся элементов списка.", _.Msg.MATH_ONLIST_TOOLTIP_RANDOM = "Возвращает случайный элемент списка.", _.Msg.MATH_ONLIST_TOOLTIP_STD_DEV = "Возвращает стандартное отклонение списка.", _.Msg.MATH_ONLIST_TOOLTIP_SUM = "Возвращает сумму всех чисел в списке.", _.Msg.MATH_POWER_SYMBOL = "^", _.Msg.MATH_POWER_SYMBOL_ARIA = "to the power of", _.Msg.MATH_RANDOM_FLOAT_HELPURL = "https://ru.wikipedia.org/wiki/Генератор_псевдослучайных_чисел", _.Msg.MATH_RANDOM_FLOAT_TITLE_RANDOM = "случайное число от 0.0 до 1.0 (вкл.)", _.Msg.MATH_RANDOM_FLOAT_TOOLTIP = "Возвращает случайное число от 0.0 (включительно) до 1.0.", _.Msg.MATH_RANDOM_INT_HELPURL = "https://ru.wikipedia.org/wiki/Генератор_псевдослучайных_чисел", _.Msg.MATH_RANDOM_INT_TITLE = "случайное целое число от %1 до %2", _.Msg.MATH_RANDOM_INT_TOOLTIP = "Возвращает случайное число между двумя заданными пределами (включая и их).", _.Msg.MATH_ROUND_HELPURL = "https://ru.wikipedia.org/wiki/Округление", _.Msg.MATH_ROUND_OPERATOR_ROUND = "округлить", _.Msg.MATH_ROUND_OPERATOR_ROUNDDOWN = "округлить к меньшему", _.Msg.MATH_ROUND_OPERATOR_ROUNDUP = "округлить к большему", _.Msg.MATH_ROUND_TOOLTIP = "Округляет число до большего или меньшего.", _.Msg.MATH_SINGLE_HELPURL = "https://ru.wikipedia.org/wiki/Квадратный_корень", _.Msg.MATH_SINGLE_OP_ABSOLUTE = "модуль", _.Msg.MATH_SINGLE_OP_ABSOLUTE_ARIA = "абсолютное значение", _.Msg.MATH_SINGLE_OP_EXP_ARIA = "e to the power of", _.Msg.MATH_SINGLE_OP_LN_ARIA = "natural logarithm", _.Msg.MATH_SINGLE_OP_LOG10_ARIA = "base 10 logarithm", _.Msg.MATH_SINGLE_OP_NEG_ARIA = "negative", _.Msg.MATH_SINGLE_OP_POW10_ARIA = "10 to the power of", _.Msg.MATH_SINGLE_OP_ROOT = "квадратный корень", _.Msg.MATH_SINGLE_TOOLTIP_ABS = "Возвращает модуль числа", _.Msg.MATH_SINGLE_TOOLTIP_EXP = "Возвращает е в указанной степени.", _.Msg.MATH_SINGLE_TOOLTIP_LN = "Возвращает натуральный логарифм числа.", _.Msg.MATH_SINGLE_TOOLTIP_LOG10 = "Возвращает десятичный логарифм числа.", _.Msg.MATH_SINGLE_TOOLTIP_NEG = "Возвращает противоположное число.", _.Msg.MATH_SINGLE_TOOLTIP_POW10 = "Возвращает 10 в указанной степени.", _.Msg.MATH_SINGLE_TOOLTIP_ROOT = "Возвращает квадратный корень числа.", _.Msg.MATH_SUBTRACTION_SYMBOL = "-", _.Msg.MATH_SUBTRACTION_SYMBOL_ARIA = "минус", _.Msg.MATH_TRIG_ACOS = "arccos", _.Msg.MATH_TRIG_ACOS_ARIA = "арккосинус", _.Msg.MATH_TRIG_ASIN = "arcsin", _.Msg.MATH_TRIG_ASIN_ARIA = "арксинус", _.Msg.MATH_TRIG_ATAN = "arctan", _.Msg.MATH_TRIG_ATAN_ARIA = "арктангенс", _.Msg.MATH_TRIG_COS = "cos", _.Msg.MATH_TRIG_COS_ARIA = "косинус", _.Msg.MATH_TRIG_HELPURL = "https://ru.wikipedia.org/wiki/Тригонометрические_функции", _.Msg.MATH_TRIG_SIN = "sin", _.Msg.MATH_TRIG_SIN_ARIA = "синус", _.Msg.MATH_TRIG_TAN = "tan", _.Msg.MATH_TRIG_TAN_ARIA = "тангенс", _.Msg.MATH_TRIG_TOOLTIP_ACOS = "Возвращает арккосинус (в градусах).", _.Msg.MATH_TRIG_TOOLTIP_ASIN = "Возвращает арксинус (в градусах).", _.Msg.MATH_TRIG_TOOLTIP_ATAN = "Возвращает арктангенс (в градусах)", _.Msg.MATH_TRIG_TOOLTIP_COS = "Возвращает косинус угла в градусах.", _.Msg.MATH_TRIG_TOOLTIP_SIN = "Возвращает синус угла в градусах.", _.Msg.MATH_TRIG_TOOLTIP_TAN = "Возвращает тангенс угла в градусах.", _.Msg.MINIMAP_ARIA_LABEL = "Workspace minimap. Use the arrow keys to pan the workspace.", _.Msg.MOVE_BLOCK = "Переместить блок", _.Msg.NEW_COLOUR_VARIABLE = "Создать переменную цвета...", _.Msg.NEW_NUMBER_VARIABLE = "Создать числовую переменную...", _.Msg.NEW_STRING_VARIABLE = "Создать строковую переменную...", _.Msg.NEW_VARIABLE = "Создать переменную…", _.Msg.NEW_VARIABLE_TITLE = "Имя новой переменной:", _.Msg.NEW_VARIABLE_TYPE_TITLE = "Новый тип переменной:", _.Msg.NO_PARENT_ANNOUNCEMENT = "Current block has no parent", _.Msg.OPEN_BACKPACK = "Open backpack", _.Msg.OPEN_TRASH = "Open trash", _.Msg.OPTION_KEY = "Option", _.Msg.ORDINAL_NUMBER_SUFFIX = "", _.Msg.PAGE_DOWN_KEY = "Page Down", _.Msg.PAGE_UP_KEY = "Page Up", _.Msg.PARENT_BLOCKS_ANNOUNCEMENT = "Parent blocks: %1", _.Msg.PASTE_ALL_FROM_BACKPACK = "Paste All Blocks from Backpack", _.Msg.PASTE_SHORTCUT = "Вставить", _.Msg.PAUSE_KEY = "Pause", _.Msg.PROCEDURES_ALLOW_STATEMENTS = "разрешить операторы", _.Msg.PROCEDURES_BEFORE_PARAMS = "с:", _.Msg.PROCEDURES_CALLNORETURN_HELPURL = "https://ru.wikipedia.org/wiki/Подпрограмма", _.Msg.PROCEDURES_CALLNORETURN_TOOLTIP = "Исполняет определённую пользователем процедуру '%1'.", _.Msg.PROCEDURES_CALLRETURN_HELPURL = "https://ru.wikipedia.org/wiki/Подпрограмма", _.Msg.PROCEDURES_CALLRETURN_TOOLTIP = "Исполняет определённую пользователем процедуру '%1' и возвращает вычисленное значение.", _.Msg.PROCEDURES_CALL_BEFORE_PARAMS = "с:", _.Msg.PROCEDURES_CALL_DISABLED_DEF_WARNING = "Невозможно запустить пользовательскую функцию '%1', поскольку блок определения отключен.", _.Msg.PROCEDURES_CREATE_DO = "Создать вызов '%1'", _.Msg.PROCEDURES_DEFNORETURN_COMMENT = "Опишите эту функцию…", _.Msg.PROCEDURES_DEFNORETURN_DO = "", _.Msg.PROCEDURES_DEFNORETURN_HELPURL = "https://ru.wikipedia.org/wiki/Подпрограмма", _.Msg.PROCEDURES_DEFNORETURN_PROCEDURE = "выполнить что-то", _.Msg.PROCEDURES_DEFNORETURN_TITLE = "чтобы", _.Msg.PROCEDURES_DEFNORETURN_TOOLTIP = "Создаёт процедуру, не возвращающую значение.", _.Msg.PROCEDURES_DEFRETURN_HELPURL = "https://ru.wikipedia.org/wiki/Функция_(программирование)", _.Msg.PROCEDURES_DEFRETURN_RETURN = "вернуть", _.Msg.PROCEDURES_DEFRETURN_TOOLTIP = "Создаёт процедуру, возвращающую значение.", _.Msg.PROCEDURES_DEF_DUPLICATE_WARNING = "Предупреждение: эта функция имеет повторяющиеся параметры.", _.Msg.PROCEDURES_HIGHLIGHT_DEF = "Выделить определение процедуры", _.Msg.PROCEDURES_IFRETURN_HELPURL = "https://c2.com/cgi/wiki?GuardClause", _.Msg.PROCEDURES_IFRETURN_TOOLTIP = "Если первое значение истинно, возвращает второе значение.", _.Msg.PROCEDURES_IFRETURN_WARNING = "Предупреждение: Этот блок может использоваться только внутри определения функции.", _.Msg.PROCEDURES_MUTATORARG_TITLE = "имя параметра:", _.Msg.PROCEDURES_MUTATORARG_TOOLTIP = "Добавить входной параметр в функцию.", _.Msg.PROCEDURES_MUTATORCONTAINER_TITLE = "параметры", _.Msg.PROCEDURES_MUTATORCONTAINER_TOOLTIP = "Добавить, удалить или изменить порядок входных параметров для этой функции.", _.Msg.REDO = "Повторить", _.Msg.REMOVE_COMMENT = "Удалить комментарий", _.Msg.REMOVE_FROM_BACKPACK = "Remove from Backpack", _.Msg.RENAME_VARIABLE = "Переименовать переменную '%1'", _.Msg.RENAME_VARIABLE_TITLE = "Переименовать все переменные '%1' в:", _.Msg.RESET_ZOOM = "Reset zoom", _.Msg.SCREENREADER_HINT = "Use the arrow keys to navigate. Press %1 to toggle screenreader accessibility mode.", _.Msg.SCREENREADER_MODE_DISABLED = "Screenreader mode is off, press %1 to turn it on", _.Msg.SCREENREADER_MODE_ENABLED = "Screenreader mode is on, press %1 to turn it off", _.Msg.SHIFT_KEY = "Shift", _.Msg.SHORTCUTS_ABORT_MOVE = "Abort move", _.Msg.SHORTCUTS_CLEANUP = "Clean up workspace", _.Msg.SHORTCUTS_CODE_NAVIGATION = "Навигация по коду", _.Msg.SHORTCUTS_DELETE = "Удалить", _.Msg.SHORTCUTS_DISCONNECT = "Disconnect block", _.Msg.SHORTCUTS_DUPLICATE = "Duplicate", _.Msg.SHORTCUTS_EDITING = "Редактирование", _.Msg.SHORTCUTS_ESCAPE = "Exit", _.Msg.SHORTCUTS_EXTENDED_INFORMATION = "Announce detailed information", _.Msg.SHORTCUTS_FINISH_MOVE = "Finish move", _.Msg.SHORTCUTS_FOCUS_TOOLBOX = "Focus toolbox", _.Msg.SHORTCUTS_FOCUS_WORKSPACE = "Focus workspace", _.Msg.SHORTCUTS_GENERAL = "Общие", _.Msg.SHORTCUTS_INFORMATION = "Announce information", _.Msg.SHORTCUTS_JUMP_BLOCK_END = "Jump to block end", _.Msg.SHORTCUTS_JUMP_BLOCK_START = "Jump to block start", _.Msg.SHORTCUTS_JUMP_BOTTOM_STACK = "Jump to bottom of stack", _.Msg.SHORTCUTS_JUMP_FIRST_BLOCK = "Jump to first block", _.Msg.SHORTCUTS_JUMP_LAST_BLOCK = "Jump to last block", _.Msg.SHORTCUTS_JUMP_NEXT_PAGE = "Jump to next page", _.Msg.SHORTCUTS_JUMP_PREVIOUS_PAGE = "Jump to previous page", _.Msg.SHORTCUTS_JUMP_TOP_STACK = "Jump to top of stack", _.Msg.SHORTCUTS_MOVE_DOWN = "Move down", _.Msg.SHORTCUTS_MOVE_LEFT = "Move left", _.Msg.SHORTCUTS_MOVE_RIGHT = "Move right", _.Msg.SHORTCUTS_MOVE_UP = "Move up", _.Msg.SHORTCUTS_NEXT_HEADING = "Next heading", _.Msg.SHORTCUTS_NEXT_STACK = "Next stack", _.Msg.SHORTCUTS_PERFORM_ACTION = "Edit or confirm", _.Msg.SHORTCUTS_PREVIOUS_HEADING = "Previous heading", _.Msg.SHORTCUTS_PREVIOUS_STACK = "Previous stack", _.Msg.SHORTCUTS_SCROLL_DOWN = "Scroll down", _.Msg.SHORTCUTS_SCROLL_LEFT = "Scroll left", _.Msg.SHORTCUTS_SCROLL_RIGHT = "Scroll right", _.Msg.SHORTCUTS_SCROLL_UP = "Scroll up", _.Msg.SHORTCUTS_SHOW_CONTEXT_MENU = "Show menu", _.Msg.SHORTCUTS_SHOW_TOOLTIP = "Show tooltip", _.Msg.SHORTCUTS_START_MOVE = "Start move", _.Msg.SHORTCUTS_START_MOVE_STACK = "Start move stack", _.Msg.SHORTCUTS_TOGGLE_SCREENREADER_MODE = "Toggle screenreader mode", _.Msg.SPACE_KEY = "Пробел", _.Msg.TAB_KEY = "Tab", _.Msg.TEXT_APPEND_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#text-modification", _.Msg.TEXT_APPEND_TITLE = "к %1 добавить текст %2", _.Msg.TEXT_APPEND_TOOLTIP = "Добавить текст к переменной «%1».", _.Msg.TEXT_CHANGECASE_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#adjusting-text-case", _.Msg.TEXT_CHANGECASE_OPERATOR_LOWERCASE = "в строчные буквы", _.Msg.TEXT_CHANGECASE_OPERATOR_TITLECASE = "в Заглавные Начальные Буквы", _.Msg.TEXT_CHANGECASE_OPERATOR_UPPERCASE = "в ЗАГЛАВНЫЕ БУКВЫ", _.Msg.TEXT_CHANGECASE_TOOLTIP = "Возвращает копию текста с ЗАГЛАВНЫМИ или строчными буквами.", _.Msg.TEXT_CHARAT_FIRST = "взять первую букву", _.Msg.TEXT_CHARAT_FROM_END = "взять букву № с конца", _.Msg.TEXT_CHARAT_FROM_START = "взять букву №", _.Msg.TEXT_CHARAT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#extracting-text", _.Msg.TEXT_CHARAT_LAST = "взять последнюю букву", _.Msg.TEXT_CHARAT_RANDOM = "взять случайную букву", _.Msg.TEXT_CHARAT_TAIL = "", _.Msg.TEXT_CHARAT_TITLE = "в тексте %1 %2", _.Msg.TEXT_CHARAT_TOOLTIP = "Возвращает букву в указанной позиции.", _.Msg.TEXT_COUNT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#counting-substrings", _.Msg.TEXT_COUNT_MESSAGE0 = "подсчитать количество %1 в %2", _.Msg.TEXT_COUNT_TOOLTIP = "Подсчитать, сколько раз отрывок текста появляется в другом тексте.", _.Msg.TEXT_CREATE_JOIN_ITEM_TOOLTIP = "Добавить элемент к тексту.", _.Msg.TEXT_CREATE_JOIN_TITLE_JOIN = "соединить", _.Msg.TEXT_CREATE_JOIN_TOOLTIP = "Добавьте, удалите, переставьте фрагменты для переделки текстового блока.", _.Msg.TEXT_FROM_END_ARIA = "letter number from end", _.Msg.TEXT_FROM_START_ARIA = "letter number", _.Msg.TEXT_GET_SUBSTRING_END_FROM_END = "по букву № с конца", _.Msg.TEXT_GET_SUBSTRING_END_FROM_START = "по букву №", _.Msg.TEXT_GET_SUBSTRING_END_LAST = "по последнюю букву", _.Msg.TEXT_GET_SUBSTRING_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#extracting-a-region-of-text", _.Msg.TEXT_GET_SUBSTRING_INPUT_IN_TEXT = "в тексте", _.Msg.TEXT_GET_SUBSTRING_START_FIRST = "взять подстроку с первой буквы", _.Msg.TEXT_GET_SUBSTRING_START_FROM_END = "взять подстроку с буквы № с конца", _.Msg.TEXT_GET_SUBSTRING_START_FROM_START = "взять подстроку с буквы №", _.Msg.TEXT_GET_SUBSTRING_TAIL = "", _.Msg.TEXT_GET_SUBSTRING_TOOLTIP = "Возвращает указанную часть текста.", _.Msg.TEXT_INDEXOF_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#finding-text", _.Msg.TEXT_INDEXOF_OPERATOR_FIRST = "найти первое вхождение текста", _.Msg.TEXT_INDEXOF_OPERATOR_LAST = "найти последнее вхождение текста", _.Msg.TEXT_INDEXOF_TITLE = "в тексте %1 %2 %3", _.Msg.TEXT_INDEXOF_TOOLTIP = "Возвращает номер позиции первого/последнего вхождения первого текста во втором.  Возвращает %1, если текст не найден.", _.Msg.TEXT_ISEMPTY_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#checking-for-empty-text", _.Msg.TEXT_ISEMPTY_TITLE = "%1 пуст", _.Msg.TEXT_ISEMPTY_TOOLTIP = "Возвращает значение истина, если предоставленный текст пуст.", _.Msg.TEXT_JOIN_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#text-creation", _.Msg.TEXT_JOIN_TITLE_CREATEWITH = "создать текст из", _.Msg.TEXT_JOIN_TOOLTIP = "Создаёт фрагмент текста, объединяя любое число элементов", _.Msg.TEXT_LENGTH_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#text-modification", _.Msg.TEXT_LENGTH_TITLE = "длина %1", _.Msg.TEXT_LENGTH_TOOLTIP = "Возвращает число символов (включая пробелы) в заданном тексте.", _.Msg.TEXT_PRINT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#printing-text", _.Msg.TEXT_PRINT_TITLE = "напечатать %1", _.Msg.TEXT_PRINT_TOOLTIP = "Печатает текст, число или другой объект.", _.Msg.TEXT_PROMPT_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#getting-input-from-the-user", _.Msg.TEXT_PROMPT_TOOLTIP_NUMBER = "Запросить у пользователя число.", _.Msg.TEXT_PROMPT_TOOLTIP_TEXT = "Запросить у пользователя текст.", _.Msg.TEXT_PROMPT_TYPE_NUMBER = "запросить число с подсказкой", _.Msg.TEXT_PROMPT_TYPE_TEXT = "запросить текст с подсказкой", _.Msg.TEXT_REPLACE_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#replacing-substrings", _.Msg.TEXT_REPLACE_MESSAGE0 = "заменить %1 на %2 в %3", _.Msg.TEXT_REPLACE_TOOLTIP = "Заменить все вхождения некоторого текста другим текстом.", _.Msg.TEXT_REVERSE_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#reversing-text", _.Msg.TEXT_REVERSE_MESSAGE0 = "изменить порядок на обратный %1", _.Msg.TEXT_REVERSE_TOOLTIP = "Меняет порядок символов в тексте на обратный.", _.Msg.TEXT_TEXT_HELPURL = "https://ru.wikipedia.org/wiki/Строковый_тип", _.Msg.TEXT_TEXT_TOOLTIP = "Буква, слово или строка текста.", _.Msg.TEXT_TRIM_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Text#trimming-removing-spaces", _.Msg.TEXT_TRIM_OPERATOR_BOTH = "обрезать пробелы с двух сторон", _.Msg.TEXT_TRIM_OPERATOR_LEFT = "обрезать пробелы слева", _.Msg.TEXT_TRIM_OPERATOR_RIGHT = "обрезать пробелы справа", _.Msg.TEXT_TRIM_TOOLTIP = "Возвращает копию текста с пробелами, удалёнными с одного или обоих концов.", _.Msg.TODAY = "Сегодня", _.Msg.TOOLBOX_SEARCH_NO_RESULTS = "No matching blocks found", _.Msg.TOOLBOX_SEARCH_PLACEHOLDER = "Search for blocks", _.Msg.TOOLBOX_SEARCH_PROMPT = "Type to search for blocks", _.Msg.TOOLBOX_SEARCH_RESULT_COUNT = "%1 matching blocks", _.Msg.TOOLBOX_SEARCH_RESULT_COUNT_ONE = "1 matching block", _.Msg.UNDO = "Отменить", _.Msg.UNKNOWN = "Неизвестно", _.Msg.UNNAMED_KEY = "без названия", _.Msg.VARIABLES_DEFAULT_NAME = "элемент", _.Msg.VARIABLES_GET_CREATE_SET = 'Создать блок "присвоить" для %1', _.Msg.VARIABLES_GET_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Variables#get", _.Msg.VARIABLES_GET_TOOLTIP = "Возвращает значение этой переменной.", _.Msg.VARIABLES_SET = "присвоить %1 = %2", _.Msg.VARIABLES_SET_CREATE_GET = "Создать вставку %1", _.Msg.VARIABLES_SET_HELPURL = "https://github.com/RaspberryPiFoundation/blockly/wiki/Variables#set", _.Msg.VARIABLES_SET_TOOLTIP = "Присваивает переменной значение вставки.", _.Msg.VARIABLE_ALREADY_EXISTS = "Переменная с именем '%1' уже существует.", _.Msg.VARIABLE_ALREADY_EXISTS_FOR_ANOTHER_TYPE = "Название переменной '%1' уже используется для другого типа: '%2'.", _.Msg.VARIABLE_ALREADY_EXISTS_FOR_A_PARAMETER = "Переменная с именем '%1' уже существует в качестве параметра в процедуре '%2'.", _.Msg.WINDOWS = "Windows", _.Msg.WORKSPACE_COMMENT_DEFAULT_TEXT = "Напишите здесь что-нибудь...", _.Msg.WORKSPACE_CONTENTS_BLOCKS_MANY = "%1 stacks of blocks%2 in workspace.", _.Msg.WORKSPACE_CONTENTS_BLOCKS_ONE = "One stack of blocks%2 in workspace.", _.Msg.WORKSPACE_CONTENTS_BLOCKS_ZERO = "No blocks%2 in workspace.", _.Msg.WORKSPACE_CONTENTS_COMMENTS_MANY = " and %1 comments", _.Msg.WORKSPACE_CONTENTS_COMMENTS_ONE = " and one comment", _.Msg.WORKSPACE_LABEL_1_STACK = "1 stack of blocks", _.Msg.WORKSPACE_LABEL_FLYOUT_WORKSPACE = "%1 blocks", _.Msg.WORKSPACE_LABEL_MANY_STACKS = "%1 stacks of blocks", _.Msg.WORKSPACE_LABEL_MUTATOR_WORKSPACE = "Block editor workspace", _.Msg.WORKSPACE_LABEL_PLAIN = "Blocks workspace.", _.Msg.WORKSPACE_ROLEDESCRIPTION = "workspace", _.Msg.WORKSPACE_SEARCH_CLOSE = "Close search bar", _.Msg.WORKSPACE_SEARCH_FIND_NEXT = "Find next", _.Msg.WORKSPACE_SEARCH_FIND_PREVIOUS = "Find previous", _.Msg.WORKSPACE_SEARCH_INPUT_LABEL = "Search workspace. Press Enter for the next match, Shift+Enter for the previous match. Press Escape to close search and focus the current match.", _.Msg.WORKSPACE_SEARCH_MATCH = "Match %1 of %2: %3", _.Msg.WORKSPACE_SEARCH_NO_MATCHES = "No matching blocks", _.Msg.WORKSPACE_SEARCH_PLACEHOLDER = "Search", _.Msg.ZOOM_IN = "Zoom in", _.Msg.ZOOM_OUT = "Zoom out", _.Msg.ZOOM_TO_FIT_ARIA_LABEL = "Zoom to fit", _.Msg.CONTROLS_FOREACH_INPUT_DO = _.Msg.CONTROLS_REPEAT_INPUT_DO, _.Msg.CONTROLS_FOR_INPUT_DO = _.Msg.CONTROLS_REPEAT_INPUT_DO, _.Msg.CONTROLS_IF_ELSEIF_TITLE_ELSEIF = _.Msg.CONTROLS_IF_MSG_ELSEIF, _.Msg.CONTROLS_IF_ELSE_TITLE_ELSE = _.Msg.CONTROLS_IF_MSG_ELSE, _.Msg.CONTROLS_IF_IF_TITLE_IF = _.Msg.CONTROLS_IF_MSG_IF, _.Msg.CONTROLS_IF_MSG_THEN = _.Msg.CONTROLS_REPEAT_INPUT_DO, _.Msg.CONTROLS_WHILEUNTIL_INPUT_DO = _.Msg.CONTROLS_REPEAT_INPUT_DO, _.Msg.LISTS_CREATE_WITH_ITEM_TITLE = _.Msg.VARIABLES_DEFAULT_NAME, _.Msg.LISTS_GET_INDEX_INPUT_IN_LIST = _.Msg.LISTS_INLIST, _.Msg.LISTS_GET_SUBLIST_INPUT_IN_LIST = _.Msg.LISTS_INLIST, _.Msg.LISTS_INDEX_OF_INPUT_IN_LIST = _.Msg.LISTS_INLIST, _.Msg.LISTS_SET_INDEX_INPUT_IN_LIST = _.Msg.LISTS_INLIST, _.Msg.MATH_CHANGE_TITLE_ITEM = _.Msg.VARIABLES_DEFAULT_NAME, _.Msg.PROCEDURES_DEFRETURN_COMMENT = _.Msg.PROCEDURES_DEFNORETURN_COMMENT, _.Msg.PROCEDURES_DEFRETURN_DO = _.Msg.PROCEDURES_DEFNORETURN_DO, _.Msg.PROCEDURES_DEFRETURN_PROCEDURE = _.Msg.PROCEDURES_DEFNORETURN_PROCEDURE, _.Msg.PROCEDURES_DEFRETURN_TITLE = _.Msg.PROCEDURES_DEFNORETURN_TITLE, _.Msg.TEXT_APPEND_VARIABLE = _.Msg.VARIABLES_DEFAULT_NAME, _.Msg.TEXT_CREATE_JOIN_ITEM_TITLE_ITEM = _.Msg.VARIABLES_DEFAULT_NAME, _.Msg.COLOUR_HUE = "20", _.Msg.LISTS_HUE = "260", _.Msg.LOGIC_HUE = "210", _.Msg.LOOPS_HUE = "120", _.Msg.MATH_HUE = "230", _.Msg.PROCEDURES_HUE = "290", _.Msg.TEXTS_HUE = "160", _.Msg.VARIABLES_DYNAMIC_HUE = "310", _.Msg.VARIABLES_HUE = "330", _.Msg;
    });
  })(b)), b.exports;
}
var vi = Gi();
const Xi = /* @__PURE__ */ r_(vi), {
  LOGIC_HUE: Vi,
  LOOPS_HUE: $i,
  MATH_HUE: ki,
  TEXTS_HUE: xi,
  LISTS_HUE: Yi,
  COLOUR_HUE: Ki,
  VARIABLES_HUE: wi,
  VARIABLES_DYNAMIC_HUE: yi,
  PROCEDURES_HUE: Wi,
  VARIABLES_DEFAULT_NAME: bi,
  UNNAMED_KEY: ji,
  TODAY: Ji,
  DUPLICATE_BLOCK: qi,
  ADD_COMMENT: zi,
  REMOVE_COMMENT: Qi,
  DUPLICATE_COMMENT: Zi,
  EXTERNAL_INPUTS: _s,
  INLINE_INPUTS: Ts,
  DELETE_BLOCK: Es,
  DELETE_X_BLOCKS: es,
  DELETE_ALL_BLOCKS: ts,
  CLEAN_UP: Os,
  CLOSE: Ls,
  COLLAPSE_BLOCK: Is,
  COLLAPSE_ALL: As,
  EXPAND_BLOCK: Ns,
  EXPAND_ALL: Rs,
  DISABLE_BLOCK: ns,
  ENABLE_BLOCK: rs,
  HELP: is,
  UNDO: ss,
  REDO: Ss,
  CHANGE_VALUE_TITLE: os,
  RENAME_VARIABLE: Ms,
  RENAME_VARIABLE_TITLE: Cs,
  NEW_VARIABLE: Ps,
  NEW_STRING_VARIABLE: as,
  NEW_NUMBER_VARIABLE: ls,
  NEW_COLOUR_VARIABLE: us,
  NEW_VARIABLE_TYPE_TITLE: Us,
  NEW_VARIABLE_TITLE: cs,
  VARIABLE_ALREADY_EXISTS: Ds,
  VARIABLE_ALREADY_EXISTS_FOR_ANOTHER_TYPE: ds,
  VARIABLE_ALREADY_EXISTS_FOR_A_PARAMETER: gs,
  DELETE_VARIABLE_CONFIRMATION: Hs,
  CANNOT_DELETE_VARIABLE_PROCEDURE: Bs,
  DELETE_VARIABLE: Fs,
  COLOUR_PICKER_HELPURL: ms,
  COLOUR_PICKER_TOOLTIP: hs,
  COLOUR_RANDOM_HELPURL: ps,
  COLOUR_RANDOM_TITLE: fs,
  COLOUR_RANDOM_TOOLTIP: Gs,
  COLOUR_RGB_HELPURL: vs,
  COLOUR_RGB_TITLE: Xs,
  COLOUR_RGB_RED: Vs,
  COLOUR_RGB_GREEN: $s,
  COLOUR_RGB_BLUE: ks,
  COLOUR_RGB_TOOLTIP: xs,
  COLOUR_BLEND_HELPURL: Ys,
  COLOUR_BLEND_TITLE: Ks,
  COLOUR_BLEND_COLOUR1: ws,
  COLOUR_BLEND_COLOUR2: ys,
  COLOUR_BLEND_RATIO: Ws,
  COLOUR_BLEND_TOOLTIP: bs,
  CONTROLS_REPEAT_HELPURL: js,
  CONTROLS_REPEAT_TITLE: Js,
  CONTROLS_REPEAT_INPUT_DO: qs,
  CONTROLS_REPEAT_TOOLTIP: zs,
  CONTROLS_WHILEUNTIL_HELPURL: Qs,
  CONTROLS_WHILEUNTIL_INPUT_DO: Zs,
  CONTROLS_WHILEUNTIL_OPERATOR_WHILE: _S,
  CONTROLS_WHILEUNTIL_OPERATOR_UNTIL: TS,
  CONTROLS_WHILEUNTIL_TOOLTIP_WHILE: ES,
  CONTROLS_WHILEUNTIL_TOOLTIP_UNTIL: eS,
  CONTROLS_FOR_HELPURL: tS,
  CONTROLS_FOR_TOOLTIP: OS,
  CONTROLS_FOR_TITLE: LS,
  CONTROLS_FOR_INPUT_DO: IS,
  CONTROLS_FOREACH_HELPURL: AS,
  CONTROLS_FOREACH_TITLE: NS,
  CONTROLS_FOREACH_INPUT_DO: RS,
  CONTROLS_FOREACH_TOOLTIP: nS,
  CONTROLS_FLOW_STATEMENTS_HELPURL: rS,
  CONTROLS_FLOW_STATEMENTS_OPERATOR_BREAK: iS,
  CONTROLS_FLOW_STATEMENTS_OPERATOR_CONTINUE: sS,
  CONTROLS_FLOW_STATEMENTS_TOOLTIP_BREAK: SS,
  CONTROLS_FLOW_STATEMENTS_TOOLTIP_CONTINUE: oS,
  CONTROLS_FLOW_STATEMENTS_WARNING: MS,
  CONTROLS_IF_HELPURL: CS,
  CONTROLS_IF_TOOLTIP_1: PS,
  CONTROLS_IF_TOOLTIP_2: aS,
  CONTROLS_IF_TOOLTIP_3: lS,
  CONTROLS_IF_TOOLTIP_4: uS,
  CONTROLS_IF_MSG_IF: US,
  CONTROLS_IF_MSG_ELSEIF: cS,
  CONTROLS_IF_MSG_ELSE: DS,
  CONTROLS_IF_MSG_THEN: dS,
  CONTROLS_IF_IF_TITLE_IF: gS,
  CONTROLS_IF_IF_TOOLTIP: HS,
  CONTROLS_IF_ELSEIF_TITLE_ELSEIF: BS,
  CONTROLS_IF_ELSEIF_TOOLTIP: FS,
  CONTROLS_IF_ELSE_TITLE_ELSE: mS,
  CONTROLS_IF_ELSE_TOOLTIP: hS,
  LOGIC_COMPARE_HELPURL: pS,
  LOGIC_COMPARE_EQ_ARIA: fS,
  LOGIC_COMPARE_TOOLTIP_EQ: GS,
  LOGIC_COMPARE_NEQ_ARIA: vS,
  LOGIC_COMPARE_TOOLTIP_NEQ: XS,
  LOGIC_COMPARE_LT_ARIA: VS,
  LOGIC_COMPARE_TOOLTIP_LT: $S,
  LOGIC_COMPARE_LTE_ARIA: kS,
  LOGIC_COMPARE_TOOLTIP_LTE: xS,
  LOGIC_COMPARE_GT_ARIA: YS,
  LOGIC_COMPARE_TOOLTIP_GT: KS,
  LOGIC_COMPARE_GTE_ARIA: wS,
  LOGIC_COMPARE_TOOLTIP_GTE: yS,
  LOGIC_OPERATION_HELPURL: WS,
  LOGIC_OPERATION_TOOLTIP_AND: bS,
  LOGIC_OPERATION_AND: jS,
  LOGIC_OPERATION_TOOLTIP_OR: JS,
  LOGIC_OPERATION_OR: qS,
  LOGIC_NEGATE_HELPURL: zS,
  LOGIC_NEGATE_TITLE: QS,
  LOGIC_NEGATE_TOOLTIP: ZS,
  LOGIC_BOOLEAN_HELPURL: _o,
  LOGIC_BOOLEAN_TRUE: To,
  LOGIC_BOOLEAN_FALSE: Eo,
  LOGIC_BOOLEAN_TOOLTIP: eo,
  LOGIC_NULL_HELPURL: to,
  LOGIC_NULL: Oo,
  LOGIC_NULL_TOOLTIP: Lo,
  LOGIC_TERNARY_HELPURL: Io,
  LOGIC_TERNARY_CONDITION: Ao,
  LOGIC_TERNARY_IF_TRUE: No,
  LOGIC_TERNARY_IF_FALSE: Ro,
  LOGIC_TERNARY_TOOLTIP: no,
  MATH_NUMBER_HELPURL: ro,
  MATH_NUMBER_TOOLTIP: io,
  MATH_ADDITION_SYMBOL: so,
  MATH_ADDITION_SYMBOL_ARIA: So,
  MATH_SUBTRACTION_SYMBOL: oo,
  MATH_SUBTRACTION_SYMBOL_ARIA: Mo,
  MATH_DIVISION_SYMBOL: Co,
  MATH_DIVISION_SYMBOL_ARIA: Po,
  MATH_MULTIPLICATION_SYMBOL: ao,
  MATH_MULTIPLICATION_SYMBOL_ARIA: lo,
  MATH_POWER_SYMBOL: uo,
  MATH_POWER_SYMBOL_ARIA: Uo,
  MATH_TRIG_SIN: co,
  MATH_TRIG_SIN_ARIA: Do,
  MATH_TRIG_COS: go,
  MATH_TRIG_COS_ARIA: Ho,
  MATH_TRIG_TAN: Bo,
  MATH_TRIG_TAN_ARIA: Fo,
  MATH_TRIG_ASIN: mo,
  MATH_TRIG_ASIN_ARIA: ho,
  MATH_TRIG_ACOS: po,
  MATH_TRIG_ACOS_ARIA: fo,
  MATH_TRIG_ATAN: Go,
  MATH_TRIG_ATAN_ARIA: vo,
  MATH_CONSTANT_PI_ARIA: Xo,
  MATH_CONSTANT_E_ARIA: Vo,
  MATH_CONSTANT_GOLDEN_RATIO_ARIA: $o,
  MATH_CONSTANT_SQRT2_ARIA: ko,
  MATH_CONSTANT_SQRT1_2_ARIA: xo,
  MATH_CONSTANT_INFINITY_ARIA: Yo,
  MATH_ARITHMETIC_HELPURL: Ko,
  MATH_ARITHMETIC_TOOLTIP_ADD: wo,
  MATH_ARITHMETIC_TOOLTIP_MINUS: yo,
  MATH_ARITHMETIC_TOOLTIP_MULTIPLY: Wo,
  MATH_ARITHMETIC_TOOLTIP_DIVIDE: bo,
  MATH_ARITHMETIC_TOOLTIP_POWER: jo,
  MATH_SINGLE_HELPURL: Jo,
  MATH_SINGLE_OP_ROOT: qo,
  MATH_SINGLE_TOOLTIP_ROOT: zo,
  MATH_SINGLE_OP_ABSOLUTE: Qo,
  MATH_SINGLE_OP_ABSOLUTE_ARIA: Zo,
  MATH_SINGLE_TOOLTIP_ABS: _M,
  MATH_SINGLE_OP_NEG_ARIA: TM,
  MATH_SINGLE_OP_LN_ARIA: EM,
  MATH_SINGLE_OP_LOG10_ARIA: eM,
  MATH_SINGLE_OP_EXP_ARIA: tM,
  MATH_SINGLE_OP_POW10_ARIA: OM,
  MATH_SINGLE_TOOLTIP_NEG: LM,
  MATH_SINGLE_TOOLTIP_LN: IM,
  MATH_SINGLE_TOOLTIP_LOG10: AM,
  MATH_SINGLE_TOOLTIP_EXP: NM,
  MATH_SINGLE_TOOLTIP_POW10: RM,
  MATH_TRIG_HELPURL: nM,
  MATH_TRIG_TOOLTIP_SIN: rM,
  MATH_TRIG_TOOLTIP_COS: iM,
  MATH_TRIG_TOOLTIP_TAN: sM,
  MATH_TRIG_TOOLTIP_ASIN: SM,
  MATH_TRIG_TOOLTIP_ACOS: oM,
  MATH_TRIG_TOOLTIP_ATAN: MM,
  MATH_CONSTANT_HELPURL: CM,
  MATH_CONSTANT_TOOLTIP: PM,
  MATH_IS_EVEN: aM,
  MATH_IS_ODD: lM,
  MATH_IS_PRIME: uM,
  MATH_IS_WHOLE: UM,
  MATH_IS_POSITIVE: cM,
  MATH_IS_NEGATIVE: DM,
  MATH_IS_DIVISIBLE_BY: dM,
  MATH_IS_TOOLTIP: gM,
  MATH_CHANGE_HELPURL: HM,
  MATH_CHANGE_TITLE: BM,
  MATH_CHANGE_TITLE_ITEM: FM,
  MATH_CHANGE_TOOLTIP: mM,
  MATH_ROUND_HELPURL: hM,
  MATH_ROUND_TOOLTIP: pM,
  MATH_ROUND_OPERATOR_ROUND: fM,
  MATH_ROUND_OPERATOR_ROUNDUP: GM,
  MATH_ROUND_OPERATOR_ROUNDDOWN: vM,
  MATH_ONLIST_HELPURL: XM,
  MATH_ONLIST_OPERATOR_SUM: VM,
  MATH_ONLIST_TOOLTIP_SUM: $M,
  MATH_ONLIST_OPERATOR_MIN: kM,
  MATH_ONLIST_OPERATOR_MIN_ARIA: xM,
  MATH_ONLIST_TOOLTIP_MIN: YM,
  MATH_ONLIST_OPERATOR_MAX: KM,
  MATH_ONLIST_OPERATOR_MAX_ARIA: wM,
  MATH_ONLIST_TOOLTIP_MAX: yM,
  MATH_ONLIST_OPERATOR_AVERAGE: WM,
  MATH_ONLIST_TOOLTIP_AVERAGE: bM,
  MATH_ONLIST_OPERATOR_MEDIAN: jM,
  MATH_ONLIST_TOOLTIP_MEDIAN: JM,
  MATH_ONLIST_OPERATOR_MODE: qM,
  MATH_ONLIST_TOOLTIP_MODE: zM,
  MATH_ONLIST_OPERATOR_STD_DEV: QM,
  MATH_ONLIST_TOOLTIP_STD_DEV: ZM,
  MATH_ONLIST_OPERATOR_RANDOM: _C,
  MATH_ONLIST_TOOLTIP_RANDOM: TC,
  MATH_MODULO_HELPURL: EC,
  MATH_MODULO_TITLE: eC,
  MATH_MODULO_TOOLTIP: tC,
  MATH_CONSTRAIN_HELPURL: OC,
  MATH_CONSTRAIN_TITLE: LC,
  MATH_CONSTRAIN_TOOLTIP: IC,
  MATH_RANDOM_INT_HELPURL: AC,
  MATH_RANDOM_INT_TITLE: NC,
  MATH_RANDOM_INT_TOOLTIP: RC,
  MATH_RANDOM_FLOAT_HELPURL: nC,
  MATH_RANDOM_FLOAT_TITLE_RANDOM: rC,
  MATH_RANDOM_FLOAT_TOOLTIP: iC,
  MATH_ATAN2_HELPURL: sC,
  MATH_ATAN2_TITLE: SC,
  MATH_ATAN2_TOOLTIP: oC,
  TEXT_TEXT_HELPURL: MC,
  TEXT_TEXT_TOOLTIP: CC,
  TEXT_JOIN_HELPURL: PC,
  TEXT_JOIN_TITLE_CREATEWITH: aC,
  TEXT_JOIN_TOOLTIP: lC,
  TEXT_CREATE_JOIN_TITLE_JOIN: uC,
  TEXT_CREATE_JOIN_TOOLTIP: UC,
  TEXT_CREATE_JOIN_ITEM_TITLE_ITEM: cC,
  TEXT_CREATE_JOIN_ITEM_TOOLTIP: DC,
  TEXT_APPEND_HELPURL: dC,
  TEXT_APPEND_TITLE: gC,
  TEXT_APPEND_VARIABLE: HC,
  TEXT_APPEND_TOOLTIP: BC,
  TEXT_LENGTH_HELPURL: FC,
  TEXT_LENGTH_TITLE: mC,
  TEXT_LENGTH_TOOLTIP: hC,
  TEXT_ISEMPTY_HELPURL: pC,
  TEXT_ISEMPTY_TITLE: fC,
  TEXT_ISEMPTY_TOOLTIP: GC,
  TEXT_INDEXOF_HELPURL: vC,
  TEXT_INDEXOF_TOOLTIP: XC,
  TEXT_INDEXOF_TITLE: VC,
  TEXT_INDEXOF_OPERATOR_FIRST: $C,
  TEXT_INDEXOF_OPERATOR_LAST: kC,
  TEXT_FROM_START_ARIA: xC,
  TEXT_FROM_END_ARIA: YC,
  TEXT_CHARAT_HELPURL: KC,
  TEXT_CHARAT_TITLE: wC,
  TEXT_CHARAT_FROM_START: yC,
  TEXT_CHARAT_FROM_END: WC,
  TEXT_CHARAT_FIRST: bC,
  TEXT_CHARAT_LAST: jC,
  TEXT_CHARAT_RANDOM: JC,
  TEXT_CHARAT_TAIL: qC,
  TEXT_CHARAT_TOOLTIP: zC,
  TEXT_GET_SUBSTRING_TOOLTIP: QC,
  TEXT_GET_SUBSTRING_HELPURL: ZC,
  TEXT_GET_SUBSTRING_INPUT_IN_TEXT: _P,
  TEXT_GET_SUBSTRING_START_FROM_START: TP,
  TEXT_GET_SUBSTRING_START_FROM_END: EP,
  TEXT_GET_SUBSTRING_START_FIRST: eP,
  TEXT_GET_SUBSTRING_END_FROM_START: tP,
  TEXT_GET_SUBSTRING_END_FROM_END: OP,
  TEXT_GET_SUBSTRING_END_LAST: LP,
  TEXT_GET_SUBSTRING_TAIL: IP,
  TEXT_CHANGECASE_HELPURL: AP,
  TEXT_CHANGECASE_TOOLTIP: NP,
  TEXT_CHANGECASE_OPERATOR_UPPERCASE: RP,
  TEXT_CHANGECASE_OPERATOR_LOWERCASE: nP,
  TEXT_CHANGECASE_OPERATOR_TITLECASE: rP,
  TEXT_TRIM_HELPURL: iP,
  TEXT_TRIM_TOOLTIP: sP,
  TEXT_TRIM_OPERATOR_BOTH: SP,
  TEXT_TRIM_OPERATOR_LEFT: oP,
  TEXT_TRIM_OPERATOR_RIGHT: MP,
  TEXT_PRINT_HELPURL: CP,
  TEXT_PRINT_TITLE: PP,
  TEXT_PRINT_TOOLTIP: aP,
  TEXT_PROMPT_HELPURL: lP,
  TEXT_PROMPT_TYPE_TEXT: uP,
  TEXT_PROMPT_TYPE_NUMBER: UP,
  TEXT_PROMPT_TOOLTIP_NUMBER: cP,
  TEXT_PROMPT_TOOLTIP_TEXT: DP,
  TEXT_COUNT_MESSAGE0: dP,
  TEXT_COUNT_HELPURL: gP,
  TEXT_COUNT_TOOLTIP: HP,
  TEXT_REPLACE_MESSAGE0: BP,
  TEXT_REPLACE_HELPURL: FP,
  TEXT_REPLACE_TOOLTIP: mP,
  TEXT_REVERSE_MESSAGE0: hP,
  TEXT_REVERSE_HELPURL: pP,
  TEXT_REVERSE_TOOLTIP: fP,
  LISTS_CREATE_EMPTY_HELPURL: GP,
  LISTS_CREATE_EMPTY_TITLE: vP,
  LISTS_CREATE_EMPTY_TOOLTIP: XP,
  LISTS_CREATE_WITH_HELPURL: VP,
  LISTS_CREATE_WITH_TOOLTIP: $P,
  LISTS_CREATE_WITH_INPUT_WITH: kP,
  LISTS_CREATE_WITH_CONTAINER_TITLE_ADD: xP,
  LISTS_CREATE_WITH_CONTAINER_TOOLTIP: YP,
  LISTS_CREATE_WITH_ITEM_TITLE: KP,
  LISTS_CREATE_WITH_ITEM_TOOLTIP: wP,
  LISTS_REPEAT_HELPURL: yP,
  LISTS_REPEAT_TOOLTIP: WP,
  LISTS_REPEAT_TITLE: bP,
  LISTS_LENGTH_HELPURL: jP,
  LISTS_LENGTH_TITLE: JP,
  LISTS_LENGTH_TOOLTIP: qP,
  LISTS_ISEMPTY_HELPURL: zP,
  LISTS_ISEMPTY_TITLE: QP,
  LISTS_ISEMPTY_TOOLTIP: ZP,
  LISTS_INLIST: _a,
  LISTS_INDEX_OF_HELPURL: Ta,
  LISTS_INDEX_OF_INPUT_IN_LIST: Ea,
  LISTS_INDEX_OF_FIRST: ea,
  LISTS_INDEX_OF_LAST: ta,
  LISTS_INDEX_OF_TOOLTIP: Oa,
  LISTS_GET_INDEX_HELPURL: La,
  LISTS_GET_INDEX_GET: Ia,
  LISTS_GET_INDEX_GET_REMOVE: Aa,
  LISTS_GET_INDEX_REMOVE: Na,
  LISTS_GET_INDEX_FROM_START: Ra,
  LISTS_GET_INDEX_FROM_END: na,
  LISTS_GET_INDEX_FIRST: ra,
  LISTS_GET_INDEX_LAST: ia,
  LISTS_GET_INDEX_RANDOM: sa,
  LISTS_GET_INDEX_TAIL: Sa,
  LISTS_GET_INDEX_INPUT_IN_LIST: oa,
  LISTS_INDEX_FROM_START_TOOLTIP: Ma,
  LISTS_INDEX_FROM_END_TOOLTIP: Ca,
  LISTS_GET_INDEX_TOOLTIP_GET_FROM: Pa,
  LISTS_GET_INDEX_TOOLTIP_GET_FIRST: aa,
  LISTS_GET_INDEX_TOOLTIP_GET_LAST: la,
  LISTS_GET_INDEX_TOOLTIP_GET_RANDOM: ua,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_FROM: Ua,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_FIRST: ca,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_LAST: Da,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_RANDOM: da,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_FROM: ga,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_FIRST: Ha,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_LAST: Ba,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_RANDOM: Fa,
  LISTS_SET_INDEX_HELPURL: ma,
  LISTS_SET_INDEX_INPUT_IN_LIST: ha,
  LISTS_SET_INDEX_SET: pa,
  LISTS_SET_INDEX_INSERT: fa,
  LISTS_SET_INDEX_INPUT_TO: Ga,
  LISTS_SET_INDEX_TOOLTIP_SET_FROM: va,
  LISTS_SET_INDEX_TOOLTIP_SET_FIRST: Xa,
  LISTS_SET_INDEX_TOOLTIP_SET_LAST: Va,
  LISTS_SET_INDEX_TOOLTIP_SET_RANDOM: $a,
  LISTS_SET_INDEX_TOOLTIP_INSERT_FROM: ka,
  LISTS_SET_INDEX_TOOLTIP_INSERT_FIRST: xa,
  LISTS_SET_INDEX_TOOLTIP_INSERT_LAST: Ya,
  LISTS_SET_INDEX_TOOLTIP_INSERT_RANDOM: Ka,
  LISTS_GET_SUBLIST_HELPURL: wa,
  LISTS_GET_SUBLIST_INPUT_IN_LIST: ya,
  LISTS_GET_SUBLIST_START_FROM_START: Wa,
  LISTS_GET_SUBLIST_START_FROM_END: ba,
  LISTS_GET_SUBLIST_START_FIRST: ja,
  LISTS_GET_SUBLIST_END_FROM_START: Ja,
  LISTS_GET_SUBLIST_END_FROM_END: qa,
  LISTS_GET_SUBLIST_END_LAST: za,
  LISTS_GET_SUBLIST_TAIL: Qa,
  LISTS_GET_SUBLIST_TOOLTIP: Za,
  LISTS_SORT_HELPURL: _l,
  LISTS_SORT_TITLE: Tl,
  LISTS_SORT_TOOLTIP: El,
  LISTS_SORT_ORDER_ASCENDING: el,
  LISTS_SORT_ORDER_DESCENDING: tl,
  LISTS_SORT_TYPE_NUMERIC: Ol,
  LISTS_SORT_TYPE_TEXT: Ll,
  LISTS_SORT_TYPE_IGNORECASE: Il,
  LISTS_SPLIT_HELPURL: Al,
  LISTS_SPLIT_LIST_FROM_TEXT: Nl,
  LISTS_SPLIT_TEXT_FROM_LIST: Rl,
  LISTS_SPLIT_WITH_DELIMITER: nl,
  LISTS_SPLIT_TOOLTIP_SPLIT: rl,
  LISTS_SPLIT_TOOLTIP_JOIN: il,
  LISTS_REVERSE_HELPURL: sl,
  LISTS_REVERSE_MESSAGE0: Sl,
  LISTS_REVERSE_TOOLTIP: ol,
  ORDINAL_NUMBER_SUFFIX: Ml,
  VARIABLES_GET_HELPURL: Cl,
  VARIABLES_GET_TOOLTIP: Pl,
  VARIABLES_GET_CREATE_SET: al,
  VARIABLES_SET_HELPURL: ll,
  VARIABLES_SET: ul,
  VARIABLES_SET_TOOLTIP: Ul,
  VARIABLES_SET_CREATE_GET: cl,
  PROCEDURES_DEFNORETURN_HELPURL: Dl,
  PROCEDURES_DEFNORETURN_TITLE: dl,
  PROCEDURES_DEFNORETURN_PROCEDURE: gl,
  PROCEDURES_BEFORE_PARAMS: Hl,
  PROCEDURES_CALL_BEFORE_PARAMS: Bl,
  PROCEDURES_CALL_DISABLED_DEF_WARNING: Fl,
  PROCEDURES_DEFNORETURN_DO: ml,
  PROCEDURES_DEFNORETURN_TOOLTIP: hl,
  PROCEDURES_DEFNORETURN_COMMENT: pl,
  PROCEDURES_DEFRETURN_HELPURL: fl,
  PROCEDURES_DEFRETURN_TITLE: Gl,
  PROCEDURES_DEFRETURN_PROCEDURE: vl,
  PROCEDURES_DEFRETURN_DO: Xl,
  PROCEDURES_DEFRETURN_COMMENT: Vl,
  PROCEDURES_DEFRETURN_RETURN: $l,
  PROCEDURES_DEFRETURN_TOOLTIP: kl,
  PROCEDURES_ALLOW_STATEMENTS: xl,
  PROCEDURES_DEF_DUPLICATE_WARNING: Yl,
  PROCEDURES_CALLNORETURN_HELPURL: Kl,
  PROCEDURES_CALLNORETURN_TOOLTIP: wl,
  PROCEDURES_CALLRETURN_HELPURL: yl,
  PROCEDURES_CALLRETURN_TOOLTIP: Wl,
  PROCEDURES_MUTATORCONTAINER_TITLE: bl,
  PROCEDURES_MUTATORCONTAINER_TOOLTIP: jl,
  PROCEDURES_MUTATORARG_TITLE: Jl,
  PROCEDURES_MUTATORARG_TOOLTIP: ql,
  PROCEDURES_HIGHLIGHT_DEF: zl,
  PROCEDURES_CREATE_DO: Ql,
  PROCEDURES_IFRETURN_TOOLTIP: Zl,
  PROCEDURES_IFRETURN_HELPURL: _u,
  PROCEDURES_IFRETURN_WARNING: Tu,
  WORKSPACE_COMMENT_DEFAULT_TEXT: Eu,
  COLLAPSED_WARNINGS_WARNING: eu,
  DIALOG_OK: tu,
  DIALOG_CANCEL: Ou,
  EDIT_BLOCK_CONTENTS: Lu,
  MOVE_BLOCK: Iu,
  WINDOWS: Au,
  MAC_OS: Nu,
  CHROME_OS: Ru,
  LINUX: nu,
  UNKNOWN: ru,
  CONTROL_KEY: iu,
  COMMAND_KEY: su,
  OPTION_KEY: Su,
  ALT_KEY: ou,
  ENTER_KEY: Mu,
  BACKSPACE_KEY: Cu,
  DELETE_KEY: Pu,
  ESCAPE: au,
  TAB_KEY: lu,
  SHIFT_KEY: uu,
  CAPS_LOCK_KEY: Uu,
  SPACE_KEY: cu,
  PAGE_UP_KEY: Du,
  PAGE_DOWN_KEY: du,
  END_KEY: gu,
  HOME_KEY: Hu,
  INSERT_KEY: Bu,
  PAUSE_KEY: Fu,
  CONTEXT_MENU_KEY: mu,
  CUT_SHORTCUT: hu,
  COPY_SHORTCUT: pu,
  PASTE_SHORTCUT: fu,
  HELP_PROMPT: Gu,
  SHORTCUTS_GENERAL: vu,
  SHORTCUTS_EDITING: Xu,
  SHORTCUTS_CODE_NAVIGATION: Vu,
  SHORTCUTS_ESCAPE: $u,
  SHORTCUTS_DELETE: ku,
  SHORTCUTS_START_MOVE: xu,
  SHORTCUTS_START_MOVE_STACK: Yu,
  SHORTCUTS_MOVE_LEFT: Ku,
  SHORTCUTS_MOVE_RIGHT: wu,
  SHORTCUTS_MOVE_UP: yu,
  SHORTCUTS_MOVE_DOWN: Wu,
  SHORTCUTS_FINISH_MOVE: bu,
  SHORTCUTS_ABORT_MOVE: ju,
  SHORTCUTS_SHOW_CONTEXT_MENU: Ju,
  SHORTCUTS_FOCUS_WORKSPACE: qu,
  SHORTCUTS_FOCUS_TOOLBOX: zu,
  SHORTCUTS_INFORMATION: Qu,
  SHORTCUTS_EXTENDED_INFORMATION: Zu,
  SHORTCUTS_DISCONNECT: _U,
  SHORTCUTS_NEXT_STACK: TU,
  SHORTCUTS_PREVIOUS_STACK: EU,
  SHORTCUTS_NEXT_HEADING: eU,
  SHORTCUTS_PREVIOUS_HEADING: tU,
  SHORTCUTS_PERFORM_ACTION: OU,
  SHORTCUTS_DUPLICATE: LU,
  SHORTCUTS_CLEANUP: IU,
  SHORTCUTS_SHOW_TOOLTIP: AU,
  SHORTCUTS_TOGGLE_SCREENREADER_MODE: NU,
  SHORTCUTS_JUMP_BLOCK_START: RU,
  SHORTCUTS_JUMP_BLOCK_END: nU,
  SHORTCUTS_JUMP_TOP_STACK: rU,
  SHORTCUTS_JUMP_BOTTOM_STACK: iU,
  SHORTCUTS_JUMP_FIRST_BLOCK: sU,
  SHORTCUTS_JUMP_LAST_BLOCK: SU,
  SHORTCUTS_JUMP_PREVIOUS_PAGE: oU,
  SHORTCUTS_JUMP_NEXT_PAGE: MU,
  SHORTCUTS_SCROLL_LEFT: CU,
  SHORTCUTS_SCROLL_RIGHT: PU,
  SHORTCUTS_SCROLL_UP: aU,
  SHORTCUTS_SCROLL_DOWN: lU,
  ANNOUNCE_SCROLLED_LEFT: uU,
  ANNOUNCE_SCROLLED_RIGHT: UU,
  ANNOUNCE_SCROLLED_UP: cU,
  ANNOUNCE_SCROLLED_DOWN: DU,
  ANNOUNCE_CANT_SCROLL_FURTHER: dU,
  KEYBOARD_NAV_UNCONSTRAINED_MOVE_HINT: gU,
  KEYBOARD_NAV_CONSTRAINED_MOVE_HINT: HU,
  KEYBOARD_NAV_COPIED_HINT: BU,
  KEYBOARD_NAV_CUT_HINT: FU,
  WORKSPACE_LABEL_PLAIN: mU,
  WORKSPACE_ROLEDESCRIPTION: hU,
  WORKSPACE_LABEL_1_STACK: pU,
  WORKSPACE_LABEL_MANY_STACKS: fU,
  WORKSPACE_LABEL_MUTATOR_WORKSPACE: GU,
  WORKSPACE_LABEL_FLYOUT_WORKSPACE: vU,
  WORKSPACE_CONTENTS_BLOCKS_MANY: XU,
  WORKSPACE_CONTENTS_BLOCKS_ONE: VU,
  WORKSPACE_CONTENTS_BLOCKS_ZERO: $U,
  WORKSPACE_CONTENTS_COMMENTS_MANY: kU,
  WORKSPACE_CONTENTS_COMMENTS_ONE: xU,
  KEYBOARD_NAV_BLOCK_NAVIGATION_HINT: YU,
  KEYBOARD_NAV_WORKSPACE_NAVIGATION_HINT: KU,
  KEYBOARD_NAV_FLYOUT_LABEL_HINT: wU,
  BLOCK_LABEL_BEGIN_STACK: yU,
  BLOCK_LABEL_BEGIN_PREFIX: WU,
  BLOCK_LABEL_TOOLBOX_CATEGORY: bU,
  BLOCK_LABEL_DISABLED: jU,
  BLOCK_LABEL_COLLAPSED: JU,
  BLOCK_LABEL_REPLACEABLE: qU,
  BLOCK_LABEL_HAS_INPUT: zU,
  BLOCK_LABEL_HAS_INPUTS: QU,
  BLOCK_LABEL_HAS_BRANCHES: ZU,
  BLOCK_LABEL_STATEMENT: _c,
  BLOCK_LABEL_CONTAINER: Tc,
  BLOCK_LABEL_VALUE: Ec,
  BLOCK_LABEL_STACK_BLOCKS: ec,
  INPUT_LABEL_INDEX: tc,
  INPUT_LABEL_VALUE: Oc,
  INPUT_LABEL_STATEMENT: Lc,
  INPUT_LABEL_END_STATEMENT: Ic,
  INPUT_LABEL_EMPTY: Ac,
  INPUT_LABEL_CONDITION: Nc,
  INPUT_LABEL_CONDITION_A: Rc,
  INPUT_LABEL_CONDITION_B: nc,
  INPUT_LABEL_VALUE_A: rc,
  INPUT_LABEL_VALUE_B: ic,
  INPUT_LABEL_NUMBER: sc,
  INPUT_LABEL_NUMBER_A: Sc,
  INPUT_LABEL_NUMBER_B: oc,
  INPUT_LABEL_NUMBER_TO_CHECK: Mc,
  INPUT_LABEL_NUMBER_LIST: Cc,
  INPUT_LABEL_MATH_DIVIDEND: Pc,
  INPUT_LABEL_MATH_DIVISOR: ac,
  INPUT_LABEL_MATH_CHANGE_BY: lc,
  INPUT_LABEL_MATH_CONSTRAIN_VALUE: uc,
  INPUT_LABEL_NUMBER_MIN: Uc,
  INPUT_LABEL_NUMBER_MAX: cc,
  INPUT_LABEL_NUMBER_ATAN2_X: Dc,
  INPUT_LABEL_NUMBER_ATAN2_Y: dc,
  INPUT_LABEL_LOOP_TIMES: gc,
  INPUT_LABEL_LOOP_FROM: Hc,
  INPUT_LABEL_LOOP_TO: Bc,
  INPUT_LABEL_LOOP_BY: Fc,
  INPUT_LABEL_LOOP_LIST: mc,
  INPUT_LABEL_TEXT_JOIN_ITEM: hc,
  INPUT_LABEL_TEXT_APPEND: pc,
  INPUT_LABEL_TEXT_TO_CHANGE: fc,
  INPUT_LABEL_TEXT_TO_CHECK: Gc,
  INPUT_LABEL_TEXT_TO_FIND: vc,
  INPUT_LABEL_TEXT_TO_REPLACE: Xc,
  INPUT_LABEL_TEXT_POSITION: Vc,
  INPUT_LABEL_TEXT_START_POSITION: $c,
  INPUT_LABEL_TEXT_END_POSITION: kc,
  INPUT_LABEL_TEXT_PROMPT_MESSAGE: xc,
  INPUT_LABEL_VARIABLES_SET: Yc,
  INPUT_LABEL_LISTS_CREATE_WITH_ITEM: Kc,
  INPUT_LABEL_LISTS_REPEAT_ITEM: wc,
  INPUT_LABEL_LISTS_REPEAT_NUM: yc,
  INPUT_LABEL_LISTS_TO_CHECK: Wc,
  INPUT_LABEL_LISTS_VALUE_TO_SET: bc,
  INPUT_LABEL_LISTS_POSITION: jc,
  INPUT_LABEL_LISTS_START_POSITION: Jc,
  INPUT_LABEL_LISTS_END_POSITION: qc,
  INPUT_LABEL_LISTS_LIST_FROM_TEXT: zc,
  INPUT_LABEL_LISTS_TEXT_FROM_LIST: Qc,
  INPUT_LABEL_LISTS_DELIMITER: Zc,
  INPUT_LABEL_LISTS_TO_CHANGE: _D,
  ANNOUNCE_MOVE_WORKSPACE: TD,
  ANNOUNCE_MOVE_BEFORE: ED,
  ANNOUNCE_MOVE_AFTER: eD,
  ANNOUNCE_MOVE_INSIDE: tD,
  ANNOUNCE_MOVE_AROUND: OD,
  ANNOUNCE_MOVE_TO: LD,
  ANNOUNCE_MOVE_OF: ID,
  ANNOUNCE_MOVE_CANCELED: AD,
  FIELD_LABEL_EMPTY: ND,
  ARIA_TYPE_FIELD_INPUT: RD,
  ARIA_TYPE_FIELD_TEXT_INPUT: nD,
  ARIA_TYPE_FIELD_NUMBER: rD,
  ARIA_TYPE_FIELD_TEXT_INPUT_PROCEDURE: iD,
  ARIA_TYPE_FIELD_TEXT_INPUT_ARGUMENT: sD,
  ARIA_TYPE_FIELD_DROPDOWN: SD,
  ARIA_TYPE_FIELD_IMAGE: oD,
  ARIA_TYPE_FIELD_CHECKBOX: MD,
  FIELD_LABEL_EDIT_PREFIX: CD,
  OPEN_TRASH: PD,
  ZOOM_IN: aD,
  ZOOM_OUT: lD,
  RESET_ZOOM: uD,
  FIELD_LABEL_OPTION_INDEX: UD,
  FIELD_LABEL_CHECKBOX_CHECKED: cD,
  FIELD_LABEL_CHECKBOX_UNCHECKED: DD,
  FIELD_LABEL_VARIABLE: dD,
  ARIA_LABEL_BUTTON: gD,
  ARIA_LABEL_HEADING: HD,
  BUBBLE_LABEL_DEFAULT: BD,
  BUBBLE_LABEL_COMMENT: FD,
  BUBBLE_LABEL_WARNING: mD,
  ICON_LABEL_DEFAULT: hD,
  ICON_LABEL_COMMENT_CLOSED: pD,
  ICON_LABEL_COMMENT_OPEN: fD,
  ICON_LABEL_MUTATOR_CLOSED: GD,
  ICON_LABEL_MUTATOR_OPEN: vD,
  ICON_LABEL_WARNING_CLOSED: XD,
  ICON_LABEL_WARNING_OPEN: VD,
  ARIA_LABEL_COMMENT: $D,
  ARIA_LABEL_COMMENT_COLLAPSE: kD,
  ARIA_LABEL_COMMENT_EXPAND: xD,
  SCREENREADER_MODE_ENABLED: YD,
  SCREENREADER_MODE_DISABLED: KD,
  CURRENT_BLOCK_ANNOUNCEMENT: wD,
  PARENT_BLOCKS_ANNOUNCEMENT: yD,
  NO_PARENT_ANNOUNCEMENT: WD,
  SCREENREADER_HINT: bD,
  ARIA_LABEL_ADD_ELSE_IF: jD,
  ARIA_LABEL_REMOVE_ELSE_IF: JD,
  ARIA_LABEL_ADD_LIST_ITEM: qD,
  ARIA_LABEL_REMOVE_LIST_ITEM: zD,
  ARIA_LABEL_ADD_TEXT: QD,
  ARIA_LABEL_REMOVE_TEXT: ZD,
  ARIA_LABEL_ADD_INPUT: _d,
  ARIA_LABEL_REMOVE_INPUT: Td,
  ARIA_TYPE_FIELD_ANGLE: Ed,
  ARIA_LABEL_FIELD_ANGLE: ed,
  ARIA_TYPE_FIELD_DATE: td,
  ARIA_TYPE_FIELD_COLOUR: Od,
  ARIA_TYPE_FIELD_BITMAP: Ld,
  ARIA_TYPE_FIELD_GRID: Id,
  FIELD_BITMAP_BUTTON_LABEL_RANDOMIZE: Ad,
  FIELD_BITMAP_BUTTON_LABEL_CLEAR: Nd,
  FIELD_BITMAP_PIXEL_ON: Rd,
  FIELD_BITMAP_PIXEL_OFF: nd,
  FIELD_BITMAP_PIXEL_LABEL: rd,
  FIELD_BITMAP_ARIA_VALUE: id,
  OPEN_BACKPACK: sd,
  CLOSE_BACKPACK: Sd,
  COPY_ALL_TO_BACKPACK: od,
  COPY_TO_BACKPACK: Md,
  EMPTY_BACKPACK: Cd,
  PASTE_ALL_FROM_BACKPACK: Pd,
  REMOVE_FROM_BACKPACK: ad,
  FIELD_MULTILINEINPUT_FINISH_EDITING: ld,
  FIELD_MULTILINEINPUT_NEW_LINE: ud,
  ZOOM_TO_FIT_ARIA_LABEL: Ud,
  MINIMAP_ARIA_LABEL: cd,
  ARIA_LABEL_TRASH_EMPTY: Dd,
  WORKSPACE_SEARCH_PLACEHOLDER: dd,
  WORKSPACE_SEARCH_INPUT_LABEL: gd,
  WORKSPACE_SEARCH_FIND_NEXT: Hd,
  WORKSPACE_SEARCH_FIND_PREVIOUS: Bd,
  WORKSPACE_SEARCH_CLOSE: Fd,
  WORKSPACE_SEARCH_NO_MATCHES: md,
  WORKSPACE_SEARCH_MATCH: hd,
  TOOLBOX_SEARCH_PLACEHOLDER: pd,
  TOOLBOX_SEARCH_PROMPT: fd,
  TOOLBOX_SEARCH_NO_RESULTS: Gd,
  TOOLBOX_SEARCH_RESULT_COUNT_ONE: vd,
  TOOLBOX_SEARCH_RESULT_COUNT: Xd
} = Xi, Vd = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ADD_COMMENT: zi,
  ALT_KEY: ou,
  ANNOUNCE_CANT_SCROLL_FURTHER: dU,
  ANNOUNCE_MOVE_AFTER: eD,
  ANNOUNCE_MOVE_AROUND: OD,
  ANNOUNCE_MOVE_BEFORE: ED,
  ANNOUNCE_MOVE_CANCELED: AD,
  ANNOUNCE_MOVE_INSIDE: tD,
  ANNOUNCE_MOVE_OF: ID,
  ANNOUNCE_MOVE_TO: LD,
  ANNOUNCE_MOVE_WORKSPACE: TD,
  ANNOUNCE_SCROLLED_DOWN: DU,
  ANNOUNCE_SCROLLED_LEFT: uU,
  ANNOUNCE_SCROLLED_RIGHT: UU,
  ANNOUNCE_SCROLLED_UP: cU,
  ARIA_LABEL_ADD_ELSE_IF: jD,
  ARIA_LABEL_ADD_INPUT: _d,
  ARIA_LABEL_ADD_LIST_ITEM: qD,
  ARIA_LABEL_ADD_TEXT: QD,
  ARIA_LABEL_BUTTON: gD,
  ARIA_LABEL_COMMENT: $D,
  ARIA_LABEL_COMMENT_COLLAPSE: kD,
  ARIA_LABEL_COMMENT_EXPAND: xD,
  ARIA_LABEL_FIELD_ANGLE: ed,
  ARIA_LABEL_HEADING: HD,
  ARIA_LABEL_REMOVE_ELSE_IF: JD,
  ARIA_LABEL_REMOVE_INPUT: Td,
  ARIA_LABEL_REMOVE_LIST_ITEM: zD,
  ARIA_LABEL_REMOVE_TEXT: ZD,
  ARIA_LABEL_TRASH_EMPTY: Dd,
  ARIA_TYPE_FIELD_ANGLE: Ed,
  ARIA_TYPE_FIELD_BITMAP: Ld,
  ARIA_TYPE_FIELD_CHECKBOX: MD,
  ARIA_TYPE_FIELD_COLOUR: Od,
  ARIA_TYPE_FIELD_DATE: td,
  ARIA_TYPE_FIELD_DROPDOWN: SD,
  ARIA_TYPE_FIELD_GRID: Id,
  ARIA_TYPE_FIELD_IMAGE: oD,
  ARIA_TYPE_FIELD_INPUT: RD,
  ARIA_TYPE_FIELD_NUMBER: rD,
  ARIA_TYPE_FIELD_TEXT_INPUT: nD,
  ARIA_TYPE_FIELD_TEXT_INPUT_ARGUMENT: sD,
  ARIA_TYPE_FIELD_TEXT_INPUT_PROCEDURE: iD,
  BACKSPACE_KEY: Cu,
  BLOCK_LABEL_BEGIN_PREFIX: WU,
  BLOCK_LABEL_BEGIN_STACK: yU,
  BLOCK_LABEL_COLLAPSED: JU,
  BLOCK_LABEL_CONTAINER: Tc,
  BLOCK_LABEL_DISABLED: jU,
  BLOCK_LABEL_HAS_BRANCHES: ZU,
  BLOCK_LABEL_HAS_INPUT: zU,
  BLOCK_LABEL_HAS_INPUTS: QU,
  BLOCK_LABEL_REPLACEABLE: qU,
  BLOCK_LABEL_STACK_BLOCKS: ec,
  BLOCK_LABEL_STATEMENT: _c,
  BLOCK_LABEL_TOOLBOX_CATEGORY: bU,
  BLOCK_LABEL_VALUE: Ec,
  BUBBLE_LABEL_COMMENT: FD,
  BUBBLE_LABEL_DEFAULT: BD,
  BUBBLE_LABEL_WARNING: mD,
  CANNOT_DELETE_VARIABLE_PROCEDURE: Bs,
  CAPS_LOCK_KEY: Uu,
  CHANGE_VALUE_TITLE: os,
  CHROME_OS: Ru,
  CLEAN_UP: Os,
  CLOSE: Ls,
  CLOSE_BACKPACK: Sd,
  COLLAPSED_WARNINGS_WARNING: eu,
  COLLAPSE_ALL: As,
  COLLAPSE_BLOCK: Is,
  COLOUR_BLEND_COLOUR1: ws,
  COLOUR_BLEND_COLOUR2: ys,
  COLOUR_BLEND_HELPURL: Ys,
  COLOUR_BLEND_RATIO: Ws,
  COLOUR_BLEND_TITLE: Ks,
  COLOUR_BLEND_TOOLTIP: bs,
  COLOUR_HUE: Ki,
  COLOUR_PICKER_HELPURL: ms,
  COLOUR_PICKER_TOOLTIP: hs,
  COLOUR_RANDOM_HELPURL: ps,
  COLOUR_RANDOM_TITLE: fs,
  COLOUR_RANDOM_TOOLTIP: Gs,
  COLOUR_RGB_BLUE: ks,
  COLOUR_RGB_GREEN: $s,
  COLOUR_RGB_HELPURL: vs,
  COLOUR_RGB_RED: Vs,
  COLOUR_RGB_TITLE: Xs,
  COLOUR_RGB_TOOLTIP: xs,
  COMMAND_KEY: su,
  CONTEXT_MENU_KEY: mu,
  CONTROLS_FLOW_STATEMENTS_HELPURL: rS,
  CONTROLS_FLOW_STATEMENTS_OPERATOR_BREAK: iS,
  CONTROLS_FLOW_STATEMENTS_OPERATOR_CONTINUE: sS,
  CONTROLS_FLOW_STATEMENTS_TOOLTIP_BREAK: SS,
  CONTROLS_FLOW_STATEMENTS_TOOLTIP_CONTINUE: oS,
  CONTROLS_FLOW_STATEMENTS_WARNING: MS,
  CONTROLS_FOREACH_HELPURL: AS,
  CONTROLS_FOREACH_INPUT_DO: RS,
  CONTROLS_FOREACH_TITLE: NS,
  CONTROLS_FOREACH_TOOLTIP: nS,
  CONTROLS_FOR_HELPURL: tS,
  CONTROLS_FOR_INPUT_DO: IS,
  CONTROLS_FOR_TITLE: LS,
  CONTROLS_FOR_TOOLTIP: OS,
  CONTROLS_IF_ELSEIF_TITLE_ELSEIF: BS,
  CONTROLS_IF_ELSEIF_TOOLTIP: FS,
  CONTROLS_IF_ELSE_TITLE_ELSE: mS,
  CONTROLS_IF_ELSE_TOOLTIP: hS,
  CONTROLS_IF_HELPURL: CS,
  CONTROLS_IF_IF_TITLE_IF: gS,
  CONTROLS_IF_IF_TOOLTIP: HS,
  CONTROLS_IF_MSG_ELSE: DS,
  CONTROLS_IF_MSG_ELSEIF: cS,
  CONTROLS_IF_MSG_IF: US,
  CONTROLS_IF_MSG_THEN: dS,
  CONTROLS_IF_TOOLTIP_1: PS,
  CONTROLS_IF_TOOLTIP_2: aS,
  CONTROLS_IF_TOOLTIP_3: lS,
  CONTROLS_IF_TOOLTIP_4: uS,
  CONTROLS_REPEAT_HELPURL: js,
  CONTROLS_REPEAT_INPUT_DO: qs,
  CONTROLS_REPEAT_TITLE: Js,
  CONTROLS_REPEAT_TOOLTIP: zs,
  CONTROLS_WHILEUNTIL_HELPURL: Qs,
  CONTROLS_WHILEUNTIL_INPUT_DO: Zs,
  CONTROLS_WHILEUNTIL_OPERATOR_UNTIL: TS,
  CONTROLS_WHILEUNTIL_OPERATOR_WHILE: _S,
  CONTROLS_WHILEUNTIL_TOOLTIP_UNTIL: eS,
  CONTROLS_WHILEUNTIL_TOOLTIP_WHILE: ES,
  CONTROL_KEY: iu,
  COPY_ALL_TO_BACKPACK: od,
  COPY_SHORTCUT: pu,
  COPY_TO_BACKPACK: Md,
  CURRENT_BLOCK_ANNOUNCEMENT: wD,
  CUT_SHORTCUT: hu,
  DELETE_ALL_BLOCKS: ts,
  DELETE_BLOCK: Es,
  DELETE_KEY: Pu,
  DELETE_VARIABLE: Fs,
  DELETE_VARIABLE_CONFIRMATION: Hs,
  DELETE_X_BLOCKS: es,
  DIALOG_CANCEL: Ou,
  DIALOG_OK: tu,
  DISABLE_BLOCK: ns,
  DUPLICATE_BLOCK: qi,
  DUPLICATE_COMMENT: Zi,
  EDIT_BLOCK_CONTENTS: Lu,
  EMPTY_BACKPACK: Cd,
  ENABLE_BLOCK: rs,
  END_KEY: gu,
  ENTER_KEY: Mu,
  ESCAPE: au,
  EXPAND_ALL: Rs,
  EXPAND_BLOCK: Ns,
  EXTERNAL_INPUTS: _s,
  FIELD_BITMAP_ARIA_VALUE: id,
  FIELD_BITMAP_BUTTON_LABEL_CLEAR: Nd,
  FIELD_BITMAP_BUTTON_LABEL_RANDOMIZE: Ad,
  FIELD_BITMAP_PIXEL_LABEL: rd,
  FIELD_BITMAP_PIXEL_OFF: nd,
  FIELD_BITMAP_PIXEL_ON: Rd,
  FIELD_LABEL_CHECKBOX_CHECKED: cD,
  FIELD_LABEL_CHECKBOX_UNCHECKED: DD,
  FIELD_LABEL_EDIT_PREFIX: CD,
  FIELD_LABEL_EMPTY: ND,
  FIELD_LABEL_OPTION_INDEX: UD,
  FIELD_LABEL_VARIABLE: dD,
  FIELD_MULTILINEINPUT_FINISH_EDITING: ld,
  FIELD_MULTILINEINPUT_NEW_LINE: ud,
  HELP: is,
  HELP_PROMPT: Gu,
  HOME_KEY: Hu,
  ICON_LABEL_COMMENT_CLOSED: pD,
  ICON_LABEL_COMMENT_OPEN: fD,
  ICON_LABEL_DEFAULT: hD,
  ICON_LABEL_MUTATOR_CLOSED: GD,
  ICON_LABEL_MUTATOR_OPEN: vD,
  ICON_LABEL_WARNING_CLOSED: XD,
  ICON_LABEL_WARNING_OPEN: VD,
  INLINE_INPUTS: Ts,
  INPUT_LABEL_CONDITION: Nc,
  INPUT_LABEL_CONDITION_A: Rc,
  INPUT_LABEL_CONDITION_B: nc,
  INPUT_LABEL_EMPTY: Ac,
  INPUT_LABEL_END_STATEMENT: Ic,
  INPUT_LABEL_INDEX: tc,
  INPUT_LABEL_LISTS_CREATE_WITH_ITEM: Kc,
  INPUT_LABEL_LISTS_DELIMITER: Zc,
  INPUT_LABEL_LISTS_END_POSITION: qc,
  INPUT_LABEL_LISTS_LIST_FROM_TEXT: zc,
  INPUT_LABEL_LISTS_POSITION: jc,
  INPUT_LABEL_LISTS_REPEAT_ITEM: wc,
  INPUT_LABEL_LISTS_REPEAT_NUM: yc,
  INPUT_LABEL_LISTS_START_POSITION: Jc,
  INPUT_LABEL_LISTS_TEXT_FROM_LIST: Qc,
  INPUT_LABEL_LISTS_TO_CHANGE: _D,
  INPUT_LABEL_LISTS_TO_CHECK: Wc,
  INPUT_LABEL_LISTS_VALUE_TO_SET: bc,
  INPUT_LABEL_LOOP_BY: Fc,
  INPUT_LABEL_LOOP_FROM: Hc,
  INPUT_LABEL_LOOP_LIST: mc,
  INPUT_LABEL_LOOP_TIMES: gc,
  INPUT_LABEL_LOOP_TO: Bc,
  INPUT_LABEL_MATH_CHANGE_BY: lc,
  INPUT_LABEL_MATH_CONSTRAIN_VALUE: uc,
  INPUT_LABEL_MATH_DIVIDEND: Pc,
  INPUT_LABEL_MATH_DIVISOR: ac,
  INPUT_LABEL_NUMBER: sc,
  INPUT_LABEL_NUMBER_A: Sc,
  INPUT_LABEL_NUMBER_ATAN2_X: Dc,
  INPUT_LABEL_NUMBER_ATAN2_Y: dc,
  INPUT_LABEL_NUMBER_B: oc,
  INPUT_LABEL_NUMBER_LIST: Cc,
  INPUT_LABEL_NUMBER_MAX: cc,
  INPUT_LABEL_NUMBER_MIN: Uc,
  INPUT_LABEL_NUMBER_TO_CHECK: Mc,
  INPUT_LABEL_STATEMENT: Lc,
  INPUT_LABEL_TEXT_APPEND: pc,
  INPUT_LABEL_TEXT_END_POSITION: kc,
  INPUT_LABEL_TEXT_JOIN_ITEM: hc,
  INPUT_LABEL_TEXT_POSITION: Vc,
  INPUT_LABEL_TEXT_PROMPT_MESSAGE: xc,
  INPUT_LABEL_TEXT_START_POSITION: $c,
  INPUT_LABEL_TEXT_TO_CHANGE: fc,
  INPUT_LABEL_TEXT_TO_CHECK: Gc,
  INPUT_LABEL_TEXT_TO_FIND: vc,
  INPUT_LABEL_TEXT_TO_REPLACE: Xc,
  INPUT_LABEL_VALUE: Oc,
  INPUT_LABEL_VALUE_A: rc,
  INPUT_LABEL_VALUE_B: ic,
  INPUT_LABEL_VARIABLES_SET: Yc,
  INSERT_KEY: Bu,
  KEYBOARD_NAV_BLOCK_NAVIGATION_HINT: YU,
  KEYBOARD_NAV_CONSTRAINED_MOVE_HINT: HU,
  KEYBOARD_NAV_COPIED_HINT: BU,
  KEYBOARD_NAV_CUT_HINT: FU,
  KEYBOARD_NAV_FLYOUT_LABEL_HINT: wU,
  KEYBOARD_NAV_UNCONSTRAINED_MOVE_HINT: gU,
  KEYBOARD_NAV_WORKSPACE_NAVIGATION_HINT: KU,
  LINUX: nu,
  LISTS_CREATE_EMPTY_HELPURL: GP,
  LISTS_CREATE_EMPTY_TITLE: vP,
  LISTS_CREATE_EMPTY_TOOLTIP: XP,
  LISTS_CREATE_WITH_CONTAINER_TITLE_ADD: xP,
  LISTS_CREATE_WITH_CONTAINER_TOOLTIP: YP,
  LISTS_CREATE_WITH_HELPURL: VP,
  LISTS_CREATE_WITH_INPUT_WITH: kP,
  LISTS_CREATE_WITH_ITEM_TITLE: KP,
  LISTS_CREATE_WITH_ITEM_TOOLTIP: wP,
  LISTS_CREATE_WITH_TOOLTIP: $P,
  LISTS_GET_INDEX_FIRST: ra,
  LISTS_GET_INDEX_FROM_END: na,
  LISTS_GET_INDEX_FROM_START: Ra,
  LISTS_GET_INDEX_GET: Ia,
  LISTS_GET_INDEX_GET_REMOVE: Aa,
  LISTS_GET_INDEX_HELPURL: La,
  LISTS_GET_INDEX_INPUT_IN_LIST: oa,
  LISTS_GET_INDEX_LAST: ia,
  LISTS_GET_INDEX_RANDOM: sa,
  LISTS_GET_INDEX_REMOVE: Na,
  LISTS_GET_INDEX_TAIL: Sa,
  LISTS_GET_INDEX_TOOLTIP_GET_FIRST: aa,
  LISTS_GET_INDEX_TOOLTIP_GET_FROM: Pa,
  LISTS_GET_INDEX_TOOLTIP_GET_LAST: la,
  LISTS_GET_INDEX_TOOLTIP_GET_RANDOM: ua,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_FIRST: ca,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_FROM: Ua,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_LAST: Da,
  LISTS_GET_INDEX_TOOLTIP_GET_REMOVE_RANDOM: da,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_FIRST: Ha,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_FROM: ga,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_LAST: Ba,
  LISTS_GET_INDEX_TOOLTIP_REMOVE_RANDOM: Fa,
  LISTS_GET_SUBLIST_END_FROM_END: qa,
  LISTS_GET_SUBLIST_END_FROM_START: Ja,
  LISTS_GET_SUBLIST_END_LAST: za,
  LISTS_GET_SUBLIST_HELPURL: wa,
  LISTS_GET_SUBLIST_INPUT_IN_LIST: ya,
  LISTS_GET_SUBLIST_START_FIRST: ja,
  LISTS_GET_SUBLIST_START_FROM_END: ba,
  LISTS_GET_SUBLIST_START_FROM_START: Wa,
  LISTS_GET_SUBLIST_TAIL: Qa,
  LISTS_GET_SUBLIST_TOOLTIP: Za,
  LISTS_HUE: Yi,
  LISTS_INDEX_FROM_END_TOOLTIP: Ca,
  LISTS_INDEX_FROM_START_TOOLTIP: Ma,
  LISTS_INDEX_OF_FIRST: ea,
  LISTS_INDEX_OF_HELPURL: Ta,
  LISTS_INDEX_OF_INPUT_IN_LIST: Ea,
  LISTS_INDEX_OF_LAST: ta,
  LISTS_INDEX_OF_TOOLTIP: Oa,
  LISTS_INLIST: _a,
  LISTS_ISEMPTY_HELPURL: zP,
  LISTS_ISEMPTY_TITLE: QP,
  LISTS_ISEMPTY_TOOLTIP: ZP,
  LISTS_LENGTH_HELPURL: jP,
  LISTS_LENGTH_TITLE: JP,
  LISTS_LENGTH_TOOLTIP: qP,
  LISTS_REPEAT_HELPURL: yP,
  LISTS_REPEAT_TITLE: bP,
  LISTS_REPEAT_TOOLTIP: WP,
  LISTS_REVERSE_HELPURL: sl,
  LISTS_REVERSE_MESSAGE0: Sl,
  LISTS_REVERSE_TOOLTIP: ol,
  LISTS_SET_INDEX_HELPURL: ma,
  LISTS_SET_INDEX_INPUT_IN_LIST: ha,
  LISTS_SET_INDEX_INPUT_TO: Ga,
  LISTS_SET_INDEX_INSERT: fa,
  LISTS_SET_INDEX_SET: pa,
  LISTS_SET_INDEX_TOOLTIP_INSERT_FIRST: xa,
  LISTS_SET_INDEX_TOOLTIP_INSERT_FROM: ka,
  LISTS_SET_INDEX_TOOLTIP_INSERT_LAST: Ya,
  LISTS_SET_INDEX_TOOLTIP_INSERT_RANDOM: Ka,
  LISTS_SET_INDEX_TOOLTIP_SET_FIRST: Xa,
  LISTS_SET_INDEX_TOOLTIP_SET_FROM: va,
  LISTS_SET_INDEX_TOOLTIP_SET_LAST: Va,
  LISTS_SET_INDEX_TOOLTIP_SET_RANDOM: $a,
  LISTS_SORT_HELPURL: _l,
  LISTS_SORT_ORDER_ASCENDING: el,
  LISTS_SORT_ORDER_DESCENDING: tl,
  LISTS_SORT_TITLE: Tl,
  LISTS_SORT_TOOLTIP: El,
  LISTS_SORT_TYPE_IGNORECASE: Il,
  LISTS_SORT_TYPE_NUMERIC: Ol,
  LISTS_SORT_TYPE_TEXT: Ll,
  LISTS_SPLIT_HELPURL: Al,
  LISTS_SPLIT_LIST_FROM_TEXT: Nl,
  LISTS_SPLIT_TEXT_FROM_LIST: Rl,
  LISTS_SPLIT_TOOLTIP_JOIN: il,
  LISTS_SPLIT_TOOLTIP_SPLIT: rl,
  LISTS_SPLIT_WITH_DELIMITER: nl,
  LOGIC_BOOLEAN_FALSE: Eo,
  LOGIC_BOOLEAN_HELPURL: _o,
  LOGIC_BOOLEAN_TOOLTIP: eo,
  LOGIC_BOOLEAN_TRUE: To,
  LOGIC_COMPARE_EQ_ARIA: fS,
  LOGIC_COMPARE_GTE_ARIA: wS,
  LOGIC_COMPARE_GT_ARIA: YS,
  LOGIC_COMPARE_HELPURL: pS,
  LOGIC_COMPARE_LTE_ARIA: kS,
  LOGIC_COMPARE_LT_ARIA: VS,
  LOGIC_COMPARE_NEQ_ARIA: vS,
  LOGIC_COMPARE_TOOLTIP_EQ: GS,
  LOGIC_COMPARE_TOOLTIP_GT: KS,
  LOGIC_COMPARE_TOOLTIP_GTE: yS,
  LOGIC_COMPARE_TOOLTIP_LT: $S,
  LOGIC_COMPARE_TOOLTIP_LTE: xS,
  LOGIC_COMPARE_TOOLTIP_NEQ: XS,
  LOGIC_HUE: Vi,
  LOGIC_NEGATE_HELPURL: zS,
  LOGIC_NEGATE_TITLE: QS,
  LOGIC_NEGATE_TOOLTIP: ZS,
  LOGIC_NULL: Oo,
  LOGIC_NULL_HELPURL: to,
  LOGIC_NULL_TOOLTIP: Lo,
  LOGIC_OPERATION_AND: jS,
  LOGIC_OPERATION_HELPURL: WS,
  LOGIC_OPERATION_OR: qS,
  LOGIC_OPERATION_TOOLTIP_AND: bS,
  LOGIC_OPERATION_TOOLTIP_OR: JS,
  LOGIC_TERNARY_CONDITION: Ao,
  LOGIC_TERNARY_HELPURL: Io,
  LOGIC_TERNARY_IF_FALSE: Ro,
  LOGIC_TERNARY_IF_TRUE: No,
  LOGIC_TERNARY_TOOLTIP: no,
  LOOPS_HUE: $i,
  MAC_OS: Nu,
  MATH_ADDITION_SYMBOL: so,
  MATH_ADDITION_SYMBOL_ARIA: So,
  MATH_ARITHMETIC_HELPURL: Ko,
  MATH_ARITHMETIC_TOOLTIP_ADD: wo,
  MATH_ARITHMETIC_TOOLTIP_DIVIDE: bo,
  MATH_ARITHMETIC_TOOLTIP_MINUS: yo,
  MATH_ARITHMETIC_TOOLTIP_MULTIPLY: Wo,
  MATH_ARITHMETIC_TOOLTIP_POWER: jo,
  MATH_ATAN2_HELPURL: sC,
  MATH_ATAN2_TITLE: SC,
  MATH_ATAN2_TOOLTIP: oC,
  MATH_CHANGE_HELPURL: HM,
  MATH_CHANGE_TITLE: BM,
  MATH_CHANGE_TITLE_ITEM: FM,
  MATH_CHANGE_TOOLTIP: mM,
  MATH_CONSTANT_E_ARIA: Vo,
  MATH_CONSTANT_GOLDEN_RATIO_ARIA: $o,
  MATH_CONSTANT_HELPURL: CM,
  MATH_CONSTANT_INFINITY_ARIA: Yo,
  MATH_CONSTANT_PI_ARIA: Xo,
  MATH_CONSTANT_SQRT1_2_ARIA: xo,
  MATH_CONSTANT_SQRT2_ARIA: ko,
  MATH_CONSTANT_TOOLTIP: PM,
  MATH_CONSTRAIN_HELPURL: OC,
  MATH_CONSTRAIN_TITLE: LC,
  MATH_CONSTRAIN_TOOLTIP: IC,
  MATH_DIVISION_SYMBOL: Co,
  MATH_DIVISION_SYMBOL_ARIA: Po,
  MATH_HUE: ki,
  MATH_IS_DIVISIBLE_BY: dM,
  MATH_IS_EVEN: aM,
  MATH_IS_NEGATIVE: DM,
  MATH_IS_ODD: lM,
  MATH_IS_POSITIVE: cM,
  MATH_IS_PRIME: uM,
  MATH_IS_TOOLTIP: gM,
  MATH_IS_WHOLE: UM,
  MATH_MODULO_HELPURL: EC,
  MATH_MODULO_TITLE: eC,
  MATH_MODULO_TOOLTIP: tC,
  MATH_MULTIPLICATION_SYMBOL: ao,
  MATH_MULTIPLICATION_SYMBOL_ARIA: lo,
  MATH_NUMBER_HELPURL: ro,
  MATH_NUMBER_TOOLTIP: io,
  MATH_ONLIST_HELPURL: XM,
  MATH_ONLIST_OPERATOR_AVERAGE: WM,
  MATH_ONLIST_OPERATOR_MAX: KM,
  MATH_ONLIST_OPERATOR_MAX_ARIA: wM,
  MATH_ONLIST_OPERATOR_MEDIAN: jM,
  MATH_ONLIST_OPERATOR_MIN: kM,
  MATH_ONLIST_OPERATOR_MIN_ARIA: xM,
  MATH_ONLIST_OPERATOR_MODE: qM,
  MATH_ONLIST_OPERATOR_RANDOM: _C,
  MATH_ONLIST_OPERATOR_STD_DEV: QM,
  MATH_ONLIST_OPERATOR_SUM: VM,
  MATH_ONLIST_TOOLTIP_AVERAGE: bM,
  MATH_ONLIST_TOOLTIP_MAX: yM,
  MATH_ONLIST_TOOLTIP_MEDIAN: JM,
  MATH_ONLIST_TOOLTIP_MIN: YM,
  MATH_ONLIST_TOOLTIP_MODE: zM,
  MATH_ONLIST_TOOLTIP_RANDOM: TC,
  MATH_ONLIST_TOOLTIP_STD_DEV: ZM,
  MATH_ONLIST_TOOLTIP_SUM: $M,
  MATH_POWER_SYMBOL: uo,
  MATH_POWER_SYMBOL_ARIA: Uo,
  MATH_RANDOM_FLOAT_HELPURL: nC,
  MATH_RANDOM_FLOAT_TITLE_RANDOM: rC,
  MATH_RANDOM_FLOAT_TOOLTIP: iC,
  MATH_RANDOM_INT_HELPURL: AC,
  MATH_RANDOM_INT_TITLE: NC,
  MATH_RANDOM_INT_TOOLTIP: RC,
  MATH_ROUND_HELPURL: hM,
  MATH_ROUND_OPERATOR_ROUND: fM,
  MATH_ROUND_OPERATOR_ROUNDDOWN: vM,
  MATH_ROUND_OPERATOR_ROUNDUP: GM,
  MATH_ROUND_TOOLTIP: pM,
  MATH_SINGLE_HELPURL: Jo,
  MATH_SINGLE_OP_ABSOLUTE: Qo,
  MATH_SINGLE_OP_ABSOLUTE_ARIA: Zo,
  MATH_SINGLE_OP_EXP_ARIA: tM,
  MATH_SINGLE_OP_LN_ARIA: EM,
  MATH_SINGLE_OP_LOG10_ARIA: eM,
  MATH_SINGLE_OP_NEG_ARIA: TM,
  MATH_SINGLE_OP_POW10_ARIA: OM,
  MATH_SINGLE_OP_ROOT: qo,
  MATH_SINGLE_TOOLTIP_ABS: _M,
  MATH_SINGLE_TOOLTIP_EXP: NM,
  MATH_SINGLE_TOOLTIP_LN: IM,
  MATH_SINGLE_TOOLTIP_LOG10: AM,
  MATH_SINGLE_TOOLTIP_NEG: LM,
  MATH_SINGLE_TOOLTIP_POW10: RM,
  MATH_SINGLE_TOOLTIP_ROOT: zo,
  MATH_SUBTRACTION_SYMBOL: oo,
  MATH_SUBTRACTION_SYMBOL_ARIA: Mo,
  MATH_TRIG_ACOS: po,
  MATH_TRIG_ACOS_ARIA: fo,
  MATH_TRIG_ASIN: mo,
  MATH_TRIG_ASIN_ARIA: ho,
  MATH_TRIG_ATAN: Go,
  MATH_TRIG_ATAN_ARIA: vo,
  MATH_TRIG_COS: go,
  MATH_TRIG_COS_ARIA: Ho,
  MATH_TRIG_HELPURL: nM,
  MATH_TRIG_SIN: co,
  MATH_TRIG_SIN_ARIA: Do,
  MATH_TRIG_TAN: Bo,
  MATH_TRIG_TAN_ARIA: Fo,
  MATH_TRIG_TOOLTIP_ACOS: oM,
  MATH_TRIG_TOOLTIP_ASIN: SM,
  MATH_TRIG_TOOLTIP_ATAN: MM,
  MATH_TRIG_TOOLTIP_COS: iM,
  MATH_TRIG_TOOLTIP_SIN: rM,
  MATH_TRIG_TOOLTIP_TAN: sM,
  MINIMAP_ARIA_LABEL: cd,
  MOVE_BLOCK: Iu,
  NEW_COLOUR_VARIABLE: us,
  NEW_NUMBER_VARIABLE: ls,
  NEW_STRING_VARIABLE: as,
  NEW_VARIABLE: Ps,
  NEW_VARIABLE_TITLE: cs,
  NEW_VARIABLE_TYPE_TITLE: Us,
  NO_PARENT_ANNOUNCEMENT: WD,
  OPEN_BACKPACK: sd,
  OPEN_TRASH: PD,
  OPTION_KEY: Su,
  ORDINAL_NUMBER_SUFFIX: Ml,
  PAGE_DOWN_KEY: du,
  PAGE_UP_KEY: Du,
  PARENT_BLOCKS_ANNOUNCEMENT: yD,
  PASTE_ALL_FROM_BACKPACK: Pd,
  PASTE_SHORTCUT: fu,
  PAUSE_KEY: Fu,
  PROCEDURES_ALLOW_STATEMENTS: xl,
  PROCEDURES_BEFORE_PARAMS: Hl,
  PROCEDURES_CALLNORETURN_HELPURL: Kl,
  PROCEDURES_CALLNORETURN_TOOLTIP: wl,
  PROCEDURES_CALLRETURN_HELPURL: yl,
  PROCEDURES_CALLRETURN_TOOLTIP: Wl,
  PROCEDURES_CALL_BEFORE_PARAMS: Bl,
  PROCEDURES_CALL_DISABLED_DEF_WARNING: Fl,
  PROCEDURES_CREATE_DO: Ql,
  PROCEDURES_DEFNORETURN_COMMENT: pl,
  PROCEDURES_DEFNORETURN_DO: ml,
  PROCEDURES_DEFNORETURN_HELPURL: Dl,
  PROCEDURES_DEFNORETURN_PROCEDURE: gl,
  PROCEDURES_DEFNORETURN_TITLE: dl,
  PROCEDURES_DEFNORETURN_TOOLTIP: hl,
  PROCEDURES_DEFRETURN_COMMENT: Vl,
  PROCEDURES_DEFRETURN_DO: Xl,
  PROCEDURES_DEFRETURN_HELPURL: fl,
  PROCEDURES_DEFRETURN_PROCEDURE: vl,
  PROCEDURES_DEFRETURN_RETURN: $l,
  PROCEDURES_DEFRETURN_TITLE: Gl,
  PROCEDURES_DEFRETURN_TOOLTIP: kl,
  PROCEDURES_DEF_DUPLICATE_WARNING: Yl,
  PROCEDURES_HIGHLIGHT_DEF: zl,
  PROCEDURES_HUE: Wi,
  PROCEDURES_IFRETURN_HELPURL: _u,
  PROCEDURES_IFRETURN_TOOLTIP: Zl,
  PROCEDURES_IFRETURN_WARNING: Tu,
  PROCEDURES_MUTATORARG_TITLE: Jl,
  PROCEDURES_MUTATORARG_TOOLTIP: ql,
  PROCEDURES_MUTATORCONTAINER_TITLE: bl,
  PROCEDURES_MUTATORCONTAINER_TOOLTIP: jl,
  REDO: Ss,
  REMOVE_COMMENT: Qi,
  REMOVE_FROM_BACKPACK: ad,
  RENAME_VARIABLE: Ms,
  RENAME_VARIABLE_TITLE: Cs,
  RESET_ZOOM: uD,
  SCREENREADER_HINT: bD,
  SCREENREADER_MODE_DISABLED: KD,
  SCREENREADER_MODE_ENABLED: YD,
  SHIFT_KEY: uu,
  SHORTCUTS_ABORT_MOVE: ju,
  SHORTCUTS_CLEANUP: IU,
  SHORTCUTS_CODE_NAVIGATION: Vu,
  SHORTCUTS_DELETE: ku,
  SHORTCUTS_DISCONNECT: _U,
  SHORTCUTS_DUPLICATE: LU,
  SHORTCUTS_EDITING: Xu,
  SHORTCUTS_ESCAPE: $u,
  SHORTCUTS_EXTENDED_INFORMATION: Zu,
  SHORTCUTS_FINISH_MOVE: bu,
  SHORTCUTS_FOCUS_TOOLBOX: zu,
  SHORTCUTS_FOCUS_WORKSPACE: qu,
  SHORTCUTS_GENERAL: vu,
  SHORTCUTS_INFORMATION: Qu,
  SHORTCUTS_JUMP_BLOCK_END: nU,
  SHORTCUTS_JUMP_BLOCK_START: RU,
  SHORTCUTS_JUMP_BOTTOM_STACK: iU,
  SHORTCUTS_JUMP_FIRST_BLOCK: sU,
  SHORTCUTS_JUMP_LAST_BLOCK: SU,
  SHORTCUTS_JUMP_NEXT_PAGE: MU,
  SHORTCUTS_JUMP_PREVIOUS_PAGE: oU,
  SHORTCUTS_JUMP_TOP_STACK: rU,
  SHORTCUTS_MOVE_DOWN: Wu,
  SHORTCUTS_MOVE_LEFT: Ku,
  SHORTCUTS_MOVE_RIGHT: wu,
  SHORTCUTS_MOVE_UP: yu,
  SHORTCUTS_NEXT_HEADING: eU,
  SHORTCUTS_NEXT_STACK: TU,
  SHORTCUTS_PERFORM_ACTION: OU,
  SHORTCUTS_PREVIOUS_HEADING: tU,
  SHORTCUTS_PREVIOUS_STACK: EU,
  SHORTCUTS_SCROLL_DOWN: lU,
  SHORTCUTS_SCROLL_LEFT: CU,
  SHORTCUTS_SCROLL_RIGHT: PU,
  SHORTCUTS_SCROLL_UP: aU,
  SHORTCUTS_SHOW_CONTEXT_MENU: Ju,
  SHORTCUTS_SHOW_TOOLTIP: AU,
  SHORTCUTS_START_MOVE: xu,
  SHORTCUTS_START_MOVE_STACK: Yu,
  SHORTCUTS_TOGGLE_SCREENREADER_MODE: NU,
  SPACE_KEY: cu,
  TAB_KEY: lu,
  TEXTS_HUE: xi,
  TEXT_APPEND_HELPURL: dC,
  TEXT_APPEND_TITLE: gC,
  TEXT_APPEND_TOOLTIP: BC,
  TEXT_APPEND_VARIABLE: HC,
  TEXT_CHANGECASE_HELPURL: AP,
  TEXT_CHANGECASE_OPERATOR_LOWERCASE: nP,
  TEXT_CHANGECASE_OPERATOR_TITLECASE: rP,
  TEXT_CHANGECASE_OPERATOR_UPPERCASE: RP,
  TEXT_CHANGECASE_TOOLTIP: NP,
  TEXT_CHARAT_FIRST: bC,
  TEXT_CHARAT_FROM_END: WC,
  TEXT_CHARAT_FROM_START: yC,
  TEXT_CHARAT_HELPURL: KC,
  TEXT_CHARAT_LAST: jC,
  TEXT_CHARAT_RANDOM: JC,
  TEXT_CHARAT_TAIL: qC,
  TEXT_CHARAT_TITLE: wC,
  TEXT_CHARAT_TOOLTIP: zC,
  TEXT_COUNT_HELPURL: gP,
  TEXT_COUNT_MESSAGE0: dP,
  TEXT_COUNT_TOOLTIP: HP,
  TEXT_CREATE_JOIN_ITEM_TITLE_ITEM: cC,
  TEXT_CREATE_JOIN_ITEM_TOOLTIP: DC,
  TEXT_CREATE_JOIN_TITLE_JOIN: uC,
  TEXT_CREATE_JOIN_TOOLTIP: UC,
  TEXT_FROM_END_ARIA: YC,
  TEXT_FROM_START_ARIA: xC,
  TEXT_GET_SUBSTRING_END_FROM_END: OP,
  TEXT_GET_SUBSTRING_END_FROM_START: tP,
  TEXT_GET_SUBSTRING_END_LAST: LP,
  TEXT_GET_SUBSTRING_HELPURL: ZC,
  TEXT_GET_SUBSTRING_INPUT_IN_TEXT: _P,
  TEXT_GET_SUBSTRING_START_FIRST: eP,
  TEXT_GET_SUBSTRING_START_FROM_END: EP,
  TEXT_GET_SUBSTRING_START_FROM_START: TP,
  TEXT_GET_SUBSTRING_TAIL: IP,
  TEXT_GET_SUBSTRING_TOOLTIP: QC,
  TEXT_INDEXOF_HELPURL: vC,
  TEXT_INDEXOF_OPERATOR_FIRST: $C,
  TEXT_INDEXOF_OPERATOR_LAST: kC,
  TEXT_INDEXOF_TITLE: VC,
  TEXT_INDEXOF_TOOLTIP: XC,
  TEXT_ISEMPTY_HELPURL: pC,
  TEXT_ISEMPTY_TITLE: fC,
  TEXT_ISEMPTY_TOOLTIP: GC,
  TEXT_JOIN_HELPURL: PC,
  TEXT_JOIN_TITLE_CREATEWITH: aC,
  TEXT_JOIN_TOOLTIP: lC,
  TEXT_LENGTH_HELPURL: FC,
  TEXT_LENGTH_TITLE: mC,
  TEXT_LENGTH_TOOLTIP: hC,
  TEXT_PRINT_HELPURL: CP,
  TEXT_PRINT_TITLE: PP,
  TEXT_PRINT_TOOLTIP: aP,
  TEXT_PROMPT_HELPURL: lP,
  TEXT_PROMPT_TOOLTIP_NUMBER: cP,
  TEXT_PROMPT_TOOLTIP_TEXT: DP,
  TEXT_PROMPT_TYPE_NUMBER: UP,
  TEXT_PROMPT_TYPE_TEXT: uP,
  TEXT_REPLACE_HELPURL: FP,
  TEXT_REPLACE_MESSAGE0: BP,
  TEXT_REPLACE_TOOLTIP: mP,
  TEXT_REVERSE_HELPURL: pP,
  TEXT_REVERSE_MESSAGE0: hP,
  TEXT_REVERSE_TOOLTIP: fP,
  TEXT_TEXT_HELPURL: MC,
  TEXT_TEXT_TOOLTIP: CC,
  TEXT_TRIM_HELPURL: iP,
  TEXT_TRIM_OPERATOR_BOTH: SP,
  TEXT_TRIM_OPERATOR_LEFT: oP,
  TEXT_TRIM_OPERATOR_RIGHT: MP,
  TEXT_TRIM_TOOLTIP: sP,
  TODAY: Ji,
  TOOLBOX_SEARCH_NO_RESULTS: Gd,
  TOOLBOX_SEARCH_PLACEHOLDER: pd,
  TOOLBOX_SEARCH_PROMPT: fd,
  TOOLBOX_SEARCH_RESULT_COUNT: Xd,
  TOOLBOX_SEARCH_RESULT_COUNT_ONE: vd,
  UNDO: ss,
  UNKNOWN: ru,
  UNNAMED_KEY: ji,
  VARIABLES_DEFAULT_NAME: bi,
  VARIABLES_DYNAMIC_HUE: yi,
  VARIABLES_GET_CREATE_SET: al,
  VARIABLES_GET_HELPURL: Cl,
  VARIABLES_GET_TOOLTIP: Pl,
  VARIABLES_HUE: wi,
  VARIABLES_SET: ul,
  VARIABLES_SET_CREATE_GET: cl,
  VARIABLES_SET_HELPURL: ll,
  VARIABLES_SET_TOOLTIP: Ul,
  VARIABLE_ALREADY_EXISTS: Ds,
  VARIABLE_ALREADY_EXISTS_FOR_ANOTHER_TYPE: ds,
  VARIABLE_ALREADY_EXISTS_FOR_A_PARAMETER: gs,
  WINDOWS: Au,
  WORKSPACE_COMMENT_DEFAULT_TEXT: Eu,
  WORKSPACE_CONTENTS_BLOCKS_MANY: XU,
  WORKSPACE_CONTENTS_BLOCKS_ONE: VU,
  WORKSPACE_CONTENTS_BLOCKS_ZERO: $U,
  WORKSPACE_CONTENTS_COMMENTS_MANY: kU,
  WORKSPACE_CONTENTS_COMMENTS_ONE: xU,
  WORKSPACE_LABEL_1_STACK: pU,
  WORKSPACE_LABEL_FLYOUT_WORKSPACE: vU,
  WORKSPACE_LABEL_MANY_STACKS: fU,
  WORKSPACE_LABEL_MUTATOR_WORKSPACE: GU,
  WORKSPACE_LABEL_PLAIN: mU,
  WORKSPACE_ROLEDESCRIPTION: hU,
  WORKSPACE_SEARCH_CLOSE: Fd,
  WORKSPACE_SEARCH_FIND_NEXT: Hd,
  WORKSPACE_SEARCH_FIND_PREVIOUS: Bd,
  WORKSPACE_SEARCH_INPUT_LABEL: gd,
  WORKSPACE_SEARCH_MATCH: hd,
  WORKSPACE_SEARCH_NO_MATCHES: md,
  WORKSPACE_SEARCH_PLACEHOLDER: dd,
  ZOOM_IN: aD,
  ZOOM_OUT: lD,
  ZOOM_TO_FIT_ARIA_LABEL: Ud
}, Symbol.toStringTag, { value: "Module" }));
var j = { exports: {} }, J = { exports: {} }, $d = J.exports, O_;
function kd() {
  return O_ || (O_ = 1, (function(g, C) {
    (function(_, s) {
      g.exports = s(K());
    })($d, function(_) {
      var s = _.__namespace__, U = function(t, L) {
        var T = 0, e = "";
        L.STATEMENT_PREFIX && (e += L.injectId(L.STATEMENT_PREFIX, t));
        do {
          var E = L.valueToCode(t, "IF" + T, A.NONE) || "false", O = L.statementToCode(t, "DO" + T);
          L.STATEMENT_SUFFIX && (O = L.prefixLines(L.injectId(L.STATEMENT_SUFFIX, t), L.INDENT) + O), e += (T > 0 ? "else " : "") + "if (" + E + `) {
` + O + "}", T++;
        } while (t.getInput("IF" + T));
        return (t.getInput("ELSE") || L.STATEMENT_SUFFIX) && (O = t.getInput("ELSE") ? L.statementToCode(t, "ELSE") : "", L.STATEMENT_SUFFIX && (O = L.prefixLines(L.injectId(L.STATEMENT_SUFFIX, t), L.INDENT) + O), e += ` else {
` + O + "}"), e + `
`;
      }, D = function(t, L) {
        var T = t.getField("TIMES") ? String(Number(t.getFieldValue("TIMES"))) : L.valueToCode(t, "TIMES", A.ASSIGNMENT) || "0", e = L.statementToCode(t, "DO");
        e = L.addLoopTrap(e, t), t = "";
        var E = L.nameDB_.getDistinctName("count", s.P.VARIABLE), O = T;
        return T.match(/^\w+$/) || s.zf(T) || (O = L.nameDB_.getDistinctName("repeat_end", s.P.VARIABLE), t += "var " + O + " = " + T + `;
`), t + ("for (int " + E + " = 0; " + E + " < " + O + "; " + E + `++) {
` + e + `}
`);
      }, u = function(t, L) {
        var T = t.getFieldValue("OP");
        if (T === "NEG") return t = L.valueToCode(t, "NUM", A.UNARY_PREFIX) || "0", t[0] === "-" && (t = " " + t), ["-" + t, A.UNARY_PREFIX];
        switch (L.definitions_.import_dart_math = "import 'dart:math' as Math;", t = T === "ABS" || T.substring(0, 5) === "ROUND" ? L.valueToCode(t, "NUM", A.UNARY_POSTFIX) || "0" : T === "SIN" || T === "COS" || T === "TAN" ? L.valueToCode(t, "NUM", A.MULTIPLICATIVE) || "0" : L.valueToCode(t, "NUM", A.NONE) || "0", T) {
          case "ABS":
            var e = t + ".abs()";
            break;
          case "ROOT":
            e = "Math.sqrt(" + t + ")";
            break;
          case "LN":
            e = "Math.log(" + t + ")";
            break;
          case "EXP":
            e = "Math.exp(" + t + ")";
            break;
          case "POW10":
            e = "Math.pow(10," + t + ")";
            break;
          case "ROUND":
            e = t + ".round()";
            break;
          case "ROUNDUP":
            e = t + ".ceil()";
            break;
          case "ROUNDDOWN":
            e = t + ".floor()";
            break;
          case "SIN":
            e = "Math.sin(" + t + " / 180 * Math.pi)";
            break;
          case "COS":
            e = "Math.cos(" + t + " / 180 * Math.pi)";
            break;
          case "TAN":
            e = "Math.tan(" + t + " / 180 * Math.pi)";
        }
        if (e) return [e, A.UNARY_POSTFIX];
        switch (T) {
          case "LOG10":
            e = "Math.log(" + t + ") / Math.log(10)";
            break;
          case "ASIN":
            e = "Math.asin(" + t + ") / Math.pi * 180";
            break;
          case "ACOS":
            e = "Math.acos(" + t + ") / Math.pi * 180";
            break;
          case "ATAN":
            e = "Math.atan(" + t + ") / Math.pi * 180";
            break;
          default:
            throw Error("Unknown math operator: " + T);
        }
        return [e, A.MULTIPLICATIVE];
      }, B = function(t, L) {
        var T = L.getProcedureName(t.getFieldValue("NAME")), e = "";
        L.STATEMENT_PREFIX && (e += L.injectId(L.STATEMENT_PREFIX, t)), L.STATEMENT_SUFFIX && (e += L.injectId(L.STATEMENT_SUFFIX, t)), e && (e = L.prefixLines(e, L.INDENT));
        var E = "";
        L.INFINITE_LOOP_TRAP && (E = L.prefixLines(L.injectId(L.INFINITE_LOOP_TRAP, t), L.INDENT));
        var O = "";
        t.getInput("STACK") && (O = L.statementToCode(
          t,
          "STACK"
        ));
        var I = "";
        t.getInput("RETURN") && (I = L.valueToCode(t, "RETURN", A.NONE) || "");
        var R = "";
        O && I && (R = e), I && (I = L.INDENT + "return " + I + `;
`);
        var i = I ? "dynamic" : "void", S = [], o = t.getVarModels();
        for (let P = 0; P < o.length; P++) S[P] = L.getVariableName(o[P].getId());
        return e = i + " " + T + "(" + S.join(", ") + `) {
` + e + E + O + R + I + "}", e = L.scrub_(t, e), L.definitions_["%" + T] = e, null;
      }, c = function(t, L) {
        L.definitions_.import_dart_html = "import 'dart:html' as Html;";
        var T = "Html.window.prompt(" + (t.getField("TEXT") ? L.quote_(t.getFieldValue("TEXT")) : L.valueToCode(t, "TEXT", A.NONE) || "''") + ", '')";
        return t.getFieldValue("TYPE") === "NUMBER" && (L.definitions_.import_dart_math = "import 'dart:math' as Math;", T = "Math.parseDouble(" + T + ")"), [T, A.UNARY_POSTFIX];
      }, d = function(t, L) {
        return [L.getVariableName(t.getFieldValue("VAR")), A.ATOMIC];
      }, l = function(t, L) {
        var T = L.valueToCode(t, "VALUE", A.ASSIGNMENT) || "0";
        return L.getVariableName(t.getFieldValue("VAR")) + " = " + T + `;
`;
      }, A, N = A || (A = {});
      N[N.ATOMIC = 0] = "ATOMIC", N[N.UNARY_POSTFIX = 1] = "UNARY_POSTFIX", N[N.UNARY_PREFIX = 2] = "UNARY_PREFIX", N[N.MULTIPLICATIVE = 3] = "MULTIPLICATIVE", N[N.ADDITIVE = 4] = "ADDITIVE", N[N.SHIFT = 5] = "SHIFT", N[N.BITWISE_AND = 6] = "BITWISE_AND", N[N.BITWISE_XOR = 7] = "BITWISE_XOR", N[N.BITWISE_OR = 8] = "BITWISE_OR", N[N.RELATIONAL = 9] = "RELATIONAL", N[N.EQUALITY = 10] = "EQUALITY", N[N.LOGICAL_AND = 11] = "LOGICAL_AND", N[N.LOGICAL_OR = 12] = "LOGICAL_OR", N[N.IF_NULL = 13] = "IF_NULL", N[N.CONDITIONAL = 14] = "CONDITIONAL", N[N.CASCADE = 15] = "CASCADE", N[N.ASSIGNMENT = 16] = "ASSIGNMENT", N[N.NONE = 99] = "NONE";
      var n = class extends s.zq {
        constructor(t = "Dart") {
          super(t), this.isInitialized = !1;
          for (let L in A) t = A[L], typeof t != "string" && (this["ORDER_" + L] = t);
          this.addReservedWords("assert,break,case,catch,class,const,continue,default,do,else,enum,extends,false,final,finally,for,if,in,is,new,null,rethrow,return,super,switch,this,throw,true,try,var,void,while,with,print,identityHashCode,identical,BidirectionalIterator,Comparable,double,Function,int,Invocation,Iterable,Iterator,List,Map,Match,num,Pattern,RegExp,Set,StackTrace,String,StringSink,Type,bool,DateTime,Deprecated,Duration,Expando,Null,Object,RuneIterator,Runes,Stopwatch,StringBuffer,Symbol,Uri,Comparator,AbstractClassInstantiationError,ArgumentError,AssertionError,CastError,ConcurrentModificationError,CyclicInitializationError,Error,Exception,FallThroughError,FormatException,IntegerDivisionByZeroException,NoSuchMethodError,NullThrownError,OutOfMemoryError,RangeError,StackOverflowError,StateError,TypeError,UnimplementedError,UnsupportedError");
        }
        init(t) {
          super.init(t), this.nameDB_ ? this.nameDB_.reset() : this.nameDB_ = new s.Cj(this.RESERVED_WORDS_), this.nameDB_.setVariableMap(t.getVariableMap()), this.nameDB_.populateVariables(t), this.nameDB_.populateProcedures(t);
          var L = [], T = s.Cd(t);
          for (let e = 0; e < T.length; e++) L.push(this.nameDB_.getName(T[e], s.P.DEVELOPER_VARIABLE));
          for (t = s.Bd(t), T = 0; T < t.length; T++) L.push(this.nameDB_.getName(t[T].getId(), s.P.VARIABLE));
          L.length && (this.definitions_.variables = "var " + L.join(", ") + ";"), this.isInitialized = !0;
        }
        finish(t) {
          t && (t = this.prefixLines(t, this.INDENT)), t = `main() {
` + t + "}";
          var L = [], T = [];
          for (let e in this.definitions_) {
            let E = this.definitions_[e];
            E.match(/^import\s/) ? L.push(E) : T.push(E);
          }
          return t = super.finish(t), this.isInitialized = !1, this.nameDB_.reset(), (L.join(`
`) + `

` + T.join(`

`)).replace(/\n\n+/g, `

`).replace(/\n*$/, `


`) + t;
        }
        scrubNakedValue(t) {
          return t + `;
`;
        }
        quote_(t) {
          return t = t.replace(/\\/g, "\\\\").replace(/\n/g, `\\
`).replace(/\$/g, "\\$").replace(/'/g, "\\'"), "'" + t + "'";
        }
        multiline_quote_(t) {
          return t.split(/\n/g).map(this.quote_).join(` + '\\n' + 
`);
        }
        scrub_(t, L, T = !1) {
          var e = "";
          if (!t.outputConnection || !t.outputConnection.targetConnection) {
            var E = t.getCommentText();
            E && (E = s.yf(E, this.COMMENT_WRAP - 3), e = "getProcedureDef" in t ? e + this.prefixLines(E + `
`, "/// ") : e + this.prefixLines(E + `
`, "// "));
            for (let O = 0; O < t.inputList.length; O++) t.inputList[O].type === s.je.VALUE && (E = t.inputList[O].connection.targetBlock()) && (E = this.allNestedComments(E)) && (e += this.prefixLines(E, "// "));
          }
          return t = t.nextConnection && t.nextConnection.targetBlock(), T = T ? "" : this.blockToCode(t), e + L + T;
        }
        getAdjusted(t, L, T = 0, e = !1, E = A.NONE) {
          t.workspace.options.oneBasedIndex && T--;
          var O = t.workspace.options.oneBasedIndex ? "1" : "0", I = E;
          return T ? I = A.ADDITIVE : e && (I = A.UNARY_PREFIX), t = this.valueToCode(t, L, I) || O, T === 0 && !e ? t : s.zf(t) ? (t = String(Number(t) + T), e && (t = String(-Number(t))), t) : (T > 0 ? t = `${t} + ${T}` : T < 0 && (t = `${t} - ${-T}`), e && (t = T ? `-(${t})` : `-${t}`), Math.floor(E) >= Math.floor(I) && (t = `(${t})`), t);
        }
      }, r = {};
      r.controls_if = U, r.controls_ifelse = U, r.logic_boolean = function(t) {
        return [t.getFieldValue("BOOL") === "TRUE" ? "true" : "false", A.ATOMIC];
      }, r.logic_compare = function(t, L) {
        var T = { EQ: "==", NEQ: "!=", LT: "<", LTE: "<=", GT: ">", GTE: ">=" }[t.getFieldValue("OP")], e = T === "==" || T === "!=" ? A.EQUALITY : A.RELATIONAL, E = L.valueToCode(t, "A", e) || "0";
        return t = L.valueToCode(t, "B", e) || "0", [E + " " + T + " " + t, e];
      }, r.logic_negate = function(t, L) {
        var T = A.UNARY_PREFIX;
        return ["!" + (L.valueToCode(t, "BOOL", T) || "true"), T];
      }, r.logic_null = function() {
        return ["null", A.ATOMIC];
      }, r.logic_operation = function(t, L) {
        var T = t.getFieldValue("OP") === "AND" ? "&&" : "||", e = T === "&&" ? A.LOGICAL_AND : A.LOGICAL_OR, E = L.valueToCode(t, "A", e);
        return t = L.valueToCode(t, "B", e), E || t ? (L = T === "&&" ? "true" : "false", E || (E = L), t || (t = L)) : t = E = "false", [E + " " + T + " " + t, e];
      }, r.logic_ternary = function(t, L) {
        var T = L.valueToCode(t, "IF", A.CONDITIONAL) || "false", e = L.valueToCode(t, "THEN", A.CONDITIONAL) || "null";
        return t = L.valueToCode(t, "ELSE", A.CONDITIONAL) || "null", [T + " ? " + e + " : " + t, A.CONDITIONAL];
      };
      var M = { controls_flow_statements: function(t, L) {
        var T = "";
        if (L.STATEMENT_PREFIX && (T += L.injectId(L.STATEMENT_PREFIX, t)), L.STATEMENT_SUFFIX && (T += L.injectId(L.STATEMENT_SUFFIX, t)), L.STATEMENT_PREFIX) {
          let e = t.getSurroundLoop();
          e && !e.suppressPrefixSuffix && (T += L.injectId(L.STATEMENT_PREFIX, e));
        }
        switch (t.getFieldValue("FLOW")) {
          case "BREAK":
            return T + `break;
`;
          case "CONTINUE":
            return T + `continue;
`;
        }
        throw Error("Unknown flow statement.");
      }, controls_for: function(t, L) {
        var T = L.getVariableName(t.getFieldValue("VAR")), e = L.valueToCode(t, "FROM", A.ASSIGNMENT) || "0", E = L.valueToCode(t, "TO", A.ASSIGNMENT) || "0", O = L.valueToCode(t, "BY", A.ASSIGNMENT) || "1", I = L.statementToCode(t, "DO");
        if (I = L.addLoopTrap(I, t), s.zf(e) && s.zf(E) && s.zf(O)) L = Number(e) <= Number(E), t = "for (" + T + " = " + e + "; " + T + (L ? " <= " : " >= ") + E + "; " + T, T = Math.abs(Number(O)), t = T === 1 ? t + (L ? "++" : "--") : t + ((L ? " += " : " -= ") + T), t += `) {
` + I + `}
`;
        else {
          t = "";
          let R = e;
          e.match(/^\w+$/) || s.zf(e) || (R = L.nameDB_.getDistinctName(T + "_start", s.P.VARIABLE), t += "var " + R + " = " + e + `;
`), e = E, E.match(/^\w+$/) || s.zf(E) || (e = L.nameDB_.getDistinctName(T + "_end", s.P.VARIABLE), t += "var " + e + " = " + E + `;
`), E = L.nameDB_.getDistinctName(T + "_inc", s.P.VARIABLE), t += "num " + E + " = ", t = s.zf(O) ? t + (Math.abs(Number(O)) + `;
`) : t + ("(" + O + `).abs();
`), t += "if (" + R + " > " + e + `) {
`, t += L.INDENT + E + " = -" + E + `;
`, t = t + `}
for (` + (T + " = " + R + "; " + E + " >= 0 ? " + T + " <= " + e + " : " + T + " >= " + e + "; " + T + " += " + E + `) {
` + I + `}
`);
        }
        return t;
      }, controls_forEach: function(t, L) {
        var T = L.getVariableName(t.getFieldValue("VAR")), e = L.valueToCode(
          t,
          "LIST",
          A.ASSIGNMENT
        ) || "[]", E = L.statementToCode(t, "DO");
        return E = L.addLoopTrap(E, t), "for (var " + T + " in " + e + `) {
` + E + `}
`;
      } };
      M.controls_repeat = D, M.controls_repeat_ext = D, M.controls_whileUntil = function(t, L) {
        var T = t.getFieldValue("MODE") === "UNTIL", e = L.valueToCode(t, "BOOL", T ? A.UNARY_PREFIX : A.NONE) || "false", E = L.statementToCode(t, "DO");
        return E = L.addLoopTrap(E, t), T && (e = "!" + e), "while (" + e + `) {
` + E + `}
`;
      };
      var F = { math_arithmetic: function(t, L) {
        var T = { ADD: [" + ", A.ADDITIVE], MINUS: [" - ", A.ADDITIVE], MULTIPLY: [" * ", A.MULTIPLICATIVE], DIVIDE: [" / ", A.MULTIPLICATIVE], POWER: [null, A.NONE] }[t.getFieldValue("OP")], e = T[0];
        T = T[1];
        var E = L.valueToCode(t, "A", T) || "0";
        return t = L.valueToCode(t, "B", T) || "0", e ? [E + e + t, T] : (L.definitions_.import_dart_math = "import 'dart:math' as Math;", ["Math.pow(" + E + ", " + t + ")", A.UNARY_POSTFIX]);
      }, math_atan2: function(t, L) {
        L.definitions_.import_dart_math = "import 'dart:math' as Math;";
        var T = L.valueToCode(t, "X", A.NONE) || "0";
        return ["Math.atan2(" + (L.valueToCode(t, "Y", A.NONE) || "0") + ", " + T + ") / Math.pi * 180", A.MULTIPLICATIVE];
      }, math_change: function(t, L) {
        var T = L.valueToCode(t, "DELTA", A.ADDITIVE) || "0";
        return t = L.getVariableName(t.getFieldValue("VAR")), t + " = (" + t + " is num ? " + t + " : 0) + " + T + `;
`;
      }, math_constant: function(t, L) {
        var T = { PI: ["Math.pi", A.UNARY_POSTFIX], E: ["Math.e", A.UNARY_POSTFIX], GOLDEN_RATIO: ["(1 + Math.sqrt(5)) / 2", A.MULTIPLICATIVE], SQRT2: ["Math.sqrt2", A.UNARY_POSTFIX], SQRT1_2: [
          "Math.sqrt1_2",
          A.UNARY_POSTFIX
        ], INFINITY: ["double.infinity", A.ATOMIC] };
        return t = t.getFieldValue("CONSTANT"), t !== "INFINITY" && (L.definitions_.import_dart_math = "import 'dart:math' as Math;"), T[t];
      }, math_constrain: function(t, L) {
        L.definitions_.import_dart_math = "import 'dart:math' as Math;";
        var T = L.valueToCode(t, "VALUE", A.NONE) || "0", e = L.valueToCode(t, "LOW", A.NONE) || "0";
        return t = L.valueToCode(t, "HIGH", A.NONE) || "double.infinity", ["Math.min(Math.max(" + T + ", " + e + "), " + t + ")", A.UNARY_POSTFIX];
      }, math_modulo: function(t, L) {
        var T = L.valueToCode(t, "DIVIDEND", A.MULTIPLICATIVE) || "0";
        return t = L.valueToCode(t, "DIVISOR", A.MULTIPLICATIVE) || "0", [T + " % " + t, A.MULTIPLICATIVE];
      }, math_number: function(t) {
        return t = Number(t.getFieldValue("NUM")), t === 1 / 0 ? ["double.infinity", A.UNARY_POSTFIX] : t === -1 / 0 ? ["-double.infinity", A.UNARY_PREFIX] : [String(t), t < 0 ? A.UNARY_PREFIX : A.ATOMIC];
      }, math_number_property: function(t, L) {
        var T = { EVEN: [" % 2 == 0", A.MULTIPLICATIVE, A.EQUALITY], ODD: [" % 2 == 1", A.MULTIPLICATIVE, A.EQUALITY], WHOLE: [
          " % 1 == 0",
          A.MULTIPLICATIVE,
          A.EQUALITY
        ], POSITIVE: [" > 0", A.RELATIONAL, A.RELATIONAL], NEGATIVE: [" < 0", A.RELATIONAL, A.RELATIONAL], DIVISIBLE_BY: [null, A.MULTIPLICATIVE, A.EQUALITY], PRIME: [null, A.NONE, A.UNARY_POSTFIX] }, e = t.getFieldValue("PROPERTY"), [E, O, I] = T[e];
        if (T = L.valueToCode(t, "NUMBER_TO_CHECK", O) || "0", e === "PRIME") L.definitions_.import_dart_math = "import 'dart:math' as Math;", t = L.provideFunction_("math_isPrime", `
bool ${L.FUNCTION_NAME_PLACEHOLDER_}(n) {
  // https://en.wikipedia.org/wiki/Primality_test#Naive_methods
  if (n == 2 || n == 3) {
    return true;
  }
  // False if n is null, negative, is 1, or not whole.
  // And false if n is divisible by 2 or 3.
  if (n == null || n <= 1 || n % 1 != 0 || n % 2 == 0 || n % 3 == 0) {
    return false;
  }
  // Check all the numbers of form 6k +/- 1, up to sqrt(n).
  for (var x = 6; x <= Math.sqrt(n) + 1; x += 6) {
    if (n % (x - 1) == 0 || n % (x + 1) == 0) {
      return false;
    }
  }
  return true;
}
`) + "(" + T + ")";
        else if (e === "DIVISIBLE_BY") {
          if (t = L.valueToCode(t, "DIVISOR", A.MULTIPLICATIVE) || "0", t === "0") return ["false", A.ATOMIC];
          t = T + " % " + t + " == 0";
        } else t = T + E;
        return [t, I];
      }, math_on_list: function(t, L) {
        var T = t.getFieldValue("OP");
        switch (t = L.valueToCode(t, "LIST", A.NONE) || "[]", T) {
          case "SUM":
            L = L.provideFunction_("math_sum", `
num ${L.FUNCTION_NAME_PLACEHOLDER_}(List<num> myList) {
  num sumVal = 0;
  myList.forEach((num entry) {sumVal += entry;});
  return sumVal;
}
`) + "(" + t + ")";
            break;
          case "MIN":
            L.definitions_.import_dart_math = "import 'dart:math' as Math;", L = L.provideFunction_("math_min", `
num ${L.FUNCTION_NAME_PLACEHOLDER_}(List<num> myList) {
  if (myList.isEmpty) return null;
  num minVal = myList[0];
  myList.forEach((num entry) {minVal = Math.min(minVal, entry);});
  return minVal;
}
`) + "(" + t + ")";
            break;
          case "MAX":
            L.definitions_.import_dart_math = "import 'dart:math' as Math;", L = L.provideFunction_("math_max", `
num ${L.FUNCTION_NAME_PLACEHOLDER_}(List<num> myList) {
  if (myList.isEmpty) return null;
  num maxVal = myList[0];
  myList.forEach((num entry) {maxVal = Math.max(maxVal, entry);});
  return maxVal;
}
`) + "(" + t + ")";
            break;
          case "AVERAGE":
            L = L.provideFunction_("math_mean", `
num ${L.FUNCTION_NAME_PLACEHOLDER_}(List myList) {
  // First filter list for numbers only.
  List localList = new List.from(myList);
  localList.removeWhere((a) => a is! num);
  if (localList.isEmpty) return null;
  num sumVal = 0;
  localList.forEach((var entry) {sumVal += entry;});
  return sumVal / localList.length;
}
`) + "(" + t + ")";
            break;
          case "MEDIAN":
            L = L.provideFunction_("math_median", `
num ${L.FUNCTION_NAME_PLACEHOLDER_}(List myList) {
  // First filter list for numbers only, then sort, then return middle value
  // or the average of two middle values if list has an even number of elements.
  List localList = new List.from(myList);
  localList.removeWhere((a) => a is! num);
  if (localList.isEmpty) return null;
  localList.sort((a, b) => (a - b));
  int index = localList.length ~/ 2;
  if (localList.length % 2 == 1) {
    return localList[index];
  } else {
    return (localList[index - 1] + localList[index]) / 2;
  }
}
`) + "(" + t + ")";
            break;
          case "MODE":
            L.definitions_.import_dart_math = "import 'dart:math' as Math;", L = L.provideFunction_("math_modes", `
List ${L.FUNCTION_NAME_PLACEHOLDER_}(List values) {
  List modes = [];
  List counts = [];
  int maxCount = 0;
  for (int i = 0; i < values.length; i++) {
    var value = values[i];
    bool found = false;
    int thisCount;
    for (int j = 0; j < counts.length; j++) {
      if (counts[j][0] == value) {
        thisCount = ++counts[j][1];
        found = true;
        break;
      }
    }
    if (!found) {
      counts.add([value, 1]);
      thisCount = 1;
    }
    maxCount = Math.max(thisCount, maxCount);
  }
  for (int j = 0; j < counts.length; j++) {
    if (counts[j][1] == maxCount) {
        modes.add(counts[j][0]);
    }
  }
  return modes;
}
`) + "(" + t + ")";
            break;
          case "STD_DEV":
            L.definitions_.import_dart_math = "import 'dart:math' as Math;", L = L.provideFunction_("math_standard_deviation", `
num ${L.FUNCTION_NAME_PLACEHOLDER_}(List myList) {
  // First filter list for numbers only.
  List numbers = new List.from(myList);
  numbers.removeWhere((a) => a is! num);
  if (numbers.isEmpty) return null;
  num n = numbers.length;
  num sum = 0;
  numbers.forEach((x) => sum += x);
  num mean = sum / n;
  num sumSquare = 0;
  numbers.forEach((x) => sumSquare += Math.pow(x - mean, 2));
  return Math.sqrt(sumSquare / n);
}
`) + "(" + t + ")";
            break;
          case "RANDOM":
            L.definitions_.import_dart_math = "import 'dart:math' as Math;", L = L.provideFunction_("math_random_item", `
dynamic ${L.FUNCTION_NAME_PLACEHOLDER_}(List myList) {
  int x = new Math.Random().nextInt(myList.length);
  return myList[x];
}
`) + "(" + t + ")";
            break;
          default:
            throw Error("Unknown operator: " + T);
        }
        return [L, A.UNARY_POSTFIX];
      }, math_random_float: function(t, L) {
        return L.definitions_.import_dart_math = "import 'dart:math' as Math;", ["new Math.Random().nextDouble()", A.UNARY_POSTFIX];
      }, math_random_int: function(t, L) {
        L.definitions_.import_dart_math = "import 'dart:math' as Math;";
        var T = L.valueToCode(t, "FROM", A.NONE) || "0";
        return t = L.valueToCode(t, "TO", A.NONE) || "0", [L.provideFunction_("math_random_int", `
int ${L.FUNCTION_NAME_PLACEHOLDER_}(num a, num b) {
  if (a > b) {
    // Swap a and b to ensure a is smaller.
    num c = a;
    a = b;
    b = c;
  }
  return new Math.Random().nextInt(b - a + 1) + a;
}
`) + "(" + T + ", " + t + ")", A.UNARY_POSTFIX];
      } };
      F.math_round = u, F.math_single = u, F.math_trig = u;
      var h = { procedures_callnoreturn: function(t, L) {
        return L.forBlock.procedures_callreturn(t, L)[0] + `;
`;
      }, procedures_callreturn: function(t, L) {
        var T = L.getProcedureName(t.getFieldValue("NAME")), e = [], E = t.getVarModels();
        for (let O = 0; O < E.length; O++) e[O] = L.valueToCode(t, "ARG" + O, A.NONE) || "null";
        return [T + "(" + e.join(", ") + ")", A.UNARY_POSTFIX];
      } };
      h.procedures_defnoreturn = B, h.procedures_defreturn = B, h.procedures_ifreturn = function(t, L) {
        var T = "if (" + (L.valueToCode(t, "CONDITION", A.NONE) || "false") + `) {
`;
        return L.STATEMENT_SUFFIX && (T += L.prefixLines(L.injectId(L.STATEMENT_SUFFIX, t), L.INDENT)), t.hasReturnValue_ ? (t = L.valueToCode(t, "VALUE", A.NONE) || "null", T += L.INDENT + "return " + t + `;
`) : T += L.INDENT + `return;
`, T + `}
`;
      };
      var f = { text: function(t, L) {
        return [L.quote_(t.getFieldValue("TEXT")), A.ATOMIC];
      }, text_append: function(t, L) {
        var T = L.getVariableName(t.getFieldValue("VAR"));
        return t = L.valueToCode(t, "TEXT", A.NONE) || "''", T + " = [" + T + ", " + t + `].join();
`;
      }, text_changeCase: function(t, L) {
        var T = { UPPERCASE: ".toUpperCase()", LOWERCASE: ".toLowerCase()", TITLECASE: null }[t.getFieldValue("CASE")];
        return t = L.valueToCode(t, "TEXT", T ? A.UNARY_POSTFIX : A.NONE) || "''", [T ? t + T : L.provideFunction_("text_toTitleCase", `
String ${L.FUNCTION_NAME_PLACEHOLDER_}(String str) {
  RegExp exp = new RegExp(r'\\b');
  List<String> list = str.split(exp);
  final title = new StringBuffer();
  for (String part in list) {
    if (part.length > 0) {
      title.write(part[0].toUpperCase());
      if (part.length > 0) {
        title.write(part.substring(1).toLowerCase());
      }
    }
  }
  return title.toString();
}
`) + "(" + t + ")", A.UNARY_POSTFIX];
      }, text_charAt: function(t, L) {
        var T = t.getFieldValue("WHERE") || "FROM_START", e = L.valueToCode(t, "VALUE", T === "FIRST" || T === "FROM_START" ? A.UNARY_POSTFIX : A.NONE) || "''";
        switch (T) {
          case "FIRST":
            return [e + "[0]", A.UNARY_POSTFIX];
          case "FROM_START":
            return t = L.getAdjusted(t, "AT"), [e + "[" + t + "]", A.UNARY_POSTFIX];
          case "LAST":
          case "FROM_END":
            return t = T === "LAST" ? 1 : L.getAdjusted(t, "AT", 1), [`${L.provideFunction_("text_get_from_end", `
String ${L.FUNCTION_NAME_PLACEHOLDER_}(String text, num x) {
  return text[text.length - x];
}
`)}(${e}, ${t})`, A.UNARY_POSTFIX];
          case "RANDOM":
            return L.definitions_.import_dart_math = "import 'dart:math' as Math;", [L.provideFunction_("text_random_letter", `
String ${L.FUNCTION_NAME_PLACEHOLDER_}(String text) {
  int x = new Math.Random().nextInt(text.length);
  return text[x];
}
`) + "(" + e + ")", A.UNARY_POSTFIX];
        }
        throw Error("Unhandled option (text_charAt).");
      }, text_count: function(t, L) {
        var T = L.valueToCode(t, "TEXT", A.NONE) || "''";
        return t = L.valueToCode(t, "SUB", A.NONE) || "''", [L.provideFunction_("text_count", `
int ${L.FUNCTION_NAME_PLACEHOLDER_}(String haystack, String needle) {
  if (needle.length == 0) {
    return haystack.length + 1;
  }
  int index = 0;
  int count = 0;
  while (index != -1) {
    index = haystack.indexOf(needle, index);
    if (index != -1) {
      count++;
     index += needle.length;
    }
  }
  return count;
}
`) + "(" + T + ", " + t + ")", A.UNARY_POSTFIX];
      }, text_getSubstring: function(t, L) {
        var T = t.getFieldValue("WHERE1"), e = t.getFieldValue("WHERE2"), E = T !== "FROM_END" && e === "FROM_START", O = L.valueToCode(t, "STRING", E ? A.UNARY_POSTFIX : A.NONE) || "''";
        if (T === "FIRST" && e === "LAST") return [O, A.NONE];
        if (O.match(/^'?\w+'?$/) || E) {
          switch (T) {
            case "FROM_START":
              T = L.getAdjusted(t, "AT1");
              break;
            case "FROM_END":
              T = L.getAdjusted(t, "AT1", 1, !1, A.ADDITIVE), T = O + ".length - " + T;
              break;
            case "FIRST":
              T = "0";
              break;
            default:
              throw Error("Unhandled option (text_getSubstring).");
          }
          switch (e) {
            case "FROM_START":
              var I = L.getAdjusted(t, "AT2", 1);
              break;
            case "FROM_END":
              I = L.getAdjusted(t, "AT2", 0, !1, A.ADDITIVE), I = O + ".length - " + I;
              break;
            case "LAST":
              break;
            default:
              throw Error("Unhandled option (text_getSubstring).");
          }
          L = e === "LAST" ? O + ".substring(" + T + ")" : O + ".substring(" + T + ", " + I + ")";
        } else I = L.getAdjusted(t, "AT1"), t = L.getAdjusted(t, "AT2"), L = L.provideFunction_("text_get_substring", `
String ${L.FUNCTION_NAME_PLACEHOLDER_}(String text, String where1, num at1, String where2, num at2) {
  int getAt(String where, num at) {
    if (where == 'FROM_END') {
      at = text.length - 1 - at;
    } else if (where == 'FIRST') {
      at = 0;
    } else if (where == 'LAST') {
      at = text.length - 1;
    } else if (where != 'FROM_START') {
      throw 'Unhandled option (text_getSubstring).';
    }
    return at;
  }
  at1 = getAt(where1, at1);
  at2 = getAt(where2, at2) + 1;
  return text.substring(at1, at2);
}
`) + "(" + O + ", '" + T + "', " + I + ", '" + e + "', " + t + ")";
        return [L, A.UNARY_POSTFIX];
      }, text_indexOf: function(t, L) {
        var T = t.getFieldValue("END") === "FIRST" ? "indexOf" : "lastIndexOf", e = L.valueToCode(t, "FIND", A.NONE) || "''";
        return L = (L.valueToCode(t, "VALUE", A.UNARY_POSTFIX) || "''") + "." + T + "(" + e + ")", t.workspace.options.oneBasedIndex ? [L + " + 1", A.ADDITIVE] : [L, A.UNARY_POSTFIX];
      }, text_isEmpty: function(t, L) {
        return [(L.valueToCode(t, "VALUE", A.UNARY_POSTFIX) || "''") + ".isEmpty", A.UNARY_POSTFIX];
      }, text_join: function(t, L) {
        switch (t.itemCount_) {
          case 0:
            return [
              "''",
              A.ATOMIC
            ];
          case 1:
            return [(L.valueToCode(t, "ADD0", A.UNARY_POSTFIX) || "''") + ".toString()", A.UNARY_POSTFIX];
          default:
            let T = Array(t.itemCount_);
            for (let e = 0; e < t.itemCount_; e++) T[e] = L.valueToCode(t, "ADD" + e, A.NONE) || "''";
            return ["[" + T.join(",") + "].join()", A.UNARY_POSTFIX];
        }
      }, text_length: function(t, L) {
        return [(L.valueToCode(t, "VALUE", A.UNARY_POSTFIX) || "''") + ".length", A.UNARY_POSTFIX];
      }, text_print: function(t, L) {
        return "print(" + (L.valueToCode(t, "TEXT", A.NONE) || "''") + `);
`;
      } };
      f.text_prompt = c, f.text_prompt_ext = c, f.text_replace = function(t, L) {
        var T = L.valueToCode(t, "TEXT", A.UNARY_POSTFIX) || "''", e = L.valueToCode(t, "FROM", A.NONE) || "''";
        return t = L.valueToCode(t, "TO", A.NONE) || "''", [T + ".replaceAll(" + e + ", " + t + ")", A.UNARY_POSTFIX];
      }, f.text_reverse = function(t, L) {
        return ["new String.fromCharCodes(" + (L.valueToCode(t, "TEXT", A.UNARY_POSTFIX) || "''") + ".runes.toList().reversed)", A.UNARY_PREFIX];
      }, f.text_trim = function(t, L) {
        var T = { LEFT: ".replaceFirst(new RegExp(r'^\\s+'), '')", RIGHT: ".replaceFirst(new RegExp(r'\\s+$'), '')", BOTH: ".trim()" }[t.getFieldValue("MODE")];
        return [(L.valueToCode(t, "TEXT", A.UNARY_POSTFIX) || "''") + T, A.UNARY_POSTFIX];
      };
      var H = {};
      H.variables_get = d, H.variables_set = l;
      var G = {};
      G.variables_get_dynamic = d, G.variables_set_dynamic = l;
      var v = new n();
      v.addReservedWords("Html,Math");
      var V = Object.assign({}, { lists_create_empty: function() {
        return ["[]", A.ATOMIC];
      }, lists_create_with: function(t, L) {
        var T = Array(t.itemCount_);
        for (let e = 0; e < t.itemCount_; e++) T[e] = L.valueToCode(t, "ADD" + e, A.NONE) || "null";
        return ["[" + T.join(", ") + "]", A.ATOMIC];
      }, lists_getIndex: function(t, L) {
        function T() {
          var I = L.nameDB_.getDistinctName("tmp_list", s.P.VARIABLE), R = "List " + I + " = " + O + `;
`;
          return O = I, R;
        }
        var e = t.getFieldValue("MODE") || "GET", E = t.getFieldValue("WHERE") || "FROM_START", O = L.valueToCode(t, "VALUE", E === "RANDOM" || E === "FROM_END" ? A.NONE : A.UNARY_POSTFIX) || "[]";
        if ((E !== "RANDOM" || e !== "REMOVE") && E !== "FROM_END" || O.match(/^\w+$/)) switch (E) {
          case "FIRST":
            if (e === "GET") return [O + ".first", A.UNARY_POSTFIX];
            if (e === "GET_REMOVE") return [O + ".removeAt(0)", A.UNARY_POSTFIX];
            if (e === "REMOVE") return O + `.removeAt(0);
`;
            break;
          case "LAST":
            if (e === "GET") return [O + ".last", A.UNARY_POSTFIX];
            if (e === "GET_REMOVE") return [O + ".removeLast()", A.UNARY_POSTFIX];
            if (e === "REMOVE") return O + `.removeLast();
`;
            break;
          case "FROM_START":
            if (t = L.getAdjusted(t, "AT"), e === "GET") return [O + "[" + t + "]", A.UNARY_POSTFIX];
            if (e === "GET_REMOVE") return [O + ".removeAt(" + t + ")", A.UNARY_POSTFIX];
            if (e === "REMOVE") return O + ".removeAt(" + t + `);
`;
            break;
          case "FROM_END":
            if (t = L.getAdjusted(t, "AT", 1, !1, A.ADDITIVE), e === "GET") return [O + "[" + O + ".length - " + t + "]", A.UNARY_POSTFIX];
            if (e === "GET_REMOVE" || e === "REMOVE") {
              if (t = O + ".removeAt(" + O + ".length - " + t + ")", e === "GET_REMOVE") return [t, A.UNARY_POSTFIX];
              if (e === "REMOVE") return t + `;
`;
            }
            break;
          case "RANDOM":
            if (L.definitions_.import_dart_math = "import 'dart:math' as Math;", e === "REMOVE") return e = L.nameDB_.getDistinctName("tmp_x", s.P.VARIABLE), "int " + e + " = new Math.Random().nextInt(" + O + `.length);
` + (O + ".removeAt(" + e + `);
`);
            if (e === "GET") return [L.provideFunction_("lists_get_random_item", `
dynamic ${L.FUNCTION_NAME_PLACEHOLDER_}(List my_list) {
  int x = new Math.Random().nextInt(my_list.length);
  return my_list[x];
}
`) + "(" + O + ")", A.UNARY_POSTFIX];
            if (e === "GET_REMOVE") return [L.provideFunction_("lists_remove_random_item", `
dynamic ${L.FUNCTION_NAME_PLACEHOLDER_}(List my_list) {
  int x = new Math.Random().nextInt(my_list.length);
  return my_list.removeAt(x);
}
`) + "(" + O + ")", A.UNARY_POSTFIX];
        }
        else {
          if (E === "RANDOM") return L.definitions_.import_dart_math = "import 'dart:math' as Math;", e = T(), t = L.nameDB_.getDistinctName("tmp_x", s.P.VARIABLE), e + ("int " + t + " = new Math.Random().nextInt(" + O + `.length);
`) + (O + ".removeAt(" + t + `);
`);
          if (e === "REMOVE") return e = L.getAdjusted(t, "AT", 1, !1, A.ADDITIVE), T() + (O + ".removeAt(" + O + ".length - " + e + `);
`);
          if (e === "GET") return e = L.getAdjusted(t, "AT", 1), [L.provideFunction_("lists_get_from_end", `
dynamic ${L.FUNCTION_NAME_PLACEHOLDER_}(List my_list, num x) {
  x = my_list.length - x;
  return my_list[x];
}
`) + "(" + O + ", " + e + ")", A.UNARY_POSTFIX];
          if (e === "GET_REMOVE") return e = L.getAdjusted(t, "AT", 1), [L.provideFunction_("lists_remove_from_end", `
dynamic ${L.FUNCTION_NAME_PLACEHOLDER_}(List my_list, num x) {
  x = my_list.length - x;
  return my_list.removeAt(x);
}
`) + "(" + O + ", " + e + ")", A.UNARY_POSTFIX];
        }
        throw Error("Unhandled combination (lists_getIndex).");
      }, lists_getSublist: function(t, L) {
        var T = L.valueToCode(t, "LIST", A.UNARY_POSTFIX) || "[]", e = t.getFieldValue("WHERE1"), E = t.getFieldValue("WHERE2");
        if (T.match(/^\w+$/) || e !== "FROM_END" && E === "FROM_START") {
          switch (e) {
            case "FROM_START":
              e = L.getAdjusted(t, "AT1");
              break;
            case "FROM_END":
              e = L.getAdjusted(t, "AT1", 1, !1, A.ADDITIVE), e = T + ".length - " + e;
              break;
            case "FIRST":
              e = "0";
              break;
            default:
              throw Error("Unhandled option (lists_getSublist).");
          }
          switch (E) {
            case "FROM_START":
              var O = L.getAdjusted(t, "AT2", 1);
              break;
            case "FROM_END":
              O = L.getAdjusted(t, "AT2", 0, !1, A.ADDITIVE), O = T + ".length - " + O;
              break;
            case "LAST":
              break;
            default:
              throw Error("Unhandled option (lists_getSublist).");
          }
          L = E === "LAST" ? T + ".sublist(" + e + ")" : T + ".sublist(" + e + ", " + O + ")";
        } else O = L.getAdjusted(t, "AT1"), t = L.getAdjusted(t, "AT2"), L = L.provideFunction_("lists_get_sublist", `
List ${L.FUNCTION_NAME_PLACEHOLDER_}(List list, String where1, num at1, String where2, num at2) {
  int getAt(String where, num at) {
    if (where == 'FROM_END') {
      at = list.length - 1 - at;
    } else if (where == 'FIRST') {
      at = 0;
    } else if (where == 'LAST') {
      at = list.length - 1;
    } else if (where != 'FROM_START') {
      throw 'Unhandled option (lists_getSublist).';
    }
    return at;
  }
  at1 = getAt(where1, at1);
  at2 = getAt(where2, at2) + 1;
  return list.sublist(at1, at2);
}
`) + "(" + T + ", '" + e + "', " + O + ", '" + E + "', " + t + ")";
        return [L, A.UNARY_POSTFIX];
      }, lists_indexOf: function(t, L) {
        var T = t.getFieldValue("END") === "FIRST" ? "indexOf" : "lastIndexOf", e = L.valueToCode(t, "FIND", A.NONE) || "''";
        return L = (L.valueToCode(t, "VALUE", A.UNARY_POSTFIX) || "[]") + "." + T + "(" + e + ")", t.workspace.options.oneBasedIndex ? [L + " + 1", A.ADDITIVE] : [L, A.UNARY_POSTFIX];
      }, lists_isEmpty: function(t, L) {
        return [(L.valueToCode(t, "VALUE", A.UNARY_POSTFIX) || "[]") + ".isEmpty", A.UNARY_POSTFIX];
      }, lists_length: function(t, L) {
        return [(L.valueToCode(
          t,
          "VALUE",
          A.UNARY_POSTFIX
        ) || "[]") + ".length", A.UNARY_POSTFIX];
      }, lists_repeat: function(t, L) {
        var T = L.valueToCode(t, "ITEM", A.NONE) || "null";
        return ["new List.filled(" + (L.valueToCode(t, "NUM", A.NONE) || "0") + ", " + T + ")", A.UNARY_POSTFIX];
      }, lists_reverse: function(t, L) {
        return ["new List.from(" + (L.valueToCode(t, "LIST", A.NONE) || "[]") + ".reversed)", A.UNARY_POSTFIX];
      }, lists_setIndex: function(t, L) {
        function T() {
          if (O.match(/^\w+$/)) return "";
          var R = L.nameDB_.getDistinctName("tmp_list", s.P.VARIABLE), i = "List " + R + " = " + O + `;
`;
          return O = R, i;
        }
        var e = t.getFieldValue("MODE") || "GET", E = t.getFieldValue("WHERE") || "FROM_START", O = L.valueToCode(t, "LIST", A.UNARY_POSTFIX) || "[]", I = L.valueToCode(t, "TO", A.ASSIGNMENT) || "null";
        switch (E) {
          case "FIRST":
            if (e === "SET") return O + "[0] = " + I + `;
`;
            if (e === "INSERT") return O + ".insert(0, " + I + `);
`;
            break;
          case "LAST":
            if (e === "SET") return T() + (O + "[" + O + ".length - 1] = " + I + `;
`);
            if (e === "INSERT") return O + ".add(" + I + `);
`;
            break;
          case "FROM_START":
            if (t = L.getAdjusted(t, "AT"), e === "SET") return O + "[" + t + "] = " + I + `;
`;
            if (e === "INSERT") return O + ".insert(" + t + ", " + I + `);
`;
            break;
          case "FROM_END":
            if (t = L.getAdjusted(t, "AT", 1, !1, A.ADDITIVE), E = T(), e === "SET") return E + (O + "[" + O + ".length - " + t + "] = " + I + `;
`);
            if (e === "INSERT") return E + (O + ".insert(" + O + ".length - " + t + ", " + I + `);
`);
            break;
          case "RANDOM":
            if (L.definitions_.import_dart_math = "import 'dart:math' as Math;", t = T(), E = L.nameDB_.getDistinctName("tmp_x", s.P.VARIABLE), t += "int " + E + " = new Math.Random().nextInt(" + O + `.length);
`, e === "SET") return t + (O + "[" + E + "] = " + I + `;
`);
            if (e === "INSERT") return t + (O + ".insert(" + E + ", " + I + `);
`);
        }
        throw Error("Unhandled combination (lists_setIndex).");
      }, lists_sort: function(t, L) {
        var T = L.valueToCode(t, "LIST", A.NONE) || "[]", e = t.getFieldValue("DIRECTION") === "1" ? 1 : -1;
        return t = t.getFieldValue("TYPE"), [L.provideFunction_("lists_sort", `
List ${L.FUNCTION_NAME_PLACEHOLDER_}(List list, String type, int direction) {
  var compareFuncs = {
    'NUMERIC': (a, b) => (direction * a.compareTo(b)).toInt(),
    'TEXT': (a, b) => direction * a.toString().compareTo(b.toString()),
    'IGNORE_CASE':
      (a, b) => direction *
      a.toString().toLowerCase().compareTo(b.toString().toLowerCase())
  };
  list = new List.from(list);
  var compare = compareFuncs[type];
  list.sort(compare);
  return list;
}
`) + "(" + T + ', "' + t + '", ' + e + ")", A.UNARY_POSTFIX];
      }, lists_split: function(t, L) {
        var T = L.valueToCode(t, "INPUT", A.UNARY_POSTFIX);
        if (L = L.valueToCode(t, "DELIM", A.NONE) || "''", t = t.getFieldValue("MODE"), t === "SPLIT") T || (T = "''"), t = "split";
        else if (t === "JOIN") T || (T = "[]"), t = "join";
        else throw Error("Unknown mode: " + t);
        return [T + "." + t + "(" + L + ")", A.UNARY_POSTFIX];
      } }, r, M, F, h, f, H, G);
      for (let t in V) v.forBlock[t] = V[t];
      var X = {};
      return X.DartGenerator = n, X.Order = A, X.dartGenerator = v, s.__chunk_dart = X, s.__chunk_dart.__namespace__ = s, s.__chunk_dart;
    });
  })(J)), J.exports;
}
var q = { exports: {} }, xd = q.exports, L_;
function Yd() {
  return L_ || (L_ = 1, (function(g, C) {
    (function(_, s) {
      g.exports = s(K());
    })(xd, function(_) {
      var s = _.__namespace__, U = function(E, O, I) {
        return O === "FIRST" ? "0" : O === "FROM_END" ? E + ".length - 1 - " + I : O === "LAST" ? E + ".length - 1" : I;
      }, D = function(E, O) {
        var I = 0, R = "";
        O.STATEMENT_PREFIX && (R += O.injectId(O.STATEMENT_PREFIX, E));
        do {
          let i = O.valueToCode(E, "IF" + I, r.NONE) || "false", S = O.statementToCode(E, "DO" + I);
          O.STATEMENT_SUFFIX && (S = O.prefixLines(O.injectId(O.STATEMENT_SUFFIX, E), O.INDENT) + S), R += (I > 0 ? " else " : "") + "if (" + i + `) {
` + S + "}", I++;
        } while (E.getInput("IF" + I));
        return (E.getInput("ELSE") || O.STATEMENT_SUFFIX) && (I = E.getInput("ELSE") ? O.statementToCode(
          E,
          "ELSE"
        ) : "", O.STATEMENT_SUFFIX && (I = O.prefixLines(O.injectId(O.STATEMENT_SUFFIX, E), O.INDENT) + I), R += ` else {
` + I + "}"), R + `
`;
      }, u = function(E, O) {
        var I = E.getField("TIMES") ? String(Number(E.getFieldValue("TIMES"))) : O.valueToCode(E, "TIMES", r.ASSIGNMENT) || "0", R = O.statementToCode(E, "DO");
        R = O.addLoopTrap(R, E), E = "";
        var i = O.nameDB_.getDistinctName("count", s.P.VARIABLE), S = I;
        return I.match(/^\w+$/) || s.zf(I) || (S = O.nameDB_.getDistinctName("repeat_end", s.P.VARIABLE), E += "var " + S + " = " + I + `;
`), E + ("for (var " + i + " = 0; " + i + " < " + S + "; " + i + `++) {
` + R + `}
`);
      }, B = function(E, O) {
        var I = E.getFieldValue("OP");
        if (I === "NEG") return E = O.valueToCode(E, "NUM", r.UNARY_NEGATION) || "0", E[0] === "-" && (E = " " + E), ["-" + E, r.UNARY_NEGATION];
        switch (E = I === "SIN" || I === "COS" || I === "TAN" ? O.valueToCode(E, "NUM", r.DIVISION) || "0" : O.valueToCode(E, "NUM", r.NONE) || "0", I) {
          case "ABS":
            var R = "Math.abs(" + E + ")";
            break;
          case "ROOT":
            R = "Math.sqrt(" + E + ")";
            break;
          case "LN":
            R = "Math.log(" + E + ")";
            break;
          case "EXP":
            R = "Math.exp(" + E + ")";
            break;
          case "POW10":
            R = "Math.pow(10," + E + ")";
            break;
          case "ROUND":
            R = "Math.round(" + E + ")";
            break;
          case "ROUNDUP":
            R = "Math.ceil(" + E + ")";
            break;
          case "ROUNDDOWN":
            R = "Math.floor(" + E + ")";
            break;
          case "SIN":
            R = "Math.sin(" + E + " / 180 * Math.PI)";
            break;
          case "COS":
            R = "Math.cos(" + E + " / 180 * Math.PI)";
            break;
          case "TAN":
            R = "Math.tan(" + E + " / 180 * Math.PI)";
        }
        if (R) return [R, r.FUNCTION_CALL];
        switch (I) {
          case "LOG10":
            R = "Math.log(" + E + ") / Math.log(10)";
            break;
          case "ASIN":
            R = "Math.asin(" + E + ") / Math.PI * 180";
            break;
          case "ACOS":
            R = "Math.acos(" + E + ") / Math.PI * 180";
            break;
          case "ATAN":
            R = "Math.atan(" + E + ") / Math.PI * 180";
            break;
          default:
            throw Error("Unknown math operator: " + I);
        }
        return [R, r.DIVISION];
      }, c = function(E, O) {
        var I = O.getProcedureName(E.getFieldValue("NAME")), R = "";
        O.STATEMENT_PREFIX && (R += O.injectId(O.STATEMENT_PREFIX, E)), O.STATEMENT_SUFFIX && (R += O.injectId(O.STATEMENT_SUFFIX, E)), R && (R = O.prefixLines(R, O.INDENT));
        var i = "";
        O.INFINITE_LOOP_TRAP && (i = O.prefixLines(O.injectId(O.INFINITE_LOOP_TRAP, E), O.INDENT));
        var S = "";
        E.getInput("STACK") && (S = O.statementToCode(E, "STACK"));
        var o = "";
        E.getInput("RETURN") && (o = O.valueToCode(E, "RETURN", r.NONE) || "");
        var P = "";
        S && o && (P = R), o && (o = O.INDENT + "return " + o + `;
`);
        var a = [], p = E.getVarModels();
        for (let m = 0; m < p.length; m++) a[m] = O.getVariableName(p[m].getId());
        return R = "function " + I + "(" + a.join(", ") + `) {
` + R + i + S + P + o + "}", R = O.scrub_(E, R), O.definitions_["%" + I] = R, null;
      }, d = function(E) {
        return v.test(E) ? [E, r.ATOMIC] : ["String(" + E + ")", r.FUNCTION_CALL];
      }, l = function(E, O, I) {
        return O === "FIRST" ? "0" : O === "FROM_END" ? E + ".length - 1 - " + I : O === "LAST" ? E + ".length - 1" : I;
      }, A = function(E, O) {
        return O = "window.prompt(" + (E.getField("TEXT") ? O.quote_(E.getFieldValue("TEXT")) : O.valueToCode(E, "TEXT", r.NONE) || "''") + ")", E.getFieldValue("TYPE") === "NUMBER" && (O = "Number(" + O + ")"), [O, r.FUNCTION_CALL];
      }, N = function(E, O) {
        return [O.getVariableName(E.getFieldValue("VAR")), r.ATOMIC];
      }, n = function(E, O) {
        var I = O.valueToCode(E, "VALUE", r.ASSIGNMENT) || "0";
        return O.getVariableName(E.getFieldValue("VAR")) + " = " + I + `;
`;
      }, r, M = r || (r = {});
      M[M.ATOMIC = 0] = "ATOMIC", M[M.NEW = 1.1] = "NEW", M[M.MEMBER = 1.2] = "MEMBER", M[M.FUNCTION_CALL = 2] = "FUNCTION_CALL", M[M.INCREMENT = 3] = "INCREMENT", M[M.DECREMENT = 3] = "DECREMENT", M[M.BITWISE_NOT = 4.1] = "BITWISE_NOT", M[M.UNARY_PLUS = 4.2] = "UNARY_PLUS", M[M.UNARY_NEGATION = 4.3] = "UNARY_NEGATION", M[M.LOGICAL_NOT = 4.4] = "LOGICAL_NOT", M[M.TYPEOF = 4.5] = "TYPEOF", M[M.VOID = 4.6] = "VOID", M[M.DELETE = 4.7] = "DELETE", M[M.AWAIT = 4.8] = "AWAIT", M[M.EXPONENTIATION = 5] = "EXPONENTIATION", M[M.MULTIPLICATION = 5.1] = "MULTIPLICATION", M[M.DIVISION = 5.2] = "DIVISION", M[M.MODULUS = 5.3] = "MODULUS", M[M.SUBTRACTION = 6.1] = "SUBTRACTION", M[M.ADDITION = 6.2] = "ADDITION", M[M.BITWISE_SHIFT = 7] = "BITWISE_SHIFT", M[M.RELATIONAL = 8] = "RELATIONAL", M[M.IN = 8] = "IN", M[M.INSTANCEOF = 8] = "INSTANCEOF", M[M.EQUALITY = 9] = "EQUALITY", M[M.BITWISE_AND = 10] = "BITWISE_AND", M[M.BITWISE_XOR = 11] = "BITWISE_XOR", M[M.BITWISE_OR = 12] = "BITWISE_OR", M[M.LOGICAL_AND = 13] = "LOGICAL_AND", M[M.LOGICAL_OR = 14] = "LOGICAL_OR", M[M.CONDITIONAL = 15] = "CONDITIONAL", M[M.ASSIGNMENT = 16] = "ASSIGNMENT", M[M.YIELD = 17] = "YIELD", M[M.COMMA = 18] = "COMMA", M[M.NONE = 99] = "NONE";
      var F = class extends s.zq {
        constructor(E = "JavaScript") {
          super(E), this.ORDER_OVERRIDES = [[r.FUNCTION_CALL, r.MEMBER], [r.FUNCTION_CALL, r.FUNCTION_CALL], [r.MEMBER, r.MEMBER], [r.MEMBER, r.FUNCTION_CALL], [r.LOGICAL_NOT, r.LOGICAL_NOT], [r.MULTIPLICATION, r.MULTIPLICATION], [r.ADDITION, r.ADDITION], [r.LOGICAL_AND, r.LOGICAL_AND], [r.LOGICAL_OR, r.LOGICAL_OR]], this.isInitialized = !1;
          for (let O in r) E = r[O], typeof E != "string" && (this["ORDER_" + O] = E);
          this.addReservedWords("break,case,catch,class,const,continue,debugger,default,delete,do,else,export,extends,finally,for,function,if,import,in,instanceof,new,return,super,switch,this,throw,try,typeof,var,void,while,with,yield,enum,implements,interface,let,package,private,protected,public,static,await,null,true,false,arguments," + Object.getOwnPropertyNames(globalThis).join(","));
        }
        init(E) {
          super.init(E), this.nameDB_ ? this.nameDB_.reset() : this.nameDB_ = new s.Cj(this.RESERVED_WORDS_), this.nameDB_.setVariableMap(E.getVariableMap()), this.nameDB_.populateVariables(E), this.nameDB_.populateProcedures(E);
          var O = [], I = s.Cd(E);
          for (let R = 0; R < I.length; R++) O.push(this.nameDB_.getName(I[R], s.P.DEVELOPER_VARIABLE));
          for (E = s.Bd(E), I = 0; I < E.length; I++) O.push(this.nameDB_.getName(E[I].getId(), s.P.VARIABLE));
          O.length && (this.definitions_.variables = "var " + O.join(", ") + ";"), this.isInitialized = !0;
        }
        finish(E) {
          var O = Object.values(this.definitions_);
          return super.finish(E), this.isInitialized = !1, this.nameDB_.reset(), O.join(`

`) + `


` + E;
        }
        scrubNakedValue(E) {
          return E + `;
`;
        }
        quote_(E) {
          return E = E.replace(/\\/g, "\\\\").replace(/\n/g, `\\
`).replace(/'/g, "\\'"), "'" + E + "'";
        }
        multiline_quote_(E) {
          return E.split(/\n/g).map(this.quote_).join(` + '\\n' +
`);
        }
        scrub_(E, O, I = !1) {
          var R = "";
          if (!E.outputConnection || !E.outputConnection.targetConnection) {
            var i = E.getCommentText();
            i && (i = s.yf(i, this.COMMENT_WRAP - 3), R += this.prefixLines(i + `
`, "// "));
            for (let S = 0; S < E.inputList.length; S++) E.inputList[S].type === s.je.VALUE && (i = E.inputList[S].connection.targetBlock()) && (i = this.allNestedComments(i)) && (R += this.prefixLines(i, "// "));
          }
          return E = E.nextConnection && E.nextConnection.targetBlock(), I = I ? "" : this.blockToCode(E), R + O + I;
        }
        getAdjusted(E, O, I = 0, R = !1, i = r.NONE) {
          E.workspace.options.oneBasedIndex && I--;
          var S = E.workspace.options.oneBasedIndex ? "1" : "0", o = i;
          return I > 0 ? o = r.ADDITION : I < 0 ? o = r.SUBTRACTION : R && (o = r.UNARY_NEGATION), E = this.valueToCode(E, O, o) || S, I === 0 && !R ? E : s.zf(E) ? (E = String(Number(E) + I), R && (E = String(-Number(E))), E) : (I > 0 ? E = `${E} + ${I}` : I < 0 && (E = `${E} - ${-I}`), R && (E = I ? `-(${E})` : `-${E}`), Math.floor(i) >= Math.floor(o) && (E = `(${E})`), E);
        }
      }, h = {};
      h.controls_if = D, h.controls_ifelse = D, h.logic_boolean = function(E) {
        return [E.getFieldValue("BOOL") === "TRUE" ? "true" : "false", r.ATOMIC];
      }, h.logic_compare = function(E, O) {
        var I = { EQ: "==", NEQ: "!=", LT: "<", LTE: "<=", GT: ">", GTE: ">=" }[E.getFieldValue("OP")], R = I === "==" || I === "!=" ? r.EQUALITY : r.RELATIONAL, i = O.valueToCode(E, "A", R) || "0";
        return E = O.valueToCode(E, "B", R) || "0", [i + " " + I + " " + E, R];
      }, h.logic_negate = function(E, O) {
        var I = r.LOGICAL_NOT;
        return ["!" + (O.valueToCode(E, "BOOL", I) || "true"), I];
      }, h.logic_null = function() {
        return ["null", r.ATOMIC];
      }, h.logic_operation = function(E, O) {
        var I = E.getFieldValue("OP") === "AND" ? "&&" : "||", R = I === "&&" ? r.LOGICAL_AND : r.LOGICAL_OR, i = O.valueToCode(E, "A", R);
        return E = O.valueToCode(E, "B", R), i || E ? (O = I === "&&" ? "true" : "false", i || (i = O), E || (E = O)) : E = i = "false", [i + " " + I + " " + E, R];
      }, h.logic_ternary = function(E, O) {
        var I = O.valueToCode(E, "IF", r.CONDITIONAL) || "false", R = O.valueToCode(E, "THEN", r.CONDITIONAL) || "null";
        return E = O.valueToCode(E, "ELSE", r.CONDITIONAL) || "null", [I + " ? " + R + " : " + E, r.CONDITIONAL];
      };
      var f = { controls_flow_statements: function(E, O) {
        var I = "";
        if (O.STATEMENT_PREFIX && (I += O.injectId(O.STATEMENT_PREFIX, E)), O.STATEMENT_SUFFIX && (I += O.injectId(O.STATEMENT_SUFFIX, E)), O.STATEMENT_PREFIX) {
          let R = E.getSurroundLoop();
          R && !R.suppressPrefixSuffix && (I += O.injectId(O.STATEMENT_PREFIX, R));
        }
        switch (E.getFieldValue("FLOW")) {
          case "BREAK":
            return I + `break;
`;
          case "CONTINUE":
            return I + `continue;
`;
        }
        throw Error("Unknown flow statement.");
      }, controls_for: function(E, O) {
        var I = O.getVariableName(E.getFieldValue("VAR")), R = O.valueToCode(E, "FROM", r.ASSIGNMENT) || "0", i = O.valueToCode(E, "TO", r.ASSIGNMENT) || "0", S = O.valueToCode(E, "BY", r.ASSIGNMENT) || "1", o = O.statementToCode(E, "DO");
        if (o = O.addLoopTrap(o, E), s.zf(R) && s.zf(i) && s.zf(S)) O = Number(R) <= Number(i), E = "for (" + I + " = " + R + "; " + I + (O ? " <= " : " >= ") + i + "; " + I, I = Math.abs(Number(S)), E = I === 1 ? E + (O ? "++" : "--") : E + ((O ? " += " : " -= ") + I), E += `) {
` + o + `}
`;
        else {
          E = "";
          let P = R;
          R.match(/^\w+$/) || s.zf(R) || (P = O.nameDB_.getDistinctName(I + "_start", s.P.VARIABLE), E += "var " + P + " = " + R + `;
`), R = i, i.match(/^\w+$/) || s.zf(i) || (R = O.nameDB_.getDistinctName(I + "_end", s.P.VARIABLE), E += "var " + R + " = " + i + `;
`), i = O.nameDB_.getDistinctName(I + "_inc", s.P.VARIABLE), E += "var " + i + " = ", E = s.zf(S) ? E + (Math.abs(Number(S)) + `;
`) : E + ("Math.abs(" + S + `);
`), E += "if (" + P + " > " + R + `) {
`, E += O.INDENT + i + " = -" + i + `;
`, E = E + `}
for (` + (I + " = " + P + "; " + i + " >= 0 ? " + I + " <= " + R + " : " + I + " >= " + R + "; " + I + " += " + i + `) {
` + o + `}
`);
        }
        return E;
      }, controls_forEach: function(E, O) {
        var I = O.getVariableName(E.getFieldValue("VAR")), R = O.valueToCode(
          E,
          "LIST",
          r.ASSIGNMENT
        ) || "[]", i = O.statementToCode(E, "DO");
        i = O.addLoopTrap(i, E), E = "";
        var S = R;
        return R.match(/^\w+$/) || (S = O.nameDB_.getDistinctName(I + "_list", s.P.VARIABLE), E += "var " + S + " = " + R + `;
`), R = O.nameDB_.getDistinctName(I + "_index", s.P.VARIABLE), i = O.INDENT + I + " = " + S + "[" + R + `];
` + i, E + ("for (var " + R + " in " + S + `) {
` + i + `}
`);
      } };
      f.controls_repeat = u, f.controls_repeat_ext = u, f.controls_whileUntil = function(E, O) {
        var I = E.getFieldValue("MODE") === "UNTIL", R = O.valueToCode(E, "BOOL", I ? r.LOGICAL_NOT : r.NONE) || "false", i = O.statementToCode(E, "DO");
        return i = O.addLoopTrap(i, E), I && (R = "!" + R), "while (" + R + `) {
` + i + `}
`;
      };
      var H = {
        math_arithmetic: function(E, O) {
          var I = { ADD: [" + ", r.ADDITION], MINUS: [" - ", r.SUBTRACTION], MULTIPLY: [" * ", r.MULTIPLICATION], DIVIDE: [" / ", r.DIVISION], POWER: [null, r.NONE] }[E.getFieldValue("OP")], R = I[0];
          I = I[1];
          var i = O.valueToCode(E, "A", I) || "0";
          return E = O.valueToCode(E, "B", I) || "0", R ? [i + R + E, I] : ["Math.pow(" + i + ", " + E + ")", r.FUNCTION_CALL];
        },
        math_atan2: function(E, O) {
          var I = O.valueToCode(E, "X", r.NONE) || "0";
          return ["Math.atan2(" + (O.valueToCode(E, "Y", r.NONE) || "0") + ", " + I + ") / Math.PI * 180", r.DIVISION];
        },
        math_change: function(E, O) {
          var I = O.valueToCode(E, "DELTA", r.ADDITION) || "0";
          return E = O.getVariableName(E.getFieldValue("VAR")), E + " = (typeof " + E + " === 'number' ? " + E + " : 0) + " + I + `;
`;
        },
        math_constant: function(E) {
          return { PI: ["Math.PI", r.MEMBER], E: ["Math.E", r.MEMBER], GOLDEN_RATIO: ["(1 + Math.sqrt(5)) / 2", r.DIVISION], SQRT2: ["Math.SQRT2", r.MEMBER], SQRT1_2: ["Math.SQRT1_2", r.MEMBER], INFINITY: ["Infinity", r.ATOMIC] }[E.getFieldValue("CONSTANT")];
        },
        math_constrain: function(E, O) {
          var I = O.valueToCode(E, "VALUE", r.NONE) || "0", R = O.valueToCode(E, "LOW", r.NONE) || "0";
          return E = O.valueToCode(E, "HIGH", r.NONE) || "Infinity", ["Math.min(Math.max(" + I + ", " + R + "), " + E + ")", r.FUNCTION_CALL];
        },
        math_modulo: function(E, O) {
          var I = O.valueToCode(E, "DIVIDEND", r.MODULUS) || "0";
          return E = O.valueToCode(E, "DIVISOR", r.MODULUS) || "0", [I + " % " + E, r.MODULUS];
        },
        math_number: function(E) {
          return E = Number(E.getFieldValue("NUM")), [String(E), E >= 0 ? r.ATOMIC : r.UNARY_NEGATION];
        },
        math_number_property: function(E, O) {
          var I = { EVEN: [" % 2 === 0", r.MODULUS, r.EQUALITY], ODD: [
            " % 2 === 1",
            r.MODULUS,
            r.EQUALITY
          ], WHOLE: [" % 1 === 0", r.MODULUS, r.EQUALITY], POSITIVE: [" > 0", r.RELATIONAL, r.RELATIONAL], NEGATIVE: [" < 0", r.RELATIONAL, r.RELATIONAL], DIVISIBLE_BY: [null, r.MODULUS, r.EQUALITY], PRIME: [null, r.NONE, r.FUNCTION_CALL] }, R = E.getFieldValue("PROPERTY"), [i, S, o] = I[R];
          return I = O.valueToCode(E, "NUMBER_TO_CHECK", S) || "0", R === "PRIME" ? E = O.provideFunction_("mathIsPrime", `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(n) {
  // https://en.wikipedia.org/wiki/Primality_test#Naive_methods
  if (n == 2 || n == 3) {
    return true;
  }
  // False if n is NaN, negative, is 1, or not whole.
  // And false if n is divisible by 2 or 3.
  if (isNaN(n) || n <= 1 || n % 1 !== 0 || n % 2 === 0 || n % 3 === 0) {
    return false;
  }
  // Check all the numbers of form 6k +/- 1, up to sqrt(n).
  for (var x = 6; x <= Math.sqrt(n) + 1; x += 6) {
    if (n % (x - 1) === 0 || n % (x + 1) === 0) {
      return false;
    }
  }
  return true;
}
`) + "(" + I + ")" : R === "DIVISIBLE_BY" ? (E = O.valueToCode(E, "DIVISOR", r.MODULUS) || "0", E = I + " % " + E + " === 0") : E = I + i, [E, o];
        },
        math_on_list: function(E, O) {
          var I = E.getFieldValue("OP");
          switch (I) {
            case "SUM":
              E = O.valueToCode(E, "LIST", r.MEMBER) || "[]", E += ".reduce(function(x, y) {return x + y;}, 0)";
              break;
            case "MIN":
              E = O.valueToCode(E, "LIST", r.NONE) || "[]", E = "Math.min.apply(null, " + E + ")";
              break;
            case "MAX":
              E = O.valueToCode(E, "LIST", r.NONE) || "[]", E = "Math.max.apply(null, " + E + ")";
              break;
            case "AVERAGE":
              I = O.provideFunction_(
                "mathMean",
                `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(myList) {
  return myList.reduce(function(x, y) {return x + y;}, 0) / myList.length;
}
`
              ), E = O.valueToCode(E, "LIST", r.NONE) || "[]", E = I + "(" + E + ")";
              break;
            case "MEDIAN":
              I = O.provideFunction_("mathMedian", `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(myList) {
  var localList = myList.filter(function (x) {return typeof x === 'number';});
  if (!localList.length) return null;
  localList.sort(function(a, b) {return b - a;});
  if (localList.length % 2 === 0) {
    return (localList[localList.length / 2 - 1] + localList[localList.length / 2]) / 2;
  } else {
    return localList[(localList.length - 1) / 2];
  }
}
`), E = O.valueToCode(E, "LIST", r.NONE) || "[]", E = I + "(" + E + ")";
              break;
            case "MODE":
              I = O.provideFunction_("mathModes", `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(values) {
  var modes = [];
  var counts = [];
  var maxCount = 0;
  for (var i = 0; i < values.length; i++) {
    var value = values[i];
    var found = false;
    var thisCount;
    for (var j = 0; j < counts.length; j++) {
      if (counts[j][0] === value) {
        thisCount = ++counts[j][1];
        found = true;
        break;
      }
    }
    if (!found) {
      counts.push([value, 1]);
      thisCount = 1;
    }
    maxCount = Math.max(thisCount, maxCount);
  }
  for (var j = 0; j < counts.length; j++) {
    if (counts[j][1] === maxCount) {
      modes.push(counts[j][0]);
    }
  }
  return modes;
}
`), E = O.valueToCode(E, "LIST", r.NONE) || "[]", E = I + "(" + E + ")";
              break;
            case "STD_DEV":
              I = O.provideFunction_("mathStandardDeviation", `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(numbers) {
  var n = numbers.length;
  if (!n) return null;
  var mean = numbers.reduce(function(x, y) {return x + y;}) / n;
  var variance = 0;
  for (var j = 0; j < n; j++) {
    variance += Math.pow(numbers[j] - mean, 2);
  }
  variance /= n;
  return Math.sqrt(variance);
}
`), E = O.valueToCode(E, "LIST", r.NONE) || "[]", E = I + "(" + E + ")";
              break;
            case "RANDOM":
              I = O.provideFunction_("mathRandomList", `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(list) {
  var x = Math.floor(Math.random() * list.length);
  return list[x];
}
`), E = O.valueToCode(E, "LIST", r.NONE) || "[]", E = I + "(" + E + ")";
              break;
            default:
              throw Error("Unknown operator: " + I);
          }
          return [E, r.FUNCTION_CALL];
        },
        math_random_float: function() {
          return ["Math.random()", r.FUNCTION_CALL];
        },
        math_random_int: function(E, O) {
          var I = O.valueToCode(E, "FROM", r.NONE) || "0";
          return E = O.valueToCode(E, "TO", r.NONE) || "0", [O.provideFunction_("mathRandomInt", `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(a, b) {
  if (a > b) {
    // Swap a and b to ensure a is smaller.
    var c = a;
    a = b;
    b = c;
  }
  return Math.floor(Math.random() * (b - a + 1) + a);
}
`) + "(" + I + ", " + E + ")", r.FUNCTION_CALL];
        }
      };
      H.math_round = B, H.math_single = B, H.math_trig = B;
      var G = { procedures_callnoreturn: function(E, O) {
        return O.forBlock.procedures_callreturn(E, O)[0] + `;
`;
      }, procedures_callreturn: function(E, O) {
        var I = O.getProcedureName(E.getFieldValue("NAME")), R = [], i = E.getVarModels();
        for (let S = 0; S < i.length; S++) R[S] = O.valueToCode(E, "ARG" + S, r.NONE) || "null";
        return [I + "(" + R.join(", ") + ")", r.FUNCTION_CALL];
      } };
      G.procedures_defnoreturn = c, G.procedures_defreturn = c, G.procedures_ifreturn = function(E, O) {
        var I = "if (" + (O.valueToCode(E, "CONDITION", r.NONE) || "false") + `) {
`;
        return O.STATEMENT_SUFFIX && (I += O.prefixLines(O.injectId(O.STATEMENT_SUFFIX, E), O.INDENT)), E.hasReturnValue_ ? (E = O.valueToCode(E, "VALUE", r.NONE) || "null", I += O.INDENT + "return " + E + `;
`) : I += O.INDENT + `return;
`, I + `}
`;
      };
      var v = /^\s*'([^']|\\')*'\s*$/, V = {
        text: function(E, O) {
          return [O.quote_(E.getFieldValue("TEXT")), r.ATOMIC];
        },
        text_append: function(E, O) {
          var I = O.getVariableName(E.getFieldValue("VAR"));
          return E = O.valueToCode(E, "TEXT", r.NONE) || "''", I + " += " + d(E)[0] + `;
`;
        },
        text_changeCase: function(E, O) {
          var I = { UPPERCASE: ".toUpperCase()", LOWERCASE: ".toLowerCase()", TITLECASE: null }[E.getFieldValue("CASE")];
          return E = O.valueToCode(E, "TEXT", I ? r.MEMBER : r.NONE) || "''", [I ? E + I : O.provideFunction_("textToTitleCase", `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(str) {
  return str.replace(/\\S+/g,
      function(txt) {return txt[0].toUpperCase() + txt.substring(1).toLowerCase();});
}
`) + "(" + E + ")", r.FUNCTION_CALL];
        },
        text_charAt: function(E, O) {
          var I = E.getFieldValue("WHERE") || "FROM_START", R = O.valueToCode(E, "VALUE", I === "RANDOM" ? r.NONE : r.MEMBER) || "''";
          switch (I) {
            case "FIRST":
              return [R + ".charAt(0)", r.FUNCTION_CALL];
            case "LAST":
              return [R + ".slice(-1)", r.FUNCTION_CALL];
            case "FROM_START":
              return E = O.getAdjusted(E, "AT"), [R + ".charAt(" + E + ")", r.FUNCTION_CALL];
            case "FROM_END":
              return E = O.getAdjusted(E, "AT", 1, !0), [R + ".slice(" + E + ").charAt(0)", r.FUNCTION_CALL];
            case "RANDOM":
              return [O.provideFunction_(
                "textRandomLetter",
                `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(text) {
  var x = Math.floor(Math.random() * text.length);
  return text[x];
}
`
              ) + "(" + R + ")", r.FUNCTION_CALL];
          }
          throw Error("Unhandled option (text_charAt).");
        },
        text_count: function(E, O) {
          var I = O.valueToCode(E, "TEXT", r.NONE) || "''";
          return E = O.valueToCode(E, "SUB", r.NONE) || "''", [O.provideFunction_("textCount", `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(haystack, needle) {
  if (needle.length === 0) {
    return haystack.length + 1;
  } else {
    return haystack.split(needle).length - 1;
  }
}
`) + "(" + I + ", " + E + ")", r.FUNCTION_CALL];
        },
        text_getSubstring: function(E, O) {
          var I = { FIRST: "First", LAST: "Last", FROM_START: "FromStart", FROM_END: "FromEnd" }, R = E.getFieldValue("WHERE1"), i = E.getFieldValue("WHERE2"), S = R !== "FROM_END" && R !== "LAST" && i !== "FROM_END" && i !== "LAST", o = O.valueToCode(E, "STRING", S ? r.MEMBER : r.NONE) || "''";
          if (R === "FIRST" && i === "LAST") return [o, r.NONE];
          if (o.match(/^'?\w+'?$/) || S) {
            switch (R) {
              case "FROM_START":
                I = O.getAdjusted(E, "AT1");
                break;
              case "FROM_END":
                I = O.getAdjusted(E, "AT1", 1, !1, r.SUBTRACTION), I = o + ".length - " + I;
                break;
              case "FIRST":
                I = "0";
                break;
              default:
                throw Error("Unhandled option (text_getSubstring).");
            }
            switch (i) {
              case "FROM_START":
                O = O.getAdjusted(E, "AT2", 1);
                break;
              case "FROM_END":
                O = O.getAdjusted(E, "AT2", 0, !1, r.SUBTRACTION), O = o + ".length - " + O;
                break;
              case "LAST":
                O = o + ".length";
                break;
              default:
                throw Error("Unhandled option (text_getSubstring).");
            }
            o = o + ".slice(" + I + ", " + O + ")";
          } else S = O.getAdjusted(E, "AT1"), E = O.getAdjusted(E, "AT2"), o = O.provideFunction_("subsequence" + I[R] + I[i], `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(sequence${R === "FROM_END" || R === "FROM_START" ? ", at1" : ""}${i === "FROM_END" || i === "FROM_START" ? ", at2" : ""}) {
  var start = ${l("sequence", R, "at1")};
  var end = ${l("sequence", i, "at2")} + 1;
  return sequence.slice(start, end);
}
`) + "(" + o + (R === "FROM_END" || R === "FROM_START" ? ", " + S : "") + (i === "FROM_END" || i === "FROM_START" ? ", " + E : "") + ")";
          return [o, r.FUNCTION_CALL];
        },
        text_indexOf: function(E, O) {
          var I = E.getFieldValue("END") === "FIRST" ? "indexOf" : "lastIndexOf", R = O.valueToCode(E, "FIND", r.NONE) || "''";
          return O = (O.valueToCode(E, "VALUE", r.MEMBER) || "''") + "." + I + "(" + R + ")", E.workspace.options.oneBasedIndex ? [O + " + 1", r.ADDITION] : [O, r.FUNCTION_CALL];
        },
        text_isEmpty: function(E, O) {
          return ["!" + (O.valueToCode(E, "VALUE", r.MEMBER) || "''") + ".length", r.LOGICAL_NOT];
        },
        text_join: function(E, O) {
          switch (E.itemCount_) {
            case 0:
              return ["''", r.ATOMIC];
            case 1:
              return E = O.valueToCode(E, "ADD0", r.NONE) || "''", d(E);
            case 2:
              var I = O.valueToCode(E, "ADD0", r.NONE) || "''";
              return E = O.valueToCode(E, "ADD1", r.NONE) || "''", [d(I)[0] + " + " + d(E)[0], r.ADDITION];
            default:
              I = Array(E.itemCount_);
              for (let R = 0; R < E.itemCount_; R++) I[R] = O.valueToCode(E, "ADD" + R, r.NONE) || "''";
              return ["[" + I.join(",") + "].join('')", r.FUNCTION_CALL];
          }
        },
        text_length: function(E, O) {
          return [
            (O.valueToCode(E, "VALUE", r.MEMBER) || "''") + ".length",
            r.MEMBER
          ];
        },
        text_print: function(E, O) {
          return "window.alert(" + (O.valueToCode(E, "TEXT", r.NONE) || "''") + `);
`;
        }
      };
      V.text_prompt = A, V.text_prompt_ext = A, V.text_replace = function(E, O) {
        var I = O.valueToCode(E, "TEXT", r.NONE) || "''", R = O.valueToCode(E, "FROM", r.NONE) || "''";
        return E = O.valueToCode(E, "TO", r.NONE) || "''", [O.provideFunction_("textReplace", `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(haystack, needle, replacement) {
  needle = needle.replace(/([-()\\[\\]{}+?*.$\\^|,:#<!\\\\])/g, '\\\\$1')
                 .replace(/\\x08/g, '\\\\x08');
  return haystack.replace(new RegExp(needle, 'g'), replacement);
}
`) + "(" + I + ", " + R + ", " + E + ")", r.FUNCTION_CALL];
      }, V.text_reverse = function(E, O) {
        return [(O.valueToCode(E, "TEXT", r.MEMBER) || "''") + ".split('').reverse().join('')", r.FUNCTION_CALL];
      }, V.text_trim = function(E, O) {
        var I = { LEFT: ".replace(/^[\\s\\xa0]+/, '')", RIGHT: ".replace(/[\\s\\xa0]+$/, '')", BOTH: ".trim()" }[E.getFieldValue("MODE")];
        return [(O.valueToCode(E, "TEXT", r.MEMBER) || "''") + I, r.FUNCTION_CALL];
      };
      var X = {};
      X.variables_get = N, X.variables_set = n;
      var t = {};
      t.variables_get_dynamic = N, t.variables_set_dynamic = n;
      var L = new F(), T = Object.assign({}, {
        lists_create_empty: function() {
          return ["[]", r.ATOMIC];
        },
        lists_create_with: function(E, O) {
          var I = Array(E.itemCount_);
          for (let R = 0; R < E.itemCount_; R++) I[R] = O.valueToCode(E, "ADD" + R, r.NONE) || "null";
          return ["[" + I.join(", ") + "]", r.ATOMIC];
        },
        lists_getIndex: function(E, O) {
          var I = E.getFieldValue("MODE") || "GET", R = E.getFieldValue("WHERE") || "FROM_START", i = O.valueToCode(E, "VALUE", R === "RANDOM" ? r.NONE : r.MEMBER) || "[]";
          switch (R) {
            case "FIRST":
              if (I === "GET") return [i + "[0]", r.MEMBER];
              if (I === "GET_REMOVE") return [i + ".shift()", r.MEMBER];
              if (I === "REMOVE") return i + `.shift();
`;
              break;
            case "LAST":
              if (I === "GET") return [i + ".slice(-1)[0]", r.MEMBER];
              if (I === "GET_REMOVE") return [i + ".pop()", r.MEMBER];
              if (I === "REMOVE") return i + `.pop();
`;
              break;
            case "FROM_START":
              if (E = O.getAdjusted(E, "AT"), I === "GET") return [i + "[" + E + "]", r.MEMBER];
              if (I === "GET_REMOVE") return [i + ".splice(" + E + ", 1)[0]", r.FUNCTION_CALL];
              if (I === "REMOVE") return i + ".splice(" + E + `, 1);
`;
              break;
            case "FROM_END":
              if (E = O.getAdjusted(E, "AT", 1, !0), I === "GET") return [i + ".slice(" + E + ")[0]", r.FUNCTION_CALL];
              if (I === "GET_REMOVE") return [i + ".splice(" + E + ", 1)[0]", r.FUNCTION_CALL];
              if (I === "REMOVE") return i + ".splice(" + E + ", 1);";
              break;
            case "RANDOM":
              if (i = O.provideFunction_("listsGetRandomItem", `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(list, remove) {
  var x = Math.floor(Math.random() * list.length);
  if (remove) {
    return list.splice(x, 1)[0];
  } else {
    return list[x];
  }
}
`) + "(" + i + ", " + (I !== "GET") + ")", I === "GET" || I === "GET_REMOVE") return [i, r.FUNCTION_CALL];
              if (I === "REMOVE") return i + `;
`;
          }
          throw Error("Unhandled combination (lists_getIndex).");
        },
        lists_getSublist: function(E, O) {
          var I = { FIRST: "First", LAST: "Last", FROM_START: "FromStart", FROM_END: "FromEnd" }, R = O.valueToCode(E, "LIST", r.MEMBER) || "[]", i = E.getFieldValue("WHERE1"), S = E.getFieldValue("WHERE2");
          if (i === "FIRST" && S === "LAST") R += ".slice(0)";
          else if (R.match(/^\w+$/) || i !== "FROM_END" && S === "FROM_START") {
            switch (i) {
              case "FROM_START":
                I = O.getAdjusted(E, "AT1");
                break;
              case "FROM_END":
                I = O.getAdjusted(E, "AT1", 1, !1, r.SUBTRACTION), I = R + ".length - " + I;
                break;
              case "FIRST":
                I = "0";
                break;
              default:
                throw Error("Unhandled option (lists_getSublist).");
            }
            switch (S) {
              case "FROM_START":
                O = O.getAdjusted(E, "AT2", 1);
                break;
              case "FROM_END":
                O = O.getAdjusted(E, "AT2", 0, !1, r.SUBTRACTION), O = R + ".length - " + O;
                break;
              case "LAST":
                O = R + ".length";
                break;
              default:
                throw Error("Unhandled option (lists_getSublist).");
            }
            R = R + ".slice(" + I + ", " + O + ")";
          } else {
            let o = O.getAdjusted(E, "AT1");
            E = O.getAdjusted(E, "AT2"), R = O.provideFunction_("subsequence" + I[i] + I[S], `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(sequence${i === "FROM_END" || i === "FROM_START" ? ", at1" : ""}${S === "FROM_END" || S === "FROM_START" ? ", at2" : ""}) {
  var start = ${U("sequence", i, "at1")};
  var end = ${U("sequence", S, "at2")} + 1;
  return sequence.slice(start, end);
}
`) + "(" + R + (i === "FROM_END" || i === "FROM_START" ? ", " + o : "") + (S === "FROM_END" || S === "FROM_START" ? ", " + E : "") + ")";
          }
          return [R, r.FUNCTION_CALL];
        },
        lists_indexOf: function(E, O) {
          var I = E.getFieldValue("END") === "FIRST" ? "indexOf" : "lastIndexOf", R = O.valueToCode(E, "FIND", r.NONE) || "''";
          return O = (O.valueToCode(E, "VALUE", r.MEMBER) || "[]") + "." + I + "(" + R + ")", E.workspace.options.oneBasedIndex ? [O + " + 1", r.ADDITION] : [O, r.FUNCTION_CALL];
        },
        lists_isEmpty: function(E, O) {
          return ["!" + (O.valueToCode(E, "VALUE", r.MEMBER) || "[]") + ".length", r.LOGICAL_NOT];
        },
        lists_length: function(E, O) {
          return [(O.valueToCode(E, "VALUE", r.MEMBER) || "[]") + ".length", r.MEMBER];
        },
        lists_repeat: function(E, O) {
          var I = O.provideFunction_("listsRepeat", `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(value, n) {
  var array = [];
  for (var i = 0; i < n; i++) {
    array[i] = value;
  }
  return array;
}
`), R = O.valueToCode(E, "ITEM", r.NONE) || "null";
          return E = O.valueToCode(E, "NUM", r.NONE) || "0", [I + "(" + R + ", " + E + ")", r.FUNCTION_CALL];
        },
        lists_reverse: function(E, O) {
          return [(O.valueToCode(E, "LIST", r.FUNCTION_CALL) || "[]") + ".slice().reverse()", r.FUNCTION_CALL];
        },
        lists_setIndex: function(E, O) {
          function I() {
            if (R.match(/^\w+$/)) return "";
            var P = O.nameDB_.getDistinctName("tmpList", s.P.VARIABLE), a = "var " + P + " = " + R + `;
`;
            return R = P, a;
          }
          var R = O.valueToCode(E, "LIST", r.MEMBER) || "[]", i = E.getFieldValue("MODE") || "GET", S = E.getFieldValue("WHERE") || "FROM_START", o = O.valueToCode(E, "TO", r.ASSIGNMENT) || "null";
          switch (S) {
            case "FIRST":
              if (i === "SET") return R + "[0] = " + o + `;
`;
              if (i === "INSERT") return R + ".unshift(" + o + `);
`;
              break;
            case "LAST":
              if (i === "SET") return I() + (R + "[" + R + ".length - 1] = " + o + `;
`);
              if (i === "INSERT") return R + ".push(" + o + `);
`;
              break;
            case "FROM_START":
              if (E = O.getAdjusted(E, "AT"), i === "SET") return R + "[" + E + "] = " + o + `;
`;
              if (i === "INSERT") return R + ".splice(" + E + ", 0, " + o + `);
`;
              break;
            case "FROM_END":
              if (E = O.getAdjusted(E, "AT", 1, !1, r.SUBTRACTION), S = I(), i === "SET") return S + (R + "[" + R + ".length - " + E + "] = " + o + `;
`);
              if (i === "INSERT") return S + (R + ".splice(" + R + ".length - " + E + ", 0, " + o + `);
`);
              break;
            case "RANDOM":
              if (E = I(), S = O.nameDB_.getDistinctName("tmpX", s.P.VARIABLE), E += "var " + S + " = Math.floor(Math.random() * " + R + `.length);
`, i === "SET") return E + (R + "[" + S + "] = " + o + `;
`);
              if (i === "INSERT") return E + (R + ".splice(" + S + ", 0, " + o + `);
`);
          }
          throw Error("Unhandled combination (lists_setIndex).");
        },
        lists_sort: function(E, O) {
          var I = O.valueToCode(E, "LIST", r.FUNCTION_CALL) || "[]", R = E.getFieldValue("DIRECTION") === "1" ? 1 : -1;
          return E = E.getFieldValue("TYPE"), O = O.provideFunction_("listsGetSortCompare", `
function ${O.FUNCTION_NAME_PLACEHOLDER_}(type, direction) {
  var compareFuncs = {
    'NUMERIC': function(a, b) {
        return Number(a) - Number(b); },
    'TEXT': function(a, b) {
        return String(a) > String(b) ? 1 : -1; },
    'IGNORE_CASE': function(a, b) {
        return String(a).toLowerCase() > String(b).toLowerCase() ? 1 : -1; },
  };
  var compare = compareFuncs[type];
  return function(a, b) { return compare(a, b) * direction; };
}
      `), [I + ".slice().sort(" + O + '("' + E + '", ' + R + "))", r.FUNCTION_CALL];
        },
        lists_split: function(E, O) {
          var I = O.valueToCode(E, "INPUT", r.MEMBER);
          if (O = O.valueToCode(E, "DELIM", r.NONE) || "''", E = E.getFieldValue("MODE"), E === "SPLIT") I || (I = "''"), E = "split";
          else if (E === "JOIN") I || (I = "[]"), E = "join";
          else throw Error("Unknown mode: " + E);
          return [I + "." + E + "(" + O + ")", r.FUNCTION_CALL];
        }
      }, h, f, H, G, V, X, t);
      for (let E in T) L.forBlock[E] = T[E];
      var e = {};
      return e.JavascriptGenerator = F, e.Order = r, e.javascriptGenerator = L, s.__chunk_javascript = e, s.__chunk_javascript.__namespace__ = s, s.__chunk_javascript;
    });
  })(q)), q.exports;
}
var z = { exports: {} }, Kd = z.exports, I_;
function wd() {
  return I_ || (I_ = 1, (function(g, C) {
    (function(_, s) {
      g.exports = s(K());
    })(Kd, function(_) {
      var s = _.__namespace__, U = function(T, e, E) {
        return e === "FIRST" ? "1" : e === "FROM_END" ? "#" + T + " + 1 - " + E : e === "LAST" ? "#" + T : e === "RANDOM" ? "math.random(#" + T + ")" : E;
      }, D = function(T, e) {
        var E = 0, O = "";
        e.STATEMENT_PREFIX && (O += e.injectId(e.STATEMENT_PREFIX, T));
        do {
          let I = e.valueToCode(T, "IF" + E, n.NONE) || "false", R = e.statementToCode(T, "DO" + E);
          e.STATEMENT_SUFFIX && (R = e.prefixLines(e.injectId(e.STATEMENT_SUFFIX, T), e.INDENT) + R), O += (E > 0 ? "else" : "") + "if " + I + ` then
` + R, E++;
        } while (T.getInput("IF" + E));
        return (T.getInput("ELSE") || e.STATEMENT_SUFFIX) && (E = T.getInput("ELSE") ? e.statementToCode(T, "ELSE") : "", e.STATEMENT_SUFFIX && (E = e.prefixLines(e.injectId(e.STATEMENT_SUFFIX, T), e.INDENT) + E), O += `else
` + E), O + `end
`;
      }, u = function(T, e) {
        return T.includes(`goto continue
`) ? T + e + `::continue::
` : T;
      }, B = function(T, e) {
        var E = T.getField("TIMES") ? String(Number(T.getFieldValue("TIMES"))) : e.valueToCode(T, "TIMES", n.NONE) || "0";
        E = s.zf(E) ? parseInt(E, 10) : "math.floor(" + E + ")";
        var O = e.statementToCode(T, "DO");
        return O = e.addLoopTrap(O, T), O = u(O, e.INDENT), "for " + e.nameDB_.getDistinctName(
          "count",
          s.P.VARIABLE
        ) + " = 1, " + E + ` do
` + O + `end
`;
      }, c = function(T, e) {
        var E = T.getFieldValue("OP");
        if (E === "NEG") return T = e.valueToCode(T, "NUM", n.UNARY) || "0", ["-" + T, n.UNARY];
        if (E === "POW10") return T = e.valueToCode(T, "NUM", n.EXPONENTIATION) || "0", ["10 ^ " + T, n.EXPONENTIATION];
        switch (T = E === "ROUND" ? e.valueToCode(T, "NUM", n.ADDITIVE) || "0" : e.valueToCode(T, "NUM", n.NONE) || "0", E) {
          case "ABS":
            E = "math.abs(" + T + ")";
            break;
          case "ROOT":
            E = "math.sqrt(" + T + ")";
            break;
          case "LN":
            E = "math.log(" + T + ")";
            break;
          case "LOG10":
            E = "math.log(" + T + ", 10)";
            break;
          case "EXP":
            E = "math.exp(" + T + ")";
            break;
          case "ROUND":
            E = "math.floor(" + T + " + .5)";
            break;
          case "ROUNDUP":
            E = "math.ceil(" + T + ")";
            break;
          case "ROUNDDOWN":
            E = "math.floor(" + T + ")";
            break;
          case "SIN":
            E = "math.sin(math.rad(" + T + "))";
            break;
          case "COS":
            E = "math.cos(math.rad(" + T + "))";
            break;
          case "TAN":
            E = "math.tan(math.rad(" + T + "))";
            break;
          case "ASIN":
            E = "math.deg(math.asin(" + T + "))";
            break;
          case "ACOS":
            E = "math.deg(math.acos(" + T + "))";
            break;
          case "ATAN":
            E = "math.deg(math.atan(" + T + "))";
            break;
          default:
            throw Error("Unknown math operator: " + E);
        }
        return [E, n.HIGH];
      }, d = function(T, e) {
        var E = e.getProcedureName(T.getFieldValue("NAME")), O = "";
        e.STATEMENT_PREFIX && (O += e.injectId(e.STATEMENT_PREFIX, T)), e.STATEMENT_SUFFIX && (O += e.injectId(e.STATEMENT_SUFFIX, T)), O && (O = e.prefixLines(O, e.INDENT));
        var I = "";
        e.INFINITE_LOOP_TRAP && (I = e.prefixLines(e.injectId(e.INFINITE_LOOP_TRAP, T), e.INDENT));
        var R = "";
        T.getInput("STACK") && (R = e.statementToCode(T, "STACK"));
        var i = "";
        T.getInput("RETURN") && (i = e.valueToCode(T, "RETURN", n.NONE) || "");
        var S = "";
        R && i && (S = O), i ? i = e.INDENT + "return " + i + `
` : R || (R = "");
        var o = [], P = T.getVarModels();
        for (let a = 0; a < P.length; a++) o[a] = e.getVariableName(P[a].getId());
        return O = "function " + E + "(" + o.join(", ") + `)
` + O + I + R + S + i + `end
`, O = e.scrub_(T, O), e.definitions_["%" + E] = O, null;
      }, l = function(T, e) {
        var E = T.getField("TEXT") ? e.quote_(T.getFieldValue("TEXT")) : e.valueToCode(T, "TEXT", n.NONE) || "''";
        return e = e.provideFunction_("text_prompt", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(msg)
  io.write(msg)
  io.flush()
  return io.read()
end
`) + "(" + E + ")", T.getFieldValue("TYPE") === "NUMBER" && (e = "tonumber(" + e + ", 10)"), [e, n.HIGH];
      }, A = function(T, e) {
        return [e.getVariableName(T.getFieldValue("VAR")), n.ATOMIC];
      }, N = function(T, e) {
        var E = e.valueToCode(T, "VALUE", n.NONE) || "0";
        return e.getVariableName(T.getFieldValue("VAR")) + " = " + E + `
`;
      }, n, r = n || (n = {});
      r[r.ATOMIC = 0] = "ATOMIC", r[r.HIGH = 1] = "HIGH", r[r.EXPONENTIATION = 2] = "EXPONENTIATION", r[r.UNARY = 3] = "UNARY", r[r.MULTIPLICATIVE = 4] = "MULTIPLICATIVE", r[r.ADDITIVE = 5] = "ADDITIVE", r[r.CONCATENATION = 6] = "CONCATENATION", r[r.RELATIONAL = 7] = "RELATIONAL", r[r.AND = 8] = "AND", r[r.OR = 9] = "OR", r[r.NONE = 99] = "NONE";
      var M = class extends s.zq {
        constructor(T = "Lua") {
          super(T), this.isInitialized = !1;
          for (let e in n) T = n[e], typeof T != "string" && (this["ORDER_" + e] = T);
          this.addReservedWords("_,__inext,assert,bit,colors,colours,coroutine,disk,dofile,error,fs,fetfenv,getmetatable,gps,help,io,ipairs,keys,loadfile,loadstring,math,native,next,os,paintutils,pairs,parallel,pcall,peripheral,print,printError,rawequal,rawget,rawset,read,rednet,redstone,rs,select,setfenv,setmetatable,sleep,string,table,term,textutils,tonumber,tostring,turtle,type,unpack,vector,write,xpcall,_VERSION,__indext,HTTP,and,break,do,else,elseif,end,false,for,function,if,in,local,nil,not,or,repeat,return,then,true,until,while,add,sub,mul,div,mod,pow,unm,concat,len,eq,lt,le,index,newindex,call,assert,collectgarbage,dofile,error,_G,getmetatable,inpairs,load,loadfile,next,pairs,pcall,print,rawequal,rawget,rawlen,rawset,select,setmetatable,tonumber,tostring,type,_VERSION,xpcall,require,package,string,table,math,bit32,io,file,os,debug");
        }
        init(T) {
          super.init(T), this.nameDB_ ? this.nameDB_.reset() : this.nameDB_ = new s.Cj(this.RESERVED_WORDS_), this.nameDB_.setVariableMap(T.getVariableMap()), this.nameDB_.populateVariables(T), this.nameDB_.populateProcedures(T), this.isInitialized = !0;
        }
        finish(T) {
          var e = Object.values(this.definitions_);
          return T = super.finish(T), this.isInitialized = !1, this.nameDB_.reset(), e.join(`

`) + `


` + T;
        }
        scrubNakedValue(T) {
          return "local _ = " + T + `
`;
        }
        quote_(T) {
          return T = T.replace(/\\/g, "\\\\").replace(/\n/g, `\\
`).replace(/'/g, "\\'"), "'" + T + "'";
        }
        multiline_quote_(T) {
          return T.split(/\n/g).map(this.quote_).join(` .. '\\n' ..
`);
        }
        scrub_(T, e, E = !1) {
          var O = "";
          if (!T.outputConnection || !T.outputConnection.targetConnection) {
            var I = T.getCommentText();
            I && (I = s.yf(I, this.COMMENT_WRAP - 3), O += this.prefixLines(I, "-- ") + `
`);
            for (let R = 0; R < T.inputList.length; R++) T.inputList[R].type === s.je.VALUE && (I = T.inputList[R].connection.targetBlock()) && (I = this.allNestedComments(I)) && (O += this.prefixLines(I, "-- "));
          }
          return T = T.nextConnection && T.nextConnection.targetBlock(), E = E ? "" : this.blockToCode(T), O + e + E;
        }
      }, F = {};
      F.controls_if = D, F.controls_ifelse = D, F.logic_boolean = function(T) {
        return [T.getFieldValue("BOOL") === "TRUE" ? "true" : "false", n.ATOMIC];
      }, F.logic_compare = function(T, e) {
        var E = { EQ: "==", NEQ: "~=", LT: "<", LTE: "<=", GT: ">", GTE: ">=" }[T.getFieldValue("OP")], O = e.valueToCode(T, "A", n.RELATIONAL) || "0";
        return T = e.valueToCode(T, "B", n.RELATIONAL) || "0", [O + " " + E + " " + T, n.RELATIONAL];
      }, F.logic_negate = function(T, e) {
        return ["not " + (e.valueToCode(T, "BOOL", n.UNARY) || "true"), n.UNARY];
      }, F.logic_null = function() {
        return ["nil", n.ATOMIC];
      }, F.logic_operation = function(T, e) {
        var E = T.getFieldValue("OP") === "AND" ? "and" : "or", O = E === "and" ? n.AND : n.OR, I = e.valueToCode(T, "A", O);
        return T = e.valueToCode(T, "B", O), I || T ? (e = E === "and" ? "true" : "false", I || (I = e), T || (T = e)) : T = I = "false", [I + " " + E + " " + T, O];
      }, F.logic_ternary = function(T, e) {
        var E = e.valueToCode(T, "IF", n.AND) || "false", O = e.valueToCode(T, "THEN", n.AND) || "nil";
        return T = e.valueToCode(T, "ELSE", n.OR) || "nil", [E + " and " + O + " or " + T, n.OR];
      };
      var h = { controls_flow_statements: function(T, e) {
        var E = "";
        if (e.STATEMENT_PREFIX && (E += e.injectId(e.STATEMENT_PREFIX, T)), e.STATEMENT_SUFFIX && (E += e.injectId(e.STATEMENT_SUFFIX, T)), e.STATEMENT_PREFIX) {
          let O = T.getSurroundLoop();
          O && !O.suppressPrefixSuffix && (E += e.injectId(e.STATEMENT_PREFIX, O));
        }
        switch (T.getFieldValue("FLOW")) {
          case "BREAK":
            return E + `break
`;
          case "CONTINUE":
            return E + `goto continue
`;
        }
        throw Error("Unknown flow statement.");
      }, controls_for: function(T, e) {
        var E = e.getVariableName(T.getFieldValue("VAR")), O = e.valueToCode(T, "FROM", n.NONE) || "0", I = e.valueToCode(T, "TO", n.NONE) || "0", R = e.valueToCode(T, "BY", n.NONE) || "1", i = e.statementToCode(T, "DO");
        if (i = e.addLoopTrap(i, T), i = u(i, e.INDENT), T = "", s.zf(O) && s.zf(I) && s.zf(R)) var S = (Number(O) <= Number(I) ? "" : "-") + Math.abs(Number(R));
        else T = "", S = e.nameDB_.getDistinctName(E + "_inc", s.P.VARIABLE), T += S + " = ", T = s.zf(R) ? T + (Math.abs(R) + `
`) : T + ("math.abs(" + R + `)
`), T = T + ("if (" + O + ") > (" + I + `) then
`) + (e.INDENT + S + " = -" + S + `
`), T += `end
`;
        return T + ("for " + E + " = " + O + ", " + I + ", " + S) + (` do
` + i + `end
`);
      }, controls_forEach: function(T, e) {
        var E = e.getVariableName(T.getFieldValue("VAR")), O = e.valueToCode(T, "LIST", n.NONE) || "{}", I = e.statementToCode(T, "DO");
        return I = e.addLoopTrap(I, T), I = u(I, e.INDENT), "for _, " + E + " in ipairs(" + O + `) do 
` + I + `end
`;
      } };
      h.controls_repeat = B, h.controls_repeat_ext = B, h.controls_whileUntil = function(T, e) {
        var E = T.getFieldValue("MODE") === "UNTIL", O = e.valueToCode(T, "BOOL", E ? n.UNARY : n.NONE) || "false", I = e.statementToCode(T, "DO");
        return I = e.addLoopTrap(I, T), I = u(I, e.INDENT), E && (O = "not " + O), "while " + O + ` do
` + I + `end
`;
      };
      var f = { math_arithmetic: function(T, e) {
        var E = { ADD: [" + ", n.ADDITIVE], MINUS: [" - ", n.ADDITIVE], MULTIPLY: [" * ", n.MULTIPLICATIVE], DIVIDE: [" / ", n.MULTIPLICATIVE], POWER: [" ^ ", n.EXPONENTIATION] }[T.getFieldValue("OP")], O = E[0];
        E = E[1];
        var I = e.valueToCode(T, "A", E) || "0";
        return T = e.valueToCode(T, "B", E) || "0", [I + O + T, E];
      }, math_atan2: function(T, e) {
        var E = e.valueToCode(T, "X", n.NONE) || "0";
        return ["math.deg(math.atan2(" + (e.valueToCode(T, "Y", n.NONE) || "0") + ", " + E + "))", n.HIGH];
      }, math_change: function(T, e) {
        var E = e.valueToCode(
          T,
          "DELTA",
          n.ADDITIVE
        ) || "0";
        return T = e.getVariableName(T.getFieldValue("VAR")), T + " = " + T + " + " + E + `
`;
      }, math_constant: function(T) {
        return { PI: ["math.pi", n.HIGH], E: ["math.exp(1)", n.HIGH], GOLDEN_RATIO: ["(1 + math.sqrt(5)) / 2", n.MULTIPLICATIVE], SQRT2: ["math.sqrt(2)", n.HIGH], SQRT1_2: ["math.sqrt(1 / 2)", n.HIGH], INFINITY: ["math.huge", n.HIGH] }[T.getFieldValue("CONSTANT")];
      }, math_constrain: function(T, e) {
        var E = e.valueToCode(T, "VALUE", n.NONE) || "0", O = e.valueToCode(T, "LOW", n.NONE) || "-math.huge";
        return T = e.valueToCode(
          T,
          "HIGH",
          n.NONE
        ) || "math.huge", ["math.min(math.max(" + E + ", " + O + "), " + T + ")", n.HIGH];
      }, math_modulo: function(T, e) {
        var E = e.valueToCode(T, "DIVIDEND", n.MULTIPLICATIVE) || "0";
        return T = e.valueToCode(T, "DIVISOR", n.MULTIPLICATIVE) || "0", [E + " % " + T, n.MULTIPLICATIVE];
      }, math_number: function(T) {
        return T = Number(T.getFieldValue("NUM")), [String(T), T < 0 ? n.UNARY : n.ATOMIC];
      }, math_number_property: function(T, e) {
        var E = { EVEN: [" % 2 == 0", n.MULTIPLICATIVE, n.RELATIONAL], ODD: [" % 2 == 1", n.MULTIPLICATIVE, n.RELATIONAL], WHOLE: [
          " % 1 == 0",
          n.MULTIPLICATIVE,
          n.RELATIONAL
        ], POSITIVE: [" > 0", n.RELATIONAL, n.RELATIONAL], NEGATIVE: [" < 0", n.RELATIONAL, n.RELATIONAL], DIVISIBLE_BY: [null, n.MULTIPLICATIVE, n.RELATIONAL], PRIME: [null, n.NONE, n.HIGH] }, O = T.getFieldValue("PROPERTY"), [I, R, i] = E[O];
        if (E = e.valueToCode(T, "NUMBER_TO_CHECK", R) || "0", O === "PRIME") T = e.provideFunction_("math_isPrime", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(n)
  -- https://en.wikipedia.org/wiki/Primality_test#Naive_methods
  if n == 2 or n == 3 then
    return true
  end
  -- False if n is NaN, negative, is 1, or not whole.
  -- And false if n is divisible by 2 or 3.
  if not(n > 1) or n % 1 ~= 0 or n % 2 == 0 or n % 3 == 0 then
    return false
  end
  -- Check all the numbers of form 6k +/- 1, up to sqrt(n).
  for x = 6, math.sqrt(n) + 1.5, 6 do
    if n % (x - 1) == 0 or n % (x + 1) == 0 then
      return false
    end
  end
  return true
end
`) + "(" + E + ")";
        else if (O === "DIVISIBLE_BY") {
          if (T = e.valueToCode(T, "DIVISOR", n.MULTIPLICATIVE) || "0", T === "0") return ["nil", n.ATOMIC];
          T = E + " % " + T + " == 0";
        } else T = E + I;
        return [T, i];
      }, math_on_list: function(T, e) {
        function E() {
          return e.provideFunction_("math_sum", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(t)
  local result = 0
  for _, v in ipairs(t) do
    result = result + v
  end
  return result
end
`);
        }
        var O = T.getFieldValue("OP");
        switch (T = e.valueToCode(T, "LIST", n.NONE) || "{}", O) {
          case "SUM":
            O = E();
            break;
          case "MIN":
            O = e.provideFunction_("math_min", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(t)
  if #t == 0 then
    return 0
  end
  local result = math.huge
  for _, v in ipairs(t) do
    if v < result then
      result = v
    end
  end
  return result
end
`);
            break;
          case "AVERAGE":
            O = e.provideFunction_("math_average", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(t)
  if #t == 0 then
    return 0
  end
  return ${E()}(t) / #t
end
`);
            break;
          case "MAX":
            O = e.provideFunction_("math_max", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(t)
  if #t == 0 then
    return 0
  end
  local result = -math.huge
  for _, v in ipairs(t) do
    if v > result then
      result = v
    end
  end
  return result
end
`);
            break;
          case "MEDIAN":
            O = e.provideFunction_("math_median", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(t)
  -- Source: http://lua-users.org/wiki/SimpleStats
  if #t == 0 then
    return 0
  end
  local temp = {}
  for _, v in ipairs(t) do
    if type(v) == 'number' then
      table.insert(temp, v)
    end
  end
  table.sort(temp)
  if #temp % 2 == 0 then
    return (temp[#temp / 2] + temp[(#temp / 2) + 1]) / 2
  else
    return temp[math.ceil(#temp / 2)]
  end
end
`);
            break;
          case "MODE":
            O = e.provideFunction_("math_modes", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(t)
  -- Source: http://lua-users.org/wiki/SimpleStats
  local counts = {}
  for _, v in ipairs(t) do
    if counts[v] == nil then
      counts[v] = 1
    else
      counts[v] = counts[v] + 1
    end
  end
  local biggestCount = 0
  for _, v  in pairs(counts) do
    if v > biggestCount then
      biggestCount = v
    end
  end
  local temp = {}
  for k, v in pairs(counts) do
    if v == biggestCount then
      table.insert(temp, k)
    end
  end
  return temp
end
`);
            break;
          case "STD_DEV":
            O = e.provideFunction_("math_standard_deviation", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(t)
  local m
  local vm
  local total = 0
  local count = 0
  local result
  m = #t == 0 and 0 or ${E()}(t) / #t
  for _, v in ipairs(t) do
    if type(v) == 'number' then
      vm = v - m
      total = total + (vm * vm)
      count = count + 1
    end
  end
  result = math.sqrt(total / (count-1))
  return result
end
`);
            break;
          case "RANDOM":
            O = e.provideFunction_("math_random_list", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(t)
  if #t == 0 then
    return nil
  end
  return t[math.random(#t)]
end
`);
            break;
          default:
            throw Error("Unknown operator: " + O);
        }
        return [O + "(" + T + ")", n.HIGH];
      }, math_random_float: function() {
        return ["math.random()", n.HIGH];
      }, math_random_int: function(T, e) {
        var E = e.valueToCode(T, "FROM", n.NONE) || "0";
        return T = e.valueToCode(T, "TO", n.NONE) || "0", ["math.random(" + E + ", " + T + ")", n.HIGH];
      } };
      f.math_round = c, f.math_single = c, f.math_trig = c;
      var H = { procedures_callnoreturn: function(T, e) {
        return e.forBlock.procedures_callreturn(T, e)[0] + `
`;
      }, procedures_callreturn: function(T, e) {
        var E = e.getProcedureName(T.getFieldValue("NAME")), O = [], I = T.getVarModels();
        for (let R = 0; R < I.length; R++) O[R] = e.valueToCode(T, "ARG" + R, n.NONE) || "nil";
        return [E + "(" + O.join(", ") + ")", n.HIGH];
      } };
      H.procedures_defnoreturn = d, H.procedures_defreturn = d, H.procedures_ifreturn = function(T, e) {
        var E = "if " + (e.valueToCode(T, "CONDITION", n.NONE) || "false") + ` then
`;
        return e.STATEMENT_SUFFIX && (E += e.prefixLines(e.injectId(e.STATEMENT_SUFFIX, T), e.INDENT)), T.hasReturnValue_ ? (T = e.valueToCode(T, "VALUE", n.NONE) || "nil", E += e.INDENT + "return " + T + `
`) : E += e.INDENT + `return
`, E + `end
`;
      };
      var G = { text: function(T, e) {
        return [e.quote_(T.getFieldValue("TEXT")), n.ATOMIC];
      }, text_append: function(T, e) {
        var E = e.getVariableName(T.getFieldValue("VAR"));
        return T = e.valueToCode(T, "TEXT", n.CONCATENATION) || "''", E + " = " + E + " .. " + T + `
`;
      }, text_changeCase: function(T, e) {
        var E = T.getFieldValue("CASE");
        T = e.valueToCode(T, "TEXT", n.NONE) || "''";
        var O;
        return E === "UPPERCASE" ? O = "string.upper" : E === "LOWERCASE" ? O = "string.lower" : E === "TITLECASE" && (O = e.provideFunction_("text_titlecase", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(str)
  local buf = {}
  local inWord = false
  for i = 1, #str do
    local c = string.sub(str, i, i)
    if inWord then
      table.insert(buf, string.lower(c))
      if string.find(c, "%s") then
        inWord = false
      end
    else
      table.insert(buf, string.upper(c))
      inWord = true
    end
  end
  return table.concat(buf)
end
`)), [O + "(" + T + ")", n.HIGH];
      }, text_charAt: function(T, e) {
        var E = T.getFieldValue("WHERE") || "FROM_START", O = e.valueToCode(T, "VALUE", n.NONE) || "''";
        if (E === "RANDOM") e = e.provideFunction_("text_random_letter", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(str)
  local index = math.random(string.len(str))
  return string.sub(str, index, index)
end
`) + "(" + O + ")";
        else {
          if (E === "FIRST") E = "1";
          else if (E === "LAST") E = "-1";
          else if (T = e.valueToCode(T, "AT", E === "FROM_END" ? n.UNARY : n.NONE) || "1", E === "FROM_START") E = T;
          else if (E === "FROM_END") E = "-" + T;
          else throw Error("Unhandled option (text_charAt).");
          e = E.match(/^-?\w*$/) ? "string.sub(" + O + ", " + E + ", " + E + ")" : e.provideFunction_("text_char_at", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(str, index)
  return string.sub(str, index, index)
end
`) + "(" + O + ", " + E + ")";
        }
        return [e, n.HIGH];
      }, text_count: function(T, e) {
        var E = e.valueToCode(T, "TEXT", n.NONE) || "''";
        return T = e.valueToCode(T, "SUB", n.NONE) || "''", [e.provideFunction_("text_count", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(haystack, needle)
  if #needle == 0 then
    return #haystack + 1
  end
  local i = 1
  local count = 0
  while true do
    i = string.find(haystack, needle, i, true)
    if i == nil then
      break
    end
    count = count + 1
    i = i + #needle
  end
  return count
end
`) + "(" + E + ", " + T + ")", n.HIGH];
      }, text_getSubstring: function(T, e) {
        var E = e.valueToCode(T, "STRING", n.NONE) || "''", O = T.getFieldValue("WHERE1"), I = e.valueToCode(T, "AT1", O === "FROM_END" ? n.UNARY : n.NONE) || "1";
        if (O === "FIRST") O = 1;
        else if (O === "FROM_START") O = I;
        else if (O === "FROM_END") O = "-" + I;
        else throw Error("Unhandled option (text_getSubstring)");
        if (I = T.getFieldValue("WHERE2"), T = e.valueToCode(T, "AT2", I === "FROM_END" ? n.UNARY : n.NONE) || "1", I === "LAST") T = -1;
        else if (I !== "FROM_START") if (I === "FROM_END") T = "-" + T;
        else throw Error("Unhandled option (text_getSubstring)");
        return ["string.sub(" + E + ", " + O + ", " + T + ")", n.HIGH];
      }, text_indexOf: function(T, e) {
        var E = e.valueToCode(T, "FIND", n.NONE) || "''", O = e.valueToCode(T, "VALUE", n.NONE) || "''";
        return [(T.getFieldValue("END") === "FIRST" ? e.provideFunction_("firstIndexOf", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(str, substr)
  local i = string.find(str, substr, 1, true)
  if i == nil then
    return 0
  end
  return i
end
`) : e.provideFunction_("lastIndexOf", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(str, substr)
  local i = string.find(string.reverse(str), string.reverse(substr), 1, true)
  if i then
    return #str + 2 - i - #substr
  end
  return 0
end
`)) + "(" + O + ", " + E + ")", n.HIGH];
      }, text_isEmpty: function(T, e) {
        return ["#" + (e.valueToCode(T, "VALUE", n.UNARY) || "''") + " == 0", n.RELATIONAL];
      }, text_join: function(T, e) {
        if (T.itemCount_ === 0) return ["''", n.ATOMIC];
        if (T.itemCount_ === 1) return ["tostring(" + (e.valueToCode(T, "ADD0", n.NONE) || "''") + ")", n.HIGH];
        if (T.itemCount_ === 2) {
          var E = e.valueToCode(T, "ADD0", n.CONCATENATION) || "''";
          return T = e.valueToCode(T, "ADD1", n.CONCATENATION) || "''", [E + " .. " + T, n.CONCATENATION];
        }
        E = [];
        for (let O = 0; O < T.itemCount_; O++) E[O] = e.valueToCode(
          T,
          "ADD" + O,
          n.NONE
        ) || "''";
        return ["table.concat({" + E.join(", ") + "})", n.HIGH];
      }, text_length: function(T, e) {
        return ["#" + (e.valueToCode(T, "VALUE", n.UNARY) || "''"), n.UNARY];
      }, text_print: function(T, e) {
        return "print(" + (e.valueToCode(T, "TEXT", n.NONE) || "''") + `)
`;
      } };
      G.text_prompt = l, G.text_prompt_ext = l, G.text_replace = function(T, e) {
        var E = e.valueToCode(T, "TEXT", n.NONE) || "''", O = e.valueToCode(T, "FROM", n.NONE) || "''";
        return T = e.valueToCode(T, "TO", n.NONE) || "''", [e.provideFunction_("text_replace", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(haystack, needle, replacement)
  local buf = {}
  local i = 1
  while i <= #haystack do
    if string.sub(haystack, i, i + #needle - 1) == needle then
      for j = 1, #replacement do
        table.insert(buf, string.sub(replacement, j, j))
      end
      i = i + #needle
    else
      table.insert(buf, string.sub(haystack, i, i))
      i = i + 1
    end
  end
  return table.concat(buf)
end
`) + "(" + E + ", " + O + ", " + T + ")", n.HIGH];
      }, G.text_reverse = function(T, e) {
        return ["string.reverse(" + (e.valueToCode(T, "TEXT", n.NONE) || "''") + ")", n.HIGH];
      }, G.text_trim = function(T, e) {
        var E = { LEFT: "^%s*(,-)", RIGHT: "(.-)%s*$", BOTH: "^%s*(.-)%s*$" }[T.getFieldValue("MODE")];
        return ["string.gsub(" + (e.valueToCode(T, "TEXT", n.NONE) || "''") + ', "' + E + '", "%1")', n.HIGH];
      };
      var v = {};
      v.variables_get = A, v.variables_set = N;
      var V = {};
      V.variables_get_dynamic = A, V.variables_set_dynamic = N;
      var X = new M(), t = Object.assign({}, { lists_create_empty: function() {
        return ["{}", n.HIGH];
      }, lists_create_with: function(T, e) {
        var E = Array(T.itemCount_);
        for (let O = 0; O < T.itemCount_; O++) E[O] = e.valueToCode(T, "ADD" + O, n.NONE) || "nil";
        return ["{" + E.join(", ") + "}", n.HIGH];
      }, lists_getIndex: function(T, e) {
        var E = T.getFieldValue("MODE") || "GET", O = T.getFieldValue("WHERE") || "FROM_START", I = e.valueToCode(T, "VALUE", n.HIGH) || "({})";
        return O !== "LAST" && O !== "FROM_END" && O !== "RANDOM" || I.match(/^\w+$/) ? (e = e.valueToCode(T, "AT", E === "GET" && O === "FROM_END" ? n.ADDITIVE : n.NONE) || "1", e = U(I, O, e), E === "GET" ? [I + "[" + e + "]", n.HIGH] : (O = "table.remove(" + I + ", " + e + ")", E === "GET_REMOVE" ? [O, n.HIGH] : O + `
`)) : E === "REMOVE" ? (E = e.valueToCode(T, "AT", O === "FROM_END" ? n.ADDITIVE : n.NONE) || "1", e = e.nameDB_.getDistinctName("tmp_list", s.P.VARIABLE), E = U(e, O, E), e + " = " + I + `
table.remove(` + e + ", " + E + `)
`) : (T = e.valueToCode(T, "AT", n.NONE) || "1", [(E === "GET" ? e.provideFunction_("list_get_" + O.toLowerCase(), ["function " + e.FUNCTION_NAME_PLACEHOLDER_ + "(t" + (O === "FROM_END" || O === "FROM_START" ? ", at)" : ")"), "  return t[" + U("t", O, "at") + "]", "end"]) : e.provideFunction_("list_remove_" + O.toLowerCase(), ["function " + e.FUNCTION_NAME_PLACEHOLDER_ + "(t" + (O === "FROM_END" || O === "FROM_START" ? ", at)" : ")"), "  return table.remove(t, " + U("t", O, "at") + ")", "end"])) + "(" + I + (O === "FROM_END" || O === "FROM_START" ? ", " + T : "") + ")", n.HIGH]);
      }, lists_getSublist: function(T, e) {
        var E = e.valueToCode(T, "LIST", n.NONE) || "{}", O = T.getFieldValue("WHERE1"), I = T.getFieldValue("WHERE2"), R = e.valueToCode(
          T,
          "AT1",
          n.NONE
        ) || "1";
        T = e.valueToCode(T, "AT2", n.NONE) || "1";
        var i = O === "FROM_END" || O === "FROM_START" ? ", at1" : "", S = I === "FROM_END" || I === "FROM_START" ? ", at2" : "";
        return [e.provideFunction_("list_sublist_" + O.toLowerCase() + "_" + I.toLowerCase(), `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(source${i}${S})
  local t = {}
  local start = ${U("source", O, "at1")}
  local finish = ${U("source", I, "at2")}
  for i = start, finish do
    table.insert(t, source[i])
  end
  return t
end
`) + "(" + E + (O === "FROM_END" || O === "FROM_START" ? ", " + R : "") + (I === "FROM_END" || I === "FROM_START" ? ", " + T : "") + ")", n.HIGH];
      }, lists_indexOf: function(T, e) {
        var E = e.valueToCode(T, "FIND", n.NONE) || "''", O = e.valueToCode(T, "VALUE", n.NONE) || "{}";
        return [(T.getFieldValue("END") === "FIRST" ? e.provideFunction_("first_index", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(t, elem)
  for k, v in ipairs(t) do
    if v == elem then
      return k
    end
  end
  return 0
end
`) : e.provideFunction_("last_index", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(t, elem)
  for i = #t, 1, -1 do
    if t[i] == elem then
      return i
    end
  end
  return 0
end
`)) + "(" + O + ", " + E + ")", n.HIGH];
      }, lists_isEmpty: function(T, e) {
        return ["#" + (e.valueToCode(T, "VALUE", n.UNARY) || "{}") + " == 0", n.RELATIONAL];
      }, lists_length: function(T, e) {
        return ["#" + (e.valueToCode(T, "VALUE", n.UNARY) || "{}"), n.UNARY];
      }, lists_repeat: function(T, e) {
        var E = e.provideFunction_("create_list_repeated", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(item, count)
  local t = {}
  for i = 1, count do
    table.insert(t, item)
  end
  return t
end
  `), O = e.valueToCode(T, "ITEM", n.NONE) || "nil";
        return T = e.valueToCode(T, "NUM", n.NONE) || "0", [E + "(" + O + ", " + T + ")", n.HIGH];
      }, lists_reverse: function(T, e) {
        return T = e.valueToCode(T, "LIST", n.NONE) || "{}", [e.provideFunction_("list_reverse", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(input)
  local reversed = {}
  for i = #input, 1, -1 do
    table.insert(reversed, input[i])
  end
  return reversed
end
`) + "(" + T + ")", n.HIGH];
      }, lists_setIndex: function(T, e) {
        var E = e.valueToCode(T, "LIST", n.HIGH) || "{}", O = T.getFieldValue("MODE") || "SET", I = T.getFieldValue("WHERE") || "FROM_START", R = e.valueToCode(T, "AT", n.ADDITIVE) || "1";
        T = e.valueToCode(T, "TO", n.NONE) || "Nil";
        var i = "";
        return I !== "LAST" && I !== "FROM_END" && I !== "RANDOM" || E.match(/^\w+$/) || (e = e.nameDB_.getDistinctName("tmp_list", s.P.VARIABLE), i = e + " = " + E + `
`, E = e), i = O === "SET" ? i + (E + "[" + U(E, I, R) + "] = " + T) : i + ("table.insert(" + E + ", " + (U(E, I, R) + (I === "LAST" ? " + 1" : "")) + ", " + T + ")"), i + `
`;
      }, lists_sort: function(T, e) {
        var E = e.valueToCode(T, "LIST", n.NONE) || "{}", O = T.getFieldValue("DIRECTION") === "1" ? 1 : -1;
        return T = T.getFieldValue("TYPE"), [e.provideFunction_("list_sort", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(list, typev, direction)
  local t = {}
  for n,v in pairs(list) do table.insert(t, v) end
  local compareFuncs = {
    NUMERIC = function(a, b)
      return (tonumber(tostring(a)) or 0)
          < (tonumber(tostring(b)) or 0) end,
    TEXT = function(a, b)
      return tostring(a) < tostring(b) end,
    IGNORE_CASE = function(a, b)
      return string.lower(tostring(a)) < string.lower(tostring(b)) end
  }
  local compareTemp = compareFuncs[typev]
  local compare = compareTemp
  if direction == -1
  then compare = function(a, b) return compareTemp(b, a) end
  end
  table.sort(t, compare)
  return t
end
`) + "(" + E + ',"' + T + '", ' + O + ")", n.HIGH];
      }, lists_split: function(T, e) {
        var E = e.valueToCode(T, "INPUT", n.NONE), O = e.valueToCode(T, "DELIM", n.NONE) || "''";
        if (T = T.getFieldValue("MODE"), T === "SPLIT") E || (E = "''"), e = e.provideFunction_("list_string_split", `
function ${e.FUNCTION_NAME_PLACEHOLDER_}(input, delim)
  local t = {}
  local pos = 1
  while true do
    next_delim = string.find(input, delim, pos)
    if next_delim == nil then
      table.insert(t, string.sub(input, pos))
      break
    else
      table.insert(t, string.sub(input, pos, next_delim-1))
      pos = next_delim + #delim
    end
  end
  return t
end
`);
        else if (T === "JOIN") E || (E = "{}"), e = "table.concat";
        else throw Error("Unknown mode: " + T);
        return [e + "(" + E + ", " + O + ")", n.HIGH];
      } }, F, h, f, H, G, v, V);
      for (let T in t) X.forBlock[T] = t[T];
      var L = {};
      return L.LuaGenerator = M, L.Order = n, L.luaGenerator = X, s.__chunk_lua = L, s.__chunk_lua.__namespace__ = s, s.__chunk_lua;
    });
  })(z)), z.exports;
}
var Q = { exports: {} }, yd = Q.exports, A_;
function Wd() {
  return A_ || (A_ = 1, (function(g, C) {
    (function(_, s) {
      g.exports = s(K());
    })(yd, function(_) {
      var s = _.__namespace__, U = function(t, L) {
        var T = 0, e = "";
        L.STATEMENT_PREFIX && (e += L.injectId(L.STATEMENT_PREFIX, t));
        do {
          var E = L.valueToCode(t, "IF" + T, A.NONE) || "false", O = L.statementToCode(t, "DO" + T);
          L.STATEMENT_SUFFIX && (O = L.prefixLines(L.injectId(L.STATEMENT_SUFFIX, t), L.INDENT) + O), e += (T > 0 ? " else " : "") + "if (" + E + `) {
` + O + "}", T++;
        } while (t.getInput("IF" + T));
        return (t.getInput("ELSE") || L.STATEMENT_SUFFIX) && (O = t.getInput("ELSE") ? L.statementToCode(t, "ELSE") : "", L.STATEMENT_SUFFIX && (O = L.prefixLines(L.injectId(L.STATEMENT_SUFFIX, t), L.INDENT) + O), e += ` else {
` + O + "}"), e + `
`;
      }, D = function(t, L) {
        var T = t.getField("TIMES") ? String(Number(t.getFieldValue("TIMES"))) : L.valueToCode(t, "TIMES", A.ASSIGNMENT) || "0", e = L.statementToCode(t, "DO");
        e = L.addLoopTrap(e, t), t = "";
        var E = L.nameDB_.getDistinctName("count", s.P.VARIABLE), O = T;
        return T.match(/^\w+$/) || s.zf(T) || (O = L.nameDB_.getDistinctName("repeat_end", s.P.VARIABLE), t += O + " = " + T + `;
`), t + ("for (" + E + " = 0; " + E + " < " + O + "; " + E + `++) {
` + e + `}
`);
      }, u = function(t, L) {
        var T = t.getFieldValue("OP");
        if (T === "NEG") return t = L.valueToCode(t, "NUM", A.UNARY_NEGATION) || "0", t[0] === "-" && (t = " " + t), ["-" + t, A.UNARY_NEGATION];
        switch (t = T === "SIN" || T === "COS" || T === "TAN" ? L.valueToCode(t, "NUM", A.DIVISION) || "0" : L.valueToCode(t, "NUM", A.NONE) || "0", T) {
          case "ABS":
            var e = "abs(" + t + ")";
            break;
          case "ROOT":
            e = "sqrt(" + t + ")";
            break;
          case "LN":
            e = "log(" + t + ")";
            break;
          case "EXP":
            e = "exp(" + t + ")";
            break;
          case "POW10":
            e = "pow(10," + t + ")";
            break;
          case "ROUND":
            e = "round(" + t + ")";
            break;
          case "ROUNDUP":
            e = "ceil(" + t + ")";
            break;
          case "ROUNDDOWN":
            e = "floor(" + t + ")";
            break;
          case "SIN":
            e = "sin(" + t + " / 180 * pi())";
            break;
          case "COS":
            e = "cos(" + t + " / 180 * pi())";
            break;
          case "TAN":
            e = "tan(" + t + " / 180 * pi())";
        }
        if (e) return [e, A.FUNCTION_CALL];
        switch (T) {
          case "LOG10":
            e = "log(" + t + ") / log(10)";
            break;
          case "ASIN":
            e = "asin(" + t + ") / pi() * 180";
            break;
          case "ACOS":
            e = "acos(" + t + ") / pi() * 180";
            break;
          case "ATAN":
            e = "atan(" + t + ") / pi() * 180";
            break;
          default:
            throw Error("Unknown math operator: " + T);
        }
        return [e, A.DIVISION];
      }, B = function(t, L) {
        var T = [], e = t.workspace, E = s.Bd(e) || [];
        for (var O of E) E = O.getName(), t.getVarModels().includes(O) || T.push(L.getVariableName(E));
        for (e = s.Cd(e), O = 0; O < e.length; O++) T.push(L.nameDB_.getName(e[O], s.P.DEVELOPER_VARIABLE));
        e = T.length ? L.INDENT + "global " + T.join(", ") + `;
` : "", T = L.getProcedureName(t.getFieldValue("NAME")), O = "", L.STATEMENT_PREFIX && (O += L.injectId(L.STATEMENT_PREFIX, t)), L.STATEMENT_SUFFIX && (O += L.injectId(L.STATEMENT_SUFFIX, t)), O && (O = L.prefixLines(O, L.INDENT)), E = "", L.INFINITE_LOOP_TRAP && (E = L.prefixLines(L.injectId(L.INFINITE_LOOP_TRAP, t), L.INDENT));
        var I = "";
        t.getInput("STACK") && (I = L.statementToCode(t, "STACK"));
        var R = "";
        t.getInput("RETURN") && (R = L.valueToCode(t, "RETURN", A.NONE) || "");
        var i = "";
        I && R && (i = O), R && (R = L.INDENT + "return " + R + `;
`);
        var S = [], o = t.getVarModels();
        for (let P = 0; P < o.length; P++) S[P] = L.getVariableName(o[P].getId());
        return e = "function " + T + "(" + S.join(", ") + `) {
` + e + O + E + I + i + R + "}", e = L.scrub_(t, e), L.definitions_["%" + T] = e, null;
      }, c = function(t, L) {
        return L = "readline(" + (t.getField("TEXT") ? L.quote_(t.getFieldValue("TEXT")) : L.valueToCode(t, "TEXT", A.NONE) || "''") + ")", t.getFieldValue("TYPE") === "NUMBER" && (L = "floatval(" + L + ")"), [L, A.FUNCTION_CALL];
      }, d = function(t, L) {
        return [L.getVariableName(t.getFieldValue("VAR")), A.ATOMIC];
      }, l = function(t, L) {
        var T = L.valueToCode(t, "VALUE", A.ASSIGNMENT) || "0";
        return L.getVariableName(t.getFieldValue("VAR")) + " = " + T + `;
`;
      }, A, N = A || (A = {});
      N[N.ATOMIC = 0] = "ATOMIC", N[N.CLONE = 1] = "CLONE", N[N.NEW = 1] = "NEW", N[N.MEMBER = 2.1] = "MEMBER", N[N.FUNCTION_CALL = 2.2] = "FUNCTION_CALL", N[N.POWER = 3] = "POWER", N[N.INCREMENT = 4] = "INCREMENT", N[N.DECREMENT = 4] = "DECREMENT", N[N.BITWISE_NOT = 4] = "BITWISE_NOT", N[N.CAST = 4] = "CAST", N[N.SUPPRESS_ERROR = 4] = "SUPPRESS_ERROR", N[N.INSTANCEOF = 5] = "INSTANCEOF", N[N.LOGICAL_NOT = 6] = "LOGICAL_NOT", N[N.UNARY_PLUS = 7.1] = "UNARY_PLUS", N[N.UNARY_NEGATION = 7.2] = "UNARY_NEGATION", N[N.MULTIPLICATION = 8.1] = "MULTIPLICATION", N[N.DIVISION = 8.2] = "DIVISION", N[N.MODULUS = 8.3] = "MODULUS", N[N.ADDITION = 9.1] = "ADDITION", N[N.SUBTRACTION = 9.2] = "SUBTRACTION", N[N.STRING_CONCAT = 9.3] = "STRING_CONCAT", N[N.BITWISE_SHIFT = 10] = "BITWISE_SHIFT", N[N.RELATIONAL = 11] = "RELATIONAL", N[N.EQUALITY = 12] = "EQUALITY", N[N.REFERENCE = 13] = "REFERENCE", N[N.BITWISE_AND = 13] = "BITWISE_AND", N[N.BITWISE_XOR = 14] = "BITWISE_XOR", N[N.BITWISE_OR = 15] = "BITWISE_OR", N[N.LOGICAL_AND = 16] = "LOGICAL_AND", N[N.LOGICAL_OR = 17] = "LOGICAL_OR", N[N.IF_NULL = 18] = "IF_NULL", N[N.CONDITIONAL = 19] = "CONDITIONAL", N[N.ASSIGNMENT = 20] = "ASSIGNMENT", N[N.LOGICAL_AND_WEAK = 21] = "LOGICAL_AND_WEAK", N[N.LOGICAL_XOR = 22] = "LOGICAL_XOR", N[N.LOGICAL_OR_WEAK = 23] = "LOGICAL_OR_WEAK", N[N.NONE = 99] = "NONE";
      var n = class extends s.zq {
        constructor(t = "PHP") {
          super(t), this.ORDER_OVERRIDES = [[A.MEMBER, A.FUNCTION_CALL], [A.MEMBER, A.MEMBER], [A.LOGICAL_NOT, A.LOGICAL_NOT], [A.MULTIPLICATION, A.MULTIPLICATION], [A.ADDITION, A.ADDITION], [A.LOGICAL_AND, A.LOGICAL_AND], [A.LOGICAL_OR, A.LOGICAL_OR]], this.isInitialized = !1;
          for (let L in A) t = A[L], typeof t != "string" && (this["ORDER_" + L] = t);
          this.addReservedWords("__halt_compiler,abstract,and,array,as,break,callable,case,catch,class,clone,const,continue,declare,default,die,do,echo,else,elseif,empty,enddeclare,endfor,endforeach,endif,endswitch,endwhile,eval,exit,extends,final,for,foreach,function,global,goto,if,implements,include,include_once,instanceof,insteadof,interface,isset,list,namespace,new,or,print,private,protected,public,require,require_once,return,static,switch,throw,trait,try,unset,use,var,while,xor,PHP_VERSION,PHP_MAJOR_VERSION,PHP_MINOR_VERSION,PHP_RELEASE_VERSION,PHP_VERSION_ID,PHP_EXTRA_VERSION,PHP_ZTS,PHP_DEBUG,PHP_MAXPATHLEN,PHP_OS,PHP_SAPI,PHP_EOL,PHP_INT_MAX,PHP_INT_SIZE,DEFAULT_INCLUDE_PATH,PEAR_INSTALL_DIR,PEAR_EXTENSION_DIR,PHP_EXTENSION_DIR,PHP_PREFIX,PHP_BINDIR,PHP_BINARY,PHP_MANDIR,PHP_LIBDIR,PHP_DATADIR,PHP_SYSCONFDIR,PHP_LOCALSTATEDIR,PHP_CONFIG_FILE_PATH,PHP_CONFIG_FILE_SCAN_DIR,PHP_SHLIB_SUFFIX,E_ERROR,E_WARNING,E_PARSE,E_NOTICE,E_CORE_ERROR,E_CORE_WARNING,E_COMPILE_ERROR,E_COMPILE_WARNING,E_USER_ERROR,E_USER_WARNING,E_USER_NOTICE,E_DEPRECATED,E_USER_DEPRECATED,E_ALL,E_STRICT,__COMPILER_HALT_OFFSET__,TRUE,FALSE,NULL,__CLASS__,__DIR__,__FILE__,__FUNCTION__,__LINE__,__METHOD__,__NAMESPACE__,__TRAIT__");
        }
        init(t) {
          super.init(t), this.nameDB_ ? this.nameDB_.reset() : this.nameDB_ = new s.Cj(this.RESERVED_WORDS_, "$"), this.nameDB_.setVariableMap(t.getVariableMap()), this.nameDB_.populateVariables(t), this.nameDB_.populateProcedures(t), this.isInitialized = !0;
        }
        finish(t) {
          var L = Object.values(this.definitions_);
          return t = super.finish(t), this.isInitialized = !1, this.nameDB_.reset(), L.join(`

`) + `


` + t;
        }
        scrubNakedValue(t) {
          return t + `;
`;
        }
        quote_(t) {
          return t = t.replace(/\\/g, "\\\\").replace(/\n/g, `\\
`).replace(/'/g, "\\'"), "'" + t + "'";
        }
        multiline_quote_(t) {
          return t.split(/\n/g).map(this.quote_).join(` . "\\n" .
`);
        }
        scrub_(t, L, T = !1) {
          var e = "";
          if (!t.outputConnection || !t.outputConnection.targetConnection) {
            var E = t.getCommentText();
            E && (E = s.yf(E, this.COMMENT_WRAP - 3), e += this.prefixLines(E, "// ") + `
`);
            for (let O = 0; O < t.inputList.length; O++) t.inputList[O].type === s.je.VALUE && (E = t.inputList[O].connection.targetBlock()) && (E = this.allNestedComments(E)) && (e += this.prefixLines(E, "// "));
          }
          return t = t.nextConnection && t.nextConnection.targetBlock(), T = T ? "" : this.blockToCode(t), e + L + T;
        }
        getAdjusted(t, L, T = 0, e = !1, E = A.NONE) {
          t.workspace.options.oneBasedIndex && T--;
          var O = t.workspace.options.oneBasedIndex ? "1" : "0", I = E;
          return T > 0 ? I = A.ADDITION : T < 0 ? I = A.SUBTRACTION : e && (I = A.UNARY_NEGATION), t = this.valueToCode(t, L, I) || O, T === 0 && !e ? t : s.zf(t) ? (t = String(Number(t) + T), e && (t = String(-Number(t))), t) : (T > 0 ? t = `${t} + ${T}` : T < 0 && (t = `${t} - ${-T}`), e && (t = T ? `-(${t})` : `-${t}`), Math.floor(E) >= Math.floor(I) && (t = `(${t})`), t);
        }
      }, r = {};
      r.controls_if = U, r.controls_ifelse = U, r.logic_boolean = function(t) {
        return [t.getFieldValue("BOOL") === "TRUE" ? "true" : "false", A.ATOMIC];
      }, r.logic_compare = function(t, L) {
        var T = { EQ: "==", NEQ: "!=", LT: "<", LTE: "<=", GT: ">", GTE: ">=" }[t.getFieldValue("OP")], e = T === "==" || T === "!=" ? A.EQUALITY : A.RELATIONAL, E = L.valueToCode(t, "A", e) || "0";
        return t = L.valueToCode(t, "B", e) || "0", [E + " " + T + " " + t, e];
      }, r.logic_negate = function(t, L) {
        var T = A.LOGICAL_NOT;
        return ["!" + (L.valueToCode(t, "BOOL", T) || "true"), T];
      }, r.logic_null = function() {
        return ["null", A.ATOMIC];
      }, r.logic_operation = function(t, L) {
        var T = t.getFieldValue("OP") === "AND" ? "&&" : "||", e = T === "&&" ? A.LOGICAL_AND : A.LOGICAL_OR, E = L.valueToCode(t, "A", e);
        return t = L.valueToCode(t, "B", e), E || t ? (L = T === "&&" ? "true" : "false", E || (E = L), t || (t = L)) : t = E = "false", [E + " " + T + " " + t, e];
      }, r.logic_ternary = function(t, L) {
        var T = L.valueToCode(t, "IF", A.CONDITIONAL) || "false", e = L.valueToCode(t, "THEN", A.CONDITIONAL) || "null";
        return t = L.valueToCode(t, "ELSE", A.CONDITIONAL) || "null", [T + " ? " + e + " : " + t, A.CONDITIONAL];
      };
      var M = { controls_flow_statements: function(t, L) {
        var T = "";
        if (L.STATEMENT_PREFIX && (T += L.injectId(L.STATEMENT_PREFIX, t)), L.STATEMENT_SUFFIX && (T += L.injectId(L.STATEMENT_SUFFIX, t)), L.STATEMENT_PREFIX) {
          let e = t.getSurroundLoop();
          e && !e.suppressPrefixSuffix && (T += L.injectId(L.STATEMENT_PREFIX, e));
        }
        switch (t.getFieldValue("FLOW")) {
          case "BREAK":
            return T + `break;
`;
          case "CONTINUE":
            return T + `continue;
`;
        }
        throw Error("Unknown flow statement.");
      }, controls_for: function(t, L) {
        var T = L.getVariableName(t.getFieldValue("VAR")), e = L.valueToCode(t, "FROM", A.ASSIGNMENT) || "0", E = L.valueToCode(t, "TO", A.ASSIGNMENT) || "0", O = L.valueToCode(t, "BY", A.ASSIGNMENT) || "1", I = L.statementToCode(t, "DO");
        if (I = L.addLoopTrap(I, t), s.zf(e) && s.zf(E) && s.zf(O)) L = Number(e) <= Number(E), t = "for (" + T + " = " + e + "; " + T + (L ? " <= " : " >= ") + E + "; " + T, T = Math.abs(Number(O)), t = T === 1 ? t + (L ? "++" : "--") : t + ((L ? " += " : " -= ") + T), t += `) {
` + I + `}
`;
        else {
          t = "";
          let R = e;
          e.match(/^\w+$/) || s.zf(e) || (R = L.nameDB_.getDistinctName(T + "_start", s.P.VARIABLE), t += R + " = " + e + `;
`), e = E, E.match(/^\w+$/) || s.zf(E) || (e = L.nameDB_.getDistinctName(T + "_end", s.P.VARIABLE), t += e + " = " + E + `;
`), E = L.nameDB_.getDistinctName(T + "_inc", s.P.VARIABLE), t += E + " = ", t = s.zf(O) ? t + (Math.abs(Number(O)) + `;
`) : t + ("abs(" + O + `);
`), t += "if (" + R + " > " + e + `) {
`, t += L.INDENT + E + " = -" + E + `;
`, t = t + `}
for (` + (T + " = " + R + "; " + E + " >= 0 ? " + T + " <= " + e + " : " + T + " >= " + e + "; " + T + " += " + E + `) {
` + I + `}
`);
        }
        return t;
      }, controls_forEach: function(t, L) {
        var T = L.getVariableName(t.getFieldValue("VAR")), e = L.valueToCode(t, "LIST", A.ASSIGNMENT) || "[]", E = L.statementToCode(t, "DO");
        return E = L.addLoopTrap(E, t), "foreach (" + e + " as " + T + `) {
` + E + `}
`;
      } };
      M.controls_repeat = D, M.controls_repeat_ext = D, M.controls_whileUntil = function(t, L) {
        var T = t.getFieldValue("MODE") === "UNTIL", e = L.valueToCode(t, "BOOL", T ? A.LOGICAL_NOT : A.NONE) || "false", E = L.statementToCode(t, "DO");
        return E = L.addLoopTrap(E, t), T && (e = "!" + e), "while (" + e + `) {
` + E + `}
`;
      };
      var F = { math_arithmetic: function(t, L) {
        var T = { ADD: [" + ", A.ADDITION], MINUS: [" - ", A.SUBTRACTION], MULTIPLY: [" * ", A.MULTIPLICATION], DIVIDE: [" / ", A.DIVISION], POWER: [" ** ", A.POWER] }[t.getFieldValue("OP")], e = T[0];
        T = T[1];
        var E = L.valueToCode(t, "A", T) || "0";
        return t = L.valueToCode(t, "B", T) || "0", [E + e + t, T];
      }, math_atan2: function(t, L) {
        var T = L.valueToCode(t, "X", A.NONE) || "0";
        return ["atan2(" + (L.valueToCode(t, "Y", A.NONE) || "0") + ", " + T + ") / pi() * 180", A.DIVISION];
      }, math_change: function(t, L) {
        var T = L.valueToCode(
          t,
          "DELTA",
          A.ADDITION
        ) || "0";
        return L.getVariableName(t.getFieldValue("VAR")) + " += " + T + `;
`;
      }, math_constant: function(t) {
        return { PI: ["M_PI", A.ATOMIC], E: ["M_E", A.ATOMIC], GOLDEN_RATIO: ["(1 + sqrt(5)) / 2", A.DIVISION], SQRT2: ["M_SQRT2", A.ATOMIC], SQRT1_2: ["M_SQRT1_2", A.ATOMIC], INFINITY: ["INF", A.ATOMIC] }[t.getFieldValue("CONSTANT")];
      }, math_constrain: function(t, L) {
        var T = L.valueToCode(t, "VALUE", A.NONE) || "0", e = L.valueToCode(t, "LOW", A.NONE) || "0";
        return t = L.valueToCode(t, "HIGH", A.NONE) || "Infinity", ["min(max(" + T + ", " + e + "), " + t + ")", A.FUNCTION_CALL];
      }, math_modulo: function(t, L) {
        var T = L.valueToCode(t, "DIVIDEND", A.MODULUS) || "0";
        return t = L.valueToCode(t, "DIVISOR", A.MODULUS) || "0", [T + " % " + t, A.MODULUS];
      }, math_number: function(t) {
        return t = Number(t.getFieldValue("NUM")), t === 1 / 0 ? ["INF", A.ATOMIC] : t === -1 / 0 ? ["-INF", A.UNARY_NEGATION] : [String(t), t >= 0 ? A.ATOMIC : A.UNARY_NEGATION];
      }, math_number_property: function(t, L) {
        var T = { EVEN: ["", " % 2 == 0", A.MODULUS, A.EQUALITY], ODD: ["", " % 2 == 1", A.MODULUS, A.EQUALITY], WHOLE: [
          "is_int(",
          ")",
          A.NONE,
          A.FUNCTION_CALL
        ], POSITIVE: ["", " > 0", A.RELATIONAL, A.RELATIONAL], NEGATIVE: ["", " < 0", A.RELATIONAL, A.RELATIONAL], DIVISIBLE_BY: [null, null, A.MODULUS, A.EQUALITY], PRIME: [null, null, A.NONE, A.FUNCTION_CALL] }, e = t.getFieldValue("PROPERTY"), [E, O, I, R] = T[e];
        if (T = L.valueToCode(t, "NUMBER_TO_CHECK", I) || "0", e === "PRIME") t = L.provideFunction_("math_isPrime", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($n) {
  // https://en.wikipedia.org/wiki/Primality_test#Naive_methods
  if ($n == 2 || $n == 3) {
    return true;
  }
  // False if n is NaN, negative, is 1, or not whole.
  // And false if n is divisible by 2 or 3.
  if (!is_numeric($n) || $n <= 1 || $n % 1 != 0 || $n % 2 == 0 || $n % 3 == 0) {
    return false;
  }
  // Check all the numbers of form 6k +/- 1, up to sqrt(n).
  for ($x = 6; $x <= sqrt($n) + 1; $x += 6) {
    if ($n % ($x - 1) == 0 || $n % ($x + 1) == 0) {
      return false;
    }
  }
  return true;
}
`) + "(" + T + ")";
        else if (e === "DIVISIBLE_BY") {
          if (t = L.valueToCode(t, "DIVISOR", A.MODULUS) || "0", t === "0") return ["false", A.ATOMIC];
          t = T + " % " + t + " == 0";
        } else t = E + T + O;
        return [t, R];
      }, math_on_list: function(t, L) {
        var T = t.getFieldValue("OP");
        switch (T) {
          case "SUM":
            t = L.valueToCode(t, "LIST", A.FUNCTION_CALL) || "array()", t = "array_sum(" + t + ")";
            break;
          case "MIN":
            t = L.valueToCode(t, "LIST", A.FUNCTION_CALL) || "array()", t = "min(" + t + ")";
            break;
          case "MAX":
            t = L.valueToCode(t, "LIST", A.FUNCTION_CALL) || "array()", t = "max(" + t + ")";
            break;
          case "AVERAGE":
            T = L.provideFunction_("math_mean", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($myList) {
  return array_sum($myList) / count($myList);
}
`), t = L.valueToCode(t, "LIST", A.NONE) || "array()", t = T + "(" + t + ")";
            break;
          case "MEDIAN":
            T = L.provideFunction_("math_median", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($arr) {
  sort($arr,SORT_NUMERIC);
  return (count($arr) % 2) ? $arr[floor(count($arr) / 2)] :
      ($arr[floor(count($arr) / 2)] + $arr[floor(count($arr) / 2) - 1]) / 2;
}
`), t = L.valueToCode(t, "LIST", A.NONE) || "[]", t = T + "(" + t + ")";
            break;
          case "MODE":
            T = L.provideFunction_("math_modes", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($values) {
  if (empty($values)) return array();
  $counts = array_count_values($values);
  arsort($counts); // Sort counts in descending order
  $modes = array_keys($counts, current($counts), true);
  return $modes;
}
`), t = L.valueToCode(t, "LIST", A.NONE) || "[]", t = T + "(" + t + ")";
            break;
          case "STD_DEV":
            T = L.provideFunction_("math_standard_deviation", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($numbers) {
  $n = count($numbers);
  if (!$n) return null;
  $mean = array_sum($numbers) / count($numbers);
  foreach($numbers as $key => $num) $devs[$key] = pow($num - $mean, 2);
  return sqrt(array_sum($devs) / (count($devs) - 1));
}
`), t = L.valueToCode(t, "LIST", A.NONE) || "[]", t = T + "(" + t + ")";
            break;
          case "RANDOM":
            T = L.provideFunction_("math_random_list", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($list) {
  $x = rand(0, count($list)-1);
  return $list[$x];
}
`), t = L.valueToCode(t, "LIST", A.NONE) || "[]", t = T + "(" + t + ")";
            break;
          default:
            throw Error("Unknown operator: " + T);
        }
        return [t, A.FUNCTION_CALL];
      }, math_random_float: function() {
        return ["(float)rand()/(float)getrandmax()", A.FUNCTION_CALL];
      }, math_random_int: function(t, L) {
        var T = L.valueToCode(t, "FROM", A.NONE) || "0";
        return t = L.valueToCode(t, "TO", A.NONE) || "0", [L.provideFunction_("math_random_int", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($a, $b) {
  if ($a > $b) {
    return rand($b, $a);
  }
  return rand($a, $b);
}
`) + "(" + T + ", " + t + ")", A.FUNCTION_CALL];
      } };
      F.math_round = u, F.math_single = u, F.math_trig = u;
      var h = { procedures_callnoreturn: function(t, L) {
        return L.forBlock.procedures_callreturn(t, L)[0] + `;
`;
      }, procedures_callreturn: function(t, L) {
        var T = L.getProcedureName(t.getFieldValue("NAME")), e = [], E = t.getVarModels();
        for (let O = 0; O < E.length; O++) e[O] = L.valueToCode(t, "ARG" + O, A.NONE) || "null";
        return [T + "(" + e.join(", ") + ")", A.FUNCTION_CALL];
      } };
      h.procedures_defnoreturn = B, h.procedures_defreturn = B, h.procedures_ifreturn = function(t, L) {
        var T = "if (" + (L.valueToCode(t, "CONDITION", A.NONE) || "false") + `) {
`;
        return L.STATEMENT_SUFFIX && (T += L.prefixLines(L.injectId(L.STATEMENT_SUFFIX, t), L.INDENT)), t.hasReturnValue_ ? (t = L.valueToCode(t, "VALUE", A.NONE) || "null", T += L.INDENT + "return " + t + `;
`) : T += L.INDENT + `return;
`, T + `}
`;
      };
      var f = {
        text: function(t, L) {
          return [L.quote_(t.getFieldValue("TEXT")), A.ATOMIC];
        },
        text_append: function(t, L) {
          var T = L.getVariableName(t.getFieldValue("VAR"));
          return t = L.valueToCode(t, "TEXT", A.ASSIGNMENT) || "''", T + " .= " + t + `;
`;
        },
        text_changeCase: function(t, L) {
          L = L.valueToCode(t, "TEXT", A.NONE) || "''";
          var T;
          return t.getFieldValue("CASE") === "UPPERCASE" ? T = "strtoupper(" + L + ")" : t.getFieldValue("CASE") === "LOWERCASE" ? T = "strtolower(" + L + ")" : t.getFieldValue("CASE") === "TITLECASE" && (T = "ucwords(strtolower(" + L + "))"), [T, A.FUNCTION_CALL];
        },
        text_charAt: function(t, L) {
          var T = t.getFieldValue("WHERE") || "FROM_START", e = L.valueToCode(t, "VALUE", A.NONE) || "''";
          switch (T) {
            case "FIRST":
              return ["substr(" + e + ", 0, 1)", A.FUNCTION_CALL];
            case "LAST":
              return ["substr(" + e + ", -1)", A.FUNCTION_CALL];
            case "FROM_START":
              return t = L.getAdjusted(t, "AT"), ["substr(" + e + ", " + t + ", 1)", A.FUNCTION_CALL];
            case "FROM_END":
              return t = L.getAdjusted(t, "AT", 1, !0), ["substr(" + e + ", " + t + ", 1)", A.FUNCTION_CALL];
            case "RANDOM":
              return [L.provideFunction_("text_random_letter", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($text) {
  return $text[rand(0, strlen($text) - 1)];
}
`) + "(" + e + ")", A.FUNCTION_CALL];
          }
          throw Error("Unhandled option (text_charAt).");
        },
        text_count: function(t, L) {
          var T = L.valueToCode(t, "TEXT", A.NONE) || "''";
          return t = L.valueToCode(t, "SUB", A.NONE) || "''", ["strlen(" + t + ") === 0 ? strlen(" + T + ") + 1 : substr_count(" + T + ", " + t + ")", A.CONDITIONAL];
        },
        text_getSubstring: function(t, L) {
          var T = t.getFieldValue("WHERE1"), e = t.getFieldValue("WHERE2"), E = L.valueToCode(t, "STRING", A.NONE) || "''";
          if (T === "FIRST" && e === "LAST") return [E, A.NONE];
          var O = L.getAdjusted(t, "AT1");
          return t = L.getAdjusted(
            t,
            "AT2"
          ), [L.provideFunction_("text_get_substring", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($text, $where1, $at1, $where2, $at2) {
  if ($where1 == 'FROM_END') {
    $at1 = strlen($text) - 1 - $at1;
  } else if ($where1 == 'FIRST') {
    $at1 = 0;
  } else if ($where1 != 'FROM_START') {
    throw new Exception('Unhandled option (text_get_substring).');
  }
  $length = 0;
  if ($where2 == 'FROM_START') {
    $length = $at2 - $at1 + 1;
  } else if ($where2 == 'FROM_END') {
    $length = strlen($text) - $at1 - $at2;
  } else if ($where2 == 'LAST') {
    $length = strlen($text) - $at1;
  } else {
    throw new Exception('Unhandled option (text_get_substring).');
  }
  return substr($text, $at1, $length);
}
`) + "(" + E + ", '" + T + "', " + O + ", '" + e + "', " + t + ")", A.FUNCTION_CALL];
        },
        text_indexOf: function(t, L) {
          var T = t.getFieldValue("END") === "FIRST" ? "strpos" : "strrpos", e = L.valueToCode(t, "FIND", A.NONE) || "''", E = L.valueToCode(t, "VALUE", A.NONE) || "''", O = " -1", I = "";
          return t.workspace.options.oneBasedIndex && (O = " 0", I = " + 1"), [L.provideFunction_(t.getFieldValue("END") === "FIRST" ? "text_indexOf" : "text_lastIndexOf", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($text, $search) {
  $pos = ${T}($text, $search);
  return $pos === false ? ${O} : $pos${I};
}
`) + "(" + E + ", " + e + ")", A.FUNCTION_CALL];
        },
        text_isEmpty: function(t, L) {
          return ["empty(" + (L.valueToCode(t, "VALUE", A.NONE) || "''") + ")", A.FUNCTION_CALL];
        },
        text_join: function(t, L) {
          if (t.itemCount_ === 0) return ["''", A.ATOMIC];
          if (t.itemCount_ === 1) return [L.valueToCode(t, "ADD0", A.NONE) || "''", A.NONE];
          if (t.itemCount_ === 2) {
            var T = L.valueToCode(t, "ADD0", A.STRING_CONCAT) || "''";
            return t = L.valueToCode(t, "ADD1", A.STRING_CONCAT) || "''", [T + " . " + t, A.STRING_CONCAT];
          }
          T = Array(t.itemCount_);
          for (let e = 0; e < t.itemCount_; e++) T[e] = L.valueToCode(
            t,
            "ADD" + e,
            A.NONE
          ) || "''";
          return ["implode('', array(" + T.join(",") + "))", A.FUNCTION_CALL];
        },
        text_length: function(t, L) {
          var T = L.provideFunction_("length", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($value) {
  if (is_string($value)) {
    return strlen($value);
  }
  return count($value);
}
`);
          return t = L.valueToCode(t, "VALUE", A.NONE) || "''", [T + "(" + t + ")", A.FUNCTION_CALL];
        },
        text_print: function(t, L) {
          return "print(" + (L.valueToCode(t, "TEXT", A.NONE) || "''") + `);
`;
        }
      };
      f.text_prompt = c, f.text_prompt_ext = c, f.text_replace = function(t, L) {
        var T = L.valueToCode(t, "TEXT", A.NONE) || "''", e = L.valueToCode(t, "FROM", A.NONE) || "''";
        return t = L.valueToCode(t, "TO", A.NONE) || "''", ["str_replace(" + e + ", " + t + ", " + T + ")", A.FUNCTION_CALL];
      }, f.text_reverse = function(t, L) {
        return ["strrev(" + (L.valueToCode(t, "TEXT", A.NONE) || "''") + ")", A.FUNCTION_CALL];
      }, f.text_trim = function(t, L) {
        var T = { LEFT: "ltrim", RIGHT: "rtrim", BOTH: "trim" }[t.getFieldValue("MODE")];
        return t = L.valueToCode(t, "TEXT", A.NONE) || "''", [T + "(" + t + ")", A.FUNCTION_CALL];
      };
      var H = {};
      H.variables_get = d, H.variables_set = l;
      var G = {};
      G.variables_get_dynamic = d, G.variables_set_dynamic = l;
      var v = new n(), V = Object.assign({}, { lists_create_empty: function() {
        return ["array()", A.FUNCTION_CALL];
      }, lists_create_with: function(t, L) {
        var T = Array(t.itemCount_);
        for (let e = 0; e < t.itemCount_; e++) T[e] = L.valueToCode(t, "ADD" + e, A.NONE) || "null";
        return ["array(" + T.join(", ") + ")", A.FUNCTION_CALL];
      }, lists_getIndex: function(t, L) {
        var T = t.getFieldValue("MODE") || "GET";
        switch (t.getFieldValue("WHERE") || "FROM_START") {
          case "FIRST":
            if (T === "GET") return [(L.valueToCode(t, "VALUE", A.MEMBER) || "array()") + "[0]", A.MEMBER];
            if (T === "GET_REMOVE") return ["array_shift(" + (L.valueToCode(t, "VALUE", A.NONE) || "array()") + ")", A.FUNCTION_CALL];
            if (T === "REMOVE") return "array_shift(" + (L.valueToCode(t, "VALUE", A.NONE) || "array()") + `);
`;
            break;
          case "LAST":
            if (T === "GET") return ["end(" + (L.valueToCode(t, "VALUE", A.NONE) || "array()") + ")", A.FUNCTION_CALL];
            if (T === "GET_REMOVE") return ["array_pop(" + (L.valueToCode(t, "VALUE", A.NONE) || "array()") + ")", A.FUNCTION_CALL];
            if (T === "REMOVE") return "array_pop(" + (L.valueToCode(t, "VALUE", A.NONE) || "array()") + `);
`;
            break;
          case "FROM_START":
            var e = L.getAdjusted(t, "AT");
            if (T === "GET") return [(L.valueToCode(t, "VALUE", A.MEMBER) || "array()") + "[" + e + "]", A.MEMBER];
            if (T === "GET_REMOVE") return ["array_splice(" + (L.valueToCode(t, "VALUE", A.NONE) || "array()") + ", " + e + ", 1)[0]", A.FUNCTION_CALL];
            if (T === "REMOVE") return "array_splice(" + (L.valueToCode(t, "VALUE", A.NONE) || "array()") + ", " + e + `, 1);
`;
            break;
          case "FROM_END":
            if (T === "GET") return T = L.valueToCode(t, "VALUE", A.NONE) || "array()", L = L.getAdjusted(t, "AT", 1, !0), ["array_slice(" + T + ", " + L + ", 1)[0]", A.FUNCTION_CALL];
            if (T === "GET_REMOVE" || T === "REMOVE") {
              if (e = L.valueToCode(t, "VALUE", A.NONE) || "array()", L = L.getAdjusted(t, "AT", 1, !1, A.SUBTRACTION), L = "array_splice(" + e + ", count(" + e + ") - " + L + ", 1)[0]", T === "GET_REMOVE") return [L, A.FUNCTION_CALL];
              if (T === "REMOVE") return L + `;
`;
            }
            break;
          case "RANDOM":
            if (t = L.valueToCode(t, "VALUE", A.NONE) || "array()", T === "GET") return [L.provideFunction_("lists_get_random_item", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($list) {
  return $list[rand(0,count($list)-1)];
}
`) + "(" + t + ")", A.FUNCTION_CALL];
            if (T === "GET_REMOVE") return [L.provideFunction_("lists_get_remove_random_item", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}(&$list) {
  $x = rand(0,count($list)-1);
  unset($list[$x]);
  return array_values($list);
}
`) + "(" + t + ")", A.FUNCTION_CALL];
            if (T === "REMOVE") return L.provideFunction_("lists_remove_random_item", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}(&$list) {
  unset($list[rand(0,count($list)-1)]);
}
`) + "(" + t + `);
`;
        }
        throw Error("Unhandled combination (lists_getIndex).");
      }, lists_getSublist: function(t, L) {
        var T = L.valueToCode(t, "LIST", A.NONE) || "array()", e = t.getFieldValue("WHERE1"), E = t.getFieldValue("WHERE2");
        if (e !== "FIRST" || E !== "LAST") if (T.match(/^\$\w+$/) || e !== "FROM_END" && E === "FROM_START") {
          switch (e) {
            case "FROM_START":
              e = L.getAdjusted(t, "AT1");
              break;
            case "FROM_END":
              e = L.getAdjusted(t, "AT1", 1, !1, A.SUBTRACTION), e = "count(" + T + ") - " + e;
              break;
            case "FIRST":
              e = "0";
              break;
            default:
              throw Error("Unhandled option (lists_getSublist).");
          }
          switch (E) {
            case "FROM_START":
              L = L.getAdjusted(t, "AT2", 0, !1, A.SUBTRACTION), L += " - ", L = s.zf(String(e)) || String(e).match(/^\(.+\)$/) ? L + e : L + ("(" + e + ")"), L += " + 1";
              break;
            case "FROM_END":
              L = L.getAdjusted(t, "AT2", 0, !1, A.SUBTRACTION), L = "count(" + T + ") - " + L + " - ", L = s.zf(String(e)) || String(e).match(/^\(.+\)$/) ? L + e : L + ("(" + e + ")");
              break;
            case "LAST":
              L = "count(" + T + ") - ", L = s.zf(String(e)) || String(e).match(/^\(.+\)$/) ? L + e : L + ("(" + e + ")");
              break;
            default:
              throw Error("Unhandled option (lists_getSublist).");
          }
          T = "array_slice(" + T + ", " + e + ", " + L + ")";
        } else {
          let O = L.getAdjusted(t, "AT1");
          t = L.getAdjusted(t, "AT2"), T = L.provideFunction_("lists_get_sublist", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($list, $where1, $at1, $where2, $at2) {
  if ($where1 == 'FROM_END') {
    $at1 = count($list) - 1 - $at1;
  } else if ($where1 == 'FIRST') {
    $at1 = 0;
  } else if ($where1 != 'FROM_START') {
    throw new Exception('Unhandled option (lists_get_sublist).');
  }
  $length = 0;
  if ($where2 == 'FROM_START') {
    $length = $at2 - $at1 + 1;
  } else if ($where2 == 'FROM_END') {
    $length = count($list) - $at1 - $at2;
  } else if ($where2 == 'LAST') {
    $length = count($list) - $at1;
  } else {
    throw new Exception('Unhandled option (lists_get_sublist).');
  }
  return array_slice($list, $at1, $length);
}
`) + "(" + T + ", '" + e + "', " + O + ", '" + E + "', " + t + ")";
        }
        return [T, A.FUNCTION_CALL];
      }, lists_indexOf: function(t, L) {
        var T = L.valueToCode(t, "FIND", A.NONE) || "''", e = L.valueToCode(t, "VALUE", A.MEMBER) || "[]", E = " -1", O = "";
        return t.workspace.options.oneBasedIndex && (E = " 0", O = " + 1"), [(t.getFieldValue("END") === "FIRST" ? L.provideFunction_("indexOf", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($haystack, $needle) {
  for ($index = 0; $index < count($haystack); $index++) {
    if ($haystack[$index] == $needle) return $index${O};
  }
  return ${E};
}
`) : L.provideFunction_("lastIndexOf", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($haystack, $needle) {
  $last = ${E};
  for ($index = 0; $index < count($haystack); $index++) {
    if ($haystack[$index] == $needle) $last = $index${O};
  }
  return $last;
}
`)) + "(" + e + ", " + T + ")", A.FUNCTION_CALL];
      }, lists_isEmpty: function(t, L) {
        return ["empty(" + (L.valueToCode(t, "VALUE", A.FUNCTION_CALL) || "array()") + ")", A.FUNCTION_CALL];
      }, lists_length: function(t, L) {
        var T = L.provideFunction_("length", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($value) {
  if (is_string($value)) {
    return strlen($value);
  } else {
    return count($value);
  }
}
`);
        return t = L.valueToCode(t, "VALUE", A.NONE) || "''", [T + "(" + t + ")", A.FUNCTION_CALL];
      }, lists_repeat: function(t, L) {
        var T = L.provideFunction_("lists_repeat", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($value, $count) {
  $array = array();
  for ($index = 0; $index < $count; $index++) {
    $array[] = $value;
  }
  return $array;
}
`), e = L.valueToCode(t, "ITEM", A.NONE) || "null";
        return t = L.valueToCode(t, "NUM", A.NONE) || "0", [T + "(" + e + ", " + t + ")", A.FUNCTION_CALL];
      }, lists_reverse: function(t, L) {
        return ["array_reverse(" + (L.valueToCode(t, "LIST", A.NONE) || "[]") + ")", A.FUNCTION_CALL];
      }, lists_setIndex: function(t, L) {
        var T = t.getFieldValue("MODE") || "GET", e = t.getFieldValue("WHERE") || "FROM_START", E = L.valueToCode(t, "TO", A.ASSIGNMENT) || "null";
        switch (e) {
          case "FIRST":
            if (T === "SET") return (L.valueToCode(t, "LIST", A.MEMBER) || "array()") + "[0] = " + E + `;
`;
            if (T === "INSERT") return "array_unshift(" + (L.valueToCode(t, "LIST", A.NONE) || "array()") + ", " + E + `);
`;
            break;
          case "LAST":
            if (t = L.valueToCode(t, "LIST", A.NONE) || "array()", T === "SET") return L.provideFunction_("lists_set_last_item", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}(&$list, $value) {
  $list[count($list) - 1] = $value;
}
`) + "(" + t + ", " + E + `);
`;
            if (T === "INSERT") return "array_push(" + t + ", " + E + `);
`;
            break;
          case "FROM_START":
            if (e = L.getAdjusted(t, "AT"), T === "SET") return (L.valueToCode(t, "LIST", A.MEMBER) || "array()") + "[" + e + "] = " + E + `;
`;
            if (T === "INSERT") return "array_splice(" + (L.valueToCode(t, "LIST", A.NONE) || "array()") + ", " + e + ", 0, " + E + `);
`;
            break;
          case "FROM_END":
            if (e = L.valueToCode(t, "LIST", A.NONE) || "array()", t = L.getAdjusted(t, "AT", 1), T === "SET") return L.provideFunction_("lists_set_from_end", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}(&$list, $at, $value) {
  $list[count($list) - $at] = $value;
}
`) + "(" + e + ", " + t + ", " + E + `);
`;
            if (T === "INSERT") return L.provideFunction_("lists_insert_from_end", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}(&$list, $at, $value) {
  return array_splice($list, count($list) - $at, 0, $value);
}
`) + "(" + e + ", " + t + ", " + E + `);
`;
            break;
          case "RANDOM":
            if (t = L.valueToCode(t, "LIST", A.REFERENCE) || "array()", t.match(/^\$\w+$/)) e = "";
            else {
              e = L.nameDB_.getDistinctName("tmp_list", s.P.VARIABLE);
              var O = e + " = &" + t + `;
`;
              t = e, e = O;
            }
            if (L = L.nameDB_.getDistinctName("tmp_x", s.P.VARIABLE), e += L + " = rand(0, count(" + t + `)-1);
`, T === "SET") return e + (t + "[" + L + "] = " + E + `;
`);
            if (T === "INSERT") return e + ("array_splice(" + t + ", " + L + ", 0, " + E + `);
`);
        }
        throw Error("Unhandled combination (lists_setIndex).");
      }, lists_sort: function(t, L) {
        var T = L.valueToCode(t, "LIST", A.NONE) || "array()", e = t.getFieldValue("DIRECTION") === "1" ? 1 : -1;
        return t = t.getFieldValue("TYPE"), [L.provideFunction_("lists_sort", `
function ${L.FUNCTION_NAME_PLACEHOLDER_}($list, $type, $direction) {
  $sortCmpFuncs = array(
    'NUMERIC' => 'strnatcasecmp',
    'TEXT' => 'strcmp',
    'IGNORE_CASE' => 'strcasecmp'
  );
  $sortCmp = $sortCmpFuncs[$type];
  $list2 = $list;
  usort($list2, $sortCmp);
  if ($direction == -1) {
    $list2 = array_reverse($list2);
  }
  return $list2;
}
`) + "(" + T + ', "' + t + '", ' + e + ")", A.FUNCTION_CALL];
      }, lists_split: function(t, L) {
        var T = L.valueToCode(t, "INPUT", A.NONE);
        if (L = L.valueToCode(t, "DELIM", A.NONE) || "''", t = t.getFieldValue("MODE"), t === "SPLIT") T || (T = "''"), t = "explode";
        else if (t === "JOIN") T || (T = "array()"), t = "implode";
        else throw Error("Unknown mode: " + t);
        return [t + "(" + L + ", " + T + ")", A.FUNCTION_CALL];
      } }, r, M, F, h, f, H, G);
      for (let t in V) v.forBlock[t] = V[t];
      var X = {};
      return X.Order = A, X.PhpGenerator = n, X.phpGenerator = v, s.__chunk_php = X, s.__chunk_php.__namespace__ = s, s.__chunk_php;
    });
  })(Q)), Q.exports;
}
var Z = { exports: {} }, bd = Z.exports, N_;
function jd() {
  return N_ || (N_ = 1, (function(g, C) {
    (function(_, s) {
      g.exports = s(K());
    })(bd, function(_) {
      var s = _.__namespace__, U = function(T, e) {
        var E = 0, O = "";
        e.STATEMENT_PREFIX && (O += e.injectId(e.STATEMENT_PREFIX, T));
        do {
          var I = e.valueToCode(T, "IF" + E, N.NONE) || "False", R = e.statementToCode(T, "DO" + E) || e.PASS;
          e.STATEMENT_SUFFIX && (R = e.prefixLines(e.injectId(e.STATEMENT_SUFFIX, T), e.INDENT) + R), O += (E === 0 ? "if " : "elif ") + I + `:
` + R, E++;
        } while (T.getInput("IF" + E));
        return (T.getInput("ELSE") || e.STATEMENT_SUFFIX) && (R = T.getInput("ELSE") && e.statementToCode(T, "ELSE") || e.PASS, e.STATEMENT_SUFFIX && (R = e.prefixLines(e.injectId(
          e.STATEMENT_SUFFIX,
          T
        ), e.INDENT) + R), O += `else:
` + R), O;
      }, D = function(T, e) {
        var E = T.getField("TIMES") ? String(parseInt(T.getFieldValue("TIMES"), 10)) : e.valueToCode(T, "TIMES", N.NONE) || "0";
        E = s.zf(E) ? parseInt(E, 10) : "int(" + E + ")";
        var O = e.statementToCode(T, "DO");
        return O = e.addLoopTrap(O, T) || e.PASS, "for " + e.nameDB_.getDistinctName("count", s.P.VARIABLE) + " in range(" + E + `):
` + O;
      }, u = function(T, e) {
        var E = T.getFieldValue("OP");
        if (E === "NEG") {
          var O = e.valueToCode(T, "NUM", N.UNARY_SIGN) || "0";
          return ["-" + O, N.UNARY_SIGN];
        }
        switch (e.definitions_.import_math = "import math", T = E === "SIN" || E === "COS" || E === "TAN" ? e.valueToCode(T, "NUM", N.MULTIPLICATIVE) || "0" : e.valueToCode(T, "NUM", N.NONE) || "0", E) {
          case "ABS":
            O = "math.fabs(" + T + ")";
            break;
          case "ROOT":
            O = "math.sqrt(" + T + ")";
            break;
          case "LN":
            O = "math.log(" + T + ")";
            break;
          case "LOG10":
            O = "math.log10(" + T + ")";
            break;
          case "EXP":
            O = "math.exp(" + T + ")";
            break;
          case "POW10":
            O = "math.pow(10," + T + ")";
            break;
          case "ROUND":
            O = "round(" + T + ")";
            break;
          case "ROUNDUP":
            O = "math.ceil(" + T + ")";
            break;
          case "ROUNDDOWN":
            O = "math.floor(" + T + ")";
            break;
          case "SIN":
            O = "math.sin(" + T + " / 180.0 * math.pi)";
            break;
          case "COS":
            O = "math.cos(" + T + " / 180.0 * math.pi)";
            break;
          case "TAN":
            O = "math.tan(" + T + " / 180.0 * math.pi)";
        }
        if (O) return [O, N.FUNCTION_CALL];
        switch (E) {
          case "ASIN":
            O = "math.asin(" + T + ") / math.pi * 180";
            break;
          case "ACOS":
            O = "math.acos(" + T + ") / math.pi * 180";
            break;
          case "ATAN":
            O = "math.atan(" + T + ") / math.pi * 180";
            break;
          default:
            throw Error("Unknown math operator: " + E);
        }
        return [O, N.MULTIPLICATIVE];
      }, B = function(T, e) {
        var E = [], O = T.workspace, I = s.Bd(O) || [];
        for (var R of I) I = R.getName(), T.getVarModels().includes(R) || E.push(e.getVariableName(I));
        for (O = s.Cd(O), R = 0; R < O.length; R++) E.push(e.nameDB_.getName(O[R], s.P.DEVELOPER_VARIABLE));
        O = E.length ? e.INDENT + "global " + E.join(", ") + `
` : "", E = e.getProcedureName(T.getFieldValue("NAME")), R = "", e.STATEMENT_PREFIX && (R += e.injectId(e.STATEMENT_PREFIX, T)), e.STATEMENT_SUFFIX && (R += e.injectId(e.STATEMENT_SUFFIX, T)), R && (R = e.prefixLines(R, e.INDENT)), I = "", e.INFINITE_LOOP_TRAP && (I = e.prefixLines(e.injectId(e.INFINITE_LOOP_TRAP, T), e.INDENT));
        var i = "";
        T.getInput("STACK") && (i = e.statementToCode(T, "STACK"));
        var S = "";
        T.getInput("RETURN") && (S = e.valueToCode(T, "RETURN", N.NONE) || "");
        var o = "";
        i && S && (o = R), S ? S = e.INDENT + "return " + S + `
` : i || (i = e.PASS);
        var P = [], a = T.getVarModels();
        for (let p = 0; p < a.length; p++) P[p] = e.getVariableName(a[p].getId());
        return O = "def " + E + "(" + P.join(", ") + `):
` + O + R + I + i + o + S, O = e.scrub_(T, O), e.definitions_["%" + E] = O, null;
      }, c = function(T) {
        return H.test(T) ? [T, N.ATOMIC] : ["str(" + T + ")", N.FUNCTION_CALL];
      }, d = function(T, e) {
        var E = e.provideFunction_(
          "text_prompt",
          `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(msg):
  try:
    return raw_input(msg)
  except NameError:
    return input(msg)
`
        );
        return e = T.getField("TEXT") ? e.quote_(T.getFieldValue("TEXT")) : e.valueToCode(T, "TEXT", N.NONE) || "''", E = E + "(" + e + ")", T.getFieldValue("TYPE") === "NUMBER" && (E = "float(" + E + ")"), [E, N.FUNCTION_CALL];
      }, l = function(T, e) {
        return [e.getVariableName(T.getFieldValue("VAR")), N.ATOMIC];
      }, A = function(T, e) {
        var E = e.valueToCode(T, "VALUE", N.NONE) || "0";
        return e.getVariableName(T.getFieldValue("VAR")) + " = " + E + `
`;
      }, N, n = N || (N = {});
      n[n.ATOMIC = 0] = "ATOMIC", n[n.COLLECTION = 1] = "COLLECTION", n[n.STRING_CONVERSION = 1] = "STRING_CONVERSION", n[n.MEMBER = 2.1] = "MEMBER", n[n.FUNCTION_CALL = 2.2] = "FUNCTION_CALL", n[n.EXPONENTIATION = 3] = "EXPONENTIATION", n[n.UNARY_SIGN = 4] = "UNARY_SIGN", n[n.BITWISE_NOT = 4] = "BITWISE_NOT", n[n.MULTIPLICATIVE = 5] = "MULTIPLICATIVE", n[n.ADDITIVE = 6] = "ADDITIVE", n[n.BITWISE_SHIFT = 7] = "BITWISE_SHIFT", n[n.BITWISE_AND = 8] = "BITWISE_AND", n[n.BITWISE_XOR = 9] = "BITWISE_XOR", n[n.BITWISE_OR = 10] = "BITWISE_OR", n[n.RELATIONAL = 11] = "RELATIONAL", n[n.LOGICAL_NOT = 12] = "LOGICAL_NOT", n[n.LOGICAL_AND = 13] = "LOGICAL_AND", n[n.LOGICAL_OR = 14] = "LOGICAL_OR", n[n.CONDITIONAL = 15] = "CONDITIONAL", n[n.LAMBDA = 16] = "LAMBDA", n[n.NONE = 99] = "NONE";
      var r = class extends s.zq {
        constructor(T = "Python") {
          super(T), this.ORDER_OVERRIDES = [[N.FUNCTION_CALL, N.MEMBER], [N.FUNCTION_CALL, N.FUNCTION_CALL], [N.MEMBER, N.MEMBER], [N.MEMBER, N.FUNCTION_CALL], [N.LOGICAL_NOT, N.LOGICAL_NOT], [N.LOGICAL_AND, N.LOGICAL_AND], [N.LOGICAL_OR, N.LOGICAL_OR]], this.PASS = "", this.isInitialized = !1;
          for (let e in N) T = N[e], typeof T != "string" && (this["ORDER_" + e] = T);
          this.addReservedWords("False,None,True,and,as,assert,break,class,continue,def,del,elif,else,except,exec,finally,for,from,global,if,import,in,is,lambda,nonlocal,not,or,pass,print,raise,return,try,while,with,yield,NotImplemented,Ellipsis,__debug__,quit,exit,copyright,license,credits,ArithmeticError,AssertionError,AttributeError,BaseException,BlockingIOError,BrokenPipeError,BufferError,BytesWarning,ChildProcessError,ConnectionAbortedError,ConnectionError,ConnectionRefusedError,ConnectionResetError,DeprecationWarning,EOFError,Ellipsis,EnvironmentError,Exception,FileExistsError,FileNotFoundError,FloatingPointError,FutureWarning,GeneratorExit,IOError,ImportError,ImportWarning,IndentationError,IndexError,InterruptedError,IsADirectoryError,KeyError,KeyboardInterrupt,LookupError,MemoryError,ModuleNotFoundError,NameError,NotADirectoryError,NotImplemented,NotImplementedError,OSError,OverflowError,PendingDeprecationWarning,PermissionError,ProcessLookupError,RecursionError,ReferenceError,ResourceWarning,RuntimeError,RuntimeWarning,StandardError,StopAsyncIteration,StopIteration,SyntaxError,SyntaxWarning,SystemError,SystemExit,TabError,TimeoutError,TypeError,UnboundLocalError,UnicodeDecodeError,UnicodeEncodeError,UnicodeError,UnicodeTranslateError,UnicodeWarning,UserWarning,ValueError,Warning,ZeroDivisionError,_,__build_class__,__debug__,__doc__,__import__,__loader__,__name__,__package__,__spec__,abs,all,any,apply,ascii,basestring,bin,bool,buffer,bytearray,bytes,callable,chr,classmethod,cmp,coerce,compile,complex,copyright,credits,delattr,dict,dir,divmod,enumerate,eval,exec,execfile,exit,file,filter,float,format,frozenset,getattr,globals,hasattr,hash,help,hex,id,input,int,intern,isinstance,issubclass,iter,len,license,list,locals,long,map,max,memoryview,min,next,object,oct,open,ord,pow,print,property,quit,range,raw_input,reduce,reload,repr,reversed,round,set,setattr,slice,sorted,staticmethod,str,sum,super,tuple,type,unichr,unicode,vars,xrange,zip");
        }
        init(T) {
          super.init(T), this.PASS = this.INDENT + `pass
`, this.nameDB_ ? this.nameDB_.reset() : this.nameDB_ = new s.Cj(this.RESERVED_WORDS_), this.nameDB_.setVariableMap(T.getVariableMap()), this.nameDB_.populateVariables(T), this.nameDB_.populateProcedures(T);
          var e = [], E = s.Cd(T);
          for (let O = 0; O < E.length; O++) e.push(this.nameDB_.getName(E[O], s.Cj.DEVELOPER_VARIABLE_TYPE) + " = None");
          for (T = s.Bd(T), E = 0; E < T.length; E++) e.push(this.getVariableName(T[E].getId()) + " = None");
          this.definitions_.variables = e.join(`
`), this.isInitialized = !0;
        }
        finish(T) {
          var e = [], E = [];
          for (let O in this.definitions_) {
            let I = this.definitions_[O];
            I.match(/^(from\s+\S+\s+)?import\s+\S+/) ? e.push(I) : E.push(I);
          }
          return T = super.finish(T), this.isInitialized = !1, this.nameDB_.reset(), (e.join(`
`) + `

` + E.join(`

`)).replace(/\n\n+/g, `

`).replace(/\n*$/, `


`) + T;
        }
        scrubNakedValue(T) {
          return T + `
`;
        }
        quote_(T) {
          T = T.replace(/\\/g, "\\\\").replace(/\n/g, `\\
`);
          var e = "'";
          return T.includes("'") && (T.includes('"') ? T = T.replace(/'/g, "\\'") : e = '"'), e + T + e;
        }
        multiline_quote_(T) {
          return T.split(/\n/g).map(this.quote_).join(` + '\\n' + 
`);
        }
        scrub_(T, e, E = !1) {
          var O = "";
          if (!T.outputConnection || !T.outputConnection.targetConnection) {
            var I = T.getCommentText();
            I && (I = s.yf(I, this.COMMENT_WRAP - 3), O += this.prefixLines(I + `
`, "# "));
            for (let R = 0; R < T.inputList.length; R++) T.inputList[R].type === s.je.VALUE && (I = T.inputList[R].connection.targetBlock()) && (I = this.allNestedComments(I)) && (O += this.prefixLines(I, "# "));
          }
          return T = T.nextConnection && T.nextConnection.targetBlock(), E = E ? "" : this.blockToCode(T), O + e + E;
        }
        getAdjustedInt(T, e, E = 0, O = !1) {
          T.workspace.options.oneBasedIndex && E--;
          var I = T.workspace.options.oneBasedIndex ? "1" : "0";
          return T = this.valueToCode(T, e, E ? N.ADDITIVE : N.NONE) || I, s.zf(T) ? (T = parseInt(T, 10) + E, O && (T = -T)) : (T = E > 0 ? "int(" + T + " + " + E + ")" : E < 0 ? "int(" + T + " - " + -E + ")" : "int(" + T + ")", O && (T = "-" + T)), T;
        }
      }, M = {};
      M.controls_if = U, M.controls_ifelse = U, M.logic_boolean = function(T) {
        return [T.getFieldValue("BOOL") === "TRUE" ? "True" : "False", N.ATOMIC];
      }, M.logic_compare = function(T, e) {
        var E = { EQ: "==", NEQ: "!=", LT: "<", LTE: "<=", GT: ">", GTE: ">=" }[T.getFieldValue("OP")], O = N.RELATIONAL, I = e.valueToCode(T, "A", O) || "0";
        return T = e.valueToCode(T, "B", O) || "0", [I + " " + E + " " + T, O];
      }, M.logic_negate = function(T, e) {
        return ["not " + (e.valueToCode(T, "BOOL", N.LOGICAL_NOT) || "True"), N.LOGICAL_NOT];
      }, M.logic_null = function() {
        return ["None", N.ATOMIC];
      }, M.logic_operation = function(T, e) {
        var E = T.getFieldValue("OP") === "AND" ? "and" : "or", O = E === "and" ? N.LOGICAL_AND : N.LOGICAL_OR, I = e.valueToCode(T, "A", O);
        return T = e.valueToCode(T, "B", O), I || T ? (e = E === "and" ? "True" : "False", I || (I = e), T || (T = e)) : T = I = "False", [I + " " + E + " " + T, O];
      }, M.logic_ternary = function(T, e) {
        var E = e.valueToCode(T, "IF", N.CONDITIONAL) || "False", O = e.valueToCode(T, "THEN", N.CONDITIONAL) || "None";
        return T = e.valueToCode(T, "ELSE", N.CONDITIONAL) || "None", [O + " if " + E + " else " + T, N.CONDITIONAL];
      };
      var F = { controls_flow_statements: function(T, e) {
        var E = "";
        if (e.STATEMENT_PREFIX && (E += e.injectId(e.STATEMENT_PREFIX, T)), e.STATEMENT_SUFFIX && (E += e.injectId(e.STATEMENT_SUFFIX, T)), e.STATEMENT_PREFIX) {
          let O = T.getSurroundLoop();
          O && !O.suppressPrefixSuffix && (E += e.injectId(e.STATEMENT_PREFIX, O));
        }
        switch (T.getFieldValue("FLOW")) {
          case "BREAK":
            return E + `break
`;
          case "CONTINUE":
            return E + `continue
`;
        }
        throw Error("Unknown flow statement.");
      }, controls_for: function(T, e) {
        function E() {
          return e.provideFunction_(
            "downRange",
            `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(start, stop, step):
  while start >= stop:
    yield start
    start -= abs(step)
`
          );
        }
        function O() {
          return e.provideFunction_("upRange", `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(start, stop, step):
  while start <= stop:
    yield start
    start += abs(step)
`);
        }
        var I = e.getVariableName(T.getFieldValue("VAR")), R = e.valueToCode(T, "FROM", N.NONE) || "0", i = e.valueToCode(T, "TO", N.NONE) || "0", S = e.valueToCode(T, "BY", N.NONE) || "1", o = e.statementToCode(T, "DO");
        o = e.addLoopTrap(o, T) || e.PASS;
        var P = "";
        return s.zf(R) && s.zf(i) && s.zf(S) ? (R = Number(R), i = Number(i), S = Math.abs(Number(S)), R % 1 === 0 && i % 1 === 0 && S % 1 === 0 ? (R <= i ? (i++, T = R === 0 && S === 1 ? i : R + ", " + i, S !== 1 && (T += ", " + S)) : (i--, T = R + ", " + i + ", -" + S), T = "range(" + T + ")") : (T = R < i ? O() : E(), T += "(" + R + ", " + i + ", " + S + ")")) : (T = function(a, p) {
          return s.zf(a) ? a = String(Number(a)) : a.match(/^\w+$/) || (p = e.nameDB_.getDistinctName(I + p, s.P.VARIABLE), P += p + " = " + a + `
`, a = p), a;
        }, R = T(R, "_start"), i = T(i, "_end"), S = T(S, "_inc"), typeof R == "number" && typeof i == "number" ? (T = R < i ? O() : E(), T += "(" + R + ", " + i + ", " + S + ")") : T = "(" + R + " <= " + i + ") and " + O() + "(" + R + ", " + i + ", " + S + ") or " + E() + "(" + R + ", " + i + ", " + S + ")"), P += "for " + I + " in " + T + `:
` + o;
      }, controls_forEach: function(T, e) {
        var E = e.getVariableName(T.getFieldValue("VAR")), O = e.valueToCode(T, "LIST", N.RELATIONAL) || "[]", I = e.statementToCode(T, "DO");
        return I = e.addLoopTrap(I, T) || e.PASS, "for " + E + " in " + O + `:
` + I;
      } };
      F.controls_repeat = D, F.controls_repeat_ext = D, F.controls_whileUntil = function(T, e) {
        var E = T.getFieldValue("MODE") === "UNTIL", O = e.valueToCode(T, "BOOL", E ? N.LOGICAL_NOT : N.NONE) || "False", I = e.statementToCode(T, "DO");
        return I = e.addLoopTrap(I, T) || e.PASS, E && (O = "not " + O), "while " + O + `:
` + I;
      };
      var h = {
        math_arithmetic: function(T, e) {
          var E = { ADD: [" + ", N.ADDITIVE], MINUS: [" - ", N.ADDITIVE], MULTIPLY: [" * ", N.MULTIPLICATIVE], DIVIDE: [" / ", N.MULTIPLICATIVE], POWER: [" ** ", N.EXPONENTIATION] }[T.getFieldValue("OP")], O = E[0];
          E = E[1];
          var I = e.valueToCode(T, "A", E) || "0";
          return T = e.valueToCode(T, "B", E) || "0", [I + O + T, E];
        },
        math_atan2: function(T, e) {
          e.definitions_.import_math = "import math";
          var E = e.valueToCode(T, "X", N.NONE) || "0";
          return ["math.atan2(" + (e.valueToCode(T, "Y", N.NONE) || "0") + ", " + E + ") / math.pi * 180", N.MULTIPLICATIVE];
        },
        math_change: function(T, e) {
          e.definitions_.from_numbers_import_Number = "from numbers import Number";
          var E = e.valueToCode(T, "DELTA", N.ADDITIVE) || "0";
          return T = e.getVariableName(T.getFieldValue("VAR")), T + " = (" + T + " if isinstance(" + T + ", Number) else 0) + " + E + `
`;
        },
        math_constant: function(T, e) {
          var E = { PI: ["math.pi", N.MEMBER], E: ["math.e", N.MEMBER], GOLDEN_RATIO: ["(1 + math.sqrt(5)) / 2", N.MULTIPLICATIVE], SQRT2: ["math.sqrt(2)", N.MEMBER], SQRT1_2: ["math.sqrt(1.0 / 2)", N.MEMBER], INFINITY: ["float('inf')", N.ATOMIC] };
          return T = T.getFieldValue("CONSTANT"), T !== "INFINITY" && (e.definitions_.import_math = "import math"), E[T];
        },
        math_constrain: function(T, e) {
          var E = e.valueToCode(T, "VALUE", N.NONE) || "0", O = e.valueToCode(T, "LOW", N.NONE) || "0";
          return T = e.valueToCode(T, "HIGH", N.NONE) || "float('inf')", ["min(max(" + E + ", " + O + "), " + T + ")", N.FUNCTION_CALL];
        },
        math_modulo: function(T, e) {
          var E = e.valueToCode(T, "DIVIDEND", N.MULTIPLICATIVE) || "0";
          return T = e.valueToCode(T, "DIVISOR", N.MULTIPLICATIVE) || "0", [E + " % " + T, N.MULTIPLICATIVE];
        },
        math_number: function(T) {
          return T = Number(T.getFieldValue("NUM")), T === 1 / 0 ? ['float("inf")', N.FUNCTION_CALL] : T === -1 / 0 ? ['-float("inf")', N.UNARY_SIGN] : [String(T), T < 0 ? N.UNARY_SIGN : N.ATOMIC];
        },
        math_number_property: function(T, e) {
          var E = { EVEN: [" % 2 == 0", N.MULTIPLICATIVE, N.RELATIONAL], ODD: [" % 2 == 1", N.MULTIPLICATIVE, N.RELATIONAL], WHOLE: [" % 1 == 0", N.MULTIPLICATIVE, N.RELATIONAL], POSITIVE: [" > 0", N.RELATIONAL, N.RELATIONAL], NEGATIVE: [" < 0", N.RELATIONAL, N.RELATIONAL], DIVISIBLE_BY: [null, N.MULTIPLICATIVE, N.RELATIONAL], PRIME: [
            null,
            N.NONE,
            N.FUNCTION_CALL
          ] }, O = T.getFieldValue("PROPERTY"), [I, R, i] = E[O];
          if (E = e.valueToCode(T, "NUMBER_TO_CHECK", R) || "0", O === "PRIME") e.definitions_.import_math = "import math", e.definitions_.from_numbers_import_Number = "from numbers import Number", T = e.provideFunction_("math_isPrime", `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(n):
  # https://en.wikipedia.org/wiki/Primality_test#Naive_methods
  # If n is not a number but a string, try parsing it.
  if not isinstance(n, Number):
    try:
      n = float(n)
    except:
      return False
  if n == 2 or n == 3:
    return True
  # False if n is negative, is 1, or not whole, or if n is divisible by 2 or 3.
  if n <= 1 or n % 1 != 0 or n % 2 == 0 or n % 3 == 0:
    return False
  # Check all the numbers of form 6k +/- 1, up to sqrt(n).
  for x in range(6, int(math.sqrt(n)) + 2, 6):
    if n % (x - 1) == 0 or n % (x + 1) == 0:
      return False
  return True
`) + "(" + E + ")";
          else if (O === "DIVISIBLE_BY") {
            if (T = e.valueToCode(T, "DIVISOR", N.MULTIPLICATIVE) || "0", T === "0") return ["False", N.ATOMIC];
            T = E + " % " + T + " == 0";
          } else T = E + I;
          return [T, i];
        },
        math_on_list: function(T, e) {
          var E = T.getFieldValue("OP");
          switch (T = e.valueToCode(T, "LIST", N.NONE) || "[]", E) {
            case "SUM":
              e = "sum(" + T + ")";
              break;
            case "MIN":
              e = "min(" + T + ")";
              break;
            case "MAX":
              e = "max(" + T + ")";
              break;
            case "AVERAGE":
              e.definitions_.from_numbers_import_Number = "from numbers import Number", e = e.provideFunction_("math_mean", `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(myList):
  localList = [e for e in myList if isinstance(e, Number)]
  if not localList: return
  return float(sum(localList)) / len(localList)
`) + "(" + T + ")";
              break;
            case "MEDIAN":
              e.definitions_.from_numbers_import_Number = "from numbers import Number", e = e.provideFunction_("math_median", `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(myList):
  localList = sorted([e for e in myList if isinstance(e, Number)])
  if not localList: return
  if len(localList) % 2 == 0:
    return (localList[len(localList) // 2 - 1] + localList[len(localList) // 2]) / 2.0
  else:
    return localList[(len(localList) - 1) // 2]
`) + "(" + T + ")";
              break;
            case "MODE":
              e = e.provideFunction_("math_modes", `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(some_list):
  modes = []
  # Using a lists of [item, count] to keep count rather than dict
  # to avoid "unhashable" errors when the counted item is itself a list or dict.
  counts = []
  maxCount = 1
  for item in some_list:
    found = False
    for count in counts:
      if count[0] == item:
        count[1] += 1
        maxCount = max(maxCount, count[1])
        found = True
    if not found:
      counts.append([item, 1])
  for counted_item, item_count in counts:
    if item_count == maxCount:
      modes.append(counted_item)
  return modes
`) + "(" + T + ")";
              break;
            case "STD_DEV":
              e.definitions_.import_math = "import math", e = e.provideFunction_("math_standard_deviation", `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(numbers):
  n = len(numbers)
  if n == 0: return
  mean = float(sum(numbers)) / n
  variance = sum((x - mean) ** 2 for x in numbers) / n
  return math.sqrt(variance)
`) + "(" + T + ")";
              break;
            case "RANDOM":
              e.definitions_.import_random = "import random", e = "random.choice(" + T + ")";
              break;
            default:
              throw Error("Unknown operator: " + E);
          }
          return [e, N.FUNCTION_CALL];
        },
        math_random_float: function(T, e) {
          return e.definitions_.import_random = "import random", ["random.random()", N.FUNCTION_CALL];
        },
        math_random_int: function(T, e) {
          e.definitions_.import_random = "import random";
          var E = e.valueToCode(T, "FROM", N.NONE) || "0";
          return T = e.valueToCode(T, "TO", N.NONE) || "0", ["random.randint(" + E + ", " + T + ")", N.FUNCTION_CALL];
        }
      };
      h.math_round = u, h.math_single = u, h.math_trig = u;
      var f = { procedures_callnoreturn: function(T, e) {
        return e.forBlock.procedures_callreturn(T, e)[0] + `
`;
      }, procedures_callreturn: function(T, e) {
        var E = e.getProcedureName(T.getFieldValue("NAME")), O = [], I = T.getVarModels();
        for (let R = 0; R < I.length; R++) O[R] = e.valueToCode(T, "ARG" + R, N.NONE) || "None";
        return [E + "(" + O.join(", ") + ")", N.FUNCTION_CALL];
      } };
      f.procedures_defnoreturn = B, f.procedures_defreturn = B, f.procedures_ifreturn = function(T, e) {
        var E = "if " + (e.valueToCode(T, "CONDITION", N.NONE) || "False") + `:
`;
        return e.STATEMENT_SUFFIX && (E += e.prefixLines(e.injectId(e.STATEMENT_SUFFIX, T), e.INDENT)), T.hasReturnValue_ ? (T = e.valueToCode(T, "VALUE", N.NONE) || "None", E += e.INDENT + "return " + T + `
`) : E += e.INDENT + `return
`, E;
      };
      var H = /^\s*'([^']|\\')*'\s*$/, G = { text: function(T, e) {
        return [e.quote_(T.getFieldValue("TEXT")), N.ATOMIC];
      }, text_append: function(T, e) {
        var E = e.getVariableName(T.getFieldValue("VAR"));
        return T = e.valueToCode(T, "TEXT", N.NONE) || "''", E + " = str(" + E + ") + " + c(T)[0] + `
`;
      }, text_changeCase: function(T, e) {
        var E = { UPPERCASE: ".upper()", LOWERCASE: ".lower()", TITLECASE: ".title()" }[T.getFieldValue("CASE")];
        return [(e.valueToCode(T, "TEXT", N.MEMBER) || "''") + E, N.FUNCTION_CALL];
      }, text_charAt: function(T, e) {
        var E = T.getFieldValue("WHERE") || "FROM_START", O = e.valueToCode(T, "VALUE", E === "RANDOM" ? N.NONE : N.MEMBER) || "''";
        switch (E) {
          case "FIRST":
            return [O + "[0]", N.MEMBER];
          case "LAST":
            return [O + "[-1]", N.MEMBER];
          case "FROM_START":
            return T = e.getAdjustedInt(T, "AT"), [O + "[" + T + "]", N.MEMBER];
          case "FROM_END":
            return T = e.getAdjustedInt(T, "AT", 1, !0), [O + "[" + T + "]", N.MEMBER];
          case "RANDOM":
            return e.definitions_.import_random = "import random", [e.provideFunction_("text_random_letter", `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(text):
  x = int(random.random() * len(text))
  return text[x]
`) + "(" + O + ")", N.FUNCTION_CALL];
        }
        throw Error("Unhandled option (text_charAt).");
      }, text_count: function(T, e) {
        var E = e.valueToCode(T, "TEXT", N.MEMBER) || "''";
        return T = e.valueToCode(T, "SUB", N.NONE) || "''", [E + ".count(" + T + ")", N.FUNCTION_CALL];
      }, text_getSubstring: function(T, e) {
        var E = T.getFieldValue("WHERE1"), O = T.getFieldValue("WHERE2"), I = e.valueToCode(T, "STRING", N.MEMBER) || "''";
        switch (E) {
          case "FROM_START":
            E = e.getAdjustedInt(T, "AT1"), E === 0 && (E = "");
            break;
          case "FROM_END":
            E = e.getAdjustedInt(T, "AT1", 1, !0);
            break;
          case "FIRST":
            E = "";
            break;
          default:
            throw Error("Unhandled option (text_getSubstring)");
        }
        switch (O) {
          case "FROM_START":
            T = e.getAdjustedInt(T, "AT2", 1);
            break;
          case "FROM_END":
            T = e.getAdjustedInt(T, "AT2", 0, !0), s.zf(String(T)) ? T === 0 && (T = "") : (e.definitions_.import_sys = "import sys", T += " or sys.maxsize");
            break;
          case "LAST":
            T = "";
            break;
          default:
            throw Error("Unhandled option (text_getSubstring)");
        }
        return [I + "[" + E + " : " + T + "]", N.MEMBER];
      }, text_indexOf: function(T, e) {
        var E = T.getFieldValue("END") === "FIRST" ? "find" : "rfind", O = e.valueToCode(
          T,
          "FIND",
          N.NONE
        ) || "''";
        return e = (e.valueToCode(T, "VALUE", N.MEMBER) || "''") + "." + E + "(" + O + ")", T.workspace.options.oneBasedIndex ? [e + " + 1", N.ADDITIVE] : [e, N.FUNCTION_CALL];
      }, text_isEmpty: function(T, e) {
        return ["not len(" + (e.valueToCode(T, "VALUE", N.NONE) || "''") + ")", N.LOGICAL_NOT];
      }, text_join: function(T, e) {
        switch (T.itemCount_) {
          case 0:
            return ["''", N.ATOMIC];
          case 1:
            return T = e.valueToCode(T, "ADD0", N.NONE) || "''", c(T);
          case 2:
            var E = e.valueToCode(T, "ADD0", N.NONE) || "''";
            return T = e.valueToCode(T, "ADD1", N.NONE) || "''", [c(E)[0] + " + " + c(T)[0], N.ADDITIVE];
          default:
            E = [];
            for (let O = 0; O < T.itemCount_; O++) E[O] = e.valueToCode(T, "ADD" + O, N.NONE) || "''";
            return T = e.nameDB_.getDistinctName("x", s.P.VARIABLE), ["''.join([str(" + T + ") for " + T + " in [" + E.join(", ") + "]])", N.FUNCTION_CALL];
        }
      }, text_length: function(T, e) {
        return ["len(" + (e.valueToCode(T, "VALUE", N.NONE) || "''") + ")", N.FUNCTION_CALL];
      }, text_print: function(T, e) {
        return "print(" + (e.valueToCode(T, "TEXT", N.NONE) || "''") + `)
`;
      } };
      G.text_prompt = d, G.text_prompt_ext = d, G.text_replace = function(T, e) {
        var E = e.valueToCode(T, "TEXT", N.MEMBER) || "''", O = e.valueToCode(T, "FROM", N.NONE) || "''";
        return T = e.valueToCode(T, "TO", N.NONE) || "''", [E + ".replace(" + O + ", " + T + ")", N.MEMBER];
      }, G.text_reverse = function(T, e) {
        return [(e.valueToCode(T, "TEXT", N.MEMBER) || "''") + "[::-1]", N.MEMBER];
      }, G.text_trim = function(T, e) {
        var E = { LEFT: ".lstrip()", RIGHT: ".rstrip()", BOTH: ".strip()" }[T.getFieldValue("MODE")];
        return [(e.valueToCode(T, "TEXT", N.MEMBER) || "''") + E, N.FUNCTION_CALL];
      };
      var v = {};
      v.variables_get = l, v.variables_set = A;
      var V = {};
      V.variables_get_dynamic = l, V.variables_set_dynamic = A;
      var X = new r();
      X.addReservedWords("math,random,Number");
      var t = Object.assign({}, { lists_create_empty: function() {
        return ["[]", N.ATOMIC];
      }, lists_create_with: function(T, e) {
        var E = Array(T.itemCount_);
        for (let O = 0; O < T.itemCount_; O++) E[O] = e.valueToCode(T, "ADD" + O, N.NONE) || "None";
        return ["[" + E.join(", ") + "]", N.ATOMIC];
      }, lists_getIndex: function(T, e) {
        var E = T.getFieldValue("MODE") || "GET", O = T.getFieldValue("WHERE") || "FROM_START", I = e.valueToCode(T, "VALUE", O === "RANDOM" ? N.NONE : N.MEMBER) || "[]";
        switch (O) {
          case "FIRST":
            if (E === "GET") return [I + "[0]", N.MEMBER];
            if (E === "GET_REMOVE") return [I + ".pop(0)", N.FUNCTION_CALL];
            if (E === "REMOVE") return I + `.pop(0)
`;
            break;
          case "LAST":
            if (E === "GET") return [I + "[-1]", N.MEMBER];
            if (E === "GET_REMOVE") return [I + ".pop()", N.FUNCTION_CALL];
            if (E === "REMOVE") return I + `.pop()
`;
            break;
          case "FROM_START":
            if (T = e.getAdjustedInt(T, "AT"), E === "GET") return [I + "[" + T + "]", N.MEMBER];
            if (E === "GET_REMOVE") return [I + ".pop(" + T + ")", N.FUNCTION_CALL];
            if (E === "REMOVE") return I + ".pop(" + T + `)
`;
            break;
          case "FROM_END":
            if (T = e.getAdjustedInt(T, "AT", 1, !0), E === "GET") return [I + "[" + T + "]", N.MEMBER];
            if (E === "GET_REMOVE") return [I + ".pop(" + T + ")", N.FUNCTION_CALL];
            if (E === "REMOVE") return I + ".pop(" + T + `)
`;
            break;
          case "RANDOM":
            if (e.definitions_.import_random = "import random", E === "GET") return ["random.choice(" + I + ")", N.FUNCTION_CALL];
            if (I = e.provideFunction_("lists_remove_random_item", `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(myList):
  x = int(random.random() * len(myList))
  return myList.pop(x)
`) + "(" + I + ")", E === "GET_REMOVE") return [I, N.FUNCTION_CALL];
            if (E === "REMOVE") return I + `
`;
        }
        throw Error("Unhandled combination (lists_getIndex).");
      }, lists_getSublist: function(T, e) {
        var E = e.valueToCode(T, "LIST", N.MEMBER) || "[]", O = T.getFieldValue("WHERE1"), I = T.getFieldValue("WHERE2");
        switch (O) {
          case "FROM_START":
            O = e.getAdjustedInt(T, "AT1"), O === 0 && (O = "");
            break;
          case "FROM_END":
            O = e.getAdjustedInt(T, "AT1", 1, !0);
            break;
          case "FIRST":
            O = "";
            break;
          default:
            throw Error("Unhandled option (lists_getSublist)");
        }
        switch (I) {
          case "FROM_START":
            T = e.getAdjustedInt(T, "AT2", 1);
            break;
          case "FROM_END":
            T = e.getAdjustedInt(T, "AT2", 0, !0), s.zf(String(T)) ? T === 0 && (T = "") : (e.definitions_.import_sys = "import sys", T += " or sys.maxsize");
            break;
          case "LAST":
            T = "";
            break;
          default:
            throw Error("Unhandled option (lists_getSublist)");
        }
        return [E + "[" + O + " : " + T + "]", N.MEMBER];
      }, lists_indexOf: function(T, e) {
        var E = e.valueToCode(T, "FIND", N.NONE) || "[]", O = e.valueToCode(T, "VALUE", N.NONE) || "''", I = " -1", R = "", i = " - 1";
        return T.workspace.options.oneBasedIndex && (I = " 0", R = " + 1", i = ""), [(T.getFieldValue("END") === "FIRST" ? e.provideFunction_("first_index", `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(my_list, elem):
  try: index = my_list.index(elem)${R}
  except: index =${I}
  return index
`) : e.provideFunction_("last_index", `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(my_list, elem):
  try: index = len(my_list) - my_list[::-1].index(elem)${i}
  except: index =${I}
  return index
`)) + "(" + O + ", " + E + ")", N.FUNCTION_CALL];
      }, lists_isEmpty: function(T, e) {
        return ["not len(" + (e.valueToCode(T, "VALUE", N.NONE) || "[]") + ")", N.LOGICAL_NOT];
      }, lists_length: function(T, e) {
        return ["len(" + (e.valueToCode(T, "VALUE", N.NONE) || "[]") + ")", N.FUNCTION_CALL];
      }, lists_repeat: function(T, e) {
        var E = e.valueToCode(T, "ITEM", N.NONE) || "None";
        return T = e.valueToCode(T, "NUM", N.MULTIPLICATIVE) || "0", ["[" + E + "] * " + T, N.MULTIPLICATIVE];
      }, lists_reverse: function(T, e) {
        return [
          "list(reversed(" + (e.valueToCode(T, "LIST", N.NONE) || "[]") + "))",
          N.FUNCTION_CALL
        ];
      }, lists_setIndex: function(T, e) {
        var E = e.valueToCode(T, "LIST", N.MEMBER) || "[]", O = T.getFieldValue("MODE") || "GET", I = T.getFieldValue("WHERE") || "FROM_START", R = e.valueToCode(T, "TO", N.NONE) || "None";
        switch (I) {
          case "FIRST":
            if (O === "SET") return E + "[0] = " + R + `
`;
            if (O === "INSERT") return E + ".insert(0, " + R + `)
`;
            break;
          case "LAST":
            if (O === "SET") return E + "[-1] = " + R + `
`;
            if (O === "INSERT") return E + ".append(" + R + `)
`;
            break;
          case "FROM_START":
            if (e = e.getAdjustedInt(T, "AT"), O === "SET") return E + "[" + e + "] = " + R + `
`;
            if (O === "INSERT") return E + ".insert(" + e + ", " + R + `)
`;
            break;
          case "FROM_END":
            if (e = e.getAdjustedInt(T, "AT", 1, !0), O === "SET") return E + "[" + e + "] = " + R + `
`;
            if (O === "INSERT") return E + ".insert(" + e + ", " + R + `)
`;
            break;
          case "RANDOM":
            if (e.definitions_.import_random = "import random", E.match(/^\w+$/) ? T = "" : (T = e.nameDB_.getDistinctName("tmp_list", s.P.VARIABLE), I = T + " = " + E + `
`, E = T, T = I), e = e.nameDB_.getDistinctName("tmp_x", s.P.VARIABLE), T += e + " = int(random.random() * len(" + E + `))
`, O === "SET") return T + (E + "[" + e + "] = " + R + `
`);
            if (O === "INSERT") return T + (E + ".insert(" + e + ", " + R + `)
`);
        }
        throw Error("Unhandled combination (lists_setIndex).");
      }, lists_sort: function(T, e) {
        var E = e.valueToCode(T, "LIST", N.NONE) || "[]", O = T.getFieldValue("TYPE");
        return T = T.getFieldValue("DIRECTION") === "1" ? "False" : "True", [e.provideFunction_("lists_sort", `
def ${e.FUNCTION_NAME_PLACEHOLDER_}(my_list, type, reverse):
  def try_float(s):
    try:
      return float(s)
    except:
      return 0
  key_funcs = {
    "NUMERIC": try_float,
    "TEXT": str,
    "IGNORE_CASE": lambda s: str(s).lower()
  }
  key_func = key_funcs[type]
  list_cpy = list(my_list)
  return sorted(list_cpy, key=key_func, reverse=reverse)
`) + "(" + E + ', "' + O + '", ' + T + ")", N.FUNCTION_CALL];
      }, lists_split: function(T, e) {
        var E = T.getFieldValue("MODE");
        if (E === "SPLIT") E = e.valueToCode(T, "INPUT", N.MEMBER) || "''", T = e.valueToCode(T, "DELIM", N.NONE), T = E + ".split(" + T + ")";
        else if (E === "JOIN") E = e.valueToCode(T, "INPUT", N.NONE) || "[]", T = (e.valueToCode(T, "DELIM", N.MEMBER) || "''") + ".join(" + E + ")";
        else throw Error("Unknown mode: " + E);
        return [T, N.FUNCTION_CALL];
      } }, M, F, h, f, G, v, V);
      for (let T in t) X.forBlock[T] = t[T];
      var L = {};
      return L.Order = N, L.PythonGenerator = r, L.pythonGenerator = X, s.__chunk_python = L, s.__chunk_python.__namespace__ = s, s.__chunk_python;
    });
  })(Z)), Z.exports;
}
/*! For license information please see index.js.LICENSE.txt */
var Jd = j.exports, R_;
function qd() {
  return R_ || (R_ = 1, (function(g, C) {
    (function(_, s) {
      g.exports = s(K(), kd(), Yd(), wd(), Wd(), jd());
    })(Jd, (_, s, U, D, u, B) => (() => {
      var c = { 370(i) {
        i.exports = _;
      }, 379(i) {
        i.exports = s;
      }, 127(i) {
        i.exports = U;
      }, 157(i) {
        i.exports = D;
      }, 537(i) {
        i.exports = u;
      }, 557(i) {
        i.exports = B;
      } };
      const d = {};
      function l(i) {
        const S = d[i];
        if (S !== void 0) return S.exports;
        const o = d[i] = { exports: {} };
        return c[i](o, o.exports, l), o.exports;
      }
      l.d = (i, S) => {
        for (var o in S) l.o(S, o) && !l.o(i, o) && Object.defineProperty(i, o, { enumerable: !0, get: S[o] });
      }, l.o = (i, S) => Object.prototype.hasOwnProperty.call(i, S), l.r = (i) => {
        Object.defineProperty(i, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(i, "__esModule", { value: !0 });
      };
      let A = {};
      l.r(A), l.d(A, { FieldMultilineInput: () => H, installAllBlocks: () => R, registerFieldMultilineInput: () => G, textMultiline: () => N });
      var N = {};
      l.r(N), l.d(N, { BLOCK_NAME: () => v, blockDefinition: () => O, installBlock: () => I, toDart: () => t, toJavascript: () => X, toLua: () => L, toPhp: () => T, toPython: () => e });
      var n = l(370), r = l(127), M = l(379), F = l(157), h = l(537), f = l(557);
      class H extends n.FieldTextInput {
        constructor(S, o, P) {
          super(n.Field.SKIP_SETUP), this.textGroup = null, this.maxLines_ = 1 / 0, this.isOverflowedY_ = !1, this.hintElement = null, this.cachedHintWidth = null, S !== n.Field.SKIP_SETUP && (P && this.configure_(P), this.setValue(S), o && this.setValidator(o));
        }
        configure_(S) {
          super.configure_(S), S.maxLines && this.setMaxLines(S.maxLines);
        }
        toXml(S) {
          return S.textContent = this.getValue().replace(/\n/g, "&#10;"), S;
        }
        fromXml(S) {
          this.setValue(S.textContent.replace(/&#10;/g, `
`));
        }
        saveState() {
          const S = this.saveLegacyState(H);
          return S !== null ? S : this.getValue();
        }
        loadState(S) {
          this.loadLegacyState(n.Field, S) || this.setValue(S);
        }
        initView() {
          this.createBorderRect_(), this.textGroup = n.utils.dom.createSvgElement(n.utils.Svg.G, { class: "blocklyEditableField" }, this.fieldGroup_), this.fieldGroup_ && n.utils.dom.addClass(this.fieldGroup_, "blocklyField");
        }
        getDisplayText_() {
          const S = this.getSourceBlock();
          if (!S) throw new Error("The field has not yet been attached to its input. Call appendField to attach it.");
          let o = this.getText();
          if (!o) return n.Field.NBSP;
          const P = o.split(`
`);
          o = "";
          const a = this.isOverflowedY_ ? this.maxLines_ : P.length;
          for (let p = 0; p < a; p++) {
            let m = P[p];
            m.length > this.maxDisplayLength ? m = m.substring(0, this.maxDisplayLength - 4) + "..." : this.isOverflowedY_ && p === a - 1 && (m = m.substring(0, m.length - 3) + "..."), m = m.replace(/\s/g, n.Field.NBSP), o += m, p !== a - 1 && (o += `
`);
          }
          return S.RTL && (o += "‏"), o;
        }
        doValueUpdate_(S) {
          super.doValueUpdate_(S), this.value_ !== null && (this.isOverflowedY_ = this.value_.split(`
`).length > this.maxLines_);
        }
        render_() {
          const S = this.getSourceBlock();
          if (!S) throw new Error("The field has not yet been attached to its input. Call appendField to attach it.");
          let o;
          const P = this.textGroup;
          for (; o = P.firstChild; ) P.removeChild(o);
          const a = this.getConstants();
          if (!a) throw Error("Constants not found");
          const p = this.getDisplayText_().split(`
`);
          let m = 0;
          for (let $ = 0; $ < p.length; $++) {
            const k = a.FIELD_TEXT_HEIGHT + a.FIELD_BORDER_RECT_Y_PADDING;
            n.utils.dom.createSvgElement(n.utils.Svg.TEXT, { class: "blocklyText blocklyMultilineText", x: a.FIELD_BORDER_RECT_X_PADDING, y: m + a.FIELD_BORDER_RECT_Y_PADDING, dy: a.FIELD_TEXT_BASELINE }, P).appendChild(document.createTextNode(p[$])), m += k;
          }
          if (this.isBeingEdited_) {
            const $ = this.htmlInput_;
            this.isOverflowedY_ ? n.utils.dom.addClass($, "blocklyHtmlTextAreaInputOverflowedY") : n.utils.dom.removeClass($, "blocklyHtmlTextAreaInputOverflowedY");
          }
          if (this.updateSize_(), this.isBeingEdited_) {
            S.RTL ? setTimeout(this.resizeEditor_.bind(this), 0) : this.resizeEditor_();
            const $ = this.htmlInput_;
            this.isTextValid_ ? (n.utils.dom.removeClass($, "blocklyInvalidInput"), n.utils.aria.setState($, n.utils.aria.State.INVALID, !1)) : (n.utils.dom.addClass($, "blocklyInvalidInput"), n.utils.aria.setState($, n.utils.aria.State.INVALID, !0));
          }
        }
        updateSize_() {
          var S;
          const o = this.getConstants();
          if (!o) throw Error("Constants not found");
          const P = this.textGroup.childNodes;
          let a = 0, p = 0;
          for (let m = 0; m < P.length; m++) {
            const $ = P[m], k = n.utils.dom.getTextWidth($);
            k > a && (a = k), p += o.FIELD_TEXT_HEIGHT + (m > 0 ? o.FIELD_BORDER_RECT_Y_PADDING : 0);
          }
          if (this.isBeingEdited_) {
            const m = String(this.value_).split(`
`), $ = n.utils.dom.createSvgElement(n.utils.Svg.TEXT, { class: "blocklyText blocklyMultilineText" });
            for (let Y = 0; Y < m.length; Y++) {
              m[Y].length > this.maxDisplayLength && (m[Y] = m[Y].substring(0, this.maxDisplayLength)), $.textContent = m[Y];
              const w = n.utils.dom.getTextWidth($);
              w > a && (a = w);
            }
            const k = this.htmlInput_;
            a += k.offsetWidth - k.clientWidth, H.showHint && (p += o.FIELD_TEXT_HEIGHT + o.FIELD_BORDER_RECT_Y_PADDING);
          }
          if (this.borderRect_ && (p += 2 * o.FIELD_BORDER_RECT_Y_PADDING, a += 2 * o.FIELD_BORDER_RECT_X_PADDING + 1), this.isBeingEdited_ && (a = Math.max(a, H.EDITOR_MIN_WIDTH), H.showHint && ((S = this.hintElement) === null || S === void 0 ? void 0 : S.isConnected))) {
            const m = this.workspace_.getScale();
            if (!this.cachedHintWidth || this.cachedHintWidth.scale !== m) {
              this.hintElement.style.width = "max-content";
              const $ = this.hintElement.offsetWidth;
              this.hintElement.style.width = "", $ > 0 && (this.cachedHintWidth = { scale: m, widthPx: $ });
            }
            this.cachedHintWidth && (a = Math.max(a, this.cachedHintWidth.widthPx / m));
          }
          this.borderRect_ && (this.borderRect_.setAttribute("width", `${a}`), this.borderRect_.setAttribute("height", `${p}`)), this.size_.width = a, this.size_.height = p, this.positionBorderRect_();
        }
        showEditor_(S, o) {
          super.showEditor_(S, o), this.forceRerender();
        }
        widgetCreate_() {
          const S = n.WidgetDiv.getDiv(), o = this.workspace_.getScale(), P = this.getConstants();
          if (!P) throw Error("Constants not found");
          const a = document.createElement("textarea");
          a.className = "blocklyHtmlInput blocklyHtmlTextAreaInput", a.setAttribute("spellcheck", String(this.spellcheck_));
          const p = P.FIELD_TEXT_FONTSIZE * o + "pt";
          S.style.fontSize = p, a.style.fontSize = p;
          const m = n.FieldTextInput.BORDERRADIUS * o + "px";
          a.style.borderRadius = m;
          const $ = P.FIELD_BORDER_RECT_X_PADDING * o, k = P.FIELD_BORDER_RECT_Y_PADDING * o / 2, Y = P.FIELD_TEXT_HEIGHT + P.FIELD_BORDER_RECT_Y_PADDING, w = Math.ceil(Y * o), o_ = H.showHint ? k + w : k;
          return a.style.padding = `${k}px ${$}px ${o_}px ${$}px`, a.style.lineHeight = Y * o + "px", S.appendChild(a), a.value = a.defaultValue = this.getEditorText_(this.value_), a.setAttribute("data-untyped-default-value", String(this.value_)), a.setAttribute("data-old-value", ""), n.utils.userAgent.GECKO ? setTimeout(this.resizeEditor_.bind(this), 0) : this.resizeEditor_(), this.bindInputEvents_(a), H.showHint && (this.hintElement = this.createHint(w), this.hintElement.style.fontFamily = P.FIELD_TEXT_FONTFAMILY, S.appendChild(this.hintElement)), a;
        }
        createHint(S) {
          const o = document.createElement("div");
          o.className = "blocklyMultilineHint", o.setAttribute("aria-hidden", "true"), o.style.height = S + "px";
          const P = document.createElement("div");
          P.className = "blocklyMultilineHintGroup", P.appendChild(this.createHintKeycap("⏎")), P.appendChild(this.createHintColon()), P.appendChild(this.createHintLabel(H.enterCommits ? "commit" : "newline")), o.appendChild(P);
          const a = document.createElement("div");
          return a.className = "blocklyMultilineHintGroup", a.appendChild(this.createHintKeycap("⇧")), a.appendChild(this.createHintKeycap("⏎")), a.appendChild(this.createHintColon()), a.appendChild(this.createHintLabel(H.enterCommits ? "newline" : "commit")), o.appendChild(a), o;
        }
        createHintColon() {
          const S = document.createElement("span");
          return S.className = "blocklyMultilineHintColon", S.textContent = ":", S;
        }
        createHintKeycap(S) {
          const o = document.createElement("span");
          return o.className = "blocklyMultilineHintKey", o.textContent = S, o;
        }
        createHintLabel(S) {
          const o = document.createElement("span");
          return o.className = "blocklyMultilineHintLabel", o.textContent = S === "commit" ? n.Msg.FIELD_MULTILINEINPUT_FINISH_EDITING || "Finish editing" : n.Msg.FIELD_MULTILINEINPUT_NEW_LINE || "New line", o;
        }
        setMaxLines(S) {
          typeof S == "number" && S > 0 && S !== this.maxLines_ && (this.maxLines_ = S, this.forceRerender());
        }
        getMaxLines() {
          return this.maxLines_;
        }
        onHtmlInputKeyDown_(S) {
          if (S.key === "Enter") {
            if (S.isComposing) return;
            const o = S.shiftKey;
            (H.enterCommits ? !o : o) ? super.onHtmlInputKeyDown_(S) : (this.insertNewline(), S.preventDefault(), S.stopPropagation());
          } else super.onHtmlInputKeyDown_(S);
        }
        insertNewline() {
          var S, o;
          const P = this.htmlInput_;
          if (!P) return;
          const a = (S = P.selectionStart) !== null && S !== void 0 ? S : P.value.length, p = (o = P.selectionEnd) !== null && o !== void 0 ? o : a;
          P.value = P.value.substring(0, a) + `
` + P.value.substring(p), P.selectionStart = P.selectionEnd = a + 1, P.dispatchEvent(new Event("input"));
        }
        static fromJson(S) {
          return new this(n.utils.parsing.replaceMessageReferences(S.text), void 0, S);
        }
      }
      function G() {
        n.fieldRegistry.register("field_multilinetext", H);
      }
      H.EDITOR_MIN_WIDTH = 150, H.enterCommits = !0, H.showHint = !0, n.Css.register(`
.blocklyHtmlTextAreaInput {
  font-family: monospace;
  resize: none;
  overflow: hidden;
  height: 100%;
  text-align: left;
}

.blocklyHtmlTextAreaInputOverflowedY {
  overflow-y: scroll;
}

.blocklyMultilineHint {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 0 4px;
  box-sizing: border-box;
  font-size: 0.85em;
  color: rgba(0, 0, 0, 0.6);
  background-color: white;
  border-top: 1px solid rgba(0, 0, 0, 0.15);
  border-radius: 0 0 4px 4px;
  user-select: none;
  pointer-events: none;
}

.blocklyMultilineHintGroup {
  display: inline-flex;
  align-items: center;
}

.blocklyMultilineHintKey {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 1.3em;
  height: 1.3em;
  padding: 0 0.25em;
  margin: 0 0.1em;
  border: 1px solid rgba(0, 0, 0, 0.35);
  border-radius: 3px;
  background-color: #f5f5f5;
  line-height: 1;
  box-sizing: border-box;
}

.blocklyMultilineHintColon {
  margin: 0 0.15em;
}

.blocklyMultilineHintLabel {
  white-space: nowrap;
}
`);
      const v = "text_multiline", V = { type: v, message0: "%1 %2", args0: [{ type: "field_image", src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAARCAYAAADpPU2iAAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAAdhgAAHYYBXaITgQAAABh0RVh0U29mdHdhcmUAcGFpbnQubmV0IDQuMS42/U4J6AAAAP1JREFUOE+Vks0KQUEYhjmRIja4ABtZ2dm5A3t3Ia6AUm7CylYuQRaUhZSlLZJiQbFAyRnPN33y01HOW08z8873zpwzM4F3GWOCruvGIE4/rLaV+Nq1hVGMBqzhqlxgCys4wJA65xnogMHsQ5lujnYHTejBBCK2mE4abjCgMGhNxHgDFWjDSG07kdfVa2pZMf4ZyMAdWmpZMfYOsLiDMYMjlMB+K613QISRhTnITnsYg5yUd0DETmEoMlkFOeIT/A58iyK5E18BuTBfgYXfwNJv4P9/oEBerLylOnRhygmGdPpTTBZAPkde61lbQe4moWUvYUZYLfUNftIY4zwA5X2Z9AYnQrEAAAAASUVORK5CYII=", width: 12, height: 17, alt: "¶" }, { type: "field_multilinetext", name: "TEXT", text: "" }], output: "String", style: "text_blocks", helpUrl: "%{BKY_TEXT_TEXT_HELPURL}", tooltip: "%{BKY_TEXT_TEXT_TOOLTIP}", extensions: ["parent_tooltip_when_inline"] };
      function X(i, S) {
        const o = S.multiline_quote_(i.getFieldValue("TEXT")), P = o.indexOf("+") !== -1 ? r.Order.ADDITION : r.Order.ATOMIC;
        return [o, P];
      }
      function t(i, S) {
        const o = S.multiline_quote_(i.getFieldValue("TEXT")), P = o.indexOf("+") !== -1 ? M.Order.ADDITIVE : M.Order.ATOMIC;
        return [o, P];
      }
      function L(i, S) {
        const o = S.multiline_quote_(i.getFieldValue("TEXT")), P = o.indexOf("..") !== -1 ? F.Order.CONCATENATION : F.Order.ATOMIC;
        return [o, P];
      }
      function T(i, S) {
        const o = S.multiline_quote_(i.getFieldValue("TEXT")), P = o.indexOf(".") !== -1 ? h.Order.STRING_CONCAT : h.Order.ATOMIC;
        return [o, P];
      }
      function e(i, S) {
        const o = S.multiline_quote_(i.getFieldValue("TEXT")), P = o.indexOf("+") !== -1 ? f.Order.ADDITIVE : f.Order.ATOMIC;
        return [o, P];
      }
      const E = n.common.createBlockDefinitionsFromJsonArray([V]), O = E[v];
      function I(i = {}) {
        G(), n.common.defineBlocks(E), i.javascript && (i.javascript.forBlock[v] = X), i.dart && (i.dart.forBlock[v] = t), i.lua && (i.lua.forBlock[v] = L), i.php && (i.php.forBlock[v] = T), i.python && (i.python.forBlock[v] = e);
      }
      const R = I;
      return A;
    })());
  })(j)), j.exports;
}
var s_ = qd();
function zd(g, C) {
  const _ = g.targetConnection;
  _ && g.disconnect(), g.connect(C.previousConnection), _ && C.nextConnection?.connect(_);
}
function Qd(g, C) {
  return C && (g.type === "mb_if" || g.type === "mb_for") ? g.getInput("DO")?.connection ?? null : g.nextConnection;
}
const S_ = ["command", "call", "assign", "comment", "raw", "if", "for", "set_macro_var", "save_var"], Zd = {
  mb_set_macro_var: "SET_GCODE_VARIABLE MACRO= VARIABLE= VALUE=",
  mb_save_var: "SAVE_VARIABLE VARIABLE= VALUE="
};
function n_() {
  const g = getComputedStyle(globalThis.document.documentElement), C = (_) => g.getPropertyValue(_).trim();
  return c_.defineTheme("tessera-macro-builder", {
    name: "tessera-macro-builder",
    base: D_.Classic,
    componentStyles: {
      workspaceBackgroundColour: C("--bg-app"),
      toolboxBackgroundColour: C("--bg-surface"),
      toolboxForegroundColour: C("--text-primary"),
      flyoutBackgroundColour: C("--bg-surface-hover-no-override"),
      flyoutForegroundColour: C("--text-primary"),
      scrollbarColour: C("--border-color"),
      insertionMarkerColour: C("--accent"),
      markerColour: C("--accent"),
      cursorColour: C("--accent"),
      selectedGlowColour: C("--accent")
    }
  });
}
class __ extends d_ {
  constructor(C = "") {
    super(C), this.maxDisplayLength = 1e4;
  }
  showEditor_(C, _) {
    super.showEditor_(C, _);
    const s = this.htmlInput_;
    s && !_ && requestAnimationFrame(() => {
      this.htmlInput_ === s && document.activeElement === s && (s.setSelectionRange(s.value.length, s.value.length), s.dispatchEvent(new Event("macro-builder-caret", { bubbles: !0 })));
    });
  }
  static fromJson(C) {
    return new __(C.text ?? "");
  }
}
class T_ extends s_.FieldMultilineInput {
  constructor(C = "") {
    super(C), this.maxDisplayLength = 1e4;
  }
  showEditor_(C, _) {
    super.showEditor_(C, _);
    const s = this.htmlInput_;
    s && !_ && requestAnimationFrame(() => {
      this.htmlInput_ === s && document.activeElement === s && (s.setSelectionRange(s.value.length, s.value.length), s.dispatchEvent(new Event("macro-builder-caret", { bubbles: !0 })));
    });
  }
  static fromJson(C) {
    return new T_(C.text ?? "");
  }
}
i_.register("mb_expanding_text", __);
i_.register("mb_expanding_multiline", T_);
s_.FieldMultilineInput.enterCommits = !1;
function _g(g) {
  for (const C of S_) {
    const _ = `mb_${C}`;
    if (u_[_]) continue;
    const s = `${g[C] ?? C} %1`, U = {
      type: _,
      message0: s,
      args0: [{
        type: C === "raw" ? "mb_expanding_multiline" : "mb_expanding_text",
        name: "VALUE",
        text: C === "comment" ? "# " : ""
      }],
      previousStatement: null,
      nextStatement: null,
      colour: C === "raw" ? 0 : C === "if" || C === "for" ? 275 : C === "call" ? 330 : C === "set_macro_var" || C === "save_var" ? 45 : 205,
      tooltip: g[C] ?? C
    };
    C === "if" ? (U.message1 = `${g.then ?? "then"} %1`, U.args1 = [{ type: "input_statement", name: "DO" }], U.message2 = `${g.else ?? "else"} %1`, U.args2 = [{ type: "input_statement", name: "ELSE" }]) : C === "for" && (U.message1 = `${g.do ?? "do"} %1`, U.args1 = [{ type: "input_statement", name: "DO" }]), U_([U]);
  }
}
function x(g) {
  const C = [];
  for (let _ = g; _; _ = _.getNextBlock()) C.push(_);
  return C;
}
class eg {
  workspace;
  toolbox = {
    kind: "flyoutToolbox",
    contents: S_.map((C) => ({ kind: "block", type: `mb_${C}` }))
  };
  origins = /* @__PURE__ */ new Map();
  document;
  lastEditedBlockId = null;
  enterBodyBlockId = null;
  constructor(C, _, s, U, D) {
    this.document = _;
    const u = globalThis.document.documentElement.getAttribute("data-locale")?.startsWith("ru") ? Vd : pi;
    M_(u.default ?? u), _g(U), this.workspace = C_(C, {
      theme: n_(),
      rtl: D,
      trashcan: !0,
      scrollbars: !0,
      move: { drag: !0, wheel: !0 },
      zoom: { controls: !0, pinch: !0, wheel: !0, startScale: 0.85, minScale: 0.35, maxScale: 2 },
      toolbox: this.toolbox
    }), this.workspace.addChangeListener((c) => {
      if (c.type === y.BLOCK_CREATE)
        for (const d of c.ids ?? []) {
          const l = this.workspace.getBlockById(d);
          if (!l) continue;
          const A = Zd[l.type];
          A && l.getFieldValue("VALUE") === "" && l.setFieldValue(A, "VALUE"), this.lastEditedBlockId = d, this.enterBodyBlockId = l.type === "mb_if" || l.type === "mb_for" ? d : null;
        }
      else if (c.type === y.BLOCK_CHANGE || c.type === y.BLOCK_MOVE && c.reason?.includes("drag")) {
        const d = c.blockId;
        d && this.workspace.getBlockById(d) && (this.lastEditedBlockId = d, this.enterBodyBlockId !== d && (this.enterBodyBlockId = null));
      }
    }), E_.getDiv()?.classList.add("macro-builder-widget");
    const B = (c, d) => {
      let l = null;
      for (const A of c) {
        const N = this.workspace.newBlock(`mb_${A.kind}`);
        N.setFieldValue(A.value, "VALUE"), N.initSvg(), N.render(), l ? l.nextConnection?.connect(N.previousConnection) : d ? d.connect(N.previousConnection) : N.moveBy(60, 40 + this.workspace.getTopBlocks(!1).length * 45), A.children.length && B(A.children, N.getInput("DO")?.connection ?? null), A.elseChildren.length && B(A.elseChildren, N.getInput("ELSE")?.connection ?? null), l = N, this.origins.set(N.id, {
          node: A,
          value: A.value,
          previous: N.getPreviousBlock()?.id ?? null,
          surround: N.getSurroundParent()?.id ?? null,
          doIds: x(N.getInputTargetBlock("DO")).map((n) => n.id),
          elseIds: x(N.getInputTargetBlock("ELSE")).map((n) => n.id)
        });
      }
    };
    y.disable();
    try {
      B(_.nodes, null);
    } finally {
      y.enable();
    }
    for (const [c, d] of this.origins) {
      const l = this.workspace.getBlockById(c);
      l && (d.previous = l.getPreviousBlock()?.id ?? null, d.surround = l.getSurroundParent()?.id ?? null, d.doIds = x(l.getInputTargetBlock("DO")).map((A) => A.id), d.elseIds = x(l.getInputTargetBlock("ELSE")).map((A) => A.id));
    }
  }
  /** Redraw Blockly's own SVG surfaces after Tessera changes theme or contrast. */
  updateTheme() {
    this.workspace.setTheme(n_());
  }
  /** Return the selected block for touch-friendly move and delete buttons. */
  selected() {
    const C = P_();
    return C instanceof a_ && C.workspace === this.workspace ? C : null;
  }
  /** Insert after the selected or last edited statement, entering a new control block first. */
  insertBlock(C) {
    const _ = this.selected(), s = this.lastEditedBlockId && this.workspace.getBlockById(this.lastEditedBlockId), U = this.workspace.getTopBlocks(!0).at(-1) ?? null, D = _ ?? s ?? (U && x(U).at(-1)) ?? null, u = this.workspace.newBlock(`mb_${C}`);
    if (u.initSvg(), u.render(), D) {
      const B = Qd(D, D.id === this.enterBodyBlockId);
      B && zd(B, u);
    } else
      u.moveBy(60, 40);
    return u.select(), this.lastEditedBlockId = u.id, this.enterBodyBlockId = C === "if" || C === "for" ? u.id : null, u;
  }
  /** A raw block uses a textarea because Blockly's single-line field cannot edit multiline Jinja. */
  editSelectedRaw(C) {
    const _ = this.selected();
    _?.type === "mb_raw" && _.setFieldValue(C, "VALUE");
  }
  /** An empty flyout releases its reserved width without replacing the workspace. */
  setToolboxVisible(C) {
    this.workspace.updateToolbox(C ? this.toolbox : { kind: "flyoutToolbox", contents: [] }), l_(this.workspace);
  }
  /** Generate only the body; Config supplies the protected section range. */
  serialize(C, _) {
    const s = this.workspace.getTopBlocks(!0).flatMap((U) => x(U)).map((U) => this.emit(U, 0)).join("");
    return g_(this.document, C, _) + s + this.document.suffix;
  }
  unchanged(C, _) {
    const s = (D) => x(C.getInputTargetBlock(D)).map((u) => u.id), U = (D, u) => D.length === u.length && D.every((B, c) => B === u[c]);
    return C.getFieldValue("VALUE") === _.value && C.getPreviousBlock()?.id === _.previous && C.getSurroundParent()?.id === _.surround && U(s("DO"), _.doIds) && U(s("ELSE"), _.elseIds) && [...x(C.getInputTargetBlock("DO")), ...x(C.getInputTargetBlock("ELSE"))].every((D) => {
      const u = this.origins.get(D.id);
      return !!u && this.unchanged(D, u);
    });
  }
  emit(C, _) {
    const s = this.origins.get(C.id), U = s?.node.kind === "raw" || C.type === "mb_raw";
    if (s && this.unchanged(C, s) && s.node.source) return s.node.source;
    const D = this.document.eol, u = this.document.indent + "    ".repeat(_), B = String(C.getFieldValue("VALUE") ?? "");
    if (U) return s && B === s.value ? s.node.source : `${B}${B.endsWith(D) ? "" : D}`;
    const c = C.type.slice(3);
    if (c === "if" || c === "for") {
      const d = c === "if" && s?.node.keyword === "elif" ? "elif" : c, l = x(C.getInputTargetBlock("DO")).map((F) => this.emit(F, _ + 1)).join(""), A = x(C.getInputTargetBlock("ELSE")), N = A.length === 1 && this.origins.get(A[0].id)?.node.keyword === "elif", n = A.map((F) => this.emit(F, N ? _ : _ + 1)).join(""), r = n && !N && (s?.node.elseHeader || `${u}{% else %}${D}`), M = d === "elif" ? "" : `${u}{% end${c} %}${D}`;
      return `${u}{% ${d} ${B} %}${D}${l}${r || ""}${n}${M}`;
    }
    return c === "assign" ? `${u}{% set ${B} %}${D}` : c === "comment" ? `${u}${H_(B)}${D}` : `${u}${B}${D}`;
  }
  /** Release SVG listeners and DOM once the dialog closes. */
  dispose() {
    E_.getDiv()?.classList.remove("macro-builder-widget"), this.workspace.dispose();
  }
}
export {
  eg as MacroWorkspace
};
