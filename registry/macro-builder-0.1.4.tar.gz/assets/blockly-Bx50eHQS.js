var af = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function Wf(Oi) {
  return Oi && Oi.__esModule && Object.prototype.hasOwnProperty.call(Oi, "default") ? Oi.default : Oi;
}
var cl = { exports: {} }, Gf = cl.exports, hf;
function Vf() {
  return hf || (hf = 1, (function(Oi, Z_) {
    (function(r, ls) {
      Oi.exports = ls();
    })(Gf, function() {
      var r = {}, ls, Se, as, mo, ul, M, jt, $, hs, _e, To, cs, Qt, ce, dl, gl, G, w, Co, yo, pl, ue, v, b, hn, Y, cn, Q, us, un, Li, xi, bo, ds, dn, li, gs, Re, fl, ai, hi, El, gn, vl, ps, fs, ci, ui, _l, Bi, Es, Nu, ml, vs, P, Mi, Mt, pn, Tl, fn, Pt, It, je, N, En, Cl, yl, bl, ht, vn, D, kl, _s, Ae, di, wl, _n, ko, Il, Sl, mn, Tn, Rl, Al, gi, pi, wo, Du, Cn, ms, yn, bn, kn, Nl, Dl, wn, In, Sn, Ts, Io, Cs, Rn, Ou, Lu, ys, Ol, te, Ne, Ll, An, xl, xu, Bl, Ml, Pl, Fl, Nn, Dn, On, Ln, De, Bu, So, Hl, xn, Bn, Mn, Ul, Pn, Ro, Fn, Mu, Wl, Gl, Pu, Fu, Pi, Hn, Ao, Un, ee, Vl, Fi, fi, zl, Hu, Kl, $e, Uu, Xl, Yl, Hi, Je, jl, Wu, $l, Jl, ql, Gu, Wn, Vu, zu, Ku, Zl, Xu, Yu, ju, Gn, No, Vn, Ql, zn, ta, ea, ia, oa, sa, na, ra, la, bs, Kn, ks, Oe, aa, ha, ws, ca, ua, Xn, da, Do, ga, pa, Is, Ss, $u, Ju, fa, Ea, Le, va, _a, ma, Ui, Rs, Yn, jn, Wi, Ta, $n, Ca, et, Oo, ya, ba, Jn, Gi, Vi, As, ka, wa, Ia, Lo, qu, Zu, Qu, Ns, Sa, td, Ra, qn, Zn, Aa, Na, Da, Ei, Oa, xo, La, zi, xa, ed, Ba, Qn, xe, Ki, Ma, tr, Ds, Pa, er, id, R, $t, St, ct, Be, Bo, A, dt, od, Fa, ir, Ha, Ua, Wa, Ga, Mo, sd, nd, rd, Os, Va, or, sr, Me, za, Ka, Po, ie, Xi, Xa, Ya, Ls, ja, $a, Ja, qa, Za, Qa, th, eh, ih, oh, sh, nh, rh, lh, ah, hh, ch, uh, dh, gh, ph, fh, Eh, vh, _h, mh, Th, ld, ad, Ch, yh, bh, kh, wh, Ih, Sh, Rh, hd, Ah, oe, nr, qe, Nh, vi, rr, lr, Dh, Oh, ar, Lh, xh, cd, Bh, xs, Mh, Ph, Fh, Hh, hr, Uh, Wh, Gh, ud, dd, gd, pd, fd, Vh, zh, Kh, Xh, Yh, jh, $h, cr, Bs, Jh, qh, Zh, Qh, tc, ec, ic, oc, sc, nc, rc, lc, d;
      ls = function(t, e) {
        Se(), ur = setTimeout(function() {
          e && e.handleRightClick(t);
        }, 750);
      }, Se = function() {
        ur && (clearTimeout(ur), ur = 0);
      }, as = function(t) {
        return !t.type.startsWith("pointer") || t instanceof PointerEvent && ul(t);
      }, mo = function(t) {
        return `${t.pointerId}`;
      }, ul = function(t) {
        var e = mo(t);
        return Ft ? Ft === e : t.type === "pointerdown" ? (Ft = e, !0) : !1;
      }, M = function(t, e, i, o, s, n) {
        function l(c) {
          (s || as(c)) && (i ? o.call(i, c) : o(c));
        }
        var a = [];
        if (e in Yi) for (let c = 0; c < Yi[e].length; c++) {
          let E = Yi[e][c];
          t.addEventListener(E, l, Object.assign({}, { capture: !1 }, n)), a.push([t, E, l]);
        }
        else t.addEventListener(e, l, Object.assign({}, { capture: !1 }, n)), a.push([t, e, l]);
        return a;
      }, jt = function(t, e, i, o, s) {
        function n(a) {
          i ? o.call(i, a) : o(a);
        }
        var l = [];
        if (e in Yi) for (let a = 0; a < Yi[e].length; a++) {
          let c = Yi[e][a];
          t.addEventListener(c, n, Object.assign({}, { capture: !1 }, s)), l.push([t, c, n]);
        }
        else t.addEventListener(e, n, Object.assign({}, { capture: !1 }, s)), l.push([t, e, n]);
        return l;
      }, $ = function(t) {
        for (var e = t[t.length - 1][2]; t.length; ) {
          let [i, o, s] = t.pop();
          i.removeEventListener(o, s, !1);
        }
        return e;
      }, hs = function(t) {
        if (t.target instanceof HTMLElement) {
          if (t.target.isContentEditable || t.target.getAttribute("data-is-text-input") === "true") return !0;
          if (t.target instanceof HTMLInputElement) return t = t.target, t.type === "text" || t.type === "number" || t.type === "email" || t.type === "password" || t.type === "search" || t.type === "tel" || t.type === "url";
          if (t.target instanceof HTMLTextAreaElement) return !0;
        }
        return !1;
      }, _e = function(t) {
        return t.ctrlKey && Fo ? !0 : t.button === 2;
      }, To = function(t, e, i) {
        var o = e.createSVGPoint();
        return o.x = t.clientX, o.y = t.clientY, i || (i = e.getScreenCTM().inverse()), o.matrixTransform(i);
      }, cs = function(t) {
        switch (t.deltaMode) {
          default:
            return { x: t.deltaX, y: t.deltaY };
          case 1:
            return { x: t.deltaX * 40, y: t.deltaY * 40 };
          case 2:
            return { x: t.deltaX * 125, y: t.deltaY * 125 };
        }
      }, Qt = function(t, e) {
        return e = t.indexOf(e), e === -1 ? !1 : (t.splice(e, 1), !0);
      }, ce = function(t) {
        Ad.push(t);
      }, dl = function(t, e, i) {
        e && typeof window < "u" && (t = t.getRootNode(), Rd.has(t) || (Rd.add(t), i = i.replace(/[\\/]$/, ""), i = [uf, ...Ad].join(`
`).replace(/<<<PATH>>>/g, i), e = document.createElement("style"), e.id = "blockly-common-style", e.textContent = i, (typeof globalThis.ShadowRoot < "u" && t instanceof ShadowRoot ? t : document.head).prepend(e)));
      }, gl = function(t) {
        t.removeAttribute("role");
      }, G = function(t, e) {
        e ? t.setAttribute("role", e) : gl(t);
      }, w = function(t, e, i) {
        Array.isArray(i) && (i = i.join(" ")), t.setAttribute("aria-" + e, `${i}`);
      }, Co = function(t, e) {
        t.removeAttribute("aria-" + e);
      }, yo = function(t, e) {
        return (t = t.getAttribute("aria-" + e)) ? t : null;
      }, pl = function(t) {
        if (!Fs || !document.contains(Fs)) {
          var e = document.createElement("div");
          e.textContent = "", e.id = "blocklyAriaAnnounce", b(e, "hiddenForAria"), w(e, y.LIVE, zt.POLITE), G(e, Dd), w(e, y.ATOMIC, !0), t.appendChild(e), Fs = e;
        }
      }, ue = function(t, e) {
        if (!Fs) throw Error("ARIA live region not initialized.");
        var i = Fs, { assertiveness: o = zt.POLITE, role: s = Dd } = e || {};
        pc.push(t), Ps = o === zt.ASSERTIVE || Ps === zt.ASSERTIVE ? zt.ASSERTIVE : o === zt.POLITE || Ps === zt.POLITE ? zt.POLITE : zt.OFF, clearTimeout(Od), Od = setTimeout(() => {
          i.replaceChildren(), w(i, y.LIVE, Ps), G(i, s);
          var n = document.createElement("span");
          n.textContent = pc.join(`
`) + (fc ? " " : ""), fc = !fc, i.appendChild(n), pc.length = 0, Ps = zt.OFF;
        }, 10);
      }, v = function(t, e, i) {
        var o = document.createElementNS("http://www.w3.org/2000/svg", `${t}`);
        t !== g.SVG.toString() && t !== g.G.toString() && o.tagName !== g.SVG.toString() && o.tagName !== g.G.toString() || G(o, W.NONE);
        for (let s in e) o.setAttribute(s, `${e[s]}`);
        return i && i.appendChild(o), o;
      }, b = function(t, e) {
        return e = e.split(" "), e.every((i) => t.classList.contains(i)) ? !1 : (t.classList.add(...e), !0);
      }, hn = function(t, e) {
        t.classList.remove(...e.split(" "));
      }, Y = function(t, e) {
        return e = e.split(" "), e.every((i) => !t.classList.contains(i)) ? !1 : (t.classList.remove(...e), !0);
      }, cn = function(t, e) {
        return t.classList.contains(e);
      }, Q = function(t) {
        return t && t.parentNode ? t.parentNode.removeChild(t) : null;
      }, us = function(t, e) {
        var i = e.nextSibling;
        if (e = e.parentNode, !e) throw Error("Reference node has no parent.");
        i ? e.insertBefore(t, i) : e.appendChild(t);
      }, un = function(t, e) {
        t.style.transform = e, t.style["-webkit-transform"] = e;
      }, Li = function() {
        Ec++, Te || (Te = /* @__PURE__ */ Object.create(null));
      }, xi = function() {
        Ec--, Ec || (Te = null);
      }, bo = function(t) {
        var e = t.textContent + `
` + t.className.baseVal, i;
        return Te && (i = Te[e]) || (i = window.getComputedStyle(t), i = ds(t, i.fontSize, i.fontWeight, i.fontFamily), Te && (Te[e] = i)), i;
      }, ds = function(t, e, i, o) {
        var s = t.textContent;
        t = s + `
` + t.className.baseVal;
        var n;
        return Te && (n = Te[t]) || (Hs || (n = document.createElement("canvas"), n.className = "blocklyComputeCanvas", document.body.appendChild(n), Hs = n.getContext("2d")), s && Hs ? (Hs.font = i + " " + e + " " + o, n = Math.ceil(Hs.measureText(s).width)) : n = 0, Te && (Te[t] = n)), n;
      }, dn = function(t, e, i, o) {
        var s = document.createElement("span");
        s.style.font = i + " " + e + " " + o, s.textContent = t, t = document.createElement("div"), t.style.width = "1px", t.style.height = "0", e = document.createElement("div"), e.style.display = "flex", e.style.position = "fixed", e.style.top = "0", e.style.left = "0", e.appendChild(s), e.appendChild(t), document.body.appendChild(e), i = { height: 0, baseline: 0 };
        try {
          e.style.alignItems = "baseline", i.baseline = t.offsetTop - s.offsetTop, e.style.alignItems = "flex-end", i.height = t.offsetTop - s.offsetTop;
        } finally {
          document.body.removeChild(e);
        }
        return i;
      }, r.t = function() {
        return Ht.getFocusManager();
      }, li = function(t) {
        return t && typeof t.getFocusableElement == "function" && typeof t.getFocusableTree == "function" && typeof t.onNodeFocus == "function" && typeof t.onNodeBlur == "function" && typeof t.canBeFocused == "function";
      }, gs = function(t) {
        return li(t) && typeof t.id == "string" && typeof t.workspace == "object" && typeof t.select == "function" && typeof t.unselect == "function";
      }, Re = function(t, e) {
        for (let i in e) e[i] !== null && Array.isArray(e[i]) ? t[i] = Re(t[i] || [], e[i]) : t[i] = e[i] !== null && typeof e[i] == "object" ? Re(t[i] || /* @__PURE__ */ Object.create(null), e[i]) : e[i];
        return t;
      }, fl = function(t, e, i, o) {
        t = t + " was deprecated in " + e + " and will be deleted in " + i + ".", o && (t += `
Use ` + o + " instead."), Bd.has(t) || (Bd.add(t), console.warn(t));
      }, ai = function(t) {
        return Us[t] || null;
      }, hi = function() {
        var t = [];
        for (let e in Us) t.push(Us[e]);
        return t;
      }, El = function(t) {
        Us[t.id] = t;
      }, gn = function(t) {
        delete Us[t.id];
      }, vl = function() {
        return de;
      }, ps = function(t) {
        de = t, t.rendered && r.t().setPopoverFocusRoot(t.getInjectionDiv());
      }, fs = function() {
        var t = r.t().getFocusedNode();
        return t && gs(t) ? t : null;
      }, ci = function(t) {
        var e = fs(), i, o, s, n, l = new (D(p.SELECTED))((i = e?.id) != null ? i : null, (o = t?.id) != null ? o : null, (n = (s = t?.workspace.id) != null ? s : e?.workspace.id) != null ? n : "");
        N(l);
      }, ui = function(t = de) {
        return vc || (t && t.rendered ? t.getInjectionDiv() : null);
      }, _l = function(t) {
        vc = t;
      }, Bi = function(t) {
        for (; t.options.parentWorkspace; ) t = t.options.parentWorkspace;
        var e = t.getParentSvg(), i = t.getCachedParentSvgSize(), o = e.parentElement;
        if (o instanceof HTMLElement) {
          var s = o.offsetWidth;
          o = o.offsetHeight, i.width !== s && (e.setAttribute("width", s + "px"), t.setCachedParentSvgSize(s, null)), i.height !== o && (e.setAttribute("height", o + "px"), t.setCachedParentSvgSize(null, o)), t.resize();
        }
      }, Es = function(t, e) {
        var i = /* @__PURE__ */ Object.create(null), o = t.getDescendants(!0);
        e && (t = t.getNextBlock()) && (t = o.indexOf(t), o.splice(t, o.length - t));
        for (let s = 0, n; n = o[s]; s++) i[n.type] ? i[n.type]++ : i[n.type] = 1;
        return i;
      }, Nu = function(t) {
        return function() {
          this.jsonInit(t);
        };
      }, ml = function(t) {
        Pd.defineBlocksWithJsonArrayInternal(t);
      }, r.yb = function(t) {
        var e = {};
        for (let i = 0; i < t.length; i++) {
          let o = t[i];
          if (!o) {
            console.warn(`Block definition #${i} in JSON array is ${o}. Skipping`);
            continue;
          }
          let s = o.type;
          s ? e[s] = { init: Nu(o) } : console.warn(`Block definition #${i} in JSON array is missing a type attribute. Skipping.`);
        }
        return e;
      }, r.Ab = function(t) {
        for (let e of Object.keys(t)) {
          let i = t[e];
          e in gt && console.warn(`Block definition "${e}" overwrites previous definition.`), gt[e] = i;
        }
      }, vs = function(t) {
        var e = de, i = r.t().getFocusedTree();
        for (let o of hi()) if (i === o) {
          e = o;
          break;
        }
        !hs(t) && e && (!e.rendered || e.isFlyout || e.isVisible()) && S.registry.onKeyDown(e, t);
      }, P = function(t, e, i, o) {
        if (!(t instanceof _) && typeof t != "string" || `${t}`.trim() === "") throw Error('Invalid type "' + t + '". The type must be a non-empty string or a Blockly.registry.Type.');
        if (t = `${t}`.toLowerCase(), typeof e != "string" || e.trim() === "") throw Error('Invalid name "' + e + '". The name must be a non-empty string.');
        var s = e.toLowerCase();
        if (!i) throw Error("Can not register a null value");
        var n = Ti[t], l = fr[t];
        switch (n || (n = Ti[t] = /* @__PURE__ */ Object.create(null), l = fr[t] = /* @__PURE__ */ Object.create(null)), t) {
          case String(_.FIELD):
            if (typeof i.fromJson != "function") throw Error('Type "' + t + '" must have a fromJson function');
        }
        if (!o && n[s] && n[s] !== i) throw Error('Name "' + s + '" with type "' + t + '" already registered.');
        n[s] = i, l[s] = e;
      }, Mi = function(t, e) {
        t = `${t}`.toLowerCase(), e = e.toLowerCase();
        var i = Ti[t];
        i && i[e] ? (delete Ti[t][e], delete fr[t][e]) : console.warn("Unable to unregister [" + e + "][" + t + "] from the registry.");
      }, Mt = function(t, e, i) {
        t = `${t}`.toLowerCase(), e = e.toLowerCase();
        var o = Ti[t];
        if (!o || !o[e]) {
          if (e = "Unable to find [" + e + "][" + t + "] in the registry.", i) throw Error(e + " You must require or register a " + t + " plugin.");
          return console.warn(e), null;
        }
        return o[e];
      }, pn = function(t, e) {
        return t = `${t}`.toLowerCase(), e = e.toLowerCase(), (t = Ti[t]) ? !!t[e] : !1;
      }, Tl = function(t, e, i) {
        return Mt(t, e, i);
      }, fn = function(t, e, i) {
        t = `${t}`.toLowerCase();
        var o = Ti[t];
        if (!o) {
          if (o = `Unable to find [${t}] in the registry.`, i) throw Error(`${o} You must require or register a ${t} plugin.`);
          return console.warn(o), null;
        }
        if (!e) return o;
        t = fr[t], i = /* @__PURE__ */ Object.create(null);
        for (let s of Object.keys(o)) i[t[s]] = o[s];
        return i;
      }, Pt = function(t, e, i) {
        return e = e.plugins[String(t)] || "default", typeof e == "function" ? e : Mt(t, e, i);
      }, It = function() {
        return "blockly-" + (pf++).toString(36);
      }, je = function() {
        return Fd.genUid();
      }, N = function(t) {
        mc.fireInternal(t);
      }, En = function() {
        var t = yl(Fe);
        Fe.length = 0;
        for (let e of t) {
          if (!e.workspaceId) continue;
          let i;
          (i = ai(e.workspaceId)) == null || i.fireChangeListener(e);
        }
      }, Cl = function(t) {
        if (t.type === p.BLOCK_CHANGE && t.element === "mutation") {
          let e;
          for (e = Fe.length; e > 0; e--) {
            let i = Fe[e - 1];
            if (i.group !== t.group || i.workspaceId !== t.workspaceId || i.type !== p.BLOCK_MOVE || i.newParentId !== t.blockId) break;
          }
          Fe.splice(e, 0, t);
        } else Fe.push(t);
      }, yl = function(t) {
        var e = [];
        for (let i of t) if (t = e[e.length - 1], !i.isNull()) if (!t || t.workspaceId !== i.workspaceId || t.group !== i.group) e.push(i);
        else if (i.type === p.BLOCK_MOVE && t.type === p.BLOCK_MOVE && i.blockId === t.blockId) {
          if (t.newParentId = i.newParentId, t.newInputName = i.newInputName, t.newCoordinate = i.newCoordinate, t.reason || i.reason) {
            let o, s;
            t.reason = Array.from(new Set(((o = t.reason) != null ? o : []).concat((s = i.reason) != null ? s : [])));
          }
        } else i.type === p.BLOCK_CHANGE && t.type === p.BLOCK_CHANGE && i.blockId === t.blockId && i.element === t.element && i.name === t.name ? t.newValue = i.newValue : i.type === p.VIEWPORT_CHANGE && t.type === p.VIEWPORT_CHANGE ? (t.viewTop = i.viewTop, t.viewLeft = i.viewLeft, t.scale = i.scale, t.oldScale = i.oldScale) : (i.type !== p.CLICK || t.type !== p.BUBBLE_OPEN) && (i.type === p.SELECTED && t.type === p.SELECTED && t.newElementId === void 0 ? (t.newElementId = i.newElementId, t.oldElementId === t.newElementId && e.pop()) : e.push(i));
        return t = e.filter((i) => !i.isNull());
      }, bl = function() {
        for (let t = 0, e; e = Fe[t]; t++) e.recordUndo = !1;
      }, ht = function() {
        return r.Ub === 0;
      }, r.B = function(t) {
        mc.setGroupInternal(t);
      }, vn = function(t) {
        var e = [];
        t = t.getDescendants(!1);
        for (let i = 0, o; o = t[i]; i++) e[i] = o.id;
        return e;
      }, D = function(t) {
        var e = Mt(_.EVENT, t, void 0);
        if (!e) throw Error(`Event type ${t} not found in registry.`);
        return e;
      }, kl = function(t) {
        Object.keys(t).forEach(function(e) {
          r.C[e] = t[e];
        });
      }, _s = function(t) {
        return Ud.getSizeInternal(t);
      }, Ae = function(t, e) {
        return t = window.getComputedStyle(t), t[e] || t.getPropertyValue(e);
      }, di = function(t) {
        var e = new m(0, 0);
        t = t.getBoundingClientRect();
        var i = document.documentElement;
        return i = new m(window.pageXOffset || i.scrollLeft, window.pageYOffset || i.scrollTop), e.x = t.left + i.x, e.y = t.top + i.y, e;
      }, wl = function() {
        var t = document.body, e = document.documentElement;
        return new m(t.scrollLeft || e.scrollLeft, t.scrollTop || e.scrollTop);
      }, _n = function(t) {
        var e = parseFloat(Ae(t, "borderLeftWidth")), i = parseFloat(Ae(t, "borderRightWidth")), o = parseFloat(Ae(t, "borderTopWidth"));
        return t = parseFloat(Ae(t, "borderBottomWidth")), new F(o, t, e, i);
      }, ko = function(t, e, i) {
        var o = i.getBoundingClientRect();
        return i = _n(i), new m(t - (o.left + window.scrollX + i.left), e - (o.top + window.scrollY + i.top));
      }, Il = function(t, e, i) {
        t = Sl(t, e, i), e.scrollLeft = t.x, e.scrollTop = t.y;
      }, Sl = function(t, e, i) {
        var o = di(t), s = di(e), n = _n(e), l = o.x - s.x - n.left;
        return o = o.y - s.y - n.top, s = new H(t.offsetWidth, t.offsetHeight), t = e.clientWidth - s.width, s = e.clientHeight - s.height, n = e.scrollLeft, e = e.scrollTop, i ? (n += l - t / 2, e += o - s / 2) : (n += Math.min(l, Math.max(l - t, 0)), e += Math.min(o, Math.max(o - s, 0))), new m(n, e);
      }, mn = function(t) {
        var e = new m(0, 0), i = t.x && t.getAttribute("x"), o = t.y && t.getAttribute("y");
        return i && (e.x = parseInt(i)), o && (e.y = parseInt(o)), (i = (i = t.getAttribute("transform")) && i.match(Wd)) && (e.x += Number(i[1]), i[3] && (e.y += Number(i[3]))), (t = t.getAttribute("style")) && t.includes("translate") && (t = t.match(Gd)) && (e.x += Number(t[1]), t[3] && (e.y += Number(t[3]))), e;
      }, Tn = function(t) {
        for (var e = 0, i = 0; t; ) {
          let o = mn(t);
          if (e += o.x, i += o.y, (" " + (t.getAttribute("class") || "") + " ").includes(" injectionDiv ")) break;
          t = t.parentNode;
        }
        return new m(e, i);
      }, Rl = function() {
        var t = wl();
        return new F(t.y, document.documentElement.clientHeight + t.y, t.x, document.documentElement.clientWidth + t.x);
      }, Al = function() {
        var t = document.documentElement, e = window;
        return new m(e.pageXOffset || t.scrollLeft, e.pageYOffset || t.scrollTop);
      }, gi = function(t, e) {
        var i = e.x;
        e = e.y;
        var o = t.getInjectionDiv().getBoundingClientRect();
        return i = new m(i - o.left, e - o.top), e = t.getOriginOffsetInPixels(), m.difference(i, e).scale(1 / t.scale);
      }, pi = function(t, e) {
        var i = e.scale(t.scale);
        e = i.x, i = i.y;
        var o = t.getInjectionDiv().getBoundingClientRect();
        return t = t.getOriginOffsetInPixels(), new m(e + o.left + t.x, i + o.top + t.y);
      }, r.sc = function(t) {
        return vr.createElementNS("https://developers.google.com/blockly/xml", t);
      }, r.tc = function(t) {
        return vr.createTextNode(t);
      }, r.vc = function(t) {
        var e = Er.parseFromString(t, "text/xml");
        if (e && e.documentElement && !e.getElementsByTagName("parsererror").length) return e.documentElement;
        if ((e = Er.parseFromString(t, "text/html")) && e.body.firstChild && e.body.firstChild.nodeName.toLowerCase() === "xml") return e.body.firstChild;
        throw Error(`DOMParser was unable to parse: ${t}`);
      }, wo = function(t) {
        return Du(Tc.serializeToString(t));
      }, Du = function(t) {
        return t.replace(ff, (e) => `&#${e.charCodeAt(0)};`);
      }, Cn = function(t) {
        if (!t) return null;
        if (t instanceof Element || typeof t == "string") {
          t = Dl(t);
          var e = { contents: kn(t) };
          t instanceof Node && Nl(t, e), t = e;
        }
        e = t.kind;
        var i = t.contents;
        if (e && e !== "flyoutToolbox" && e !== "categoryToolbox") throw Error("Invalid toolbox kind " + e + ". Please supply either flyoutToolbox or categoryToolbox");
        if (!i) throw Error("Toolbox must have a contents attribute.");
        return t;
      }, ms = function(t) {
        return t ? t.contents ? t.contents : Array.isArray(t) && t.length > 0 && !t[0].nodeType ? t : kn(t) : [];
      }, yn = function(t) {
        if (!t) return !1;
        var e = t.kind;
        return e ? e === "categoryToolbox" : !!t.contents.filter((i) => i.kind.toUpperCase() === "CATEGORY").length;
      }, bn = function(t) {
        return t && t.contents ? !!t.contents.filter(function(e) {
          return e.kind.toUpperCase() === "CATEGORY";
        }).length : !1;
      }, kn = function(t) {
        var e = [], i = t.childNodes;
        i || (i = t);
        for (let o = 0, s; s = i[o]; o++) {
          if (!s.tagName) continue;
          t = {};
          let n = s.tagName.toUpperCase();
          t.kind = n, n === "BLOCK" ? t.blockxml = s : s.childNodes && s.childNodes.length > 0 && (t.contents = kn(s)), Nl(s, t), e.push(t);
        }
        return e;
      }, Nl = function(t, e) {
        for (let i = 0; i < t.attributes.length; i++) {
          let o = t.attributes[i];
          o.nodeName.includes("css-") ? (e.cssconfig = e.cssconfig || {}, e.cssconfig[o.nodeName.replace("css-", "")] = o.value) : e[o.nodeName] = o.value;
        }
      }, Dl = function(t) {
        var e = null;
        if (t) if (typeof t == "string") {
          if (e = r.vc(t), e.nodeName.toLowerCase() !== "xml") throw TypeError("Toolbox should be an <xml> document.");
        } else t instanceof Element && (e = t);
        return e;
      }, wn = function(t, e, i, o, s, n) {
        var l = n.scrollbar && n.scrollbar.canScrollVertically();
        return t.horizontal === Vo.LEFT ? (i = s.absoluteMetrics.left + i, l && n.RTL && (i += pt.scrollbarThickness)) : (i = s.absoluteMetrics.left + s.viewMetrics.width - e.width - i, l && !n.RTL && (i -= pt.scrollbarThickness)), t.vertical === ei.TOP ? t = s.absoluteMetrics.top + o : (t = s.absoluteMetrics.top + s.viewMetrics.height - e.height - o, n.scrollbar && n.scrollbar.canScrollHorizontally() && (t -= pt.scrollbarThickness)), new F(t, t + e.height, i, i + e.width);
      }, In = function(t, e) {
        return { horizontal: e.toolboxMetrics.position === I.LEFT || t.horizontalLayout && !t.RTL ? Vo.RIGHT : Vo.LEFT, vertical: e.toolboxMetrics.position === I.BOTTOM ? ei.TOP : ei.BOTTOM };
      }, Sn = function(t, e, i, o) {
        var s = t.left, n = t.right - t.left, l = t.bottom - t.top;
        for (let a = 0; a < o.length; a++) {
          let c = o[a];
          t.intersects(c) && (t = i === yi.UP ? c.top - l - e : c.bottom + e, t = new F(t, t + l, s, s + n), a = -1);
        }
        return t;
      }, Ts = function(t, e) {
        P(_.SERIALIZER, t, e);
      }, Io = function(t, { addCoordinates: e = !1, saveIds: i = !0 } = {}) {
        var o = t.workspace, s = /* @__PURE__ */ Object.create(null);
        return s.height = t.getSize().height, s.width = t.getSize().width, i && (s.id = t.id), e && (e = t.getRelativeToSurfaceXY(), s.x = o.RTL ? o.getWidth() - e.x : e.x, s.y = e.y), t.getText() && (s.text = t.getText()), t.isCollapsed() && (s.collapsed = !0), t.isOwnEditable() || (s.editable = !1), t.isOwnMovable() || (s.movable = !1), t.isOwnDeletable() || (s.deletable = !1), s;
      }, Cs = function(t, e, { recordUndo: i = !1 } = {}) {
        var o = r.Qc;
        if (r.Qc = i, i = e.newComment(t.id), t.x !== void 0 || t.y !== void 0) {
          let n = i.getRelativeToSurfaceXY(), l, a = (l = t.x) != null ? l : n.x;
          a = e.RTL ? e.getWidth() - a : a;
          var s;
          e = (s = t.y) != null ? s : n.y, i.moveTo(new m(a, e));
        }
        if (t.width !== void 0 || t.height) {
          s = i.getSize();
          let n, l;
          i.setSize(new H((n = t.width) != null ? n : s.width, (l = t.height) != null ? l : s.height));
        }
        return t.text !== void 0 && i.setText(t.text), t.collapsed !== void 0 && i.setCollapsed(t.collapsed), t.editable !== void 0 && i.setEditable(t.editable), t.movable !== void 0 && i.setMovable(t.movable), t.deletable !== void 0 && i.setDeletable(t.deletable), r.Qc = o, i;
      }, Rn = function(t, e) {
        P(_.PASTER, t, e);
      }, Ou = function(t) {
        for (var e = t.workspace, i = t.getRelativeToSurfaceXY(), o = new m(0, 0), s = e.getTopComments(!1).filter((n) => n.id !== t.id).map((n) => n.getRelativeToSurfaceXY()); Lu(m.sum(i, o), s); ) o.translate(e.RTL ? -30 : 30, 30);
        t.moveTo(m.sum(i, o));
      }, Lu = function(t, e) {
        return e.some((i) => Math.abs(i.x - t.x) <= 1 && Math.abs(i.y - t.y) <= 1);
      }, ys = function(t) {
        return t && typeof t.saveState == "function" && typeof t.loadState == "function";
      }, Ol = function(t) {
        return Ll(t), bd ? (An(), Promise.resolve()) : (zo || (zo = new Promise((e) => {
          Sc = e, Xd = window.requestAnimationFrame(() => {
            An(), e();
          });
        })), zo);
      }, te = function() {
        return zo || Promise.resolve();
      }, Ne = function(t) {
        t || window.cancelAnimationFrame(Xd), An(t), !t && Sc && Sc();
      }, Ll = function(t) {
        wc.add(t), Ic.set(t, { group: r.gd, recordUndo: r.Qc });
        var e = t.getParent();
        e ? Ll(e) : kr.add(t);
      }, An = function(t) {
        var e = t ? /* @__PURE__ */ new Set([t]) : new Set([...kr].map((l) => l.workspace)), i = [...kr].filter(xu).filter((l) => e.has(l.workspace));
        for (var o of i) Bl(o);
        for (let l of e) l.resizeContents(), l.connectionDBList.forEach((a) => a?.beginBulkUpdates());
        for (var s of i) o = s.getRelativeToSurfaceXY(), s.updateComponentLocations(o);
        for (var n of e) n.connectionDBList.forEach((l) => l?.endBulkUpdates());
        for (let l of i)
          s = r.gd, n = r.Qc, (o = Ic.get(l)) && (o.group && r.B(o.group), r.Qc = o.recordUndo), l.bumpNeighbours(), r.B(s), r.Qc = n;
        for (let l of i) xl(l);
        t || (zo = null);
      }, xl = function(t) {
        kr.delete(t), wc.delete(t), Ic.delete(t);
        for (let e of t.getChildren(!1)) xl(e);
      }, xu = function(t) {
        return !t.isDisposed() && !t.getParent();
      }, Bl = function(t) {
        if (wc.has(t) && t.initialized) {
          for (let e of t.getChildren(!1)) Bl(e);
          t.renderEfficiently();
        }
      }, Ml = function(t, e) {
        Ln(ye.ALERT, t, e, void 0);
      }, Pl = function(t, e) {
        Ln(ye.CONFIRM, t, e, void 0);
      }, Fl = function(t, e, i) {
        Ln(ye.PROMPT, t, i, e);
      }, Nn = function(t, e) {
        Rc(t, e);
      }, Dn = function(t, e) {
        Yd(t, e);
      }, On = function(t, e, i) {
        jd(t, e, i);
      }, Ln = function(...[t, e, i, o]) {
        var s = document.createElement("dialog"), n = document.createElement("form"), l = document.createElement("label"), a = document.createElement("input"), c = document.createElement("div"), E = document.createElement("button");
        s.className = "blocklyDialog", n.className = "blocklyDialogForm", l.className = "blocklyDialogPrompt", c.className = "blocklyDialogButtonRow", E.className = "blocklyDialogConfirmButton", n.setAttribute("method", "dialog"), l.textContent = e, l.setAttribute("for", "blockly-form-input"), E.textContent = r.C.DIALOG_OK, E.value = "ok", s.appendChild(n), n.appendChild(l), t === ye.PROMPT && (a.id = "blockly-form-input", a.className = "blocklyDialogInput", a.type = "text", a.name = "input", a.autofocus = !0, o && (a.value = o), n.appendChild(a)), c.appendChild(E), (t === ye.CONFIRM || t === ye.PROMPT) && (e = document.createElement("button"), e.className = "blocklyDialogCancelButton", e.textContent = r.C.DIALOG_CANCEL, e.value = "cancel", c.appendChild(e)), n.appendChild(c);
        var O;
        Ir === 0 && (O = r.t().ephemeralFocusTaken() ? void 0 : r.t().takeEphemeralFocus(s)), Ir++, s.addEventListener("close", () => {
          if (Ir--, !Ir) {
            let L;
            (L = O) == null || L();
          }
          switch (s.remove(), t) {
            case ye.CONFIRM:
              i(s.returnValue === "ok");
              break;
            case ye.PROMPT:
              i(s.returnValue === "ok" ? a.value : null);
              break;
            case ye.ALERT:
              i?.();
          }
        }), document.body.appendChild(s), s.showModal();
      }, De = function(t) {
        return typeof t.bubbleIsVisible == "function" && typeof t.setBubbleVisible == "function" && typeof t.getBubble == "function";
      }, Bu = function(t, e) {
        return e.map((i) => t.getBlockById(i)).filter((i) => i && i.isShadow()).length === e.length;
      }, So = function(t) {
        return t && typeof t.getProcedureDef == "function";
      }, Hl = function(t) {
        return t.getVariableModel !== void 0;
      }, r.Bd = function(t) {
        t = t.getAllBlocks(!1);
        var e = /* @__PURE__ */ new Set();
        for (let i = 0; i < t.length; i++) {
          let o = t[i].getVarModels();
          if (o) for (let s = 0; s < o.length; s++) {
            let n = o[s];
            n.getId() && e.add(n);
          }
        }
        return Array.from(e.values());
      }, r.Cd = function(t) {
        t = t.getAllBlocks(!1);
        var e = /* @__PURE__ */ new Set();
        for (let o = 0, s; s = t[o]; o++) {
          var i = s.getDeveloperVariables;
          if (i) {
            i = i();
            for (let n = 0; n < i.length; n++) e.add(i[n]);
          }
        }
        return Array.from(e.values());
      }, xn = function(t) {
        return gt.variables_set || gt.variables_get || console.warn("There are no variable blocks, but there is a variable category."), t.registerButtonCallback("CREATE_VARIABLE", function(e) {
          Ro(e.getTargetWorkspace());
        }), [{ kind: "button", text: "%{BKY_NEW_VARIABLE}", callbackkey: "CREATE_VARIABLE" }, ...Mn(t, t.getVariableMap().getVariablesOfType(""), !0)];
      }, Bn = function(t) {
        return { VAR: { name: t.getName(), type: t.getType() } };
      }, Mn = function(t, e, i, o = "variables_get", s = "variables_set") {
        i && (i = gt.math_change), t = [];
        var n = e.slice(-1)[0];
        return n && (gt[s] && t.push({ kind: "block", type: s, gap: i ? 8 : 24, fields: Bn(n) }), i && t.push({ kind: "block", type: "math_change", gap: gt[o] ? 20 : 8, fields: Bn(n), inputs: { DELTA: { shadow: { type: "math_number", fields: { NUM: 1 } } } } })), gt[o] && t.push(...e.sort(Ao).map((l) => ({ kind: "block", type: o, gap: 8, fields: Bn(l) }))), t;
      }, Ul = function(t) {
        return bg.generateUniqueNameInternal(t);
      }, Pn = function(t, e) {
        if (!e.length) return t;
        for (var i = "", o = "ijkmnopqrstuvwxyzabcdefgh".indexOf(t); ; ) {
          let s = !1;
          for (let n = 0; n < e.length; n++) if (e[n].toLowerCase() === t) {
            s = !0;
            break;
          }
          if (!s) break;
          o++, o === 25 && (o = 0, i = `${Number(i) + 1}`), t = "ijkmnopqrstuvwxyzabcdefgh".charAt(o) + i;
        }
        return t;
      }, Ro = function(t, e, i) {
        function o(n) {
          Fn(r.C.NEW_VARIABLE_TITLE, n, function(l) {
            if (l) {
              var a = Wl(l, t);
              if (a) {
                if (a.getType() === s) var c = r.C.VARIABLE_ALREADY_EXISTS.replace("%1", a.getName());
                else c = r.C.VARIABLE_ALREADY_EXISTS_FOR_ANOTHER_TYPE, c = c.replace("%1", a.getName()).replace("%2", a.getType());
                Nn(c, function() {
                  o(l);
                });
              } else {
                let O = t.getVariableMap().createVariable(l, s);
                e && e(l);
                let L = (c = t.getFlyout()) == null ? void 0 : c.getWorkspace();
                if (L && st.getIsActive()) {
                  var E = (x) => {
                    x.type === r.Od && (x = x.blockId) && (x = L.getBlockById(x)) && x.type === "variables_set" && x.getFieldValue("VAR") === O.getId() && (r.t().focusNode(x), L.removeChangeListener(E));
                  };
                  L.addChangeListener(E);
                }
              }
            } else e && e(null);
          });
        }
        var s = i || "";
        o("");
      }, r.Rd = function(t, e, i) {
        function o(s) {
          var n = r.C.RENAME_VARIABLE_TITLE.replace("%1", e.getName());
          Fn(n, s, function(l) {
            if (l) {
              var a = Mu(l, e.getType(), t), c = Gl(e.getName(), l, t);
              if (a || c) {
                var E = "";
                a ? E = r.C.VARIABLE_ALREADY_EXISTS_FOR_ANOTHER_TYPE.replace("%1", a.getName()).replace("%2", a.getType()) : c && (E = r.C.VARIABLE_ALREADY_EXISTS_FOR_A_PARAMETER.replace("%1", l).replace("%2", c)), Nn(E, function() {
                  o(l);
                });
              } else t.getVariableMap().renameVariable(e, l), i && i(l);
            } else i && i(null);
          });
        }
        o("");
      }, Fn = function(t, e, i) {
        On(t, e, function(o) {
          o && (o = o.replace(/[\s\xa0]+/g, " ").trim(), o === r.C.RENAME_VARIABLE || o === r.C.NEW_VARIABLE) && (o = null), i(o);
        });
      }, Mu = function(t, e, i) {
        i = i.getVariableMap().getAllVariables(), t = t.toLowerCase();
        for (let o = 0, s; s = i[o]; o++) if (s.getName().toLowerCase() === t && s.getType() !== e) return s;
        return null;
      }, Wl = function(t, e) {
        e = e.getVariableMap().getAllVariables(), t = t.toLowerCase();
        for (let i = 0, o; o = e[i]; i++) if (o.getName().toLowerCase() === t) return o;
        return null;
      }, Gl = function(t, e, i) {
        return i.getProcedureMap().getProcedures().length ? Pu(t, e, i) : Fu(t, e, i);
      }, Pu = function(t, e, i) {
        t = t.toLowerCase(), e = e.toLowerCase(), i = i.getProcedureMap().getProcedures();
        for (let s of i) {
          var o = s.getParameters().filter(Hl).map((n) => n.getVariableModel().getName());
          if (o && (i = o.some((n) => n.toLowerCase() === t), o = o.some((n) => n.toLowerCase() === e), i && o))
            return s.getName();
        }
        return null;
      }, Fu = function(t, e, i) {
        t = t.toLowerCase(), e = e.toLowerCase(), i = i.getAllBlocks(!1);
        for (let s of i) {
          if (!So(s)) continue;
          i = s.getProcedureDef();
          var o = i[1];
          let n = o.some((l) => l.toLowerCase() === t);
          if (o = o.some((l) => l.toLowerCase() === e), n && o) return i[0];
        }
        return null;
      }, Pi = function(t) {
        var e = r.sc("field");
        return e.setAttribute("name", "VAR"), e.setAttribute("id", t.getId()), e.setAttribute("variabletype", t.getType()), t = r.tc(t.getName()), e.appendChild(t), e;
      }, r.Wd = function(t, e, i, o) {
        var s = r.Vd(t, e, i, o);
        if (!s) {
          s = t.getVariableMap();
          let n = t.getPotentialVariableMap();
          i || (i = Ul(t.isFlyout ? t.targetWorkspace : t)), s = n ? n.createVariable(i, o, e ?? void 0) : s.createVariable(i, o, e);
        }
        return s;
      }, r.Vd = function(t, e, i, o) {
        var s = t.getPotentialVariableMap(), n = null;
        if (e && (n = t.getVariableMap().getVariableById(e), !n && s && (n = s.getVariableById(e)), n)) return n;
        if (i) {
          if (o === void 0) throw Error("Tried to look up a variable by name without a type");
          n = t.getVariableMap().getVariable(i, o), !n && s && (n = s.getVariable(i, o));
        }
        return n;
      }, Hn = function(t, e) {
        t = t.getVariableMap().getAllVariables();
        var i = [];
        if (e.length !== t.length) for (let o = 0; o < t.length; o++) {
          let s = t[o];
          e.includes(s) || i.push(s);
        }
        return i;
      }, Ao = function(t, e) {
        return mf.compare(t.getName(), e.getName());
      }, Un = function(t, e) {
        var i = [];
        t = t.getAllBlocks(!1);
        for (let o = 0; o < t.length; o++) {
          let s = t[o].getVarModels();
          if (s) for (let n = 0; n < s.length; n++) s[n].getId() === e && i.push(t[o]);
        }
        return i;
      }, r.$d = function(t, e, i) {
        var o = e.getName(), s = Un(t, e.getId());
        for (let n = s.length - 1; n >= 0; n--) {
          let l = s[n];
          if (l.type === "procedures_defnoreturn" || l.type === "procedures_defreturn") {
            i = String(l.getFieldValue("NAME")), o = r.C.CANNOT_DELETE_VARIABLE_PROCEDURE.replace("%1", o).replace("%2", i), Rc(o, void 0);
            return;
          }
          l === i && s.splice(n, 1);
        }
        i && s.length || s.length > 1 ? (o = r.C.DELETE_VARIABLE_CONFIRMATION.replace("%1", String(s.length + (i && !i.workspace.isFlyout ? 1 : 0))).replace("%2", o), Dn(o, (n) => {
          n && e && t.getVariableMap().deleteVariable(e);
        })) : t.getVariableMap().deleteVariable(e);
      }, ee = function(t, { addCoordinates: e = !1, addInputBlocks: i = !0, addNextBlocks: o = !0, doFullSerialization: s = !0, saveIds: n = !0 } = {}) {
        if (t.isInsertionMarker()) return null;
        var l = { type: t.type, id: n ? t.id : void 0 };
        if (e) {
          e = t.workspace;
          var a = t.getRelativeToSurfaceXY();
          l.x = Math.round(e.RTL ? e.getWidth() - a.x : a.x), l.y = Math.round(a.y);
        }
        t.isCollapsed() && (l.collapsed = !0), t.isEnabled() || (l.disabledReasons = Array.from(t.getDisabledReasons())), t.isOwnDeletable() || (l.deletable = !1), t.isOwnMovable() || (l.movable = !1), t.isOwnEditable() || (l.editable = !1), t.inputsInline !== void 0 && t.inputsInline !== t.inputsInlineDefault && (l.inline = t.inputsInline), t.data && (l.data = t.data), t.saveExtraState ? (e = t.saveExtraState(s), e !== null && (l.extraState = e)) : t.mutationToDom && (e = t.mutationToDom(), e !== null && (l.extraState = xo(e).replace(' xmlns="https://developers.google.com/blockly/xml"', ""))), e = /* @__PURE__ */ Object.create(null);
        for (var c of t.getIcons()) ys(c) && (a = c.saveState(s)) && (e[c.getType().toString()] = a);
        Object.keys(e).length && (l.icons = e), c = /* @__PURE__ */ Object.create(null);
        for (var E of t.getFields()) E.isSerializable() && (c[E.name] = E.saveState(s));
        if (Object.keys(c).length && (l.fields = c), i) {
          for (i = /* @__PURE__ */ Object.create(null), E = 0; E < t.inputList.length; E++)
            c = t.inputList[E], c.connection && (e = Vl(c.connection, s, n)) && (i[c.name] = e);
          Object.keys(i).length && (l.inputs = i);
        }
        return o && t.nextConnection && (t = Vl(t.nextConnection, s, n)) && (l.next = t), l;
      }, Vl = function(t, e, i) {
        var o = t.getShadowState(!0);
        if (t = t.targetBlock(), !o && !t) return null;
        var s = /* @__PURE__ */ Object.create(null);
        return o && (s.shadow = o), t && !t.isShadow() && (s.block = ee(t, { doFullSerialization: e, saveIds: i })), s;
      }, Fi = function(t, e, { recordUndo: i = !1 } = {}) {
        return t = fi(t, e, { recordUndo: i }), e.rendered && Ne(), t;
      }, fi = function(t, e, { parentConnection: i, isShadow: o = !1, recordUndo: s = !1 } = {}) {
        var n = r.Qc;
        r.Qc = s, (s = r.gd) || r.B(!0), r.Ub++;
        var l = e.getVariableMap().getAllVariables();
        try {
          var a = zl(t, e, { parentConnection: i, isShadow: o });
        } finally {
          r.Ub--;
        }
        if (Hu(e, l), ht() && N(new (D(p.BLOCK_CREATE))(a)), r.B(s), r.Qc = n, e.rendered) {
          let c = a;
          setTimeout(() => {
            c.disposed || c.setConnectionTracking(!0);
          }, 1);
        }
        return a;
      }, zl = function(t, e, { parentConnection: i, isShadow: o = !1 } = {}) {
        if (!t.type) throw new kg(t);
        var s = e.newBlock(t.type, t.id);
        s.setShadow(o), o = t.x === void 0 ? 0 : t.x;
        var n = t.y === void 0 ? 0 : t.y, l = s.workspace;
        if (o = l.RTL ? l.getWidth() - o : o, s.moveBy(o, n), t.collapsed && s.setCollapsed(!0), t.deletable === !1 && s.setDeletable(!1), t.movable === !1 && s.setMovable(!1), t.editable === !1 && s.setEditable(!1), t.enabled === !1 && s.setDisabledReason(!0, "MANUALLY_DISABLED"), Array.isArray(t.disabledReasons)) for (var a of t.disabledReasons) s.setDisabledReason(
          !0,
          a
        );
        if (t.inline !== void 0 && s.setInputsInline(t.inline), t.data !== void 0 && (s.data = t.data), t.extraState && (s.loadExtraState ? s.loadExtraState(t.extraState) : s.domToMutation && s.domToMutation(r.vc(t.extraState))), i) {
          if (i.getSourceBlock().isShadow() && !s.isShadow()) throw new Ig(t);
          if (i.type === r.je.VALUE) {
            if (a = s.outputConnection, !a) throw new zs("output", s, t);
          } else if (a = s.previousConnection, !a) throw new zs("previous", s, t);
          if (!i.connect(a)) throw e = s.workspace.connectionChecker, new wg(e.getErrorMessage(e.canConnectWithReason(
            a,
            i,
            !1
          ), a, i), i.type === r.je.VALUE ? "output connection" : "previous connection", s, t);
        }
        if (t.icons) {
          i = Object.keys(t.icons);
          for (var c of i) {
            if (i = t.icons[c], a = s.getIcon(c), !a) {
              if (a = Mt(_.ICON, c, !1), !a) throw new Sg(c, s, t);
              a = new a(s), s.addIcon(a);
            }
            ys(a) && a.loadState(i);
          }
        }
        if (t.fields) for (c = Object.keys(t.fields), i = 0; i < c.length; i++) a = c[i], o = t.fields[a], (n = s.getField(a)) ? n.loadState(o) : console.warn(`Ignoring non-existant field ${a} in block ${s.type}`);
        if (t.inputs) for (c = Object.keys(t.inputs), i = 0; i < c.length; i++) {
          if (a = c[i], o = s.getInput(a), !o || !o.connection) throw new zs(a, s, t);
          Kl(o.connection, t.inputs[a]);
        }
        if (t.next) {
          if (!s.nextConnection) throw new zs("next", s, t);
          Kl(s.nextConnection, t.next);
        }
        if (e.rendered) {
          s.setConnectionTracking(!1), s.initSvg(), s.queueRender();
          for (let E of s.getIcons()) E.onLocationChange(s.getRelativeToSurfaceXY());
        } else s.initModel();
        return s;
      }, Hu = function(t, e) {
        if (ht()) for (t = Hn(t, e), e = 0; e < t.length; e++) {
          let i = t[e];
          N(new (D(p.VAR_CREATE))(i));
        }
      }, Kl = function(t, e) {
        e.shadow && t.setShadowState(e.shadow), e.block && zl(e.block, t.getSourceBlock().workspace, { parentConnection: t });
      }, $e = function(t) {
        return t = Uu(t, Tf), t.length ? t[0].join(Ho ? " " : " + ") : "";
      }, Uu = function(t, e) {
        if (t = S.registry.getKeyCodesByShortcutName(t), t.length === 0) return [];
        t = t.map((o) => o.split("+")), t.forEach((o) => o.sort((s, n) => (s = Xl(s), n = Xl(n), s - n))), t.sort((o, s) => (o = o.includes("Meta") ? 1 : 0, (s.includes("Meta") ? 1 : 0) - o));
        var i = t.filter((o) => o.includes("Meta") === Ho);
        return i = i.length === 0 ? t : i, i.sort((o, s) => o.length - s.length), (i.some((o) => o.some((s) => s === "Meta" || s === "Alt" || s === "Control")) ? [i[0]] : i).map((o) => o.map((s) => {
          if (Number.isFinite(+s)) if (s = +s, s >= 65 && s <= 90) s = String.fromCharCode(s);
          else {
            var n = {
              8: r.C.BACKSPACE_KEY,
              9: r.C.TAB_KEY,
              13: r.C.ENTER_KEY,
              16: r.C.SHIFT_KEY,
              17: r.C.CONTROL_KEY,
              18: r.C.ALT_KEY,
              19: r.C.PAUSE_KEY,
              20: r.C.CAPS_LOCK_KEY,
              27: r.C.ESCAPE,
              32: r.C.SPACE_KEY,
              33: r.C.PAGE_UP_KEY,
              34: r.C.PAGE_DOWN_KEY,
              35: r.C.END_KEY,
              36: r.C.HOME_KEY,
              37: "←",
              38: "↑",
              39: "→",
              40: "↓",
              45: r.C.INSERT_KEY,
              46: r.C.DELETE_KEY,
              48: "0",
              49: "1",
              50: "2",
              51: "3",
              52: "4",
              53: "5",
              54: "6",
              55: "7",
              56: "8",
              57: "9",
              59: ";",
              61: "=",
              93: r.C.CONTEXT_MENU_KEY,
              96: "0",
              97: "1",
              98: "2",
              99: "3",
              100: "4",
              101: "5",
              102: "6",
              103: "7",
              104: "8",
              105: "9",
              106: "×",
              107: "+",
              109: "−",
              110: ".",
              111: "÷",
              112: "F1",
              113: "F2",
              114: "F3",
              115: "F4",
              116: "F5",
              117: "F6",
              118: "F7",
              119: "F8",
              120: "F9",
              121: "F10",
              122: "F11",
              123: "F12",
              186: ";",
              187: "=",
              189: "-",
              188: ",",
              190: ".",
              191: "/",
              192: "`",
              219: "[",
              220: "\\",
              221: "]",
              222: "'",
              224: "⌘"
            }[s];
            n ? s = n : (console.warn("Unknown key code: " + s), s = String.fromCharCode(s));
          }
          return s;
        }).map((s) => {
          var n, l = (n = e[s]) != null ? n : s;
          return l.charAt(0).toUpperCase() + l.substring(1);
        }));
      }, Xl = function(t) {
        return t = Cf.indexOf(t), t === -1 ? Number.MAX_VALUE : t;
      }, Yl = function(t) {
        return t && typeof t.init == "function" && typeof t.getDiv == "function" && typeof t.getId == "function" && typeof t.getParent == "function" && typeof t.getLevel == "function" && typeof t.isSelectable == "function" && typeof t.isCollapsible == "function" && typeof t.dispose == "function" && typeof t.getClickTarget == "function" && typeof t.setVisible_ == "function" && typeof t.getParentToolbox == "function";
      }, Hi = function(t) {
        return typeof t.getName == "function" && typeof t.getContents == "function" && typeof t.setSelected == "function" && typeof t.onClick == "function" && Yl(t) && t.isSelectable();
      }, Je = function(t, e = ot.STANDARD, i) {
        return [e >= ot.STANDARD && $l(t), Wu(t), ...Jl(t, e, i), e === ot.LOQUACIOUS && zu(t), e >= ot.STANDARD && (t.isEnabled() ? void 0 : r.C.BLOCK_LABEL_DISABLED), e >= ot.STANDARD && (t.isCollapsed() ? r.C.BLOCK_LABEL_COLLAPSED : void 0), e >= ot.LOQUACIOUS && (t.isShadow() ? r.C.BLOCK_LABEL_REPLACEABLE : void 0), e >= ot.STANDARD && ju(t), e >= ot.LOQUACIOUS && t.getAriaRoleDescription()].filter((o) => !!o).join(", ");
      }, jl = function(t, e, i = ot.STANDARD) {
        var o = i >= ot.LOQUACIOUS, s = [], n = t.fieldRow.filter((a) => a.isVisible()).flatMap((a, c, E) => {
          if (a.isLabelField()) {
            if (c < E.length - 1 && E[c + 1].isLabelField()) return s.push(a.computeAriaLabel(o)), [];
            if (s.length >= 1) return s.push(a.computeAriaLabel(o)), a = s.join(" "), s = [], a;
          }
          return a.computeAriaLabel(o);
        });
        if (!n.length && e) {
          let a = t.getSourceBlock().inputList, c = a.indexOf(t);
          if (c > 0) return jl(a[c - 1], e, i);
        }
        var l;
        return t.type === r.je.VALUE && ((l = t.connection) == null ? void 0 : l.targetConnection) === null && i >= ot.STANDARD && n.push(r.C.INPUT_LABEL_EMPTY), n.filter((a) => !!a);
      }, Wu = function(t) {
        var e, i, o, s = (e = (o = t.outputConnection) != null ? o : t.previousConnection) == null || (i = e.targetConnection) == null ? void 0 : i.getParentInput();
        if (s && (t = s.getSourceBlock(), !t.isInsertionMarker())) {
          if (e = s.getAriaLabelText()) t = e;
          else {
            if (!t.statementInputCount || (e = t.inputList.find((n) => n.type === r.je.STATEMENT), s === e) || (t = Wn(t, s, !1), !t.length)) return;
            t = t.join(", ");
          }
          return s.type === r.je.STATEMENT ? (s = Array.isArray(t) ? t.join(" ") : t, r.C.BLOCK_LABEL_BEGIN_PREFIX.replace("%1", s)) : t;
        }
      }, $l = function(t) {
        if (!t.isInFlyout && !t.isDragging()) return t.getRootBlock() === t ? r.C.BLOCK_LABEL_BEGIN_STACK : void 0;
      }, Jl = function(t, e = ot.STANDARD, i) {
        if (i) return [i];
        if (i = t = t.inputList.filter((s) => s.isVisible()), e <= ot.STANDARD) {
          let s = t.filter((n) => n.type === r.je.STATEMENT);
          s.length > 1 && (i = t.slice(0, t.indexOf(s[0]) + 1));
        }
        var o = [];
        return i.flatMap((s, n, l) => {
          var a = s.getLabel(e), c;
          if (c = n < l.length - 1 && Gu(s) && ql(l[n + 1])) {
            c = l[n + 1];
            let E;
            n = ((E = s.connection) == null ? void 0 : E.type) === T.NEXT_STATEMENT || s.type === r.je.END_ROW;
            let O;
            c = !(!s.getSourceBlock().getInputsInline() || ((O = c.connection) == null ? void 0 : O.type) === T.NEXT_STATEMENT || n);
          }
          return c ? (o.push(a), []) : ql(s) && o.length > 0 ? (o.push(a), s = o.join(" "), o = [], s) : a;
        });
      }, ql = function(t) {
        return t = t.fieldRow.filter((e) => e.isVisible()), t.length > 0 && t[0].isLabelField();
      }, Gu = function(t) {
        return t.type === r.je.VALUE || t.type === r.je.STATEMENT ? !1 : (t = t.fieldRow.filter((e) => e.isVisible()), t.length > 0 && t[t.length - 1].isLabelField());
      }, Wn = function(t, e, i) {
        var o = t.inputList.indexOf(e);
        if (o === -1) throw Error(`Input with name "${e.name}" not found on block with id "${t.id}".`);
        var s = e.type === r.je.STATEMENT, n = s ? Vu(t.inputList, o) : o, l = t.inputList.slice(n, o + 1).filter((E) => E.isVisible()), a = l.map((E) => E.getLabel(ot.TERSE, E !== e || i)), c = s && a.slice(0, -1).some((E) => !!E);
        return a.map((E, O) => {
          if (E) return E;
          if (E = l[O], !(E.type === r.je.DUMMY || E.type === r.je.END_ROW || s && O === a.length - 1 && c)) return r.C.INPUT_LABEL_INDEX.replace("%1", (E.getIndex() + 1).toString());
        }).filter((E) => E !== void 0);
      }, Vu = function(t, e) {
        for (--e; e >= 0; e--) if (t[e].type === r.je.STATEMENT) return e + 1;
        return 0;
      }, zu = function(t) {
        var e = t.workspace.getToolbox();
        if (e) {
          var i = void 0;
          for (let o of e.getToolboxItems())
            if (Hi(o)) {
              if (e = o.getContents(), Array.isArray(e) && e.some((s) => s.kind.toLowerCase() === "block" && "type" in s && s.type === t.type)) {
                i = o;
                break;
              }
              "getColour" in o && typeof o.getColour == "function" && o.getColour() === t.getColour() && (i = o);
            }
          if (i) return r.C.BLOCK_LABEL_TOOLBOX_CATEGORY.replace("%1", i.getName());
        }
      }, Ku = function(t) {
        switch (t) {
          case Jt.BEFORE:
            return r.C.ANNOUNCE_MOVE_BEFORE;
          case Jt.AFTER:
            return r.C.ANNOUNCE_MOVE_AFTER;
          case Jt.INSIDE:
            return r.C.ANNOUNCE_MOVE_INSIDE;
          case Jt.AROUND:
            return r.C.ANNOUNCE_MOVE_AROUND;
          default:
            return r.C.ANNOUNCE_MOVE_TO;
        }
      }, Zl = function(t, e) {
        var i = t.getParentInput();
        if (!i) return e;
        var o = i.getAriaLabelText();
        if (!o) {
          if (t = Wn(t.getSourceBlock(), i, !0), !t.length) return e;
          o = t.join(", ");
        }
        return e ? r.C.ANNOUNCE_MOVE_OF.replace("%1", o).replace("%2", e) : o;
      }, Xu = function(t, e, i, o = !1) {
        var s = Yu(t, e), n = Ku(s), l = ![Jt.BEFORE, Jt.AFTER].includes(s);
        return s = l && i(!0), i = l && i(!1), o = o ? t.getSourceBlock().getStackBlocksCountLabel() : "", l = e.getSourceBlock().getAriaLabel(ot.TERSE), s && (o = Zl(t, o)), i && (l = Zl(e, l)), n.replace("%1", o).replace("%2", l);
      }, Yu = function(t, e) {
        switch (t.type) {
          case T.INPUT_VALUE:
          case T.OUTPUT_VALUE:
            return Jt.TO;
          case T.NEXT_STATEMENT:
            return t === t.getSourceBlock().nextConnection ? Jt.BEFORE : Jt.AROUND;
          case T.PREVIOUS_STATEMENT:
            return e === e.getSourceBlock().nextConnection ? Jt.AFTER : Jt.INSIDE;
        }
        return Jt.UNKNOWN;
      }, ju = function(t) {
        var e = t.inputList.filter((i) => i.type === r.je.STATEMENT).length;
        if (e > 1) return r.C.BLOCK_LABEL_HAS_BRANCHES.replace("%1", e.toString());
        switch (t.inputList.reduce((i, o) => {
          var s;
          return o.fieldRow.reduce((n, l) => l.EDITABLE && !l.isFullBlockField() ? ++n : n, i) + (((s = o.connection) == null ? void 0 : s.type) === T.INPUT_VALUE ? 1 : 0);
        }, 0)) {
          case 0:
            break;
          case 1:
            return r.C.BLOCK_LABEL_HAS_INPUT;
          default:
            return r.C.BLOCK_LABEL_HAS_INPUTS;
        }
      }, Gn = function(t) {
        return t * Math.PI / 180;
      }, No = function(t, e, i) {
        if (i < t) {
          let o = i;
          i = t, t = o;
        }
        return Math.max(t, Math.min(e, i));
      }, Vn = function() {
        document.querySelector(".blocklyDropDownDiv") || (tt = document.createElement("div"), tt.className = "blocklyDropDownDiv", tt.tabIndex = -1, tt.id = It(), (ui() || document.body).appendChild(tt), eo = document.createElement("div"), eo.className = "blocklyDropDownContent", tt.appendChild(eo), Ar = M(eo, "keydown", null, (t) => {
          vs(t), t.stopPropagation();
        }), io = document.createElement("div"), io.className = "blocklyDropDownArrow", tt.appendChild(io), tt.style.opacity = "0", tt.style.transition = "transform 0.25s, opacity 0.25s");
      }, Ql = function() {
        oo && (oo(!1), oo = null), ks();
      }, zn = function() {
        Ar && ($(Ar), Ar = null), tt.remove(), Vn();
      }, ta = function(t, e) {
        tt.style.backgroundColor = t, tt.style.borderColor = e;
      }, ea = function(t, e, i, o = !0) {
        return Dg = !0, sa(oa(t), t, o, e, i);
      }, ia = function(t) {
        var e = t.getSvgRoot(), i = t.workspace.scale, o = t.height * i;
        return t = t.width * i, e = di(e), new F(e.y, e.y + o, e.x, e.x + t);
      }, oa = function(t) {
        return t = t.getScaledBBox(), new F(t.top, t.bottom, t.left, t.right);
      }, sa = function(t, e, i, o, s) {
        var n = t.left + (t.right - t.left) / 2, l = t.bottom;
        t = t.top, s && (t += s), s = e.getSourceBlock();
        for (var a = s.workspace; a.options.parentWorkspace; ) a = a.options.parentWorkspace;
        return Rr = a.getParentSvg().parentNode, na(e, s.RTL, n, l, n, t, i, o);
      }, na = function(t, e, i, o, s, n, l, a) {
        r.t().registerPopoverFocusLossHandler(Ql);
        var c;
        return (c = ui()) == null || c.appendChild(tt), mt = t, to = a || null, tt.style.direction = e ? "rtl" : "ltr", t = de, Ag = t.getRenderer().getClassName(), Ng = t.getTheme().getClassName(), b(tt, Ag), b(tt, Ng), e = yo(t.getFocusableElement(), y.OWNS), w(t.getFocusableElement(), y.OWNS, e ? [e, tt.id] : tt.id), t.getFocusableElement().classList.add("blocklyShowingDropDownDiv"), i = aa(i, o, s, n), l && (oo = r.t().takeEphemeralFocus(tt)), i;
      }, ra = function(t, e, i, o) {
        return t = bs(t, i.left, i.right, o.width), { initialX: t.divX, initialY: e, finalX: t.divX, finalY: e + 16, arrowX: t.arrowX, arrowY: -9, arrowAtTop: !0, arrowVisible: !0 };
      }, la = function(t, e, i, o) {
        return t = bs(t, i.left, i.right, o.width), { initialX: t.divX, initialY: e - o.height, finalX: t.divX, finalY: e - o.height - 16, arrowX: t.arrowX, arrowY: o.height - 2 - 8, arrowAtTop: !1, arrowVisible: !0 };
      }, bs = function(t, e, i, o) {
        return e = No(e, t - o / 2, i - o), t = t - 8 - e, t = No(12, t, o - 12 - 16), { arrowX: t, divX: e };
      }, Kn = function(t, e) {
        return mt === t ? (e ? Oe() : ks(), !0) : !1;
      }, ks = function() {
        mt && (r.t().unregisterPopoverFocusLossHandler(Ql), tt.style.transform = "translate(0, 0)", tt.style.opacity = "0", iu = setTimeout(function() {
          Oe();
        }, 250), to && (to(), to = null));
      }, Oe = function() {
        if (mt) {
          iu && clearTimeout(iu), to && (to(), to = null), mt = null;
          var t = de, e, i = (e = yo(t.getFocusableElement(), y.OWNS)) != null ? e : "";
          w(t.getFocusableElement(), y.OWNS, i.replace(tt.id, "")), t.getFocusableElement().classList.remove("blocklyShowingDropDownDiv"), t.markFocused(), oo && (oo(), oo = null), zn();
        }
      }, aa = function(t, e, i, o) {
        t = ou.getPositionMetrics(t, e, i, o), t.arrowVisible ? (e = t.arrowX, i = t.arrowY, o = t.arrowAtTop ? 45 : 225, io.style.display = "", io.style.transform = `translate(${e}px, ${i}px) rotate(${o}deg)`, io.setAttribute("class", "blocklyDropDownArrow")) : io.style.display = "none", e = Math.floor(t.initialX), i = Math.floor(t.initialY), o = Math.floor(t.finalX);
        var s = Math.floor(t.finalY), n = tt.parentElement;
        return n && ({ x: e, y: i } = ko(e, i, n), { x: o, y: s } = ko(o, s, n)), tt.style.left = e + "px", tt.style.top = i + "px", tt.style.visibility = "visible", tt.style.opacity = "1", tt.style.transform = "translate(" + (o - e) + "px," + (s - i) + "px)", !!t.arrowAtTop;
      }, ha = function() {
        if (mt) {
          var t = mt.getSourceBlock();
          t = Dg ? oa(mt) : ia(t);
          let e = t.left + (t.right - t.left) / 2;
          aa(e, t.bottom, e, t.top);
        } else ks();
      }, ws = function(t) {
        return t.length ? t.reduce(function(e, i) {
          return e.length < i.length ? e : i;
        }).length : 0;
      }, ca = function(t, e) {
        if (!t.length) return 0;
        if (t.length === 1) return t[0].length;
        var i = 0;
        e = e || ws(t);
        var o;
        for (o = 0; o < e; o++) {
          for (var s = t[0][o], n = 1; n < t.length; n++) if (s !== t[n][o]) return i;
          s === " " && (i = o + 1);
        }
        for (s = 1; s < t.length; s++) if ((n = t[s][o]) && n !== " ") return i;
        return e;
      }, ua = function(t, e) {
        if (!t.length) return 0;
        if (t.length === 1) return t[0].length;
        var i = 0;
        e = e || ws(t);
        var o;
        for (o = 0; o < e; o++) {
          for (var s = t[0].substr(-o - 1, 1), n = 1; n < t.length; n++) if (s !== t[n].substr(-o - 1, 1)) return i;
          s === " " && (i = o + 1);
        }
        for (s = 1; s < t.length; s++) if ((n = t[s].charAt(t[s].length - o - 1)) && n !== " ") return i;
        return e;
      }, r.yf = function(t, e) {
        t = t.split(`
`);
        for (let E = 0; E < t.length; E++) {
          var i = E;
          t: {
            var o = void 0;
            let O;
            var s = t[E], n = e;
            if (s.length <= n) {
              n = s;
              break t;
            }
            let L = s.trim().split(/\s+/);
            for (o = 0; o < L.length; o++) L[o].length > n && (n = L[o].length);
            var l = -1 / 0;
            let x = 1;
            do {
              O = l, o = s;
              var a = [];
              l = L.length / x, s = 1;
              for (var c = 0; c < L.length - 1; c++) s < (c + 1.5) / l ? (s++, a[c] = !0) : a[c] = !1;
              a = da(L, a, n), l = Xn(L, a, n), s = L, c = [];
              for (let z = 0; z < s.length; z++) c.push(s[z]), a[z] !== void 0 && c.push(a[z] ? `
` : " ");
              s = c.join(""), x++;
            } while (l > O);
            n = o;
          }
          t[i] = n;
        }
        return t.join(`
`);
      }, Xn = function(t, e, i) {
        for (var o = [0], s = [], n = 0; n < t.length; n++) o[o.length - 1] += t[n].length, e[n] === !0 ? (o.push(0), s.push(t[n].charAt(t[n].length - 1))) : e[n] === !1 && o[o.length - 1]++;
        for (t = Math.max(...o), e = 0, n = 0; n < o.length; n++) e -= Math.pow(Math.abs(i - o[n]), 1.5) * 2, e -= Math.pow(t - o[n], 1.5), ".?!".includes(s[n]) ? e += i / 3 : ",;)]}".includes(s[n]) && (e += i / 4);
        return o.length > 1 && o[o.length - 1] <= o[o.length - 2] && (e += 0.5), e;
      }, da = function(t, e, i) {
        var o = Xn(t, e, i);
        for (let n = 0; n < e.length - 1; n++) {
          if (e[n] === e[n + 1]) continue;
          let l = [].concat(e);
          l[n] = !l[n], l[n + 1] = !l[n + 1];
          let a = Xn(t, l, i);
          if (a > o) {
            o = a;
            var s = l;
          }
        }
        return s ? da(t, s, i) : e;
      }, r.zf = function(t) {
        return /^\s*-?\d+(\.\d+)?\s*$/.test(t);
      }, Do = function(t) {
        if (t = ga(t)) {
          for (t = t.tooltip; typeof t == "function"; ) t = t();
          if (typeof t != "string") throw Error("Tooltip function must return a string.");
          return t;
        }
        return "";
      }, ga = function(t) {
        for (; t && t.tooltip; ) {
          if (typeof t.tooltip == "string" || typeof t.tooltip == "function") return t;
          t = t.tooltip;
        }
        return null;
      }, pa = function() {
        document.querySelector(".blocklyTooltipDiv") || (ft = document.createElement("div"), ft.className = "blocklyTooltipDiv", (ui() || document.body).appendChild(ft));
      }, Is = function(t) {
        t.mouseOverWrapper_ = jt(t, "pointerover", null, $u), t.mouseOutWrapper_ = jt(t, "pointerout", null, Ju), t.addEventListener("pointermove", fa, !1);
      }, Ss = function(t) {
        t && ($(t.mouseOverWrapper_), $(t.mouseOutWrapper_), t.removeEventListener("pointermove", fa));
      }, $u = function(t) {
        ki || (t = ga(t.currentTarget), xt !== t && (Le(), jo = null, xt = t), clearTimeout(Og));
      }, Ju = function() {
        ki || (Og = setTimeout(function() {
          jo = xt = null, Le();
        }, 1), clearTimeout(so), so = 0);
      }, fa = function(t) {
        if (xt && xt.tooltip && !ki) if (Xs) {
          let e = Dr - t.pageX;
          t = Or - t.pageY, Math.sqrt(e * e + t * t) > 10 && Le();
        } else jo !== xt && (clearTimeout(so), Dr = t.pageX, Or = t.pageY, so = setTimeout(() => {
          if (this instanceof Element) for (let i of hi()) {
            if (!i.rendered) continue;
            let o;
            if ((o = i.getInjectionDiv()) != null && o.contains(this)) {
              var e = i;
              break;
            }
          }
          ma(e);
        }, 750));
      }, Ea = function() {
        jo = xt = null, Le();
      }, Le = function() {
        Xs && (Xs = !1, ft && (ft.style.display = "none")), so && (clearTimeout(so), so = 0);
      }, va = function(t, e) {
        xt !== t && (Le(), jo = null, xt = t), xt && xt.tooltip && !ki && (t = t.getFocusableElement().getBoundingClientRect(), Dr = xt.RTL ? t.x + t.width : t.x, Or = t.y + t.height, ma(e));
      }, _a = function() {
        Le(), ki = !0;
      }, ma = function(t) {
        if (!ki && (jo = xt, ft)) {
          var e;
          if ((e = ui(t)) == null || e.appendChild(ft), ft.textContent = "", ft && xt) if (typeof Nr == "function") Nr(ft, xt);
          else for (t = Do(xt), t = r.yf(t, 50), t = t.split(`
`), e = 0; e < t.length; e++) {
            var i = document.createElement("div");
            i.appendChild(document.createTextNode(t[e])), ft.appendChild(i);
          }
          t = xt.RTL, ft.style.direction = t ? "rtl" : "ltr", ft.style.display = "block", Xs = !0, e = document.documentElement.clientWidth, i = document.documentElement.clientHeight;
          var o = Dr;
          o = t ? o - (0 + ft.offsetWidth) : o + 0;
          var s = Or + 10, n, l = (n = ft) == null ? void 0 : n.parentElement;
          l && (n = l.getBoundingClientRect(), o -= n.left + window.scrollX, s -= n.top + window.scrollY), s + ft.offsetHeight > i + window.scrollY && (s -= ft.offsetHeight + 20), t ? o = Math.max(5 - window.scrollX, o) : o + ft.offsetWidth > e + window.scrollX - 10 && (o = e - ft.offsetWidth - 10);
          var { x: a, y: c } = { x: o, y: s };
          ft.style.left = a + "px", ft.style.top = c + "px";
        }
      }, Ui = function(t) {
        t = `${t}`.toLowerCase().trim();
        var e = Lg[t];
        if (e || (e = t.substring(0, 2) === "0x" ? "#" + t.substring(2) : t, e = e[0] === "#" ? e : "#" + e, /^#[0-9a-f]{6}$/.test(e))) return e;
        if (/^#[0-9a-f]{3}$/.test(e)) return ["#", e[1], e[1], e[2], e[2], e[3], e[3]].join("");
        var i = t.match(/^(?:rgb)?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/);
        return i && (t = Number(i[1]), e = Number(i[2]), i = Number(i[3]), t >= 0 && t < 256 && e >= 0 && e < 256 && i >= 0 && i < 256) ? Rs(t, e, i) : null;
      }, Rs = function(t, e, i) {
        return e = t << 16 | e << 8 | i, t < 16 ? "#" + (16777216 | e).toString(16).substr(1) : "#" + e.toString(16);
      }, Yn = function(t) {
        return t = Ui(t), t ? (t = parseInt(t.substr(1), 16), [t >> 16, t >> 8 & 255, t & 255]) : [0, 0, 0];
      }, jn = function(t, e, i) {
        var o = 0, s = 0, n = 0;
        if (e === 0) n = s = o = i;
        else {
          let l = Math.floor(t / 60), a = t / 60 - l;
          t = i * (1 - e);
          let c = i * (1 - e * a);
          switch (e = i * (1 - e * (1 - a)), l) {
            case 1:
              o = c, s = i, n = t;
              break;
            case 2:
              o = t, s = i, n = e;
              break;
            case 3:
              o = t, s = c, n = i;
              break;
            case 4:
              o = e, s = t, n = i;
              break;
            case 5:
              o = i, s = t, n = c;
              break;
            case 6:
            case 0:
              o = i, s = e, n = t;
          }
        }
        return Rs(Math.floor(o), Math.floor(s), Math.floor(n));
      }, Wi = function(t, e, i) {
        return t = Ui(t), !t || (e = Ui(e), !e) ? null : (t = Yn(t), e = Yn(e), Rs(Math.round(e[0] + i * (t[0] - e[0])), Math.round(e[1] + i * (t[1] - e[1])), Math.round(e[2] + i * (t[2] - e[2]))));
      }, Ta = function(t) {
        return jn(t, Lr, xr * 255);
      }, $n = function(t, e, i) {
        var o = [], s = t.split("");
        s.push("");
        var n = 0;
        t = [];
        var l = null;
        for (let E = 0; E < s.length; E++) {
          var a = s[E];
          if (n === 0) if (a === "%") (n = t.join("")) && o.push(n), t.length = 0, n = 1;
          else if (i && a === `
`) {
            let O = t.join("");
            O && o.push(O), t.length = 0, o.push(a);
          } else t.push(a);
          else if (n === 1) a === "%" ? (t.push(a), n = 0) : e && "0" <= a && a <= "9" ? (n = 2, l = a, (a = t.join("")) && o.push(a), t.length = 0) : a === "{" ? n = 3 : (t.push("%", a), n = 0);
          else if (n === 2) if ("0" <= a && a <= "9") l += a;
          else {
            var c = void 0;
            o.push(parseInt((c = l) != null ? c : "", 10)), E--, n = 0;
          }
          else n === 3 && (a === "" ? (t.splice(0, 0, "%{"), E--, n = 0) : a !== "}" ? t.push(a) : (n = t.join(""), /[A-Z]\w*/i.test(n) ? (a = n.toUpperCase(), (a = a.startsWith("BKY_") ? a.substring(4) : null) && a in r.C ? (n = r.C[a], typeof n == "string" ? Array.prototype.push.apply(o, $n(n, e, i)) : e ? o.push(`${n}`) : o.push(n)) : o.push("%{" + n + "}")) : o.push("%{" + n + "}"), n = t.length = 0));
        }
        for ((e = t.join("")) && o.push(e), c = [], t.length = 0, s = 0; s < o.length; s++) typeof o[s] != "string" || i && o[s] === `
` ? ((e = t.join("")) && c.push(e), t.length = 0, c.push(o[s])) : t.push(o[s]);
        return (e = t.join("")) && c.push(e), t.length = 0, c;
      }, Ca = function(t) {
        return $n(t, !0, !0);
      }, et = function(t) {
        return typeof t != "string" ? t : (t = $n(t, !1, !1), t.length ? String(t[0]) : "");
      }, Oo = function(t) {
        var e = typeof t == "string" ? et(t) : t, i = Number(e);
        if (!isNaN(i) && 0 <= i && i <= 360) return { hue: i, hex: jn(i, Lr, xr * 255) };
        if (i = Ui(e)) return { hue: null, hex: i };
        throw i = 'Invalid colour: "' + e + '"', t !== e && (i += ' (from "' + t + '")'), Error(i);
      }, ya = function() {
        no && (no(!1), no = null), Gi();
      }, ba = function() {
        var t = ui() || document.body, e = document.querySelector("div.blocklyWidgetDiv");
        e ? vt = e : (vt = document.createElement("div"), vt.id = It(), vt.className = "blocklyWidgetDiv", vt.tabIndex = -1), M(vt, "keydown", null, (i) => {
          vs(i), i.stopPropagation();
        }), t.appendChild(vt);
      }, Jn = function(t, e, i, o, s = !0) {
        if (Gi(), Bt = t, Mr = i, i = vt) {
          Ee = o ?? de;
          var n = yo(Ee.getFocusableElement(), y.OWNS);
          w(Ee.getFocusableElement(), y.OWNS, n ? [n, i.id] : i.id), Ee.getFocusableElement().classList.add("blocklyShowingWidgetDiv");
          var l;
          (l = ui()) == null || l.appendChild(i), i.style.direction = e ? "rtl" : "ltr", i.style.display = "block", !o && t instanceof Z && t.getSourceBlock(), $o = Ee.getRenderer().getClassName(), Jo = Ee.getTheme().getClassName(), $o && b(i, $o), Jo && b(i, Jo), s && (no = r.t().takeEphemeralFocus(i)), r.t().registerPopoverFocusLossHandler(ya);
        }
      }, Gi = function() {
        if (Bt) {
          Bt = null;
          var t = vt;
          if (t) {
            r.t().unregisterPopoverFocusLossHandler(ya), t.style.display = "none", t.style.left = "", t.style.top = "", Mr && (Mr(), Mr = null), t.textContent = "", $o && (Y(t, $o), $o = ""), Jo && (Y(t, Jo), Jo = "");
            var e;
            if ((e = Ee) == null || e.markFocused(), no && (no(), no = null), Ee && vt) {
              var i;
              t = (i = yo(Ee.getFocusableElement(), y.OWNS)) != null ? i : "", w(Ee.getFocusableElement(), y.OWNS, t.replace(vt.id, "")), Ee.getFocusableElement().classList.remove("blocklyShowingWidgetDiv");
            }
          }
        }
      }, Vi = function(t) {
        Bt === t && Gi();
      }, As = function(t) {
        for (var e = Ee === null, i = t; !e && i; ) {
          if (i === t) {
            e = !0;
            break;
          }
          i = t.options.parentWorkspace;
        }
        e && Gi();
      }, ka = function(t, e, i) {
        if (vt) {
          var o = vt.parentElement;
          o && ({ x: t, y: e } = ko(t, e, o)), vt.style.left = t + "px", vt.style.top = e + "px", vt.style.height = i + "px";
        }
      }, wa = function(t, e, i, o) {
        var s = e.bottom + i.height >= t.bottom ? e.top - i.height : e.bottom;
        t = o ? Math.min(Math.max(e.right - i.width, t.left), t.right - i.width) : Math.max(Math.min(e.left, t.right - i.width), t.left), s < 0 ? ka(t, 0, i.height + s) : ka(t, s, i.height);
      }, Ia = function() {
        var t;
        (t = Bt) != null && t.repositionForWindowResize && Bt.repositionForWindowResize() || Gi();
      }, Lo = function(t, e, i, o, s) {
        if (Jn(xg, i, Sa, o), e.length) {
          s || (t instanceof PointerEvent ? s = new m(t.clientX, t.clientY) : (console.warn("Context menu opened with keyboard but no location given"), s = new m(0, 0)));
          var n = qu(e, i, t, s);
          wi = n, Zu(n, i, s), setTimeout(function() {
            n.focus();
          }, 1), Ys = null;
        } else Ns();
      }, qu = function(t, e, i, o) {
        var s = new kc();
        s.setRole(W.MENU);
        for (let n = 0; n < t.length; n++) {
          let l = t[n];
          if (l.separator) {
            s.addChild(new Kd());
            continue;
          }
          let a = new br(td(l));
          a.setRightToLeft(e), a.setRole(W.MENUITEM), s.addChild(a), a.setEnabled(l.enabled), l.enabled && a.onAction(function(c, E) {
            Ns(), requestAnimationFrame(() => {
              setTimeout(() => {
                l.callback(l.scope, i, E, o);
              }, 0);
            });
          }, {});
        }
        return s;
      }, Zu = function(t, e, i) {
        var o = Rl();
        i = new F(i.y + o.top, i.y + o.top, i.x + o.left, i.x + o.left);
        var s = vt;
        if (!s) throw Error("Attempting to create a context menu when widget div is null");
        s = t.render(s), b(s, "blocklyContextMenu"), M(s, "contextmenu", null, Qu), t.focus(), s = t.getSize(), e && (i.left += s.width, i.right += s.width, o.left += s.width, o.right += s.width), wa(o, i, s, e), t.focus();
      }, Qu = function(t) {
        t.preventDefault(), t.stopPropagation();
      }, Ns = function() {
        Vi(xg), Ys = null;
        var t;
        (t = wi) == null || t.dispose(), wi = null;
      }, Sa = function() {
        wi && (wi.dispose(), wi = null);
      }, r.Pg = function(t, e) {
        return () => {
          r.Ub++;
          try {
            var i = e instanceof Element ? zi(e, t.workspace) : fi(e, t.workspace);
            let o = t.getRelativeToSurfaceXY();
            o.x = t.RTL ? o.x - r.Og.snapRadius : o.x + r.Og.snapRadius, o.y += r.Og.snapRadius * 2, i.moveBy(o.x, o.y);
          } finally {
            r.Ub--;
          }
          return ht() && !i.isShadow() && N(new (D(p.BLOCK_CREATE))(i)), r.t().focusNode(i), i;
        };
      }, td = function(t) {
        var e = t.text;
        if (e && !(e instanceof HTMLElement)) {
          let i = document.createElement("div");
          i.className = "blocklyShortcutContainer";
          let o = document.createElement("span");
          return o.textContent = e, e = document.createElement("span"), e.className = "blocklyShortcut", t = "id" in t && t.associatedKeyboardShortcut ? $e(t.associatedKeyboardShortcut) : "", e.textContent = ` ${t}`, i.appendChild(o), i.appendChild(e), i;
        }
        return t.text;
      }, Ra = function(t, e) {
        return e = To(e, t.getParentSvg(), t.getInverseScreenCTM()), e.x /= t.scale, e.y /= t.scale, e;
      }, qn = function(t, e, i) {
        e = Ra(t, e), Mg.set(t, m.difference(i, e));
      }, Zn = function(t, e) {
        if (e = Ra(t, e), t = Mg.get(t), !t) throw Error("Drag not initialized");
        return m.sum(t, e);
      }, Aa = function(t, e = !1) {
        var i = r.sc("comment");
        e || i.setAttribute("id", t.id), e = t.workspace;
        var o = t.getRelativeToSurfaceXY().clone();
        return o.x = e.RTL ? e.getWidth() - o.x : o.x, i.setAttribute("x", `${o.x}`), i.setAttribute("y", `${o.y}`), i.setAttribute("w", `${t.getSize().width}`), i.setAttribute("h", `${t.getSize().height}`), t.getText() && (i.textContent = t.getText()), t.isCollapsed() && i.setAttribute("collapsed", "true"), t.isOwnEditable() || i.setAttribute("editable", "false"), t.isOwnMovable() || i.setAttribute("movable", "false"), t.isOwnDeletable() || i.setAttribute("deletable", "false"), i;
      }, Na = function(t) {
        var e = r.sc("variables");
        for (let i = 0; i < t.length; i++) {
          let o = t[i], s = r.sc("variable");
          s.appendChild(r.tc(o.getName())), o.getType() && s.setAttribute("type", o.getType()), s.id = o.getId(), e.appendChild(s);
        }
        return e;
      }, Da = function(t, e) {
        if (t.isInsertionMarker() && (t = t.getChildren(!1)[0], !t)) return new DocumentFragment();
        var i = 0;
        if (t.workspace.RTL && (i = t.workspace.getWidth()), e = Ei(t, e), e.nodeType === Pe.ELEMENT_NODE) {
          let o = t.getRelativeToSurfaceXY();
          e.setAttribute("x", String(Math.round(t.workspace.RTL ? i - o.x : o.x))), e.setAttribute("y", String(Math.round(o.y)));
        }
        return e;
      }, Ei = function(t, e) {
        if (t.isInsertionMarker()) return (e = t.getChildren(!1)[0]) ? Ei(e) : new DocumentFragment();
        var i = r.sc(t.isShadow() ? "shadow" : "block");
        if (i.setAttribute("type", t.type), e || (i.id = t.id), t.mutationToDom) {
          var o = t.mutationToDom();
          o && (o.hasChildNodes() || o.hasAttributes()) && i.appendChild(o);
        }
        for (var s of t.getFields()) s.isSerializable() ? (o = r.sc("field"), o.setAttribute("name", s.name || ""), o = s.toXml(o)) : o = null, o && i.appendChild(o);
        if (s = t.getCommentText()) {
          var n = t.getIcon(Ct.COMMENT);
          o = n.getBubbleSize();
          var l = n.bubbleIsVisible();
          n = n.getBubbleLocation();
          var a = r.sc("comment");
          a.appendChild(r.tc(s)), a.setAttribute("pinned", `${l}`), a.setAttribute("h", `${o.height}`), a.setAttribute("w", `${o.width}`), n && (a.setAttribute("x", `${t.workspace.RTL ? t.workspace.getWidth() - (n.x + o.width) : n.x}`), a.setAttribute("y", `${n.y}`)), i.appendChild(a);
        }
        for (t.data && (s = r.sc("data"), s.appendChild(r.tc(t.data)), i.appendChild(s)), s = 0; s < t.inputList.length; s++) {
          o = t.inputList[s];
          var c = void 0;
          l = !0, o.type !== r.je.DUMMY && o.type !== r.je.END_ROW && (n = o.connection.targetBlock(), o.type === r.je.VALUE ? c = r.sc("value") : o.type === r.je.STATEMENT && (c = r.sc("statement")), a = o.connection.getShadowDom(), !a || n && n.isShadow() || c.appendChild(Oa(a, e)), n && (n = Ei(n, e), n.nodeType === Pe.ELEMENT_NODE && (c.appendChild(n), l = !1)), c.setAttribute("name", o.name), l || i.appendChild(c));
        }
        if (t.inputsInline !== void 0 && t.inputsInline !== t.inputsInlineDefault && i.setAttribute("inline", String(t.inputsInline)), t.isCollapsed() && i.setAttribute("collapsed", "true"), t.isEnabled() || i.setAttribute(
          "disabled-reasons",
          Array.from(t.getDisabledReasons()).map(encodeURIComponent).join(",")
        ), t.isOwnDeletable() || i.setAttribute("deletable", "false"), t.isOwnMovable() || i.setAttribute("movable", "false"), t.isOwnEditable() || i.setAttribute("editable", "false"), c = t.getNextBlock(), c && (s = Ei(c, e), s.nodeType === Pe.ELEMENT_NODE)) {
          var E = r.sc("next");
          E.appendChild(s), i.appendChild(E);
        }
        return t = t.nextConnection && t.nextConnection.getShadowDom(), !t || c && c.isShadow() || E.appendChild(Oa(t, e)), i;
      }, Oa = function(t, e) {
        for (var i = t = t.cloneNode(!0), o; i; ) if (e && i.nodeName === "shadow" && i.removeAttribute("id"), i.firstChild) i = i.firstChild;
        else {
          for (; i && !i.nextSibling; ) {
            o = i, i = i.parentNode;
            let s;
            o.nodeType === Pe.TEXT_NODE && o.data.trim() === "" && ((s = i) == null ? void 0 : s.firstChild) !== o && Q(o);
          }
          i && (o = i, i = i.nextSibling, o.nodeType === Pe.TEXT_NODE && o.data.trim() === "" && Q(o));
        }
        return t;
      }, xo = function(t) {
        return wo(t).replace(/<(\w+)([^<]*)\/>/g, "<$1$2></$1>");
      }, r.ch = function(t, e) {
        var i = 0;
        e.RTL && (i = e.getWidth());
        var o = [];
        Li();
        var s = r.gd;
        s || r.B(!0), e.setResizesEnabled && e.setResizesEnabled(!1);
        var n = !0;
        try {
          for (let l = 0, a; a = t.childNodes[l]; l++) {
            let c = a.nodeName.toLowerCase(), E = a;
            if (c === "block" || c === "shadow" && !r.Qc) {
              let O = zi(E, e);
              o.push(O.id);
              let L, x = parseInt((L = E.getAttribute("x")) != null ? L : "10", 10), z, yt = parseInt((z = E.getAttribute("y")) != null ? z : "10", 10);
              isNaN(x) || isNaN(yt) || O.moveBy(e.RTL ? i - x : x, yt, ["create"]), n = !1;
            } else {
              if (c === "shadow") throw TypeError("Shadow block cannot be a top-level block.");
              if (c === "comment") La(E, e);
              else if (c === "variables") {
                if (n) xa(E, e);
                else throw Error("'variables' tag must exist once before block and shadow tag elements in the workspace XML, but it was found in another location.");
                n = !1;
              }
            }
          }
        } finally {
          r.B(s), e.setResizesEnabled && e.setResizesEnabled(!0), e.rendered && Ne(), xi();
        }
        return N(new (D(p.FINISHED_LOADING))(e)), o;
      }, La = function(t, e) {
        var i, o = (i = t.getAttribute("id")) != null ? i : void 0;
        i = e.rendered ? new ro(e, o) : new Hr(e, o);
        var s;
        i.setText((s = t.textContent) != null ? s : "");
        var n;
        s = parseInt((n = t.getAttribute("x")) != null ? n : "", 10);
        var l;
        n = parseInt((l = t.getAttribute("y")) != null ? l : "", 10), isNaN(s) || isNaN(n) || (s = e.RTL ? e.getWidth() - s : s, i.moveTo(new m(s, n)));
        var a;
        e = parseInt((a = t.getAttribute("w")) != null ? a : "", 10);
        var c;
        return a = parseInt((c = t.getAttribute("h")) != null ? c : "", 10), isNaN(e) || isNaN(a) || i.setSize(new H(e, a)), t.getAttribute("collapsed") === "true" && i.setCollapsed(!0), t.getAttribute("editable") === "false" && i.setEditable(!1), t.getAttribute("movable") === "false" && i.setMovable(!1), t.getAttribute("deletable") === "false" && i.setDeletable(!1), i;
      }, r.fh = function(t, e) {
        return t = zi(t, e), e.rendered && Ne(), t;
      }, zi = function(t, e) {
        r.Ub++;
        var i = e.getVariableMap().getAllVariables();
        try {
          var o = Qn(t, e);
          if (e.rendered) {
            let s = o, n = o.getDescendants(!1);
            s.setConnectionTracking(!1);
            for (let l = n.length - 1; l >= 0; l--) n[l].initSvg();
            for (let l = n.length - 1; l >= 0; l--) n[l].queueRender();
            setTimeout(function() {
              s.disposed || s.setConnectionTracking(!0);
            }, 1), e.resizeContents();
          } else {
            let s = o.getDescendants(!1);
            for (let n = s.length - 1; n >= 0; n--) s[n].initModel();
          }
        } finally {
          r.Ub--;
        }
        if (ht()) {
          for (t = Hn(e, i), e = 0; e < t.length; e++) i = t[e], N(new (D(p.VAR_CREATE))(i));
          N(new (D(p.BLOCK_CREATE))(o));
        }
        return o;
      }, xa = function(t, e) {
        for (let o = 0; o < t.children.length; o++) {
          var i = t.children[o];
          let s = i.getAttribute("type"), n = i.getAttribute("id");
          if (i = i.textContent, !i) break;
          e.getVariableMap().createVariable(i, s ?? void 0, n);
        }
      }, ed = function(t, e) {
        for (let i = 0; i < t.length; i++) {
          let o = t[i], s = o.textContent, n = o.getAttribute("pinned") === "true", l, a = parseInt((l = o.getAttribute("w")) != null ? l : "50", 10), c, E = parseInt((c = o.getAttribute("h")) != null ? c : "50", 10), O, L = parseInt((O = o.getAttribute("x")) != null ? O : "", 10), x, z = parseInt((x = o.getAttribute("y")) != null ? x : "", 10);
          e.setCommentText(s);
          let yt = e.getIcon(Ct.COMMENT);
          isNaN(a) || isNaN(E) || yt.setBubbleSize(new H(a, E)), yt.setBubbleVisible(n), setTimeout(() => {
            isNaN(L) || isNaN(z) || (L = e.workspace.RTL ? e.workspace.getWidth() - (L + a) : L, yt.setBubbleLocation(new m(L, z))), yt.setBubbleVisible(n);
          }, 1);
        }
      }, Ba = function(t) {
        var e = null, i = null;
        for (let o = 0; o < t.childNodes.length; o++) {
          let s = t.childNodes[o];
          s.nodeType === Pe.ELEMENT_NODE && (s.nodeName.toLowerCase() === "block" ? e = s : s.nodeName.toLowerCase() === "shadow" && (i = s));
        }
        return { childBlockElement: e, childShadowElement: i };
      }, Qn = function(t, e, i, o) {
        var s, n = t.getAttribute("type");
        if (!n) throw TypeError("Block type unspecified: " + t.outerHTML);
        var l = (s = t.getAttribute("id")) != null ? s : void 0;
        s = e.newBlock(n, l);
        var a = [], c = [], E = [], O = [], L = [];
        l = [];
        for (var x = 0; x < t.children.length; x++) {
          var z = t.children[x];
          if (z.nodeType !== Pe.TEXT_NODE) switch (z.nodeName.toLowerCase()) {
            case "mutation":
              a.push(z);
              break;
            case "comment":
              c.push(z);
              break;
            case "data":
              E.push(z);
              break;
            case "title":
            case "field":
              O.push(z);
              break;
            case "value":
            case "statement":
              L.push(z);
              break;
            case "next":
              l.push(z);
              break;
            default:
              console.warn("Ignoring unknown tag: " + z.nodeName);
          }
        }
        for (x = !1, z = 0; z < a.length; z++) {
          let Ru = a[z];
          s.domToMutation && (s.domToMutation(Ru), s.initSvg && (x = !0));
        }
        for (a = x, ed(c, s), c = E, E = 0; E < c.length; E++) s.data = c[E].textContent;
        if (i) {
          if (o) if (s.previousConnection) o = s.previousConnection;
          else throw TypeError("Next block does not have previous statement.");
          else if (s.outputConnection) o = s.outputConnection;
          else if (s.previousConnection) o = s.previousConnection;
          else throw TypeError("Child block does not have output or previous statement.");
          if (!i.connect(o)) throw t = s.workspace.connectionChecker, TypeError(t.getErrorMessage(t.canConnectWithReason(o, i, !1), o, i));
        }
        for (i = O, O = 0; O < i.length; O++) c = i[O], (E = c.getAttribute("name")) ? (o = s, (x = o.getField(E)) ? x.fromXml(c) : console.warn("Ignoring non-existent field " + E + " in block " + o.type)) : console.warn(`Ignoring unnamed field in block ${s.type}`);
        for (i = 0; i < L.length; i++) {
          if (O = L[i], o = (c = O.getAttribute("name")) ? s.getInput(c) : null, !o) {
            console.warn("Ignoring non-existent input " + c + " in block " + n);
            break;
          }
          if (O = Ba(O), O.childBlockElement) {
            if (!o.connection) throw TypeError("Input connection does not exist.");
            Qn(O.childBlockElement, e, o.connection, !1);
          }
          if (O.childShadowElement) {
            var yt = void 0;
            (yt = o.connection) == null || yt.setShadowDom(O.childShadowElement);
          }
        }
        for (n = l, yt = 0; yt < n.length; yt++) {
          if (l = Ba(n[yt]), l.childBlockElement) {
            if (!s.nextConnection) throw TypeError("Next statement does not exist.");
            if (s.nextConnection.isConnected()) throw TypeError("Next statement is already connected.");
            Qn(
              l.childBlockElement,
              e,
              s.nextConnection,
              !0
            );
          }
          l.childShadowElement && s.nextConnection && s.nextConnection.setShadowDom(l.childShadowElement);
        }
        if (a && s.initSvg(), (e = t.getAttribute("inline")) && s.setInputsInline(e === "true"), (e = t.getAttribute("disabled")) && s.setDisabledReason(e === "true" || e === "disabled", "MANUALLY_DISABLED"), e = t.getAttribute("disabled-reasons"), e !== null) for (var Lt of e.split(",")) s.setDisabledReason(!0, decodeURIComponent(Lt));
        if ((Lt = t.getAttribute("deletable")) && s.setDeletable(Lt === "true"), (Lt = t.getAttribute("movable")) && s.setMovable(Lt === "true"), (Lt = t.getAttribute("editable")) && s.setEditable(Lt === "true"), (Lt = t.getAttribute("collapsed")) && s.setCollapsed(Lt === "true"), t.nodeName.toLowerCase() === "shadow") {
          for (t = s.getChildren(!1), Lt = 0; Lt < t.length; Lt++) if (!t[Lt].isShadow()) throw TypeError("Shadow block not allowed non-shadow child.");
          s.setShadow(!0);
        }
        return s;
      }, xe = function(t, e) {
        P(_.FIELD, t, e, !0);
      }, r.lh = function(t) {
        return Hg.fromJsonInternal(t);
      }, Ki = function(t) {
        return t && typeof t == "object" && "src" in t && typeof t.src == "string" && "alt" in t && typeof t.alt == "string" && "width" in t && typeof t.width == "number" && "height" in t && typeof t.height == "number";
      }, r.oh = function(t, e) {
        if (typeof t != "string" || t.trim() === "") throw Error('Error: Invalid extension name "' + t + '"');
        if (Zo[t]) throw Error('Error: Extension "' + t + '" is already registered.');
        if (typeof e != "function") throw Error('Error: Extension "' + t + '" must be a function');
        Zo[t] = e;
      }, r.ph = function(t, e) {
        if (!e || typeof e != "object") throw Error('Error: Mixin "' + t + '" must be a object');
        r.oh(t, function() {
          this.mixin(e);
        });
      }, r.th = function(t, e, i, o) {
        var s = 'Error when registering mutator "' + t + '": ';
        Pa(s, e);
        var n = Ds(e.compose, e.decompose, s + " compose/decompose");
        if (i && typeof i != "function") throw Error(s + 'Extension "' + t + '" is not a function');
        r.oh(t, function() {
          n && this.setMutator(new r.sh(o || [], this)), this.mixin(e), i && i.apply(this);
        });
      }, Ma = function(t) {
        return !!Zo[t];
      }, tr = function(t, e, i) {
        var o = Zo[t];
        if (typeof o != "function") throw Error('Error: Extension "' + t + '" not found.');
        if (i) {
          if (er(e).length) throw Error('Error: tried to apply mutation "' + t + '" to a block that already has mutator functions.  Block id: ' + e.id);
        } else var s = er(e);
        if (o.apply(e), i) Pa('Error after applying mutator "' + t + '": ', e);
        else {
          t: if (i = s, e = er(e), e.length !== i.length) e = !1;
          else {
            for (o = 0; o < e.length; o++) if (i[o] !== e[o]) {
              e = !1;
              break t;
            }
            e = !0;
          }
          if (!e) throw Error('Error when applying extension "' + t + '": mutation properties changed when applying a non-mutator extension.');
        }
      }, Ds = function(t, e, i) {
        if (t && e) {
          if (typeof t != "function" || typeof e != "function") throw Error(i + " must be a function");
          return !0;
        }
        if (!t && !e) return !1;
        throw Error(i + "Must have both or neither functions");
      }, Pa = function(t, e) {
        var i = Ds(e.mutationToDom, e.domToMutation, t + " mutationToDom/domToMutation"), o = Ds(e.saveExtraState, e.loadExtraState, t + " saveExtraState/loadExtraState");
        if (!i && !o) throw Error(t + "Mutations must contain either XML hooks, or JSON hooks, or both");
        Ds(e.compose, e.decompose, t + " compose/decompose");
      }, er = function(t) {
        var e = [];
        return t.domToMutation !== void 0 && e.push(t.domToMutation), t.mutationToDom !== void 0 && e.push(t.mutationToDom), t.saveExtraState !== void 0 && e.push(t.saveExtraState), t.loadExtraState !== void 0 && e.push(t.loadExtraState), t.compose !== void 0 && e.push(t.compose), t.decompose !== void 0 && e.push(t.decompose), e;
      }, r.yh = function(t, e) {
        var i = [];
        return function() {
          i.includes(this.type) || (id(this, t, e), i.push(this.type)), this.setTooltip(function() {
            var o = String(this.getFieldValue(t));
            return et(e[o]);
          }.bind(this));
        };
      }, id = function(t, e, i) {
        var o = t.getField(e);
        if (o instanceof Nt && !o.isOptionListDynamic()) {
          o = o.getOptions();
          for (let s of o)
            s !== Nt.SEPARATOR && ([, o] = s, i[o] === void 0 && console.warn(`No tooltip mapping for value ${o} of field ${e} of block type ${t.type}.`));
        }
      }, r.Ah = function(t, e) {
        return function() {
          this.setTooltip(function() {
            var i = this.getField(e);
            return et(t).replace("%1", i ? i.getText() : "");
          }.bind(this));
        };
      }, R = function(t, e) {
        return " " + t + "," + e + " ";
      }, $t = function(t, e) {
        return " " + t + e.join("");
      }, St = function(t, e) {
        return " M " + t + "," + e + " ";
      }, ct = function(t, e) {
        return " m " + t + "," + e + " ";
      }, Be = function(t, e) {
        return " l " + t + "," + e + " ";
      }, Bo = function(t) {
        return " l" + t.join("");
      }, A = function(t, e) {
        return " " + t + " " + e + " ";
      }, dt = function(t, e, i, o) {
        return t + " " + i + " " + i + " " + e + o;
      }, od = function(t, e) {
        var i = null;
        e = e.outputConnection;
        var o = e?.getConnectionChecker();
        for (let s = 0, n; n = t.inputList[s]; s++) {
          let l = n.connection;
          if (l && (o != null && o.canConnect(e, l, !1))) {
            if (i) return null;
            i = l;
          }
        }
        return i;
      }, Fa = function(t) {
        return li(t) && typeof t.getType == "function" && typeof t.initView == "function" && typeof t.dispose == "function" && typeof t.getWeight == "function" && typeof t.getSize == "function" && typeof t.applyColour == "function" && typeof t.hideForInsertionMarker == "function" && typeof t.updateEditable == "function" && typeof t.updateCollapsed == "function" && typeof t.isShownWhenCollapsed == "function" && typeof t.setOffsetInBlock == "function" && typeof t.onLocationChange == "function" && typeof t.onClick == "function";
      }, ir = function(t) {
        if (!(t.getDescendants(!1).length > 100)) {
          var e = t.workspace, i = t.getSvgRoot();
          e.getAudioManager().play("delete");
          var o = t.getRelativeToSurfaceXY(), s = i.cloneNode(!0);
          s.setAttribute("transform", "translate(" + o.x + "," + o.y + ")");
          var n;
          (n = e.getLayerManager()) == null || n.appendToAnimationLayer({ getSvgRoot: () => s }), Ha(s, { x: o.x, y: o.y, width: t.width, height: t.height }, e.RTL, /* @__PURE__ */ new Date());
        }
      }, Ha = function(t, e, i, o) {
        var s = ((/* @__PURE__ */ new Date()).getTime() - o.getTime()) / 150;
        s > 1 ? Q(t) : (t.setAttribute("transform", "translate(" + (e.x + (i ? -1 : 1) * e.width / 2 * s) + "," + (e.y + e.height / 2 * s) + ") scale(" + (1 - s) + ")"), setTimeout(Ha, 10, t, e, i, o));
      }, Ua = function(t) {
        var e = t.workspace, i = e.scale;
        if (e.getAudioManager().play("click"), !(i < 1)) {
          var o = e.getSvgXY(t.getSvgRoot());
          t.outputConnection ? (o.x += (t.RTL ? 3 : -3) * i, o.y += 13 * i) : t.previousConnection && (o.x += (t.RTL ? -23 : 23) * i, o.y += 3 * i);
          var s = v(g.CIRCLE, { cx: o.x, cy: o.y, r: 0, fill: "none", stroke: "#888", "stroke-width": 10 }, e.getParentSvg());
          t = v(g.ANIMATE, { id: "animationCircle", begin: "indefinite", attributeName: "r", dur: "150ms", from: 0, to: 25 * i }, s), e = v(g.ANIMATE, {
            id: "animationOpacity",
            begin: "indefinite",
            attributeName: "opacity",
            dur: "150ms",
            from: 1,
            to: 0
          }, s), t.beginElement(), e.beginElement(), setTimeout(() => void Q(s), 150);
        }
      }, Wa = function(t) {
        if (Mo(), t.workspace.getAudioManager().play("disconnect"), !(t.workspace.scale < 1)) {
          var e = t.getHeightWidth().height;
          e = Math.atan(10 / e) / Math.PI * 180, t.RTL || (e *= -1), Js = t, Ga(t, e, /* @__PURE__ */ new Date(), 0);
        }
      }, Ga = function(t, e, i, o) {
        var s = [0.66, 1, 0.66, 0, -0.66, -1, -0.66, 0], n = "";
        i.getTime() + 200 > (/* @__PURE__ */ new Date()).getTime() && (n = `skewX(${Math.round(s[o % s.length] * e)})`, Gr = setTimeout(Ga, 15, t, e, i, o + 1)), t.getSvgRoot().setAttribute("transform", `${t.getTranslation()} ${n}`);
      }, Mo = function() {
        Js && (Gr && (clearTimeout(Gr), Gr = null), Js.getSvgRoot().setAttribute("transform", Js.getTranslation()), Js = null);
      }, sd = function(t, e) {
        t.workspace.RTL && (e.x = t.workspace.getWidth() - e.x);
        for (var i = t.workspace, o = r.Og.snapRadius, s = m.difference(e, t.getRelativeToSurfaceXY()), n = new m(0, 0), l = i.getAllBlocks(!1).filter((a) => a.id != t.id).map((a) => a.getRelativeToSurfaceXY()); nd(m.sum(e, n), l) || rd(t, m.sum(s, n), o); ) i.RTL ? n.translate(-o, o * 2) : n.translate(o, o * 2);
        t.moveTo(m.sum(e, n));
      }, nd = function(t, e) {
        return e.some((i) => Math.abs(i.x - t.x) <= 1 && Math.abs(i.y - t.y) <= 1);
      }, rd = function(t, e, i) {
        return t.getConnections_(!1).some((o) => !!o.closest(i, e).connection);
      }, Os = function(t, e, i) {
        var o = i.getBoundingRectangle(), s = o.right - o.left, n = No(e.top, o.top, e.top + e.height - (o.bottom - o.top)) - o.top, l = e.left;
        return e = e.left + e.width - s, t.RTL ? l = Math.min(e, l) : e = Math.max(l, e), (t = No(l, o.left, e) - o.left) || n ? (i.moveBy(t, n, ["inbounds"]), !0) : !1;
      }, Va = function(t) {
        return (e) => {
          var i = t.getMetricsManager();
          if (i.hasFixedEdges() && !t.isDragging()) {
            var o;
            if (Nd.includes((o = e.type) != null ? o : "")) {
              switch (i = i.getScrollMetrics(!0), o = null, e.type) {
                case p.BLOCK_CREATE:
                case p.BLOCK_MOVE:
                  (o = t.getBlockById(e.blockId)) && (o = o.getRootBlock());
                  break;
                case p.COMMENT_CREATE:
                case p.COMMENT_MOVE:
                case p.COMMENT_RESIZE:
                  o = t.getCommentById(e.commentId);
              }
              if (o) {
                var s = r.gd || !1;
                r.B(e.group), Os(t, i, o) && !e.group && console.warn("Moved object in bounds but there was no event group. This may break undo."), r.B(s);
              }
            } else e.type === p.VIEWPORT_CHANGE && e.scale && e.oldScale && e.scale > e.oldScale && or(t);
          }
        };
      }, or = function(t) {
        var e = t.getMetricsManager();
        if (e.hasFixedEdges() && !t.isDragging()) {
          e = e.getScrollMetrics(!0);
          var i = t.getTopBoundedElements();
          for (let o = 0, s; s = i[o]; o++) Os(t, e, s);
        }
      }, sr = function(t, e) {
        var i = t.toCopyData();
        return co = i, uo = gs(t) && t.workspace instanceof Ot ? t.workspace : null, Qs = e, i;
      }, Me = function(t, e, i) {
        return t && e ? za(t, e, i) : co && uo ? za(co, uo, Qs) : null;
      }, za = function(t, e, i) {
        var o;
        e = e.isMutator ? e : (o = e.options.parentWorkspace) != null ? o : e;
        var s, n;
        return (n = (s = Mt(_.PASTER, t.paster, !1)) == null ? void 0 : s.paste(t, e, i)) != null ? n : null;
      }, Ka = function(t) {
        return typeof t.getBoundingRectangle == "function" && typeof t.moveBy == "function";
      }, Po = function(t) {
        return t && typeof t.toCopyData == "function";
      }, ie = function(t) {
        return t && typeof t.isDeletable == "function" && typeof t.dispose == "function" && typeof t.setDeleteStyle == "function";
      }, Xi = function(t) {
        return t && typeof t.getRelativeToSurfaceXY == "function" && typeof t.isMovable == "function" && typeof t.startDrag == "function" && typeof t.drag == "function" && typeof t.endDrag == "function" && typeof t.revertDrag == "function";
      }, Xa = function() {
        S.registry.register({ name: B.ESCAPE, preconditionFn(t) {
          return !t.isReadOnly();
        }, callback(t) {
          return t.hideChaff(), !0;
        }, keyCodes: [C.ESC], displayText: () => r.C.SHORTCUTS_ESCAPE });
      }, Ya = function() {
        S.registry.register({ name: B.DELETE, preconditionFn(t, e) {
          return e = e.focusedNode, (e = !t.isReadOnly() && e != null && ie(e) && e.isDeletable() && !t.isDragging() && !r.t().ephemeralFocusTaken()) || t.getAudioManager().playErrorBeep(), e;
        }, callback(t, e, i, o) {
          return e.preventDefault(), e = o.focusedNode, e instanceof ut ? e.checkAndDelete() : ie(e) && e.isDeletable() && (r.B(!0), e.dispose(), r.B(!1), t.getAudioManager().play("delete")), !0;
        }, keyCodes: [C.DELETE, C.BACKSPACE], displayText: () => r.C.SHORTCUTS_DELETE });
      }, Ls = function(t) {
        return Po(t) && ie(t) && Xi(t) ? t.isCopyable ? t.isCopyable() : t instanceof ut || t instanceof ro ? t.isOwnDeletable() && t.isOwnMovable() : t.isDeletable() && t.isMovable() : !1;
      }, ja = function() {
        var t = S.registry.createSerializedKey(C.C, [C.CTRL_CMD]);
        S.registry.register({ name: B.COPY, preconditionFn(e, i) {
          i = i.focusedNode;
          var o = e.isFlyout ? e.targetWorkspace : e;
          return (i = !!i && !!o && !o.isDragging() && !r.t().ephemeralFocusTaken() && Ls(i)) || e.getAudioManager().playErrorBeep(), i;
        }, callback(e, i, o, s) {
          return i.preventDefault(), o = s.focusedNode, !o || !Po(o) || !Ls(o) || (s = e.isFlyout ? e.targetWorkspace : e, !s) ? !1 : (o.workspace.isFlyout || s.hideChaff(), s = Xi(o) && o.workspace == s ? o.getRelativeToSurfaceXY() : void 0, (o = !!sr(o, s)) && i instanceof KeyboardEvent && Xt.show(e, { message: r.C.KEYBOARD_NAV_COPIED_HINT.replace("%1", $e(B.PASTE)), duration: 7, id: "copiedHint" }), o);
        }, keyCodes: [t], displayText: () => r.C.COPY_SHORTCUT });
      }, $a = function() {
        var t = S.registry.createSerializedKey(C.X, [C.CTRL_CMD]);
        S.registry.register({ name: B.CUT, preconditionFn(e, i) {
          return i = i.focusedNode, (i = !!i && !e.isReadOnly() && !e.isDragging() && !r.t().ephemeralFocusTaken() && Ls(i) && ie(i) && i.isDeletable()) || e.getAudioManager().playErrorBeep(), i;
        }, callback(e, i, o, s) {
          return o = s.focusedNode, o && Ls(o) && ie(o) && o.isDeletable() && Po(o) ? (s = Xi(o) ? o.getRelativeToSurfaceXY() : void 0, s = sr(o, s), o instanceof ut ? (o.checkAndDelete(), i.preventDefault()) : ie(o) && (r.B(!0), o.dispose(), r.B(!1), e.getAudioManager().play("delete"), i.preventDefault()), s && i instanceof KeyboardEvent && Xt.show(e, { message: r.C.KEYBOARD_NAV_CUT_HINT.replace("%1", $e(B.PASTE)), duration: 7, id: "cutHint" }), !!s) : !1;
        }, keyCodes: [t], displayText: () => r.C.CUT_SHORTCUT });
      }, Ja = function() {
        var t = S.registry.createSerializedKey(C.V, [C.CTRL_CMD]);
        S.registry.register({ name: B.PASTE, preconditionFn() {
          var e = uo;
          if (!e || !e.rendered) return !1;
          var i = e.isFlyout ? e.targetWorkspace : e;
          return (i = !!co && !!i && !i.isReadOnly() && !i.isDragging() && !r.t().ephemeralFocusTaken()) || e.getAudioManager().playErrorBeep(), i;
        }, callback(e, i) {
          var o = co, s = r.t().getFocusedNode();
          if (!o) return !1;
          var n = uo;
          if (!n || (Xt.hide(e, "cutHint"), Xt.hide(e, "copiedHint"), e = n.isFlyout ? n.targetWorkspace : n, !e || e.isReadOnly())) return !1;
          if (i instanceof PointerEvent) {
            var l = gi(e, new m(i.clientX, i.clientY));
            return !!Me(o, e, l);
          }
          if (i = (l = e.getNavigator().getSourceBlockFromNode(s)) == null ? void 0 : l.getRelativeToSurfaceXY()) return !!Me(o, e, i);
          if (l = Qs, !l) return !!Me(o, e);
          var { left: a, top: c, width: E, height: O } = e.getMetricsManager().getViewMetrics(!0);
          return new F(c, c + O, a, a + E).contains(l.x, l.y) ? !!Me(o, e) : (l = new m(a + E / 2, c + O / 2), !!Me(o, e, l));
        }, keyCodes: [t], displayText: () => r.C.PASTE_SHORTCUT });
      }, qa = function() {
        var t = S.registry.createSerializedKey(C.Z, [C.CTRL_CMD]);
        S.registry.register({ name: B.UNDO, preconditionFn(e) {
          return !e.isReadOnly() && !e.isDragging() && !r.t().ephemeralFocusTaken();
        }, callback(e, i) {
          return e.hideChaff(), e.undo(), i.preventDefault(), !0;
        }, keyCodes: [t], displayText: () => r.C.UNDO });
      }, Za = function() {
        var t = S.registry.createSerializedKey(C.Z, [C.CTRL_CMD, C.SHIFT]), e = S.registry.createSerializedKey(C.Y, [C.CTRL]);
        S.registry.register({ name: B.REDO, preconditionFn(i) {
          return !i.isDragging() && !i.isReadOnly() && !r.t().ephemeralFocusTaken();
        }, callback(i, o) {
          return i.hideChaff(), i.redo(), o.preventDefault(), !0;
        }, keyCodes: [t, e], displayText: () => r.C.REDO });
      }, Qa = function() {
        var t = (o) => {
          var s = r.t().getFocusedNode();
          if (Xi(s)) return s;
          var n;
          return (n = o.getNavigator().getSourceBlockFromNode(r.t().getFocusedNode())) != null ? n : void 0;
        }, e = S.registry.createSerializedKey(C.M, [C.SHIFT]), i = { name: B.START_MOVE, preconditionFn: (o) => (o = t(o), !!o && J.mover.canMove(o)), callback: (o, s) => (st.setIsActive(!0), (o = t(o)) && r.t().focusNode(o), !!o && J.mover.startMove(o, s)), keyCodes: [C.M], displayText: () => r.C.SHORTCUTS_START_MOVE };
        e = [
          i,
          Object.assign({}, i, {
            name: B.START_MOVE_STACK,
            keyCodes: [e],
            displayText: () => r.C.SHORTCUTS_START_MOVE_STACK
          }),
          { name: B.FINISH_MOVE, preconditionFn: () => J.mover.isMoving(), callback: (o, s) => J.mover.finishMove(s), keyCodes: [C.ENTER, C.SPACE], allowCollision: !0, displayText: () => r.C.SHORTCUTS_FINISH_MOVE },
          { name: B.ABORT_MOVE, preconditionFn: () => J.mover.isMoving(), callback: (o, s) => J.mover.abortMove(s), keyCodes: [C.ESC], allowCollision: !0, displayText: () => r.C.SHORTCUTS_ABORT_MOVE },
          { name: B.MOVE_LEFT, preconditionFn: () => J.mover.isMoving(), callback: (o, s) => (s.preventDefault(), J.mover.move(lt.LEFT, s)), keyCodes: [C.LEFT, Kg], allowCollision: !0, displayText: () => r.C.SHORTCUTS_MOVE_LEFT },
          { name: B.MOVE_RIGHT, preconditionFn: () => J.mover.isMoving(), callback: (o, s) => (s.preventDefault(), J.mover.move(lt.RIGHT, s)), keyCodes: [C.RIGHT, Xg], allowCollision: !0, displayText: () => r.C.SHORTCUTS_MOVE_RIGHT },
          { name: B.MOVE_UP, preconditionFn: () => J.mover.isMoving(), callback: (o, s) => (s.preventDefault(), J.mover.move(lt.UP, s)), keyCodes: [C.UP, Yg], allowCollision: !0, displayText: () => r.C.SHORTCUTS_MOVE_UP },
          { name: B.MOVE_DOWN, preconditionFn: () => J.mover.isMoving(), callback: (o, s) => (s.preventDefault(), J.mover.move(lt.DOWN, s)), keyCodes: [C.DOWN, jg], allowCollision: !0, displayText: () => r.C.SHORTCUTS_MOVE_DOWN }
        ];
        for (let o of e) S.registry.register(o);
      }, th = function() {
        var t = S.registry.createSerializedKey(C.ENTER, [C.CTRL_CMD]), e = S.registry.createSerializedKey(C.F10, [C.SHIFT]);
        S.registry.register({ name: B.MENU, preconditionFn: (i) => !i.isDragging(), callback: (i, o) => {
          if (st.setIsActive(!0), (i = r.t().getFocusedNode()) && typeof i.showContextMenu == "function") {
            i.showContextMenu(o);
            let s;
            return (s = wi) == null || s.highlightNext(), !0;
          }
          return !1;
        }, keyCodes: [t, e, C.CONTEXT_MENU], displayText: () => r.C.SHORTCUTS_SHOW_CONTEXT_MENU });
      }, eh = function() {
        var t = { right: { name: B.NAVIGATE_RIGHT, preconditionFn: (e) => !e.isDragging() && !mt && !Bt, callback: (e, i) => {
          i.preventDefault(), st.setIsActive(!0);
          var o, s;
          return i = e.RTL ? (o = r.t().getFocusedTree()) == null ? void 0 : o.getNavigator().getOutNode() : (s = r.t().getFocusedTree()) == null ? void 0 : s.getNavigator().getInNode(), i ? (r.t().focusNode(i), !0) : (e.getAudioManager().playErrorBeep(), !1);
        }, keyCodes: [C.RIGHT], allowCollision: !0, displayText: () => r.C.SHORTCUTS_NAVIGATE_RIGHT }, left: { name: B.NAVIGATE_LEFT, preconditionFn: (e) => !e.isDragging() && !mt && !Bt, callback: (e, i) => {
          i.preventDefault(), st.setIsActive(!0);
          var o, s;
          return i = e.RTL ? (o = r.t().getFocusedTree()) == null ? void 0 : o.getNavigator().getInNode() : (s = r.t().getFocusedTree()) == null ? void 0 : s.getNavigator().getOutNode(), i ? (r.t().focusNode(i), !0) : (e.getAudioManager().playErrorBeep(), !1);
        }, keyCodes: [C.LEFT], allowCollision: !0, displayText: () => r.C.SHORTCUTS_NAVIGATE_LEFT }, down: { name: B.NAVIGATE_DOWN, preconditionFn: (e) => !e.isDragging() && !mt && !Bt, callback: (e, i) => {
          i.preventDefault(), st.setIsActive(!0);
          var o;
          return i = (o = r.t().getFocusedTree()) == null ? void 0 : o.getNavigator().getNextNode(), i ? (e.getAudioManager().maybePlayScopeChangeAudioCue(i), r.t().focusNode(i), !0) : (e.getAudioManager().playErrorBeep(), !1);
        }, keyCodes: [C.DOWN], allowCollision: !0, displayText: () => r.C.SHORTCUTS_NAVIGATE_DOWN }, up: { name: B.NAVIGATE_UP, preconditionFn: (e) => !e.isDragging() && !mt && !Bt, callback: (e, i) => {
          i.preventDefault(), st.setIsActive(!0);
          var o;
          return i = (o = r.t().getFocusedTree()) == null ? void 0 : o.getNavigator().getPreviousNode(), i ? (e.getAudioManager().maybePlayScopeChangeAudioCue(i), r.t().focusNode(i), !0) : (e.getAudioManager().playErrorBeep(), !1);
        }, keyCodes: [C.UP], allowCollision: !0, displayText: () => r.C.SHORTCUTS_NAVIGATE_UP } };
        for (let e of Object.values(t)) S.registry.register(e);
      }, ih = function() {
        S.registry.register({ name: B.FOCUS_WORKSPACE, preconditionFn: (t) => !t.isDragging(), callback: (t) => {
          st.setIsActive(!0), t = lu(t);
          var e;
          return r.t().focusNode((e = t.getWorkspaceFocusTarget()) != null ? e : t), !0;
        }, keyCodes: [C.W], displayText: () => r.C.SHORTCUTS_FOCUS_WORKSPACE });
      }, oh = function() {
        S.registry.register({ name: B.FOCUS_TOOLBOX, preconditionFn: (t) => !t.isDragging(), callback: (t, e) => {
          var i = t.getToolbox();
          if (i) st.setIsActive(!0), r.t().focusTree(i);
          else {
            if (t = t.getFlyout(), !t) return !1;
            st.setIsActive(!0), r.t().focusTree(t.getWorkspace());
          }
          return e.preventDefault(), !0;
        }, keyCodes: [C.T], displayText: () => r.C.SHORTCUTS_FOCUS_TOOLBOX });
      }, sh = function() {
        S.registry.register({ name: B.INFORMATION, preconditionFn: () => !0, callback: (t) => {
          var e = r.t().getFocusedNode(), i = t.getNavigator().getSourceBlockFromNode(e);
          if (i) return t = Je(i, ot.LOQUACIOUS), ue(t), !0;
          if (e === t) {
            e = lu(t), t = e.getTopBlocks().length, e = e.getTopComments().length, i = t === 0 ? "WORKSPACE_CONTENTS_BLOCKS_ZERO" : t === 1 ? "WORKSPACE_CONTENTS_BLOCKS_ONE" : "WORKSPACE_CONTENTS_BLOCKS_MANY";
            let o = "";
            return e > 0 && (o = r.C[e === 1 ? "WORKSPACE_CONTENTS_COMMENTS_ONE" : "WORKSPACE_CONTENTS_COMMENTS_MANY"].replace("%1", String(e))), t = r.C[i].replace("%1", String(t)).replace("%2", o), ue(t), !0;
          }
          return !1;
        }, keyCodes: [C.I], displayText: () => r.C.SHORTCUTS_INFORMATION });
      }, nh = function() {
        var t = S.registry.createSerializedKey(C.I, [C.SHIFT]);
        S.registry.register({ name: B.EXTENDED_INFORMATION, preconditionFn: () => !0, callback: (e) => {
          if (e = e.getNavigator().getSourceBlockFromNode(r.t().getFocusedNode()), !e) return !1;
          for (var i = [], o = e, s; (s = o.outputConnection) != null && s.isConnected(); ) o = o.getParent();
          for (o !== e && i.push(Je(o, ot.TERSE)), s = o.getParent(); s; ) i.push(Je(s, ot.TERSE)), s = s.getParent();
          if (i.length) {
            i.reverse();
            let n;
            (n = e.outputConnection) != null && n.isConnected() || i.push(r.C.CURRENT_BLOCK_ANNOUNCEMENT.replace(
              "%1",
              Je(e, ot.TERSE)
            )), ue(r.C.PARENT_BLOCKS_ANNOUNCEMENT.replace("%1", i.join(",")));
          } else ue(r.C.NO_PARENT_ANNOUNCEMENT);
          return !0;
        }, keyCodes: [t], displayText: () => r.C.SHORTCUTS_EXTENDED_INFORMATION });
      }, rh = function() {
        var t = S.registry.createSerializedKey(C.X, [C.SHIFT]);
        S.registry.register({ name: B.DISCONNECT, preconditionFn: (e, i) => (i = i.focusedNode, (i = !e.isDragging() && !e.isReadOnly() && i instanceof ut && !i.isShadow()) || e.getAudioManager().playErrorBeep(), i), callback: (e, i) => (st.setIsActive(!0), e = r.t().getFocusedNode(), e instanceof ut ? (i = !(i instanceof KeyboardEvent && i.shiftKey), r.B(!0), e.unplug(i), r.B(!1), !0) : !1), keyCodes: [C.X, t], displayText: () => r.C.SHORTCUTS_DISCONNECT });
      }, lh = function() {
        var t = (i, o = r.t().getFocusedNode()) => {
          var s = i.getNavigator();
          for (let n = o; n && n !== i; n = s.getParent(n)) o = n;
          return gs(o) ? o : null;
        }, e = { name: B.PREVIOUS_STACK, preconditionFn: (i) => !i.isDragging() && !!t(i) && !mt && !Bt, callback: (i) => {
          st.setIsActive(!0);
          var o = t(i);
          return !o || (i = t(i, i.getNavigator().navigateStacks(o, -1)), !i) ? !1 : (r.t().focusNode(i), !0);
        }, keyCodes: [C.B], displayText: () => r.C.SHORTCUTS_PREVIOUS_STACK };
        S.registry.register({ name: B.NEXT_STACK, preconditionFn: (i) => !i.isDragging() && !!t(i) && !mt && !Bt, callback: (i) => {
          st.setIsActive(!0);
          var o = t(i);
          return !o || (i = i.getNavigator().navigateStacks(o, 1), !i) ? !1 : (r.t().focusNode(i), !0);
        }, keyCodes: [C.N], displayText: () => r.C.SHORTCUTS_NEXT_STACK }), S.registry.register(e);
      }, ah = function() {
        var t = () => {
          var s = r.t().getFocusedTree();
          if (s instanceof Ot && s.isFlyout && s.targetWorkspace) {
            let n;
            return (n = s.targetWorkspace.getFlyout()) != null ? n : null;
          }
          return null;
        }, e = (s) => {
          var n = s.getWorkspace().getNavigator();
          s = s.getContents().map((c) => c.getElement());
          for (var l, a = (l = r.t().getFocusedNode()) != null ? l : null; a && !s.includes(a); ) a = n.getParent(a);
          return a;
        }, i = (s, n) => {
          var l = s.getContents().map((c) => c.getElement());
          s = (s = e(s)) ? l.indexOf(s) : n === 1 ? -1 : l.length;
          for (let c = 1; c <= l.length; c++) {
            var a = s + n * c;
            if (a < 0 || a >= l.length) break;
            if (a = l[a], a instanceof Gt && a.isLabel()) return a;
          }
          return null;
        }, o = S.registry.createSerializedKey(C.H, [C.SHIFT]);
        o = { name: B.PREVIOUS_HEADING, preconditionFn: (s) => !s.isDragging() && !mt && !Bt && !!t(), callback: () => {
          var s = t();
          return !s || (s = i(s, -1), !s) ? !1 : (st.setIsActive(!0), r.t().focusNode(s), !0);
        }, keyCodes: [o], displayText: () => r.C.SHORTCUTS_PREVIOUS_HEADING }, S.registry.register({ name: B.NEXT_HEADING, preconditionFn: (s) => !s.isDragging() && !mt && !Bt && !!t(), callback: () => {
          var s = t();
          return !s || (s = i(s, 1), !s) ? !1 : (st.setIsActive(!0), r.t().focusNode(s), !0);
        }, keyCodes: [C.H], displayText: () => r.C.SHORTCUTS_NEXT_HEADING }), S.registry.register(o);
      }, hh = function() {
        S.registry.register({ name: B.PERFORM_ACTION, preconditionFn: (t) => !t.isDragging() && !mt && !Bt && !r.t().ephemeralFocusTaken(), callback: (t, e) => {
          if (st.setIsActive(!0), (t = r.t().getFocusedNode()) && "performAction" in t) {
            e.preventDefault();
            let i;
            return (i = t.performAction) == null || i.call(t, e), !0;
          }
          return !1;
        }, keyCodes: [C.ENTER, C.SPACE], allowCollision: !0, displayText: () => r.C.SHORTCUTS_PERFORM_ACTION });
      }, ch = function() {
        S.registry.register({ name: B.DUPLICATE, preconditionFn: (t, e) => ({ focusedNode: e } = e, (e = !t.isDragging() && !t.isReadOnly() && !t.isFlyout && (e instanceof ut ? e.isDuplicatable() : !0)) || t.getAudioManager().playErrorBeep(), e), callback: (t, e, i, o) => (st.setIsActive(!0), e = Po(o.focusedNode) && o.focusedNode, e && (e = e.toCopyData()) ? !!Me(e, t) : !1), keyCodes: [C.D], allowCollision: !0, displayText: () => r.C.SHORTCUTS_DUPLICATE });
      }, uh = function() {
        S.registry.register({ name: B.CLEANUP, preconditionFn: (t) => !t.isDragging() && !t.isReadOnly() && !t.isFlyout, callback: (t) => (st.setIsActive(!0), t.cleanUp(), !0), keyCodes: [C.C], allowCollision: !0, displayText: () => r.C.SHORTCUTS_CLEANUP });
      }, dh = function() {
        var t = S.registry.createSerializedKey(C.J, [C.CTRL_CMD]);
        S.registry.register({ name: B.SHOW_TOOLTIP, preconditionFn: (e) => !e.isDragging(), callback: (e) => {
          var i = r.t().getFocusedNode();
          return i !== null && (st.setIsActive(!0), va(i, e)), !0;
        }, keyCodes: [t], allowCollision: !0, displayText: () => r.C.SHORTCUTS_SHOW_TOOLTIP });
      }, gh = function() {
        var t = S.registry.createSerializedKey(C.A, [C.ALT, C.SHIFT]), e = !1;
        S.registry.register({ name: B.TOGGLE_SCREENREADER, preconditionFn: () => !0, callback: (i, o) => {
          e = !e, st.setScopeChangeAudioCuesEnabled(e), i.getNavigator().setNavigationLoops(!e);
          var s;
          (s = i.getToolbox()) == null || s.getNavigator().setNavigationLoops(!e);
          var n;
          return (n = i.getFlyout()) == null || n.getWorkspace().getNavigator().setNavigationLoops(!e), Xt.show(i, { message: (e ? r.C.SCREENREADER_MODE_ENABLED : r.C.SCREENREADER_MODE_DISABLED).replace(
            "%1",
            $e(B.TOGGLE_SCREENREADER)
          ), duration: 7, id: "screenreaderHint" }), o.preventDefault(), !0;
        }, keyCodes: [t], allowCollision: !0, displayText: () => r.C.SHORTCUTS_TOGGLE_SCREENREADER_MODE });
      }, ph = function() {
        S.registry.register({ name: B.JUMP_BLOCK_START, preconditionFn: zr, callback(t, e, i, o) {
          if (!o.focusedNode) return !1;
          t = t.getNavigator().getSourceBlockFromNode(o.focusedNode);
          var s;
          return (s = t) != null && s.getFullBlockField() && t.getParent() && (t = t.getParent()), t ? (r.t().focusNode(t), !0) : !1;
        }, keyCodes: [C.HOME], displayText: () => r.C.SHORTCUTS_JUMP_BLOCK_START });
      }, fh = function() {
        S.registry.register({ name: B.JUMP_BLOCK_END, preconditionFn: zr, callback(t, e, i, o) {
          if (!o.focusedNode) return !1;
          t = t.getNavigator().getSourceBlockFromNode(o.focusedNode);
          var s;
          return (s = t) != null && s.getFullBlockField() && t.getParent() && (t = t.getParent()), !t || (s = t.inputList, !s.length) || (s = s[s.length - 1].connection, !(s && s instanceof Dt)) ? !1 : (r.t().focusNode(s), !0);
        }, keyCodes: [C.END], displayText: () => r.C.SHORTCUTS_JUMP_BLOCK_END });
      }, Eh = function() {
        S.registry.register({ name: B.JUMP_TOP_STACK, preconditionFn: zr, callback(t, e, i, o) {
          return !o.focusedNode || (t = t.getNavigator().getSourceBlockFromNode(o.focusedNode), !t) ? !1 : (t = t.getRootBlock(), r.t().focusNode(t), !0);
        }, keyCodes: [C.PAGE_UP], displayText: () => r.C.SHORTCUTS_JUMP_TOP_STACK });
      }, vh = function() {
        S.registry.register({ name: B.JUMP_BOTTOM_STACK, preconditionFn: zr, callback(t, e, i, o) {
          if (!o.focusedNode || (t = t.getNavigator().getSourceBlockFromNode(o.focusedNode), !t)) return !1;
          var s;
          return t = (s = t.getRootBlock().lastConnectionInStack(!1)) == null ? void 0 : s.getSourceBlock(), t ? (s = t.getDescendants(!0), s = s[s.length - 1], r.t().focusNode(s), !0) : !1;
        }, keyCodes: [C.PAGE_DOWN], displayText: () => r.C.SHORTCUTS_JUMP_BOTTOM_STACK });
      }, _h = function() {
        var t = S.registry.createSerializedKey(C.HOME, [C.CTRL_CMD]);
        S.registry.register({ name: B.JUMP_FIRST_BLOCK, preconditionFn: (e) => !e.isDragging() && !r.t().ephemeralFocusTaken(), callback(e) {
          var i = $g(e);
          return i ? i.length ? (r.t().focusNode(i[0]), !0) : !1 : (e = e.getTopBlocks(!0), e.length ? (r.t().focusNode(e[0]), !0) : !1);
        }, keyCodes: [t], displayText: () => r.C.SHORTCUTS_JUMP_FIRST_BLOCK });
      }, mh = function() {
        var t = S.registry.createSerializedKey(C.END, [C.CTRL_CMD]);
        S.registry.register({ name: B.JUMP_LAST_BLOCK, preconditionFn: (e) => !e.isDragging() && !r.t().ephemeralFocusTaken(), callback(e) {
          var i = $g(e);
          return i ? i.length ? (r.t().focusNode(i[i.length - 1]), !0) : !1 : (e = e.getAllBlocks(!0), e.length ? (r.t().focusNode(e[e.length - 1]), !0) : !1);
        }, keyCodes: [t], displayText: () => r.C.SHORTCUTS_JUMP_LAST_BLOCK });
      }, Th = function(t, e, i) {
        var o = e[e.length - 1].start >= e[0].start;
        return { items: t, leadingEdge: (s) => o ? e[s].start : -e[s].end, trailingEdge: (s) => o ? e[s].end : -e[s].start, viewLeadingEdge: o ? i.start : -i.end, viewTrailingEdge: o ? i.end : -i.start };
      }, ld = function(t) {
        var e = t.getNavigator().getNavigableItems(t.getRootFocusableNode());
        if (!e.length) return null;
        var i = t.isHorizontal(), o = (n) => (n = n.getBoundingClientRect(), i ? { start: n.left, end: n.right } : { start: n.top, end: n.bottom });
        t = t.getRootFocusableNode().getFocusableElement();
        var s = e.map((n) => o(n.getFocusableElement()));
        return Th(e, s, o(t));
      }, ad = function(t) {
        var e = t.getNavigator().getNavigableItems(t.getRootFocusableNode()).filter((n) => Ka(n));
        if (!e.length) return null;
        var i, o, s = !!(!((i = t.targetWorkspace) == null || (o = i.getFlyout()) == null) && o.horizontalLayout);
        return t = t.getMetricsManager().getViewMetrics(!0), t = s ? { start: t.left, end: t.left + t.width } : { start: t.top, end: t.top + t.height }, i = e.map((n) => (n = n.getBoundingRectangle(), s ? { start: n.left, end: n.right } : { start: n.top, end: n.bottom })), Th(e, i, t);
      }, Ch = function(t, e) {
        var i = au(t);
        if (t = i ? ld(i) : ad(t), !t) return !1;
        i = t.items;
        var o = r.t().getFocusedNode();
        o = o ? i.indexOf(o) : -1;
        var s = t.viewTrailingEdge - t.viewLeadingEdge, n = -1;
        if (e)
          for (var l = o >= 0 ? Math.max(t.viewLeadingEdge, t.leadingEdge(o)) : t.viewLeadingEdge, a = 0; a < i.length && !(t.leadingEdge(a) >= l + s); a++) n = a;
        else for (l = o >= 0 ? Math.min(t.viewTrailingEdge, t.trailingEdge(o)) : t.viewTrailingEdge, a = i.length - 1; a >= 0 && !(t.trailingEdge(a) <= l - s); a--) n = a;
        return n < 0 || n === o && (n += e ? 1 : -1, n < 0 || n >= i.length) ? !1 : (r.t().focusNode(i[n]), !0);
      }, yh = function() {
        S.registry.register({ name: B.JUMP_PREVIOUS_PAGE, preconditionFn: Jg, callback(t, e) {
          return Ch(t, !1) ? (e.preventDefault(), !0) : !1;
        }, keyCodes: [C.PAGE_UP], allowCollision: !0, displayText: () => r.C.SHORTCUTS_JUMP_PREVIOUS_PAGE });
      }, bh = function() {
        S.registry.register({ name: B.JUMP_NEXT_PAGE, preconditionFn: Jg, callback(t, e) {
          return Ch(t, !0) ? (e.preventDefault(), !0) : !1;
        }, keyCodes: [C.PAGE_DOWN], allowCollision: !0, displayText: () => r.C.SHORTCUTS_JUMP_NEXT_PAGE });
      }, kh = function() {
        var t = [{ name: B.SCROLL_LEFT, preconditionFn: Kr, callback: (e, i) => Xr(e, i, Vt.LEFT), keyCodes: [Kg], allowCollision: !0, displayText: () => r.C.SHORTCUTS_SCROLL_LEFT }, { name: B.SCROLL_RIGHT, preconditionFn: Kr, callback: (e, i) => Xr(e, i, Vt.RIGHT), keyCodes: [Xg], allowCollision: !0, displayText: () => r.C.SHORTCUTS_SCROLL_RIGHT }, { name: B.SCROLL_UP, preconditionFn: Kr, callback: (e, i) => Xr(e, i, Vt.UP), keyCodes: [Yg], allowCollision: !0, displayText: () => r.C.SHORTCUTS_SCROLL_UP }, { name: B.SCROLL_DOWN, preconditionFn: Kr, callback: (e, i) => Xr(e, i, Vt.DOWN), keyCodes: [jg], allowCollision: !0, displayText: () => r.C.SHORTCUTS_SCROLL_DOWN }];
        for (let e of t) S.registry.register(e);
      }, wh = function() {
        Xa(), Ya(), ja(), $a(), Ja(), qa(), Za();
      }, Ih = function() {
        th(), Qa(), ih(), oh(), eh(), rh(), lh(), ah(), hh(), ch(), uh(), dh();
      }, Sh = function() {
        sh(), nh(), gh();
      }, Rh = function(t, e = !1) {
        var i = r.C.KEYBOARD_NAV_UNCONSTRAINED_MOVE_HINT.replace("%1", Fo || Ms || pr ? r.C.COMMAND_KEY : r.C.CONTROL_KEY).replace("%2", r.C.ENTER_KEY);
        Xt.show(t, { message: i, id: "unconstrainedMoveHint", oncePerSession: !e });
      }, hd = function(t) {
        var e = r.C.KEYBOARD_NAV_CONSTRAINED_MOVE_HINT.replace("%1", r.C.ENTER_KEY);
        Xt.show(t, { message: e, id: "constrainedMoveHint", oncePerSession: !0 });
      }, Ah = function(t) {
        var e = [];
        for (var i of t.getIcons()) {
          if (t.isCollapsed() && !i.isShownWhenCollapsed()) continue;
          e.push(i);
          let o;
          De(i) && i.bubbleIsVisible() && (o = i.getBubble()) && e.push(o);
        }
        for (let o of t.inputList)
          o.isVisible() && (e.push(...o.fieldRow), i = o.connection, i && (e.push(i), i = i.targetBlock(), i && (e.push(i), (i = i.lastConnectionInStack(!1)) && e.push(i))));
        return t.nextConnection && !t.isCollapsed() && e.push(t.nextConnection), e;
      }, oe = function(t, e, i) {
        return t = Ah(t), e = t.indexOf(e), e === -1 ? null : (i = e + i, i >= 0 && i < t.length ? t[i] : null);
      }, nr = function(t) {
        return t && typeof t.getChildToolboxItems == "function" && typeof t.isExpanded == "function" && typeof t.toggleExpanded == "function" && Hi(t) && t.isCollapsible();
      }, qe = function(t) {
        var e = t.options.toolboxPosition;
        return t.options.RTL && e !== I.TOP && e !== I.BOTTOM ? e === I.LEFT ? I.RIGHT : I.LEFT : e;
      }, Nh = function(t, e) {
        P(_.ICON, t.toString(), e);
      }, vi = function(t) {
        return typeof t.getProcedureModel == "function" && typeof t.doProcedureUpdate == "function" && typeof t.isProcedureDef == "function";
      }, rr = function(t) {
        return t && typeof t.startPublishing == "function" && typeof t.stopPublishing == "function";
      }, lr = function(t) {
        var e = t.getProcedureMap().getProcedures().filter((o) => !o.getReturnTypes()).map((o) => [o.getName(), o.getParameters().map((s) => s.getName()), !1]);
        t.getBlocksByType("procedures_defnoreturn", !1).forEach((o) => {
          !vi(o) && So(o) && e.push(o.getProcedureDef());
        });
        var i = t.getProcedureMap().getProcedures().filter((o) => !!o.getReturnTypes()).map((o) => [o.getName(), o.getParameters().map((s) => s.getName()), !0]);
        return t.getBlocksByType("procedures_defreturn", !1).forEach((o) => {
          !vi(o) && So(o) && i.push(o.getProcedureDef());
        }), e.sort(Dh), i.sort(Dh), [e, i];
      }, Dh = function(t, e) {
        return t[0].localeCompare(e[0], void 0, { sensitivity: "base" });
      }, r.Bj = function(t, e) {
        if (e.isInFlyout) return t;
        for (t = t || r.C.UNNAMED_KEY || "unnamed"; Oh(t, e.workspace, e); ) {
          let i = t.match(/^(.*?)(\d+)$/);
          t = i ? i[1] + (parseInt(i[2]) + 1) : t + "2";
        }
        return t;
      }, Oh = function(t, e, i) {
        for (let o of e.getAllBlocks(!1)) if (o !== i && So(o) && r.Cj.equals(o.getProcedureDef()[0], t)) return !0;
        i = i && vi(i) ? i?.getProcedureModel() : void 0;
        for (let o of e.getProcedureMap().getProcedures()) if (o !== i && r.Cj.equals(o.getName(), t)) return !0;
        return !1;
      }, r.Ej = function(t) {
        var e = this.getSourceBlock();
        if (!e) throw new Et();
        t = t.trim();
        var i = r.Bj(t, e);
        vi(e) && !e.isInsertionMarker() && e.getProcedureModel().setName(i);
        var o = this.getValue();
        if (o !== t && o !== i) for (t = e.workspace.getAllBlocks(!1), e = 0; e < t.length; e++) {
          let s = t[e];
          s.renameProcedure && s.renameProcedure(o, i);
        }
        return i;
      }, ar = function(t) {
        function e(o, s) {
          for (let [n, l] of o) i.push({ kind: "block", type: s, gap: 16, extraState: { name: n, params: l } });
        }
        var i = [];
        return gt.procedures_defnoreturn && i.push({ kind: "block", type: "procedures_defnoreturn", gap: 16, fields: { NAME: r.C.PROCEDURES_DEFNORETURN_PROCEDURE } }), gt.procedures_defreturn && i.push({ kind: "block", type: "procedures_defreturn", gap: 16, fields: { NAME: r.C.PROCEDURES_DEFRETURN_PROCEDURE } }), gt.procedures_ifreturn && i.push({ kind: "block", type: "procedures_ifreturn", gap: 16 }), i.length && (i[i.length - 1].gap = 24), t = lr(t), e(t[0], "procedures_callnoreturn"), e(t[1], "procedures_callreturn"), i;
      }, Lh = function(t) {
        var e = [], i = t.getBlocksByType("procedures_mutatorarg", !1);
        for (let n = 0, l; l = i[n]; n++) e.push(l.getFieldValue("NAME"));
        i = r.sc("xml");
        var o = r.sc("block");
        o.setAttribute("type", "procedures_mutatorarg");
        var s = r.sc("field");
        s.setAttribute("name", "NAME"), e = Pn("x", e), e = r.tc(e), s.appendChild(e), o.appendChild(s), i.appendChild(o), t.updateToolbox(i);
      }, xh = function(t) {
        if (t.type === p.BUBBLE_OPEN && t.bubbleType === "mutator" && t.isOpen && t.blockId) {
          t = ai(t.workspaceId).getBlockById(t.blockId);
          var e = t.type;
          (e === "procedures_defnoreturn" || e === "procedures_defreturn") && (t = t.getIcon(r.sh.TYPE).getWorkspace(), Lh(t), t.addChangeListener(cd));
        }
      }, cd = function(t) {
        (t.type === p.BLOCK_CREATE || t.type === p.BLOCK_DELETE || t.type === p.BLOCK_CHANGE || t.type === p.BLOCK_FIELD_INTERMEDIATE_CHANGE) && (t = ai(t.workspaceId), Lh(t));
      }, Bh = function(t, e) {
        return e.getAllBlocks(!1).filter((i) => vi(i) && !i.isProcedureDef() && i.getProcedureModel() && r.Cj.equals(i.getProcedureModel().getName(), t) || i && typeof i.getProcedureCall == "function" && typeof i.renameProcedure == "function" && r.Cj.equals(i.getProcedureCall(), t));
      }, r.Kj = function(t) {
        var e = r.Qc, i = t.getProcedureDef()[0], o = t.mutationToDom(!0);
        t = Bh(i, t.workspace);
        for (let n = 0, l; l = t[n]; n++) {
          i = (i = l.mutationToDom()) && wo(i), l.domToMutation && l.domToMutation(o);
          var s = l.mutationToDom();
          s = s && wo(s), i !== s && (r.Qc = !1, N(new (D(p.BLOCK_CHANGE))(l, "mutation", null, i, s)), r.Qc = e);
        }
      }, r.Lj = function(t, e) {
        for (let i of e.getAllBlocks(!1)) if (vi(i) && i.isProcedureDef() && r.Cj.equals(i.getProcedureModel().getName(), t) || So(i) && r.Cj.equals(i.getProcedureDef()[0], t)) return i;
        return null;
      }, xs = function(t, e) {
        P(_.RENDERER, t, e);
      }, Mh = function(t, e, i) {
        return t = new (Mt(_.RENDERER, t, void 0))(t), t.init(e, i), t;
      }, Ph = function(t) {
        Ro(t.getTargetWorkspace(), void 0, "String");
      }, Fh = function(t) {
        Ro(t.getTargetWorkspace(), void 0, "Number");
      }, Hh = function(t) {
        Ro(t.getTargetWorkspace(), void 0, "Colour");
      }, hr = function(t) {
        return gt.variables_set_dynamic || gt.variables_get_dynamic || console.warn("There are no dynamic variable blocks, but there is a dynamic variable category."), t.registerButtonCallback("CREATE_VARIABLE_STRING", Ph), t.registerButtonCallback("CREATE_VARIABLE_NUMBER", Fh), t.registerButtonCallback("CREATE_VARIABLE_COLOUR", Hh), [{ kind: "button", text: r.C.NEW_STRING_VARIABLE, callbackkey: "CREATE_VARIABLE_STRING" }, { kind: "button", text: r.C.NEW_NUMBER_VARIABLE, callbackkey: "CREATE_VARIABLE_NUMBER" }, {
          kind: "button",
          text: r.C.NEW_COLOUR_VARIABLE,
          callbackkey: "CREATE_VARIABLE_COLOUR"
        }, ...Mn(t, t.getVariableMap().getAllVariables(), !1, "variables_get_dynamic", "variables_set_dynamic")];
      }, Uh = function(t) {
        var e = t.saveState();
        return t.getParameters().length && (e.parameters = t.getParameters().map((i) => i.saveState())), e;
      }, Wh = function(t, e, i, o) {
        if (t = t.loadState(i, o), !i.parameters) return t;
        for (let [s, n] of i.parameters.entries()) t.insertParameter(e.loadState(n, o), s);
        return t;
      }, Gh = function(t, e) {
        return t <= 0 ? 0 : (e = Math.min(Math.abs(e), t), t - Math.sqrt(t * t - e * e));
      }, ud = function(t, e) {
        t.setAttribute("dir", "LTR"), dl(t, e.hasCss, e.pathToMedia);
        var i = v(g.SVG, { xmlns: "http://www.w3.org/2000/svg", "xmlns:html": "http://www.w3.org/1999/xhtml", "xmlns:xlink": "http://www.w3.org/1999/xlink", version: "1.1", class: "blocklySvg" }, t), o = v(g.DEFS, {}, i), s = String(Math.random()).substring(2);
        return e.gridPattern = uu.createDom(s, e.gridOptions, o, t), i;
      }, dd = function(t, e, i) {
        i.parentWorkspace = null, i = new Ot(i);
        var o = i.options;
        i.scale = o.zoomOptions.startScale, e.appendChild(i.createDom("blocklyMainBackground", t));
        var s = i.getRenderer().getClassName();
        return s && b(t, s), (s = i.getTheme().getClassName()) && b(t, s), !o.hasCategories && o.languageTree && (s = i.addFlyout(g.SVG), t.insertBefore(s, e)), o.hasTrashcan && i.addTrashcan(), o.zoomOptions && o.zoomOptions.controls && i.addZoomControls(), i.getThemeManager().subscribe(e, "workspaceBackgroundColour", "background-color"), i.translate(
          0,
          0
        ), i.addChangeListener(Va(i)), Bi(i), ba(), Vn(), pa(), i;
      }, gd = function(t) {
        var e = t.options, i = t.getParentSvg();
        if (M(i.parentNode, "contextmenu", null, function(o) {
          hs(o) || o.preventDefault();
        }), i = M(window, "resize", null, function() {
          Le(), t.hideComponents(!0), Bi(t), ha(), Ia(), or(t);
        }), t.setResizeHandlerWrapper(i), pd(), e.languageTree) {
          i = t.getToolbox();
          let o = t.getFlyout(!0);
          i ? i.init() : o && (o.init(t), o.show(e.languageTree), typeof o.scrollToStart == "function" && o.scrollToStart());
        }
        e.hasTrashcan && t.trashcan.init(), e.zoomOptions && e.zoomOptions.controls && t.zoomControls_.init(), e.moveOptions && e.moveOptions.scrollbars ? (t.scrollbar = new cu(t, e.moveOptions.scrollbars === !0 || !!e.moveOptions.scrollbars.horizontal, e.moveOptions.scrollbars === !0 || !!e.moveOptions.scrollbars.vertical, "blocklyMainWorkspaceScrollbar"), t.scrollbar.resize()) : t.setMetrics({ x: 0.5, y: 0.5 }), e.hasSounds && fd(e.pathToMedia, t);
      }, pd = function() {
        Jp || (M(document, "scroll", null, function() {
          var t = hi();
          for (let e = 0, i; i = t[e]; e++) i instanceof Ot && i.updateInverseScreenCTM();
        }), jt(document, "touchend", null, Se), jt(document, "touchcancel", null, Se), jt(document, "keydown", null, function(t) {
          t.key === "Tab" && st.setIsActive(!0);
        })), Jp = !0;
      }, fd = function(t, e) {
        e = e.getAudioManager(), e.load([`${t}click.mp3`], "click"), e.load([`${t}disconnect.mp3`], "disconnect"), e.load([`${t}delete.mp3`], "delete"), e.load([`${t}drop.mp3`], "drop");
      }, Vh = function() {
        V.registry.register({ displayText() {
          return r.C.UNDO;
        }, preconditionFn(t) {
          return t.workspace.getUndoStack().length > 0 ? "enabled" : "disabled";
        }, callback(t) {
          t.workspace.undo();
        }, scopeType: V.ScopeType.WORKSPACE, id: "undoWorkspace", weight: 1, associatedKeyboardShortcut: "undo" });
      }, zh = function() {
        V.registry.register({ displayText() {
          return r.C.REDO;
        }, preconditionFn(t) {
          return t.workspace.getRedoStack().length > 0 ? "enabled" : "disabled";
        }, callback(t) {
          t.workspace.redo();
        }, scopeType: V.ScopeType.WORKSPACE, id: "redoWorkspace", weight: 2, associatedKeyboardShortcut: "redo" });
      }, Kh = function() {
        V.registry.register({ displayText() {
          return r.C.CLEAN_UP;
        }, preconditionFn(t) {
          return t.workspace.isMovable() ? t.workspace.getTopBlocks(!1).length > 1 ? "enabled" : "disabled" : "hidden";
        }, callback(t) {
          t.workspace.cleanUp();
        }, scopeType: V.ScopeType.WORKSPACE, id: "cleanWorkspace", weight: 3, associatedKeyboardShortcut: "cleanup" });
      }, Xh = function(t, e) {
        function i(n) {
          s--, n.setCollapsed(t), s === 0 && r.B(!1);
        }
        var o = 0, s = 0;
        r.B(!0);
        for (let n = 0; n < e.length; n++) {
          let l = e[n];
          for (; l; ) s++, setTimeout(i.bind(null, l), o), l = l.getNextBlock(), o += 10;
        }
      }, Yh = function() {
        V.registry.register({ displayText() {
          return r.C.COLLAPSE_ALL;
        }, preconditionFn(t) {
          if (t.workspace.options.collapse) {
            t = t.workspace.getTopBlocks(!1);
            for (let e = 0; e < t.length; e++) {
              let i = t[e];
              for (; i; ) {
                if (!i.isCollapsed()) return "enabled";
                i = i.getNextBlock();
              }
            }
            return "disabled";
          }
          return "hidden";
        }, callback(t) {
          Xh(!0, t.workspace.getTopBlocks(!0));
        }, scopeType: V.ScopeType.WORKSPACE, id: "collapseWorkspace", weight: 4 });
      }, jh = function() {
        V.registry.register({ displayText() {
          return r.C.EXPAND_ALL;
        }, preconditionFn(t) {
          if (t.workspace.options.collapse) {
            t = t.workspace.getTopBlocks(!1);
            for (let e = 0; e < t.length; e++) {
              let i = t[e];
              for (; i; ) {
                if (i.isCollapsed()) return "enabled";
                i = i.getNextBlock();
              }
            }
            return "disabled";
          }
          return "hidden";
        }, callback(t) {
          Xh(!1, t.workspace.getTopBlocks(!0));
        }, scopeType: V.ScopeType.WORKSPACE, id: "expandWorkspace", weight: 5 });
      }, $h = function(t, e) {
        if (t.isDeletable()) Array.prototype.push.apply(e, t.getDescendants(!1));
        else {
          t = t.getChildren(!1);
          for (let i = 0; i < t.length; i++) $h(t[i], e);
        }
      }, cr = function(t) {
        var e = [];
        t = t.getTopBlocks(!0);
        for (let i = 0; i < t.length; i++) $h(t[i], e);
        return e;
      }, Bs = function(t, e) {
        e ? r.B(e) : (r.B(!0), e = r.gd);
        var i = t.shift();
        i && (i.isDeadOrDying() ? Bs(t, e) : (i.dispose(!1, !0), setTimeout(Bs, 10, t, e))), r.B(!1);
      }, Jh = function() {
        V.registry.register({
          displayText(t) {
            return t.workspace ? (t = cr(t.workspace).length, t === 1 ? r.C.DELETE_BLOCK : r.C.DELETE_X_BLOCKS.replace("%1", `${t}`)) : "";
          },
          preconditionFn(t) {
            return t.workspace && cr(t.workspace).length > 0 ? "enabled" : "disabled";
          },
          callback(t) {
            if (t.workspace) {
              t.workspace.cancelCurrentGesture();
              var e = cr(t.workspace);
              e.length < 2 ? Bs(e) : Dn(r.C.DELETE_ALL_BLOCKS.replace("%1", String(e.length)), function(i) {
                i && Bs(e);
              });
            }
          },
          scopeType: V.ScopeType.WORKSPACE,
          id: "workspaceDelete",
          weight: 6
        });
      }, qh = function() {
        V.registry.register({ displayText() {
          return r.C.DUPLICATE_BLOCK;
        }, preconditionFn(t) {
          return t = t.block, !t.isInFlyout && t.isDeletable() && t.isMovable() ? t.isDuplicatable() ? "enabled" : "disabled" : "hidden";
        }, callback(t) {
          if (t.block) {
            var e = t.block.toCopyData();
            e && Me(e, t.block.workspace);
          }
        }, scopeType: V.ScopeType.BLOCK, id: "blockDuplicate", weight: 1, associatedKeyboardShortcut: "duplicate" });
      }, Zh = function() {
        V.registry.register({
          displayText(t) {
            return t.block.hasIcon(ze.TYPE) ? r.C.REMOVE_COMMENT : r.C.ADD_COMMENT;
          },
          preconditionFn(t) {
            t = t.block;
            var e;
            if ((e = t && !t.isInFlyout && t.workspace.options.comments && !t.isCollapsed() && t.isEditable()) && !(e = t.hasIcon(ze.TYPE))) {
              if (t && t.isSimpleReporter()) {
                var i;
                t = (i = t.getFields().next().value) == null ? void 0 : i.isFullBlockField();
              } else t = !1;
              e = !t;
            }
            return e ? "enabled" : "hidden";
          },
          callback(t) {
            (t = t.block) && t.hasIcon(ze.TYPE) ? t.setCommentText(null) : t.setCommentText("");
          },
          scopeType: V.ScopeType.BLOCK,
          id: "blockComment",
          weight: 2
        });
      }, Qh = function() {
        V.registry.register({ displayText(t) {
          return t.block.getInputsInline() ? r.C.EXTERNAL_INPUTS : r.C.INLINE_INPUTS;
        }, preconditionFn(t) {
          if (t = t.block, !t.isInFlyout && t.isMovable() && !t.isCollapsed()) {
            for (let e = 1; e < t.inputList.length; e++) if (!(t.inputList[e - 1] instanceof ll || t.inputList[e] instanceof ll)) return "enabled";
          }
          return "hidden";
        }, callback(t) {
          t.block.setInputsInline(!t.block.getInputsInline());
        }, scopeType: V.ScopeType.BLOCK, id: "blockInline", weight: 3 });
      }, tc = function() {
        V.registry.register({ displayText(t) {
          return t.block.isCollapsed() ? r.C.EXPAND_BLOCK : r.C.COLLAPSE_BLOCK;
        }, preconditionFn(t) {
          return t = t.block, !t.isInFlyout && t.isMovable() && t.workspace.options.collapse ? "enabled" : "hidden";
        }, callback(t) {
          t.block.setCollapsed(!t.block.isCollapsed());
        }, scopeType: V.ScopeType.BLOCK, id: "blockCollapseExpand", weight: 4 });
      }, ec = function() {
        V.registry.register({ displayText(t) {
          return t.block.hasDisabledReason("MANUALLY_DISABLED") ? r.C.ENABLE_BLOCK : r.C.DISABLE_BLOCK;
        }, preconditionFn(t) {
          if (t = t.block, !t.isInFlyout && t.workspace.options.disable && t.isEditable()) {
            var e = t.getDisabledReasons();
            return e = e.size > (e.has("MANUALLY_DISABLED") ? 1 : 0), t.getInheritedDisabled() || e ? "disabled" : "enabled";
          }
          return "hidden";
        }, callback(t) {
          t = t.block;
          var e = r.gd;
          e || r.B(!0), t.setDisabledReason(!t.hasDisabledReason("MANUALLY_DISABLED"), "MANUALLY_DISABLED"), r.B(e);
        }, scopeType: V.ScopeType.BLOCK, id: "blockDisable", weight: 5 });
      }, ic = function() {
        V.registry.register({ displayText(t) {
          var e = t.block;
          return t = e.getDescendants(!1).length, (e = e.getNextBlock()) && (t -= e.getDescendants(!1).length), t === 1 ? r.C.DELETE_BLOCK : r.C.DELETE_X_BLOCKS.replace("%1", `${t}`);
        }, preconditionFn(t) {
          return !t.block.isInFlyout && t.block.isDeletable() ? "enabled" : "hidden";
        }, callback(t) {
          t.block && (r.t().focusNode(t.block), t.block.checkAndDelete());
        }, scopeType: V.ScopeType.BLOCK, id: "blockDelete", weight: 6, associatedKeyboardShortcut: "delete" });
      }, oc = function() {
        V.registry.register({ displayText() {
          return r.C.HELP;
        }, preconditionFn(t) {
          return t = t.block, (typeof t.helpUrl == "function" ? t.helpUrl() : t.helpUrl) ? "enabled" : "hidden";
        }, callback(t) {
          t.block.showHelp();
        }, scopeType: V.ScopeType.BLOCK, id: "blockHelp", weight: 7 });
      }, sc = function() {
        V.registry.register({ displayText: () => r.C.REMOVE_COMMENT, preconditionFn(t) {
          var e;
          return (e = t.comment) != null && e.isDeletable() ? "enabled" : "hidden";
        }, callback(t) {
          r.B(!0);
          var e;
          (e = t.comment) == null || e.dispose(), r.B(!1);
          var i;
          (i = t.comment) == null || i.workspace.getAudioManager().play("delete");
        }, scopeType: V.ScopeType.COMMENT, id: "commentDelete", weight: 6, associatedKeyboardShortcut: "delete" });
      }, nc = function() {
        V.registry.register({ displayText: () => r.C.DUPLICATE_COMMENT, preconditionFn(t) {
          var e;
          return (e = t.comment) != null && e.isMovable() ? "enabled" : "hidden";
        }, callback(t) {
          if (t.comment) {
            var e = t.comment.toCopyData();
            e && Me(e, t.comment.workspace);
          }
        }, scopeType: V.ScopeType.COMMENT, id: "commentDuplicate", weight: 1, associatedKeyboardShortcut: "duplicate" });
      }, rc = function() {
        V.registry.register({ displayText: () => r.C.ADD_COMMENT, preconditionFn: (t) => {
          var e;
          return (e = t.workspace) != null && e.isMutator ? "hidden" : "enabled";
        }, callback: (t, e, i, o) => {
          (t = t.workspace) && (r.B(!0), e = new ro(t), e.moveTo(gi(t, new m(o.x, o.y))), r.t().focusNode(e), r.B(!1));
        }, scopeType: V.ScopeType.WORKSPACE, id: "commentCreate", weight: 8 });
      }, lc = function() {
        Vh(), zh(), Kh(), Yh(), jh(), Jh(), qh(), Zh(), Qh(), tc(), ec(), ic(), oc();
      }, d = d || {}, d.scope = {}, d.ASSUME_ES2020 = !1, d.ASSUME_ES6 = d.ASSUME_ES2020, d.ASSUME_ES5 = d.ASSUME_ES6, d.ASSUME_NO_NATIVE_MAP = !1, d.ASSUME_NO_NATIVE_SET = !1, d.ISOLATE_POLYFILLS = !1, d.FORCE_POLYFILL_PROMISE = !1, d.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION = !1, d.INSTRUMENT_ASYNC_CONTEXT = !0, d.objectCreate = d.ASSUME_ES5 || typeof Object.create == "function" ? Object.create : function(t) {
        function e() {
        }
        return e.prototype = t, new e();
      }, d.defineProperty = d.ASSUME_ES5 || typeof Object.defineProperties == "function" ? Object.defineProperty : function(t, e, i) {
        return t == Array.prototype || t == Object.prototype || (t[e] = i.value), t;
      }, d.getGlobal = function(t) {
        t = [typeof globalThis == "object" && globalThis, t, typeof window == "object" && window, typeof self == "object" && self, typeof af == "object" && af];
        for (var e = 0; e < t.length; ++e) {
          var i = t[e];
          if (i && i.Math == Math) return i;
        }
        throw Error("Cannot find global object");
      }, d.global = d.ASSUME_ES2020 ? globalThis : d.getGlobal(this), d.IS_SYMBOL_NATIVE = typeof Symbol == "function" && typeof Symbol("x") == "symbol", d.TRUST_ES6_POLYFILLS = !d.ISOLATE_POLYFILLS || d.IS_SYMBOL_NATIVE, d.polyfills = {}, d.propertyToPolyfillSymbol = {}, d.POLYFILL_PREFIX = "$jscp$";
      var ac = "Int8 Uint8 Uint8Clamped Int16 Uint16 Int32 Uint32 Float32 Float64".split(" ");
      d.global.BigInt64Array && (ac.push("BigInt64"), ac.push("BigUint64")), d.TYPED_ARRAY_CLASSES = ac, d.polyfillTypedArrayMethod = function(t, e, i, o) {
        if (e) for (var s = 0; s < d.TYPED_ARRAY_CLASSES.length; s++) {
          var n = d.TYPED_ARRAY_CLASSES[s] + "Array.prototype." + t;
          d.ISOLATE_POLYFILLS ? d.polyfillIsolated(n, e, i, o) : d.polyfillUnisolated(n, e, i, o);
        }
      }, d.polyfill = function(t, e, i, o) {
        e && (d.ISOLATE_POLYFILLS ? d.polyfillIsolated(t, e, i, o) : d.polyfillUnisolated(t, e, i, o));
      }, d.polyfillUnisolated = function(t, e) {
        var i = d.global;
        t = t.split(".");
        for (var o = 0; o < t.length - 1; o++) {
          var s = t[o];
          if (!(s in i)) return;
          i = i[s];
        }
        t = t[t.length - 1], o = i[t], e = e(o), e != o && e != null && d.defineProperty(i, t, { configurable: !0, writable: !0, value: e });
      }, d.polyfillIsolated = function(t, e, i) {
        var o = t.split(".");
        t = o.length === 1;
        var s = o[0];
        s = !t && s in d.polyfills ? d.polyfills : d.global;
        for (var n = 0; n < o.length - 1; n++) {
          var l = o[n];
          if (!(l in s)) return;
          s = s[l];
        }
        o = o[o.length - 1], i = d.IS_SYMBOL_NATIVE && i === "es6" ? s[o] : null, e = e(i), e != null && (t ? d.defineProperty(d.polyfills, o, { configurable: !0, writable: !0, value: e }) : e !== i && (d.propertyToPolyfillSymbol[o] === void 0 && (t = Math.random() * 1e9 >>> 0, d.propertyToPolyfillSymbol[o] = d.IS_SYMBOL_NATIVE ? d.global.Symbol(o) : d.POLYFILL_PREFIX + t + "$" + o), d.defineProperty(s, d.propertyToPolyfillSymbol[o], { configurable: !0, writable: !0, value: e })));
      }, d.getConstructImplementation = function() {
        function t() {
          function i() {
          }
          return Reflect.construct(i, [], function() {
          }), new i() instanceof i;
        }
        if (d.TRUST_ES6_POLYFILLS && typeof Reflect < "u" && Reflect.construct) {
          if (t()) return Reflect.construct;
          var e = Reflect.construct;
          return function(i, o, s) {
            return i = e(i, o), s && Reflect.setPrototypeOf(i, s.prototype), i;
          };
        }
        return function(i, o, s) {
          return s === void 0 && (s = i), s = d.objectCreate(s.prototype || Object.prototype), Function.prototype.apply.call(i, s, o) || s;
        };
      }, d.construct = { valueOf: d.getConstructImplementation }.valueOf(), d.underscoreProtoCanBeSet = function() {
        var t = { a: !0 }, e = {};
        try {
          return e.__proto__ = t, e.a;
        } catch {
        }
        return !1;
      }, d.setPrototypeOf = d.ASSUME_ES6 || d.TRUST_ES6_POLYFILLS && typeof Object.setPrototypeOf == "function" ? Object.setPrototypeOf : d.underscoreProtoCanBeSet() ? function(t, e) {
        if (t.__proto__ = e, t.__proto__ !== e) throw new TypeError(t + " is not extensible");
        return t;
      } : null, d.inherits = function(t, e) {
        if (t.prototype = d.objectCreate(e.prototype), t.prototype.constructor = t, d.ASSUME_ES6 || d.setPrototypeOf) {
          var i = d.setPrototypeOf;
          i(t, e);
        } else for (i in e) if (i != "prototype") if (Object.defineProperties) {
          var o = Object.getOwnPropertyDescriptor(e, i);
          o && Object.defineProperty(t, i, o);
        } else t[i] = e[i];
        t.superClass_ = e.prototype;
      }, d.arrayIteratorImpl = function(t) {
        var e = 0;
        return function() {
          return e < t.length ? { done: !1, value: t[e++] } : { done: !0 };
        };
      }, d.arrayIterator = function(t) {
        return { next: d.arrayIteratorImpl(t) };
      }, d.makeIterator = function(t) {
        var e = typeof Symbol < "u" && Symbol.iterator && t[Symbol.iterator];
        if (e) return e.call(t);
        if (typeof t.length == "number") return d.arrayIterator(t);
        throw Error(String(t) + " is not an iterable or ArrayLike");
      }, d.arrayFromIterator = function(t) {
        for (var e, i = []; !(e = t.next()).done; ) i.push(e.value);
        return i;
      }, d.arrayFromIterable = function(t) {
        return t instanceof Array ? t : d.arrayFromIterator(d.makeIterator(t));
      }, d.generator = {}, d.generator.ensureIteratorResultIsObject_ = function(t) {
        if (!(t instanceof Object)) throw new TypeError("Iterator result " + t + " is not an object");
      }, d.generator.Context = function() {
        this.isRunning_ = !1, this.yieldAllIterator_ = null, this.yieldResult = void 0, this.nextAddress = 1, this.finallyAddress_ = this.catchAddress_ = 0, this.finallyContexts_ = this.abruptCompletion_ = null;
      }, d.generator.Context.prototype.start_ = function() {
        if (this.isRunning_) throw new TypeError("Generator is already running");
        this.isRunning_ = !0;
      }, d.generator.Context.prototype.stop_ = function() {
        this.isRunning_ = !1;
      }, d.generator.Context.prototype.jumpToErrorHandler_ = function() {
        this.nextAddress = this.catchAddress_ || this.finallyAddress_;
      }, d.generator.Context.prototype.next_ = function(t) {
        this.yieldResult = t;
      }, d.generator.Context.prototype.throw_ = function(t) {
        this.abruptCompletion_ = { exception: t, isException: !0 }, this.jumpToErrorHandler_();
      }, d.generator.Context.prototype.getNextAddressJsc = function() {
        return this.nextAddress;
      }, d.generator.Context.prototype.getNextAddressJsc = function() {
        return this.nextAddress;
      }, d.generator.Context.prototype.getYieldResultJsc = function() {
        return this.yieldResult;
      }, d.generator.Context.prototype.getYieldResultJsc = function() {
        return this.yieldResult;
      }, d.generator.Context.prototype.return = function(t) {
        this.abruptCompletion_ = { return: t }, this.nextAddress = this.finallyAddress_;
      }, d.generator.Context.prototype.return = d.generator.Context.prototype.return, d.generator.Context.prototype.jumpThroughFinallyBlocks = function(t) {
        this.abruptCompletion_ = { jumpTo: t }, this.finallyAddress_ < t ? (this.nextAddress = t, this.abruptCompletion_ = null) : this.nextAddress = this.finallyAddress_;
      }, d.generator.Context.prototype.jumpThroughFinallyBlocks = d.generator.Context.prototype.jumpThroughFinallyBlocks, d.generator.Context.prototype.yield = function(t, e) {
        return this.nextAddress = e, { value: t };
      }, d.generator.Context.prototype.yield = d.generator.Context.prototype.yield, d.generator.Context.prototype.yieldAll = function(t, e) {
        t = d.makeIterator(t);
        var i = t.next();
        if (d.generator.ensureIteratorResultIsObject_(i), i.done) this.yieldResult = i.value, this.nextAddress = e;
        else return this.yieldAllIterator_ = t, this.yield(i.value, e);
      }, d.generator.Context.prototype.yieldAll = d.generator.Context.prototype.yieldAll, d.generator.Context.prototype.jumpTo = function(t) {
        this.nextAddress = t;
      }, d.generator.Context.prototype.jumpTo = d.generator.Context.prototype.jumpTo, d.generator.Context.prototype.jumpToEnd = function() {
        this.nextAddress = 0;
      }, d.generator.Context.prototype.jumpToEnd = d.generator.Context.prototype.jumpToEnd, d.generator.Context.prototype.setCatchFinallyBlocks = function(t, e) {
        this.catchAddress_ = t, e != null && (this.finallyAddress_ = e);
      }, d.generator.Context.prototype.setCatchFinallyBlocks = d.generator.Context.prototype.setCatchFinallyBlocks, d.generator.Context.prototype.setFinallyBlock = function(t) {
        this.catchAddress_ = 0, this.finallyAddress_ = t || 0;
      }, d.generator.Context.prototype.setFinallyBlock = d.generator.Context.prototype.setFinallyBlock, d.generator.Context.prototype.leaveTryBlock = function(t, e) {
        this.nextAddress = t, this.catchAddress_ = e || 0;
      }, d.generator.Context.prototype.leaveTryBlock = d.generator.Context.prototype.leaveTryBlock, d.generator.Context.prototype.enterCatchBlock = function(t) {
        return this.catchAddress_ = t || 0, t = this.abruptCompletion_.exception, this.abruptCompletion_ = null, t;
      }, d.generator.Context.prototype.enterCatchBlock = d.generator.Context.prototype.enterCatchBlock, d.generator.Context.prototype.enterFinallyBlock = function(t, e, i) {
        i ? this.finallyContexts_[i] = this.abruptCompletion_ : this.finallyContexts_ = [this.abruptCompletion_], this.catchAddress_ = t || 0, this.finallyAddress_ = e || 0, this.abruptCompletion_ = null;
      }, d.generator.Context.prototype.enterFinallyBlock = d.generator.Context.prototype.enterFinallyBlock, d.generator.Context.prototype.leaveFinallyBlock = function(t, e) {
        if (e = this.finallyContexts_.splice(e || 0)[0], e = this.abruptCompletion_ = this.abruptCompletion_ || e) {
          if (e.isException) return this.jumpToErrorHandler_();
          e.jumpTo != null && this.finallyAddress_ < e.jumpTo ? (this.nextAddress = e.jumpTo, this.abruptCompletion_ = null) : this.nextAddress = this.finallyAddress_;
        } else this.nextAddress = t;
      }, d.generator.Context.prototype.leaveFinallyBlock = d.generator.Context.prototype.leaveFinallyBlock, d.generator.Context.prototype.forIn = function(t) {
        return new d.generator.Context.PropertyIterator(t);
      }, d.generator.Context.prototype.forIn = d.generator.Context.prototype.forIn, d.generator.Context.PropertyIterator = function(t) {
        this.object_ = t, this.properties_ = [];
        for (var e in t) this.properties_.push(e);
        this.properties_.reverse();
      }, d.generator.Context.PropertyIterator.prototype.getNext = function() {
        for (; this.properties_.length > 0; ) {
          var t = this.properties_.pop();
          if (t in this.object_) return t;
        }
        return null;
      }, d.generator.Context.PropertyIterator.prototype.getNext = d.generator.Context.PropertyIterator.prototype.getNext, d.generator.Engine_ = function(t) {
        this.context_ = new d.generator.Context(), this.program_ = t;
      }, d.generator.Engine_.prototype.next_ = function(t) {
        return this.context_.start_(), this.context_.yieldAllIterator_ ? this.yieldAllStep_(this.context_.yieldAllIterator_.next, t, this.context_.next_) : (this.context_.next_(t), this.nextStep_());
      }, d.generator.Engine_.prototype.return_ = function(t) {
        this.context_.start_();
        var e = this.context_.yieldAllIterator_;
        return e ? this.yieldAllStep_("return" in e ? e.return : function(i) {
          return { value: i, done: !0 };
        }, t, this.context_.return) : (this.context_.return(t), this.nextStep_());
      }, d.generator.Engine_.prototype.throw_ = function(t) {
        if (this.context_.start_(), this.context_.yieldAllIterator_) {
          var e = this.context_.yieldAllIterator_.throw;
          if (e) return this.yieldAllStep_(e, t, this.context_.next_);
          t = this.context_.yieldAllIterator_, this.context_.yieldAllIterator_ = null;
          try {
            if (t.return) {
              var i = t.return();
              d.generator.ensureIteratorResultIsObject_(i);
            }
            this.context_.throw_(new TypeError("The iterator does not provide a 'throw' method."));
          } catch (o) {
            this.context_.throw_(o);
          }
          return this.nextStep_();
        }
        return this.context_.throw_(t), this.nextStep_();
      }, d.generator.Engine_.prototype.yieldAllStep_ = function(t, e, i) {
        try {
          var o = t.call(this.context_.yieldAllIterator_, e);
          if (d.generator.ensureIteratorResultIsObject_(o), !o.done) return this.context_.stop_(), o;
          var s = o.value;
        } catch (n) {
          return this.context_.yieldAllIterator_ = null, this.context_.throw_(n), this.nextStep_();
        }
        return this.context_.yieldAllIterator_ = null, i.call(this.context_, s), this.nextStep_();
      }, d.generator.Engine_.prototype.nextStep_ = function() {
        for (; this.context_.nextAddress; ) try {
          var t = this.program_(this.context_);
          if (t) return this.context_.stop_(), { value: t.value, done: !1 };
        } catch (e) {
          this.context_.yieldResult = void 0, this.context_.throw_(e);
        }
        if (this.context_.stop_(), this.context_.abruptCompletion_) {
          if (t = this.context_.abruptCompletion_, this.context_.abruptCompletion_ = null, t.isException) throw t.exception;
          return { value: t.return, done: !0 };
        }
        return { value: void 0, done: !0 };
      }, d.generator.Generator_ = function(t) {
        this.next = function(e) {
          return t.next_(e);
        }, this.throw = function(e) {
          return t.throw_(e);
        }, this.return = function(e) {
          return t.return_(e);
        }, this[Symbol.iterator] = function() {
          return this;
        };
      }, d.generator.createGenerator = function(t, e) {
        return e = new d.generator.Generator_(new d.generator.Engine_(e)), d.setPrototypeOf && t.prototype && d.setPrototypeOf(e, t.prototype), e;
      }, d.asyncExecutePromiseGenerator = function(t) {
        function e(o) {
          return t.next(o);
        }
        function i(o) {
          return t.throw(o);
        }
        return new Promise(function(o, s) {
          function n(l) {
            l.done ? o(l.value) : Promise.resolve(l.value).then(e, i).then(n, s);
          }
          n(t.next());
        });
      }, d.asyncExecutePromiseGeneratorFunction = function(t) {
        return d.asyncExecutePromiseGenerator(t());
      }, d.asyncExecutePromiseGeneratorProgram = function(t) {
        return d.asyncExecutePromiseGenerator(new d.generator.Generator_(new d.generator.Engine_(t)));
      }, d.polyfill("globalThis", function(t) {
        return t || d.global;
      }, "es_2020", "es3"), d.polyfill("Array.prototype.includes", function(t) {
        return t || function(e, i) {
          var o = this;
          o instanceof String && (o = String(o));
          var s = o.length;
          for (i = i || 0, i < 0 && (i = Math.max(i + s, 0)); i < s; i++) {
            var n = o[i];
            if (n === e || Object.is(n, e)) return !0;
          }
          return !1;
        };
      }, "es7", "es3"), d.owns = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
      }, d.polyfill("Object.values", function(t) {
        return t || function(e) {
          var i = [], o;
          for (o in e) d.owns(e, o) && i.push(e[o]);
          return i;
        };
      }, "es8", "es3"), d.checkEs6ConformanceViaProxy = function() {
        try {
          var t = {}, e = Object.create(new d.global.Proxy(t, { get: function(i, o, s) {
            return i == t && o == "q" && s == e;
          } }));
          return e.q === !0;
        } catch {
          return !1;
        }
      }, d.USE_PROXY_FOR_ES6_CONFORMANCE_CHECKS = !1, d.ES6_CONFORMANCE = d.USE_PROXY_FOR_ES6_CONFORMANCE_CHECKS && d.checkEs6ConformanceViaProxy(), d.initSymbol = function() {
      }, d.iteratorPrototype = function(t) {
        return t = { next: t }, t[Symbol.iterator] = function() {
          return this;
        }, t;
      }, d.MapEntry = function() {
      }, d.polyfill("Set.prototype.difference", function(t) {
        return t || function(e) {
          d.checkIsSetInstance(this), d.checkIsSetLike(e);
          var i = d.getSmallerAndLargerSets(this, e);
          e = new Set(this);
          var o = i.smallerSetIterator;
          i = i.largerSet;
          for (var s = o.next(); !s.done; ) i.has(s.value) && e.delete(s.value), s = o.next();
          return e;
        };
      }, "es_next", "es6"), d.checkIsSetLike = function(t) {
        if (typeof t != "object" || t === null || typeof t.size != "number" || t.size < 0 || typeof t.keys != "function" || typeof t.has != "function") throw new TypeError("Argument must be set-like");
      }, d.checkIsValidIterator = function(t) {
        if (typeof t != "object" || t === null || typeof t.next != "function") throw new TypeError("Invalid iterator.");
        return t;
      }, d.getSmallerAndLargerSets = function(t, e) {
        return t.size <= e.size ? { smallerSetIterator: t.keys(), largerSet: e } : { smallerSetIterator: d.checkIsValidIterator(e.keys()), largerSet: t };
      }, d.checkIsSetInstance = function(t) {
        if (!(t instanceof Set)) throw new TypeError("Method must be called on an instance of Set.");
      }, d.iteratorFromArray = function(t, e) {
        if (d.ASSUME_ES6) return t[Symbol.iterator]();
        t instanceof String && (t += "");
        var i = 0, o = !1, s = { next: function() {
          if (!o && i < t.length) {
            var n = i++;
            return { value: e(n, t[n]), done: !1 };
          }
          return o = !0, { done: !0, value: void 0 };
        } };
        return s[Symbol.iterator] = function() {
          return s;
        }, s;
      }, d.polyfill("Array.prototype.values", function(t) {
        return t || function() {
          return d.iteratorFromArray(this, function(e, i) {
            return i;
          });
        };
      }, "es8", "es3"), d.polyfill("Array.prototype.flatMap", function(t) {
        return t || function(e, i) {
          var o = [];
          return Array.prototype.forEach.call(this, function(s, n, l) {
            s = e.call(i, s, n, l), Array.isArray(s) ? o.push.apply(o, s) : o.push(s);
          }), o;
        };
      }, "es9", "es5"), d.polyfill("Array.prototype.flat", function(t) {
        return t || function(e) {
          e = e === void 0 ? 1 : e;
          var i = [];
          return Array.prototype.forEach.call(this, function(o) {
            Array.isArray(o) && e > 0 ? (o = Array.prototype.flat.call(o, e - 1), i.push.apply(i, o)) : i.push(o);
          }), i;
        };
      }, "es9", "es5"), d.polyfill("Object.entries", function(t) {
        return t || function(e) {
          var i = [], o;
          for (o in e) d.owns(e, o) && i.push([o, e[o]]);
          return i;
        };
      }, "es8", "es3");
      var Ed = "ontouchstart" in globalThis || !!(globalThis.document && document.documentElement && "ontouchstart" in document.documentElement) || !(!globalThis.navigator || !globalThis.navigator.maxTouchPoints && !globalThis.navigator.msMaxTouchPoints), Ft = null, Yi = { mousedown: ["pointerdown"], mouseenter: ["pointerenter"], mouseleave: ["pointerleave"], mousemove: ["pointermove"], mouseout: ["pointerout"], mouseover: ["pointerover"], mouseup: ["pointerup", "pointercancel"], touchend: ["pointerup"], touchcancel: ["pointercancel"] }, ur = 0, ji = { TOUCH_ENABLED: Ed, TOUCH_MAP: Yi };
      ji.checkTouchIdentifier = ul, ji.clearTouchIdentifier = function() {
        Ft = null;
      }, ji.getTouchIdentifierFromEvent = mo, ji.longStart = ls, ji.longStop = Se, ji.shouldHandleEvent = as;
      var hc, vd, _d, md, dr, gr, cc, Td, Cd, yd;
      (function(t) {
        function e(o) {
          return i.includes(o.toUpperCase());
        }
        hc = t;
        var i = hc.toUpperCase();
        vd = e("JavaFX"), _d = e("WebKit"), md = e("Gecko") && !_d, dr = e("Android"), t = globalThis.navigator && globalThis.navigator.maxTouchPoints, gr = e("iPad") || e("Macintosh") && t > 0, cc = e("iPhone") && !gr, Td = e("Macintosh"), Cd = gr || dr && !e("Mobile") || e("Silk"), yd = !Cd && (cc || dr);
      })(globalThis.navigator && globalThis.navigator.userAgent || "");
      var bd = vd, kd = md, wd = dr, Ms = gr, pr = cc, Fo = Td, uc = yd, Ho = Fo || Ms || pr, cf = { ANDROID: wd, APPLE: Ho, GECKO: kd, IPAD: Ms, IPHONE: pr, JavaFx: bd, MAC: Fo, MOBILE: uc, raw: hc }, Ze = {};
      Ze.bind = jt, Ze.conditionalBind = M, Ze.getScrollDeltaPixels = cs, Ze.isRightButton = _e, Ze.isTargetInput = hs, Ze.mouseToSvg = To, Ze.unbind = $;
      var Id = {};
      Id.removeElem = Qt;
      var me = class {
        constructor(t) {
          this.name = t;
        }
        toString() {
          return this.name;
        }
      };
      me.POSITIONABLE = new me("positionable"), me.DRAG_TARGET = new me("drag_target"), me.DELETE_AREA = new me("delete_area"), me.AUTOHIDEABLE = new me("autohideable"), me.FOCUSABLE = new me("focusable");
      var nt = class {
        constructor() {
          this.componentData = /* @__PURE__ */ new Map(), this.capabilityToComponentIds = /* @__PURE__ */ new Map();
        }
        addComponent(t, e) {
          var i = t.component.id;
          if (!e && this.componentData.has(i)) {
            var o;
            throw Error('Plugin "' + i + '" with capabilities "' + ((o = this.componentData.get(i)) == null ? void 0 : o.capabilities) + '" already added.');
          }
          for (this.componentData.set(i, t), e = [], o = 0; o < t.capabilities.length; o++) {
            let s = String(t.capabilities[o]).toLowerCase();
            if (e.push(s), this.capabilityToComponentIds.has(s)) {
              let n;
              (n = this.capabilityToComponentIds.get(s)) == null || n.push(i);
            } else this.capabilityToComponentIds.set(s, [i]);
          }
          this.componentData.get(i).capabilities = e;
        }
        removeComponent(t) {
          var e = this.componentData.get(t);
          if (e) {
            for (let i = 0; i < e.capabilities.length; i++) {
              let o = String(e.capabilities[i]).toLowerCase();
              Qt(this.capabilityToComponentIds.get(o), t);
            }
            this.componentData.delete(t);
          }
        }
        addCapability(t, e) {
          if (!this.getComponent(t)) throw Error('Cannot add capability, "' + e + '". Plugin "' + t + '" has not been added to the ComponentManager');
          if (this.hasCapability(t, e)) console.warn('Plugin "' + t + 'already has capability "' + e + '"');
          else {
            e = `${e}`.toLowerCase();
            var i;
            (i = this.componentData.get(t)) == null || i.capabilities.push(e);
            var o;
            (o = this.capabilityToComponentIds.get(e)) == null || o.push(t);
          }
        }
        removeCapability(t, e) {
          if (!this.getComponent(t)) throw Error('Cannot remove capability, "' + e + '". Plugin "' + t + '" has not been added to the ComponentManager');
          this.hasCapability(t, e) ? (e = `${e}`.toLowerCase(), Qt(this.componentData.get(t).capabilities, e), Qt(this.capabilityToComponentIds.get(e), t)) : console.warn('Plugin "' + t + `doesn't have capability "` + e + '" to remove');
        }
        hasCapability(t, e) {
          return e = `${e}`.toLowerCase(), this.componentData.has(t) && this.componentData.get(t).capabilities.includes(e);
        }
        getComponent(t) {
          var e;
          return (e = this.componentData.get(t)) == null ? void 0 : e.component;
        }
        getComponents(t, e) {
          if (t = `${t}`.toLowerCase(), t = this.capabilityToComponentIds.get(t), !t) return [];
          var i = [];
          if (e) {
            let o = [];
            t.forEach((s) => {
              o.push(this.componentData.get(s));
            }), o.sort(function(s, n) {
              return s.weight - n.weight;
            }), o.forEach(function(s) {
              i.push(s.component);
            });
          } else t.forEach((o) => {
            i.push(this.componentData.get(o).component);
          });
          return i;
        }
      };
      nt.Capability = me;
      var Sd = nt || (nt = {}), _i = Sd.ComponentWeight || (Sd.ComponentWeight = {});
      _i[_i.TOOLBOX_WEIGHT = 0] = "TOOLBOX_WEIGHT", _i[_i.FLYOUT_WEIGHT = 1] = "FLYOUT_WEIGHT", _i[_i.TRASHCAN_WEIGHT = 2] = "TRASHCAN_WEIGHT", _i[_i.ZOOM_CONTROLS_WEIGHT = 3] = "ZOOM_CONTROLS_WEIGHT";
      var Rd = /* @__PURE__ */ new WeakSet(), Ad = [], uf = `
:is(
  .injectionDiv,
  .blocklyWidgetDiv,
  .blocklyDropdownDiv,
  .blocklyTooltipDiv,
) * {
  box-sizing: border-box;
}

.blocklySvg {
  background-color: #fff;
  outline: none;
  overflow: hidden;  /* IE overflows by default. */
  position: absolute;
  display: block;
}

.blocklyWidgetDiv {
  display: none;
  position: absolute;
  z-index: 99999;  /* big value for bootstrap3 compatibility */
}

.injectionDiv {
  height: 100%;
  position: relative;
  overflow: hidden;  /* So blocks in drag surface disappear at edges */
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
}

.blocklyBlockCanvas.blocklyCanvasTransitioning,
.blocklyBubbleCanvas.blocklyCanvasTransitioning {
  transition: transform .5s;
}

.blocklyEmboss {
  filter: var(--blocklyEmbossFilter);
}

.blocklyTooltipDiv {
  background-color: #ffffc7;
  border: 1px solid #ddc;
  box-shadow: 4px 4px 20px 1px rgba(0,0,0,.15);
  color: #000;
  display: none;
  font: 9pt sans-serif;
  opacity: .9;
  padding: 2px;
  position: absolute;
  z-index: 100000;  /* big value for bootstrap3 compatibility */
}

.blocklyDropDownDiv {
  position: absolute;
  left: 0;
  top: 0;
  z-index: 1000;
  visibility: hidden;
  border: 1px solid;
  border-color: #dadce0;
  background-color: #fff;
  border-radius: 2px;
  padding: 4px;
  box-shadow: 0 0 3px 1px rgba(0,0,0,.3);
}

.blocklyDropDownDiv:focus {
  box-shadow: 0 0 6px 1px rgba(0,0,0,.3);
}

.blocklyDropDownContent {
  max-height: 300px;  /* @todo: spec for maximum height. */
}

.blocklyDropDownArrow {
  position: absolute;
  left: 0;
  top: 0;
  width: 16px;
  height: 16px;
  z-index: -1;
  background-color: inherit;
  border-color: inherit;
  border-top: 1px solid;
  border-left: 1px solid;
  border-top-left-radius: 4px;
  border-color: inherit;
}

.blocklyHighlighted>.blocklyPath {
  filter: var(--blocklyEmbossFilter);
}

.blocklyHighlightedConnectionPath {
  fill: none;
}

.blocklyHighlightedConnectionPathVisible {
  stroke: #fc3;
  stroke-width: 4px;
}

.blocklyPathLight {
  fill: none;
  stroke-linecap: round;
  stroke-width: 1;
}

.blocklySelected>.blocklyPathLight {
  display: none;
}

.blocklyDraggable {
  cursor: grab;
  cursor: -webkit-grab;
}

.blocklyDragging {
  cursor: grabbing;
  cursor: -webkit-grabbing;
  /* Drag surface disables events to not block the toolbox, so we have to
   * reenable them here for the cursor values to work. */
  pointer-events: auto;
}

  /* Changes cursor on mouse down. Not effective in Firefox because of
     https://bugzilla.mozilla.org/show_bug.cgi?id=771241 */
.blocklyDraggable:active {
  cursor: grabbing;
  cursor: -webkit-grabbing;
}

.blocklyDragging.blocklyDraggingDelete,
.blocklyDragging.blocklyDraggingDelete .blocklyField {
  cursor: url("<<<PATH>>>/handdelete.cur"), auto;
}

.blocklyDragging>.blocklyPath,
.blocklyDragging>.blocklyPathLight {
  fill-opacity: .8;
  stroke-opacity: .8;
}

.blocklyDragging>.blocklyPathDark {
  display: none;
}

.blocklyDisabledPattern>.blocklyPath {
  fill: var(--blocklyDisabledPattern);
  fill-opacity: .5;
  stroke-opacity: .5;
}

.blocklyDisabled>.blocklyPathLight,
.blocklyDisabled>.blocklyPathDark {
  display: none;
}

.blocklyInsertionMarker>.blocklyPath,
.blocklyInsertionMarker>.blocklyPathLight,
.blocklyInsertionMarker>.blocklyPathDark {
  fill-opacity: .2;
  stroke: none;
}

.blocklyNonEditableField>text {
  pointer-events: none;
}

.blocklyFlyout {
  position: absolute;
  z-index: 20;
}

.blocklyText text {
  cursor: default;
}

/*
  Don't allow users to select text.  It gets annoying when trying to
  drag a block and selected text moves instead.
*/
.blocklySvg text {
  user-select: none;
  -ms-user-select: none;
  -webkit-user-select: none;
  cursor: inherit;
}

.blocklyIconGroup {
  cursor: default;
}

.blocklyIconGroup:not(:hover):not(:focus),
.blocklyIconGroupReadonly {
  opacity: .6;
}

.blocklyIconShape {
  fill: #00f;
  stroke: #fff;
  stroke-width: 1px;
}

.blocklyIconSymbol {
  fill: #fff;
}

.blocklyMinimalBody {
  margin: 0;
  padding: 0;
  height: 100%;
}

.blocklyHtmlInput {
  border: none;
  border-radius: 4px;
  height: 100%;
  margin: 0;
  outline: none;
  padding: 0;
  width: 100%;
  text-align: center;
  display: block;
  box-sizing: border-box;
}

/* Remove the increase and decrease arrows on the field number editor */
input.blocklyHtmlInput[type=number]::-webkit-inner-spin-button,
input.blocklyHtmlInput[type=number]::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

input[type=number] {
  -moz-appearance: textfield;
}

.blocklyMainBackground {
  stroke-width: 1;
  stroke: #c6c6c6;  /* Equates to #ddd due to border being off-pixel. */
}

.blocklyMutatorBackground {
  fill: #fff;
  stroke: #ddd;
  stroke-width: 1;
}

.blocklyFlyoutBackground {
  fill: #ddd;
  fill-opacity: .8;
}

.blocklyMainWorkspaceScrollbar {
  z-index: 20;
}

.blocklyFlyoutScrollbar {
  z-index: 30;
}

.blocklyScrollbarHorizontal,
.blocklyScrollbarVertical {
  position: absolute;
  outline: none;
}

.blocklyScrollbarBackground {
  opacity: 0;
  pointer-events: none;
}

.blocklyScrollbarHandle {
  fill: #ccc;
}

.blocklyScrollbarBackground:hover+.blocklyScrollbarHandle,
.blocklyScrollbarHandle:hover {
  fill: #bbb;
}

/* Darken flyout scrollbars due to being on a grey background. */
/* By contrast, workspace scrollbars are on a white background. */
.blocklyFlyout .blocklyScrollbarHandle {
  fill: #bbb;
}

.blocklyFlyout .blocklyScrollbarBackground:hover+.blocklyScrollbarHandle,
.blocklyFlyout .blocklyScrollbarHandle:hover {
  fill: #aaa;
}

.blocklyInvalidInput {
  background: #faa;
}

.blocklyVerticalMarker {
  stroke-width: 3px;
  fill: rgba(255,255,255,.5);
  pointer-events: none;
}

.blocklyComputeCanvas {
  position: absolute;
  width: 0;
  height: 0;
}

.blocklyNoPointerEvents {
  pointer-events: none;
}

.blocklyContextMenu {
  border-radius: 4px;
  max-height: 100%;
  box-sizing: content-box;
}

.blocklyDropdownMenu {
  border-radius: 2px;
  padding: 0 !important;
}

.blocklyDropdownMenu .blocklyMenuItem {
  /* 28px on the left for icon or checkbox. */
  padding-left: 28px;
}

/* BiDi override for the resting state. */
.blocklyDropdownMenu .blocklyMenuItemRtl {
  /* Flip left/right padding for BiDi. */
  padding-left: 5px;
  padding-right: 28px;
}

.blocklyWidgetDiv .blocklyMenu {
  user-select: none;
  -ms-user-select: none;
  -webkit-user-select: none;
  background: #fff;
  border: 1px solid transparent;
  box-shadow: 0 0 3px 1px rgba(0,0,0,.3);
  font: normal 13px Arial, sans-serif;
  margin: 0;
  outline: none;
  padding: 4px 0;
  position: absolute;
  overflow-y: auto;
  overflow-x: hidden;
  max-height: 100%;
  z-index: 20000;  /* Arbitrary, but some apps depend on it... */
}

.blocklyWidgetDiv .blocklyMenu:focus {
  box-shadow: 0 0 6px 1px rgba(0,0,0,.3);
}

.blocklyDropDownDiv .blocklyMenu {
  user-select: none;
  -ms-user-select: none;
  -webkit-user-select: none;
  background: inherit;  /* Compatibility with gapi, reset from goog-menu */
  border: inherit;  /* Compatibility with gapi, reset from goog-menu */
  font: normal 13px "Helvetica Neue", Helvetica, sans-serif;
  outline: none;
  overflow-y: auto;
  overflow-x: hidden;
  max-height: 100%;
  z-index: 20000;  /* Arbitrary, but some apps depend on it... */
}

/* State: resting. */
.blocklyMenuItem {
  border: none;
  color: #000;
  cursor: pointer;
  list-style: none;
  margin: 0;
  /* 7em on the right for shortcut. */
  min-width: 7em;
  padding: 6px 15px;
  white-space: nowrap;
}

/* State: disabled. */
.blocklyMenuItemDisabled {
  color: #ccc;
  cursor: inherit;
}

/* State: hover. */
.blocklyMenuItemHighlight {
  background-color: rgba(0,0,0,.1);
}

/* State: selected/checked. */
.blocklyMenuItemSelected .blocklyMenuItemCheckbox {
  background: url(<<<PATH>>>/sprites.svg) no-repeat -48px -16px;
  float: left;
  margin-left: -24px;
  width: 16px;
  height: 16px;
  position: static;  /* Scroll with the menu. */
  display: block;
}

.blocklyMenuItemRtl .blocklyMenuItemCheckbox {
  float: right;
  margin-right: -24px;
}

.blocklyMenuSeparator {
  background-color: #ccc;
  height: 1px;
  border: 0;
  margin-left: 4px;
  margin-right: 4px;
}

.blocklyRTL .blocklyMenuItemContent .blocklyShortcutContainer {
  flex-direction: row-reverse;
}
.blocklyMenuItemContent .blocklyShortcutContainer {
  width: 100%;
  display: flex;
  justify-content: space-between;
  gap: 16px;
}
.blocklyMenuItemContent .blocklyShortcutContainer .blocklyShortcut {
  color: #ccc;
}

.blocklyBlockDragSurface, .blocklyAnimationLayer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  overflow: visible !important;
  z-index: 80;
  pointer-events: none;
}

.blocklyField {
  cursor: default;
}

.blocklyInputField {
  cursor: text;
}

.blocklyDragging .blocklyField,
.blocklyDragging .blocklyIconGroup {
  cursor: grabbing;
}

.blocklyActiveFocus:is(
  .blocklyFlyout,
  .blocklyWorkspace,
  .blocklyWorkspaceSelectionRing,
  .blocklyField,
  .blocklyPath,
  .blocklyHighlightedConnectionPath,
  .blocklyComment,
  .blocklyBubble,
  .blocklyIconGroup,
  .blocklyTextarea,
),
.blocklyZoom:focus,
.blocklyTrash:focus {
  outline: none;
}
.hiddenForAria {
  position: absolute;
  left: -9999px;
  width: 1px;
  height: 1px;
  overflow: hidden;
}

.injectionDiv {
  --blockly-active-node-color: #fff200;
  --blockly-active-tree-color: #1379f6;
  --blockly-selection-width: 3px;
}

/* Active focus cases: */
/* Blocks with active focus. */
.blocklyKeyboardNavigation
  .blocklyActiveFocus:is(.blocklyPath, .blocklyHighlightedConnectionPath),
/* Fields with active focus, */
.blocklyKeyboardNavigation
  .blocklyActiveFocus.blocklyField
  > .blocklyFieldRect,
/* Icons with active focus. */
.blocklyKeyboardNavigation
  .blocklyActiveFocus.blocklyIconGroup
  > .blocklyIconShape:first-child,
.blocklyKeyboardNavigation
  .blocklyActiveFocus
  > .blocklyFocusRing,
.blocklyTrash:focus-visible > .blocklyFocusRing,
.blocklyZoom:focus-visible > .blocklyFocusRing {
  stroke: var(--blockly-active-node-color);
  stroke-width: var(--blockly-selection-width);
}

/* Passive focus cases: */
/* Blocks with passive focus except when widget/dropdown div in use. */
.blocklyKeyboardNavigation:not(
        :has(
            .blocklyDropDownDiv:focus-within,
            .blocklyWidgetDiv:focus-within
          )
      )
  .blocklyPassiveFocus:is(
    .blocklyPath:not(.blocklyFlyout .blocklyPath),
    .blocklyHighlightedConnectionPath
  ),
/* Fields with passive focus except when widget/dropdown div in use. */
.blocklyKeyboardNavigation:not(
        :has(
            .blocklyDropDownDiv:focus-within,
            .blocklyWidgetDiv:focus-within
          )
      )
  .blocklyPassiveFocus.blocklyField
  > .blocklyFieldRect,
/* Icons with passive focus except when widget/dropdown div in use. */
.blocklyKeyboardNavigation:not(
        :has(
            .blocklyDropDownDiv:focus-within,
            .blocklyWidgetDiv:focus-within
          )
      )
  .blocklyPassiveFocus.blocklyIconGroup
  > .blocklyIconShape:first-child {
  stroke: var(--blockly-active-node-color);
  stroke-dasharray: 5px 3px;
  stroke-width: var(--blockly-selection-width);
}

/* Different ways for toolbox/flyout to be the active tree: */
/* Active focus in the flyout. */
.blocklyKeyboardNavigation .blocklyFlyout:has(.blocklyActiveFocus),
/* Active focus in the toolbox. */
.blocklyKeyboardNavigation .blocklyToolbox:has(.blocklyActiveFocus),
/* Active focus on the toolbox/flyout. */
.blocklyKeyboardNavigation
  .blocklyActiveFocus:is(.blocklyFlyout, .blocklyToolbox) {
  outline-offset: calc(var(--blockly-selection-width) * -1);
  outline: var(--blockly-selection-width) solid
    var(--blockly-active-tree-color);
}

/* Suppress default outline. */
.blocklyKeyboardNavigation
  .blocklyToolboxCategoryContainer:focus-visible {
  outline: none;
}

 /* Different ways for the workspace to be the active tree: */
/* Active focus within workspace. */
.blocklyKeyboardNavigation
  .blocklyWorkspace:has(.blocklyActiveFocus)
  .blocklyWorkspaceFocusRing,
/* Active focus within drag layer. */
.blocklyKeyboardNavigation
  .blocklySvg:has(~ .blocklyBlockDragSurface .blocklyActiveFocus)
  .blocklyWorkspaceFocusRing,
/* Active focus on workspace. */
.blocklyKeyboardNavigation
  .blocklyWorkspace.blocklyActiveFocus
  .blocklyWorkspaceFocusRing,
/* Focus in widget/dropdown div considered to be in workspace. */
  .blocklyKeyboardNavigation
  .blocklyWorkspace.blocklyShowingDropDownDiv
  .blocklyWorkspaceFocusRing,
.blocklyKeyboardNavigation
  .blocklyWorkspace.blocklyShowingWidgetDiv
  .blocklyWorkspaceFocusRing {
  stroke: var(--blockly-active-tree-color);
  stroke-width: calc(var(--blockly-selection-width) * 2);
}

/* The region itself is the active node (e.g. focused by clicking the
   background). */
.blocklyKeyboardNavigation
  .blocklyWorkspace.blocklyActiveFocus
  .blocklyWorkspaceSelectionRing,
/* The selection ring itself is the active node (it doubles as the workspace's
   keyboard focus target). */
.blocklyKeyboardNavigation
  .blocklyWorkspaceSelectionRing.blocklyActiveFocus {
  stroke: var(--blockly-active-node-color);
  stroke-width: var(--blockly-selection-width);
}

/* The selection ring is a decorative highlight that can also be the workspace's
   focus target; either way it should never intercept pointer events. */
.blocklyWorkspaceSelectionRing {
  pointer-events: none;
}

/* The workspace itself is the active node. */
.blocklyKeyboardNavigation
  .blocklyBubble.blocklyActiveFocus
  .blocklyEmboss .blocklyDraggable {
  stroke: var(--blockly-active-node-color);
  stroke-width: var(--blockly-selection-width);
}
/* Flyout buttons and labels */
.blocklyKeyboardNavigation .blocklyFlyout .blocklyFlyoutLabel.blocklyActiveFocus,
.blocklyKeyboardNavigation .blocklyFlyout .blocklyFlyoutButton.blocklyActiveFocus {
  outline: none;
}
.blocklyKeyboardNavigation .blocklyFlyout .blocklyFlyoutLabel.blocklyActiveFocus > .blocklyFlyoutLabelText,
.blocklyKeyboardNavigation .blocklyFlyout .blocklyFlyoutButton.blocklyActiveFocus > .blocklyFlyoutButtonBackground {
  outline-offset: 2px;
  outline: var(--blockly-selection-width) solid var(--blockly-active-node-color);
  border-radius: 2px;
}
.blocklyDialog {
  min-width: 300px;
  border-radius: 16px;
  box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
  border: 1px solid #999;
}
.blocklyDialogForm {
  display: flex;
  flex-direction: column;
  row-gap: 8px;
}
.blocklyDialogButtonRow {
  display: flex;
  flex-direction: ${uc || Ho ? "row-reverse" : "row"};
  column-gap: 8px;
}
`, dc = {};
      dc.inject = dl, dc.register = ce;
      var p, it = p || (p = {});
      it.BLOCK_CREATE = "create", it.BLOCK_DELETE = "delete", it.BLOCK_CHANGE = "change", it.BLOCK_FIELD_INTERMEDIATE_CHANGE = "block_field_intermediate_change", it.BLOCK_MOVE = "move", it.VAR_CREATE = "var_create", it.VAR_DELETE = "var_delete", it.VAR_RENAME = "var_rename", it.VAR_TYPE_CHANGE = "var_type_change", it.UI = "ui", it.BLOCK_DRAG = "drag", it.SELECTED = "selected", it.CLICK = "click", it.MARKER_MOVE = "marker_move", it.BUBBLE_OPEN = "bubble_open", it.TRASHCAN_OPEN = "trashcan_open", it.TOOLBOX_ITEM_SELECT = "toolbox_item_select", it.THEME_CHANGE = "theme_change", it.VIEWPORT_CHANGE = "viewport_change", it.COMMENT_CREATE = "comment_create", it.COMMENT_DELETE = "comment_delete", it.COMMENT_CHANGE = "comment_change", it.COMMENT_MOVE = "comment_move", it.COMMENT_RESIZE = "comment_resize", it.COMMENT_DRAG = "comment_drag", it.COMMENT_COLLAPSE = "comment_collapse", it.FINISHED_LOADING = "finished_loading";
      var Nd = [p.BLOCK_CREATE, p.BLOCK_MOVE, p.COMMENT_CREATE, p.COMMENT_MOVE], gt = /* @__PURE__ */ Object.create(null), zt, gc = zt || (zt = {});
      gc.ASSERTIVE = "assertive", gc.OFF = "off", gc.POLITE = "polite";
      var Ps = zt.OFF, pc = [], W, rt = W || (W = {});
      rt.APPLICATION = "application", rt.BUTTON = "button", rt.CHECKBOX = "checkbox", rt.DIALOG = "dialog", rt.FIGURE = "figure", rt.GENERIC = "generic", rt.GRID = "grid", rt.GRIDCELL = "gridcell", rt.GROUP = "group", rt.LIST = "list", rt.LISTBOX = "listbox", rt.LISTITEM = "listitem", rt.MENU = "menu", rt.MENUITEM = "menuitem", rt.NONE = "none", rt.OPTION = "option", rt.REGION = "region", rt.ROW = "row", rt.SEARCH = "search", rt.SEPARATOR = "separator", rt.STATUS = "status", rt.TEXTBOX = "textbox", rt.TREE = "tree", rt.TREEITEM = "treeitem";
      var Dd = W.STATUS, y, bt = y || (y = {});
      bt.ACTIVEDESCENDANT = "activedescendant", bt.ATOMIC = "atomic", bt.CHECKED = "checked", bt.CONTROLS = "controls", bt.DISABLED = "disabled", bt.EXPANDED = "expanded", bt.HASPOPUP = "haspopup", bt.HIDDEN = "hidden", bt.INVALID = "invalid", bt.LABEL = "label", bt.LABELLEDBY = "labelledby", bt.LEVEL = "level", bt.LIVE = "live", bt.PRESSED = "pressed", bt.ROLEDESCRIPTION = "roledescription", bt.SELECTED = "selected", bt.VALUEMAX = "valuemax", bt.VALUEMIN = "valuemin", bt.OWNS = "owns";
      var ot, Uo = ot || (ot = {});
      Uo[Uo.TERSE = 0] = "TERSE", Uo[Uo.STANDARD = 1] = "STANDARD", Uo[Uo.LOQUACIOUS = 2] = "LOQUACIOUS";
      var Fs = null, Od, fc = !1, se = {};
      se.LiveRegionAssertiveness = zt, se.Role = W, se.State = y, se.Verbosity = ot, se.announceDynamicAriaState = ue, se.clearState = Co, se.getRole = function(t) {
        return (t = t.getAttribute("role")) && Object.values(W).includes(t) ? t : null;
      }, se.getState = yo, se.initializeGlobalAriaLiveRegion = pl, se.removeRole = gl, se.setRole = G, se.setState = w;
      var g = class {
        constructor(t) {
          this.tagName = t;
        }
        toString() {
          return this.tagName;
        }
      };
      g.ANIMATE = new g("animate"), g.CIRCLE = new g("circle"), g.CLIPPATH = new g("clipPath"), g.DEFS = new g("defs"), g.FECOMPOSITE = new g("feComposite"), g.FECOMPONENTTRANSFER = new g("feComponentTransfer"), g.FEFLOOD = new g("feFlood"), g.FEFUNCA = new g("feFuncA"), g.FEGAUSSIANBLUR = new g("feGaussianBlur"), g.FEPOINTLIGHT = new g("fePointLight"), g.FESPECULARLIGHTING = new g("feSpecularLighting"), g.FILTER = new g("filter"), g.FOREIGNOBJECT = new g("foreignObject"), g.G = new g("g"), g.IMAGE = new g("image"), g.LINE = new g("line"), g.PATH = new g("path"), g.PATTERN = new g("pattern"), g.POLYGON = new g("polygon"), g.RECT = new g("rect"), g.SVG = new g("svg"), g.TEXT = new g("text"), g.TSPAN = new g("tspan");
      var Pe, Wo = Pe || (Pe = {});
      Wo[Wo.ELEMENT_NODE = 1] = "ELEMENT_NODE", Wo[Wo.TEXT_NODE = 3] = "TEXT_NODE", Wo[Wo.COMMENT_NODE = 8] = "COMMENT_NODE";
      var Te = null, Ec = 0, Hs = null, Rt = { HTML_NS: "http://www.w3.org/1999/xhtml" };
      Rt.NodeType = Pe, Rt.SVG_NS = "http://www.w3.org/2000/svg", Rt.XLINK_NS = "http://www.w3.org/1999/xlink", Rt.addClass = b, Rt.createSvgElement = v, Rt.getFastTextWidth = function(t, e, i, o) {
        return ds(t, e + "pt", i, o);
      }, Rt.getFastTextWidthWithSizeString = ds, Rt.getTextWidth = bo, Rt.hasClass = cn, Rt.insertAfter = us, Rt.measureFontMetrics = dn, Rt.removeClass = Y, Rt.removeClasses = hn, Rt.removeNode = Q, Rt.setCssTransform = un, Rt.startTextWidthCache = Li, Rt.stopTextWidthCache = xi;
      var At = class {
        static findFocusedNode(t) {
          var e = t.getRootFocusableNode();
          if (!e.canBeFocused()) return null;
          var i = e.getFocusableElement();
          return cn(i, At.ACTIVE_CLASS_NAME) || cn(i, At.PASSIVE_CSS_CLASS_NAME) || (e = i.querySelector(this.ACTIVE_FOCUS_NODE_CSS_SELECTOR), (e instanceof HTMLElement || e instanceof SVGElement) && (e = At.findFocusableNodeFor(e, t))) ? e : (i = i.querySelector(this.PASSIVE_FOCUS_NODE_CSS_SELECTOR), (i instanceof HTMLElement || i instanceof SVGElement) && (t = At.findFocusableNodeFor(i, t)) ? t : null);
        }
        static findFocusableNodeFor(t, e) {
          if (!t.id || t.id === "null" || e.getNestedTrees().map((s) => At.findFocusableNodeFor(t, s)).findIndex((s) => !!s) !== -1) return null;
          var i = e.getRootFocusableNode();
          if (i.canBeFocused() && t === i.getFocusableElement()) return i;
          var o;
          return (i = (o = e.lookUpFocusableNode(t.id)) != null ? o : null) ? i : (o = t.getAttribute("tabindex"), o !== null && Number(o) >= 0 ? null : (o = t.parentElement) ? At.findFocusableNodeFor(o, e) : null);
        }
      };
      At.ACTIVE_CLASS_NAME = "blocklyActiveFocus", At.PASSIVE_CSS_CLASS_NAME = "blocklyPassiveFocus", At.ACTIVE_FOCUS_NODE_CSS_SELECTOR = `.${At.ACTIVE_CLASS_NAME}`, At.PASSIVE_FOCUS_NODE_CSS_SELECTOR = `.${At.PASSIVE_CSS_CLASS_NAME}`;
      var df = class {
        constructor(t, e) {
          this.tree = t, this.rootShouldBeAutoTabbable = e;
        }
      }, Ht = class {
        constructor(t) {
          this.previouslyFocusedNode = this.focusedNode = null, this.registeredTrees = [], this.isUpdatingFocusedNode = this.recentlyLostAllFocus = this.lockFocusStateChanges = this.currentlyHoldsEphemeralFocus = !1, this.popoverFocusLossHandlers = /* @__PURE__ */ new Set(), this.popoverFocusOutHandler = (i) => {
            i = i.relatedTarget;
            var o;
            if (i === null || i instanceof Node && ((o = this.popoverFocusRoot) == null || !o.contains(i))) for (let s of this.popoverFocusLossHandlers) s();
          };
          var e = (i) => {
            if (!this.isUpdatingFocusedNode) {
              this.recentlyLostAllFocus = !i;
              var o = null;
              if (i instanceof HTMLElement || i instanceof SVGElement) {
                for (var s of this.registeredTrees) if (o = At.findFocusableNodeFor(i, s.tree)) break;
              }
              if (o && o.canBeFocused()) {
                i = o.getFocusableTree();
                let n;
                s = (n = this.focusedNode) == null ? void 0 : n.getFocusableTree(), o === i.getRootFocusableNode() && i !== s ? this.focusTree(i) : this.focusNode(o);
              } else this.defocusCurrentFocusedNode();
            }
          };
          t("focusin", (i) => {
            i instanceof FocusEvent && e(document.activeElement);
          }), t("focusout", (i) => {
            i instanceof FocusEvent && e(i.relatedTarget);
          });
        }
        registerTree(t, e = !1) {
          if (this.ensureManagerIsUnlocked(), this.isRegistered(t)) throw Error(`Attempted to re-register already registered tree: ${t}.`);
          this.registeredTrees.push(new df(t, e));
          var i = t.getRootFocusableNode().getFocusableElement();
          if (!i.id || i.id === "null") throw Error(`Attempting to register a tree with a root element that has an invalid ID: ${t}.`);
          e && (i.tabIndex = 0);
        }
        isRegistered(t) {
          return !!this.lookUpRegistration(t);
        }
        lookUpRegistration(t) {
          var e;
          return (e = this.registeredTrees.find((i) => i.tree === t)) != null ? e : null;
        }
        unregisterTree(t) {
          if (this.ensureManagerIsUnlocked(), !this.isRegistered(t)) throw Error(`Attempted to unregister not registered tree: ${t}.`);
          var e = this.registeredTrees.findIndex((s) => s.tree === t), i = this.registeredTrees[e];
          this.registeredTrees.splice(e, 1), e = At.findFocusedNode(t);
          var o = t.getRootFocusableNode();
          e && this.removeHighlight(e), this.focusedNode !== e && this.focusedNode !== o || this.updateFocusedNode(null), this.removeHighlight(o), i.rootShouldBeAutoTabbable && t.getRootFocusableNode().getFocusableElement().removeAttribute("tabindex");
        }
        getFocusedTree() {
          var t, e;
          return (e = (t = this.focusedNode) == null ? void 0 : t.getFocusableTree()) != null ? e : null;
        }
        getFocusedNode() {
          return this.focusedNode;
        }
        getPreviouslyFocusedNode() {
          return this.previouslyFocusedNode;
        }
        focusTree(t) {
          if (this.ensureManagerIsUnlocked(), !this.isRegistered(t)) throw Error(`Attempted to focus unregistered tree: ${t}.`);
          var e = At.findFocusedNode(t), i = t.getRestoredFocusableNode(e);
          t = t.getRootFocusableNode();
          var o;
          this.focusNode((o = i ?? e) != null ? o : t);
        }
        focusNode(t) {
          this.ensureManagerIsUnlocked();
          var e = !this.currentlyHoldsEphemeralFocus;
          e && (this.isUpdatingFocusedNode = !0);
          var i, o = ((i = this.focusedNode) == null ? void 0 : i.getFocusableElement()) !== document.activeElement;
          if (this.focusedNode !== t || o) if (t.canBeFocused()) {
            if (i = t.getFocusableTree(), !this.isRegistered(i)) throw Error(`Attempted to focus unregistered node: ${t}.`);
            o = t.getFocusableElement(), o.id && o.id !== "null" || console.warn("Trying to focus a node that has an invalid ID.");
            var s = At.findFocusableNodeFor(o, i);
            o = At.findFocusedNode(i);
            var n = t;
            if (s !== t) {
              n = i.getRestoredFocusableNode(o), t = i.getRootFocusableNode();
              var l;
              n = (l = n ?? o) != null ? l : t;
            }
            t = this.focusedNode, l = t?.getFocusableTree(), t && this.passivelyFocusNode(t, i), i = i.getRootFocusableNode(), o && this.removeHighlight(o), i !== n && this.removeHighlight(i), this.currentlyHoldsEphemeralFocus || this.activelyFocusNode(n, l ?? null), this.updateFocusedNode(n);
          } else console.warn("Trying to focus a node that can't be focused.");
          e && (this.isUpdatingFocusedNode = !1);
        }
        takeEphemeralFocus(t) {
          if (this.ensureManagerIsUnlocked(), this.currentlyHoldsEphemeralFocus) throw Error(`Attempted to take ephemeral focus when it's already held, with new element: ${t}.`);
          this.currentlyHoldsEphemeralFocus = !0, this.focusedNode && this.passivelyFocusNode(this.focusedNode, null), t.focus({ preventScroll: !0 });
          var e = !1;
          return (i = !0) => {
            if (e) throw Error(`Attempted to finish ephemeral focus twice for element: ${t}.`);
            if (e = !0, this.currentlyHoldsEphemeralFocus = !1, this.focusedNode && i) {
              this.activelyFocusNode(this.focusedNode, null);
              let o = this.focusedNode;
              setTimeout(() => {
                !this.focusedNode && this.previouslyFocusedNode === o && this.recentlyLostAllFocus && this.focusNode(o);
              }, 0);
            }
          };
        }
        ephemeralFocusTaken() {
          return this.currentlyHoldsEphemeralFocus;
        }
        ensureManagerIsUnlocked() {
          if (this.lockFocusStateChanges) throw Error("FocusManager state changes cannot happen in a tree/node focus/blur callback.");
        }
        updateFocusedNode(t) {
          this.previouslyFocusedNode = this.focusedNode, this.focusedNode = t;
        }
        defocusCurrentFocusedNode() {
          this.focusedNode && !this.currentlyHoldsEphemeralFocus && (this.passivelyFocusNode(this.focusedNode, null), this.updateFocusedNode(null));
        }
        activelyFocusNode(t, e) {
          this.lockFocusStateChanges = !0;
          var i = t.getFocusableTree(), o = t.getFocusableElement(), s, n = (s = this.lookUpRegistration(i)) == null ? void 0 : s.rootShouldBeAutoTabbable;
          i !== e && (i.onTreeFocus(t, e), n && (i.getRootFocusableNode().getFocusableElement().tabIndex = -1)), t.onNodeFocus(), this.lockFocusStateChanges = !1, n && t === i.getRootFocusableNode() || o.hasAttribute("tabindex") || (o.tabIndex = -1), this.setNodeToVisualActiveFocus(t), o.focus({ preventScroll: !0 });
        }
        passivelyFocusNode(t, e) {
          this.lockFocusStateChanges = !0;
          var i = t.getFocusableTree();
          if (i !== e) {
            i.onTreeBlur(e);
            let o;
            (o = this.lookUpRegistration(i)) != null && o.rootShouldBeAutoTabbable && (i.getRootFocusableNode().getFocusableElement().tabIndex = 0);
          }
          t.onNodeBlur(), this.lockFocusStateChanges = !1, i !== e && this.setNodeToVisualPassiveFocus(t);
        }
        setNodeToVisualActiveFocus(t) {
          t = t.getFocusableElement(), b(t, Ht.ACTIVE_FOCUS_NODE_CSS_CLASS_NAME), Y(t, Ht.PASSIVE_FOCUS_NODE_CSS_CLASS_NAME);
        }
        setNodeToVisualPassiveFocus(t) {
          t = t.getFocusableElement(), Y(t, Ht.ACTIVE_FOCUS_NODE_CSS_CLASS_NAME), b(t, Ht.PASSIVE_FOCUS_NODE_CSS_CLASS_NAME);
        }
        removeHighlight(t) {
          t = t.getFocusableElement(), Y(t, Ht.ACTIVE_FOCUS_NODE_CSS_CLASS_NAME), Y(t, Ht.PASSIVE_FOCUS_NODE_CSS_CLASS_NAME);
        }
        static getFocusManager() {
          return Ht.focusManager || (Ht.focusManager = new Ht(document.addEventListener)), Ht.focusManager;
        }
        setPopoverFocusRoot(t) {
          var e;
          (e = this.popoverFocusRoot) == null || e.removeEventListener("focusout", this.popoverFocusOutHandler), this.popoverFocusRoot = t, this.popoverFocusRoot.addEventListener("focusout", this.popoverFocusOutHandler);
        }
        registerPopoverFocusLossHandler(t) {
          this.popoverFocusLossHandlers.add(t);
        }
        unregisterPopoverFocusLossHandler(t) {
          this.popoverFocusLossHandlers.delete(t);
        }
      };
      Ht.ACTIVE_FOCUS_NODE_CSS_CLASS_NAME = "blocklyActiveFocus", Ht.PASSIVE_FOCUS_NODE_CSS_CLASS_NAME = "blocklyPassiveFocus", Ht.focusManager = null;
      var Ld = {};
      Ld.deepMerge = Re;
      var S = class {
        constructor() {
          this.shortcuts = /* @__PURE__ */ new Map(), this.keyMap = /* @__PURE__ */ new Map(), this.reset();
        }
        reset() {
          this.shortcuts.clear(), this.keyMap.clear();
        }
        register(t, e) {
          if (this.shortcuts.get(t.name) && !e) throw Error(`Shortcut named "${t.name}" already exists.`);
          if (this.shortcuts.set(t.name, t), e = t.keyCodes, e != null && e.length) for (let i of e) this.addKeyMapping(i, t.name, !!t.allowCollision);
        }
        unregister(t) {
          return this.shortcuts.get(t) ? (this.removeAllKeyMappings(t), this.shortcuts.delete(t), !0) : (console.warn(`Keyboard shortcut named "${t}" not found.`), !1);
        }
        addKeyMapping(t, e, i) {
          t = `${t}`;
          var o = this.keyMap.get(t);
          if (o && !i) throw Error(`Shortcut named "${e}" collides with shortcuts "${[...o]}"`);
          o && i ? this.keyMap.set(t, /* @__PURE__ */ new Set([e, ...o])) : this.keyMap.set(t, /* @__PURE__ */ new Set([e]));
        }
        removeKeyMapping(t, e, i) {
          var o = this.keyMap.get(t);
          return o ? o.delete(e) ? (o.size === 0 && this.keyMap.delete(t), !0) : (i || console.warn(`No keyboard shortcut named "${e}" registered with key code "${t}"`), !1) : (i || console.warn(`No keyboard shortcut named "${e}" registered with key code "${t}"`), !1);
        }
        removeAllKeyMappings(t) {
          for (let e of this.keyMap.keys()) this.removeKeyMapping(e, t, !0);
        }
        setKeyMap(t) {
          this.keyMap.clear();
          for (let e in t) this.keyMap.set(e, new Set(t[e]));
        }
        getKeyMap() {
          var t = /* @__PURE__ */ Object.create(null);
          for (let [e, i] of this.keyMap) t[e] = [...i];
          return t;
        }
        getRegistry() {
          var t = /* @__PURE__ */ Object.create(null);
          for (let [e, i] of this.shortcuts) t[e] = i;
          return Re(/* @__PURE__ */ Object.create(null), t);
        }
        onKeyDown(t, e) {
          var i = this.serializeKeyEvent(e);
          if (i = this.getShortcutNamesByKeyCode(i), !i) return !1;
          for (let o of i) {
            i = this.shortcuts.get(o);
            let s;
            if (!i || i.preconditionFn && !i.preconditionFn(t, { focusedNode: (s = r.t().getFocusedNode()) != null ? s : void 0 })) continue;
            let n, l;
            if ((n = i.callback) != null && n.call(i, t, e, i, { focusedNode: (l = r.t().getFocusedNode()) != null ? l : void 0 })) return !0;
          }
          return !1;
        }
        getShortcutNamesByKeyCode(t) {
          return (t = this.keyMap.get(t)) ? [...t] : [];
        }
        getKeyCodesByShortcutName(t) {
          var e = [];
          for (let [i, o] of this.keyMap) o.has(t) && e.push(i);
          return e;
        }
        serializeKeyEvent(t) {
          var e = "";
          for (let i in S.modifierKeys) t.getModifierState(i) && (e !== "" && (e += "+"), e += i);
          return e !== "" && t.keyCode ? e += "+" + t.keyCode : t.keyCode && (e = String(t.keyCode)), e;
        }
        checkModifiers(t) {
          for (let e of t) if (!(e in S.modifierKeys)) throw Error(e + " is not a valid modifier key.");
        }
        createSerializedKey(t, e) {
          var i = "";
          if (e) {
            this.checkModifiers(e);
            for (let o in S.modifierKeys) e.includes(S.modifierKeys[o]) && (i !== "" && (i += "+"), i += o);
          }
          return i !== "" && t ? i += "+" + t : t && (i = `${t}`), i;
        }
      };
      S.registry = new S();
      var xd = S || (S = {}), mi = xd.modifierKeys || (xd.modifierKeys = {});
      mi[mi.Shift = 16] = "Shift", mi[mi.Control = 17] = "Control", mi[mi.Alt = 18] = "Alt", mi[mi.Meta = 91] = "Meta";
      var Bd = /* @__PURE__ */ new Set(), Md = {};
      Md.warn = fl;
      var Us = /* @__PURE__ */ Object.create(null), de, vc, Ws = [], Pd = { defineBlocksWithJsonArrayInternal: function(t) {
        r.Ab(r.yb(t));
      } }, Tt = { TEST_ONLY: Pd };
      Tt.createBlockDefinitionsFromJsonArray = r.yb, Tt.defineBlocks = r.Ab, Tt.defineBlocksWithJsonArray = ml, Tt.draggingConnections = Ws, Tt.fireSelectedEvent = ci, Tt.getAllWorkspaces = hi, Tt.getBlockTypeCounts = Es, Tt.getMainWorkspace = vl, Tt.getParentContainer = ui, Tt.getSelected = fs, Tt.getWorkspaceById = ai, Tt.globalShortcutHandler = vs, Tt.registerWorkspace = El, Tt.setMainWorkspace = ps, Tt.setParentContainer = _l, Tt.setSelected = function(t) {
        r.t().focusNode(t);
      }, Tt.svgResize = Bi, Tt.unregisterWorkpace = function(t) {
        fl("Blockly.common.unregisterWorkpace", "v13", "v14", "Blockly.common.unregisterWorkspace"), gn(t);
      }, Tt.unregisterWorkspace = gn;
      var Ti = /* @__PURE__ */ Object.create(null), gf = { typeMap: Ti }, fr = /* @__PURE__ */ Object.create(null), _ = class {
        constructor(t) {
          this.name = t;
        }
        toString() {
          return this.name;
        }
      };
      _.CONNECTION_CHECKER = new _("connectionChecker"), _.CONNECTION_PREVIEWER = new _("connectionPreviewer"), _.EVENT = new _("event"), _.FIELD = new _("field"), _.INPUT = new _("input"), _.RENDERER = new _("renderer"), _.TOOLBOX = new _("toolbox"), _.THEME = new _("theme"), _.TOOLBOX_ITEM = new _("toolboxItem"), _.FLYOUTS_VERTICAL_TOOLBOX = new _("flyoutsVerticalToolbox"), _.FLYOUTS_HORIZONTAL_TOOLBOX = new _("flyoutsHorizontalToolbox"), _.FLYOUT_INFLATER = new _("flyoutInflater"), _.METRICS_MANAGER = new _("metricsManager"), _.BLOCK_DRAGGER = new _("blockDragger"), _.SERIALIZER = new _("serializer"), _.ICON = new _("icon"), _.PASTER = new _("paster"), _.VARIABLE_MODEL = new _("variableModel"), _.VARIABLE_MAP = new _("variableMap");
      var Qe = { DEFAULT: "default", TEST_ONLY: gf };
      Qe.Type = _, Qe.getAllItems = fn, Qe.getClass = Tl, Qe.getClassFromOptions = Pt, Qe.getObject = function(t, e, i) {
        return Mt(t, e, i);
      }, Qe.hasItem = pn, Qe.register = P, Qe.unregister = Mi;
      var Fd = { genUid: () => {
        var t = [];
        for (let e = 0; e < 20; e++) t[e] = "!#$%()*+,-./:;=?@[]^_`{|}~ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".charAt(Math.random() * 88);
        return t.join("");
      } }, pf = 0, _c = { TEST_ONLY: Fd };
      _c.genUid = je, _c.getNextUniqueId = It;
      var Fe, mc;
      r.gd = "", r.Qc = !0, r.Ub = 0, Fe = [], mc = { FIRE_QUEUE: Fe, enqueueEvent: Cl, fireNow: En, fireInternal: function(t) {
        if (ht()) {
          if (!Fe.length) try {
            requestAnimationFrame(() => {
              setTimeout(En, 0);
            });
          } catch {
            setTimeout(En, 0);
          }
          Cl(t);
        }
      }, setGroupInternal: function(t) {
        r.gd = typeof t == "boolean" ? t ? je() : "" : t;
      } };
      var Hd;
      r.C = /* @__PURE__ */ Object.create(null), Hd = { Msg: r.C, setLocale: kl };
      var m = class {
        constructor(t, e) {
          this.x = t, this.y = e;
        }
        clone() {
          return new m(this.x, this.y);
        }
        scale(t) {
          return this.x *= t, this.y *= t, this;
        }
        translate(t, e) {
          return this.x += t, this.y += e, this;
        }
        static equals(t, e) {
          return t === e ? !0 : t && e ? t.x === e.x && t.y === e.y : !1;
        }
        static distance(t, e) {
          var i = t.x - e.x;
          return t = t.y - e.y, Math.sqrt(i * i + t * t);
        }
        static magnitude(t) {
          return Math.sqrt(t.x * t.x + t.y * t.y);
        }
        static difference(t, e) {
          return new m(t.x - e.x, t.y - e.y);
        }
        static sum(t, e) {
          return new m(t.x + e.x, t.y + e.y);
        }
      }, F = class {
        constructor(t, e, i, o) {
          this.top = t, this.bottom = e, this.left = i, this.right = o;
        }
        static from(t) {
          return new F(t.y, t.y + t.height, t.x, t.x + t.width);
        }
        clone() {
          return new F(this.top, this.bottom, this.left, this.right);
        }
        getHeight() {
          return this.bottom - this.top;
        }
        getWidth() {
          return this.right - this.left;
        }
        getOrigin() {
          return new m(this.left, this.top);
        }
        contains(t, e) {
          return t >= this.left && t <= this.right && e >= this.top && e <= this.bottom;
        }
        intersects(t) {
          return this.left <= t.right && this.right >= t.left && this.bottom >= t.top && this.top <= t.bottom;
        }
        static equals(t, e) {
          return t === e ? !0 : t && e ? t.top === e.top && t.bottom === e.bottom && t.left === e.left && t.right === e.right : !1;
        }
        static createFromPoint(t, e, i) {
          var o = t.x;
          return t = t.y, new F(t, t + i, o, o + e);
        }
      }, H = class {
        constructor(t, e) {
          this.width = t, this.height = e;
        }
        static equals(t, e) {
          return t === e ? !0 : t && e ? t.width === e.width && t.height === e.height : !1;
        }
        static max(t, e) {
          return new H(Math.max(t.width, e.width), Math.max(t.height, e.height));
        }
        static min(t, e) {
          return new H(Math.min(t.width, e.width), Math.min(t.height, e.height));
        }
      }, Ud = { getSizeInternal: function(t) {
        if (Ae(t, "display") !== "none") return new H(t.offsetWidth, t.offsetHeight);
        var e = t.style, i = e.display, o = e.visibility, s = e.position;
        e.visibility = "hidden", e.position = "absolute", e.display = "inline";
        var n = t.offsetWidth;
        return t = t.offsetHeight, e.display = i, e.position = s, e.visibility = o, new H(n, t);
      } }, ti = { TEST_ONLY: Ud };
      ti.getBorderBox = _n, ti.getComputedStyle = Ae, ti.getContainerOffsetToScrollInto = Sl, ti.getPageOffset = di, ti.getSize = _s, ti.getViewportPageOffset = wl, ti.pageToContainerOffset = ko, ti.scrollIntoContainerView = Il;
      var Wd = /translate\(\s*([-+\d.e]+)([ ,]\s*([-+\d.e]+)\s*)?/, Gd = /transform:\s*translate(?:3d)?\(\s*([-+\d.e]+)\s*px([ ,]\s*([-+\d.e]+)\s*px)?/, $i = { TEST_ONLY: { XY_REGEX: Wd, XY_STYLE_REGEX: Gd } };
      $i.getDocumentScroll = Al, $i.getInjectionDivXY = Tn, $i.getRelativeXY = mn, $i.getViewportBBox = Rl, $i.screenToWsCoordinates = gi, $i.wsToScreenCoordinates = pi;
      var pt = class {
        constructor(t, e, i, o, s) {
          this.workspace = t, this.horizontal = e, this.oldHostMetrics = null, this.ratio = 1, this.origin = new m(0, 0), this.startDragHandle = this.handlePosition = this.handleLength = this.scrollbarLength = this.startDragMouse = 0, this.containerVisible = this.isHandleVisible = !0, this.position = new m(0, 0), this.onMouseMoveWrapper_ = this.onMouseUpWrapper_ = null, this.pair = i || !1, this.margin = s !== void 0 ? s : pt.DEFAULT_SCROLLBAR_MARGIN, t = "blocklyScrollbar" + (this.horizontal ? "Horizontal" : "Vertical"), o && (t += " " + o), this.outerSvg = v(g.SVG, { class: t }), o = v(g.G, {}, this.outerSvg), this.svgBackground = v(g.RECT, { class: "blocklyScrollbarBackground" }, o), t = Math.floor((pt.scrollbarThickness - 5) / 2), this.svgHandle = v(g.RECT, { class: "blocklyScrollbarHandle", rx: t, ry: t }, o), this.workspace.getThemeManager().subscribe(this.svgHandle, "scrollbarColour", "fill"), this.workspace.getThemeManager().subscribe(this.svgHandle, "scrollbarOpacity", "fill-opacity"), us(this.outerSvg, this.workspace.getParentSvg()), this.setInitialThickness(), e ? (this.lengthAttribute_ = "width", this.positionAttribute_ = "x") : (this.lengthAttribute_ = "height", this.positionAttribute_ = "y"), this.onMouseDownBarWrapper_ = M(this.svgBackground, "pointerdown", this, this.onMouseDownBar), this.onMouseDownHandleWrapper_ = M(this.svgHandle, "pointerdown", this, this.onMouseDownHandle);
        }
        setInitialThickness() {
          var t = pt.scrollbarThickness;
          this.horizontal ? (this.svgBackground.setAttribute("height", String(t)), this.outerSvg.setAttribute("height", String(t)), this.svgHandle.setAttribute(
            "height",
            String(t - 5)
          ), this.svgHandle.setAttribute("y", "2.5")) : (this.svgBackground.setAttribute("width", String(t)), this.outerSvg.setAttribute("width", String(t)), this.svgHandle.setAttribute("width", String(t - 5)), this.svgHandle.setAttribute("x", "2.5"));
        }
        dispose() {
          this.cleanUp(), $(this.onMouseDownBarWrapper_), $(this.onMouseDownHandleWrapper_), Q(this.outerSvg), this.workspace.getThemeManager().unsubscribe(this.svgHandle);
        }
        constrainHandleLength(t) {
          return t = t <= 0 || isNaN(t) ? 0 : Math.min(t, this.scrollbarLength);
        }
        setHandleLength(t) {
          this.handleLength = t, this.svgHandle.setAttribute(this.lengthAttribute_, String(this.handleLength));
        }
        constrainHandlePosition(t) {
          return t = t <= 0 || isNaN(t) ? 0 : Math.min(t, this.scrollbarLength - this.handleLength);
        }
        setHandlePosition(t) {
          this.handlePosition = t, this.svgHandle.setAttribute(this.positionAttribute_, String(this.handlePosition));
        }
        setScrollbarLength(t) {
          this.scrollbarLength = t, this.outerSvg.setAttribute(this.lengthAttribute_, String(this.scrollbarLength)), this.svgBackground.setAttribute(this.lengthAttribute_, String(this.scrollbarLength));
        }
        setPosition(t, e) {
          this.position.x = t, this.position.y = e, un(this.outerSvg, "translate(" + (this.position.x + this.origin.x) + "px," + (this.position.y + this.origin.y) + "px)");
        }
        resize(t) {
          !t && (t = this.workspace.getMetrics(), !t) || this.oldHostMetrics && pt.metricsAreEquivalent(t, this.oldHostMetrics) || (this.horizontal ? this.resizeHorizontal(t) : this.resizeVertical(t), this.oldHostMetrics = t, this.updateMetrics());
        }
        requiresViewResize(t) {
          return this.oldHostMetrics ? this.oldHostMetrics.viewWidth !== t.viewWidth || this.oldHostMetrics.viewHeight !== t.viewHeight || this.oldHostMetrics.absoluteLeft !== t.absoluteLeft || this.oldHostMetrics.absoluteTop !== t.absoluteTop : !0;
        }
        resizeHorizontal(t) {
          this.requiresViewResize(t) ? this.resizeViewHorizontal(t) : this.resizeContentHorizontal(t);
        }
        resizeViewHorizontal(t) {
          var e = t.viewWidth - this.margin * 2;
          this.pair && (e -= pt.scrollbarThickness), this.setScrollbarLength(Math.max(0, e)), e = t.absoluteLeft + this.margin, this.pair && this.workspace.RTL && (e += pt.scrollbarThickness), this.setPosition(e, t.absoluteTop + t.viewHeight - pt.scrollbarThickness - this.margin), this.resizeContentHorizontal(t);
        }
        resizeContentHorizontal(t) {
          if (t.viewWidth >= t.scrollWidth) this.setHandleLength(this.scrollbarLength), this.setHandlePosition(0), this.pair || this.setVisible(!1);
          else {
            this.pair || this.setVisible(!0);
            var e = this.scrollbarLength * t.viewWidth / t.scrollWidth;
            e = this.constrainHandleLength(e), this.setHandleLength(e), e = t.scrollWidth - t.viewWidth;
            var i = this.scrollbarLength - this.handleLength;
            t = (t.viewLeft - t.scrollLeft) / e * i, t = this.constrainHandlePosition(t), this.setHandlePosition(t), this.ratio = i / e;
          }
        }
        resizeVertical(t) {
          this.requiresViewResize(t) ? this.resizeViewVertical(t) : this.resizeContentVertical(t);
        }
        resizeViewVertical(t) {
          var e = t.viewHeight - this.margin * 2;
          this.pair && (e -= pt.scrollbarThickness), this.setScrollbarLength(Math.max(0, e)), this.setPosition(this.workspace.RTL ? t.absoluteLeft + this.margin : t.absoluteLeft + t.viewWidth - pt.scrollbarThickness - this.margin, t.absoluteTop + this.margin), this.resizeContentVertical(t);
        }
        resizeContentVertical(t) {
          if (t.viewHeight >= t.scrollHeight) this.setHandleLength(this.scrollbarLength), this.setHandlePosition(0), this.pair || this.setVisible(!1);
          else {
            this.pair || this.setVisible(!0);
            var e = this.scrollbarLength * t.viewHeight / t.scrollHeight;
            e = this.constrainHandleLength(e), this.setHandleLength(e), e = t.scrollHeight - t.viewHeight;
            var i = this.scrollbarLength - this.handleLength;
            t = (t.viewTop - t.scrollTop) / e * i, t = this.constrainHandlePosition(t), this.setHandlePosition(t), this.ratio = i / e;
          }
        }
        isVisible() {
          return this.isHandleVisible;
        }
        setContainerVisible(t) {
          var e = t !== this.containerVisible;
          this.containerVisible = t, e && this.updateDisplay_();
        }
        setVisible(t) {
          if (this.pair) throw Error("Unable to toggle visibility of paired scrollbars.");
          this.setVisibleInternal(t);
        }
        setVisibleInternal(t) {
          var e = t !== this.isVisible();
          this.isHandleVisible = t, e && this.updateDisplay_();
        }
        updateDisplay_() {
          this.containerVisible && this.isVisible() ? this.outerSvg.setAttribute("display", "block") : this.outerSvg.setAttribute("display", "none");
        }
        onMouseDownBar(t) {
          if (this.workspace.markFocused(), Ft = null, this.cleanUp(), _e(t)) t.stopPropagation();
          else {
            var e = To(t, this.workspace.getParentSvg(), this.workspace.getInverseScreenCTM());
            e = this.horizontal ? e.x : e.y;
            var i = Tn(this.svgHandle);
            i = this.horizontal ? i.x : i.y;
            var o = this.handlePosition, s = this.handleLength * 0.95;
            e <= i ? o -= s : e >= i + this.handleLength && (o += s), this.setHandlePosition(this.constrainHandlePosition(o)), this.updateMetrics(), t.stopPropagation(), t.preventDefault();
          }
        }
        onMouseDownHandle(t) {
          this.workspace.markFocused(), this.cleanUp(), _e(t) ? t.stopPropagation() : (this.startDragHandle = this.handlePosition, this.startDragMouse = this.horizontal ? t.clientX : t.clientY, this.onMouseUpWrapper_ = M(document, "pointerup", this, this.onMouseUpHandle), this.onMouseMoveWrapper_ = M(document, "pointermove", this, this.onMouseMoveHandle), t.stopPropagation(), t.preventDefault());
        }
        onMouseMoveHandle(t) {
          this.setHandlePosition(this.constrainHandlePosition(this.startDragHandle + ((this.horizontal ? t.clientX : t.clientY) - this.startDragMouse))), this.updateMetrics();
        }
        onMouseUpHandle() {
          Ft = null, this.cleanUp();
        }
        cleanUp() {
          this.workspace.hideChaff(!0), this.onMouseUpWrapper_ && ($(this.onMouseUpWrapper_), this.onMouseUpWrapper_ = null), this.onMouseMoveWrapper_ && ($(this.onMouseMoveWrapper_), this.onMouseMoveWrapper_ = null);
        }
        getRatio_() {
          var t = this.handlePosition / (this.scrollbarLength - this.handleLength);
          return isNaN(t) && (t = 0), t;
        }
        updateMetrics() {
          var t = this.getRatio_();
          this.horizontal ? this.workspace.setMetrics({ x: t }) : this.workspace.setMetrics({ y: t });
        }
        set(t, e) {
          this.setHandlePosition(this.constrainHandlePosition(t * this.ratio)), (e || e === void 0) && this.updateMetrics();
        }
        setOrigin(t, e) {
          this.origin = new m(t, e);
        }
        static metricsAreEquivalent(t, e) {
          return t.viewWidth === e.viewWidth && t.viewHeight === e.viewHeight && t.viewLeft === e.viewLeft && t.viewTop === e.viewTop && t.absoluteTop === e.absoluteTop && t.absoluteLeft === e.absoluteLeft && t.scrollWidth === e.scrollWidth && t.scrollHeight === e.scrollHeight && t.scrollLeft === e.scrollLeft && t.scrollTop === e.scrollTop;
        }
      };
      pt.scrollbarThickness = Ed ? 25 : 15, pt.DEFAULT_SCROLLBAR_MARGIN = 0.5;
      var Er = { parseFromString: function() {
        throw Error("DOMParser was not found in the global scope and was not properly injected using injectDependencies");
      } }, Tc = { serializeToString: function() {
        throw Error("XMLSerializer was not foundin the global scope and was not properly injected using injectDependencies");
      } }, { document: vr, DOMParser: Gs, XMLSerializer: Vs } = globalThis;
      Gs && (Er = new Gs()), Vs && (Tc = new Vs());
      var ff = /[\x00-\x09\x0B\x0C\x0E-\x1F]/g, Go = { NAME_SPACE: "https://developers.google.com/blockly/xml" };
      Go.createElement = r.sc, Go.createTextNode = r.tc, Go.domToText = wo, Go.injectDependencies = function(t) {
        ({ document: vr = vr, DOMParser: Gs = Gs, XMLSerializer: Vs = Vs } = t), Er = new Gs(), Tc = new Vs();
      }, Go.textToDom = r.vc;
      var I, Ci = I || (I = {});
      Ci[Ci.TOP = 0] = "TOP", Ci[Ci.BOTTOM = 1] = "BOTTOM", Ci[Ci.LEFT = 2] = "LEFT", Ci[Ci.RIGHT = 3] = "RIGHT";
      var Ji = {};
      Ji.Position = I, Ji.convertFlyoutDefToJsonArray = ms, Ji.convertToolboxDefToJson = Cn, Ji.hasCategories = yn, Ji.isCategoryCollapsible = bn, Ji.parseToolboxTree = Dl;
      var ei, _r = ei || (ei = {});
      _r[_r.TOP = 0] = "TOP", _r[_r.BOTTOM = 1] = "BOTTOM";
      var Vo, mr = Vo || (Vo = {});
      mr[mr.LEFT = 0] = "LEFT", mr[mr.RIGHT = 1] = "RIGHT";
      var yi, Tr = yi || (yi = {});
      Tr[Tr.UP = 0] = "UP", Tr[Tr.DOWN = 1] = "DOWN";
      var qi = {};
      qi.bumpDirection = yi, qi.bumpPositionRect = Sn, qi.getCornerOppositeToolbox = In, qi.getStartPositionRect = wn, qi.horizontalPosition = Vo, qi.verticalPosition = ei;
      var Kt = { width: 96, height: 124, url: "sprites.svg" }, Cc = class {
        constructor(t, e) {
          this.workspace = t, this.group = e, this.pointerDownHandler = M(e, "pointerdown", null, this.performAction.bind(this)), this.keyDownHandler = jt(e, "keydown", this, this.onKeyDown), G(e, W.BUTTON), this.id = It(), this.group.id = this.id;
        }
        zoom(t, e) {
          this.workspace.markFocused(), this.workspace.zoomCenter(t), this.fireZoomEvent(), Ft = null, e.stopPropagation(), e.preventDefault();
        }
        fireZoomEvent() {
          var t = new (D(p.CLICK))(null, this.workspace.id, "zoom_controls");
          N(t);
        }
        getGroup() {
          return this.group;
        }
        onKeyDown(t) {
          (t.key === "Enter" || t.key === " ") && (t.preventDefault(), this.performAction(t));
        }
        dispose() {
          $(this.pointerDownHandler), $(this.keyDownHandler);
        }
      }, Ef = class extends Cc {
        constructor(t, e) {
          var i = String(Math.random()).substring(2);
          e = v(g.G, { class: "blocklyZoom blocklyZoomIn", tabindex: "0" }, e), w(e, y.LABEL, r.C.ZOOM_IN), v(g.RECT, { width: 40, height: 40, x: -4, y: -4, rx: 2, ry: 2, fill: "none", class: "blocklyFocusRing" }, e);
          var o = v(g.CLIPPATH, { id: "blocklyZoominClipPath" + i }, e);
          v(g.RECT, { width: 32, height: 32 }, o), v(g.IMAGE, {
            width: Kt.width,
            height: Kt.height,
            x: -32,
            y: -92,
            "clip-path": "url(#blocklyZoominClipPath" + i + ")"
          }, e).setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", t.options.pathToMedia + Kt.url), super(t, e);
        }
        performAction(t) {
          this.zoom(1, t);
        }
      }, vf = class extends Cc {
        constructor(t, e) {
          var i = String(Math.random()).substring(2);
          e = v(g.G, { class: "blocklyZoom blocklyZoomOut", tabindex: "0" }, e), w(e, y.LABEL, r.C.ZOOM_OUT), v(g.RECT, { width: 40, height: 40, x: -4, y: -4, rx: 2, ry: 2, fill: "none", class: "blocklyFocusRing" }, e);
          var o = v(g.CLIPPATH, { id: "blocklyZoomoutClipPath" + i }, e);
          v(g.RECT, { width: 32, height: 32 }, o), v(g.IMAGE, { width: Kt.width, height: Kt.height, x: -64, y: -92, "clip-path": "url(#blocklyZoomoutClipPath" + i + ")" }, e).setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", t.options.pathToMedia + Kt.url), super(t, e);
        }
        performAction(t) {
          this.zoom(-1, t);
        }
      }, _f = class extends Cc {
        constructor(t, e) {
          var i = String(Math.random()).substring(2);
          e = v(g.G, { class: "blocklyZoom blocklyZoomReset", tabindex: "0" }, e), w(e, y.LABEL, r.C.RESET_ZOOM), v(g.RECT, {
            width: 40,
            height: 40,
            x: -4,
            y: -4,
            rx: 2,
            ry: 2,
            fill: "none",
            class: "blocklyFocusRing"
          }, e);
          var o = v(g.CLIPPATH, { id: "blocklyZoomresetClipPath" + i }, e);
          v(g.RECT, { width: 32, height: 32 }, o), v(g.IMAGE, { width: Kt.width, height: Kt.height, y: -92, "clip-path": "url(#blocklyZoomresetClipPath" + i + ")" }, e).setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", t.options.pathToMedia + Kt.url), super(t, e);
        }
        performAction(t) {
          this.workspace.markFocused();
          var e = Math.log(this.workspace.options.zoomOptions.startScale / this.workspace.scale) / Math.log(this.workspace.options.zoomOptions.scaleSpeed);
          this.workspace.beginCanvasTransition(), this.workspace.zoomCenter(e), this.workspace.scrollCenter(), setTimeout(this.workspace.endCanvasTransition.bind(this.workspace), 500), this.fireZoomEvent(), Ft = null, t.stopPropagation(), t.preventDefault();
        }
      }, Vd = class {
        constructor(t) {
          this.workspace = t, this.id = "zoomControls", this.zoomResetControl = this.zoomOutControl = this.zoomInControl = null, this.HEIGHT = this.WIDTH = 32, this.SMALL_SPACING = 2, this.LARGE_SPACING = 11, this.MARGIN_HORIZONTAL = this.MARGIN_VERTICAL = 20, this.svgGroup = null, this.top = this.left = 0, this.initialized = !1;
        }
        createDom() {
          return this.svgGroup = v(g.G, {}), this.zoomOutControl = new vf(this.workspace, this.svgGroup), this.zoomInControl = new Ef(this.workspace, this.svgGroup), this.workspace.isMovable() && (this.zoomResetControl = new _f(this.workspace, this.svgGroup)), this.svgGroup;
        }
        init() {
          this.workspace.getComponentManager().addComponent({ component: this, weight: nt.ComponentWeight.ZOOM_CONTROLS_WEIGHT, capabilities: [nt.Capability.POSITIONABLE] }), this.initialized = !0;
        }
        dispose() {
          this.workspace.getComponentManager().removeComponent("zoomControls"), this.svgGroup && Q(this.svgGroup);
          var t;
          (t = this.zoomInControl) == null || t.dispose();
          var e;
          (e = this.zoomOutControl) == null || e.dispose();
          var i;
          (i = this.zoomResetControl) == null || i.dispose();
        }
        getBoundingRectangle() {
          var t = this.SMALL_SPACING + 2 * this.HEIGHT;
          return this.zoomResetControl && (t += this.LARGE_SPACING + this.HEIGHT), new F(this.top, this.top + t, this.left, this.left + this.WIDTH);
        }
        position(t, e) {
          if (this.initialized) {
            var i = In(this.workspace, t), o = this.SMALL_SPACING + 2 * this.HEIGHT;
            if (this.zoomResetControl && (o += this.LARGE_SPACING + this.HEIGHT), t = wn(i, new H(this.WIDTH, o), this.MARGIN_HORIZONTAL, this.MARGIN_VERTICAL, t, this.workspace), i = i.vertical, e = Sn(t, this.MARGIN_VERTICAL, i === ei.TOP ? yi.DOWN : yi.UP, e), i === ei.TOP) {
              var s = this.SMALL_SPACING + this.HEIGHT, n;
              (n = this.zoomInControl) == null || n.getGroup().setAttribute("transform", "translate(0, " + s + ")"), this.zoomResetControl && (s = s + this.LARGE_SPACING + this.HEIGHT, this.zoomResetControl.getGroup().setAttribute("transform", "translate(0, " + s + ")"));
            } else {
              n = this.zoomResetControl ? this.LARGE_SPACING + this.HEIGHT : 0;
              let a;
              (a = this.zoomInControl) == null || a.getGroup().setAttribute("transform", "translate(0, " + n + ")"), n = n + this.SMALL_SPACING + this.HEIGHT, (s = this.zoomOutControl) == null || s.getGroup().setAttribute("transform", "translate(0, " + n + ")");
            }
            this.top = e.top, this.left = e.left;
            var l;
            (l = this.svgGroup) == null || l.setAttribute("transform", "translate(" + this.left + "," + this.top + ")");
          }
        }
      };
      ce(`
.blocklyZoom>image, .blocklyZoom>svg>image {
  opacity: .4;
}

.blocklyZoom>image:hover, .blocklyZoom>svg>image:hover, .blocklyZoom:focus>image {
  opacity: .8;
}

.blocklyZoom>image:active, .blocklyZoom>svg>image:active {
  opacity: 1;
}
`);
      var yc = {};
      yc.register = Ts, yc.unregister = function(t) {
        Mi(_.SERIALIZER, t);
      };
      var zd = class {
        constructor() {
          this.priority = 25;
        }
        save(t) {
          var e = [];
          for (let i of t.getTopComments()) (t = Io(i, { addCoordinates: !0, saveIds: !0 })) && e.push(t);
          return e.length ? e : null;
        }
        load(t, e) {
          for (let i of t) Cs(i, e, { recordUndo: r.Qc });
        }
        clear(t) {
          for (let e of t.getTopComments()) e.dispose();
        }
      };
      Ts("workspaceComments", new zd());
      var Cr = {};
      Cr.WorkspaceCommentSerializer = zd, Cr.append = Cs, Cr.save = Io;
      var bc = {};
      bc.register = Rn, bc.unregister = function(t) {
        Mi(_.PASTER, t);
      };
      var yr = class {
        paste(t, e, i) {
          t = t.commentState, i && (t.x = i.x, t.y = i.y), r.Ub++;
          try {
            var o = Cs(t, e);
            Ou(o);
          } finally {
            r.Ub--;
          }
          return o ? (ht() && N(new (D(p.COMMENT_CREATE))(o)), r.t().focusNode(o), o) : null;
        }
      };
      yr.TYPE = "workspace-comment", Rn(yr.TYPE, new yr()), r.Og = { dragRadius: 5, flyoutDragRadius: 10, snapRadius: 28, connectingSnapRadius: 28, currentConnectionPreference: 8, bumpDelay: 250 };
      var br = class {
        constructor(t, e, i) {
          this.content = t, this.opt_value = e, this.ariaLabel = i, this.enabled = !0, this.element = null, this.rightToLeft = !1, this.roleName = null, this.highlight = this.checked = this.checkable = !1, this.actionHandler = null, this.id = It();
        }
        createDom() {
          var t = document.createElement("div");
          t.id = this.getId(), this.element = t, t.className = "blocklyMenuItem " + (this.enabled ? "" : "blocklyMenuItemDisabled ") + (this.checked ? "blocklyMenuItemSelected " : "") + (this.highlight ? "blocklyMenuItemHighlight " : "") + (this.rightToLeft ? "blocklyMenuItemRtl " : "");
          var e = document.createElement("div");
          w(t, y.LABEL, this.getAriaLabel()), G(e, W.NONE), e.className = "blocklyMenuItemContent";
          var i = this.content;
          return typeof this.content == "string" && (i = document.createTextNode(this.content)), e.appendChild(i), t.appendChild(e), this.checkable && this.toggleHasCheckbox(!0), this.roleName && G(t, this.roleName), w(t, y.SELECTED, this.checkable && this.checked || !1), w(t, y.DISABLED, !this.enabled), t;
        }
        getAriaLabel() {
          return this.ariaLabel || (typeof this.content == "string" ? this.content : this.content.textContent);
        }
        dispose() {
          this.element = null;
        }
        getElement() {
          return this.element;
        }
        getId() {
          return this.id;
        }
        getValue() {
          var t;
          return (t = this.opt_value) != null ? t : null;
        }
        setRightToLeft(t) {
          this.rightToLeft = t;
          var e;
          (e = this.getElement()) == null || e.classList.toggle("blocklyMenuItemRtl", this.rightToLeft);
        }
        setRole(t) {
          this.roleName = t;
        }
        setCheckable(t) {
          (this.checkable = t) || this.setChecked(!1), this.toggleHasCheckbox(t);
        }
        setChecked(t) {
          (!t || this.checkable) && (this.checked = t, (t = this.getElement()) && (t.classList.toggle(
            "blocklyMenuItemSelected",
            this.checked
          ), w(t, y.SELECTED, this.checked)));
        }
        setHighlighted(t) {
          if (this.highlight = t, this.isEnabled()) {
            let e;
            (e = this.getElement()) == null || e.classList.toggle("blocklyMenuItemHighlight", this.highlight);
          }
        }
        isEnabled() {
          return this.enabled;
        }
        setEnabled(t) {
          this.enabled = t, (t = this.getElement()) && (t.classList.toggle("blocklyMenuItemDisabled", !this.enabled), w(t, y.DISABLED, !this.enabled));
        }
        performAction(t) {
          this.isEnabled() && this.actionHandler && this.actionHandler(this, t);
        }
        onAction(t, e) {
          this.actionHandler = t.bind(e);
        }
        toggleHasCheckbox(t) {
          if (t) {
            let o;
            if ((o = this.getElement()) == null || !o.querySelector(".blocklyMenuItemContent .blocklyMenuItemCheckbox")) {
              t = document.createElement("div"), w(t, y.HIDDEN, !0), t.className = "blocklyMenuItemCheckbox ";
              var e, i;
              (e = this.getElement()) == null || (i = e.querySelector(".blocklyMenuItemContent")) == null || i.prepend(t);
            }
          } else {
            let o, s;
            (o = this.getElement()) == null || (s = o.querySelector(".blocklyMenuItemContent .blocklyMenuItemCheckbox")) == null || s.remove();
          }
        }
      }, kc = class {
        constructor() {
          this.menuItems = [], this.roleName = this.element = this.onKeyDownHandler = this.pointerLeaveHandler = this.pointerEnterHandler = this.clickHandler = this.pointerMoveHandler = this.highlightedItem = this.openingCoords = null, this.id = It();
        }
        addChild(t) {
          this.menuItems.push(t);
        }
        render(t) {
          var e = document.createElement("div");
          e.className = "blocklyMenu", e.tabIndex = 0, e.id = this.getId(), this.roleName && G(e, this.roleName), this.element = e;
          for (let i = 0, o; o = this.menuItems[i]; i++) e.appendChild(o.createDom());
          return this.pointerMoveHandler = M(e, "pointermove", this, this.handlePointerMove, !0), this.clickHandler = M(e, "pointerup", this, this.handleClick, !0), this.pointerEnterHandler = M(e, "pointerenter", this, this.handlePointerEnter, !0), this.pointerLeaveHandler = M(e, "pointerleave", this, this.handlePointerLeave, !0), this.onKeyDownHandler = M(e, "keydown", this, this.handleKeyEvent), t.appendChild(e), e;
        }
        getElement() {
          return this.element;
        }
        focus() {
          var t = this.getElement();
          t && t.focus({ preventScroll: !0 });
        }
        blur() {
          var t = this.getElement();
          t && t.blur();
        }
        setRole(t) {
          this.roleName = t;
        }
        dispose() {
          this.pointerMoveHandler && ($(this.pointerMoveHandler), this.pointerMoveHandler = null), this.clickHandler && ($(this.clickHandler), this.clickHandler = null), this.pointerEnterHandler && ($(this.pointerEnterHandler), this.pointerEnterHandler = null), this.pointerLeaveHandler && ($(this.pointerLeaveHandler), this.pointerLeaveHandler = null), this.onKeyDownHandler && ($(this.onKeyDownHandler), this.onKeyDownHandler = null);
          for (let t = 0, e; e = this.menuItems[t]; t++) e.dispose();
          this.element = null;
        }
        getMenuItem(t) {
          for (var e = this.getElement(); t && t !== e; ) {
            if (t.classList.contains("blocklyMenuItem")) {
              let i = this.getMenuItems();
              for (let o = 0, s; s = i[o]; o++) if (s.getElement() === t) return s;
            }
            t = t.parentElement;
          }
          return null;
        }
        setHighlighted(t) {
          var e = this.highlightedItem;
          if (e && (e.setHighlighted(!1), this.highlightedItem = null), t) {
            t.setHighlighted(!0), this.highlightedItem = t, e = this.getElement();
            let i = t.getElement();
            e && i && (Il(i, e), w(e, y.ACTIVEDESCENDANT, t.getId()));
          }
        }
        highlightNext() {
          var t = this.highlightedItem ? this.getMenuItems().indexOf(this.highlightedItem) : -1;
          this.highlightHelper(t, 1);
        }
        highlightPrevious() {
          var t = this.highlightedItem ? this.getMenuItems().indexOf(this.highlightedItem) : -1;
          this.highlightHelper(t < 0 ? this.menuItems.length : t, -1);
        }
        highlightFirst() {
          this.highlightHelper(-1, 1);
        }
        highlightLast() {
          this.highlightHelper(this.menuItems.length, -1);
        }
        highlightHelper(t, e) {
          t += e;
          for (var i, o = this.getMenuItems(); i = o[t]; ) {
            if (i.isEnabled()) {
              this.setHighlighted(i);
              break;
            }
            t += e;
          }
        }
        handlePointerMove(t) {
          Math.max(Math.abs(t.movementX), Math.abs(t.movementY)) !== 0 && (t = this.getMenuItem(t.target)) && (t.isEnabled() ? this.highlightedItem !== t && this.setHighlighted(t) : this.setHighlighted(null));
        }
        handleClick(t) {
          var e = this.openingCoords;
          if (this.openingCoords = null, e && typeof t.clientX == "number") {
            let i = new m(t.clientX, t.clientY);
            if (m.distance(e, i) < 1) return;
          }
          (e = this.getMenuItem(t.target)) && e.performAction(t);
        }
        handlePointerEnter() {
          this.focus();
        }
        handlePointerLeave() {
          this.getElement() && this.setHighlighted(null);
        }
        handleKeyEvent(t) {
          if (this.menuItems.length && !(t.shiftKey || t.ctrlKey || t.metaKey || t.altKey)) {
            var e = this.highlightedItem;
            switch (t.key) {
              case "Enter":
              case " ":
                e && e.performAction(t);
                break;
              case "ArrowUp":
                this.highlightPrevious();
                break;
              case "ArrowDown":
                this.highlightNext();
                break;
              case "PageUp":
              case "Home":
                this.highlightFirst();
                break;
              case "PageDown":
              case "End":
                this.highlightLast();
                break;
              default:
                return;
            }
            t.preventDefault(), t.stopPropagation();
          }
        }
        getSize() {
          var t = this.getElement(), e = _s(t);
          return e.height = t.scrollHeight, e;
        }
        getMenuItems() {
          return this.menuItems.filter((t) => t instanceof br);
        }
        getId() {
          return this.id;
        }
      }, Kd = class {
        constructor() {
          this.element = null;
        }
        createDom() {
          return this.element = document.createElement("hr"), this.element.className = "blocklyMenuSeparator", G(this.element, W.SEPARATOR), this.element;
        }
        dispose() {
          var t;
          (t = this.element) == null || t.remove(), this.element = null;
        }
      }, Ce;
      Ce = r.je || (r.je = {}), Ce[Ce.VALUE = 1] = "VALUE", Ce[Ce.STATEMENT = 3] = "STATEMENT", Ce[Ce.DUMMY = 5] = "DUMMY", Ce[Ce.CUSTOM = 6] = "CUSTOM", Ce[Ce.END_ROW = 7] = "END_ROW";
      var kr = /* @__PURE__ */ new Set(), wc = /* @__PURE__ */ new WeakSet(), Ic = /* @__PURE__ */ new WeakMap(), zo = null, Sc = null, Xd = 0, wr = {};
      wr.finishQueuedRenders = te, wr.queueRender = Ol, wr.triggerQueuedRenders = Ne;
      var Xt = class {
        static show(t, e) {
          if (e.oncePerSession && e.id) {
            if (this.shownIds.has(e.id)) return;
            this.shownIds.add(e.id);
          }
          this.hide(t);
          var i = this.createDom(t, e);
          requestAnimationFrame(() => {
            i.style.bottom = "2rem";
          });
        }
        static createDom(t, e) {
          var { message: i, duration: o = 5, assertiveness: s = zt.POLITE } = e, n = document.createElement("div");
          t.getInjectionDiv().appendChild(n), n.dataset.toastId = e.id, n.className = "blocklyToast", e = n.appendChild(document.createElement("div")), e.className = "blocklyToastMessage", e.innerText = i, e = n.appendChild(document.createElement("button")), e.className = "blocklyToastCloseButton", w(e, y.LABEL, r.C.CLOSE);
          var l = v(g.SVG, { width: 24, height: 24, viewBox: "0 0 24 24", fill: "none" }, e);
          w(l, y.HIDDEN, !0), v(g.RECT, { x: 19.7782, y: 2.80762, width: 2, height: 24, transform: "rotate(45, 19.7782, 2.80762)", fill: "black" }, l), v(g.RECT, { x: 2.80762, y: 4.22183, width: 2, height: 24, transform: "rotate(-45, 2.80762, 4.22183)", fill: "black" }, l), e.addEventListener("click", () => {
            var c = r.t(), E = c.getPreviouslyFocusedNode();
            n.remove(), E != null && E.canBeFocused() ? c.focusNode(E) : c.focusTree(t);
          });
          var a;
          return e = () => {
            a = setTimeout(() => n.remove(), o * 1e3);
          }, l = () => clearTimeout(a), n.addEventListener("focusin", l), n.addEventListener("focusout", e), n.addEventListener("mouseenter", l), n.addEventListener("mousemove", l), n.addEventListener("mouseleave", e), e(), ue(i, { assertiveness: s, role: W.STATUS }), n;
        }
        static hide(t, e) {
          t = t.getInjectionDiv().querySelector(".blocklyToast"), t instanceof HTMLElement && (!e || e === t.dataset.toastId) && t.remove();
        }
      };
      Xt.shownIds = /* @__PURE__ */ new Set(), ce(`
.blocklyToast {
  font-size: 1.2rem;
  position: absolute;
  bottom: -10rem;
  right: 2rem;
  padding: 1rem;
  color: black;
  background-color: white;
  border: 2px solid black;
  border-radius: 0.4rem;
  z-index: 999;
  display: flex;
  align-items: center;
  gap: 0.8rem;
  line-height: 1.5;
  transition: bottom 0.3s ease-out;
}

.blocklyToast .blocklyToastMessage {
  max-width: 18rem;
}

.blocklyToast .blocklyToastCloseButton {
  margin: 0;
  padding: 0.2rem;
  background-color: transparent;
  color: black;
  border: none;
  cursor: pointer;
}
`);
      var ye, Ko = ye || (ye = {});
      Ko[Ko.ALERT = 1] = "ALERT", Ko[Ko.CONFIRM = 2] = "CONFIRM", Ko[Ko.PROMPT = 3] = "PROMPT";
      var Ir = 0, Rc = Ml, Yd = Pl, jd = Fl, $d = Xt.show.bind(Xt), Jd = $d, ii = {};
      ii.alert = Nn, ii.confirm = Dn, ii.prompt = On, ii.setAlert = function(t = Ml) {
        Rc = t;
      }, ii.setConfirm = function(t = Pl) {
        Yd = t;
      }, ii.setPrompt = function(t = Fl) {
        jd = t;
      }, ii.setToast = function(t = $d) {
        Jd = t;
      }, ii.toast = function(t, e) {
        Jd(t, e);
      };
      var oi = class {
        constructor() {
          this.workspaceId = void 0, this.isUiEvent = !1, this.type = "", this.group = r.gd, this.recordUndo = r.Qc;
        }
        toJson() {
          return { type: this.type, group: this.group };
        }
        static fromJson(t, e, i) {
          return i.isBlank = !1, i.group = t.group || "", i.workspaceId = e.id, i;
        }
        isNull() {
          return !1;
        }
        run() {
        }
        getEventWorkspace_() {
          var t;
          if (this.workspaceId && (t = ai(this.workspaceId)), !t) throw Error("Workspace is null. Event must have been generated from real Blockly events.");
          return t;
        }
      }, ge = class extends oi {
        constructor(t) {
          super(), this.isBlank = !0, this.isBlank = !t, t && (this.blockId = t.id, this.workspaceId = t.workspace.id);
        }
        toJson() {
          var t = super.toJson();
          if (!this.blockId) throw Error("The block ID is undefined. Either pass a block to the constructor, or call fromJson");
          return t.blockId = this.blockId, t;
        }
        static fromJson(t, e, i) {
          return e = oi.fromJson(t, e, i ?? new ge()), e.blockId = t.blockId, e;
        }
      }, Ct = class {
        constructor(t) {
          this.name = t;
        }
        toString() {
          return this.name;
        }
        equals(t) {
          return this.name === t.toString();
        }
      };
      Ct.MUTATOR = new Ct("mutator"), Ct.WARNING = new Ct("warning"), Ct.COMMENT = new Ct("comment");
      var Zi = class extends ge {
        constructor(t, e, i, o, s) {
          super(t), this.type = p.BLOCK_CHANGE, t && (this.element = e, this.name = i || void 0, this.oldValue = o, this.newValue = s);
        }
        toJson() {
          var t = super.toJson();
          if (!this.element) throw Error("The changed element is undefined. Either pass an element to the constructor, or call fromJson");
          return t.element = this.element, t.name = this.name, t.oldValue = this.oldValue, t.newValue = this.newValue, this.disabledReason && (t.disabledReason = this.disabledReason), t;
        }
        static fromJson(t, e, i) {
          return e = ge.fromJson(
            t,
            e,
            i ?? new Zi()
          ), e.element = t.element, e.name = t.name, e.oldValue = t.oldValue, e.newValue = t.newValue, t.disabledReason !== void 0 && (e.disabledReason = t.disabledReason), e;
        }
        setDisabledReason(t) {
          if (this.element !== "disabled") throw Error('Cannot set the disabled reason for a BlockChange event if the element is not "disabled".');
          this.disabledReason = t;
        }
        isNull() {
          return this.oldValue === this.newValue;
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.blockId) throw Error("The block ID is undefined. Either pass a block to the constructor, or call fromJson");
          if (e = e.getBlockById(this.blockId), !e) throw Error("The associated block is undefined. Either pass a block to the constructor, or call fromJson");
          var i = e.getIcon(Ct.MUTATOR);
          switch (i && De(i) && i.bubbleIsVisible() && i.setBubbleVisible(!1), t = t ? this.newValue : this.oldValue, this.element) {
            case "field":
              (e = e.getField(this.name)) ? e.setValue(t) : console.warn("Can't set non-existent field: " + this.name);
              break;
            case "comment":
              e.setCommentText(t ?? null);
              break;
            case "collapsed":
              e.setCollapsed(!!t);
              break;
            case "disabled":
              var o;
              e.setDisabledReason(!!t, (o = this.disabledReason) != null ? o : "MANUALLY_DISABLED");
              break;
            case "inline":
              e.setInputsInline(!!t);
              break;
            case "mutation":
              o = Zi.getExtraBlockState_(e), e.loadExtraState ? e.loadExtraState(JSON.parse(t || "{}")) : e.domToMutation && e.domToMutation(r.vc(t || "<mutation/>")), N(new Zi(e, "mutation", null, o, t));
              break;
            default:
              console.warn("Unknown change type: " + this.element);
          }
        }
        static getExtraBlockState_(t) {
          return t.saveExtraState ? (t = t.saveExtraState(!0)) ? JSON.stringify(t) : "" : t.mutationToDom && (t = t.mutationToDom()) ? xo(t) : "";
        }
      };
      P(_.EVENT, p.BLOCK_CHANGE, Zi);
      var Ac = class extends ge {
        constructor(t) {
          super(t), this.type = p.BLOCK_CREATE, t && (t.isShadow() && (this.recordUndo = !1), this.ids = vn(t), this.json = ee(t, { addCoordinates: !0 }));
        }
        toJson() {
          var t = super.toJson();
          if (!this.ids) throw Error("The block IDs are undefined. Either pass a block to the constructor, or call fromJson");
          if (!this.json) throw Error("The block JSON is undefined. Either pass a block to the constructor, or call fromJson");
          return t.ids = this.ids, t.json = this.json, this.recordUndo || (t.recordUndo = this.recordUndo), t;
        }
        static fromJson(t, e, i) {
          return e = ge.fromJson(t, e, i ?? new Ac()), e.ids = t.ids, e.json = t.json, t.recordUndo !== void 0 && (e.recordUndo = t.recordUndo), e;
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.json) throw Error("The block JSON is undefined. Either pass a block to the constructor, or call fromJson");
          if (!this.ids) throw Error("The block IDs are undefined. Either pass a block to the constructor, or call fromJson");
          if (!Bu(e, this.ids)) if (t) Fi(this.json, e);
          else for (t = 0; t < this.ids.length; t++) {
            let i = this.ids[t], o = e.getBlockById(i);
            o ? o.dispose(!1) : i === this.blockId && console.warn("Can't uncreate non-existent block: " + i);
          }
        }
      };
      P(_.EVENT, p.BLOCK_CREATE, Ac);
      var Nc = class extends ge {
        constructor(t) {
          if (super(t), this.type = p.BLOCK_DELETE, t) {
            if (t.getParent()) throw Error("Connected blocks cannot be deleted.");
            t.isShadow() && (this.recordUndo = !1), this.ids = vn(t), this.wasShadow = t.isShadow(), this.oldJson = ee(t, { addCoordinates: !0 });
          }
        }
        toJson() {
          var t = super.toJson();
          if (!this.ids) throw Error("The block IDs are undefined. Either pass a block to the constructor, or call fromJson");
          if (this.wasShadow === void 0) throw Error("Whether the block was a shadow is undefined. Either pass a block to the constructor, or call fromJson");
          if (!this.oldJson) throw Error("The old block JSON is undefined. Either pass a block to the constructor, or call fromJson");
          return t.ids = this.ids, t.wasShadow = this.wasShadow, t.oldJson = this.oldJson, this.recordUndo || (t.recordUndo = this.recordUndo), t;
        }
        static fromJson(t, e, i) {
          return e = ge.fromJson(t, e, i ?? new Nc()), e.ids = t.ids, e.wasShadow = t.wasShadow, e.oldJson = t.oldJson, t.recordUndo !== void 0 && (e.recordUndo = t.recordUndo), e;
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.ids) throw Error("The block IDs are undefined. Either pass a block to the constructor, or call fromJson");
          if (!this.oldJson) throw Error("The old block JSON is undefined. Either pass a block to the constructor, or call fromJson");
          if (t) for (t = 0; t < this.ids.length; t++) {
            let i = this.ids[t], o = e.getBlockById(i);
            o ? o.dispose(!1) : i === this.blockId && console.warn("Can't delete non-existent block: " + i);
          }
          else Fi(this.oldJson, e);
        }
      };
      P(_.EVENT, p.BLOCK_DELETE, Nc);
      var kt = class extends oi {
        constructor(t) {
          super(), this.isBlank = !0, this.recordUndo = !1, this.isUiEvent = !0, this.isBlank = typeof t > "u", this.workspaceId = t || "";
        }
      }, Dc = class extends kt {
        constructor(t, e, i) {
          super(t ? t.workspace.id : void 0), this.type = p.BLOCK_DRAG, t && (this.blockId = t.id, this.isStart = e, this.blocks = i);
        }
        toJson() {
          var t = super.toJson();
          if (this.isStart === void 0) throw Error("Whether this event is the start of a drag is undefined. Either pass the value to the constructor, or call fromJson");
          if (this.blockId === void 0) throw Error("The block ID is undefined. Either pass a block to the constructor, or call fromJson");
          return t.isStart = this.isStart, t.blockId = this.blockId, t.blocks = this.blocks, t;
        }
        static fromJson(t, e, i) {
          return e = kt.fromJson(t, e, i ?? new Dc()), e.isStart = t.isStart, e.blockId = t.blockId, e.blocks = t.blocks, e;
        }
      };
      P(_.EVENT, p.BLOCK_DRAG, Dc);
      var Oc = class extends ge {
        constructor(t, e, i, o) {
          super(t), this.type = p.BLOCK_FIELD_INTERMEDIATE_CHANGE, this.recordUndo = !1, t && (this.name = e, this.oldValue = i, this.newValue = o);
        }
        toJson() {
          var t = super.toJson();
          if (!this.name) throw Error("The changed field name is undefined. Either pass a name to the constructor, or call fromJson.");
          return t.name = this.name, t.oldValue = this.oldValue, t.newValue = this.newValue, t;
        }
        static fromJson(t, e, i) {
          return e = ge.fromJson(t, e, i ?? new Oc()), e.name = t.name, e.oldValue = t.oldValue, e.newValue = t.newValue, e;
        }
        isNull() {
          return this.oldValue === this.newValue;
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.blockId) throw Error("The block ID is undefined. Either pass a block to the constructor, or call fromJson");
          if (e = e.getBlockById(this.blockId), !e) throw Error("The associated block is undefined. Either pass a block to the constructor, or call fromJson");
          t = t ? this.newValue : this.oldValue, (e = e.getField(this.name)) ? e.setValue(t) : console.warn("Can't set non-existent field: " + this.name);
        }
      };
      P(_.EVENT, p.BLOCK_FIELD_INTERMEDIATE_CHANGE, Oc);
      var T, bi = T || (T = {});
      bi[bi.INPUT_VALUE = 1] = "INPUT_VALUE", bi[bi.OUTPUT_VALUE = 2] = "OUTPUT_VALUE", bi[bi.NEXT_STATEMENT = 3] = "NEXT_STATEMENT", bi[bi.PREVIOUS_STATEMENT = 4] = "PREVIOUS_STATEMENT";
      var Lc = class extends ge {
        constructor(t) {
          super(t), this.type = p.BLOCK_MOVE, t && (t.isShadow() && (this.recordUndo = !1), t = this.currentLocation(), this.oldParentId = t.parentId, this.oldInputName = t.inputName, this.oldCoordinate = t.coordinate);
        }
        toJson() {
          var t = super.toJson();
          return t.oldParentId = this.oldParentId, t.oldInputName = this.oldInputName, this.oldCoordinate && (t.oldCoordinate = `${Math.round(this.oldCoordinate.x)}, ${Math.round(this.oldCoordinate.y)}`), t.newParentId = this.newParentId, t.newInputName = this.newInputName, this.newCoordinate && (t.newCoordinate = `${Math.round(this.newCoordinate.x)}, ${Math.round(this.newCoordinate.y)}`), this.reason && (t.reason = this.reason), this.recordUndo || (t.recordUndo = this.recordUndo), t;
        }
        static fromJson(t, e, i) {
          return e = ge.fromJson(t, e, i ?? new Lc()), e.oldParentId = t.oldParentId, e.oldInputName = t.oldInputName, t.oldCoordinate && (i = t.oldCoordinate.split(","), e.oldCoordinate = new m(Number(i[0]), Number(i[1]))), e.newParentId = t.newParentId, e.newInputName = t.newInputName, t.newCoordinate && (i = t.newCoordinate.split(","), e.newCoordinate = new m(Number(i[0]), Number(i[1]))), t.reason !== void 0 && (e.reason = t.reason), t.recordUndo !== void 0 && (e.recordUndo = t.recordUndo), e;
        }
        recordNew() {
          var t = this.currentLocation();
          this.newParentId = t.parentId, this.newInputName = t.inputName, this.newCoordinate = t.coordinate;
        }
        setReason(t) {
          this.reason = t;
        }
        currentLocation() {
          var t = this.getEventWorkspace_();
          if (!this.blockId) throw Error("The block ID is undefined. Either pass a block to the constructor, or call fromJson");
          var e = t.getBlockById(this.blockId);
          if (!e) throw Error("The block associated with the block move event could not be found");
          t = {};
          var i = e.getParent();
          return i ? (t.parentId = i.id, (e = i.getInputWithBlock(e)) && (t.inputName = e.name)) : t.coordinate = e.getRelativeToSurfaceXY(), t;
        }
        isNull() {
          return this.oldParentId === this.newParentId && this.oldInputName === this.newInputName && m.equals(this.oldCoordinate, this.newCoordinate);
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.blockId) throw Error("The block ID is undefined. Either pass a block to the constructor, or call fromJson");
          var i = e.getBlockById(this.blockId);
          if (i) {
            var o = t ? this.newParentId : this.oldParentId, s = t ? this.newInputName : this.oldInputName;
            if (t = t ? this.newCoordinate : this.oldCoordinate, o) {
              var n = e.getBlockById(o);
              if (!n) {
                console.warn("Can't connect to non-existent block: " + o);
                return;
              }
            }
            if (i.getParent() && i.unplug(), t) s = i.getRelativeToSurfaceXY(), i.moveBy(t.x - s.x, t.y - s.y, this.reason);
            else {
              e = i.outputConnection, (!e || i.previousConnection && i.previousConnection.isConnected()) && (e = i.previousConnection);
              let l, a;
              i = (a = e) == null ? void 0 : a.type, s ? (i = n.getInput(s)) && (l = i.connection) : i === T.PREVIOUS_STATEMENT && (l = n.nextConnection), l && e ? e.connect(l) : console.warn("Can't connect to non-existent input: " + s);
            }
          } else console.warn("Can't move non-existent block: " + this.blockId);
        }
      };
      P(_.EVENT, p.BLOCK_MOVE, Lc);
      var xc = class extends kt {
        constructor(t, e, i) {
          super(t ? t.workspace.id : void 0), this.type = p.BUBBLE_OPEN, t && (this.blockId = t.id, this.isOpen = e, this.bubbleType = i);
        }
        toJson() {
          var t = super.toJson();
          if (this.isOpen === void 0) throw Error("Whether this event is for opening the bubble is undefined. Either pass the value to the constructor, or call fromJson");
          if (!this.bubbleType) throw Error("The type of bubble is undefined. Either pass the value to the constructor, or call fromJson");
          return t.isOpen = this.isOpen, t.bubbleType = this.bubbleType, t.blockId = this.blockId || "", t;
        }
        static fromJson(t, e, i) {
          return e = kt.fromJson(t, e, i ?? new xc()), e.isOpen = t.isOpen, e.bubbleType = t.bubbleType, e.blockId = t.blockId, e;
        }
      }, Bc, Mc = Bc || (Bc = {});
      Mc.MUTATOR = "mutator", Mc.COMMENT = "comment", Mc.WARNING = "warning", P(_.EVENT, p.BUBBLE_OPEN, xc);
      var Pc = class extends kt {
        constructor(t, e, i) {
          e = t ? t.workspace.id : e, e === null && (e = void 0), super(e), this.type = p.CLICK, this.blockId = t ? t.id : void 0, this.targetType = i;
        }
        toJson() {
          var t = super.toJson();
          if (!this.targetType) throw Error("The click target type is undefined. Either pass a block to the constructor, or call fromJson");
          return t.targetType = this.targetType, t.blockId = this.blockId, t;
        }
        static fromJson(t, e, i) {
          return e = kt.fromJson(t, e, i ?? new Pc()), e.targetType = t.targetType, e.blockId = t.blockId, e;
        }
      }, Fc, Hc = Fc || (Fc = {});
      Hc.BLOCK = "block", Hc.WORKSPACE = "workspace", Hc.ZOOM_CONTROLS = "zoom_controls", P(_.EVENT, p.CLICK, Pc);
      var Ut = class extends oi {
        constructor(t) {
          super(), this.isBlank = !0, this.isBlank = !t, t && (this.commentId = t.id, this.workspaceId = t.workspace.id, this.group = r.gd, this.recordUndo = r.Qc);
        }
        toJson() {
          var t = super.toJson();
          if (!this.commentId) throw Error("The comment ID is undefined. Either pass a comment to the constructor, or call fromJson");
          return t.commentId = this.commentId, t;
        }
        static fromJson(t, e, i) {
          return e = oi.fromJson(t, e, i ?? new Ut()), e.commentId = t.commentId, e;
        }
        static CommentCreateDeleteHelper(t, e) {
          var i = t.getEventWorkspace_();
          if (e) {
            if (!t.json) throw Error("Encountered a comment event without proper json");
            Cs(t.json, i);
          } else {
            if (!t.commentId) throw Error("The comment ID is undefined. Either pass a comment to the constructor, or call fromJson");
            (e = i.getCommentById(t.commentId)) ? e.dispose() : console.warn("Can't delete non-existent comment: " + t.commentId);
          }
        }
      }, Uc = class extends Ut {
        constructor(t, e, i) {
          super(t), this.type = p.COMMENT_CHANGE, t && (this.oldContents_ = typeof e > "u" ? "" : e, this.newContents_ = typeof i > "u" ? "" : i);
        }
        toJson() {
          var t = super.toJson();
          if (!this.oldContents_) throw Error("The old contents is undefined. Either pass a value to the constructor, or call fromJson");
          if (!this.newContents_) throw Error("The new contents is undefined. Either pass a value to the constructor, or call fromJson");
          return t.oldContents = this.oldContents_, t.newContents = this.newContents_, t;
        }
        static fromJson(t, e, i) {
          return e = Ut.fromJson(t, e, i ?? new Uc()), e.oldContents_ = t.oldContents, e.newContents_ = t.newContents, e;
        }
        isNull() {
          return this.oldContents_ === this.newContents_;
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.commentId) throw Error("The comment ID is undefined. Either pass a comment to the constructor, or call fromJson");
          if (e = e.getCommentById(this.commentId)) {
            var i = t ? this.newContents_ : this.oldContents_;
            if (i === void 0)
              throw Error(t ? "The new contents is undefined. Either pass a value to the constructor, or call fromJson" : "The old contents is undefined. Either pass a value to the constructor, or call fromJson");
            e.setText(i);
          } else console.warn("Can't change non-existent comment: " + this.commentId);
        }
      };
      P(_.EVENT, p.COMMENT_CHANGE, Uc);
      var Wc = class extends Ut {
        constructor(t, e) {
          super(t), this.newCollapsed = e, this.type = p.COMMENT_COLLAPSE;
        }
        toJson() {
          var t = super.toJson();
          if (this.newCollapsed === void 0) throw Error("The new collapse value undefined. Either call recordNew, or call fromJson");
          return t.newCollapsed = this.newCollapsed, t;
        }
        static fromJson(t, e, i) {
          return e = Ut.fromJson(t, e, i ?? new Wc()), e.newCollapsed = t.newCollapsed, e;
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.commentId) throw Error("The comment ID is undefined. Either pass a comment to the constructor, or call fromJson");
          (e = e.getCommentById(this.commentId)) ? e.setCollapsed(t ? !!this.newCollapsed : !this.newCollapsed) : console.warn("Can't collapse or uncollapse non-existent comment: " + this.commentId);
        }
      };
      P(_.EVENT, p.COMMENT_COLLAPSE, Wc);
      var Gc = class extends Ut {
        constructor(t) {
          super(t), this.type = p.COMMENT_CREATE, t && (this.json = Io(t, { addCoordinates: !0 }));
        }
        toJson() {
          var t = super.toJson();
          if (!this.json) throw Error("The comment JSON is undefined. Either pass a block to the constructor, or call fromJson");
          return t.json = this.json, t;
        }
        static fromJson(t, e, i) {
          return e = Ut.fromJson(t, e, i ?? new Gc()), e.json = t.json, e;
        }
        run(t) {
          Ut.CommentCreateDeleteHelper(this, t);
        }
      };
      P(_.EVENT, p.COMMENT_CREATE, Gc);
      var Vc = class extends Ut {
        constructor(t) {
          super(t), this.type = p.COMMENT_DELETE, t && (this.json = Io(t, { addCoordinates: !0 }));
        }
        run(t) {
          Ut.CommentCreateDeleteHelper(this, !t);
        }
        toJson() {
          var t = super.toJson();
          if (!this.json) throw Error("The comment JSON is undefined. Either pass a block to the constructor, or call fromJson");
          return t.json = this.json, t;
        }
        static fromJson(t, e, i) {
          return e = Ut.fromJson(t, e, i ?? new Vc()), e.json = t.json, e;
        }
      };
      P(_.EVENT, p.COMMENT_DELETE, Vc);
      var zc = class extends kt {
        constructor(t, e) {
          super(t ? t.workspace.id : void 0), this.type = p.COMMENT_DRAG, t && (this.commentId = t.id, this.isStart = e);
        }
        toJson() {
          var t = super.toJson();
          if (this.isStart === void 0) throw Error("Whether this event is the start of a drag is undefined. Either pass the value to the constructor, or call fromJson");
          if (this.commentId === void 0) throw Error("The comment ID is undefined. Either pass a comment to the constructor, or call fromJson");
          return t.isStart = this.isStart, t.commentId = this.commentId, t;
        }
        static fromJson(t, e, i) {
          return e = kt.fromJson(t, e, i ?? new zc()), e.isStart = t.isStart, e.commentId = t.commentId, e;
        }
      };
      P(_.EVENT, p.COMMENT_DRAG, zc);
      var Kc = class extends Ut {
        constructor(t) {
          super(t), this.type = p.COMMENT_MOVE, t && (this.comment_ = t, this.oldCoordinate_ = t.getRelativeToSurfaceXY());
        }
        recordNew() {
          if (this.newCoordinate_) throw Error("Tried to record the new position of a comment on the same event twice.");
          if (!this.comment_) throw Error("The comment is undefined. Pass a comment to the constructor if you want to use the record functionality");
          this.newCoordinate_ = this.comment_.getRelativeToSurfaceXY();
        }
        setReason(t) {
          this.reason = t;
        }
        setOldCoordinate(t) {
          this.oldCoordinate_ = t;
        }
        toJson() {
          var t = super.toJson();
          if (!this.oldCoordinate_) throw Error("The old comment position is undefined. Either pass a comment to the constructor, or call fromJson");
          if (!this.newCoordinate_) throw Error("The new comment position is undefined. Either call recordNew, or call fromJson");
          return t.oldCoordinate = `${Math.round(this.oldCoordinate_.x)}, ${Math.round(this.oldCoordinate_.y)}`, t.newCoordinate = Math.round(this.newCoordinate_.x) + "," + Math.round(this.newCoordinate_.y), t;
        }
        static fromJson(t, e, i) {
          return e = Ut.fromJson(t, e, i ?? new Kc()), i = t.oldCoordinate.split(","), e.oldCoordinate_ = new m(Number(i[0]), Number(i[1])), i = t.newCoordinate.split(","), e.newCoordinate_ = new m(Number(i[0]), Number(i[1])), e;
        }
        isNull() {
          return m.equals(this.oldCoordinate_, this.newCoordinate_);
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.commentId) throw Error("The comment ID is undefined. Either pass a comment to the constructor, or call fromJson");
          if (e = e.getCommentById(this.commentId)) {
            if (t = t ? this.newCoordinate_ : this.oldCoordinate_, !t) throw Error("Either oldCoordinate_ or newCoordinate_ is undefined. Either pass a comment to the constructor and call recordNew, or call fromJson");
            e.moveTo(t);
          } else console.warn("Can't move non-existent comment: " + this.commentId);
        }
      };
      P(_.EVENT, p.COMMENT_MOVE, Kc);
      var Xc = class extends Ut {
        constructor(t) {
          super(t), this.type = p.COMMENT_RESIZE, t && (this.oldSize = t.getSize());
        }
        recordCurrentSizeAsNewSize() {
          if (this.newSize) throw Error("Tried to record the new size of a comment on the same event twice.");
          var t = this.getEventWorkspace_();
          if (!this.commentId) throw Error("The comment ID is undefined. Either pass a comment to the constructor, or call fromJson");
          if (t = t.getCommentById(this.commentId), !t) throw Error("The comment associated with the comment resize event could not be found");
          this.newSize = t.getSize();
        }
        toJson() {
          var t = super.toJson();
          if (!this.oldSize) throw Error("The old comment size is undefined. Either pass a comment to the constructor, or call fromJson");
          if (!this.newSize) throw Error("The new comment size is undefined. Either call recordCurrentSizeAsNewSize, or call fromJson");
          return t.oldWidth = Math.round(this.oldSize.width), t.oldHeight = Math.round(this.oldSize.height), t.newWidth = Math.round(this.newSize.width), t.newHeight = Math.round(this.newSize.height), t;
        }
        static fromJson(t, e, i) {
          return e = Ut.fromJson(t, e, i ?? new Xc()), e.oldSize = new H(t.oldWidth, t.oldHeight), e.newSize = new H(t.newWidth, t.newHeight), e;
        }
        isNull() {
          return H.equals(this.oldSize, this.newSize);
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.commentId) throw Error("The comment ID is undefined. Either pass a comment to the constructor, or call fromJson");
          if (e = e.getCommentById(this.commentId)) {
            if (t = t ? this.newSize : this.oldSize, !t) throw Error("Either oldSize or newSize is undefined. Either pass a comment to the constructor and call recordCurrentSizeAsNewSize, or call fromJson");
            e.setSize(t);
          } else console.warn("Can't resize non-existent comment: " + this.commentId);
        }
      };
      P(_.EVENT, p.COMMENT_RESIZE, Xc);
      var Yc = class extends kt {
        constructor(t, e, i) {
          super(i), this.type = p.SELECTED, this.oldElementId = t ?? void 0, this.newElementId = e ?? void 0;
        }
        toJson() {
          var t = super.toJson();
          return t.oldElementId = this.oldElementId, t.newElementId = this.newElementId, t;
        }
        static fromJson(t, e, i) {
          return e = kt.fromJson(t, e, i ?? new Yc()), e.oldElementId = t.oldElementId, e.newElementId = t.newElementId, e;
        }
      };
      P(_.EVENT, p.SELECTED, Yc);
      var jc = class extends kt {
        constructor(t, e) {
          super(e), this.type = p.THEME_CHANGE, this.themeName = t;
        }
        toJson() {
          var t = super.toJson();
          if (!this.themeName) throw Error("The theme name is undefined. Either pass a theme name to the constructor, or call fromJson");
          return t.themeName = this.themeName, t;
        }
        static fromJson(t, e, i) {
          return e = kt.fromJson(t, e, i ?? new jc()), e.themeName = t.themeName, e;
        }
      };
      P(_.EVENT, p.THEME_CHANGE, jc);
      var $c = class extends kt {
        constructor(t, e, i) {
          super(i), this.type = p.TOOLBOX_ITEM_SELECT, this.oldItem = t ?? void 0, this.newItem = e ?? void 0;
        }
        toJson() {
          var t = super.toJson();
          return t.oldItem = this.oldItem, t.newItem = this.newItem, t;
        }
        static fromJson(t, e, i) {
          return e = kt.fromJson(t, e, i ?? new $c()), e.oldItem = t.oldItem, e.newItem = t.newItem, e;
        }
      };
      P(_.EVENT, p.TOOLBOX_ITEM_SELECT, $c);
      var Jc = class extends kt {
        constructor(t, e) {
          super(e), this.type = p.TRASHCAN_OPEN, this.isOpen = t;
        }
        toJson() {
          var t = super.toJson();
          if (this.isOpen === void 0) throw Error("Whether this is already open or not is undefined. Either pass a value to the constructor, or call fromJson");
          return t.isOpen = this.isOpen, t;
        }
        static fromJson(t, e, i) {
          return e = kt.fromJson(t, e, i ?? new Jc()), e.isOpen = t.isOpen, e;
        }
      };
      P(_.EVENT, p.TRASHCAN_OPEN, Jc);
      var He = class extends oi {
        constructor(t) {
          super(), this.isBlank = !0, this.isBlank = typeof t > "u", t && (this.varId = t.getId(), this.workspaceId = t.getWorkspace().id);
        }
        toJson() {
          var t = super.toJson();
          if (!this.varId) throw Error("The var ID is undefined. Either pass a variable to the constructor, or call fromJson");
          return t.varId = this.varId, t;
        }
        static fromJson(t, e, i) {
          return e = oi.fromJson(t, e, i ?? new He()), e.varId = t.varId, e;
        }
      }, qc = class extends He {
        constructor(t) {
          super(t), this.type = p.VAR_CREATE, t && (this.varType = t.getType(), this.varName = t.getName());
        }
        toJson() {
          var t = super.toJson();
          if (this.varType === void 0) throw Error("The var type is undefined. Either pass a variable to the constructor, or call fromJson");
          if (!this.varName) throw Error("The var name is undefined. Either pass a variable to the constructor, or call fromJson");
          return t.varType = this.varType, t.varName = this.varName, t;
        }
        static fromJson(t, e, i) {
          return e = He.fromJson(t, e, i ?? new qc()), e.varType = t.varType, e.varName = t.varName, e;
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.varId) throw Error("The var ID is undefined. Either pass a variable to the constructor, or call fromJson");
          if (!this.varName) throw Error("The var name is undefined. Either pass a variable to the constructor, or call fromJson");
          e = e.getVariableMap(), t ? e.createVariable(this.varName, this.varType, this.varId) : (t = e.getVariableById(this.varId)) && e.deleteVariable(t);
        }
      };
      P(_.EVENT, p.VAR_CREATE, qc);
      var Zc = class extends He {
        constructor(t) {
          super(t), this.type = p.VAR_DELETE, t && (this.varType = t.getType(), this.varName = t.getName());
        }
        toJson() {
          var t = super.toJson();
          if (this.varType === void 0) throw Error("The var type is undefined. Either pass a variable to the constructor, or call fromJson");
          if (!this.varName) throw Error("The var name is undefined. Either pass a variable to the constructor, or call fromJson");
          return t.varType = this.varType, t.varName = this.varName, t;
        }
        static fromJson(t, e, i) {
          return e = He.fromJson(t, e, i ?? new Zc()), e.varType = t.varType, e.varName = t.varName, e;
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.varId) throw Error("The var ID is undefined. Either pass a variable to the constructor, or call fromJson");
          if (!this.varName) throw Error("The var name is undefined. Either pass a variable to the constructor, or call fromJson");
          e = e.getVariableMap(), t ? (t = e.getVariableById(this.varId)) && e.deleteVariable(t) : e.createVariable(this.varName, this.varType, this.varId);
        }
      };
      P(_.EVENT, p.VAR_DELETE, Zc);
      var Qc = class extends He {
        constructor(t, e) {
          super(t), this.type = p.VAR_RENAME, t && (this.oldName = t.getName(), this.newName = typeof e > "u" ? "" : e);
        }
        toJson() {
          var t = super.toJson();
          if (!this.oldName) throw Error("The old var name is undefined. Either pass a variable to the constructor, or call fromJson");
          if (!this.newName) throw Error("The new var name is undefined. Either pass a value to the constructor, or call fromJson");
          return t.oldName = this.oldName, t.newName = this.newName, t;
        }
        static fromJson(t, e, i) {
          return e = He.fromJson(
            t,
            e,
            i ?? new Qc()
          ), e.oldName = t.oldName, e.newName = t.newName, e;
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.varId) throw Error("The var ID is undefined. Either pass a variable to the constructor, or call fromJson");
          if (!this.oldName) throw Error("The old var name is undefined. Either pass a variable to the constructor, or call fromJson");
          if (!this.newName) throw Error("The new var name is undefined. Either pass a value to the constructor, or call fromJson");
          e = e.getVariableMap();
          var i = e.getVariableById(this.varId);
          t ? i && e.renameVariable(i, this.newName) : i && e.renameVariable(i, this.oldName);
        }
      };
      P(_.EVENT, p.VAR_RENAME, Qc);
      var tu = class extends He {
        constructor(t, e, i) {
          super(t), this.oldType = e, this.newType = i, this.type = p.VAR_TYPE_CHANGE;
        }
        toJson() {
          var t = super.toJson();
          if (!this.oldType || !this.newType) throw Error("The variable's types are undefined. Either pass them to the constructor, or call fromJson");
          return t.oldType = this.oldType, t.newType = this.newType, t;
        }
        static fromJson(t, e, i) {
          return e = He.fromJson(t, e, i ?? new tu()), e.oldType = t.oldType, e.newType = t.newType, e;
        }
        run(t) {
          var e = this.getEventWorkspace_();
          if (!this.varId) throw Error("The var ID is undefined. Either pass a variable to the constructor, or call fromJson");
          if (!this.oldType || !this.newType) throw Error("The variable's types are undefined. Either pass them to the constructor, or call fromJson");
          var i = e.getVariableMap().getVariableById(this.varId);
          i && (t ? e.getVariableMap().changeVariableType(i, this.newType) : e.getVariableMap().changeVariableType(i, this.oldType));
        }
      };
      P(_.EVENT, p.VAR_TYPE_CHANGE, tu);
      var eu = class extends kt {
        constructor(t, e, i, o, s) {
          super(o), this.type = p.VIEWPORT_CHANGE, this.viewTop = t, this.viewLeft = e, this.scale = i, this.oldScale = s;
        }
        toJson() {
          var t = super.toJson();
          if (this.viewTop === void 0) throw Error("The view top is undefined. Either pass a value to the constructor, or call fromJson");
          if (this.viewLeft === void 0) throw Error("The view left is undefined. Either pass a value to the constructor, or call fromJson");
          if (this.scale === void 0) throw Error("The scale is undefined. Either pass a value to the constructor, or call fromJson");
          if (this.oldScale === void 0) throw Error("The old scale is undefined. Either pass a value to the constructor, or call fromJson");
          return t.viewTop = this.viewTop, t.viewLeft = this.viewLeft, t.scale = this.scale, t.oldScale = this.oldScale, t;
        }
        static fromJson(t, e, i) {
          return e = kt.fromJson(t, e, i ?? new eu()), e.viewTop = t.viewTop, e.viewLeft = t.viewLeft, e.scale = t.scale, e.oldScale = t.oldScale, e;
        }
      };
      P(_.EVENT, p.VIEWPORT_CHANGE, eu);
      var qd = class extends oi {
        constructor(t) {
          super(), this.isBlank = !0, this.recordUndo = !1, this.type = p.FINISHED_LOADING, this.isBlank = !!t, t && (this.workspaceId = t.id);
        }
      };
      P(_.EVENT, p.FINISHED_LOADING, qd);
      var Zd, Qd, tg, eg, ig, og, sg, ng, rg, lg, ag, hg, cg, ug, dg, gg, pg, fg, Eg, vg, _g, mg, Tg, Cg, k;
      r.Dm = p.BLOCK_CHANGE, r.Od = p.BLOCK_CREATE, r.Em = p.BLOCK_DELETE, Zd = p.BLOCK_DRAG, r.Gm = p.BLOCK_MOVE, Qd = p.BLOCK_FIELD_INTERMEDIATE_CHANGE, tg = p.BUBBLE_OPEN, eg = p.BLOCK_CHANGE, ig = p.CLICK, og = p.COMMENT_CHANGE, sg = p.COMMENT_CREATE, ng = p.COMMENT_DELETE, rg = p.COMMENT_MOVE, lg = p.COMMENT_RESIZE, ag = p.COMMENT_DRAG, hg = p.BLOCK_CREATE, cg = p.BLOCK_DELETE, ug = p.FINISHED_LOADING, dg = p.BLOCK_MOVE, gg = p.SELECTED, pg = p.THEME_CHANGE, fg = p.TOOLBOX_ITEM_SELECT, Eg = p.TRASHCAN_OPEN, vg = p.UI, _g = p.VAR_CREATE, mg = p.VAR_DELETE, Tg = p.VAR_RENAME, Cg = p.VIEWPORT_CHANGE, k = {}, k.Abstract = oi, k.BLOCK_CHANGE = r.Dm, k.BLOCK_CREATE = r.Od, k.BLOCK_DELETE = r.Em, k.BLOCK_DRAG = Zd, k.BLOCK_FIELD_INTERMEDIATE_CHANGE = Qd, k.BLOCK_MOVE = r.Gm, k.BUBBLE_OPEN = tg, k.BUMP_EVENTS = Nd, k.BlockBase = ge, k.BlockChange = Zi, k.BlockCreate = Ac, k.BlockDelete = Nc, k.BlockDrag = Dc, k.BlockFieldIntermediateChange = Oc, k.BlockMove = Lc, k.BubbleOpen = xc, k.BubbleType = Bc, k.CHANGE = eg, k.CLICK = ig, k.COMMENT_CHANGE = og, k.COMMENT_CREATE = sg, k.COMMENT_DELETE = ng, k.COMMENT_DRAG = ag, k.COMMENT_MOVE = rg, k.COMMENT_RESIZE = lg, k.CREATE = hg, k.Click = Pc, k.ClickTarget = Fc, k.CommentBase = Ut, k.CommentChange = Uc, k.CommentCollapse = Wc, k.CommentCreate = Gc, k.CommentDelete = Vc, k.CommentDrag = zc, k.CommentMove = Kc, k.CommentResize = Xc, k.DELETE = cg, k.FINISHED_LOADING = ug, k.FinishedLoading = qd, k.MOVE = dg, k.SELECTED = gg, k.Selected = Yc, k.THEME_CHANGE = pg, k.TOOLBOX_ITEM_SELECT = fg, k.TRASHCAN_OPEN = Eg, k.ThemeChange = jc, k.ToolboxItemSelect = $c, k.TrashcanOpen = Jc, k.UI = vg, k.UiBase = kt, k.VAR_CREATE = _g, k.VAR_DELETE = mg, k.VAR_RENAME = Tg, k.VIEWPORT_CHANGE = Cg, k.VarBase = He, k.VarCreate = qc, k.VarDelete = Zc, k.VarRename = Qc, k.VarTypeChange = tu, k.ViewportChange = eu, k.clearPendingUndo = bl, k.disable = function() {
        r.Ub++;
      }, k.disableOrphans = function(t) {
        if ((t.type === p.BLOCK_MOVE || t.type === p.BLOCK_CREATE || t.type === p.BLOCK_DRAG && !t.isStart) && t.workspaceId) {
          var e = ai(t.workspaceId);
          if (!t.blockId) throw Error("Encountered a blockEvent without a proper blockId");
          if (t = e.getBlockById(t.blockId)) {
            let i = r.Qc;
            try {
              r.Qc = !1;
              let o = t.getParent();
              if (o && !o.hasDisabledReason("ORPHANED_BLOCK")) {
                let s = t.getDescendants(!1);
                for (let n = 0, l; l = s[n]; n++) l.setDisabledReason(!1, "ORPHANED_BLOCK");
              } else if ((t.outputConnection || t.previousConnection) && !e.isDragging())
                do
                  t.setDisabledReason(!0, "ORPHANED_BLOCK"), t = t.getNextBlock();
                while (t);
            } finally {
              r.Qc = i;
            }
          }
        }
      }, k.enable = function() {
        r.Ub--;
      }, k.filter = yl, k.fire = N, k.fromJson = function(t, e) {
        var i = D(t.type);
        if (!i) throw Error("Unknown event type.");
        return i.fromJson(t, e);
      }, k.get = D, k.getDescendantIds = vn, k.getGroup = function() {
        return r.gd;
      }, k.getRecordUndo = function() {
        return r.Qc;
      }, k.isEnabled = ht, k.setGroup = r.B, k.setRecordUndo = function(t) {
        r.Qc = t;
      };
      var yg = class {
        constructor() {
          this.scopeChangeAudioCuesEnabled = this.isActive = !1, this.activeClassName = "blocklyKeyboardNavigation";
        }
        setIsActive(t = !0) {
          this.isActive = t, this.updateActiveVisualization();
        }
        getIsActive() {
          return this.isActive;
        }
        setScopeChangeAudioCuesEnabled(t) {
          this.scopeChangeAudioCuesEnabled = t;
        }
        getScopeChangeAudioCuesEnabled() {
          return this.scopeChangeAudioCuesEnabled;
        }
        updateActiveVisualization() {
          var t = de.getInjectionDiv().parentElement;
          this.isActive ? t?.classList.add(this.activeClassName) : t?.classList.remove(this.activeClassName);
        }
      }, st = new yg(), mf = new Intl.Collator(void 0, { sensitivity: "base" }), bg = { generateUniqueNameInternal: function(t) {
        return Pn("i", t.getVariableMap().getAllVariables().map((e) => e.getName()));
      } }, _t = { CATEGORY_NAME: "VARIABLE", TEST_ONLY: bg, VAR_LETTER_OPTIONS: "ijkmnopqrstuvwxyzabcdefgh" };
      _t.allDeveloperVariables = r.Cd, _t.allUsedVarModels = r.Bd, _t.compareByName = Ao, _t.createVariableButtonHandler = Ro, _t.deleteVariable = r.$d, _t.flyoutCategory = xn, _t.flyoutCategoryBlocks = function(t) {
        t = t.getVariableMap().getVariablesOfType("");
        var e = [];
        if (t.length > 0) {
          var i = t[t.length - 1];
          if (gt.variables_set) {
            var o = r.sc("block");
            o.setAttribute("type", "variables_set"), o.setAttribute("gap", gt.math_change ? "8" : "24"), o.appendChild(Pi(i)), e.push(o);
          }
          if (gt.math_change && (o = r.sc("block"), o.setAttribute("type", "math_change"), o.setAttribute("gap", gt.variables_get ? "20" : "8"), o.appendChild(Pi(i)), i = r.vc('<value name="DELTA"><shadow type="math_number"><field name="NUM">1</field></shadow></value>'), o.appendChild(i), e.push(o)), gt.variables_get) {
            t.sort(Ao);
            for (let s = 0, n; n = t[s]; s++) i = r.sc("block"), i.setAttribute("type", "variables_get"), i.setAttribute("gap", "8"), i.appendChild(Pi(n)), e.push(i);
          }
        }
        return e;
      }, _t.generateUniqueName = Ul, _t.generateUniqueNameFromOptions = Pn, _t.generateVariableFieldDom = Pi, _t.getAddedVariables = Hn, _t.getOrCreateVariablePackage = r.Wd, _t.getVariable = r.Vd, _t.getVariableUsesById = Un, _t.jsonFlyoutCategoryBlocks = Mn, _t.nameUsedWithAnyType = Wl, _t.nameUsedWithConflictingParam = Gl, _t.promptName = Fn, _t.renameVariable = r.Rd;
      var Xo = class extends Error {
      }, kg = class extends Xo {
        constructor(t) {
          super("Expected to find a 'type' property, defining the block type"), this.state = t;
        }
      }, zs = class extends Xo {
        constructor(t, e, i) {
          super(`The block ${e.toDevString()} is missing a(n) ${t}
connection`), this.block = e, this.state = i;
        }
      }, wg = class extends Xo {
        constructor(t, e, i, o) {
          super(`The block ${i.toDevString()} could not connect its
${e} to its parent, because: ${t}`), this.childBlock = i, this.childState = o;
        }
      }, Ig = class extends Xo {
        constructor(t) {
          super(`Encountered a real block which is defined as a child of a shadow
block. It is an invariant of Blockly that shadow blocks only have shadow
children`), this.state = t;
        }
      }, Sg = class extends Xo {
        constructor(t, e, i) {
          super(`Cannot add an icon of type '${t}' to the block ${e.toDevString()}, because there is no icon registered with type '${t}'. Make sure that all of your icons have been registered.`), this.block = e, this.state = i;
        }
      }, Qi = {};
      Qi.BadConnectionCheck = wg, Qi.DeserializationError = Xo, Qi.MissingBlockType = kg, Qi.MissingConnection = zs, Qi.RealChildOfShadow = Ig, Qi.UnregisteredIcon = Sg;
      var Rg = class {
        constructor() {
          this.priority = 50;
        }
        save(t) {
          var e = [];
          for (let i of t.getTopBlocks(!1)) (t = ee(i, { addCoordinates: !0, doFullSerialization: !1 })) && e.push(t);
          return e.length ? { languageVersion: 0, blocks: e } : null;
        }
        load(t, e) {
          t = t.blocks;
          for (let i of t) Fi(i, e, { recordUndo: r.Qc });
        }
        clear(t) {
          for (let e of t.getTopBlocks(!1)) e.dispose(!1);
        }
      };
      Ts("blocks", new Rg());
      var Ks = {};
      Ks.BlockSerializer = Rg, Ks.append = Fi, Ks.appendInternal = fi, Ks.save = ee;
      var Tf = { Control: r.C.CONTROL_KEY, Meta: "⌘", Alt: Ho ? "⌥" : r.C.ALT_KEY }, Cf = ["Meta", "Control", "Alt", "Shift"], Jt, pe = Jt || (Jt = {});
      pe[pe.UNKNOWN = 0] = "UNKNOWN", pe[pe.BEFORE = 1] = "BEFORE", pe[pe.AFTER = 2] = "AFTER", pe[pe.AROUND = 3] = "AROUND", pe[pe.INSIDE = 4] = "INSIDE", pe[pe.TO = 5] = "TO";
      var Sr = {};
      Sr.clamp = No, Sr.toDegrees = function(t) {
        return t * 180 / Math.PI;
      }, Sr.toRadians = Gn;
      var iu = null, to = null, Ag = "", Ng = "", tt, eo, io, Rr = null, mt = null, Dg = null, oo = null, Ar = null, ou = { getBoundsInfo: function() {
        var t = di(Rr), e = _s(Rr);
        return { left: t.x, right: t.x + e.width, top: t.y, bottom: t.y + e.height, width: e.width, height: e.height };
      }, getPositionMetrics: function(t, e, i, o) {
        var s = ou.getBoundsInfo(), n = _s(tt);
        return e + n.height < s.bottom ? ra(t, e, s, n) : o - n.height > s.top ? la(i, o, s, n) : e + n.height < document.documentElement.clientHeight ? ra(t, e, s, n) : o - n.height > document.documentElement.clientTop ? la(
          i,
          o,
          s,
          n
        ) : (t = bs(t, s.left, s.right, n.width), { initialX: t.divX, initialY: 0, finalX: t.divX, finalY: 0, arrowAtTop: null, arrowX: null, arrowY: null, arrowVisible: !1 });
      } }, Wt = { ANIMATION_TIME: 0.25, ARROW_HORIZONTAL_PADDING: 12, ARROW_SIZE: 16, BORDER_SIZE: 1, PADDING_Y: 16, TEST_ONLY: ou };
      Wt.clearContent = zn, Wt.createDom = Vn, Wt.getContentDiv = function() {
        return eo;
      }, Wt.getOwner = function() {
        return mt;
      }, Wt.getPositionX = bs, Wt.hide = ks, Wt.hideIfOwner = Kn, Wt.hideWithoutAnimation = Oe, Wt.isVisible = function() {
        return !!mt;
      }, Wt.repositionForWindowResize = ha, Wt.setBoundsElement = function(t) {
        Rr = t;
      }, Wt.setColour = ta, Wt.show = na, Wt.showPositionedByBlock = function(t, e, i, o, s = !0) {
        return sa(ia(e), t, s, i, o);
      }, Wt.showPositionedByField = ea;
      var Yo = {};
      Yo.commonWordPrefix = ca, Yo.commonWordSuffix = ua, Yo.isNumber = r.zf, Yo.shortestStringLength = ws, Yo.wrap = r.yf;
      var Nr = void 0, Xs = !1, ki = !1, Og = 0, so = 0, Dr = 0, Or = 0, xt = null, jo = null, ft = null, qt = { HOVER_MS: 750, LIMIT: 50, MARGINS: 5, OFFSET_X: 0, OFFSET_Y: 10, RADIUS_OK: 10 };
      qt.bindMouseEvents = Is, qt.block = _a, qt.createDom = pa, qt.display = va, qt.dispose = Ea, qt.getCustomTooltip = function() {
        return Nr;
      }, qt.getDiv = function() {
        return ft;
      }, qt.getTooltipOfObject = Do, qt.hide = Le, qt.isVisible = function() {
        return Xs;
      }, qt.setCustomTooltip = function(t) {
        Nr = t;
      }, qt.unbindMouseEvents = Ss, qt.unblock = function() {
        ki = !1;
      };
      var Lr = 0.45, xr = 0.65, Lg = { aqua: "#00ffff", black: "#000000", blue: "#0000ff", fuchsia: "#ff00ff", gray: "#808080", green: "#008000", lime: "#00ff00", maroon: "#800000", navy: "#000080", olive: "#808000", purple: "#800080", red: "#ff0000", silver: "#c0c0c0", teal: "#008080", white: "#ffffff", yellow: "#ffff00" }, fe = {};
      fe.blend = Wi, fe.getHsvSaturation = function() {
        return Lr;
      }, fe.getHsvValue = function() {
        return xr;
      }, fe.hexToRgb = Yn, fe.hsvToHex = jn, fe.hueToHex = Ta, fe.names = Lg, fe.parse = Ui, fe.rgbToHex = Rs, fe.setHsvSaturation = function(t) {
        Lr = t;
      }, fe.setHsvValue = function(t) {
        xr = t;
      };
      var Br = { checkMessageReferences: function(t) {
        var e = !0, i = t.match(/%{BKY_[A-Z]\w*}/gi);
        if (i) for (let o = 0; o < i.length; o++) {
          let s = i[o].toUpperCase();
          r.C[s.slice(6, -1)] === void 0 && (console.warn("No message string for " + i[o] + " in " + t), e = !1);
        }
        return e;
      } };
      Br.parseBlockColour = Oo, Br.replaceMessageReferences = et, Br.tokenizeInterpolation = Ca;
      var Z = class {
        get size_() {
          return this.size;
        }
        set size_(t) {
          this.size = t;
        }
        constructor(t, e, i) {
          this.DEFAULT_VALUE = null, this.name = void 0, this.tooltip = this.ariaTypeName = this.validator_ = null, this.size = new H(0, 0), this.constants_ = this.mouseDownWrapper = this.textContent_ = this.textElement_ = this.borderRect_ = this.fieldGroup_ = null, this.disposed = !1, this.maxDisplayLength = 50, this.sourceBlock_ = null, this.enabled_ = this.visible_ = this.isDirty_ = !0, this.suffixField = this.prefixField = this.clickTarget_ = null, this.EDITABLE = !0, this.SERIALIZABLE = !1, this.id_ = null, this.value_ = "DEFAULT_VALUE" in new.target.prototype ? new.target.prototype.DEFAULT_VALUE : this.DEFAULT_VALUE, this.size_ = new H(0, 0), t !== Z.SKIP_SETUP && (i && this.configure_(i), this.setValue(t), e && this.setValidator(e));
        }
        configure_(t) {
          t.tooltip && this.setTooltip(et(t.tooltip)), t.ariaTypeName && this.setAriaTypeName(t.ariaTypeName);
        }
        setSourceBlock(t) {
          if (this.sourceBlock_) throw Error("Field already bound to a block");
          if (this.sourceBlock_ = t, t.id.includes("_field")) throw Error(`Field ID indicator is contained in block ID. This may cause problems with focus: ${t.id}.`);
        }
        getConstants() {
          return !this.constants_ && this.sourceBlock_ && !this.sourceBlock_.isDeadOrDying() && this.sourceBlock_.workspace.rendered && (this.constants_ = this.sourceBlock_.workspace.getRenderer().getConstants()), this.constants_;
        }
        getSourceBlock() {
          return this.sourceBlock_;
        }
        getAriaTypeName() {
          return this.ariaTypeName || null;
        }
        setAriaTypeName(t) {
          this.ariaTypeName = et(t);
        }
        getAriaValue() {
          return this.getValue() == null ? null : this.getText();
        }
        computeAriaLabel(t = !0) {
          t = t ? this.getAriaTypeName() : null;
          var e = this.getAriaValue();
          return (e === null || e === "") && (e = r.C.FIELD_LABEL_EMPTY), t ? `${t}: ${e}` : e;
        }
        init() {
          if (!this.fieldGroup_) {
            this.fieldGroup_ = v(g.G, {}), this.isVisible() || (this.fieldGroup_.style.display = "none");
            var t = this.sourceBlock_;
            t.getSvgRoot().appendChild(this.fieldGroup_), this.initView(), this.updateEditable(), this.setTooltip(this.tooltip), this.bindEvents_(), this.initModel(), this.applyColour(), this.isFullBlockField() ? this.id_ = It() : this.id_ = `${t.id}_field_${It()}`, this.fieldGroup_.setAttribute("id", this.id_);
          }
        }
        initView() {
          this.createBorderRect_(), this.createTextElement_(), this.fieldGroup_ && b(this.fieldGroup_, "blocklyField");
        }
        initModel() {
        }
        isFullBlockField() {
          return !1;
        }
        isLabelField() {
          return !1;
        }
        createBorderRect_() {
          this.borderRect_ = v(g.RECT, { rx: this.getConstants().FIELD_BORDER_RECT_RADIUS, ry: this.getConstants().FIELD_BORDER_RECT_RADIUS, x: 0, y: 0, height: this.size_.height, width: this.size_.width, class: "blocklyFieldRect" }, this.fieldGroup_);
        }
        createTextElement_() {
          this.textElement_ = v(g.TEXT, { class: "blocklyText blocklyFieldText", "aria-hidden": "true" }, this.fieldGroup_), this.getConstants().FIELD_TEXT_BASELINE_CENTER && this.textElement_.setAttribute("dominant-baseline", "central"), this.textContent_ = document.createTextNode(""), this.textElement_.appendChild(this.textContent_);
        }
        bindEvents_() {
          var t = this.getClickTarget_();
          if (!t) throw Error("A click target has not been set.");
          Is(t), this.mouseDownWrapper = M(t, "pointerdown", this, this.onMouseDown_);
        }
        fromXml(t) {
          this.setValue(t.textContent);
        }
        toXml(t) {
          return t.textContent = this.getValue(), t;
        }
        saveState() {
          var t = this.saveLegacyState(Z);
          return t !== null ? t : this.getValue();
        }
        loadState(t) {
          this.loadLegacyState(Z, t) || this.setValue(t);
        }
        saveLegacyState(t) {
          return t.prototype.saveState === this.saveState && t.prototype.toXml !== this.toXml ? (t = r.sc("field"), t.setAttribute("name", this.name || ""), wo(this.toXml(t)).replace(' xmlns="https://developers.google.com/blockly/xml"', "")) : null;
        }
        loadLegacyState(t, e) {
          return t.prototype.loadState === this.loadState && t.prototype.fromXml !== this.fromXml ? (this.fromXml(r.vc(e)), !0) : !1;
        }
        dispose() {
          Kn(this), Vi(this);
          var t;
          (t = this.getSourceBlock()) != null && t.isDeadOrDying() || Q(this.fieldGroup_), (t = this.getClickTarget_()) && (Ss(t), delete t.tooltip), this.tooltip = null, this.disposed = !0;
        }
        updateEditable() {
          var t = this.fieldGroup_, e = this.getSourceBlock();
          this.EDITABLE && t && e && (this.enabled_ && e.isEditable() ? (b(t, "blocklyEditableField"), Y(t, "blocklyNonEditableField")) : (b(t, "blocklyNonEditableField"), Y(t, "blocklyEditableField")));
        }
        setEnabled(t) {
          this.enabled_ = t, this.updateEditable();
        }
        isEnabled() {
          return this.enabled_;
        }
        isClickable() {
          return this.enabled_ && !!this.sourceBlock_ && this.sourceBlock_.isEditable() && this.showEditor_ !== Z.prototype.showEditor_;
        }
        isClickableInFlyout(t) {
          return !t;
        }
        isCurrentlyEditable() {
          return this.enabled_ && this.EDITABLE && !!this.sourceBlock_ && this.sourceBlock_.isEditable();
        }
        isSerializable() {
          var t = !1;
          return this.name && (this.SERIALIZABLE ? t = !0 : this.EDITABLE && (console.warn("Detected an editable field that was not serializable. Please define SERIALIZABLE property as true on all editable custom fields. Proceeding with serialization."), t = !0)), t;
        }
        isVisible() {
          return this.visible_;
        }
        setVisible(t) {
          if (this.visible_ !== t) {
            this.visible_ = t;
            var e = this.fieldGroup_;
            e && (e.style.display = t ? "block" : "none");
          }
        }
        setValidator(t) {
          this.validator_ = t;
        }
        getValidator() {
          return this.validator_;
        }
        getSvgRoot() {
          return this.fieldGroup_;
        }
        getBorderRect() {
          if (!this.borderRect_) throw Error(`The border rectangle is ${this.borderRect_}.`);
          return this.borderRect_;
        }
        getTextElement() {
          if (!this.textElement_) throw Error(`The text element is ${this.textElement_}.`);
          return this.textElement_;
        }
        getTextContent() {
          if (!this.textContent_) throw Error(`The text content is ${this.textContent_}.`);
          return this.textContent_;
        }
        applyColour() {
        }
        render_() {
          this.textContent_ && (this.textContent_.nodeValue = this.getDisplayText_()), this.updateSize_();
        }
        showEditor(t) {
          this.isClickable() && this.showEditor_(t);
        }
        showEditor_() {
        }
        repositionForWindowResize() {
          return !1;
        }
        updateSize_(t) {
          var e = this.getConstants();
          t = t !== void 0 ? t : this.borderRect_ ? this.getConstants().FIELD_BORDER_RECT_X_PADDING : 0;
          var i = t * 2, o = e.FIELD_TEXT_HEIGHT, s = 0;
          this.textElement_ && (s = bo(this.textElement_), i += s), this.borderRect_ && (o = Math.max(o, e.FIELD_BORDER_RECT_HEIGHT)), this.size_ = new H(i, o), this.positionTextElement_(t, s), this.positionBorderRect_();
        }
        positionTextElement_(t, e) {
          if (this.textElement_) {
            var i = this.getConstants(), o = this.size_.height / 2, s;
            this.textElement_.setAttribute("x", String((s = this.getSourceBlock()) != null && s.RTL ? this.size_.width - e - t : t)), this.textElement_.setAttribute("y", String(i.FIELD_TEXT_BASELINE_CENTER ? o : o - i.FIELD_TEXT_HEIGHT / 2 + i.FIELD_TEXT_BASELINE));
          }
        }
        positionBorderRect_() {
          this.borderRect_ && (this.borderRect_.setAttribute("width", String(this.size_.width)), this.borderRect_.setAttribute("height", String(this.size_.height)), this.borderRect_.setAttribute("rx", String(this.getConstants().FIELD_BORDER_RECT_RADIUS)), this.borderRect_.setAttribute("ry", String(this.getConstants().FIELD_BORDER_RECT_RADIUS)));
        }
        getSize() {
          return this.isVisible() ? (this.isDirty_ && (this.render_(), this.isDirty_ = !1), this.size_) : new H(0, 0);
        }
        getScaledBBox() {
          var t = this.getSourceBlock();
          if (!t) throw new Et();
          if (this.borderRect_) {
            var e = this.borderRect_.getBoundingClientRect(), i = di(this.borderRect_);
            t = e.width, e = e.height;
          } else {
            e = this.sourceBlock_.getHeightWidth();
            let o = t.workspace.scale;
            i = this.getAbsoluteXY_(), t = (e.width + 1) * o, e = (e.height + 1) * o, kd ? (i.x += 1.5 * o, i.y += 1.5 * o) : (i.x -= 0.5 * o, i.y -= 0.5 * o);
          }
          return new F(i.y, i.y + e, i.x, i.x + t);
        }
        onLocationChange() {
        }
        getDisplayText_() {
          var t = this.getText();
          return t.length > this.maxDisplayLength && (t = t.substring(0, this.maxDisplayLength - 2) + "…"), t = t.replace(/\s/g, Z.NBSP), this.sourceBlock_ && this.sourceBlock_.RTL && (t += "‏"), t;
        }
        getText() {
          var t = this.getText_();
          return String(t !== null ? t : this.getValue());
        }
        getText_() {
          return null;
        }
        markDirty() {
          this.isDirty_ = !0, this.constants_ = null;
        }
        forceRerender() {
          this.isDirty_ = !0, this.sourceBlock_ && this.sourceBlock_.rendered && this.sourceBlock_.queueRender();
        }
        setValue(t, e = !0) {
          if (t !== null) {
            var i = r.gd;
            i || r.B(!0);
            try {
              let c = this.doClassValidation_(t), E = this.processValidation(t, c, e);
              if (!(E instanceof Error)) {
                var o, s = (o = this.getValidator()) == null ? void 0 : o.call(this, E), n = this.processValidation(E, s, e);
                if (!(n instanceof Error)) {
                  var l = this.sourceBlock_;
                  if (!l || !l.disposed) {
                    var a = this.getValue();
                    a === n ? this.doValueUpdate_(n) : (this.doValueUpdate_(n), e && l && ht() && N(new (D(p.BLOCK_CHANGE))(l, "field", this.name || null, a, n)), this.isDirty_ && this.forceRerender());
                  }
                }
              }
            } finally {
              r.B(i);
            }
          }
        }
        processValidation(t, e, i) {
          return e === null ? (this.doValueInvalid_(t, i), this.isDirty_ && this.forceRerender(), Error()) : e === void 0 ? t : e;
        }
        getValue() {
          return this.value_;
        }
        doClassValidation_(t) {
          return t ?? null;
        }
        doValueUpdate_(t) {
          this.value_ = t, this.isDirty_ = !0;
        }
        doValueInvalid_() {
        }
        onMouseDown_(t) {
          this.sourceBlock_ && !this.sourceBlock_.isDeadOrDying() && (t = this.sourceBlock_.workspace.getGesture(t)) && t.setStartField(this);
        }
        setTooltip(t) {
          t || t === "" || (t = this.sourceBlock_);
          var e = this.getClickTarget_();
          e ? e.tooltip = t : this.tooltip = t;
        }
        getTooltip() {
          var t = this.getClickTarget_();
          return Do(t || { tooltip: this.tooltip });
        }
        getClickTarget_() {
          return this.clickTarget_ || this.getSvgRoot();
        }
        getAbsoluteXY_() {
          return di(this.getClickTarget_());
        }
        referencesVariables() {
          return !1;
        }
        refreshVariableName() {
        }
        getParentInput() {
          var t = null, e = this.getSourceBlock();
          if (!e) throw new Et();
          var i = e.inputList;
          for (let o = 0; o < e.inputList.length; o++) {
            let s = i[o], n = s.fieldRow;
            for (let l = 0; l < n.length; l++) if (n[l] === this) {
              t = s;
              break;
            }
          }
          return t;
        }
        getFlipRtl() {
          return !1;
        }
        onShortcut() {
          return !1;
        }
        getFocusableElement() {
          if (!this.fieldGroup_) throw Error("This field currently has no representative DOM element.");
          return this.fieldGroup_;
        }
        getFocusableTree() {
          var t = this.getSourceBlock();
          if (!t) throw new Et();
          return t.workspace;
        }
        onNodeFocus() {
          var t = this.getSourceBlock();
          t.workspace.scrollBoundsIntoView(t.getBoundingRectangleWithoutChildren());
        }
        onNodeBlur() {
        }
        canBeFocused() {
          return !0;
        }
        performAction() {
          this.showEditor();
        }
        recomputeAriaContext() {
          try {
            var t = this.getFocusableElement();
          } catch {
            return !1;
          }
          if (!t) return !1;
          var e;
          if ((e = this.getSourceBlock()) != null && e.isInFlyout) {
            let o, s;
            if ((o = this.getSourceBlock()) == null || !o.getFullBlockField() || (s = this.getSourceBlock()) != null && s.getParent()) return w(t, y.HIDDEN, !0), !1;
            var i;
            e = ((i = this.getSourceBlock()) == null ? void 0 : i.getAriaRoleDescription()) || r.C.BLOCK_LABEL_VALUE, w(t, y.ROLEDESCRIPTION, e);
          }
          return Co(t, y.HIDDEN), G(t, W.BUTTON), i = this.computeAriaLabel(!0), this.isFullBlockField() && (i = Je(
            this.getSourceBlock(),
            ot.STANDARD,
            i
          )), w(t, y.LABEL, i), !0;
        }
        static fromJson() {
          throw Error("Attempted to instantiate a field from the registry that hasn't defined a 'fromJson' method.");
        }
      };
      Z.NBSP = " ", Z.SKIP_SETUP = Symbol("SKIP_SETUP");
      var Et = class extends Error {
        constructor() {
          super("The field has not yet been attached to its input. Call appendField to attach it.");
        }
      }, Bt = null, Ee = null, Mr = null, $o = "", Jo = "", vt, no = null, be = {};
      be.createDom = ba, be.getDiv = function() {
        return vt;
      }, be.hide = Gi, be.hideIfOwner = Vi, be.hideIfOwnerIsInWorkspace = As, be.isVisible = function() {
        return !!Bt;
      }, be.positionWithAnchor = wa, be.repositionForWindowResize = Ia, be.show = Jn, be.testOnly_setDiv = function(t) {
        if (vt = t, t === null) {
          let e;
          (e = document.querySelector(".blocklyWidgetDiv")) == null || e.remove();
        }
      };
      var Ys = null, xg = {}, wi = null, Ii = {};
      Ii.callbackFactory = r.Pg, Ii.dispose = Sa, Ii.getCurrentBlock = function() {
        return Ys;
      }, Ii.getMenu = function() {
        return wi;
      }, Ii.hide = Ns, Ii.setCurrentBlock = function(t) {
        Ys = t;
      }, Ii.show = Lo;
      var V = class {
        constructor() {
          this.registeredItems = /* @__PURE__ */ new Map(), this.reset();
        }
        reset() {
          this.registeredItems.clear();
        }
        register(t) {
          if (this.registeredItems.has(t.id)) throw Error('Menu item with ID "' + t.id + '" is already registered.');
          this.registeredItems.set(t.id, t);
        }
        unregister(t) {
          if (!this.registeredItems.has(t)) throw Error('Menu item with ID "' + t + '" not found.');
          this.registeredItems.delete(t);
        }
        getItem(t) {
          var e;
          return (e = this.registeredItems.get(t)) != null ? e : null;
        }
        getContextMenuOptions(t, e) {
          var i = [];
          for (let o of this.registeredItems.values()) {
            if (o.scopeType && (o.scopeType === nu.BLOCK && !t.block || o.scopeType === nu.COMMENT && !t.comment || o.scopeType === nu.WORKSPACE && !t.workspace))
              continue;
            let s;
            s = { id: o.id, scope: t, weight: o.weight };
            let n, l, a = (l = (n = o).preconditionFn) == null ? void 0 : l.call(n, t, e);
            if (a !== "hidden") {
              if (o.separator) s = Object.assign({}, s, { separator: !0 });
              else {
                let c = typeof o.displayText == "function" ? o.displayText(t) : o.displayText;
                s = Object.assign({}, s, { text: c, callback: o.callback, enabled: a === "enabled", associatedKeyboardShortcut: o.associatedKeyboardShortcut });
              }
              i.push(s);
            }
          }
          return i.sort(function(o, s) {
            return o.weight - s.weight;
          }), i;
        }
      }, Pr = V || (V = {}), su = Pr.ScopeType || (Pr.ScopeType = {});
      su.BLOCK = "block", su.WORKSPACE = "workspace", su.COMMENT = "comment", Pr.registry = new Pr();
      var nu = V.ScopeType, Bg = class {
        constructor(t) {
          this.comment = t, this.startLoc = null, this.workspace = t.workspace;
        }
        isMovable() {
          return this.comment.isOwnMovable() && !this.comment.isDeadOrDying() && !this.workspace.isReadOnly();
        }
        startDrag() {
          this.fireDragStartEvent(), this.startLoc = this.comment.getRelativeToSurfaceXY(), this.workspace.setResizesEnabled(!1);
          var t;
          return (t = this.workspace.getLayerManager()) == null || t.moveToDragLayer(this.comment), this.comment.setDragging(!0), this.comment;
        }
        drag(t) {
          this.comment.moveDuringDrag(t);
        }
        endDrag() {
          this.fireDragEndEvent(), this.fireMoveEvent();
          var t;
          (t = this.workspace.getLayerManager()) == null || t.moveOffDragLayer(this.comment, 50), this.workspace.getAudioManager().play("drop"), this.comment.setDragging(!1), this.comment.snapToGrid(), this.workspace.setResizesEnabled(!0);
        }
        fireDragStartEvent() {
          var t = new (D(p.COMMENT_DRAG))(this.comment, !0);
          N(t);
        }
        fireDragEndEvent() {
          var t = new (D(p.COMMENT_DRAG))(this.comment, !1);
          N(t);
        }
        fireMoveEvent() {
          if (!this.comment.isDeadOrDying()) {
            var t = new (D(p.COMMENT_MOVE))(this.comment);
            t.setReason(["drag"]), t.oldCoordinate_ = this.startLoc, t.recordNew(), N(t);
          }
        }
        revertDrag() {
          this.startLoc && this.comment.moveDuringDrag(this.startLoc);
        }
      }, Mg = /* @__PURE__ */ new WeakMap(), Fr = class {
        constructor(t, e, i, o) {
          this.id = t, this.workspace = e, this.container = i, this.commentView = o;
        }
        isVisible() {
          return this.icon.checkVisibility();
        }
        getCommentView() {
          return this.commentView;
        }
        getSize(t = !1) {
          var e = this.icon.getBBox();
          return e = F.from(e), t && (t = this.getMargin(), e.left -= t, e.top -= t, e.bottom += t, e.right += t), e;
        }
        getMargin() {
          return (this.container.getBBox().height - this.icon.getBBox().height) / 2;
        }
        getFocusableElement() {
          return this.icon;
        }
        getFocusableTree() {
          return this.workspace;
        }
        onNodeFocus() {
          var t = this.getCommentView(), e = t.getRelativeToSurfaceXY(), i = t.getSize();
          e = new F(e.y, e.y + i.height, e.x, e.x + i.width), t.workspace.scrollBoundsIntoView(e);
        }
        onNodeBlur() {
        }
        canBeFocused() {
          return this.isVisible();
        }
        recomputeAriaContext() {
          if (this.icon) {
            G(this.icon, W.BUTTON);
            var t = this.getAriaLabel();
            w(this.icon, y.LABEL, t || r.C.ARIA_LABEL_BUTTON);
          }
        }
        getAriaLabel() {
          return null;
        }
      }, Pg = class extends Fr {
        constructor(t, e, i, o) {
          super(`${t}_collapse_bar_button`, e, i, o), this.icon = v(g.IMAGE, { class: "blocklyFoldoutIcon", href: `${this.workspace.options.pathToMedia}foldout-icon.svg`, id: this.id }, this.container), this.recomputeAriaContext(), this.bindId = M(this.icon, "pointerdown", this, this.performAction.bind(this));
        }
        dispose() {
          $(this.bindId);
        }
        reposition() {
          var t = this.getMargin();
          this.icon.setAttribute("y", `${t}`), this.icon.setAttribute("x", `${t}`);
        }
        performAction(t) {
          Ft = null, this.getCommentView().bringToFront(), t && t instanceof PointerEvent && _e(t) ? t.stopPropagation() : (this.getCommentView().setCollapsed(!this.getCommentView().isCollapsed()), this.recomputeAriaContext(), this.workspace.hideChaff(), t?.stopPropagation());
        }
        getAriaLabel() {
          return this.getCommentView().isCollapsed() ? r.C.ARIA_LABEL_COMMENT_EXPAND : r.C.ARIA_LABEL_COMMENT_COLLAPSE;
        }
      }, js = class {
        constructor(t, e, i) {
          this.workspace = t, this.onFinishEditing = i, this.textChangeListeners = [], this.text = "", this.foreignObject = v(g.FOREIGNOBJECT, { class: "blocklyCommentForeignObject" }), t = document.createElementNS("http://www.w3.org/1999/xhtml", "body"), t.setAttribute("xmlns", "http://www.w3.org/1999/xhtml"), t.className = "blocklyMinimalBody", this.textArea = document.createElementNS("http://www.w3.org/1999/xhtml", "textarea"), this.textArea.setAttribute("tabindex", "-1"), this.textArea.setAttribute(
            "dir",
            this.workspace.RTL ? "RTL" : "LTR"
          ), G(this.textArea, W.TEXTBOX), this.textArea.setAttribute("placeholder", r.C.WORKSPACE_COMMENT_DEFAULT_TEXT), b(this.textArea, "blocklyCommentText"), b(this.textArea, "blocklyTextarea"), b(this.textArea, "blocklyText"), t.appendChild(this.textArea), this.foreignObject.appendChild(t), this.id = e + "_comment_textarea_", this.textArea.setAttribute("id", this.id), M(this.textArea, "change", this, this.onTextChange), M(this.textArea, "pointerdown", this, (o) => {
            o.stopPropagation(), r.t().focusNode(this), Ft = null;
          }), M(this.textArea, "wheel", this, (o) => {
            o.stopPropagation();
          }, !1, { passive: !0 }), M(this.textArea, "keydown", this, this.handleKeyDown);
        }
        getDom() {
          return this.foreignObject;
        }
        getText() {
          return this.text;
        }
        setText(t) {
          this.textArea.value = t, this.onTextChange();
        }
        setParent(t) {
          this.parent = t;
        }
        getParent() {
          return this.parent;
        }
        onTextChange() {
          var t = this.text;
          this.text = this.textArea.value;
          for (let e = this.textChangeListeners.length - 1; e >= 0; e--) this.textChangeListeners[e](t, this.text);
        }
        handleKeyDown(t) {
          (t.key === "Escape" || t.key === "Enter" && (t.ctrlKey || t.metaKey)) && (this.onFinishEditing && this.onFinishEditing(), t.stopPropagation());
        }
        addTextChangeListener(t) {
          this.textChangeListeners.push(t);
        }
        removeTextChangeListener(t) {
          this.textChangeListeners.splice(this.textChangeListeners.indexOf(t), 1);
        }
        setPlaceholderText(t) {
          this.textArea.placeholder = t;
        }
        setEditable(t) {
          t ? this.textArea.removeAttribute("readonly") : this.textArea.setAttribute("readonly", "true");
        }
        updateSize(t, e) {
          this.foreignObject.setAttribute("height", `${t.height - e.height}`), this.foreignObject.setAttribute(
            "width",
            `${t.width}`
          ), this.foreignObject.setAttribute("y", `${e.height}`), this.workspace.RTL && this.foreignObject.setAttribute("x", `${-t.width}`);
        }
        getFocusableElement() {
          return this.textArea;
        }
        getFocusableTree() {
          return this.workspace;
        }
        onNodeFocus() {
          var t = F.from(this.foreignObject.getBoundingClientRect());
          this.workspace.scrollBoundsIntoView(F.createFromPoint(gi(this.workspace, t.getOrigin()), t.getWidth(), t.getHeight()));
        }
        onNodeBlur() {
        }
        canBeFocused() {
          return !!this.id;
        }
      }, Fg = class extends Fr {
        constructor(t, e, i, o) {
          super(`${t}_delete_bar_button`, e, i, o), this.icon = v(g.IMAGE, { class: "blocklyDeleteIcon", href: `${this.workspace.options.pathToMedia}delete-icon.svg`, id: this.id }, i), this.recomputeAriaContext(), this.bindId = M(this.icon, "pointerdown", this, this.performAction.bind(this));
        }
        dispose() {
          $(this.bindId);
        }
        reposition() {
          var t = this.getMargin();
          this.icon.setAttribute("x", "0");
          var e = this.container.getBBox();
          this.icon.setAttribute("y", `${t}`), this.icon.setAttribute("x", `${e.width - this.getSize(!0).getWidth()}`);
        }
        performAction(t) {
          Ft = null, t && t instanceof PointerEvent && _e(t) ? t.stopPropagation() : (this.getCommentView().dispose(), t?.stopPropagation(), r.t().focusNode(this.workspace), this.workspace.getAudioManager().play("delete"));
        }
        getAriaLabel() {
          return r.C.REMOVE_COMMENT;
        }
      }, $s = class {
        constructor(t, e) {
          this.workspace = t, this.commentId = e, this.collapsed = !1, this.editable = !0, this.location = new m(0, 0), this.sizeChangeListeners = [], this.disposeListeners = [], this.collapseChangeListeners = [], this.resizePointerMoveListener = this.resizePointerUpListener = null, this.disposed = this.disposing = !1, this.svgRoot = v(g.G, { class: "blocklyComment blocklyEditable blocklyDraggable" }), G(this.svgRoot, W.BUTTON), w(this.svgRoot, y.ROLEDESCRIPTION, r.C.ARIA_LABEL_COMMENT), this.highlightRect = this.createHighlightRect(this.svgRoot), { topBarGroup: this.topBarGroup, topBarBackground: this.topBarBackground, deleteButton: this.deleteButton, foldoutButton: this.foldoutButton, textPreview: this.textPreview, textPreviewNode: this.textPreviewNode } = this.createTopBar(this.svgRoot), this.commentEditor = this.createTextArea(), w(this.svgRoot, y.LABELLEDBY, this.commentEditor.getFocusableElement().id), this.resizeHandle = this.createResizeHandle(this.svgRoot, t);
          var i;
          (i = t.getLayerManager()) == null || i.append(this, 50), this.size = $s.defaultCommentSize, this.setSizeWithoutFiringEvents(this.size), this.moveTo(new m(0, 0));
        }
        createHighlightRect(t) {
          return v(g.RECT, { class: "blocklyCommentHighlight" }, t);
        }
        createTopBar(t) {
          t = v(g.G, { class: "blocklyCommentTopbar" }, t);
          var e = v(g.RECT, { class: "blocklyCommentTopbarBackground" }, t), i = new Fg(this.commentId, this.workspace, t, this), o = new Pg(this.commentId, this.workspace, t, this);
          this.addDisposeListener(() => {
            i.dispose(), o.dispose();
          });
          var s = v(g.TEXT, { class: "blocklyCommentPreview blocklyCommentText blocklyText" }, t), n = document.createTextNode("");
          return s.appendChild(n), { topBarGroup: t, topBarBackground: e, deleteButton: i, foldoutButton: o, textPreview: s, textPreviewNode: n };
        }
        createTextArea() {
          var t = new js(this.workspace, this.commentId, () => this.svgRoot.focus());
          return this.svgRoot.appendChild(t.getDom()), t.addTextChangeListener((e, i) => {
            this.updateTextPreview(i), this.setSize(this.size);
          }), t;
        }
        getEditorFocusableNode() {
          return this.commentEditor;
        }
        createResizeHandle(t, e) {
          return t = v(g.IMAGE, { class: "blocklyResizeHandle", href: `${e.options.pathToMedia}resize-handle.svg` }, t), M(
            t,
            "pointerdown",
            this,
            this.onResizePointerDown
          ), t;
        }
        getSvgRoot() {
          return this.svgRoot;
        }
        getSize() {
          return this.collapsed ? this.topBarBackground.getBBox() : this.size;
        }
        setSizeWithoutFiringEvents(t) {
          var e = this.topBarBackground.getBBox(), i = this.textPreview.getBBox(), o = this.resizeHandle.getBBox();
          this.size = t = H.max(t, this.calcMinSize(e)), this.svgRoot.setAttribute("height", `${t.height}`), this.svgRoot.setAttribute("width", `${t.width}`), this.updateHighlightRect(t), this.updateTopBarSize(t), this.commentEditor.updateSize(t, e), this.deleteButton.reposition(), this.foldoutButton.reposition(), this.updateTextPreviewSize(t, e, i), this.updateResizeHandlePosition(t, o);
        }
        setSize(t) {
          var e = this.preResizeSize || this.size;
          this.setSizeWithoutFiringEvents(t), this.onSizeChange(e, this.size);
        }
        calcMinSize(t) {
          var e;
          this.updateTextPreview((e = this.commentEditor.getText()) != null ? e : "");
          var i = e = bo(this.textPreview);
          return this.foldoutButton.isVisible() ? i += this.foldoutButton.getSize(!0).getWidth() : e && (i += 4), this.deleteButton.isVisible() ? i += this.deleteButton.getSize(!0).getWidth() : e && (i += 4), new H(i, t.height + 20);
        }
        updateHighlightRect(t) {
          this.highlightRect.setAttribute("height", `${t.height}`), this.highlightRect.setAttribute("width", `${t.width}`), this.workspace.RTL && this.highlightRect.setAttribute("x", `${-t.width}`);
        }
        updateTopBarSize(t) {
          this.topBarBackground.setAttribute("width", `${t.width}`);
        }
        updateTextPreviewSize(t, e, i) {
          e = (e.height - i.height) / 2;
          var o = this.foldoutButton.getSize(!0), s = this.deleteButton.getSize(!0);
          t = t.width - o.getWidth() - s.getWidth(), this.textPreview.setAttribute(
            "x",
            `${(this.workspace.RTL ? -1 : 1) * o.getWidth()}`
          ), this.textPreview.setAttribute("y", `${e + i.height / 2}`), this.textPreview.setAttribute("width", `${t}`);
        }
        updateResizeHandlePosition(t, e) {
          this.resizeHandle.setAttribute("y", `${t.height - e.height}`), this.resizeHandle.setAttribute("x", `${t.width - e.width}`);
        }
        onSizeChange(t, e) {
          for (let i = this.sizeChangeListeners.length - 1; i >= 0; i--) this.sizeChangeListeners[i](t, e);
        }
        addSizeChangeListener(t) {
          this.sizeChangeListeners.push(t);
        }
        removeSizeChangeListener(t) {
          this.sizeChangeListeners.splice(
            this.sizeChangeListeners.indexOf(t),
            1
          );
        }
        onResizePointerDown(t) {
          this.isEditable() && (this.bringToFront(), _e(t) || (this.preResizeSize = this.getSize(), qn(this.workspace, t, new m(this.workspace.RTL ? -this.getSize().width : this.getSize().width, this.getSize().height)), this.resizePointerUpListener = M(document, "pointerup", this, this.onResizePointerUp), this.resizePointerMoveListener = M(document, "pointermove", this, this.onResizePointerMove), this.workspace.hideChaff()), t.stopPropagation());
        }
        onResizePointerUp() {
          Ft = null, this.resizePointerUpListener && ($(this.resizePointerUpListener), this.resizePointerUpListener = null), this.resizePointerMoveListener && ($(this.resizePointerMoveListener), this.resizePointerMoveListener = null), this.setSize(this.size), this.preResizeSize = void 0;
        }
        onResizePointerMove(t) {
          t = Zn(this.workspace, t), this.setSizeWithoutFiringEvents(new H(this.workspace.RTL ? -t.x : t.x, t.y));
        }
        isCollapsed() {
          return this.collapsed;
        }
        setCollapsed(t) {
          (this.collapsed = t) ? b(this.svgRoot, "blocklyCollapsed") : Y(this.svgRoot, "blocklyCollapsed"), this.setSizeWithoutFiringEvents(this.size), this.onCollapse();
        }
        onCollapse() {
          for (let t = this.collapseChangeListeners.length - 1; t >= 0; t--) this.collapseChangeListeners[t](this.collapsed);
        }
        addOnCollapseListener(t) {
          this.collapseChangeListeners.push(t);
        }
        removeOnCollapseListener(t) {
          this.collapseChangeListeners.splice(this.collapseChangeListeners.indexOf(t), 1);
        }
        isEditable() {
          return this.editable;
        }
        setEditable(t) {
          (this.editable = t) ? (b(this.svgRoot, "blocklyEditable"), Y(this.svgRoot, "blocklyReadonly")) : (Y(this.svgRoot, "blocklyEditable"), b(this.svgRoot, "blocklyReadonly")), this.commentEditor.setEditable(t);
        }
        getRelativeToSurfaceXY() {
          return this.location;
        }
        moveTo(t) {
          this.location = t, this.svgRoot.setAttribute("transform", `translate(${t.x}, ${t.y})`);
        }
        getText() {
          return this.commentEditor.getText();
        }
        setText(t) {
          this.commentEditor.setText(t);
        }
        setPlaceholderText(t) {
          this.commentEditor.setPlaceholderText(t);
        }
        addTextChangeListener(t) {
          this.commentEditor.addTextChangeListener(t);
        }
        removeTextChangeListener(t) {
          this.commentEditor.removeTextChangeListener(t);
        }
        updateTextPreview(t) {
          this.textPreviewNode.textContent = this.truncateText(t);
        }
        truncateText(t) {
          return t.length >= 12 ? `${t.substring(0, 9)}...` : t;
        }
        bringToFront() {
          var t = this.svgRoot.parentNode, e = t.childNodes;
          e[e.length - 1] !== this.svgRoot && t.appendChild(this.svgRoot);
        }
        onDeleteDown(t) {
          Ft = null, _e(t) || this.dispose(), t.stopPropagation();
        }
        dispose() {
          this.disposing = !0, Q(this.svgRoot);
          for (let t = this.disposeListeners.length - 1; t >= 0; t--) this.disposeListeners[t]();
          this.disposeListeners.length = 0, this.disposed = !0;
        }
        isDisposed() {
          return this.disposed;
        }
        isDeadOrDying() {
          return this.disposing || this.disposed;
        }
        addDisposeListener(t) {
          this.disposeListeners.push(t);
        }
        removeDisposeListener(t) {
          this.disposeListeners.splice(
            this.disposeListeners.indexOf(t),
            1
          );
        }
        getCommentBarButtons() {
          return [this.foldoutButton, this.deleteButton];
        }
      };
      $s.defaultCommentSize = new H(120, 100), ce(`
.injectionDiv {
  --commentFillColour: #FFFCC7;
  --commentBorderColour: #F2E49B;
}

.blocklyComment .blocklyTextarea {
  background-color: var(--commentFillColour);
  border: 1px solid var(--commentBorderColour);
  box-sizing: border-box;
  display: block;
  outline: 0;
  padding: 5px;
  resize: none;
  width: 100%;
  height: 100%;
}

.blocklyReadonly.blocklyComment .blocklyTextarea {
  cursor: inherit;
}

.blocklyDeleteIcon {
  width: 20px;
  height: 20px;
  display: none;
  cursor: pointer;
}

.blocklyFoldoutIcon {
  width: 20px;
  height: 20px;
  transform-origin: 12px 12px;
  cursor: pointer;
}
.blocklyResizeHandle {
  width: 12px;
  height: 12px;
  cursor: se-resize;
}
.blocklyReadonly.blocklyComment .blocklyResizeHandle {
  cursor: inherit;
}

.blocklyCommentTopbarBackground {
  fill: var(--commentBorderColour);
  height: 24px;
}

.blocklyComment .blocklyCommentPreview.blocklyText {
  fill: #000;
  dominant-baseline: middle;
  visibility: hidden;
}

.blocklyCollapsed.blocklyComment .blocklyCommentPreview {
  visibility: visible;
}

.blocklyCollapsed.blocklyComment .blocklyCommentForeignObject,
.blocklyCollapsed.blocklyComment .blocklyResizeHandle {
  display: none;
}

.blocklyCollapsed.blocklyComment .blocklyFoldoutIcon {
  transform: rotate(-90deg);
}

.blocklyRTL .blocklyCommentTopbar {
  transform: scale(-1, 1);
}

.blocklyRTL .blocklyCommentForeignObject {
  direction: rtl;
}

.blocklyRTL .blocklyCommentPreview {
  /* Revert the scale and control RTL using direction instead. */
  transform: scale(-1, 1);
  direction: rtl;
}

.blocklyRTL .blocklyResizeHandle {
  transform: scale(-1, 1);
  cursor: sw-resize;
}

.blocklyCommentHighlight {
  fill: none;
}

.blocklyComment.blocklyActiveFocus .blocklyCommentHighlight {
  stroke: var(--blockly-active-node-color);
  stroke-width: calc(2 * var(--blockly-selection-width));
}

.blocklyCollapsed.blocklyComment.blocklyActiveFocus .blocklyCommentTopbarBackground {
  stroke: var(--blockly-active-node-color);
  stroke-width: var(--blockly-selection-width);
}

.blocklyCommentText.blocklyActiveFocus {
  border-color: var(--blockly-active-node-color);
  border-width: var(--blockly-selection-width);
}

.blocklyCommentTopbar image.blocklyActiveFocus {
  outline: var(--blockly-selection-width) solid var(--blockly-active-node-color);
}

.blocklyCollapsed.blocklyComment.blocklyActiveFocus .blocklyCommentHighlight {
  stroke: none;
}
`);
      var Hr = class {
        constructor(t, e) {
          this.workspace = t, this.text = "", this.collapsed = !1, this.deletable = this.movable = this.editable = !0, this.location = new m(0, 0), this.disposing = this.disposed = !1, this.id = e && !t.getCommentById(e) ? e : je(), this.size = $s.defaultCommentSize, t.addTopComment(this), this.fireCreateEvent();
        }
        fireCreateEvent() {
          ht() && N(new (D(p.COMMENT_CREATE))(this));
        }
        fireDeleteEvent() {
          ht() && N(new (D(p.COMMENT_DELETE))(this));
        }
        fireChangeEvent(t, e) {
          ht() && N(new (D(p.COMMENT_CHANGE))(this, t, e));
        }
        fireCollapseEvent(t) {
          ht() && N(new (D(p.COMMENT_COLLAPSE))(this, t));
        }
        setText(t) {
          var e = this.text;
          this.text = t, this.fireChangeEvent(e, t);
        }
        getText() {
          return this.text;
        }
        setSize(t) {
          var e = new (D(p.COMMENT_RESIZE))(this);
          this.size = t, e.recordCurrentSizeAsNewSize(), N(e);
        }
        getSize() {
          return this.size;
        }
        setCollapsed(t) {
          this.collapsed = t, this.fireCollapseEvent(t);
        }
        isCollapsed() {
          return this.collapsed;
        }
        setEditable(t) {
          this.editable = t;
        }
        isEditable() {
          return this.isOwnEditable() && !this.workspace.isReadOnly();
        }
        isOwnEditable() {
          return this.editable;
        }
        setMovable(t) {
          this.movable = t;
        }
        isMovable() {
          return this.isOwnMovable() && !this.workspace.isReadOnly() && !this.workspace.isFlyout;
        }
        isOwnMovable() {
          return this.movable;
        }
        setDeletable(t) {
          this.deletable = t;
        }
        isDeletable() {
          return this.isOwnDeletable() && !this.isDeadOrDying() && !this.workspace.isReadOnly() && !this.workspace.isFlyout;
        }
        isOwnDeletable() {
          return this.deletable;
        }
        moveTo(t, e) {
          var i = new (D(p.COMMENT_MOVE))(this);
          e && i.setReason(e), this.location = t, i.recordNew(), N(i);
        }
        getRelativeToSurfaceXY() {
          return this.location.clone();
        }
        dispose() {
          this.disposing = !0, this.fireDeleteEvent(), this.workspace.removeTopComment(this), this.disposed = !0;
        }
        isDisposed() {
          return this.disposed;
        }
        isDeadOrDying() {
          return this.disposing || this.disposed;
        }
      }, ro = class extends Hr {
        constructor(t, e) {
          super(t, e), this.dragStrategy = new Bg(this), this.workspace = t, this.view = new $s(t, this.id), this.view.getEditorFocusableNode().setParent(this), this.view.setSize(this.getSize()), this.view.setEditable(this.isEditable()), this.view.getSvgRoot().setAttribute("data-id", this.id), this.view.getSvgRoot().setAttribute("id", this.id), this.addModelUpdateBindings(), M(this.view.getSvgRoot(), "pointerdown", this, this.startGesture);
        }
        addModelUpdateBindings() {
          this.view.addTextChangeListener((t, e) => void super.setText(e)), this.view.addSizeChangeListener((t, e) => void super.setSize(e)), this.view.addOnCollapseListener(() => void super.setCollapsed(this.view.isCollapsed())), this.view.addDisposeListener(() => {
            this.isDeadOrDying() || this.dispose();
          });
        }
        setText(t) {
          this.view.setText(t);
        }
        setPlaceholderText(t) {
          this.view.setPlaceholderText(t);
        }
        setSize(t) {
          this.view.setSize(t);
        }
        setCollapsed(t) {
          this.view.setCollapsed(t);
        }
        setEditable(t) {
          super.setEditable(t), this.view.setEditable(this.isEditable());
        }
        getSvgRoot() {
          return this.view.getSvgRoot();
        }
        getSize() {
          return super.getSize();
        }
        getBoundingRectangle() {
          var t = this.getRelativeToSurfaceXY(), e, i, o = (i = (e = this.view) == null ? void 0 : e.getSize()) != null ? i : this.getSize();
          return this.workspace.RTL ? (e = t.x - o.width, i = t.x) : (e = t.x, i = t.x + o.width), new F(t.y, t.y + o.height, e, i);
        }
        moveBy(t, e, i) {
          var o = this.getRelativeToSurfaceXY();
          t = new m(o.x + t, o.y + e), this.moveTo(t, i);
        }
        moveTo(t, e) {
          super.moveTo(t, e), this.view.moveTo(t);
        }
        moveDuringDrag(t) {
          this.location = t, this.view.moveTo(t);
        }
        setDragging(t) {
          t ? b(this.getSvgRoot(), "blocklyDragging") : Y(this.getSvgRoot(), "blocklyDragging");
        }
        dispose() {
          this.disposing = !0;
          var t = r.t();
          t.getFocusedNode() === this && setTimeout(() => {
            t.isRegistered(this.workspace) && t.focusTree(this.workspace);
          }, 0), this.view.isDeadOrDying() || this.view.dispose(), super.dispose();
        }
        startGesture(t) {
          var e = this.workspace.getGesture(t);
          e && (e.handleCommentStart(t, this), r.t().focusNode(this));
        }
        setDeleteStyle(t) {
          t ? b(this.getSvgRoot(), "blocklyDraggingDelete") : Y(this.getSvgRoot(), "blocklyDraggingDelete");
        }
        isCopyable() {
          return this.isOwnMovable() && this.isOwnDeletable();
        }
        isMovable() {
          return this.dragStrategy.isMovable();
        }
        startDrag() {
          return this.dragStrategy.startDrag();
        }
        drag(t) {
          this.dragStrategy.drag(t);
        }
        endDrag() {
          this.dragStrategy.endDrag();
        }
        revertDrag() {
          this.dragStrategy.revertDrag();
        }
        select() {
          b(
            this.getSvgRoot(),
            "blocklySelected"
          ), ci(this);
        }
        unselect() {
          Y(this.getSvgRoot(), "blocklySelected"), ci(null);
        }
        toCopyData() {
          return { paster: yr.TYPE, commentState: Io(this, { addCoordinates: !0, saveIds: !1 }) };
        }
        showContextMenu(t) {
          var e = V.registry.getContextMenuOptions({ comment: this, focusedNode: this }, t), i = t instanceof PointerEvent ? new m(t.clientX, t.clientY) : pi(this.workspace, this.getRelativeToSurfaceXY()).translate(10, 10);
          Lo(t, e, this.workspace.RTL, this.workspace, i);
        }
        snapToGrid() {
          if (!this.isDeadOrDying()) {
            var t = this.workspace.getGrid();
            if (t != null && t.shouldSnap()) {
              var e = this.getRelativeToSurfaceXY();
              t = t.alignXY(e), t !== e && this.moveTo(t, ["snap"]);
            }
          }
        }
        getEditorFocusableNode() {
          return this.view.getEditorFocusableNode();
        }
        getFocusableElement() {
          return this.getSvgRoot();
        }
        getFocusableTree() {
          return this.workspace;
        }
        onNodeFocus() {
          this.select();
          var t;
          (t = this.getSvgRoot().parentElement) == null || t.appendChild(this.getSvgRoot()), this.workspace.scrollBoundsIntoView(this.getBoundingRectangle());
        }
        onNodeBlur() {
          this.unselect();
        }
        canBeFocused() {
          return !0;
        }
        performAction() {
          this.setCollapsed(!1), r.t().focusNode(this.getEditorFocusableNode());
        }
      }, Yt = { appendDomToWorkspace: function(t, e) {
        if (!e.getBlocksBoundingBox) return r.ch(t, e);
        var i = e.getBlocksBoundingBox();
        if (t = r.ch(t, e), i && i.top !== i.bottom) {
          var o = i.bottom;
          i = e.RTL ? i.right : i.left;
          var s = 1 / 0;
          let n = -1 / 0, l = 1 / 0;
          for (let a = 0; a < t.length; a++) {
            let c = e.getBlockById(t[a]).getRelativeToSurfaceXY();
            c.y < l && (l = c.y), c.x < s && (s = c.x), c.x > n && (n = c.x);
          }
          for (o = o - l + 10, i = e.RTL ? i - n : i - s, s = 0; s < t.length; s++) e.getBlockById(t[s]).moveBy(i, o, ["create"]);
        }
        return t;
      } };
      Yt.blockToDom = Ei, Yt.blockToDomWithXY = Da, Yt.clearWorkspaceAndLoadFromXml = function(t, e) {
        return e.setResizesEnabled(!1), e.clear(), t = r.ch(t, e), e.setResizesEnabled(!0), t;
      }, Yt.deleteNext = function(t) {
        for (let e = 0; e < t.childNodes.length; e++) {
          let i = t.childNodes[e];
          if (i.nodeName.toLowerCase() === "next") {
            t.removeChild(i);
            break;
          }
        }
      }, Yt.domToBlock = r.fh, Yt.domToBlockInternal = zi, Yt.domToPrettyText = function(t) {
        t = xo(t).split("<");
        var e = "";
        for (let i = 1; i < t.length; i++) {
          let o = t[i];
          o[0] === "/" && (e = e.substring(2)), t[i] = e + "<" + o, o[0] !== "/" && o.slice(-2) !== "/>" && (e += "  ");
        }
        return t = t.join(`
`), t = t.replace(/(<(\w+)\b[^>]*>[^\n]*)\n *<\/\2>/g, "$1</$2>"), t.replace(/^\n/, "");
      }, Yt.domToText = xo, Yt.domToVariables = xa, Yt.domToWorkspace = r.ch, Yt.loadWorkspaceComment = La, Yt.saveWorkspaceComment = Aa, Yt.variablesToDom = Na, Yt.workspaceToDom = function(t, e = !1) {
        var i = r.sc("xml"), o = Na(r.Bd(t));
        o.hasChildNodes() && i.appendChild(o);
        for (let s of t.getTopComments()) i.appendChild(Aa(s, e));
        for (t = t.getTopBlocks(!0), o = 0; o < t.length; o++) i.appendChild(Da(t[o], e));
        return i;
      };
      var Hg = { fromJsonInternal: function(t) {
        var e = Mt(_.FIELD, t.type, void 0);
        return e ? e.fromJson(t) : (console.warn("Blockly could not create a field of type " + t.type + ". The field is probably not being registered. This could be because the file is not loaded, the field does not register itself (Issue #1584), or the registration is not being reached."), null);
      } }, Ur = { TEST_ONLY: Hg };
      Ur.fromJson = r.lh, Ur.register = xe, Ur.unregister = function(t) {
        Mi(_.FIELD, t);
      };
      var Nt = class extends Z {
        constructor(t, e, i) {
          super(Z.SKIP_SETUP), this.svgArrow = this.arrow = this.imageElement = this.menu_ = this.selectedMenuItem = null, this.SERIALIZABLE = !0, this.clickTarget_ = this.suffixField = this.prefixField = this.generatedOptions = null, this.isInitialized = !1, t !== Z.SKIP_SETUP && (this.setOptions(t), i && this.configure_(i), e && this.setValidator(e));
        }
        fromXml(t) {
          this.isOptionListDynamic() && this.getOptions(!1), this.setValue(t.textContent);
        }
        loadState(t) {
          this.loadLegacyState(Nt, t) || (this.isOptionListDynamic() && this.getOptions(!1), this.setValue(t));
        }
        initView() {
          this.shouldAddBorderRect_() ? this.createBorderRect_() : this.clickTarget_ = this.sourceBlock_.getSvgRoot(), this.createTextElement_(), this.imageElement = v(g.IMAGE, {}, this.fieldGroup_), this.getConstants().FIELD_DROPDOWN_SVG_ARROW ? this.createSVGArrow_() : this.createTextArrow_(), this.borderRect_ && b(this.borderRect_, "blocklyDropdownRect"), this.fieldGroup_ && (b(this.fieldGroup_, "blocklyField"), b(this.fieldGroup_, "blocklyDropdownField")), this.recomputeAriaContext(), this.isInitialized = !0;
        }
        isFullBlockField() {
          var t;
          return !this.shouldAddBorderRect_() && !((t = this.getSourceBlock()) == null || !t.isSimpleReporter());
        }
        shouldAddBorderRect_() {
          var t;
          return !this.getConstants().FIELD_DROPDOWN_NO_BORDER_RECT_SHADOW || this.getConstants().FIELD_DROPDOWN_NO_BORDER_RECT_SHADOW && !((t = this.getSourceBlock()) != null && t.isShadow());
        }
        createTextArrow_() {
          this.arrow = v(g.TSPAN, {}, this.textElement_);
          var t;
          this.arrow.appendChild(document.createTextNode((t = this.getSourceBlock()) != null && t.RTL ? Nt.ARROW_CHAR + " " : " " + Nt.ARROW_CHAR)), this.getConstants().FIELD_TEXT_BASELINE_CENTER && this.arrow.setAttribute("dominant-baseline", "central");
          var e;
          (e = this.getSourceBlock()) != null && e.RTL ? this.getTextElement().insertBefore(this.arrow, this.textContent_) : this.getTextElement().appendChild(this.arrow);
        }
        createSVGArrow_() {
          this.svgArrow = v(g.IMAGE, { height: this.getConstants().FIELD_DROPDOWN_SVG_ARROW_SIZE + "px", width: this.getConstants().FIELD_DROPDOWN_SVG_ARROW_SIZE + "px" }, this.fieldGroup_), w(this.svgArrow, y.HIDDEN, !0), this.svgArrow.setAttributeNS(
            "http://www.w3.org/1999/xlink",
            "xlink:href",
            this.getConstants().FIELD_DROPDOWN_SVG_ARROW_DATAURI
          );
        }
        showEditor_(t) {
          var e = this.getSourceBlock();
          if (!e) throw new Et();
          this.dropdownCreate(), this.menu_ && (this.menu_.openingCoords = t && typeof t.clientX == "number" ? new m(t.clientX, t.clientY) : null, zn(), t = this.menu_.render(eo), b(t, "blocklyDropdownMenu"), this.getConstants().FIELD_DROPDOWN_COLOURED_DIV && (e = e.getColour(), t = this.sourceBlock_.getColourTertiary(), ta(e, t)), ea(this, this.dropdownDispose_.bind(this)), eo.style.height = `${this.menu_.getSize().height}px`, this.menu_.focus(), this.selectedMenuItem && this.menu_.setHighlighted(this.selectedMenuItem), this.applyColour(), w(this.getFocusableElement(), y.EXPANDED, !0));
        }
        dropdownCreate() {
          var t = this.getSourceBlock();
          if (!t) throw new Et();
          var e = new kc();
          e.setRole(W.LISTBOX), this.menu_ = e, w(this.getFocusableElement(), y.CONTROLS, this.menu_.getId());
          var i = this.getOptions(!1);
          this.selectedMenuItem = null;
          for (let n = 0; n < i.length; n++) {
            var o = i[n];
            if (o === Nt.SEPARATOR) {
              e.addChild(new Kd());
              continue;
            }
            let [l, a] = o;
            if (o = this.computeOptionAriaLabel(
              o,
              n
            ), Ki(l)) {
              var s = new Image(l.width, l.height);
              s.src = l.src, s.alt = l.alt;
            } else s = l;
            o = new br(s, a, o), o.setRole(W.OPTION), o.setRightToLeft(t.RTL), o.setCheckable(!0), e.addChild(o), o.setChecked(a === this.value_), a === this.value_ && (this.selectedMenuItem = o), o.onAction(this.handleMenuActionEvent, this);
          }
        }
        dropdownDispose_() {
          this.menu_ && this.menu_.dispose(), this.selectedMenuItem = this.menu_ = null, this.applyColour(), w(this.getFocusableElement(), y.EXPANDED, !1);
        }
        handleMenuActionEvent(t) {
          Kn(this, !0), this.onItemSelected_(
            this.menu_,
            t
          );
        }
        onItemSelected_(t, e) {
          this.setValue(e.getValue());
        }
        isOptionListDynamic() {
          return typeof this.menuGenerator_ == "function";
        }
        getOptions(t) {
          if (!this.menuGenerator_) throw TypeError("A menu generator was never defined.");
          return Array.isArray(this.menuGenerator_) ? this.menuGenerator_ : t && this.generatedOptions ? this.generatedOptions : (this.generatedOptions = this.menuGenerator_(), this.validateOptions(this.generatedOptions), this.generatedOptions);
        }
        setOptions(t) {
          Array.isArray(t) ? (this.validateOptions(t), t = this.trimOptions(t), this.menuGenerator_ = t.options, this.prefixField = t.prefix || null, this.suffixField = t.suffix || null) : this.menuGenerator_ = t, this.selectedOption = this.getOptions(!1)[0], this.setValue(this.selectedOption[1]);
        }
        doClassValidation_(t) {
          return this.getOptions(!0).some((e) => e[1] === t) ? t : (this.sourceBlock_ && console.warn("Cannot set the dropdown's value to an unavailable option. Block type: " + this.sourceBlock_.type + ", Field name: " + this.name + ", Value: " + t), null);
        }
        doValueUpdate_(t) {
          super.doValueUpdate_(t), t = this.getOptions(!0);
          for (let e = 0, i; i = t[e]; e++) i[1] === this.value_ && (this.selectedOption = i);
          this.isInitialized && this.recomputeAriaContext();
        }
        applyColour() {
          var t = this.sourceBlock_;
          this.borderRect_ && (this.borderRect_.setAttribute("stroke", t.getColourTertiary()), this.menu_ ? this.borderRect_.setAttribute("fill", t.getColourTertiary()) : this.borderRect_.setAttribute("fill", "transparent")), t && this.arrow && (t.isShadow() ? this.arrow.style.fill = t.getColourSecondary() : this.arrow.style.fill = t.getColour());
        }
        render_() {
          this.getTextContent().nodeValue = "", this.imageElement.style.display = "none";
          var t = this.selectedOption && this.selectedOption[0];
          Ki(t) ? this.renderSelectedImage(t) : this.renderSelectedText(), this.positionBorderRect_();
        }
        renderSelectedImage(t) {
          var e = this.getSourceBlock();
          if (!e) throw new Et();
          this.imageElement.style.display = "", this.imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", t.src), this.imageElement.setAttribute("height", String(t.height)), this.imageElement.setAttribute("width", String(t.width));
          var i = Number(t.height);
          t = Number(t.width);
          var o = !!this.borderRect_, s = Math.max(o ? this.getConstants().FIELD_DROPDOWN_BORDER_RECT_HEIGHT : 0, i + Nt.IMAGE_Y_PADDING);
          o = o ? this.getConstants().FIELD_BORDER_RECT_X_PADDING : 0;
          var n = this.svgArrow ? this.positionSVGArrow(t + o, s / 2 - this.getConstants().FIELD_DROPDOWN_SVG_ARROW_SIZE / 2) : bo(this.arrow);
          this.size_ = new H(t + n + o * 2, s);
          var l = 0;
          e.RTL ? this.imageElement.setAttribute("x", `${o + n}`) : (l = t + n, this.getTextElement().setAttribute("text-anchor", "end"), this.imageElement.setAttribute("x", `${o}`)), this.imageElement.setAttribute("y", String(s / 2 - i / 2)), this.positionTextElement_(l + o, t + n);
        }
        renderSelectedText() {
          this.getTextContent().nodeValue = this.getDisplayText_();
          var t = this.getTextElement();
          b(t, "blocklyDropdownText"), t.setAttribute("text-anchor", "start");
          var e = !!this.borderRect_;
          t = Math.max(e ? this.getConstants().FIELD_DROPDOWN_BORDER_RECT_HEIGHT : 0, this.getConstants().FIELD_TEXT_HEIGHT);
          var i = bo(this.getTextElement());
          e = e ? this.getConstants().FIELD_BORDER_RECT_X_PADDING : 0;
          var o = 0;
          this.svgArrow && (o = this.positionSVGArrow(i + e, t / 2 - this.getConstants().FIELD_DROPDOWN_SVG_ARROW_SIZE / 2)), this.size_ = new H(i + o + e * 2, t), this.positionTextElement_(e, i);
        }
        positionSVGArrow(t, e) {
          if (!this.svgArrow) return 0;
          var i = this.getSourceBlock();
          if (!i) throw new Et();
          var o = this.borderRect_ ? this.getConstants().FIELD_BORDER_RECT_X_PADDING : 0, s = this.getConstants().FIELD_DROPDOWN_SVG_ARROW_PADDING, n = this.getConstants().FIELD_DROPDOWN_SVG_ARROW_SIZE;
          return this.svgArrow.setAttribute("transform", "translate(" + (i.RTL ? o : t + s) + "," + e + ")"), n + s;
        }
        getText_() {
          if (!this.selectedOption) return null;
          var t = this.selectedOption[0];
          if (Ki(t)) return t.alt;
          if (typeof HTMLElement < "u" && t instanceof HTMLElement) {
            let e;
            return t.title || ((e = t.ariaLabel) != null ? e : t.innerText);
          }
          return typeof t == "string" ? t : (console.warn("Can't get text for existing dropdown option. If you're using HTMLElement dropdown options in node, ensure you're using jsdom-global or similar."), null);
        }
        static fromJson(t) {
          if (!t.options) throw Error("options are required for the dropdown field. The options property must be assigned an array of [humanReadableValue, languageNeutralValue] tuples.");
          return new this(t.options, void 0, t);
        }
        trimOptions(t) {
          var e = !1, i = t.map((l) => {
            if (l === Nt.SEPARATOR) return e = !0, l;
            var [a, c, E] = l;
            return typeof a == "string" ? (l = [et(a), c], E && l.push(et(E)), l) : (e = !0, l = [Ki(a) ? Object.assign({}, a, { alt: et(a.alt) }) : a, c], E && l.push(et(E)), l);
          });
          if (e || t.length < 2) return { options: i };
          var o = i.map(([l]) => l), s = ws(o);
          t = ca(o, s);
          var n = ua(o, s);
          return !t && !n || s <= t + n ? { options: i } : (s = t ? o[0].substring(0, t - 1) : void 0, o = n ? o[0].substr(1 - n) : void 0, { options: this.applyTrim(i, t, n), prefix: s, suffix: o });
        }
        applyTrim(t, e, i) {
          return t.map(([o, s, n]) => (o = o.substring(e, o.length - i), n !== void 0 ? [o, s, n] : [o, s]));
        }
        validateOptions(t) {
          if (!Array.isArray(t)) throw TypeError("FieldDropdown options must be an array.");
          if (!t.length) throw TypeError("FieldDropdown options must not be an empty array.");
          var e = !1;
          for (let i = 0; i < t.length; i++) {
            let o = t[i];
            Array.isArray(o) || o === Nt.SEPARATOR ? typeof o[1] != "string" ? (e = !0, console.error(`Invalid option[${i}]: Each FieldDropdown option id must be a string.
          Found ${o[1]} in: ${o}`)) : !o[0] || typeof o[0] == "string" || Ki(o[0]) || typeof HTMLElement < "u" && o[0] instanceof HTMLElement ? o[2] && typeof o[2] != "string" && (e = !0, console.error(`Invalid option[${i}]: Each FieldDropdown option ARIA label must be a string.
          Found ${o[2]} in: ${o}`)) : (e = !0, console.error(`Invalid option[${i}]: Each FieldDropdown option must have a string
          label, image description, or HTML element. Found ${o[0]} in: ${o}`)) : (e = !0, console.error(`Invalid option[${i}]: Each FieldDropdown option must be an array or
          the string literal 'separator'. Found: ${o}`));
          }
          if (e) throw TypeError("Found invalid FieldDropdown options.");
        }
        getAriaTypeName() {
          return this.ariaTypeName || r.C.ARIA_TYPE_FIELD_DROPDOWN;
        }
        getAriaValue() {
          return this.getSelectedAriaLabel() || this.getText() || r.C.FIELD_LABEL_EMPTY;
        }
        getSelectedAriaLabel() {
          if (!this.selectedOption) return null;
          var t = this.selectedOption;
          return t = this.computeOptionAriaLabel(t, this.getOptions(!1).indexOf(t)), typeof t == "string" ? t : null;
        }
        recomputeAriaContext() {
          if (!super.recomputeAriaContext()) return !1;
          var t = this.getFocusableElement();
          return w(t, y.HASPOPUP, "listbox"), w(t, y.EXPANDED, !!this.menu_), !0;
        }
        computeOptionAriaLabel(t, e) {
          if (t === Nt.SEPARATOR) return "";
          var [i, , o] = t;
          if (typeof o == "string" && o.trim()) return o;
          if (t = null, Ki(i)) {
            let s;
            t = (s = i.ariaLabel) != null ? s : i.alt;
          } else if (typeof HTMLElement < "u" && i instanceof HTMLElement) {
            let s;
            t = (s = i.ariaLabel) != null ? s : i.title || i.innerText;
          } else typeof i == "string" && (t = i);
          return t && t.trim() ? t : r.C.FIELD_LABEL_OPTION_INDEX.replace("%1", String(e + 1));
        }
      };
      Nt.SEPARATOR = "separator", Nt.ARROW_CHAR = "▾", Nt.IMAGE_Y_OFFSET = 5, Nt.IMAGE_Y_PADDING = Nt.IMAGE_Y_OFFSET * 2, xe("field_dropdown", Nt);
      var C, h = C || (C = {});
      h[h.WIN_KEY_FF_LINUX = 0] = "WIN_KEY_FF_LINUX", h[h.MAC_ENTER = 3] = "MAC_ENTER", h[h.BACKSPACE = 8] = "BACKSPACE", h[h.TAB = 9] = "TAB", h[h.NUM_CENTER = 12] = "NUM_CENTER", h[h.ENTER = 13] = "ENTER", h[h.SHIFT = 16] = "SHIFT", h[h.CTRL = 17] = "CTRL", h[h.ALT = 18] = "ALT", h[h.PAUSE = 19] = "PAUSE", h[h.CAPS_LOCK = 20] = "CAPS_LOCK", h[h.ESC = 27] = "ESC", h[h.SPACE = 32] = "SPACE", h[h.PAGE_UP = 33] = "PAGE_UP", h[h.PAGE_DOWN = 34] = "PAGE_DOWN", h[h.END = 35] = "END", h[h.HOME = 36] = "HOME", h[h.LEFT = 37] = "LEFT", h[h.UP = 38] = "UP", h[h.RIGHT = 39] = "RIGHT", h[h.DOWN = 40] = "DOWN", h[h.PLUS_SIGN = 43] = "PLUS_SIGN", h[h.PRINT_SCREEN = 44] = "PRINT_SCREEN", h[h.INSERT = 45] = "INSERT", h[h.DELETE = 46] = "DELETE", h[h.ZERO = 48] = "ZERO", h[h.ONE = 49] = "ONE", h[h.TWO = 50] = "TWO", h[h.THREE = 51] = "THREE", h[h.FOUR = 52] = "FOUR", h[h.FIVE = 53] = "FIVE", h[h.SIX = 54] = "SIX", h[h.SEVEN = 55] = "SEVEN", h[h.EIGHT = 56] = "EIGHT", h[h.NINE = 57] = "NINE", h[h.FF_SEMICOLON = 59] = "FF_SEMICOLON", h[h.FF_EQUALS = 61] = "FF_EQUALS", h[h.FF_DASH = 173] = "FF_DASH", h[h.FF_HASH = 163] = "FF_HASH", h[h.QUESTION_MARK = 63] = "QUESTION_MARK", h[h.AT_SIGN = 64] = "AT_SIGN", h[h.A = 65] = "A", h[h.B = 66] = "B", h[h.C = 67] = "C", h[h.D = 68] = "D", h[h.E = 69] = "E", h[h.F = 70] = "F", h[h.G = 71] = "G", h[h.H = 72] = "H", h[h.I = 73] = "I", h[h.J = 74] = "J", h[h.K = 75] = "K", h[h.L = 76] = "L", h[h.M = 77] = "M", h[h.N = 78] = "N", h[h.O = 79] = "O", h[h.P = 80] = "P", h[h.Q = 81] = "Q", h[h.R = 82] = "R", h[h.S = 83] = "S", h[h.T = 84] = "T", h[h.U = 85] = "U", h[h.V = 86] = "V", h[h.W = 87] = "W", h[h.X = 88] = "X", h[h.Y = 89] = "Y", h[h.Z = 90] = "Z", h[h.META = 91] = "META", h[h.WIN_KEY_RIGHT = 92] = "WIN_KEY_RIGHT", h[h.CONTEXT_MENU = 93] = "CONTEXT_MENU", h[h.NUM_ZERO = 96] = "NUM_ZERO", h[h.NUM_ONE = 97] = "NUM_ONE", h[h.NUM_TWO = 98] = "NUM_TWO", h[h.NUM_THREE = 99] = "NUM_THREE", h[h.NUM_FOUR = 100] = "NUM_FOUR", h[h.NUM_FIVE = 101] = "NUM_FIVE", h[h.NUM_SIX = 102] = "NUM_SIX", h[h.NUM_SEVEN = 103] = "NUM_SEVEN", h[h.NUM_EIGHT = 104] = "NUM_EIGHT", h[h.NUM_NINE = 105] = "NUM_NINE", h[h.NUM_MULTIPLY = 106] = "NUM_MULTIPLY", h[h.NUM_PLUS = 107] = "NUM_PLUS", h[h.NUM_MINUS = 109] = "NUM_MINUS", h[h.NUM_PERIOD = 110] = "NUM_PERIOD", h[h.NUM_DIVISION = 111] = "NUM_DIVISION", h[h.F1 = 112] = "F1", h[h.F2 = 113] = "F2", h[h.F3 = 114] = "F3", h[h.F4 = 115] = "F4", h[h.F5 = 116] = "F5", h[h.F6 = 117] = "F6", h[h.F7 = 118] = "F7", h[h.F8 = 119] = "F8", h[h.F9 = 120] = "F9", h[h.F10 = 121] = "F10", h[h.F11 = 122] = "F11", h[h.F12 = 123] = "F12", h[h.NUMLOCK = 144] = "NUMLOCK", h[h.SCROLL_LOCK = 145] = "SCROLL_LOCK", h[h.FIRST_MEDIA_KEY = 166] = "FIRST_MEDIA_KEY", h[h.LAST_MEDIA_KEY = 183] = "LAST_MEDIA_KEY", h[h.SEMICOLON = 186] = "SEMICOLON", h[h.DASH = 189] = "DASH", h[h.EQUALS = 187] = "EQUALS", h[h.COMMA = 188] = "COMMA", h[h.PERIOD = 190] = "PERIOD", h[h.SLASH = 191] = "SLASH", h[h.APOSTROPHE = 192] = "APOSTROPHE", h[h.TILDE = 192] = "TILDE", h[h.SINGLE_QUOTE = 222] = "SINGLE_QUOTE", h[h.OPEN_SQUARE_BRACKET = 219] = "OPEN_SQUARE_BRACKET", h[h.BACKSLASH = 220] = "BACKSLASH", h[h.CLOSE_SQUARE_BRACKET = 221] = "CLOSE_SQUARE_BRACKET", h[h.WIN_KEY = 224] = "WIN_KEY", h[h.MAC_FF_META = 224] = "MAC_FF_META", h[h.MAC_WK_CMD_LEFT = 91] = "MAC_WK_CMD_LEFT", h[h.MAC_WK_CMD_RIGHT = 93] = "MAC_WK_CMD_RIGHT", h[h.WIN_IME = 229] = "WIN_IME", h[h.VK_NONAME = 252] = "VK_NONAME", h[h.PHANTOM = 255] = "PHANTOM", h[h.CTRL_CMD = Fo || pr || Ms ? h.MAC_WK_CMD_LEFT : h.CTRL] = "CTRL_CMD";
      var Ug = class {
        constructor(t) {
          this.workspace = t;
          var e, i, o;
          this.svgRoot = v(g.G, {}, (o = (e = t.getLayerManager()) == null ? void 0 : e.getDragLayer()) != null ? o : (i = t.getLayerManager()) == null ? void 0 : i.getBlockLayer()), this.svgRoot.classList.add("blocklyMoveIndicator"), t = t.RTL, v(g.CIRCLE, { fill: "white", "fill-opacity": "0.8", stroke: "grey", "stroke-width": "1", r: 20, cx: 20 * (t ? -1 : 1), cy: 20 }, this.svgRoot), v(g.PATH, {
            fill: "none",
            stroke: "black",
            "stroke-linecap": "round",
            "stroke-linejoin": "round",
            "stroke-width": "2",
            d: "m18 9l3 3l-3 3m-3-3h6M6 9l-3 3l3 3m-3-3h6m0 6l3 3l3-3m-3-3v6m3-15l-3-3l-3 3m3-3v6",
            transform: `translate(${(t ? -4 : 1) * 8} 8)`
          }, this.svgRoot);
        }
        moveTo(t, e) {
          this.svgRoot.setAttribute("transform", `translate(${t + (this.workspace.RTL ? 20 : -20)}, ${e - 20})`);
        }
        dispose() {
          Q(this.svgRoot);
        }
      }, lt, Ue = lt || (lt = {});
      Ue[Ue.NONE = 0] = "NONE", Ue[Ue.UP = 1] = "UP", Ue[Ue.DOWN = 2] = "DOWN", Ue[Ue.LEFT = 3] = "LEFT", Ue[Ue.RIGHT = 4] = "RIGHT";
      var J = class {
        constructor() {
          this.totalDelta = new m(0, 0), this.stepDistance = 20, this.allowedShortcuts = [], this.blurListener = () => {
            this.abortMove();
          }, this.moving = !1;
        }
        canMove(t) {
          return !t.workspace.isReadOnly() && t.isMovable();
        }
        isMoving() {
          return this.moving;
        }
        startMove(t, e) {
          if (!this.canMove(t) || this.isMoving()) return !1;
          this.moving = !0;
          var i = Pt(_.BLOCK_DRAGGER, t.workspace.options, !0);
          if (!i) throw Error("no Dragger registered");
          return this.dragger = new i(t, t.workspace), this.draggable = this.dragger.onDragStart(e), this.startLocation = this.draggable.getRelativeToSurfaceXY(), this.updateTotalDelta(), this.draggable.getFocusableElement().addEventListener("blur", this.blurListener), t = Object.values(S.registry.getRegistry()).flatMap((o) => o.keyCodes).filter((o) => o && ![C.RIGHT, C.LEFT, C.UP, C.DOWN, C.ENTER, C.SPACE, C.ESC, C.M].includes(typeof o == "number" ? o : parseInt(`${o.split("+").pop()}`))).filter((o) => !!o), S.registry.register(
            { name: "commitMove", preconditionFn: () => this.isMoving(), callback: () => (this.finishMove(), !1), keyCodes: t, allowCollision: !0 },
            !0
          ), this.scrollCurrentElementIntoView(), this.moveIndicator = new Ug(this.draggable.workspace), this.repositionMoveIndicator(), !0;
        }
        move(t, e) {
          switch (t) {
            case lt.UP:
              this.totalDelta.y -= this.stepDistance;
              break;
            case lt.DOWN:
              this.totalDelta.y += this.stepDistance;
              break;
            case lt.LEFT:
              this.totalDelta.x -= this.stepDistance;
              break;
            case lt.RIGHT:
              this.totalDelta.x += this.stepDistance;
          }
          var i;
          return (i = this.dragger) == null || i.onDrag(e, this.totalPixelDelta()), this.updateTotalDelta(), this.scrollCurrentElementIntoView(), this.repositionMoveIndicator(), !0;
        }
        finishMove(t) {
          this.preDragEndCleanup();
          var e;
          return (e = this.dragger) == null || e.onDragEnd(t, this.totalPixelDelta()), this.postDragEndCleanup(), !0;
        }
        abortMove(t) {
          this.preDragEndCleanup();
          var e;
          return (e = this.dragger) == null || e.onDragRevert(t, this.totalPixelDelta()), this.postDragEndCleanup(), !0;
        }
        setMoveDistance(t) {
          this.stepDistance = t;
        }
        getAllowedShortcuts() {
          return this.allowedShortcuts;
        }
        setAllowedShortcuts(t) {
          this.allowedShortcuts = t;
        }
        repositionMoveIndicator() {
          te().then(() => {
            var t, e = (t = this.draggable) == null ? void 0 : t.getBoundingRectangle();
            if (this.draggable && "getBoundingRectangleWithoutChildren" in this.draggable && (e = this.positionForBlockMoveIndicator(this.draggable)), e) {
              var i, o;
              (o = this.moveIndicator) == null || o.moveTo((i = this.draggable) != null && i.workspace.RTL ? e.left : e.right, e.top);
            }
          });
        }
        positionForBlockMoveIndicator(t) {
          for (var e = t.workspace.getNavigator(), i = t, o; o = e.getInNode(i); ) i = o;
          e = e.getSourceBlockFromNode(i), i = t.getBoundingRectangleWithoutChildren().getOrigin().y;
          for (var s; ((s = e) == null ? void 0 : s.getBoundingRectangleWithoutChildren().getOrigin().y) !== i; ) {
            let a, c;
            e = (c = (a = e) == null ? void 0 : a.getParent()) != null ? c : null;
          }
          var n, l;
          return (l = (n = e) == null ? void 0 : n.getBoundingRectangleWithoutChildren()) != null ? l : t.getBoundingRectangleWithoutChildren();
        }
        preDragEndCleanup() {
          S.registry.unregister("commitMove");
          var t;
          (t = this.draggable) == null || t.getFocusableElement().removeEventListener("blur", this.blurListener);
        }
        postDragEndCleanup() {
          var t;
          (t = this.moveIndicator) == null || t.dispose(), this.startLocation = this.dragger = this.draggable = this.moveIndicator = void 0, this.totalDelta = new m(0, 0), this.moving = !1;
        }
        totalPixelDelta() {
          var t, e, i = (e = (t = this.draggable) == null ? void 0 : t.workspace.scale) != null ? e : 1;
          return new m(this.totalDelta.x * i, this.totalDelta.y * i);
        }
        scrollCurrentElementIntoView() {
          if (this.draggable) {
            var t = this.draggable.getBoundingRectangle();
            this.draggable.workspace.scrollBoundsIntoView(t);
          }
        }
        updateTotalDelta() {
          this.draggable && this.startLocation && (this.totalDelta = new m(
            this.draggable.getRelativeToSurfaceXY().x - this.startLocation.x,
            this.draggable.getRelativeToSurfaceXY().y - this.startLocation.y
          ));
        }
      };
      J.mover = new J();
      var lo = class {
        constructor(t, e, i, o) {
          this.name = t, this.startHats = !1, this.blockStyles = e || /* @__PURE__ */ Object.create(null), this.categoryStyles = i || /* @__PURE__ */ Object.create(null), this.componentStyles = o || /* @__PURE__ */ Object.create(null), this.fontStyle = /* @__PURE__ */ Object.create(null), P(_.THEME, t, this, !0);
        }
        getClassName() {
          return this.name + "-theme";
        }
        setBlockStyle(t, e) {
          this.blockStyles[t] = e;
        }
        setCategoryStyle(t, e) {
          this.categoryStyles[t] = e;
        }
        getComponentStyle(t) {
          if (t = this.componentStyles[t], !t) return null;
          if (typeof t == "string") {
            let e = this.getComponentStyle(t);
            if (e) return e;
          }
          return `${t}`;
        }
        setComponentStyle(t, e) {
          this.componentStyles[t] = e;
        }
        setFontStyle(t) {
          this.fontStyle = t;
        }
        setStartHats(t) {
          this.startHats = t;
        }
        static defineTheme(t, e) {
          t = t.toLowerCase();
          var i = new lo(t), o = e.base;
          if (o) {
            if (typeof o == "string") {
              let s;
              o = (s = Mt(_.THEME, o, void 0)) != null ? s : void 0;
            }
            o instanceof lo && (Re(i, o), i.name = t);
          }
          return Re(i.blockStyles, e.blockStyles), Re(i.categoryStyles, e.categoryStyles), Re(i.componentStyles, e.componentStyles), Re(i.fontStyle, e.fontStyle), e.startHats !== null && (i.startHats = e.startHats), i;
        }
      }, Wr = new lo("classic", { colour_blocks: { colourPrimary: "20" }, list_blocks: { colourPrimary: "260" }, logic_blocks: { colourPrimary: "210" }, loop_blocks: { colourPrimary: "120" }, math_blocks: { colourPrimary: "230" }, procedure_blocks: { colourPrimary: "290" }, text_blocks: { colourPrimary: "160" }, variable_blocks: { colourPrimary: "330" }, variable_dynamic_blocks: { colourPrimary: "310" }, hat_blocks: { colourPrimary: "330", hat: "cap" } }, {
        colour_category: { colour: "20" },
        list_category: { colour: "260" },
        logic_category: { colour: "210" },
        loop_category: { colour: "120" },
        math_category: { colour: "230" },
        procedure_category: { colour: "290" },
        text_category: { colour: "160" },
        variable_category: { colour: "330" },
        variable_dynamic_category: { colour: "310" }
      }), We = class {
        constructor(t) {
          this.gridPattern = null, this.getMetrics = this.setMetrics = void 0;
          var e = null, i = !1, o = !1, s = !1, n = !1, l = !1, a = !1, c = !!t.readOnly;
          if (!c) {
            var E;
            e = Cn((E = t.toolbox) != null ? E : null), i = yn(e), o = t.trashcan, o = o === void 0 ? i : o, s = t.collapse, s = s === void 0 ? i : s, n = t.comments, n = n === void 0 ? i : n, l = t.disable, l = l === void 0 ? i : l, a = t.sounds, a = a === void 0 ? !0 : a;
          }
          E = t.maxTrashcanContents, o ? E === void 0 && (E = 32) : E = 0;
          var O = !!t.rtl, L = t.horizontalLayout;
          L === void 0 && (L = !1);
          var x = t.toolboxPosition !== "end";
          x = L ? x ? I.TOP : I.BOTTOM : x === O ? I.RIGHT : I.LEFT;
          var z = t.css;
          z === void 0 && (z = !0);
          var yt = "https://static.blockly.com/media/";
          t.media && (yt = t.media.endsWith("/") ? t.media : t.media + "/");
          var Lt = t.oneBasedIndex;
          Lt = Lt === void 0 ? !0 : Lt;
          var Ru = t.renderer || "thrasos", Uf = t.plugins || {}, Au = t.modalInputs;
          Au === void 0 && (Au = !0), this.RTL = O, this.oneBasedIndex = Lt, this.collapse = s, this.comments = n, this.disable = l, this.readOnly = c, this.maxBlocks = t.maxBlocks || 1 / 0;
          var nf;
          this.maxInstances = (nf = t.maxInstances) != null ? nf : null, this.modalInputs = Au, this.pathToMedia = yt, this.hasCategories = i, this.moveOptions = We.parseMoveOptions(t, i), this.hasScrollbars = !!this.moveOptions.scrollbars, this.hasTrashcan = o, this.maxTrashcanContents = E, this.hasSounds = a, this.hasCss = z, this.horizontalLayout = L, this.languageTree = e, this.gridOptions = We.parseGridOptions(t), this.zoomOptions = We.parseZoomOptions(t), this.toolboxPosition = x, this.theme = We.parseThemeOptions(t), this.renderer = Ru;
          var rf;
          this.rendererOverrides = (rf = t.rendererOverrides) != null ? rf : null;
          var lf;
          this.parentWorkspace = (lf = t.parentWorkspace) != null ? lf : null, this.plugins = Uf;
        }
        static parseMoveOptions(t, e) {
          var i = t.move || {}, o = {};
          return i.scrollbars === void 0 && t.scrollbars === void 0 ? o.scrollbars = e : typeof i.scrollbars == "object" ? (o.scrollbars = { horizontal: !!i.scrollbars.horizontal, vertical: !!i.scrollbars.vertical }, o.scrollbars.horizontal && o.scrollbars.vertical ? o.scrollbars = !0 : o.scrollbars.horizontal || o.scrollbars.vertical || (o.scrollbars = !1)) : o.scrollbars = !!i.scrollbars || !!t.scrollbars, o.wheel = o.scrollbars && i.wheel !== void 0 ? !!i.wheel : typeof o.scrollbars == "object", o.drag = o.scrollbars ? i.drag === void 0 ? !0 : !!i.drag : !1, o;
        }
        static parseZoomOptions(t) {
          t = t.zoom || {};
          var e = {};
          return e.controls = t.controls === void 0 ? !1 : !!t.controls, e.wheel = t.wheel === void 0 ? !1 : !!t.wheel, e.startScale = t.startScale === void 0 ? 1 : Number(t.startScale), e.maxScale = t.maxScale === void 0 ? 3 : Number(t.maxScale), e.minScale = t.minScale === void 0 ? 0.3 : Number(t.minScale), e.scaleSpeed = t.scaleSpeed === void 0 ? 1.2 : Number(t.scaleSpeed), e.pinch = t.pinch === void 0 ? e.wheel || e.controls : !!t.pinch, e;
        }
        static parseGridOptions(t) {
          t = t.grid || {};
          var e = {};
          return e.spacing = Number(t.spacing) || 0, e.colour = t.colour || "#888", e.length = t.length === void 0 ? 1 : Number(t.length), e.snap = e.spacing > 0 && !!t.snap, e;
        }
        static parseThemeOptions(t) {
          return t = t.theme || Wr, typeof t == "string" ? Mt(_.THEME, t, void 0) : t instanceof lo ? t : lo.defineTheme(t.name || "builtin" + It(), t);
        }
      }, Wg = class {
        constructor(t, e) {
          this.bubble = t, this.workspace = e, this.startLoc = null;
        }
        isMovable() {
          return !0;
        }
        startDrag() {
          this.startLoc = this.bubble.getRelativeToSurfaceXY(), this.workspace.setResizesEnabled(!1);
          var t;
          return (t = this.workspace.getLayerManager()) == null || t.moveToDragLayer(this.bubble), this.bubble.setDragging && this.bubble.setDragging(!0), this.bubble;
        }
        drag(t) {
          this.bubble.moveDuringDrag(t);
        }
        endDrag() {
          this.workspace.setResizesEnabled(!0);
          var t;
          (t = this.workspace.getLayerManager()) == null || t.moveOffDragLayer(
            this.bubble,
            100
          ), this.bubble.setDragging(!1);
        }
        revertDrag() {
          this.startLoc && this.bubble.moveDuringDrag(this.startLoc);
        }
      }, ne, j = class {
        constructor(t, e, i, o, s) {
          this.workspace = t, this.anchor = e, this.ownerRect = i, this.owner = s, this.size = new H(0, 0), this.colour = "#ffffff", this.disposed = !1, this.relativeLeft = this.relativeTop = 0, this.dragStrategy = new Wg(this, this.workspace), this.ariaLabelProvider = null, this.id = It(), this.svgRoot = v(g.G, { class: "blocklyBubble" }, t.getBubbleCanvas()), t = v(g.G, { class: "blocklyEmboss" }, this.svgRoot), this.tail = v(g.PATH, { class: "blocklyBubbleTail" }, t), this.background = v(g.RECT, {
            class: "blocklyDraggable",
            x: 0,
            y: 0,
            rx: ne.BORDER_WIDTH,
            ry: ne.BORDER_WIDTH
          }, t), this.contentContainer = v(g.G, {}, this.svgRoot), this.focusableElement = o ?? this.svgRoot, this.focusableElement.setAttribute("id", this.id), M(this.background, "pointerdown", this, this.onMouseDown), M(this.focusableElement, "keydown", this, this.onKeyDown), this.recomputeAriaContext();
        }
        dispose() {
          Q(this.svgRoot), this.disposed = !0;
        }
        setAnchorLocation(t, e = !1) {
          this.anchor = t, e ? this.positionByRect(this.ownerRect) : this.positionRelativeToAnchor(), this.renderTail();
        }
        setPositionRelativeToAnchor(t, e) {
          this.relativeLeft = t, this.relativeTop = e, this.positionRelativeToAnchor(), this.renderTail();
        }
        getSize() {
          return this.size;
        }
        setSize(t, e = !1) {
          t.width = Math.max(t.width, ne.MIN_SIZE), t.height = Math.max(t.height, ne.MIN_SIZE), this.size = t, this.background.setAttribute("width", `${t.width}`), this.background.setAttribute("height", `${t.height}`), e ? this.positionByRect(this.ownerRect) : this.positionRelativeToAnchor(), this.renderTail();
        }
        getColour() {
          return this.colour;
        }
        setColour(t) {
          this.colour = t, this.tail.setAttribute(
            "fill",
            t
          ), this.background.setAttribute("fill", t);
        }
        onMouseDown(t) {
          var e;
          (e = this.workspace.getGesture(t)) == null || e.handleBubbleStart(t, this), r.t().focusNode(this);
        }
        onKeyDown(t) {
          t.key === "Escape" && this.owner && (this.owner.setBubbleVisible(!1), r.t().focusNode(this.owner));
        }
        positionRelativeToAnchor() {
          var t = this.anchor.x;
          t = this.workspace.RTL ? t - (this.relativeLeft + this.size.width) : t + this.relativeLeft, this.moveTo(t, this.relativeTop + this.anchor.y);
        }
        moveTo(t, e) {
          this.svgRoot.setAttribute("transform", `translate(${t}, ${e})`);
        }
        moveBy(t, e) {
          var i = this.getRelativeToSurfaceXY();
          this.moveTo(i.x + t, i.y + e);
        }
        positionByRect(t = new F(0, 0, 0, 0)) {
          var e = this.workspace.getMetricsManager().getViewMetrics(!0), i = this.getOptimalRelativeLeft(e), o = this.getOptimalRelativeTop(e), s = { x: i, y: -this.size.height - this.workspace.getRenderer().getConstants().MIN_BLOCK_HEIGHT }, n = { x: -this.size.width - 30, y: o };
          o = { x: t.getWidth(), y: o };
          var l = { x: i, y: t.getHeight() };
          i = t.getWidth() < t.getHeight() ? o : l, t = t.getWidth() < t.getHeight() ? l : o, o = this.getOverlap(s, e), l = this.getOverlap(
            n,
            e
          );
          var a = this.getOverlap(i, e);
          e = this.getOverlap(t, e), e = Math.max(o, l, a, e), o === e ? (this.relativeLeft = s.x, this.relativeTop = s.y) : l === e ? (this.relativeLeft = n.x, this.relativeTop = n.y) : a === e ? (this.relativeLeft = i.x, this.relativeTop = i.y) : (this.relativeLeft = t.x, this.relativeTop = t.y), this.positionRelativeToAnchor();
        }
        getOverlap(t, e) {
          var i = this.workspace.RTL ? this.anchor.x - t.x - this.size.width : t.x + this.anchor.x;
          return t = t.y + this.anchor.y, Math.max(0, Math.min(1, (Math.min(i + this.size.width, e.left + e.width) - Math.max(i, e.left)) * (Math.min(t + this.size.height, e.top + e.height) - Math.max(t, e.top)) / (this.size.width * this.size.height)));
        }
        getOptimalRelativeLeft(t) {
          var e = -this.size.width / 4;
          if (this.size.width > t.width) return e;
          if (t = this.getWorkspaceViewRect(t), this.workspace.RTL) {
            var i = this.anchor.x - e;
            i - this.size.width < t.left ? e = -(t.left - this.anchor.x + this.size.width) : i > t.right && (e = -(t.right - this.anchor.x));
          } else {
            i = e + this.anchor.x;
            let o = i + this.size.width;
            i < t.left ? e = t.left - this.anchor.x : o > t.right && (e = t.right - this.anchor.x - this.size.width);
          }
          return e;
        }
        getOptimalRelativeTop(t) {
          var e = -this.size.height / 4;
          if (this.size.height > t.height) return e;
          var i = this.anchor.y + e, o = i + this.size.height;
          return t = this.getWorkspaceViewRect(t), i < t.top ? e = t.top - this.anchor.y : o > t.bottom && (e = t.bottom - this.anchor.y - this.size.height), e;
        }
        getWorkspaceViewRect(t) {
          var e = t.top, i = t.top + t.height, o = t.left;
          return t = t.left + t.width, i -= this.getScrollbarThickness(), this.workspace.RTL ? o -= this.getScrollbarThickness() : t -= this.getScrollbarThickness(), new F(e, i, o, t);
        }
        getScrollbarThickness() {
          return pt.scrollbarThickness / this.workspace.scale;
        }
        renderTail() {
          var t = [], e = this.size.width / 2, i = this.size.height / 2, o = -this.relativeLeft, s = -this.relativeTop;
          if (e === o && i === s) t.push("M " + e + "," + i);
          else {
            s -= i, o -= e, this.workspace.RTL && (o *= -1);
            var n = Math.sqrt(s * s + o * o), l = Math.acos(o / n);
            s < 0 && (l = 2 * Math.PI - l);
            var a = l + Math.PI / 2;
            a > Math.PI * 2 && (a -= Math.PI * 2);
            var c = Math.sin(a);
            let O = Math.cos(a), L = (this.size.width + this.size.height) / ne.TAIL_THICKNESS;
            L = Math.min(L, this.size.width, this.size.height) / 4, a = 1 - ne.ANCHOR_RADIUS / n, o = e + a * o, s = i + a * s, a = e + L * O;
            let x = i + L * c;
            e -= L * O, i -= L * c, c = Gn(this.workspace.RTL ? -ne.TAIL_ANGLE : ne.TAIL_ANGLE), c = l + c, c > Math.PI * 2 && (c -= Math.PI * 2), l = Math.sin(c) * n / ne.TAIL_BEND, n = Math.cos(c) * n / ne.TAIL_BEND, t.push("M" + a + "," + x), t.push("C" + (a + n) + "," + (x + l) + " " + o + "," + s + " " + o + "," + s), t.push("C" + o + "," + s + " " + (e + n) + "," + (i + l) + " " + e + "," + i);
          }
          t.push("z");
          var E;
          (E = this.tail) == null || E.setAttribute("d", t.join(" "));
        }
        bringToFront() {
          var t, e = (t = this.svgRoot) == null ? void 0 : t.parentNode;
          return this.svgRoot && e?.lastChild !== this.svgRoot ? (e?.appendChild(this.svgRoot), !0) : !1;
        }
        getRelativeToSurfaceXY() {
          return new m(this.workspace.RTL ? -this.relativeLeft + this.anchor.x - this.size.width : this.anchor.x + this.relativeLeft, this.anchor.y + this.relativeTop);
        }
        getBoundingRectangle() {
          var t = this.getRelativeToSurfaceXY();
          return new F(t.y, t.y + this.size.height, t.x, t.x + this.size.width);
        }
        getSvgRoot() {
          return this.svgRoot;
        }
        moveDuringDrag(t) {
          this.moveTo(t.x, t.y), this.relativeLeft = this.workspace.RTL ? this.anchor.x - t.x - this.size.width : t.x - this.anchor.x, this.relativeTop = t.y - this.anchor.y, this.renderTail();
        }
        setDragging() {
        }
        setDeleteStyle() {
        }
        isDeletable() {
          return !1;
        }
        showContextMenu() {
        }
        isMovable() {
          return !0;
        }
        startDrag() {
          return this.dragStrategy.startDrag();
        }
        drag(t) {
          this.dragStrategy.drag(t);
        }
        endDrag() {
          this.dragStrategy.endDrag();
        }
        revertDrag() {
          this.dragStrategy.revertDrag();
        }
        select() {
          ci(this);
        }
        unselect() {
          ci(null);
        }
        getFocusableElement() {
          return this.focusableElement;
        }
        getFocusableTree() {
          return this.workspace;
        }
        onNodeFocus() {
          this.select(), this.bringToFront();
          var t = this.getRelativeToSurfaceXY(), e = this.getSize();
          t = new F(t.y, t.y + e.height, t.x, t.x + e.width), this.workspace.scrollBoundsIntoView(t);
        }
        onNodeBlur() {
          this.unselect();
        }
        canBeFocused() {
          return !0;
        }
        getOwner() {
          return this.owner;
        }
        recomputeAriaContext() {
          var t = this.getFocusableElement();
          if (t) {
            G(t, W.GROUP);
            var e, i = (e = this.getAriaLabel()) == null ? void 0 : e.trim();
            w(t, y.LABEL, i || r.C.BUBBLE_LABEL_DEFAULT);
          }
        }
        setAriaLabelProvider(t) {
          this.ariaLabelProvider = t, this.recomputeAriaContext();
        }
        getAriaLabel() {
          if (this.ariaLabelProvider) {
            if (typeof this.ariaLabelProvider == "string") return this.ariaLabelProvider;
            if (typeof this.ariaLabelProvider == "function") return this.ariaLabelProvider(this);
          }
          return null;
        }
      };
      ne = j, j.BORDER_WIDTH = 6, j.DOUBLE_BORDER = ne.BORDER_WIDTH * 2, j.MIN_SIZE = ne.DOUBLE_BORDER, j.TAIL_THICKNESS = 1, j.TAIL_ANGLE = 20, j.TAIL_BEND = 4, j.ANCHOR_RADIUS = 8;
      var si = class extends j {
        constructor(t, e, i, o, s) {
          super(e, i, o, void 0, s), this.workspace = e, this.anchor = i, this.ownerRect = o, this.owner = s, this.autoLayout = !0, e = new We(t), this.validateWorkspaceOptions(e), this.svgDialog = v(g.SVG, { x: j.BORDER_WIDTH, y: j.BORDER_WIDTH }, this.contentContainer), t.parentWorkspace = this.workspace, this.miniWorkspace = this.newWorkspaceSvg(new We(t)), this.miniWorkspace.internalIsMutator = !0, t = this.miniWorkspace.createDom("blocklyMutatorBackground"), this.svgDialog.appendChild(t), e.languageTree && (t.insertBefore(this.miniWorkspace.addFlyout(g.G), this.miniWorkspace.getCanvas()), t = this.miniWorkspace.getFlyout(), t?.init(this.miniWorkspace), t?.show(e.languageTree)), b(this.svgRoot, "blocklyMiniWorkspaceBubble"), this.miniWorkspace.addChangeListener(this.onWorkspaceChange.bind(this));
          var n, l;
          (n = this.miniWorkspace.getFlyout()) == null || (l = n.getWorkspace()) == null || l.addChangeListener(this.onWorkspaceChange.bind(this)), this.updateBubbleSize();
        }
        dispose() {
          this.miniWorkspace.dispose(), super.dispose();
        }
        getWorkspace() {
          return this.miniWorkspace;
        }
        addWorkspaceChangeListener(t) {
          this.miniWorkspace.addChangeListener(t);
        }
        validateWorkspaceOptions(t) {
          if (t.hasCategories) throw Error("The miniworkspace bubble does not support toolboxes with categories");
          if (t.hasTrashcan) throw Error("The miniworkspace bubble does not support trashcans");
          if (t.zoomOptions.controls || t.zoomOptions.wheel || t.zoomOptions.pinch) throw Error("The miniworkspace bubble does not support zooming");
          if (t.moveOptions.scrollbars || t.moveOptions.wheel || t.moveOptions.drag) throw Error("The miniworkspace bubble does not allow scrolling/moving the workspace");
          if (t.horizontalLayout) throw Error("The miniworkspace bubble does not support horizontal layouts");
        }
        onWorkspaceChange() {
          this.bumpBlocksIntoBounds(), this.updateBubbleSize();
        }
        bumpBlocksIntoBounds() {
          if (!this.miniWorkspace.isDragging() || J.mover.isMoving()) for (let t of this.miniWorkspace.getTopBlocks(!1)) {
            let e = t.getRelativeToSurfaceXY();
            if (e.y < 20 && t.moveBy(0, 20 - e.y), t.RTL) {
              let i = -20, o = this.miniWorkspace.getFlyout();
              o && (i -= o.getWidth()), e.x > i && t.moveBy(i - e.x, 0);
            } else e.x < 20 && t.moveBy(20 - e.x, 0);
          }
        }
        updateBubbleSize() {
          if (!this.miniWorkspace.isDragging() || J.mover.isMoving()) {
            this.autoLayout && (this.autoLayout = !J.mover.isMoving());
            var t = this.getSize(), e = this.calculateWorkspaceSize();
            Math.abs(t.width - e.width) < si.MINIMUM_VIEW_CHANGE && Math.abs(t.height - e.height) < si.MINIMUM_VIEW_CHANGE || (this.svgDialog.setAttribute("width", `${e.width}px`), this.svgDialog.setAttribute("height", `${e.height}px`), this.miniWorkspace.setCachedParentSvgSize(e.width, e.height), this.miniWorkspace.RTL && this.miniWorkspace.getCanvas().setAttribute("transform", `translate(${e.width}, 0)`), this.setSize(new H(e.width + j.DOUBLE_BORDER, e.height + j.DOUBLE_BORDER), this.autoLayout), this.miniWorkspace.resize(), this.miniWorkspace.recordDragTargets());
          }
        }
        calculateWorkspaceSize() {
          var t = this.miniWorkspace.getCanvas().getBBox(), e = t.width + si.MARGIN;
          t = t.height + si.MARGIN;
          var i = this.miniWorkspace.getFlyout();
          if (i) {
            let o = i.getWorkspace().getMetricsManager().getScrollMetrics();
            t = Math.max(t, o.height + 20), e += i.getWidth();
          }
          return new H(e, t);
        }
        updateBlockStyles() {
          for (var t of this.miniWorkspace.getAllBlocks(!1)) t.setStyle(t.getStyleName());
          var e;
          if (t = (e = this.miniWorkspace.getFlyout()) == null ? void 0 : e.getWorkspace()) for (let i of t.getAllBlocks(!1)) i.setStyle(i.getStyleName());
        }
        moveDuringDrag(t) {
          super.moveDuringDrag(t), this.autoLayout = !1;
        }
        moveTo(t, e) {
          super.moveTo(t, e), this.miniWorkspace.recordDragTargets();
        }
        newWorkspaceSvg() {
          throw Error("The implementation of newWorkspaceSvg should be monkey-patched in by blockly.ts");
        }
        performAction() {
          r.t().focusTree(this.getWorkspace());
        }
      };
      si.MINIMUM_VIEW_CHANGE = 10, si.MARGIN = j.DOUBLE_BORDER * 3;
      var qo = class {
        constructor(t) {
          this.sourceBlock = t, this.offsetInBlock = new m(0, 0), this.workspaceLocation = new m(0, 0), this.svgRoot = null, this.tooltip = t, this.id = It();
        }
        getType() {
          throw Error("Icons must implement getType");
        }
        initView(t) {
          if (!this.svgRoot) {
            var e = this.sourceBlock;
            this.svgRoot = v(g.G, { class: "blocklyIconGroup", id: this.id }), e.getSvgRoot().appendChild(this.svgRoot), this.updateSvgRootOffset(), M(this.svgRoot, "pointerdown", this, t), this.svgRoot.tooltip = this, Is(this.svgRoot), this.recomputeAriaContext();
          }
        }
        dispose() {
          this.svgRoot && (Ss(this.svgRoot), delete this.svgRoot.tooltip, Q(this.svgRoot)), this.tooltip = "";
        }
        getWeight() {
          return -1;
        }
        getSize() {
          return new H(0, 0);
        }
        setTooltip(t) {
          this.tooltip = t ?? this.sourceBlock;
        }
        getTooltip() {
          return this.tooltip;
        }
        applyColour() {
        }
        updateEditable() {
        }
        updateCollapsed() {
          this.svgRoot && (this.sourceBlock.isCollapsed() ? this.svgRoot.style.display = "none" : this.svgRoot.style.display = "block", De(this) && this.setBubbleVisible(!1));
        }
        hideForInsertionMarker() {
          this.svgRoot && (this.svgRoot.style.display = "none");
        }
        isShownWhenCollapsed() {
          return !1;
        }
        setOffsetInBlock(t) {
          this.offsetInBlock = t, this.updateSvgRootOffset();
        }
        updateSvgRootOffset() {
          var t;
          (t = this.svgRoot) == null || t.setAttribute("transform", `translate(${this.offsetInBlock.x}, ${this.offsetInBlock.y})`);
        }
        onLocationChange(t) {
          this.workspaceLocation = m.sum(t, this.offsetInBlock);
        }
        onClick() {
        }
        isClickableInFlyout() {
          return !0;
        }
        getFocusableElement() {
          var t = this.svgRoot;
          if (!t) throw Error("Attempting to focus uninitialized icon.");
          return t;
        }
        getFocusableTree() {
          return this.sourceBlock.workspace;
        }
        onNodeFocus() {
          var t = this.sourceBlock.getBoundingRectangle();
          t = new F(t.top + this.offsetInBlock.y, t.top + this.offsetInBlock.y + this.getSize().height, t.left + this.offsetInBlock.x, t.left + this.offsetInBlock.x + this.getSize().width), this.sourceBlock.workspace.scrollBoundsIntoView(t);
        }
        onNodeBlur() {
        }
        canBeFocused() {
          return !0;
        }
        performAction() {
          this.onClick(), te().then(() => {
            if (De(this) && this.bubbleIsVisible()) {
              let t = this.getBubble();
              t && r.t().focusNode(t);
            }
          });
        }
        getSourceBlock() {
          return this.sourceBlock;
        }
        showContextMenu(t) {
          this.getSourceBlock().showContextMenu(t);
        }
        recomputeAriaContext() {
          var t = this.getFocusableElement();
          if (t) {
            var e, i = (e = this.sourceBlock.workspace.targetWorkspace) == null ? void 0 : e.getFlyout();
            if (i && !this.isClickableInFlyout(i.autoClose)) w(t, y.HIDDEN, !0);
            else {
              Co(t, y.HIDDEN), G(t, W.BUTTON);
              var o;
              e = (o = this.getAriaLabel()) != null ? o : r.C.ICON_LABEL_DEFAULT, w(t, y.LABEL, e);
            }
          }
        }
        getAriaLabel() {
          return null;
        }
      };
      r.sh = class extends qo {
        constructor(t, e) {
          super(e), this.flyoutBlockTypes = t, this.sourceBlock = e, this.saveConnectionsListener = this.updateWorkspacePid = this.rootBlock = this.miniWorkspaceBubble = null;
        }
        getType() {
          return r.sh.TYPE;
        }
        initView(t) {
          this.svgRoot || (super.initView(t), v(g.RECT, { class: "blocklyIconShape", rx: "4", ry: "4", height: "16", width: "16" }, this.svgRoot), v(
            g.PATH,
            { class: "blocklyIconSymbol", d: "m4.203,7.296 0,1.368 -0.92,0.677 -0.11,0.41 0.9,1.559 0.41,0.11 1.043,-0.457 1.187,0.683 0.127,1.134 0.3,0.3 1.8,0 0.3,-0.299 0.127,-1.138 1.185,-0.682 1.046,0.458 0.409,-0.11 0.9,-1.559 -0.11,-0.41 -0.92,-0.677 0,-1.366 0.92,-0.677 0.11,-0.41 -0.9,-1.559 -0.409,-0.109 -1.046,0.458 -1.185,-0.682 -0.127,-1.138 -0.3,-0.299 -1.8,0 -0.3,0.3 -0.126,1.135 -1.187,0.682 -1.043,-0.457 -0.41,0.11 -0.899,1.559 0.108,0.409z" },
            this.svgRoot
          ), v(g.CIRCLE, { class: "blocklyIconShape", r: "2.7", cx: "8", cy: "8" }, this.svgRoot), b(this.svgRoot, "blocklyMutatorIcon"));
        }
        dispose() {
          super.dispose();
          var t;
          (t = this.miniWorkspaceBubble) == null || t.dispose();
        }
        getWeight() {
          return r.sh.WEIGHT;
        }
        getSize() {
          return new H(17, 17);
        }
        applyColour() {
          super.applyColour();
          var t;
          (t = this.miniWorkspaceBubble) == null || t.setColour(this.sourceBlock.getColour());
          var e;
          (e = this.miniWorkspaceBubble) == null || e.updateBlockStyles();
        }
        updateCollapsed() {
          super.updateCollapsed(), this.sourceBlock.isCollapsed() && this.setBubbleVisible(!1);
        }
        onLocationChange(t) {
          super.onLocationChange(t);
          var e;
          (e = this.miniWorkspaceBubble) == null || e.setAnchorLocation(this.getAnchorLocation());
        }
        onClick() {
          super.onClick(), this.sourceBlock.isEditable() && this.setBubbleVisible(!this.bubbleIsVisible());
        }
        isClickableInFlyout() {
          return !1;
        }
        bubbleIsVisible() {
          return !!this.miniWorkspaceBubble;
        }
        setBubbleVisible(t) {
          var e = this;
          return (0, d.asyncExecutePromiseGeneratorFunction)(function* () {
            if (e.bubbleIsVisible() !== t) {
              if (yield te(), t) {
                e.miniWorkspaceBubble = new si(e.getMiniWorkspaceConfig(), e.sourceBlock.workspace, e.getAnchorLocation(), e.getBubbleOwnerRect(), e), e.applyColour(), e.createRootBlock(), e.addSaveConnectionsListener();
                let i;
                (i = e.miniWorkspaceBubble) == null || i.addWorkspaceChangeListener(e.createMiniWorkspaceChangeListener()), e.miniWorkspaceBubble.setAriaLabelProvider(r.C.WORKSPACE_LABEL_MUTATOR_WORKSPACE);
              } else {
                let i;
                (i = e.miniWorkspaceBubble) == null || i.dispose(), e.miniWorkspaceBubble = null, e.saveConnectionsListener && e.sourceBlock.workspace.removeChangeListener(e.saveConnectionsListener), e.saveConnectionsListener = null;
              }
              N(new (D(p.BUBBLE_OPEN))(e.sourceBlock, t, "mutator")), e.recomputeAriaContext();
            }
          });
        }
        getBubble() {
          return this.miniWorkspaceBubble;
        }
        getMiniWorkspaceConfig() {
          var t, e = { disable: !1, media: this.sourceBlock.workspace.options.pathToMedia, rtl: this.sourceBlock.RTL, renderer: this.sourceBlock.workspace.options.renderer, rendererOverrides: (t = this.sourceBlock.workspace.options.rendererOverrides) != null ? t : void 0 };
          return this.flyoutBlockTypes.length && (e.toolbox = { kind: "flyoutToolbox", contents: this.flyoutBlockTypes.map((i) => ({ kind: "block", type: i })) }), e;
        }
        getAnchorLocation() {
          return m.sum(this.workspaceLocation, new m(8.5, 8.5));
        }
        getBubbleOwnerRect() {
          var t = this.sourceBlock.getSvgRoot().getBBox();
          return new F(t.y, t.y + t.height, t.x, t.x + t.width);
        }
        createRootBlock() {
          if (!this.sourceBlock.decompose) throw Error("Blocks with mutator icons must include a decompose method");
          this.rootBlock = this.sourceBlock.decompose(this.miniWorkspaceBubble.getWorkspace());
          for (var t of this.rootBlock.getDescendants(!1)) t.queueRender();
          this.rootBlock.setMovable(!1), this.rootBlock.setDeletable(!1);
          var e, i, o, s;
          t = (s = (e = this.miniWorkspaceBubble) == null || (i = e.getWorkspace()) == null || (o = i.getFlyout()) == null ? void 0 : o.getWidth()) != null ? s : 0, this.rootBlock.moveBy(this.rootBlock.RTL ? -(t + 16) : 16, 16);
        }
        addSaveConnectionsListener() {
          this.sourceBlock.saveConnections && this.rootBlock && (this.saveConnectionsListener = () => {
            this.sourceBlock.saveConnections && this.rootBlock && this.sourceBlock.saveConnections(this.rootBlock);
          }, this.saveConnectionsListener(), this.sourceBlock.workspace.addChangeListener(this.saveConnectionsListener));
        }
        createMiniWorkspaceChangeListener() {
          return (t) => {
            r.sh.isIgnorableMutatorEvent(t) || this.updateWorkspacePid || (this.updateWorkspacePid = setTimeout(() => {
              this.updateWorkspacePid = null, this.recomposeSourceBlock();
            }, 0));
          };
        }
        static isIgnorableMutatorEvent(t) {
          return t.isUiEvent || t.type === p.BLOCK_CREATE || t.type === p.BLOCK_CHANGE && t.element === "disabled";
        }
        recomposeSourceBlock() {
          if (this.rootBlock) {
            if (!this.sourceBlock.compose) throw Error("Blocks with mutator icons must include a compose method");
            var t = r.gd;
            t || r.B(!0);
            var e = Zi.getExtraBlockState_(this.sourceBlock);
            this.sourceBlock.compose(this.rootBlock);
            var i = Zi.getExtraBlockState_(this.sourceBlock);
            e !== i && N(new (D(p.BLOCK_CHANGE))(this.sourceBlock, "mutation", null, e, i)), r.B(t);
          }
        }
        getWorkspace() {
          var t;
          return (t = this.miniWorkspaceBubble) == null ? void 0 : t.getWorkspace();
        }
        getAriaLabel() {
          return this.bubbleIsVisible() ? r.C.ICON_LABEL_MUTATOR_OPEN : r.C.ICON_LABEL_MUTATOR_CLOSED;
        }
      }, r.sh.TYPE = Ct.MUTATOR, r.sh.WEIGHT = 1;
      var Zo = /* @__PURE__ */ Object.create(null), yf = { allExtensions: Zo };
      r.oh("parent_tooltip_when_inline", function() {
        var t = this.tooltip;
        this.setTooltip(function() {
          var e = this.getParent();
          return e && e.getInputsInline() && e.tooltip || t;
        }.bind(this));
      });
      var ke = { TEST_ONLY: yf };
      ke.apply = tr, ke.buildTooltipForDropdown = r.yh, ke.buildTooltipWithFieldText = r.Ah, ke.isRegistered = Ma, ke.register = r.oh, ke.registerMixin = r.ph, ke.registerMutator = r.th, ke.runAfterPageLoad = function(t) {
        if (typeof document != "object") throw Error("runAfterPageLoad() requires browser document.");
        if (document.readyState === "complete") t();
        else {
          let e = setInterval(function() {
            document.readyState === "complete" && (clearInterval(e), t());
          }, 10);
        }
      }, ke.unregister = function(t) {
        Ma(t) ? delete Zo[t] : console.warn('No extension mapping for name "' + t + '" found to unregister');
      };
      var ni = {};
      ni.arc = dt, ni.curve = $t, ni.line = Bo, ni.lineOnAxis = A, ni.lineTo = Be, ni.moveBy = ct, ni.moveTo = St, ni.point = R;
      var at = {};
      at.Coordinate = m, at.KeyCodes = C, at.Rect = F, at.Size = H, at.Svg = g, at.aria = se, at.array = Id, at.browserEvents = Ze, at.colour = fe, at.deprecation = Md, at.dom = Rt, at.extensions = ke, at.idGenerator = _c, at.math = Sr, at.object = Ld, at.parsing = Br, at.string = Yo, at.style = ti, at.svgMath = $i, at.svgPaths = ni, at.toolbox = Ji, at.userAgent = cf, at.xml = Go;
      var ru = class extends j {
        constructor(t, e, i, o) {
          super(t, e, i, void 0, o), this.workspace = t, this.anchor = e, this.ownerRect = i, this.owner = o, this.resizePointerMoveListener = this.resizePointerUpListener = null, this.sizeChangeListeners = [], this.locationChangeListeners = [], this.DEFAULT_SIZE = new H(160 + j.DOUBLE_BORDER, 80 + j.DOUBLE_BORDER), this.MIN_SIZE = new H(45 + j.DOUBLE_BORDER, 20 + j.DOUBLE_BORDER), this.editable = !0, this.textChangeListener = () => {
            this.recomputeAriaContext();
          }, b(this.svgRoot, "blocklyTextInputBubble"), this.editor = new js(t, this.id, () => {
            r.t().focusNode(this);
          }), this.contentContainer.appendChild(this.editor.getDom()), this.resizeGroup = this.createResizeHandle(this.svgRoot, t), this.setSize(this.DEFAULT_SIZE, !0), this.addTextChangeListener(this.textChangeListener);
        }
        getText() {
          return this.editor.getText();
        }
        setText(t) {
          this.editor.setText(t);
        }
        setEditable(t) {
          this.editable = t, this.editor.setEditable(t);
        }
        isEditable() {
          return this.editable;
        }
        addTextChangeListener(t) {
          this.editor.addTextChangeListener(t);
        }
        addSizeChangeListener(t) {
          this.sizeChangeListeners.push(t);
        }
        addLocationChangeListener(t) {
          this.locationChangeListeners.push(t);
        }
        createResizeHandle(t, e) {
          return t = v(g.IMAGE, { class: "blocklyResizeHandle", href: `${e.options.pathToMedia}resize-handle.svg` }, t), M(t, "pointerdown", this, this.onResizePointerDown), t;
        }
        setSize(t, e = !1) {
          t.width = Math.max(t.width, this.MIN_SIZE.width), t.height = Math.max(t.height, this.MIN_SIZE.height);
          var i = t.width - j.DOUBLE_BORDER, o = t.height - j.DOUBLE_BORDER;
          this.editor.updateSize(new H(i, o), new H(0, 0)), this.editor.getDom().setAttribute("x", `${j.DOUBLE_BORDER / 2}`), this.editor.getDom().setAttribute("y", `${j.DOUBLE_BORDER / 2}`), this.resizeGroup.setAttribute("y", `${o}`), this.workspace.RTL ? this.resizeGroup.setAttribute("x", `${-j.DOUBLE_BORDER}`) : this.resizeGroup.setAttribute("x", `${i}`), super.setSize(t, e), this.onSizeChange();
        }
        getSize() {
          return super.getSize();
        }
        moveDuringDrag(t) {
          super.moveDuringDrag(t), this.onLocationChange();
        }
        setPositionRelativeToAnchor(t, e) {
          super.setPositionRelativeToAnchor(t, e), this.onLocationChange();
        }
        positionByRect(t = new F(0, 0, 0, 0)) {
          super.positionByRect(t), this.onLocationChange();
        }
        onResizePointerDown(t) {
          this.bringToFront(), _e(t) || (qn(this.workspace, t, new m(this.workspace.RTL ? -this.getSize().width : this.getSize().width, this.getSize().height)), this.resizePointerUpListener = M(document, "pointerup", this, this.onResizePointerUp), this.resizePointerMoveListener = M(document, "pointermove", this, this.onResizePointerMove), this.workspace.hideChaff()), t.stopPropagation();
        }
        onResizePointerUp() {
          Ft = null, this.resizePointerUpListener && ($(this.resizePointerUpListener), this.resizePointerUpListener = null), this.resizePointerMoveListener && ($(this.resizePointerMoveListener), this.resizePointerMoveListener = null);
        }
        onResizePointerMove(t) {
          t = Zn(this.workspace, t), this.setSize(new H(this.workspace.RTL ? -t.x : t.x, t.y), !1), this.onSizeChange();
        }
        onSizeChange() {
          for (let t of this.sizeChangeListeners) t();
        }
        onLocationChange() {
          for (let t of this.locationChangeListeners) t();
        }
        getEditor() {
          return this.editor;
        }
        performAction() {
          r.t().focusNode(this.getEditor());
        }
        dispose() {
          super.dispose(), this.editor.removeTextChangeListener(this.textChangeListener);
        }
      };
      ce(`
.blocklyTextInputBubble .blocklyTextarea {
  background-color: var(--commentFillColour);
  border: 0;
  box-sizing: border-box;
  display: block;
  outline: 0;
  padding: 5px;
  resize: none;
  width: 100%;
  height: 100%;
}
`);
      var Qo = class {
        constructor(t) {
          this.connectionChecker = t, this.connections = [], this.bulkCounter = 0;
        }
        addConnection(t, e) {
          e = this.calculateIndexForYPos(e), this.connections.splice(e, 0, t);
        }
        findIndexOfConnection(t, e) {
          if (!this.connections.length) return -1;
          var i = this.calculateIndexForYPos(e);
          if (i >= this.connections.length) return -1;
          e = t.y;
          for (var o = i; o >= 0 && this.connections[o].y === e; ) {
            if (this.connections[o] === t) return o;
            o--;
          }
          for (o = i; o < this.connections.length && this.connections[o].y === e; ) {
            if (this.connections[o] === t) return o;
            o++;
          }
          return -1;
        }
        calculateIndexForYPos(t) {
          if (!this.connections.length) return 0;
          for (var e = 0, i = this.connections.length; e < i; ) {
            let o = Math.floor((e + i) / 2);
            if (this.connections[o].y < t) e = o + 1;
            else if (this.connections[o].y > t) i = o;
            else {
              e = o;
              break;
            }
          }
          return e;
        }
        removeConnection(t, e) {
          if (t = this.findIndexOfConnection(t, e), t === -1) throw Error("Unable to find connection in connectionDB.");
          this.connections.splice(t, 1);
        }
        reorderConnection(t, e) {
          this.bulkCounter === 0 && (this.removeConnection(t, t.y), this.addConnection(t, e));
        }
        getNeighbours(t, e) {
          function i(E) {
            var O = s - o[E].x, L = n - o[E].y;
            return Math.sqrt(O * O + L * L) <= e && c.push(o[E]), L < e;
          }
          var o = this.connections, s = t.x, n = t.y;
          t = 0;
          for (var l = o.length - 2, a = l; t < a; ) o[a].y < n ? t = a : l = a, a = Math.floor((t + l) / 2);
          var c = [];
          if (l = t = a, o.length) {
            for (; t >= 0 && i(t); ) t--;
            do
              l++;
            while (l < o.length && i(l));
          }
          return c;
        }
        isInYRange(t, e, i) {
          return Math.abs(this.connections[t].y - e) <= i;
        }
        searchForClosest(t, e, i) {
          if (!this.connections.length) return { connection: null, radius: e };
          var o = t.y, s = t.x;
          t.x = s + i.x, t.y = o + i.y;
          var n = this.calculateIndexForYPos(t.y);
          i = null;
          for (var l = e, a, c = n - 1; c >= 0 && this.isInYRange(c, t.y, e); ) a = this.connections[c], this.connectionChecker.canConnect(t, a, !0, l) && (i = a, l = a.distanceFrom(t)), c--;
          for (; n < this.connections.length && this.isInYRange(n, t.y, e); ) a = this.connections[n], this.connectionChecker.canConnect(t, a, !0, l) && (i = a, l = a.distanceFrom(t)), n++;
          return t.x = s, t.y = o, { connection: i, radius: l };
        }
        beginBulkUpdates() {
          this.bulkCounter++;
        }
        endBulkUpdates() {
          if (this.bulkCounter === 0) throw Error("Bulk updates are already ended.");
          this.bulkCounter--, this.bulkCounter === 0 && this.reorderConnections();
        }
        reorderConnections() {
          this.connections.sort((t, e) => t.y - e.y);
        }
        static init(t) {
          var e = [];
          return e[T.INPUT_VALUE] = new Qo(t), e[T.OUTPUT_VALUE] = new Qo(t), e[T.NEXT_STATEMENT] = new Qo(t), e[T.PREVIOUS_STATEMENT] = new Qo(t), e;
        }
      }, X = class {
        constructor(t, e) {
          if (this.type = e, this.targetConnection = null, this.disposed = !1, this.shadowDom = this.check = null, this.y = this.x = 0, this.shadowState = null, this.sourceBlock_ = t, t.id.includes("_connection")) throw Error(`Connection ID indicator is contained in block ID. This will cause problems with focus: ${t.id}.`);
          this.id = `${t.id}_connection_${It()}`;
        }
        connect_(t) {
          var e = T.INPUT_VALUE, i = this.getSourceBlock(), o = t.getSourceBlock();
          if (t.isConnected() && t.disconnectInternal(!1), this.isConnected()) {
            let l = this.stashShadowState(), a = this.targetBlock();
            if (a.isShadow()) a.dispose(!1);
            else {
              this.disconnectInternal();
              var s = a;
            }
            this.applyShadowState(l);
          }
          if (ht()) {
            var n = new (D(p.BLOCK_MOVE))(o);
            n.setReason(["connect"]);
          }
          if (!this || !t) throw Error("Cannot connect null connections.");
          this.targetConnection = t, t.targetConnection = this, o.setParent(i), n && (n.recordNew(), N(n)), s && (t = this.type === e ? s.outputConnection : s.previousConnection) && ((o = X.getConnectionForOrphanedConnection(o, t)) ? t.connect(o) : t.onFailedConnect(this));
        }
        dispose() {
          if (this.isConnected()) {
            this.isSuperior() && this.setShadowStateInternal();
            let t = this.targetBlock();
            t && !t.isDeadOrDying() && t.unplug();
          }
          this.disposed = !0;
        }
        getSourceBlock() {
          return this.sourceBlock_;
        }
        isSuperior() {
          return this.type === T.INPUT_VALUE || this.type === T.NEXT_STATEMENT;
        }
        isConnected() {
          return !!this.targetConnection;
        }
        getConnectionChecker() {
          return this.sourceBlock_.workspace.connectionChecker;
        }
        onFailedConnect() {
        }
        connect(t) {
          if (this.targetConnection === t) return !0;
          if (this.getConnectionChecker().canConnect(this, t, !1)) {
            let e = r.gd;
            e || r.B(!0), this.isSuperior() ? this.connect_(t) : t.connect_(this), r.B(e);
          }
          return this.isConnected();
        }
        disconnect() {
          this.disconnectInternal();
        }
        disconnectInternal(t = !0) {
          var { parentConnection: e, childConnection: i } = this.getParentAndChildConnections();
          if (!e || !i) throw Error("Source connection not connected.");
          var o = r.gd;
          if (o || r.B(!0), ht()) {
            var s = new (D(p.BLOCK_MOVE))(i.getSourceBlock());
            s.setReason(["disconnect"]);
          }
          var n = this.targetConnection;
          n && (n.targetConnection = null), this.targetConnection = null, t && i.getSourceBlock().setParent(null), s && (s.recordNew(), N(s)), i.getSourceBlock().isShadow() || e.respawnShadow_(), r.B(o);
        }
        getParentAndChildConnections() {
          return this.targetConnection ? this.isSuperior() ? { parentConnection: this, childConnection: this.targetConnection } : { parentConnection: this.targetConnection, childConnection: this } : {};
        }
        respawnShadow_() {
          this.createShadowBlock(!0);
        }
        reconnect(t, e) {
          if (this.getSourceBlock().isDeadOrDying()) return !1;
          var i;
          return e = (i = t.getInput(e)) == null ? void 0 : i.connection, i = this.targetBlock(), i && i !== t || !e || e.targetConnection === this ? !1 : (e.isConnected() && e.disconnect(), e.connect(this), !0);
        }
        targetBlock() {
          if (this.isConnected()) {
            let t, e;
            return (e = (t = this.targetConnection) == null ? void 0 : t.getSourceBlock()) != null ? e : null;
          }
          return null;
        }
        onCheckChanged_() {
          !this.isConnected() || this.targetConnection && this.getConnectionChecker().canConnect(this, this.targetConnection, !1) || (this.isSuperior() ? this.targetBlock() : this.sourceBlock_).unplug();
        }
        setCheck(t) {
          return t ? (Array.isArray(t) || (t = [t]), this.check = t, this.onCheckChanged_()) : this.check = null, this;
        }
        getCheck() {
          return this.check;
        }
        setShadowDom(t) {
          this.setShadowStateInternal({ shadowDom: t });
        }
        getShadowDom(t) {
          return t && this.targetBlock().isShadow() ? Ei(this.targetBlock()) : this.shadowDom;
        }
        setShadowState(t) {
          this.setShadowStateInternal({ shadowState: t });
        }
        getShadowState(t) {
          return t && this.targetBlock() && this.targetBlock().isShadow() ? ee(this.targetBlock()) : this.shadowState;
        }
        neighbours() {
          return [];
        }
        getParentInput() {
          var t = null, e = this.sourceBlock_.inputList;
          for (let i = 0; i < e.length; i++) if (e[i].connection === this) {
            t = e[i];
            break;
          }
          return t;
        }
        toString() {
          var t = this.sourceBlock_;
          if (!t) return "Orphan Connection";
          if (t.outputConnection === this) var e = "Output Connection of ";
          else if (t.previousConnection === this) e = "Previous Connection of ";
          else if (t.nextConnection === this) e = "Next Connection of ";
          else {
            e = null;
            for (let i = 0, o; o = t.inputList[i]; i++) if (o.connection === this) {
              e = o;
              break;
            }
            if (e) e = 'Input "' + e.name + '" connection on ';
            else return console.warn("Connection not actually connected to sourceBlock_"), "Orphan Connection";
          }
          return e + t.toDevString();
        }
        stashShadowState() {
          var t = this.getShadowDom(!0), e = this.getShadowState(!0);
          return this.shadowState = this.shadowDom = null, { shadowDom: t, shadowState: e };
        }
        applyShadowState({ shadowDom: t, shadowState: e }) {
          this.shadowDom = t, this.shadowState = e;
        }
        setShadowStateInternal({ shadowDom: t = null, shadowState: e = null } = {}) {
          this.shadowDom = t, this.shadowState = e, this.getSourceBlock().isDeadOrDying() || ((t = this.targetBlock()) ? t.isShadow() ? (t.dispose(!1), this.respawnShadow_(), this.targetBlock() && this.targetBlock().isShadow() && this.serializeShadow(this.targetBlock())) : (t = this.createShadowBlock(!1), this.serializeShadow(t), t && t.dispose(!1)) : (this.respawnShadow_(), this.targetBlock() && this.targetBlock().isShadow() && this.serializeShadow(this.targetBlock())));
        }
        createShadowBlock(t) {
          var e = this.getSourceBlock(), i = this.getShadowState(), o = this.getShadowDom();
          if (e.isDeadOrDying() || !i && !o) return null;
          if (i) return e = fi(i, e.workspace, { parentConnection: t ? this : void 0, isShadow: !0, recordUndo: !1 });
          if (o) {
            if (e = zi(o, e.workspace), t) if (this.type === T.INPUT_VALUE) {
              if (!e.outputConnection) throw Error("Shadow block is missing an output connection");
              if (!this.connect(e.outputConnection)) throw Error("Could not connect shadow block to connection");
            } else if (this.type === T.NEXT_STATEMENT) {
              if (!e.previousConnection) throw Error("Shadow block is missing previous connection");
              if (!this.connect(e.previousConnection)) throw Error("Could not connect shadow block to connection");
            } else throw Error("Cannot connect a shadow block to a previous/output connection");
            return e;
          }
          return null;
        }
        serializeShadow(t) {
          t && (this.shadowDom = Ei(t), this.shadowState = ee(t));
        }
        static getConnectionForOrphanedConnection(t, e) {
          if (e.type === T.OUTPUT_VALUE) {
            t: {
              e = e.getSourceBlock();
              for (var i; i = od(t, e); ) if (t = i.targetBlock(), !t || t.isShadow()) {
                e = i;
                break t;
              }
              e = null;
            }
            return e;
          }
          return t = t.lastConnectionInStack(!0), i = e.getConnectionChecker(), t && i.canConnect(e, t, !1) ? t : null;
        }
      };
      X.CAN_CONNECT = 0, X.REASON_SELF_CONNECTION = 1, X.REASON_WRONG_TYPE = 2, X.REASON_TARGET_NULL = 3, X.REASON_CHECKS_FAILED = 4, X.REASON_DIFFERENT_WORKSPACES = 5, X.REASON_SHADOW_PARENT = 6, X.REASON_DRAG_CHECKS_FAILED = 7, X.REASON_PREVIOUS_AND_OUTPUT = 8;
      var Gg = class extends Error {
        constructor(t) {
          super(`Tried to append an icon of type ${t.getType()} when an icon of that type already exists on the block. Use getIcon to access the existing icon.`), this.icon = t;
        }
      }, Vg = {};
      Vg.DuplicateIconType = Gg;
      var ao;
      ao = r.Xn || (r.Xn = {}), ao[ao.LEFT = -1] = "LEFT", ao[ao.CENTRE = 0] = "CENTRE", ao[ao.RIGHT = 1] = "RIGHT";
      var ho = [];
      ho[T.INPUT_VALUE] = T.OUTPUT_VALUE, ho[T.OUTPUT_VALUE] = T.INPUT_VALUE, ho[T.NEXT_STATEMENT] = T.PREVIOUS_STATEMENT, ho[T.PREVIOUS_STATEMENT] = T.NEXT_STATEMENT;
      var Dt = class extends X {
        constructor(t, e) {
          super(t, e), this.highlighted = !1, this.targetConnection = null, this.db = t.workspace.connectionDBList[e], this.dbOpposite = t.workspace.connectionDBList[ho[e]], this.offsetInBlock = new m(0, 0), this.trackedState = Dt.TrackedState.WILL_TRACK;
        }
        dispose() {
          super.dispose(), this.trackedState === Dt.TrackedState.TRACKED && this.db.removeConnection(this, this.y);
          var t, e;
          (e = (t = this.sourceBlock_.pathObject).removeConnectionHighlight) == null || e.call(t, this);
        }
        getSourceBlock() {
          return super.getSourceBlock();
        }
        targetBlock() {
          return super.targetBlock();
        }
        distanceFrom(t) {
          var e = this.x - t.x;
          return t = this.y - t.y, Math.sqrt(e * e + t * t);
        }
        bumpAwayFrom(t, e = !1) {
          if (!this.sourceBlock_.workspace.isDragging()) {
            var i = r.Og.snapRadius + Math.floor(Math.random() * 10), o = r.Og.snapRadius + Math.floor(Math.random() * 10), s = t.sourceBlock_.getRootBlock(), n = this.sourceBlock_.getRootBlock();
            if (!s.isInFlyout && !n.isInFlyout) {
              var l = !0;
              if (n.isMovable()) s.isMovable() && e && (o = -o);
              else if (s.isMovable()) l = !1, i = -i, o = -o;
              else return;
              e = l ? t : this, t = l ? this : t, s = l ? n : s, s.RTL && (i = -i), s.moveBy(e.x + i - t.x, e.y + o - t.y, ["bump"]);
            }
          }
        }
        moveTo(t, e) {
          var i = this.x !== t || this.y !== e, o = !1;
          return this.trackedState === Dt.TrackedState.WILL_TRACK ? (this.db.addConnection(this, e), this.trackedState = Dt.TrackedState.TRACKED, o = !0) : this.trackedState === Dt.TrackedState.TRACKED && i && (this.db.reorderConnection(this, e), o = !0), this.x = t, this.y = e, o;
        }
        moveBy(t, e) {
          return this.moveTo(this.x + t, this.y + e);
        }
        moveToOffset(t) {
          return this.moveTo(t.x + this.offsetInBlock.x, t.y + this.offsetInBlock.y);
        }
        setOffsetInBlock(t, e) {
          this.offsetInBlock.x = t, this.offsetInBlock.y = e;
        }
        getOffsetInBlock() {
          return this.offsetInBlock;
        }
        tightenEfficiently() {
          var t = this.targetConnection, e = this.targetBlock();
          t && e && (t = m.difference(this.offsetInBlock, t.offsetInBlock), this.insertionMarker && (this.type === T.INPUT_VALUE ? t.x += this.insertionMarker.getHeightWidth().width : t.y += this.insertionMarker.getHeightWidth().height), e.translate(t.x, t.y));
        }
        closest(t, e) {
          return this.dbOpposite.searchForClosest(this, t, e);
        }
        setAriaRole(t) {
          var e = this.type === T.INPUT_VALUE ? r.C.INPUT_LABEL_VALUE : r.C.INPUT_LABEL_STATEMENT;
          G(t, W.FIGURE), w(t, y.ROLEDESCRIPTION, e);
        }
        recomputeAriaContext(t) {
          this.setAriaRole(t);
          var e, i, o, s = (o = this.getParentInput()) != null ? o : (e = this.getSourceBlock().getTopStackBlock().previousConnection) == null || (i = e.targetConnection) == null ? void 0 : i.getParentInput();
          if (s) {
            var n;
            e = (n = s?.getAriaLabelText()) != null ? n : Wn(s.getSourceBlock(), s, !0).join(", "), this.type === T.NEXT_STATEMENT ? w(t, y.LABEL, r.C.INPUT_LABEL_END_STATEMENT.replace("%1", e)) : w(t, y.LABEL, e);
          } else w(t, y.LABEL, r.C.INPUT_LABEL_EMPTY);
        }
        highlight() {
          this.highlighted = !0;
          var t = this.findHighlightSvg();
          t && (b(t, "blocklyHighlightedConnectionPathVisible"), requestAnimationFrame(() => {
            var e = t.parentElement;
            if (e) for (; t.nextSibling; ) e.insertBefore(t.nextSibling, t);
          }), this.recomputeAriaContext(t));
        }
        unhighlight() {
          this.highlighted = !1;
          var t = this.findHighlightSvg();
          t && Y(t, "blocklyHighlightedConnectionPathVisible");
        }
        isHighlighted() {
          return this.highlighted;
        }
        setTracking(t) {
          t && this.trackedState === Dt.TrackedState.TRACKED || !t && this.trackedState === Dt.TrackedState.UNTRACKED || this.sourceBlock_.isInFlyout || (t ? (this.db.addConnection(this, this.y), this.trackedState = Dt.TrackedState.TRACKED) : (this.trackedState === Dt.TrackedState.TRACKED && this.db.removeConnection(this, this.y), this.trackedState = Dt.TrackedState.UNTRACKED));
        }
        stopTrackingAll() {
          if (this.setTracking(!1), this.targetConnection) {
            let t = this.targetBlock().getDescendants(!1);
            for (let e = 0; e < t.length; e++) {
              let i = t[e], o = i.getConnections_(!0);
              for (let s = 0; s < o.length; s++) o[s].setTracking(!1);
              for (let s of i.getIcons()) De(s) && s.setBubbleVisible(!1);
            }
          }
        }
        startTrackingAll() {
          this.setTracking(!0);
          var t = [];
          if (this.type !== T.INPUT_VALUE && this.type !== T.NEXT_STATEMENT) return t;
          var e = this.targetBlock();
          if (e) {
            let i;
            e.isCollapsed() ? (i = [], e.outputConnection && i.push(e.outputConnection), e.nextConnection && i.push(e.nextConnection), e.previousConnection && i.push(e.previousConnection)) : i = e.getConnections_(!0);
            for (let o = 0; o < i.length; o++) t.push(...i[o].startTrackingAll());
            t.length || (t = [e]);
          }
          return t;
        }
        onFailedConnect(t) {
          var e = this.getSourceBlock();
          if (r.Qc) {
            let i = r.gd;
            setTimeout(function() {
              e.isDisposed() || e.getParent() || (r.B(i), this.bumpAwayFrom(t), r.B(!1));
            }.bind(this), r.Og.bumpDelay);
          }
        }
        disconnectInternal(t = !0) {
          var { parentConnection: e, childConnection: i } = this.getParentAndChildConnections();
          if (e && i) {
            var o = r.gd;
            o || r.B(!0);
            var s = e.getSourceBlock(), n = i.getSourceBlock();
            super.disconnectInternal(t), s.queueRender(), n.updateDisabled(), n.queueRender(), n.getSvgRoot().style.display = "block", r.B(o);
          }
        }
        respawnShadow_() {
          super.respawnShadow_();
          var t = this.targetBlock();
          t && (t.initSvg(), t.queueRender());
        }
        neighbours(t) {
          return this.dbOpposite.getNeighbours(this, t);
        }
        connect_(t) {
          super.connect_(t);
          var e = this.getSourceBlock();
          t = t.getSourceBlock(), e.updateDisabled(), t.updateDisabled(), t.queueRender(), (e = e.getInputWithBlock(t)) && (e = e.isVisible(), t.getSvgRoot().style.display = e ? "block" : "none");
        }
        onCheckChanged_() {
          !this.isConnected() || this.targetConnection && this.getConnectionChecker().canConnect(this, this.targetConnection, !1) || (this.isSuperior() ? this.targetBlock() : this.sourceBlock_).unplug();
        }
        setCheck(t) {
          return super.setCheck(t), this.sourceBlock_.queueRender(), this;
        }
        showContextMenu(t) {
          var e = V.registry.getContextMenuOptions(
            { focusedNode: this },
            t
          );
          if (e.length) {
            var i = this.getSourceBlock(), o = i.workspace;
            if (t instanceof PointerEvent) var s = new m(t.clientX, t.clientY);
            else s = new m(this.x, this.y), s = pi(o, s).translate(i.RTL ? -5 : 5, 5);
            Lo(t, e, i.RTL, o, s);
          }
        }
        getFocusableElement() {
          var t = this.findHighlightSvg();
          if (t) return t;
          throw Error("No highlight SVG found corresponding to this connection.");
        }
        getFocusableTree() {
          return this.getSourceBlock().workspace;
        }
        onNodeFocus() {
          this.highlight();
          var t = this.getSourceBlock();
          t.workspace.isFlyout || t.moveSvgRootToFront(), t.workspace.scrollBoundsIntoView(t.getBoundingRectangleWithoutChildren());
        }
        onNodeBlur() {
          this.unhighlight();
        }
        canBeFocused() {
          return this.findHighlightSvg() !== null;
        }
        findHighlightSvg() {
          return this.getSourceBlock().getSvgRoot().querySelector(`#${CSS.escape(this.id)}`);
        }
        attachInsertionMarker(t) {
          this.insertionMarker = t;
        }
        detachInsertionMarker() {
          this.insertionMarker = void 0;
        }
        getInsertionMarker() {
          return this.insertionMarker;
        }
      }, zg = Dt || (Dt = {}), ts = zg.TrackedState || (zg.TrackedState = {});
      ts[ts.WILL_TRACK = -1] = "WILL_TRACK", ts[ts.UNTRACKED = 0] = "UNTRACKED", ts[ts.TRACKED = 1] = "TRACKED";
      var es = class {
        constructor(t, e) {
          this.name = t, this.sourceBlock = e, this.fieldRow = [], this.align = r.Xn.LEFT, this.visible = !0, this.ariaLabelProvider = null, this.type = r.je.CUSTOM, this.connection = null;
        }
        getSourceBlock() {
          return this.sourceBlock;
        }
        appendField(t, e) {
          return this.insertFieldAt(this.fieldRow.length, t, e), this;
        }
        insertFieldAt(t, e, i) {
          if (t < 0 || t > this.fieldRow.length) throw Error("index " + t + " out of bounds.");
          return (e || e === "" && i) && (typeof e == "string" && (e = r.lh({ type: "field_label", text: e })), e.setSourceBlock(this.sourceBlock), this.sourceBlock.initialized && this.initField(e), e.name = i, e.setVisible(this.isVisible()), e.prefixField && (t = this.insertFieldAt(t, e.prefixField)), this.fieldRow.splice(t, 0, e), t++, e.suffixField && (t = this.insertFieldAt(t, e.suffixField)), this.sourceBlock.rendered && this.sourceBlock.queueRender()), t;
        }
        removeField(t, e) {
          for (let i = 0, o; o = this.fieldRow[i]; i++) if (o.name === t) return o.dispose(), this.fieldRow.splice(i, 1), this.sourceBlock.rendered && this.sourceBlock.queueRender(), !0;
          if (e) return !1;
          throw Error('Field "' + t + '" not found.');
        }
        isVisible() {
          return this.visible;
        }
        setVisible(t) {
          var e = [];
          if (this.visible === t) return e;
          this.visible = t;
          for (let i = 0, o; o = this.fieldRow[i]; i++) o.setVisible(t);
          if (this.connection && this.connection instanceof Dt) {
            t ? e = this.connection.startTrackingAll() : this.connection.stopTrackingAll();
            let i = this.connection.targetBlock();
            i && (i.getSvgRoot().style.display = t ? "block" : "none");
          }
          return e;
        }
        markDirty() {
          for (let t = 0, e; e = this.fieldRow[t]; t++) e.markDirty();
        }
        setCheck(t) {
          if (!this.connection) throw Error("This input does not have a connection.");
          return this.connection.setCheck(t), this;
        }
        setAlign(t) {
          return this.align = t, this.sourceBlock.rendered && this.sourceBlock.queueRender(), this;
        }
        setShadowDom(t) {
          if (!this.connection) throw Error("This input does not have a connection.");
          return this.connection.setShadowDom(t), this;
        }
        getShadowDom() {
          if (!this.connection) throw Error("This input does not have a connection.");
          return this.connection.getShadowDom();
        }
        init() {
          for (let t of this.fieldRow) t.init();
        }
        setAriaLabelProvider(t) {
          return this.ariaLabelProvider = t, this;
        }
        getAriaLabelText() {
          return this.ariaLabelProvider ? typeof this.ariaLabelProvider == "string" ? et(this.ariaLabelProvider) : this.ariaLabelProvider(this) : null;
        }
        initModel() {
          for (let t of this.fieldRow) t.initModel();
        }
        initField(t) {
          this.sourceBlock.rendered ? t.init() : t.initModel();
        }
        dispose() {
          for (let t = 0, e; e = this.fieldRow[t]; t++) e.dispose();
          this.connection && this.connection.dispose();
        }
        makeConnection(t) {
          return this.sourceBlock.makeConnection_(t);
        }
        getRowId() {
          var t = this.getSourceBlock().inputList;
          if (this === t.find((n) => n.isVisible()) || this === t[0]) return this.getSourceBlock().getRowId();
          var e = t.indexOf(this), i, o = ((i = t[e - 1].connection) == null ? void 0 : i.type) === T.NEXT_STATEMENT, s;
          return ((s = this.connection) == null ? void 0 : s.type) === T.NEXT_STATEMENT || o ? `${this.getSourceBlock().id}-input${e}` : t[e - 1].getRowId();
        }
        getLabel(t = ot.STANDARD, e = !0) {
          if (!this.isVisible()) return "";
          var i = jl(this, !1, t), o;
          return e && ((o = this.connection) == null ? void 0 : o.type) === T.INPUT_VALUE && (e = this.connection.targetBlock()) && !e.isInsertionMarker() && i.push(Jl(e, t).join(", ")), i.join(", ");
        }
        getIndex() {
          var t = [r.je.DUMMY, r.je.END_ROW];
          return this.getSourceBlock().inputList.filter((e) => !t.includes(e.type)).indexOf(this);
        }
      }, Ge = class extends es {
        constructor(t, e) {
          super(t, e), this.name = t, this.type = r.je.DUMMY;
        }
      }, ri = class extends es {
        constructor(t, e) {
          super(t, e), this.name = t, this.type = r.je.END_ROW;
        }
      }, re = class extends es {
        constructor(t, e) {
          if (!t) throw Error("Statement inputs must have a non-empty name");
          super(t, e), this.name = t, this.type = r.je.STATEMENT, this.connection = this.makeConnection(T.NEXT_STATEMENT);
        }
      };
      r.go = class extends es {
        constructor(t, e) {
          if (!t) throw Error("Value inputs must have a non-empty name");
          super(t, e), this.name = t, this.type = r.je.VALUE, this.connection = this.makeConnection(T.INPUT_VALUE);
        }
      };
      var is = class {
        constructor(t, e, i) {
          if (this.data = null, this.disposed = !1, this.hue = null, this.colour_ = "#000000", this.styleName_ = "", this.suppressPrefixSuffix = !1, this.previousConnection = this.nextConnection = this.outputConnection = null, this.inputList = [], this.icons = [], this.disabledReasons = /* @__PURE__ */ new Set(), this.tooltip = "", this.contextMenu = !0, this.parentBlock_ = null, this.childBlocks_ = [], this.editable = this.movable = this.deletable = !0, this.collapsed_ = this.shadow = !1, this.outputShape_ = null, this.rendered = this.isInsertionMarker_ = this.initialized = this.disposing = !1, this.onchangeWrapper = this.helpUrl = null, this.statementInputCount = 0, this.workspace = t, this.id = i && !t.getBlockById(i) ? i : je(), t.setBlockById(this.id, this), this.xy = new m(0, 0), this.isInFlyout = t.isFlyout, this.isInMutator = t.isMutator, this.RTL = t.RTL, e) {
            if (this.type = e, i = gt[e], !i || typeof i != "object") throw TypeError("Invalid block definition for type: " + e);
            Object.assign(this, i);
          }
          t.addTopBlock(this), t.addTypedBlock(this), new.target === is && this.doInit_();
        }
        doInit_() {
          var t = r.gd;
          t || r.B(!0);
          var e = r.Qc;
          try {
            typeof this.init == "function" && (r.Qc = !1, this.init(), r.Qc = e), ht() && N(new (D(p.BLOCK_CREATE))(this));
          } finally {
            r.B(t), r.Qc = e;
          }
          this.inputsInlineDefault = this.inputsInline, typeof this.onchange == "function" && this.setOnChange(this.onchange);
        }
        dispose(t = !1) {
          this.disposing = !0, this.tooltip = "", this.onchangeWrapper && this.workspace.removeChangeListener(this.onchangeWrapper), this.unplug(t), ht() && N(new (D(p.BLOCK_DELETE))(this)), this.workspace.removeTopBlock(this), this.disposeInternal();
        }
        disposeInternal() {
          this.disposing = !0, this.onchangeWrapper && this.workspace.removeChangeListener(this.onchangeWrapper), this.workspace.removeTypedBlock(this), this.workspace.removeBlockById(this.id), typeof this.destroy == "function" && this.destroy(), this.childBlocks_.forEach((t) => t.disposeInternal()), this.inputList.forEach((t) => t.dispose()), this.inputList.length = 0, this.getConnections_(!0).forEach((t) => t.dispose()), this.disposed = !0;
        }
        isDeadOrDying() {
          return this.disposing || this.disposed;
        }
        initModel() {
          if (!this.initialized) {
            for (let t of this.inputList) t.initModel();
            this.initialized = !0;
          }
        }
        unplug(t) {
          this.outputConnection && this.unplugFromRow(t), this.previousConnection && this.unplugFromStack(t);
        }
        unplugFromRow(t) {
          var e = null, i;
          (i = this.outputConnection) != null && i.isConnected() && (e = this.outputConnection.targetConnection, this.outputConnection.disconnect()), e && t && (t = this.getOnlyValueConnection()) && t.isConnected() && !t.targetBlock().isShadow() && (t = t.targetConnection, t?.disconnect(), this.workspace.connectionChecker.canConnect(t, e, !1) ? e.connect(t) : t?.onFailedConnect(e));
        }
        getOnlyValueConnection() {
          var t = null;
          for (let e = 0; e < this.inputList.length; e++) {
            let i = this.inputList[e].connection;
            if (i && i.type === T.INPUT_VALUE && i.targetConnection) {
              if (t) return null;
              t = i;
            }
          }
          return t;
        }
        unplugFromStack(t) {
          var e = null, i;
          if ((i = this.previousConnection) != null && i.isConnected() && (e = this.previousConnection.targetConnection, this.previousConnection.disconnect()), t) {
            for (t = this.getNextBlock(); t && (t.isShadow() || !t.isMovable()); ) t = t.getNextBlock();
            if (t) {
              var o, s, n, l;
              t = (l = (o = t.previousConnection) == null || (s = o.targetBlock()) == null || (n = s.nextConnection) == null ? void 0 : n.targetConnection) != null ? l : null, t?.disconnect(), e && this.workspace.connectionChecker.canConnect(e, t, !1) && e.connect(t);
            }
          }
        }
        getConnections_() {
          var t = [];
          this.outputConnection && t.push(this.outputConnection), this.previousConnection && t.push(this.previousConnection), this.nextConnection && t.push(this.nextConnection);
          for (let e = 0, i; i = this.inputList[e]; e++) i.connection && t.push(i.connection);
          return t;
        }
        lastConnectionInStack(t) {
          for (var e = this.nextConnection; e; ) {
            let i = e.targetBlock();
            if (!i || t && i.isShadow()) return e;
            e = i.nextConnection;
          }
          return null;
        }
        bumpNeighbours() {
        }
        getParent() {
          return this.parentBlock_;
        }
        getInputWithBlock(t) {
          for (let e = 0, i; i = this.inputList[e]; e++) if (i.connection && i.connection.targetBlock() === t) return i;
          return null;
        }
        getSurroundParent() {
          var t = this;
          do {
            var e = t;
            if (t = t.getParent(), !t) return null;
          } while (t.getNextBlock() === e);
          return t;
        }
        getNextBlock() {
          return this.nextConnection && this.nextConnection.targetBlock();
        }
        getPreviousBlock() {
          return this.previousConnection && this.previousConnection.targetBlock();
        }
        getRootBlock() {
          var t = this;
          do {
            var e = t;
            t = e.parentBlock_;
          } while (t);
          return e;
        }
        getTopStackBlock() {
          var t = this;
          do
            var e = t.getPreviousBlock();
          while (e && e.getNextBlock() === t && (t = e));
          return t;
        }
        getChildren(t) {
          if (!t) return this.childBlocks_;
          t = [];
          for (let i = 0, o; o = this.inputList[i]; i++) if (o.connection) {
            var e = o.connection.targetBlock();
            e && t.push(e);
          }
          return (e = this.getNextBlock()) && t.push(e), t;
        }
        setParent(t) {
          if (t !== this.parentBlock_) {
            var e = this.previousConnection && this.previousConnection.targetBlock() || this.outputConnection && this.outputConnection.targetBlock(), i = !!e;
            if (i && t && e !== t) throw Error("Block connected to superior one that is not new parent.");
            if (!i && t) throw Error("Block not connected to new parent.");
            if (i && !t) throw Error("Cannot set parent to null while block is still connected to superior block.");
            this.parentBlock_ ? Qt(this.parentBlock_.childBlocks_, this) : this.workspace.removeTopBlock(this), (this.parentBlock_ = t) ? t.childBlocks_.push(this) : this.workspace.addTopBlock(this);
          }
        }
        getDescendants(t) {
          var e = [this], i = this.getChildren(t);
          for (let o, s = 0; o = i[s]; s++) e.push(...o.getDescendants(t));
          return e;
        }
        isDeletable() {
          return this.deletable && !this.isInFlyout && !this.shadow && !this.isDeadOrDying() && !this.workspace.isReadOnly();
        }
        isOwnDeletable() {
          return this.deletable;
        }
        setDeletable(t) {
          this.deletable = t;
        }
        isMovable() {
          return this.movable && !this.isInFlyout && !this.shadow && !this.isDeadOrDying() && !this.workspace.isReadOnly();
        }
        isOwnMovable() {
          return this.movable;
        }
        setMovable(t) {
          this.movable = t;
        }
        isDuplicatable() {
          return this.workspace.hasBlockLimits() ? this.workspace.isCapacityAvailable(Es(this, !0)) : !0;
        }
        isShadow() {
          return this.shadow;
        }
        setShadow(t) {
          this.shadow = t;
        }
        isInsertionMarker() {
          return this.isInsertionMarker_;
        }
        setInsertionMarker(t) {
          this.isInsertionMarker_ = t;
        }
        isEditable() {
          return this.editable && !this.isDeadOrDying() && !this.workspace.isReadOnly();
        }
        isOwnEditable() {
          return this.editable;
        }
        setEditable(t) {
          this.editable = t;
          for (let e of this.getFields()) e.updateEditable();
        }
        isDisposed() {
          return this.disposed;
        }
        getFullBlockField() {
          if (!this.isSimpleReporter()) return null;
          var t, e = (t = this.inputList[0]) == null ? void 0 : t.fieldRow[0];
          return e != null && e.isFullBlockField() ? e : null;
        }
        isSimpleReporter() {
          if (!this.outputConnection) return !1;
          for (let t of this.inputList) if (t.connection || t.fieldRow.length > 1) return !1;
          return !0;
        }
        getMatchingConnection(t, e) {
          var i = this.getConnections_(!0);
          if (t = t.getConnections_(!0), i.length !== t.length) throw Error("Connection lists did not match in length.");
          for (let o = 0; o < t.length; o++) if (t[o] === e) return i[o];
          return null;
        }
        setHelpUrl(t) {
          this.helpUrl = t;
        }
        setTooltip(t) {
          this.tooltip = t;
        }
        getTooltip() {
          return Do(this);
        }
        getColour() {
          return this.colour_;
        }
        getStyleName() {
          return this.styleName_;
        }
        getHue() {
          return this.hue;
        }
        setColour(t) {
          t = Oo(t), this.hue = t.hue, this.colour_ = t.hex;
        }
        setStyle(t) {
          this.styleName_ = t;
        }
        setOnChange(t) {
          if (t && typeof t != "function") throw Error("onchange must be a function.");
          this.onchangeWrapper && this.workspace.removeChangeListener(this.onchangeWrapper), this.onchange = t, this.onchangeWrapper = t.bind(this), this.workspace.addChangeListener(this.onchangeWrapper);
        }
        getField(t) {
          if (typeof t != "string") throw TypeError("Block.prototype.getField expects a string with the field name but received " + (t === void 0 ? "nothing" : t + " of type " + typeof t) + " instead");
          for (let e of this.getFields()) if (e.name === t) return e;
          return null;
        }
        *getFields() {
          for (let t of this.inputList) for (let e of t.fieldRow) yield e;
        }
        getVarModels() {
          var t = [];
          for (let e of this.getFields()) if (e.referencesVariables()) {
            let i = this.workspace.getVariableMap().getVariableById(e.getValue());
            i && t.push(i);
          }
          return t;
        }
        updateVarName(t) {
          for (let e of this.getFields()) e.referencesVariables() && t.getId() === e.getValue() && e.refreshVariableName();
        }
        renameVarById(t, e) {
          for (let i of this.getFields()) i.referencesVariables() && t === i.getValue() && i.setValue(e);
        }
        getFieldValue(t) {
          return (t = this.getField(t)) ? t.getValue() : null;
        }
        setFieldValue(t, e) {
          var i = this.getField(e);
          if (!i) throw Error('Field "' + e + '" not found.');
          i.setValue(t);
        }
        setPreviousStatement(t, e) {
          if (t) e === void 0 && (e = null), this.previousConnection || (this.previousConnection = this.makeConnection_(T.PREVIOUS_STATEMENT)), this.previousConnection.setCheck(e);
          else if (this.previousConnection) {
            if (this.previousConnection.isConnected()) throw Error("Must disconnect previous statement before removing connection.");
            this.previousConnection.dispose(), this.previousConnection = null;
          }
        }
        setNextStatement(t, e) {
          if (t) e === void 0 && (e = null), this.nextConnection || (this.nextConnection = this.makeConnection_(T.NEXT_STATEMENT)), this.nextConnection.setCheck(e);
          else if (this.nextConnection) {
            if (this.nextConnection.isConnected()) throw Error("Must disconnect next statement before removing connection.");
            this.nextConnection.dispose(), this.nextConnection = null;
          }
        }
        setOutput(t, e) {
          if (t) e === void 0 && (e = null), this.outputConnection || (this.outputConnection = this.makeConnection_(T.OUTPUT_VALUE)), this.outputConnection.setCheck(e);
          else if (this.outputConnection) {
            if (this.outputConnection.isConnected()) throw Error("Must disconnect output value before removing connection.");
            this.outputConnection.dispose(), this.outputConnection = null;
          }
        }
        setInputsInline(t) {
          this.inputsInline !== t && (N(new (D(p.BLOCK_CHANGE))(
            this,
            "inline",
            null,
            this.inputsInline,
            t
          )), this.inputsInline = t);
        }
        getInputsInline() {
          if (this.inputsInline !== void 0) return this.inputsInline;
          for (var t = 1; t < this.inputList.length; t++) if (this.inputList[t - 1] instanceof Ge && this.inputList[t] instanceof Ge) return !1;
          for (t = 1; t < this.inputList.length; t++) if (this.inputList[t - 1] instanceof r.go && this.inputList[t] instanceof Ge) return !0;
          for (t = 0; t < this.inputList.length; t++) if (this.inputList[t] instanceof ri) return !0;
          return !1;
        }
        setOutputShape(t) {
          this.outputShape_ = t;
        }
        getOutputShape() {
          return this.outputShape_;
        }
        isEnabled() {
          return this.disabledReasons.size === 0;
        }
        setDisabledReason(t, e) {
          t || this.workspace.options.disable || !this.hasDisabledReason("MANUALLY_DISABLED") || e == "MANUALLY_DISABLED" || this.setDisabledReason(!1, "MANUALLY_DISABLED"), this.disabledReasons.has(e) !== t && (t ? this.disabledReasons.add(e) : this.disabledReasons.delete(e), t = new (D(p.BLOCK_CHANGE))(this, "disabled", null, !t, t), t.setDisabledReason(e), N(t));
        }
        getInheritedDisabled() {
          for (var t = this.getSurroundParent(); t; ) {
            if (!t.isEnabled()) return !0;
            t = t.getSurroundParent();
          }
          return !1;
        }
        hasDisabledReason(t) {
          return this.disabledReasons.has(t);
        }
        getDisabledReasons() {
          return this.disabledReasons;
        }
        isCollapsed() {
          return this.collapsed_;
        }
        setCollapsed(t) {
          this.collapsed_ !== t && (N(new (D(p.BLOCK_CHANGE))(this, "collapsed", null, this.collapsed_, t)), this.collapsed_ = t);
        }
        setAriaRoleDescriptionProvider(t) {
          this.ariaRoleDescriptionProvider = t;
        }
        getAriaRoleDescription() {
          return this.ariaRoleDescriptionProvider ? typeof this.ariaRoleDescriptionProvider == "function" ? this.ariaRoleDescriptionProvider() : et(this.ariaRoleDescriptionProvider) : this.statementInputCount ? r.C.BLOCK_LABEL_CONTAINER : this.outputConnection ? r.C.BLOCK_LABEL_VALUE : r.C.BLOCK_LABEL_STATEMENT;
        }
        toString(t, e) {
          e = this.toTokens(e);
          for (let o = 2; o < e.length; o++) e[o - 2] === "(" && e[o] === ")" && (e[o - 2] = e[o - 1], e.splice(o - 1, 2));
          var i = "";
          return e = e.reduce((o, s) => (o = o + (i === "(" || s === ")" ? "" : " ") + s, i = s[s.length - 1], o), ""), e = e.trim() || "???", t && e.length > t && (e = e.substring(0, t - 3) + "..."), e;
        }
        toTokens(t = "?") {
          var e = [];
          for (let o of this.inputList) if (o.name != "_TEMP_COLLAPSED_INPUT") {
            for (let s of o.fieldRow) e.push(s.getText());
            if (o.connection) {
              let s = o.connection.targetBlock();
              if (s) {
                var i = o.connection;
                let n = i.getCheck();
                !n && i.targetConnection && (n = i.targetConnection.getCheck()), (i = !!n && (n.includes("Boolean") || n.includes("Number"))) && e.push("("), e.push(...s.toTokens(t)), i && e.push(")");
              } else e.push(t);
            }
          }
          return e;
        }
        appendValueInput(t) {
          return this.appendInput(new r.go(t, this));
        }
        appendStatementInput(t) {
          return this.statementInputCount++, this.appendInput(new re(t, this));
        }
        appendDummyInput(t = "") {
          return this.appendInput(new Ge(t, this));
        }
        appendEndRowInput(t = "") {
          return this.appendInput(new ri(t, this));
        }
        appendInput(t) {
          return this.inputList.push(t), t;
        }
        appendInputFromRegistry(t, e) {
          return (t = Mt(
            _.INPUT,
            t,
            !1
          )) ? this.appendInput(new t(e, this)) : null;
        }
        jsonInit(t) {
          var e = t.type ? 'Block "' + t.type + '": ' : "";
          if (t.output && t.previousStatement) throw Error(e + "Must not have both an output and a previousStatement.");
          for (var i = 0; t[`args${i}`]; ) {
            if (t[`message${i}`] === void 0) throw Error(e + `args${i} must have a corresponding message (message${i}).`);
            i++;
          }
          if (t.style && typeof t.style == "object" && (this.hat = t.style.hat, t.style = null), t.style && t.colour) throw Error(e + "Must not have both a colour and a style.");
          for (t.style ? this.jsonInitStyle(
            t,
            e
          ) : this.jsonInitColour(t, e), i = 0; t[`message${i}`] !== void 0; ) this.interpolate(t[`message${i}`] || "", t[`args${i}`] || [], t[`implicitAlign${i}`] || t[`lastDummyAlign${i}`], e), i++;
          if (t.inputsInline !== void 0 && (r.Ub++, this.setInputsInline(t.inputsInline), r.Ub--), t.output !== void 0 && this.setOutput(!0, t.output), t.outputShape !== void 0 && this.setOutputShape(t.outputShape), t.previousStatement !== void 0 && this.setPreviousStatement(!0, t.previousStatement), t.nextStatement !== void 0 && this.setNextStatement(!0, t.nextStatement), t.tooltip !== void 0 && (i = et(t.tooltip), this.setTooltip(i)), t.enableContextMenu !== void 0 && (this.contextMenu = !!t.enableContextMenu), t.suppressPrefixSuffix !== void 0 && (this.suppressPrefixSuffix = !!t.suppressPrefixSuffix), t.helpUrl !== void 0 && (i = et(t.helpUrl), this.setHelpUrl(i)), t.ariaRoleDescription !== void 0 && this.setAriaRoleDescriptionProvider(t.ariaRoleDescription), typeof t.extensions == "string" && (console.warn(e + "JSON attribute 'extensions' should be an array of strings. Found raw string in JSON for '" + t.type + "' block."), t.extensions = [t.extensions]), t.mutator !== void 0 && tr(t.mutator, this, !0), t = t.extensions, Array.isArray(t)) for (e = 0; e < t.length; e++) tr(t[e], this, !1);
        }
        jsonInitColour(t, e) {
          if ("colour" in t) if (t.colour === void 0) console.warn(e + "Undefined colour value.");
          else {
            t = t.colour;
            try {
              this.setColour(t);
            } catch {
              console.warn(e + "Illegal colour value: ", t);
            }
          }
        }
        jsonInitStyle(t, e) {
          t = t.style;
          try {
            this.setStyle(t);
          } catch {
            console.warn(e + "Style does not exist: ", t);
          }
        }
        mixin(t, e) {
          if (e !== void 0 && typeof e != "boolean") throw Error("opt_disableCheck must be a boolean if provided");
          if (!e) {
            e = [];
            for (let i in t) this[i] !== void 0 && e.push(i);
            if (e.length) throw Error("Mixin will overwrite block members: " + JSON.stringify(e));
          }
          Object.assign(this, t);
        }
        interpolate(t, e, i, o) {
          t = Ca(t), this.validateTokens(t, e.length), e = this.interpolateArguments(t, e, i), i = [];
          for (let s = 0, n; n = e[s]; s++) if (this.isInputKeyword(n.type)) {
            if (t = this.inputFromJson(n, o)) {
              for (let l = 0, a; a = i[l]; l++) t.appendField(a[0], a[1]);
              i.length = 0;
            }
          } else (t = this.fieldFromJson(n)) && i.push([t, n.name]);
        }
        validateTokens(t, e) {
          var i = [], o = 0;
          for (let s = 0; s < t.length; s++) {
            let n = t[s];
            if (typeof n == "number") {
              if (n < 1 || n > e) throw Error('Block "' + this.type + '": Message index %' + n + " out of range.");
              if (i[n]) throw Error('Block "' + this.type + '": Message index %' + n + " duplicated.");
              i[n] = !0, o++;
            }
          }
          if (o !== e) throw Error('Block "' + this.type + '": Message does not reference all ' + e + " arg(s).");
        }
        interpolateArguments(t, e, i) {
          var o = [];
          for (let n = 0; n < t.length; n++) {
            var s = t[n];
            if (typeof s == "number" && (s = e[s - 1]), typeof s == "string") {
              if (s === `
`) s = { type: "input_end_row" }, i && (s.align = i);
              else if (s = this.stringToFieldJson(s), !s) continue;
            }
            o.push(s);
          }
          return (t = o.length) && !this.isInputKeyword(o[t - 1].type) && (t = { type: "input_dummy" }, i && (t.align = i), o.push(t)), o;
        }
        fieldFromJson(t) {
          var e = r.lh(t);
          return !e && t.alt ? typeof t.alt == "string" ? (t = this.stringToFieldJson(t.alt)) ? this.fieldFromJson(t) : null : this.fieldFromJson(t.alt) : e;
        }
        inputFromJson(t, e) {
          var i = { LEFT: r.Xn.LEFT, RIGHT: r.Xn.RIGHT, CENTRE: r.Xn.CENTRE, CENTER: r.Xn.CENTRE };
          switch (t.type) {
            case "input_value":
              var o = this.appendValueInput(t.name);
              break;
            case "input_statement":
              o = this.appendStatementInput(t.name);
              break;
            case "input_dummy":
              o = this.appendDummyInput(t.name);
              break;
            case "input_end_row":
              o = this.appendEndRowInput(t.name);
              break;
            default:
              o = this.appendInputFromRegistry(t.type, t.name);
          }
          return o ? (t.check && o.setCheck(t.check), t.align && (i = i[t.align.toUpperCase()], i === void 0 ? console.warn(e + "Illegal align value: ", t.align) : o.setAlign(i)), t.ariaLabelText && o.setAriaLabelProvider(t.ariaLabelText), o) : null;
        }
        isInputKeyword(t) {
          return t === "input_value" || t === "input_statement" || t === "input_dummy" || t === "input_end_row" || pn(_.INPUT, t);
        }
        stringToFieldJson(t) {
          return (t = t.trim()) ? { type: "field_label", text: t } : null;
        }
        moveInputBefore(t, e) {
          if (t !== e) {
            var i = -1, o = e ? -1 : this.inputList.length;
            for (let s = 0, n; n = this.inputList[s]; s++) if (n.name === t) {
              if (i = s, o !== -1) break;
            } else if (e && n.name === e && (o = s, i !== -1)) break;
            if (i === -1) throw Error('Named input "' + t + '" not found.');
            if (o === -1) throw Error('Reference input "' + e + '" not found.');
            this.moveNumberedInputBefore(i, o);
          }
        }
        moveNumberedInputBefore(t, e) {
          if (t === e) throw Error("Can't move input to itself.");
          if (t >= this.inputList.length) throw RangeError("Input index " + t + " out of bounds.");
          if (e > this.inputList.length) throw RangeError("Reference input " + e + " out of bounds.");
          var i = this.inputList[t];
          this.inputList.splice(t, 1), t < e && e--, this.inputList.splice(e, 0, i);
        }
        removeInput(t, e) {
          for (let i = 0, o; o = this.inputList[i]; i++) if (o.name === t) return o instanceof re && this.statementInputCount--, o.dispose(), this.inputList.splice(i, 1), !0;
          if (e) return !1;
          throw Error("Input not found: " + t);
        }
        getInput(t) {
          for (let e = 0, i; i = this.inputList[e]; e++) if (i.name === t) return i;
          return null;
        }
        getInputTargetBlock(t) {
          return (t = this.getInput(t)) && t.connection && t.connection.targetBlock();
        }
        getCommentText() {
          var t, e;
          return (e = (t = this.getIcon(Ct.COMMENT)) == null ? void 0 : t.getText()) != null ? e : null;
        }
        setCommentText(t) {
          var e, i, o = (i = (e = this.getIcon(Ct.COMMENT)) == null ? void 0 : e.getText()) != null ? i : null;
          if (o !== t) {
            if (t !== null) {
              if (e = this.getIcon(Ct.COMMENT), !e) {
                if (e = Mt(_.ICON, Ct.COMMENT.toString(), !1), !e) throw Error("No comment icon class is registered, so a comment cannot be set");
                if (e = new e(this), !(Fa(e) && De(e) && ys(e) && typeof e.setText == "function" && typeof e.getText == "function" && typeof e.setBubbleSize == "function" && typeof e.getBubbleSize == "function" && typeof e.setBubbleLocation == "function" && typeof e.getBubbleLocation == "function" && e.getType() === Ct.COMMENT)) throw Error("The class registered as a comment icon does not conform to the ICommentIcon interface");
                e = this.addIcon(e);
              }
              r.Ub++, e.setText(t), r.Ub--;
            } else this.removeIcon(Ct.COMMENT);
            N(new (D(p.BLOCK_CHANGE))(
              this,
              "comment",
              null,
              o,
              t
            ));
          }
        }
        setWarningText() {
        }
        setMutator() {
        }
        addIcon(t) {
          if (this.hasIcon(t.getType())) throw new Gg(t);
          return this.icons.push(t), this.icons.sort((e, i) => e.getWeight() - i.getWeight()), t;
        }
        removeIcon(t) {
          if (!this.hasIcon(t)) return !1;
          var e;
          return (e = this.getIcon(t)) == null || e.dispose(), this.icons = this.icons.filter((i) => !i.getType().equals(t)), !0;
        }
        hasIcon(t) {
          return this.icons.some((e) => e.getType().equals(t));
        }
        getIcon(t) {
          return t instanceof Ct ? this.icons.find((e) => e.getType().equals(t)) : this.icons.find((e) => e.getType().toString() === t);
        }
        getIcons() {
          return [...this.icons];
        }
        getRelativeToSurfaceXY() {
          return this.xy.clone();
        }
        moveBy(t, e, i) {
          if (this.parentBlock_) throw Error("Block has parent");
          var o = new (D(p.BLOCK_MOVE))(this);
          i && o.setReason(i), this.xy.translate(t, e), o.recordNew(), N(o);
        }
        makeConnection_(t) {
          return new X(this, t);
        }
        allInputsFilled(t) {
          if (t === void 0 && (t = !0), !t && this.isShadow()) return !1;
          for (let i = 0, o; o = this.inputList[i]; i++)
            if (o.connection) {
              var e = o.connection.targetBlock();
              if (!e || !e.allInputsFilled(t)) return !1;
            }
          return (e = this.getNextBlock()) ? e.allInputsFilled(t) : !0;
        }
        toDevString() {
          var t = this.type ? '"' + this.type + '" block' : "Block";
          return this.id && (t += ' (id="' + this.id + '")'), t;
        }
      };
      is.COLLAPSED_INPUT_NAME = "_TEMP_COLLAPSED_INPUT", is.COLLAPSED_FIELD_NAME = "_TEMP_COLLAPSED_FIELD";
      var Gr = null, Js = null, qs = {};
      qs.connectionUiEffect = Ua, qs.disconnectUiEffect = Wa, qs.disconnectUiStop = Mo, qs.disposeUiEffect = ir;
      var Zs = class {
        paste(t, e, i) {
          if (!e.isCapacityAvailable(t.typeCounts)) return null;
          i && (t.blockState.x = i.x, t.blockState.y = i.y), i = i ?? new m(t.blockState.x || 0, t.blockState.y || 0), r.Ub++;
          try {
            var o = Fi(t.blockState, e);
            sd(o, i);
          } finally {
            r.Ub--;
          }
          if (!o) return o;
          ht() && !o.isShadow() && N(new (D(p.BLOCK_CREATE))(o));
          var s = o;
          return te().then(() => {
            o.isDeadOrDying() || r.t().focusNode(s);
          }), o;
        }
      };
      Zs.TYPE = "block", Rn(Zs.TYPE, new Zs());
      var Vr = {};
      Vr.bumpIntoBounds = Os, Vr.bumpIntoBoundsHandler = Va, Vr.bumpTopObjectsIntoBounds = or;
      var co = null, uo = null, Qs = void 0, we = {};
      we.BlockPaster = Zs, we.copy = sr, we.getLastCopiedData = function() {
        return co;
      }, we.getLastCopiedLocation = function() {
        return Qs;
      }, we.getLastCopiedWorkspace = function() {
        return uo;
      }, we.paste = Me, we.registry = bc, we.setLastCopiedData = function(t) {
        co = t;
      }, we.setLastCopiedLocation = function(t) {
        Qs = t;
      }, we.setLastCopiedWorkspace = function(t) {
        uo = t;
      };
      var Si = {};
      Si.CollapseCommentBarButton = Pg, Si.CommentBarButton = Fr, Si.CommentEditor = js, Si.CommentView = $s, Si.DeleteCommentBarButton = Fg, Si.RenderedWorkspaceComment = ro, Si.WorkspaceComment = Hr;
      var Gt = class {
        constructor(t, e, i, o) {
          if (this.workspace = t, this.targetWorkspace = e, this.isFlyoutLabel = o, this.height = this.width = 0, this.cursorSvg = this.svgText = null, this.text = i.text, this.position = new m(0, 0), this.callbackKey = i.callbackKey || i.callbackkey, this.cssClass = i["web-class"] || null, this.info = i, t = this.isFlyoutLabel ? "blocklyFlyoutLabel" : "blocklyFlyoutButton", this.cssClass && (t += " " + this.cssClass), this.id = It(), this.svgGroup = v(g.G, { id: this.id, class: t }, this.workspace.getCanvas()), !this.isFlyoutLabel) {
            var s = v(g.RECT, { class: "blocklyFlyoutButtonShadow", rx: Gt.BORDER_RADIUS, ry: Gt.BORDER_RADIUS, x: 1, y: 1 }, this.svgGroup);
            G(s, W.NONE);
          }
          t = v(g.RECT, { class: this.isFlyoutLabel ? "blocklyFlyoutLabelBackground" : "blocklyFlyoutButtonBackground", rx: Gt.BORDER_RADIUS, ry: Gt.BORDER_RADIUS }, this.svgGroup), G(t, W.NONE), e = v(g.TEXT, { class: this.isFlyoutLabel ? "blocklyFlyoutLabelText" : "blocklyText", x: 0, y: 0, "text-anchor": "middle" }, this.svgGroup), i = et(this.text), this.workspace.RTL && (i += "‏"), e.textContent = i, this.isFlyoutLabel && (this.svgText = e, this.workspace.getThemeManager().subscribe(this.svgText, "flyoutForegroundColour", "fill")), G(e, W.NONE), o = `${i}, ${this.isFlyoutLabel ? r.C.ARIA_LABEL_HEADING : r.C.ARIA_LABEL_BUTTON}`, w(this.getFocusableElement(), y.LABEL, o), G(this.getFocusableElement(), W.OPTION), o = Ae(e, "fontSize");
          var n = Ae(e, "fontWeight"), l = Ae(e, "fontFamily");
          if (this.width = ds(e, o, n, l), i = dn(i, o, n, l), this.height = this.height || i.height, !this.isFlyoutLabel) {
            this.width += 2 * Gt.TEXT_MARGIN_X, this.height += 2 * Gt.TEXT_MARGIN_Y;
            let a;
            (a = s) == null || a.setAttribute("width", String(this.width));
            let c;
            (c = s) == null || c.setAttribute("height", String(this.height));
          }
          t.setAttribute("width", String(this.width)), t.setAttribute("height", String(this.height)), e.setAttribute("x", String(this.width / 2)), e.setAttribute("y", String(this.height / 2 - i.height / 2 + i.baseline)), this.updateTransform(), this.onMouseDownWrapper = M(this.svgGroup, "pointerdown", this, this.onMouseDown), this.onMouseUpWrapper = M(this.svgGroup, "pointerup", this, this.onMouseUp);
        }
        createDom() {
          return this.svgGroup;
        }
        show() {
          this.updateTransform(), this.svgGroup.setAttribute("display", "block");
        }
        updateTransform() {
          this.svgGroup.setAttribute("transform", "translate(" + this.position.x + "," + this.position.y + ")");
        }
        moveTo(t, e) {
          this.position.x = t, this.position.y = e, this.updateTransform();
        }
        moveBy(t, e) {
          this.moveTo(this.position.x + t, this.position.y + e);
        }
        isLabel() {
          return this.isFlyoutLabel;
        }
        getPosition() {
          return this.position;
        }
        getBoundingRectangle() {
          return new F(this.position.y, this.position.y + this.height, this.position.x, this.position.x + this.width);
        }
        getButtonText() {
          return this.text;
        }
        getTargetWorkspace() {
          return this.targetWorkspace;
        }
        getWorkspace() {
          return this.workspace;
        }
        dispose() {
          $(this.onMouseDownWrapper), $(this.onMouseUpWrapper), this.svgGroup && Q(this.svgGroup), this.svgText && this.workspace.getThemeManager().unsubscribe(this.svgText);
        }
        setCursorSvg(t) {
          t ? this.svgGroup && (this.svgGroup.appendChild(t), this.cursorSvg = t) : this.cursorSvg = null;
        }
        onMouseUp(t) {
          (t = this.targetWorkspace.getGesture(t)) && t.cancel(), this.isFlyoutLabel && this.callbackKey ? console.warn("Labels should not have callbacks. Label text: " + this.text) : this.isFlyoutLabel || this.callbackKey && this.targetWorkspace.getButtonCallback(this.callbackKey) ? this.isFlyoutLabel || (t = this.targetWorkspace.getButtonCallback(this.callbackKey)) && t(this) : console.warn("Buttons should have callbacks. Button text: " + this.text);
        }
        onMouseDown(t) {
          var e = this.targetWorkspace.getGesture(t), i = this.targetWorkspace.getFlyout();
          e && i && e.handleFlyoutStart(t, i);
        }
        getSvgRoot() {
          return this.svgGroup;
        }
        getFocusableElement() {
          return this.svgGroup;
        }
        getFocusableTree() {
          return this.workspace;
        }
        onNodeFocus() {
          var t = this.getPosition();
          t = new F(t.y, t.y + this.height, t.x, t.x + this.width), this.workspace.scrollBoundsIntoView(t);
        }
        onNodeBlur() {
        }
        canBeFocused() {
          return !0;
        }
        getId() {
          return this.id;
        }
        performAction() {
          if (this.isFlyoutLabel) {
            var t = this.targetWorkspace;
            let e = r.C.KEYBOARD_NAV_FLYOUT_LABEL_HINT.replace("%1", $e(B.NEXT_HEADING));
            Xt.show(t, { message: e, id: "flyoutLabelHint" });
          } else (t = this.targetWorkspace.getButtonCallback(this.callbackKey)) && t(this);
        }
      };
      Gt.TEXT_MARGIN_X = 5, Gt.TEXT_MARGIN_Y = 2, Gt.BORDER_RADIUS = 4, ce(`
.blocklyFlyoutButton {
  fill: #888;
  cursor: default;
}

.blocklyFlyoutButtonShadow {
  fill: #666;
}

@media (hover: hover) {
  .blocklyFlyoutButton:hover {
    fill: #aaa;
  }
}

.blocklyFlyoutButton:active {
  fill: #aaa;
}

.blocklyFlyoutLabel {
  cursor: default;
}

.blocklyFlyoutLabelBackground {
  opacity: 0;
}
`);
      var ve, os = ve || (ve = {});
      os[os.COMMIT = 1] = "COMMIT", os[os.DELETE = 2] = "DELETE", os[os.REVERT = 3] = "REVERT";
      var B, U = B || (B = {});
      U.ESCAPE = "escape", U.DELETE = "delete", U.COPY = "copy", U.CUT = "cut", U.PASTE = "paste", U.UNDO = "undo", U.REDO = "redo", U.MENU = "menu", U.FOCUS_WORKSPACE = "focus_workspace", U.FOCUS_TOOLBOX = "focus_toolbox", U.START_MOVE = "start_move", U.START_MOVE_STACK = "start_move_stack", U.FINISH_MOVE = "finish_move", U.ABORT_MOVE = "abort_move", U.MOVE_UP = "move_up", U.MOVE_DOWN = "move_down", U.MOVE_LEFT = "move_left", U.MOVE_RIGHT = "move_right", U.NAVIGATE_RIGHT = "right", U.NAVIGATE_LEFT = "left", U.NAVIGATE_UP = "up", U.NAVIGATE_DOWN = "down", U.DISCONNECT = "disconnect", U.NEXT_STACK = "next_stack", U.PREVIOUS_STACK = "previous_stack", U.INFORMATION = "information", U.EXTENDED_INFORMATION = "extended_information", U.PERFORM_ACTION = "perform_action", U.DUPLICATE = "duplicate", U.CLEANUP = "cleanup", U.SHOW_TOOLTIP = "show_tooltip", U.NEXT_HEADING = "next_heading", U.PREVIOUS_HEADING = "previous_heading", U.TOGGLE_SCREENREADER = "toggle_screenreader", U.JUMP_TOP_STACK = "jump_to_top_of_stack", U.JUMP_BOTTOM_STACK = "jump_to_bottom_of_stack", U.JUMP_BLOCK_START = "jump_to_block_start", U.JUMP_BLOCK_END = "jump_to_block_end", U.JUMP_FIRST_BLOCK = "jump_to_first_block", U.JUMP_LAST_BLOCK = "jump_to_last_block", U.JUMP_PREVIOUS_PAGE = "jump_to_previous_page", U.JUMP_NEXT_PAGE = "jump_to_next_page", U.SCROLL_LEFT = "scroll_left", U.SCROLL_RIGHT = "scroll_right", U.SCROLL_UP = "scroll_up", U.SCROLL_DOWN = "scroll_down";
      var Kg = S.registry.createSerializedKey(C.LEFT, [C.CTRL_CMD]), Xg = S.registry.createSerializedKey(C.RIGHT, [C.CTRL_CMD]), Yg = S.registry.createSerializedKey(C.UP, [C.CTRL_CMD]), jg = S.registry.createSerializedKey(C.DOWN, [C.CTRL_CMD]), lu = (t) => {
        if (t.isFlyout) {
          let i = t.targetWorkspace;
          if (i) return lu(i);
        }
        var e;
        return (e = t.getRootWorkspace()) != null ? e : t;
      }, zr = (t, e) => !t.isFlyout && !!e.focusedNode && !t.isDragging() && !r.t().ephemeralFocusTaken() && !!t.getNavigator().getSourceBlockFromNode(e.focusedNode), au = (t) => (t = t.getToolbox()) && r.t().getFocusedTree() === t ? t : null, $g = (t) => {
        var e, i = (e = au(t)) != null ? e : t.isFlyout && r.t().getFocusedTree() === t ? t : null;
        return i ? i.getNavigator().getNavigableItems(i.getRootFocusableNode()) : null;
      }, Jg = (t) => {
        var e;
        return (e = !t.isDragging() && !r.t().ephemeralFocusTaken()) && ((e = !!au(t)) || (e = t.isFlyout && r.t().getFocusedTree() === t)), e;
      }, Vt, Ri = Vt || (Vt = {});
      Ri[Ri.LEFT = 0] = "LEFT", Ri[Ri.RIGHT = 1] = "RIGHT", Ri[Ri.UP = 2] = "UP", Ri[Ri.DOWN = 3] = "DOWN";
      var bf = { [Vt.LEFT]: "ANNOUNCE_SCROLLED_LEFT", [Vt.RIGHT]: "ANNOUNCE_SCROLLED_RIGHT", [Vt.UP]: "ANNOUNCE_SCROLLED_UP", [Vt.DOWN]: "ANNOUNCE_SCROLLED_DOWN" }, Kr = (t) => {
        var e;
        return !t.isDragging() && t.isMovable() && !((e = t.targetWorkspace) != null && e.isMutator) && !J.mover.isMoving() && !mt && !Bt;
      }, qg = (t) => {
        t.getAudioManager().playErrorBeep(), ue(r.C.ANNOUNCE_CANT_SCROLL_FURTHER);
      }, Xr = (t, e, i) => {
        if (e.preventDefault(), i === Vt.LEFT || i === Vt.RIGHT ? !t.isMovableHorizontally() : !t.isMovableVertically()) return qg(t), !0;
        var o = e = 0;
        switch (i) {
          case Vt.LEFT:
            e = 50;
            break;
          case Vt.RIGHT:
            e = -50;
            break;
          case Vt.UP:
            o = 50;
            break;
          case Vt.DOWN:
            o = -50;
        }
        var s = t.scrollX, n = t.scrollY;
        return t.scroll(s + e, n + o), t.scrollX === s && t.scrollY === n ? (qg(t), !0) : (ue(r.C[bf[i]]), !0);
      };
      wh(), Ih(), Sh();
      var K = {};
      K.names = B, K.registerArrowNavigation = eh, K.registerCleanup = uh, K.registerCopy = ja, K.registerCut = $a, K.registerDefaultShortcuts = wh, K.registerDelete = Ya, K.registerDisconnectBlock = rh, K.registerDuplicate = ch, K.registerEscape = Xa, K.registerFocusToolbox = oh, K.registerFocusWorkspace = ih, K.registerHeadingNavigation = ah, K.registerJumpBlockEnd = fh, K.registerJumpBlockStart = ph, K.registerJumpBottomStack = vh, K.registerJumpFirstBlock = _h, K.registerJumpLastBlock = mh, K.registerJumpNextPage = bh, K.registerJumpPreviousPage = yh, K.registerJumpTopStack = Eh, K.registerKeyboardNavigationShortcuts = Ih, K.registerMovementShortcuts = Qa, K.registerNavigationShortcuts = function() {
        ph(), fh(), Eh(), vh(), _h(), mh(), yh(), bh(), kh();
      }, K.registerPaste = Ja, K.registerPerformAction = hh, K.registerReadExtendedInformation = nh, K.registerReadInformation = sh, K.registerRedo = Za, K.registerScreenReaderShortcuts = Sh, K.registerShowContextMenu = th, K.registerShowTooltip = dh, K.registerStackNavigation = lh, K.registerToggleScreenreaderMode = gh, K.registerUndo = qa, K.registerWorkspaceScrollShortcuts = kh;
      var le, Yr = le || (le = {});
      Yr[Yr.CONSTRAINED = 1] = "CONSTRAINED", Yr[Yr.UNCONSTRAINED = 2] = "UNCONSTRAINED";
      var Zg = class {
        constructor(t) {
          this.block = t, this.connectionPreviewer = this.connectionCandidate = this.startLoc = this.startChildConn = this.startParentConn = null, this.dragging = !1, this.allConnectionPairs = [], this.moveMode = le.UNCONSTRAINED, this.originalEventGroup = "", this.lastAnnouncedNeighbour = this.lastAnnouncedLocal = void 0, this.lastBlockDisabledReasons = /* @__PURE__ */ new Map(), this.WORKSPACE_MARGIN = this.BLOCK_CONNECTION_OFFSET = 10, this.workspace = t.workspace;
        }
        isMovable() {
          var t;
          return this.block.isOwnMovable() && !this.block.isDeadOrDying() && !this.workspace.isReadOnly() && (!this.block.isInFlyout || this.block.isEnabled() && !((t = this.block.workspace.targetWorkspace) != null && t.isReadOnly()));
        }
        positionNewBlock(t, e) {
          if (t = pi(t.workspace, t.getRelativeToSurfaceXY()), t = gi(e.workspace, t), e.moveDuringDrag(t), this.moveMode === le.CONSTRAINED) {
            t = e.workspace;
            var i = t.getMetricsManager().getViewMetrics(!0), o = i.top + this.WORKSPACE_MARGIN, s = t.RTL ? i.left + i.width - this.WORKSPACE_MARGIN : i.left + this.WORKSPACE_MARGIN, n = Math.max(r.Og.connectingSnapRadius, r.Og.snapRadius) + 2, l = t.getTopBlocks(!0).filter((z) => z.id !== e.id).map((z) => (z = z.getBoundingRectangle(), new F(z.top - n, z.bottom + n, z.left - n, z.right + n))), a = e.getHeightWidth().width, c = function(z) {
              for (let yt of l) if (z.intersects(yt)) return yt;
              return null;
            }, E = s, O = t.getRenderer().getConstants().MIN_BLOCK_HEIGHT, L = e.getBoundingRectangle();
            e.moveBy(t.RTL ? E - L.right : E - L.left, o - L.top, ["cleanup"]), L = e.getBoundingRectangle();
            for (var x = c(L); x != null; ) E = t.RTL ? x.left - 80 : x.right + 80, x = x.top + x.getHeight() + O, (t.RTL ? E - a >= i.left : E + a <= i.left + i.width) || (o = x, E = s), e.moveBy(t.RTL ? E - L.right : E - L.left, o - L.top, ["cleanup"]), L = e.getBoundingRectangle(), x = c(L);
          }
        }
        getTargetBlock() {
          if (this.block.isShadow()) {
            var t = this.block.getParent();
            if (t) return t;
          } else if (this.block.isInFlyout && this.block.workspace.targetWorkspace && (t = this.block.getRootBlock(), t = ee(t))) return t = fi(t, this.block.workspace.targetWorkspace, { recordUndo: !0 }), r.Qc = !1, t.render(), this.positionNewBlock(this.block, t), t.setDragging(!0), r.Qc = !0, t;
          return this.block;
        }
        announceMove(t = !1) {
          if (this.connectionCandidate) t = Xu(this.connectionCandidate.local, this.connectionCandidate.neighbour, this.hasMultipleCompatibleConnections.bind(this), t);
          else {
            var e = t ? this.block.getStackBlocksCountLabel() : "";
            t = r.C.ANNOUNCE_MOVE_WORKSPACE, t = t.replace("%1", e);
          }
          var i, o;
          e = (o = (i = this.connectionCandidate) == null ? void 0 : i.local) != null ? o : null;
          var s, n;
          i = (n = (s = this.connectionCandidate) == null ? void 0 : s.neighbour) != null ? n : null, (this.lastAnnouncedLocal === void 0 || e !== this.lastAnnouncedLocal || i !== this.lastAnnouncedNeighbour) && (this.lastAnnouncedLocal = e, this.lastAnnouncedNeighbour = i, ue(t.replace(/\s+/g, " ")));
        }
        hasMultipleCompatibleConnections(t = !0) {
          var e = this.connectionCandidate;
          if (!e) return !1;
          var i = t ? "local" : "neighbour", o = t ? "neighbour" : "local";
          return this.allConnectionPairs.filter((s) => s[o] === e[o] && s[i] !== e[i].getSourceBlock().nextConnection && s[i].getSourceBlock().id === e[i].getSourceBlock().id).length > 1;
        }
        startDrag(t) {
          this.updateMoveMode(t);
          var e = this.getTargetBlock();
          if (e !== this.block) return e.startDrag(t);
          if (this.block.workspace.recordDragTargets(), this.dragging = !0, this.lastAnnouncedNeighbour = this.lastAnnouncedLocal = void 0, this.fireDragStartEvent(), this.startLoc = this.block.getRelativeToSurfaceXY(), this.connectionCandidate = null, this.connectionPreviewer = new (Pt(_.CONNECTION_PREVIEWER, this.workspace.options))(this.block), Li(), this.workspace.setResizesEnabled(!1), Mo(), e = this.shouldHealStack(t), this.storeInitialConnections(e), this.shouldDisconnect(e) && this.disconnectBlock(e), this.block.setDragging(!0), this.enableAllDraggedBlocks(this.block), this.cacheAllConnectionPairs(), t instanceof KeyboardEvent) {
            let o;
            t = (o = this.getInitialCandidate()) != null ? o : void 0, this.updateConnectionPreview(this.block, new m(0, 0), t) && this.block.moveDuringDrag(this.determineConnectionOffset()), this.allConnectionPairs.length ? hd(this.workspace) : Rh(this.workspace);
          } else this.block.moveDuringDrag(this.startLoc);
          var i;
          return (i = this.workspace.getLayerManager()) == null || i.moveToDragLayer(this.block), this.getVisibleBubbles(this.block).forEach((o) => {
            var s;
            (s = this.workspace.getLayerManager()) == null || s.moveToDragLayer(
              o,
              !1
            );
          }), this.announceMove(!0), this.block;
        }
        cacheAllConnectionPairs() {
          var t = this.block.workspace.connectionChecker, e = [];
          this.allConnectionPairs = [];
          var i = this.getLocalConnections(this.block);
          for (let o of this.block.workspace.getTopBlocks(!0)) e.push(...this.getAllConnections(o));
          for (let o of e) for (let s of i) {
            let n;
            !t.canConnect(s, o, !0, 1 / 0) || (n = o.targetBlock()) != null && n.isInsertionMarker() || this.allConnectionPairs.push({ local: s, neighbour: o });
          }
        }
        getVisibleBubbles(t) {
          return t.getDescendants(!1).flatMap((e) => e.getIcons()).filter((e) => De(e) && e.bubbleIsVisible()).map((e) => e.getBubble()).filter((e) => !!e).sort((e, i) => (e = e.getSvgRoot().compareDocumentPosition(i.getSvgRoot()), e & Node.DOCUMENT_POSITION_PRECEDING ? 1 : e & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 0));
        }
        shouldHealStack(t) {
          return t instanceof PointerEvent ? t.ctrlKey || t.metaKey : t instanceof KeyboardEvent ? !(t.shiftKey || !this.block.previousConnection) : !1;
        }
        shouldDisconnect(t) {
          return !!(this.block.getParent() || t && this.block.nextConnection && this.block.nextConnection.targetBlock());
        }
        disconnectBlock(t) {
          this.block.unplug(t), Wa(this.block);
        }
        storeInitialConnections(t) {
          var e = this.startChildConn = this.startParentConn = null, i = null, o;
          if ((o = this.block.outputConnection) != null && o.isConnected()) e = this.block.outputConnection, i = this.block.outputConnection.targetConnection;
          else {
            let s;
            (s = this.block.previousConnection) != null && s.isConnected() && (e = this.block.previousConnection, i = this.block.previousConnection.targetConnection);
          }
          this.startParentConn = i, e && i ? this.connectionCandidate = { local: e, neighbour: i, distance: 0 } : t && (t = this.block.nextConnection, e = t?.targetConnection, t && e && (this.connectionCandidate = { local: t, neighbour: e, distance: 0 }), this.startChildConn = e ?? null);
        }
        fireDragStartEvent() {
          var t = new (D(p.BLOCK_DRAG))(this.block, !0, this.block.getDescendants(!1));
          N(t);
        }
        fireDragEndEvent() {
          var t = new (D(p.BLOCK_DRAG))(this.block, !1, this.block.getDescendants(!1));
          N(t);
        }
        fireMoveEvent() {
          if (!this.block.isDeadOrDying()) {
            var t = new (D(p.BLOCK_MOVE))(this.block);
            t.setReason(["drag"]), t.oldCoordinate = this.startLoc, t.recordNew(), N(t);
          }
        }
        drag(t, e) {
          if (this.updateMoveMode(e), this.moveMode === le.UNCONSTRAINED && this.block.moveDuringDrag(t), e = !!this.connectionCandidate, this.updateConnectionPreview(this.block, m.difference(t, this.startLoc)), this.connectionCandidate) this.moveMode === le.CONSTRAINED && this.block.moveDuringDrag(this.determineConnectionOffset());
          else if (this.moveMode === le.CONSTRAINED && (this.allConnectionPairs.length || Rh(this.workspace, !0), !e)) {
            this.workspace.getAudioManager().playErrorBeep();
            return;
          }
          this.announceMove();
        }
        determineConnectionOffset() {
          var {
            local: t,
            neighbour: e
          } = this.connectionCandidate, i = t.getOffsetInBlock(), o = e.x - i.x;
          i = e.y - i.y;
          var s = this.BLOCK_CONNECTION_OFFSET;
          return t.type === T.PREVIOUS_STATEMENT || t.type === T.OUTPUT_VALUE ? (o += s, i += s) : (o -= s, i -= s), new m(o, i);
        }
        updateConnectionPreview(t, e, i) {
          var o = this.connectionCandidate;
          if (i = i ?? this.getConnectionCandidate(e), this.connectionCandidate = null, i) {
            var s = o && this.currCandidateIsBetter(o, e, i) ? o : i;
            this.connectionCandidate = s;
            var { local: n, neighbour: l } = s;
            s = n.type === T.OUTPUT_VALUE || n.type === T.PREVIOUS_STATEMENT;
            var a;
            if (e = l.isConnected() && !((a = l.targetBlock()) != null && a.isInsertionMarker()), s && e && !this.orphanCanConnectAtEnd(t, l.targetBlock(), n.type)) {
              var c;
              (c = this.connectionPreviewer) == null || c.previewReplacement(n, l, l.targetBlock());
            } else {
              let O;
              (O = this.connectionPreviewer) == null || O.previewConnection(n, l);
            }
            return l;
          }
          if (this.moveMode === le.CONSTRAINED) {
            let O;
            a = (O = o?.neighbour.getSourceBlock()) != null ? O : null;
            let L;
            if (c = (L = a?.getRootBlock()) != null ? L : a, c === t && (c = a), !c) {
              let x;
              (x = this.connectionPreviewer) == null || x.hidePreview();
              return;
            }
            if (a = t.workspace.getTopBlocks().filter((x) => x !== t.getRootBlock()).map((x) => x.getBoundingRectangle()), !a.length) {
              let x;
              (x = this.connectionPreviewer) == null || x.hidePreview();
              return;
            }
            var E;
            switch (o = (E = o?.neighbour.x) != null ? E : t.getRelativeToSurfaceXY().x, E = this.BLOCK_CONNECTION_OFFSET * 2, this.getDirectionToNewLocation(m.sum(this.startLoc, e))) {
              case lt.LEFT:
              case lt.UP:
                e = Math.min(...a.map((x) => x.top)) - E - t.getHeightWidth().height;
                break;
              default:
                e = Math.max(...a.map((x) => x.bottom)) + E;
            }
            t.moveDuringDrag(new m(o, e));
          }
          (s = this.connectionPreviewer) == null || s.hidePreview();
        }
        orphanCanConnectAtEnd(t, e, i) {
          return !!X.getConnectionForOrphanedConnection(t, i === T.OUTPUT_VALUE ? e.outputConnection : e.previousConnection);
        }
        currCandidateIsBetter(t, e, i) {
          if (this.moveMode === le.CONSTRAINED) return !1;
          var { local: o, neighbour: s } = t;
          t = new m(o.x, o.y);
          var n = new m(s.x, s.y);
          return e = m.distance(m.sum(t, e), n), i.distance > e - r.Og.currentConnectionPreference;
        }
        getConnectionCandidate(t) {
          return this.moveMode === le.CONSTRAINED ? this.findTraversalCandidate(t) : this.getClosestCandidate(this.block, t);
        }
        getClosestCandidate(t, e) {
          var i = this.getSearchRadius();
          t = this.getLocalConnections(t);
          var o = null;
          for (let s of t) {
            let { connection: n, radius: l } = s.closest(i, e);
            n && (o = { local: s, neighbour: n, distance: l }, i = l);
          }
          return o;
        }
        getSearchRadius() {
          return this.moveMode === le.CONSTRAINED ? 1 / 0 : this.connectionCandidate ? r.Og.connectingSnapRadius : r.Og.snapRadius;
        }
        getLocalConnections(t) {
          var e = t.getConnections_(!1), i = t.lastConnectionInStack(!0);
          i && i !== t.nextConnection && e.push(i), t = [t.outputConnection, t.previousConnection, t.nextConnection].filter((o) => !!o), i = [];
          for (let o of e) t.includes(o) || i.push(o);
          return i.reverse(), [...t, ...i];
        }
        endDrag(t, e) {
          e === ve.DELETE && ir(this.block), this.originalEventGroup = r.gd, this.fireDragEndEvent(), this.fireMoveEvent(), xi(), Mo();
          var i;
          if ((i = this.connectionPreviewer) == null || i.hidePreview(), !this.block.isDeadOrDying() && this.dragging && e !== ve.DELETE) {
            let o;
            (o = this.workspace.getLayerManager()) == null || o.moveOffDragLayer(this.block, 50), this.getVisibleBubbles(this.block).forEach((s) => {
              var n;
              return (n = this.workspace.getLayerManager()) == null ? void 0 : n.moveOffDragLayer(s, 100, !1);
            }), this.block.setDragging(!1), this.redisableAllDraggedBlocks(this.block);
          }
          this.connectionCandidate && e !== ve.DELETE ? (this.applyConnections(this.connectionCandidate), this.disposeStep()) : (e !== ve.DELETE && this.workspace.getAudioManager().play("drop"), this.block.queueRender().then(() => this.disposeStep())), this.allConnectionPairs = [], this.connectionCandidate = this.startChildConn = this.startParentConn = null, this.dragging = !1;
        }
        disposeStep() {
          var t = r.gd;
          r.B(this.originalEventGroup), this.block.snapToGrid();
          var e;
          (e = this.connectionPreviewer) == null || e.dispose(), this.workspace.setResizesEnabled(!0), r.B(t);
        }
        applyConnections(t) {
          var { local: e, neighbour: i } = t;
          e.connect(i);
          var o = e.isSuperior() ? i : e, s = this.block.getRootBlock();
          te().then(() => {
            Ua(o.getSourceBlock()), setTimeout(() => {
              s.bringToFront();
            }, 0);
          });
        }
        revertDrag() {
          var t;
          if ((t = this.connectionPreviewer) == null || t.hidePreview(), this.connectionCandidate = null, this.block.nextConnection) {
            let e;
            (e = this.startChildConn) == null || e.connect(this.block.nextConnection);
          }
          if (this.startParentConn) switch (this.startParentConn.type) {
            case T.INPUT_VALUE:
              this.block.outputConnection && this.startParentConn.connect(this.block.outputConnection);
              break;
            case T.NEXT_STATEMENT:
              this.block.previousConnection && this.startParentConn.connect(this.block.previousConnection);
          }
          else {
            this.block.moveDuringDrag(this.startLoc);
            let e;
            (e = this.workspace.getLayerManager()) == null || e.moveOffDragLayer(this.block, 50), this.getVisibleBubbles(this.block).forEach((i) => {
              var o;
              return (o = this.workspace.getLayerManager()) == null ? void 0 : o.moveOffDragLayer(i, 100, !1);
            }), Os(this.workspace, this.workspace.getMetricsManager().getScrollMetrics(!0), this.block);
          }
          this.startParentConn = this.startChildConn = null, this.block.setDragging(!1), this.redisableAllDraggedBlocks(this.block), this.dragging = !1, ue(r.C.ANNOUNCE_MOVE_CANCELED);
        }
        findTraversalCandidate(t) {
          var e = this.getDirectionToNewLocation(m.sum(this.startLoc, t)), i = this.allConnectionPairs;
          if (e === lt.NONE || !i.length) return this.connectionCandidate;
          e = e === lt.RIGHT || e === lt.DOWN;
          var o = i.findIndex((n) => {
            var l, a;
            return ((l = this.connectionCandidate) == null ? void 0 : l.local) === n.local && ((a = this.connectionCandidate) == null ? void 0 : a.neighbour) === n.neighbour;
          }), s = this.block.workspace.getNavigator();
          return e ? o === -1 ? this.isInTerminalPosition(this.block, lt.DOWN) ? s.getNavigationLoops() ? this.pairToCandidate(i[0]) : null : this.getClosestCandidate(this.block, t) : o === i.length - 1 ? null : this.pairToCandidate(i[o + 1]) : o === -1 ? this.isInTerminalPosition(this.block, lt.UP) ? s.getNavigationLoops() ? this.pairToCandidate(i[i.length - 1]) : null : this.getClosestCandidate(this.block, t) : o === 0 ? null : this.pairToCandidate(i[o - 1]);
        }
        isInTerminalPosition(t, e) {
          if (t.getParent()) return !1;
          var i = t.workspace.getTopBlocks(!0), o = t.getBoundingRectangle(), s = (e = e === lt.UP) ? "top" : "bottom", n = e ? (l, a) => l <= a : (l, a) => l >= a;
          e = i.filter((l) => l.id !== t.id && n(l.getBoundingRectangle()[s], o[s])), i = t.getConnections_(!1);
          for (let l of e) {
            e = this.getAllConnections(l);
            for (let a of i) for (let c of e) if (t.workspace.connectionChecker.canConnect(
              a,
              c,
              !0,
              1 / 0
            )) return !1;
          }
          return !0;
        }
        pairToCandidate(t) {
          return Object.assign({}, t, { distance: 0 });
        }
        getDirectionToNewLocation(t) {
          var e = this.block.getRelativeToSurfaceXY();
          t = m.difference(t, e);
          var { x: i, y: o } = t;
          return Math.abs(i) > Math.abs(o) ? i < 0 ? lt.LEFT : lt.RIGHT : Math.abs(o) > 0 ? o < 0 ? lt.UP : lt.DOWN : lt.NONE;
        }
        getAllConnections(t) {
          if (t.isShadow()) return [];
          var e = [];
          if (t.outputConnection && e.push(t.outputConnection), t.previousConnection && e.push(t.previousConnection), !t.isCollapsed()) {
            for (let i of t.inputList) if (i.connection && i.isVisible()) {
              e.push(i.connection);
              let o = i.connection.targetBlock();
              o && e.push(...this.getAllConnections(o));
            }
          }
          return t.nextConnection && (e.push(t.nextConnection), (t = t.nextConnection.targetBlock()) && e.push(...this.getAllConnections(t))), e;
        }
        getInitialCandidate() {
          var t = this.workspace.getSvgGroup().querySelector(`.${Ht.PASSIVE_FOCUS_NODE_CSS_CLASS_NAME}`);
          if (!t || !t.id || t === this.block.getFocusableElement() || (t = this.workspace.lookUpFocusableNode(t.id), !t)) return null;
          var e = this.workspace.getNavigator().getSourceBlockFromNode(t);
          if (!e) return null;
          var i = null;
          if (e.getConnections_(!1).includes(t)) {
            i = t;
            let l = this.block.workspace.connectionChecker;
            if (t = this.block.getConnections_(!1).find((a) => l.canConnect(a, i, !0, 1 / 0))) return { local: t, neighbour: i, distance: 0 };
          }
          if (t = this.allConnectionPairs.find((l) => l.neighbour.getSourceBlock() === e)) return this.pairToCandidate(t);
          var o, s = (o = e.outputConnection) == null ? void 0 : o.targetConnection;
          if (o = this.allConnectionPairs.find((l) => l.neighbour === s)) return this.pairToCandidate(o);
          for (var n = e.getSurroundParent(); n; ) {
            if (o = this.allConnectionPairs.find((l) => l.neighbour.getSourceBlock() === n)) return this.pairToCandidate(o);
            n = n.getSurroundParent();
          }
          return null;
        }
        updateMoveMode(t) {
          this.moveMode = t instanceof KeyboardEvent && !t.ctrlKey && !t.metaKey ? le.CONSTRAINED : le.UNCONSTRAINED;
        }
        enableAllDraggedBlocks(t) {
          var e = r.Qc;
          r.Qc = !1, this.lastBlockDisabledReasons.clear(), t.getDescendants(!1).forEach((i) => {
            var o = new Set(i.getDisabledReasons());
            this.lastBlockDisabledReasons.set(i.id, o), o.forEach((s) => i.setDisabledReason(!1, s));
          }), r.Qc = e;
        }
        redisableAllDraggedBlocks(t) {
          var e = r.Qc;
          r.Qc = !1, t.getDescendants(!1).forEach((i) => {
            var o;
            (o = this.lastBlockDisabledReasons.get(i.id)) == null || o.forEach((s) => {
              i.setDisabledReason(!0, s);
            });
          }), r.Qc = e;
        }
      }, go = class extends Z {
        isLabelField() {
          return !0;
        }
        constructor(t, e, i) {
          super(Z.SKIP_SETUP), this.class = null, this.EDITABLE = !1, this.maxDisplayLength = 1 / 0, t !== Z.SKIP_SETUP && (i ? this.configure_(i) : this.class = e || null, this.setValue(t));
        }
        configure_(t) {
          super.configure_(t), t.class && (this.class = t.class);
        }
        initView() {
          this.createTextElement_(), this.class && b(this.getTextElement(), this.class), this.fieldGroup_ && (b(this.fieldGroup_, "blocklyLabelField"), w(this.fieldGroup_, y.HIDDEN, !0));
        }
        computeAriaLabel(t = !0) {
          t = t ? this.getAriaTypeName() : null;
          var e, i = (e = this.getAriaValue()) != null ? e : "";
          return t ? `${t}: ${i}` : i;
        }
        doClassValidation_(t) {
          return t == null ? null : `${t}`;
        }
        setClass(t) {
          this.textElement_ && (this.class && Y(this.textElement_, this.class), t && b(this.textElement_, t)), this.class = t;
        }
        static fromJson(t) {
          return new this(et(t.text), void 0, t);
        }
      };
      xe("field_label", go), go.prototype.DEFAULT_VALUE = "";
      var Qg = class extends j {
        constructor(t, e, i, o, s) {
          super(e, i, o, void 0, s), this.text = t, this.workspace = e, this.anchor = i, this.ownerRect = o, this.owner = s, this.paragraph = this.stringToSvg(t, this.contentContainer), this.updateBubbleSize(), b(this.svgRoot, "blocklyTextBubble");
        }
        getText() {
          return this.text;
        }
        setText(t) {
          this.text = t, Q(this.paragraph), this.paragraph = this.stringToSvg(t, this.contentContainer), this.updateBubbleSize();
        }
        stringToSvg(t, e) {
          return e = this.createParagraph(e), t = this.createTextFragments(e, t), this.workspace.RTL && this.rightAlignTextFragments(e.getBBox().width, t), e;
        }
        createParagraph(t) {
          return v(g.G, { class: "blocklyText blocklyBubbleText blocklyNoPointerEvents", transform: `translate(0,${j.BORDER_WIDTH})`, style: `direction: ${this.workspace.RTL ? "rtl" : "ltr"}` }, t);
        }
        createTextFragments(t, e) {
          var i = 1;
          return e.split(`
`).map((o) => {
            var s = v(g.TEXT, { y: `${i}em`, x: j.BORDER_WIDTH }, t);
            return o = document.createTextNode(o), s.appendChild(o), i += 1, s;
          });
        }
        rightAlignTextFragments(t, e) {
          for (let i of e) i.setAttribute(
            "text-anchor",
            "start"
          ), i.setAttribute("x", `${t + j.BORDER_WIDTH}`);
        }
        updateBubbleSize() {
          var t = this.paragraph.getBBox();
          this.setSize(new H(t.width + j.BORDER_WIDTH * 2, t.height + j.BORDER_WIDTH * 2), !0);
        }
      }, Ve = class extends qo {
        constructor(t) {
          super(t), this.sourceBlock = t, this.textMap = /* @__PURE__ */ new Map(), this.textBubble = null;
        }
        getType() {
          return Ve.TYPE;
        }
        initView(t) {
          this.svgRoot || (super.initView(t), v(g.PATH, { class: "blocklyIconShape", d: "M2,15Q-1,15 0.5,12L6.5,1.7Q8,-1 9.5,1.7L15.5,12Q17,15 14,15z" }, this.svgRoot), v(g.PATH, { class: "blocklyIconSymbol", d: "m7,4.8v3.16l0.27,2.27h1.46l0.27,-2.27v-3.16z" }, this.svgRoot), v(g.RECT, { class: "blocklyIconSymbol", x: "7", y: "11", height: "2", width: "2" }, this.svgRoot), b(this.svgRoot, "blocklyWarningIcon"));
        }
        dispose() {
          super.dispose();
          var t;
          (t = this.textBubble) == null || t.dispose();
        }
        getWeight() {
          return Ve.WEIGHT;
        }
        getSize() {
          return new H(17, 17);
        }
        applyColour() {
          super.applyColour();
          var t;
          (t = this.textBubble) == null || t.setColour(this.sourceBlock.getColour());
        }
        updateCollapsed() {
        }
        isShownWhenCollapsed() {
          return !0;
        }
        onLocationChange(t) {
          super.onLocationChange(t);
          var e;
          (e = this.textBubble) == null || e.setAnchorLocation(this.getAnchorLocation());
        }
        addMessage(t, e) {
          if (this.textMap.get(e) === t) return this;
          t ? this.textMap.set(e, t) : this.textMap.delete(e);
          var i;
          return (i = this.textBubble) == null || i.setText(this.getText()), this;
        }
        getText() {
          return [...this.textMap.values()].join(`
`);
        }
        onClick() {
          super.onClick(), this.setBubbleVisible(!this.bubbleIsVisible());
        }
        isClickableInFlyout() {
          return !1;
        }
        bubbleIsVisible() {
          return !!this.textBubble;
        }
        setBubbleVisible(t) {
          var e = this;
          return (0, d.asyncExecutePromiseGeneratorFunction)(function* () {
            if (e.bubbleIsVisible() !== t) {
              if (yield te(), t) e.textBubble = new Qg(e.getText(), e.sourceBlock.workspace, e.getAnchorLocation(), e.getBubbleOwnerRect(), e), e.applyColour(), e.textBubble.setAriaLabelProvider(() => r.C.BUBBLE_LABEL_WARNING.replace("%1", e.getText()));
              else {
                let i;
                (i = e.textBubble) == null || i.dispose(), e.textBubble = null;
              }
              N(new (D(p.BUBBLE_OPEN))(e.sourceBlock, t, "warning")), e.recomputeAriaContext();
            }
          });
        }
        getBubble() {
          return this.textBubble;
        }
        getAnchorLocation() {
          return m.sum(this.workspaceLocation, new m(8.5, 8.5));
        }
        getBubbleOwnerRect() {
          var t = this.sourceBlock.getSvgRoot().getBBox();
          return new F(t.y, t.y + t.height, t.x, t.x + t.width);
        }
        getAriaLabel() {
          return this.bubbleIsVisible() ? r.C.ICON_LABEL_WARNING_OPEN : r.C.ICON_LABEL_WARNING_CLOSED;
        }
      };
      Ve.TYPE = Ct.WARNING, Ve.WEIGHT = 2;
      var ut = class extends is {
        constructor(t, e, i) {
          if (super(t, e, i), this.childlessWidth = this.width = this.height = 0, this.warningTextDb = /* @__PURE__ */ new Map(), this.mutator = null, this.rendered = !0, this.visuallyDisabled = !1, this.previousConnection = this.nextConnection = this.outputConnection = null, this.translation = "", this.dragging = !1, this.relativeCoords = new m(0, 0), this.dragStrategy = new Zg(this), !t.rendered) throw TypeError("Cannot create a rendered block in a headless workspace");
          this.workspace = t, this.svgGroup = v(g.G, {}), e && b(
            this.svgGroup,
            e
          ), this.style = t.getRenderer().getConstants().getBlockStyle(null), this.pathObject = t.getRenderer().makePathObject(this.svgGroup, this.style), t = this.pathObject.svgPath, t.tooltip = this, Is(t), this.svgGroup.setAttribute("data-id", this.id), t.id = It(), this.doInit_();
        }
        initSvg() {
          if (!this.initialized) {
            for (var t of this.inputList) t.init();
            for (let e of this.getIcons()) e.initView(this.createIconPointerDownListener(e)), e.updateEditable();
            this.applyColour(), this.pathObject.updateMovable(this.isMovable() || this.isInFlyout), (t = this.getSvgRoot()) && M(t, "pointerdown", this, this.onMouseDown), t.parentNode || this.workspace.getCanvas().appendChild(t), this.recomputeAriaContext(), this.initialized = !0;
          }
        }
        getColourSecondary() {
          return this.style.colourSecondary;
        }
        getColourTertiary() {
          return this.style.colourTertiary;
        }
        select() {
          this.addSelect(), ci(this);
        }
        unselect() {
          this.removeSelect(), ci(null);
        }
        setParent(t) {
          var e = this.parentBlock_;
          if (t !== e) {
            Li(), super.setParent(t), xi();
            var i = this.getSvgRoot();
            if (!this.workspace.isClearing && i) {
              var o = r.t().getFocusedNode(), s, n = this.getSvgRoot().contains((s = o?.getFocusableElement()) != null ? s : null);
              t ? (t.getSvgRoot().appendChild(i), n && o && r.t().focusNode(o)) : e && (t = this.getRelativeToSurfaceXY(), this.workspace.getCanvas().appendChild(i), this.translate(t.x, t.y)), n && o && r.t().focusNode(o), this.applyColour(), this.recomputeAriaContext();
            }
          }
        }
        moveBy(t, e, i) {
          if (this.parentBlock_) throw Error("Block has parent");
          var o = ht(), s = null;
          o && (s = new (D(p.BLOCK_MOVE))(this), i && s.setReason(i)), t = new m(t, e), e = this.getRelativeToSurfaceXY(), t = m.sum(e, t), this.translate(t.x, t.y), this.workspace.connectionDBList.forEach((n) => n?.beginBulkUpdates()), this.updateComponentLocations(t), this.workspace.connectionDBList.forEach((n) => n?.endBulkUpdates()), o && s && (s.recordNew(), N(s)), this.workspace.resizeContents();
        }
        translate(t, e) {
          this.translation = `translate(${t}, ${e})`, this.relativeCoords = new m(t, e), this.getSvgRoot().setAttribute("transform", this.getTranslation());
        }
        getTranslation() {
          return this.translation;
        }
        moveTo(t, e) {
          var i = this.getRelativeToSurfaceXY();
          this.moveBy(t.x - i.x, t.y - i.y, e);
        }
        moveDuringDrag(t) {
          this.translate(t.x, t.y), this.updateComponentLocations(t);
        }
        snapToGrid() {
          if (!this.isDeadOrDying() && !this.getParent() && !this.isInFlyout) {
            var t = this.workspace.getGrid();
            if (t != null && t.shouldSnap()) {
              var e = this.getRelativeToSurfaceXY();
              t = t.alignXY(e), t !== e && this.moveTo(t, ["snap"]);
            }
          }
        }
        getBoundingRectangle() {
          return this.getBoundingRectangleWithDimensions(this.getHeightWidth());
        }
        getBoundingRectangleWithoutChildren() {
          return this.getBoundingRectangleWithDimensions({
            height: this.height,
            width: this.childlessWidth
          });
        }
        getBoundingRectangleWithDimensions(t) {
          var e = this.getRelativeToSurfaceXY();
          if (this.RTL)
            var i = e.x - t.width, o = e.x;
          else i = e.x, o = e.x + t.width;
          return new F(e.y, e.y + t.height, i, o);
        }
        markDirty() {
          this.pathObject.constants = this.workspace.getRenderer().getConstants();
          for (let t = 0, e; e = this.inputList[t]; t++) e.markDirty();
        }
        setCollapsed(t) {
          this.collapsed_ !== t && (super.setCollapsed(t), this.updateCollapsed());
        }
        childHasWarning() {
          var t = this.getNextBlock();
          t = t ? new Set(t.getDescendants(!1)) : null;
          var e = this.getDescendants(!1);
          for (let i of e) if (i !== this && (t == null || !t.has(i)) && i.getIcon(Ve.TYPE)) return !0;
          return !1;
        }
        updateCollapsed() {
          var t = this.isCollapsed();
          for (let i = 0, o; o = this.inputList[i]; i++) o.name !== "_TEMP_COLLAPSED_INPUT" && o.setVisible(!t);
          for (var e of this.getIcons()) e.updateCollapsed();
          t ? (b(this.svgGroup, "blocklyCollapsed"), this.childHasWarning() && this.setWarningText(r.C.COLLAPSED_WARNINGS_WARNING, ut.COLLAPSED_WARNING_ID), t = this.toString(30), (e = this.getField("_TEMP_COLLAPSED_FIELD")) ? e.setValue(t) : ((this.getInput("_TEMP_COLLAPSED_INPUT") || this.appendDummyInput("_TEMP_COLLAPSED_INPUT")).appendField(new go(t), "_TEMP_COLLAPSED_FIELD"), this.recomputeAriaContext())) : (this.updateDisabled(), this.removeInput("_TEMP_COLLAPSED_INPUT"), Y(this.svgGroup, "blocklyCollapsed"), this.setWarningText(null, ut.COLLAPSED_WARNING_ID));
        }
        onMouseDown(t) {
          if (!this.workspace.isReadOnly()) {
            var e = this.workspace.getGesture(t);
            e && e.handleBlockStart(t, this);
          }
        }
        showHelp() {
          var t = typeof this.helpUrl == "function" ? this.helpUrl() : this.helpUrl;
          t && window.open(t);
        }
        generateContextMenu(t) {
          return this.workspace.isReadOnly() || !this.contextMenu ? null : (t = V.registry.getContextMenuOptions({ block: this, focusedNode: this }, t), this.customContextMenu && this.customContextMenu(t), t);
        }
        calculateContextMenuLocation(t) {
          if (t instanceof PointerEvent) return new m(t.clientX, t.clientY);
          t = pi(this.workspace, this.getRelativeToSurfaceXY());
          var e, i, o = (e = this.inputList.filter((s) => s.isVisible()).flatMap((s) => s.fieldRow).find((s) => s.isVisible())) == null || (i = e.getSvgRoot()) == null ? void 0 : i.getBoundingClientRect();
          return new m(this.RTL ? t.x - 5 : t.x + 5, (o && o.height ? o.y + o.height : t.y + this.height) + 5);
        }
        showContextMenu(t) {
          if (this.isShadow()) {
            for (var e = this.getParent(); e && e.isShadow(); ) e = e.getParent();
            e && (r.t().focusNode(e), e.showContextMenu(t));
          } else {
            e = this.generateContextMenu(t);
            var i = this.calculateContextMenuLocation(t);
            e && e.length && (Lo(t, e, this.RTL, this.workspace, i), Ys = this);
          }
        }
        updateComponentLocations(t) {
          this.xy.x = t.x, this.xy.y = t.y, this.dragging || this.updateConnectionLocations(t), this.updateIconLocations(t), this.updateFieldLocations(t);
          for (let e of this.getChildren(!1)) e.updateComponentLocations(m.sum(t, e.relativeCoords));
        }
        updateConnectionLocations(t) {
          for (let e of this.getConnections_(!1)) e.moveToOffset(t);
        }
        updateIconLocations(t) {
          for (let e of this.getIcons()) e.onLocationChange(t);
        }
        updateFieldLocations(t) {
          for (let e of this.inputList) for (let i of e.fieldRow) i.onLocationChange(t);
        }
        addClass(t) {
          b(this.svgGroup, t);
        }
        removeClass(t) {
          Y(this.svgGroup, t);
        }
        setDragging(t) {
          (this.dragging = t) ? (this.translation = "", Ws.push(...this.getConnections_(!0)), this.addClass("blocklyDragging")) : (Ws.length = 0, this.removeClass("blocklyDragging"), this.getFullBlockField() && this.recomputeAriaContext());
          for (let e = 0; e < this.childBlocks_.length; e++) this.childBlocks_[e].setDragging(t);
        }
        isDragging() {
          return this.dragging;
        }
        setMovable(t) {
          super.setMovable(t), this.pathObject.updateMovable(t);
        }
        setEditable(t) {
          super.setEditable(t), t ? Y(this.svgGroup, "blocklyNotEditable") : b(this.svgGroup, "blocklyNotEditable"), t = this.getIcons();
          for (let e = 0; e < t.length; e++) t[e].updateEditable();
        }
        setShadow(t) {
          super.setShadow(t), this.applyColour(), this.recomputeAriaContext();
        }
        setInsertionMarker(t) {
          this.isInsertionMarker_ !== t && (this.isInsertionMarker_ = t) && (this.setColour(this.workspace.getRenderer().getConstants().INSERTION_MARKER_COLOUR), this.pathObject.updateInsertionMarker(!0));
        }
        getSvgRoot() {
          return this.svgGroup;
        }
        getNearestNeighbour() {
          if (!this.workspace.rendered) return null;
          var t = this.workspace.getAllBlocks(!1).filter((s) => !s.isDeadOrDying()), e = null, i = Number.MAX_SAFE_INTEGER, o = this.getRelativeToSurfaceXY();
          for (let s of t) t = s.getRelativeToSurfaceXY(), t = Math.sqrt(Math.pow(t.x - o.x, 2) + Math.pow(t.y - o.y, 2)), t < i && (e = s, i = t);
          return e;
        }
        dispose(t, e) {
          this.disposing = !0, Ss(this.pathObject.svgPath), delete this.pathObject.svgPath.tooltip, Ea(), Ns(), e && (this.unplug(t), ir(this));
          var i = r.t();
          try {
            let s, n;
            var o = (n = (s = i.getFocusedNode()) == null ? void 0 : s.getFocusableElement()) != null ? n : null;
          } catch {
            o = null;
          }
          if (super.dispose(!!t), Q(this.svgGroup), this.getSvgRoot().contains(o)) {
            let s = this.getParent();
            if (!s) {
              let n;
              if (t = (n = this.outputConnection) != null ? n : this.previousConnection) {
                let l;
                s = (l = t.closest(0, new m(0, 0)).connection) == null ? void 0 : l.getSourceBlock();
              }
            }
            setTimeout(() => {
              if (this.workspace.rendered) if (s) i.focusNode(s);
              else {
                let n = this.getNearestNeighbour();
                n ? i.focusNode(n) : i.focusTree(this.workspace);
              }
            }, 0);
          }
        }
        disposeInternal() {
          this.disposing = !0, super.disposeInternal(), r.t().getFocusedNode() === this && this.workspace.cancelCurrentGesture(), [...this.warningTextDb.values()].forEach((t) => clearTimeout(t)), this.warningTextDb.clear(), this.getIcons().forEach((t) => t.dispose());
        }
        checkAndDelete() {
          this.workspace.isFlyout || (r.B(!0), this.workspace.hideChaff(), this.outputConnection ? this.dispose(!1, !0) : this.dispose(!0, !0), r.B(!1));
        }
        toCopyData(t = !1) {
          return this.isInsertionMarker_ ? null : { paster: Zs.TYPE, blockState: ee(this, { addCoordinates: !0, addNextBlocks: t, saveIds: !1 }), typeCounts: Es(this, !0) };
        }
        applyColour() {
          var t, e;
          for ((e = (t = this.pathObject).applyColour) == null || e.call(t, this), t = this.getIcons(), e = 0; e < t.length; e++) t[e].applyColour();
          for (let i of this.getFields()) i.applyColour();
        }
        updateDisabled() {
          var t = !this.isEnabled() || this.getInheritedDisabled();
          if (this.visuallyDisabled === t) {
            let e;
            (e = this.getNextBlock()) == null || e.updateDisabled();
          } else {
            this.applyColour(), this.visuallyDisabled = t;
            for (let e of this.getChildren(!1)) e.updateDisabled();
            this.recomputeAriaContext();
          }
        }
        setWarningText(t, e = "") {
          if (e) this.warningTextDb.has(e) && (clearTimeout(this.warningTextDb.get(e)), this.warningTextDb.delete(e));
          else {
            for (var i of this.warningTextDb.values()) clearTimeout(i);
            this.warningTextDb.clear();
          }
          if (this.workspace.isDragging()) this.warningTextDb.set(e, setTimeout(() => {
            this.isDeadOrDying() || (this.warningTextDb.delete(e), this.setWarningText(t, e));
          }, 100));
          else if (this.isInFlyout && (t = null), i = this.getIcon(Ve.TYPE), t) {
            let o = this.getSurroundParent(), s = null;
            for (; o; ) o.isCollapsed() && (s = o), o = o.getSurroundParent();
            s && s.setWarningText(r.C.COLLAPSED_WARNINGS_WARNING, ut.COLLAPSED_WARNING_ID), i ? i.addMessage(t, e) : this.addIcon(new Ve(this).addMessage(t, e));
          } else i && (e ? (i.addMessage(
            "",
            e
          ), i.getText() || this.removeIcon(Ve.TYPE)) : this.removeIcon(Ve.TYPE));
        }
        setMutator(t) {
          this.removeIcon(r.sh.TYPE), t && this.addIcon(t);
        }
        addIcon(t) {
          return super.addIcon(t), t instanceof r.sh && (this.mutator = t), t.initView(this.createIconPointerDownListener(t)), t.applyColour(), t.updateEditable(), this.queueRender(), t;
        }
        createIconPointerDownListener(t) {
          return (e) => {
            !this.isDeadOrDying() && (e = this.workspace.getGesture(e)) && (this.bringToFront(), e.setStartIcon(t), r.t().focusNode(t));
          };
        }
        removeIcon(t) {
          var e = super.removeIcon(t);
          return t.equals(r.sh.TYPE) && (this.mutator = null), this.queueRender(), e;
        }
        setDisabledReason(t, e) {
          var i = this.isEnabled();
          super.setDisabledReason(t, e), this.isEnabled() === i || this.getInheritedDisabled() || this.updateDisabled();
        }
        setDeletable(t) {
          super.setDeletable(t), t ? Y(this.svgGroup, "blocklyNotDeletable") : b(this.svgGroup, "blocklyNotDeletable");
        }
        setHighlighted(t) {
          this.pathObject.updateHighlighted(t);
        }
        addSelect() {
          this.pathObject.updateSelected(!0);
        }
        removeSelect() {
          this.pathObject.updateSelected(!1);
        }
        setDeleteStyle(t) {
          this.pathObject.updateDraggingDelete(t);
        }
        getColour() {
          return this.style.colourPrimary;
        }
        setColour(t) {
          super.setColour(t), t = this.workspace.getRenderer().getConstants().getBlockStyleForColour(this.colour_);
          var e, i;
          (i = (e = this.pathObject).setStyle) == null || i.call(e, t.style), this.style = t.style, this.styleName_ = t.name, this.applyColour();
        }
        setStyle(t) {
          var e = this.workspace.getRenderer().getConstants().getBlockStyle(t);
          if (this.styleName_ && Y(this.svgGroup, this.styleName_), e) {
            this.hat = e.hat;
            let i, o;
            (o = (i = this.pathObject).setStyle) == null || o.call(i, e), this.colour_ = e.colourPrimary, this.style = e, this.applyColour(), b(this.svgGroup, t), this.styleName_ = t;
          } else throw Error("Invalid style name: " + t);
        }
        getStyle() {
          return this.style;
        }
        bringToFront(t = !1) {
          var e = r.t().getFocusedNode();
          this.moveSvgRootToFront(t), e && r.t().focusNode(e);
        }
        moveSvgRootToFront(t = !1) {
          this.isDeadOrDying() || requestAnimationFrame(() => {
            if (!this.dragging) {
              var e = this;
              do {
                if (e.isDeadOrDying()) break;
                let i = e.getSvgRoot(), o = i.parentNode;
                if (!o) break;
                let s = o.childNodes;
                if (s[s.length - 1] !== i) for (; i.nextSibling; ) o.insertBefore(i.nextSibling, i);
                if (t) break;
                e = e.getParent();
              } while (e);
            }
          });
        }
        setPreviousStatement(t, e) {
          super.setPreviousStatement(t, e), this.queueRender();
        }
        setNextStatement(t, e) {
          super.setNextStatement(t, e), this.queueRender();
        }
        setOutput(t, e) {
          super.setOutput(t, e), this.queueRender();
        }
        setInputsInline(t) {
          super.setInputsInline(t), this.queueRender();
        }
        removeInput(t, e) {
          return t = super.removeInput(t, e), this.queueRender(), t;
        }
        moveNumberedInputBefore(t, e) {
          super.moveNumberedInputBefore(t, e), this.queueRender();
        }
        appendInput(t) {
          return super.appendInput(t), this.queueRender(), t;
        }
        setConnectionTracking(t) {
          if (this.previousConnection && this.previousConnection.setTracking(t), this.outputConnection && this.outputConnection.setTracking(t), this.nextConnection) {
            this.nextConnection.setTracking(t);
            var e = this.nextConnection.targetBlock();
            e && e.setConnectionTracking(t);
          }
          if (!this.collapsed_) for (e = 0; e < this.inputList.length; e++) {
            var i = this.inputList[e].connection;
            i && (i.setTracking(t), (i = i.targetBlock()) && i.setConnectionTracking(t));
          }
        }
        getConnections_(t) {
          var e = [];
          if (this.outputConnection && e.push(this.outputConnection), this.previousConnection && e.push(this.previousConnection), this.nextConnection && e.push(this.nextConnection), t || !this.collapsed_) for (let i = 0, o; o = this.inputList[i]; i++) o.connection && e.push(o.connection);
          return e;
        }
        lastConnectionInStack(t) {
          return super.lastConnectionInStack(t);
        }
        getMatchingConnection(t, e) {
          return super.getMatchingConnection(t, e);
        }
        makeConnection_(t) {
          return new Dt(this, t);
        }
        getNextBlock() {
          return super.getNextBlock();
        }
        getPreviousBlock() {
          return super.getPreviousBlock();
        }
        bumpNeighbours() {
          var t = this.getRootBlock();
          if (!(this.isDeadOrDying() || this.workspace.isDragging() || this.isDragging() || t.isInFlyout)) for (let e of this.getConnections_(!1)) {
            if (e.isSuperior()) {
              let i;
              (i = e.targetBlock()) == null || i.bumpNeighbours();
            }
            for (let i of e.neighbours(r.Og.snapRadius)) i.getSourceBlock().getRootBlock() !== t && (e.isConnected() && i.isConnected() || (e.isSuperior() ? i.bumpAwayFrom(e, !1) : i.getSourceBlock().isDragging() || e.bumpAwayFrom(i, !0)));
          }
        }
        scheduleSnapAndBump() {
          this.snapToGrid(), this.bumpNeighbours();
        }
        positionNearConnection(t, e, i) {
          if (t.type === T.NEXT_STATEMENT || t.type === T.INPUT_VALUE) {
            let o = e.x;
            e = e.y, o += i.x - t.getOffsetInBlock().x, e += i.y - t.getOffsetInBlock().y, this.moveBy(o, e);
          }
        }
        getChildren(t) {
          return super.getChildren(t);
        }
        queueRender() {
          return Ol(this);
        }
        render() {
          this.queueRender(), Ne();
        }
        renderEfficiently() {
          Li(), this.isCollapsed() && this.updateCollapsed(), this.isEnabled() || this.updateDisabled(), this.workspace.getRenderer().render(this), this.tightenChildrenEfficiently(), xi();
        }
        tightenChildrenEfficiently() {
          for (let t of this.inputList) {
            let e = t.connection;
            e && e.tightenEfficiently();
          }
          this.nextConnection && this.nextConnection.tightenEfficiently();
        }
        getHeightWidth() {
          var t = this.height, e = this.width, i = this.getNextBlock();
          if (i) {
            i = i.getHeightWidth();
            let o = this.workspace.getRenderer().getConstants().NOTCH_HEIGHT;
            t += i.height - o, e = Math.max(e, i.width);
          }
          return { height: t, width: e };
        }
        fadeForReplacement(t) {
          var e, i;
          (i = (e = this.pathObject).updateReplacing) == null || i.call(e, t);
        }
        getDragStrategy() {
          return this.dragStrategy;
        }
        setDragStrategy(t) {
          this.dragStrategy = t;
        }
        isCopyable() {
          return this.isOwnDeletable() && this.isOwnMovable();
        }
        isMovable() {
          return this.dragStrategy.isMovable();
        }
        startDrag(t) {
          return this.dragStrategy.startDrag(t);
        }
        drag(t, e) {
          this.dragStrategy.drag(t, e);
        }
        endDrag(t, e) {
          this.dragStrategy.endDrag(t, e);
        }
        revertDrag() {
          this.dragStrategy.revertDrag();
        }
        toFlyoutInfo() {
          function t(o) {
            for (let s in o) i.has(s) ? delete o[s] : typeof o[s] == "object" && t(o[s]);
          }
          var e = Object.assign({}, { kind: "BLOCK" }, ee(this)), i = /* @__PURE__ */ new Set(["id", "height", "width", "pinned", "enabled"]);
          return t(e), [e];
        }
        jsonInit(t) {
          super.jsonInit(t), t.classes && this.addClass(Array.isArray(t.classes) ? t.classes.join(" ") : t.classes);
        }
        getNestingLevel() {
          var t = this.getSurroundParent();
          return t ? t.getNestingLevel() + 1 : 0;
        }
        getFocusableElement() {
          var t = this.getFullBlockField();
          return t ? t.getFocusableElement() : this.pathObject.svgPath;
        }
        getFocusableTree() {
          return this.workspace;
        }
        onNodeFocus() {
          this.recomputeAriaContext(), this.select(), this.workspace.isFlyout || this.moveSvgRootToFront();
          var t = r.t().getFocusedNode();
          t && t !== this && te().then(() => {
            this.workspace.scrollBoundsIntoView(this.getBoundingRectangleWithoutChildren());
          });
        }
        onNodeBlur() {
          this.unselect();
        }
        canBeFocused() {
          return !0;
        }
        performAction(t) {
          if (this.workspace.isFlyout) J.mover.startMove(
            this,
            t
          );
          else {
            if (this.isSimpleReporter()) {
              for (var e of this.inputList) for (let i of e.fieldRow) if (i.isClickable() && i.isFullBlockField()) {
                i.showEditor();
                return;
              }
            }
            this.workspace.getNavigator().getInNode(this) ? (t = this.workspace, e = $e(t.RTL ? B.NAVIGATE_LEFT : B.NAVIGATE_RIGHT), e = r.C.KEYBOARD_NAV_BLOCK_NAVIGATION_HINT.replace("%1", e), Xt.show(t, { message: e, id: "blockNavigationHint" })) : (t = this.workspace, (e = $e("list_shortcuts")) && (e = r.C.HELP_PROMPT.replace("%1", e), Xt.show(t, { message: e, id: "helpHint" })));
          }
        }
        getParents() {
          for (var t = /* @__PURE__ */ new Set(), e = this.getParent(); e; ) t.add(e), e = e.getParent();
          return t;
        }
        getOutputParents() {
          var t = /* @__PURE__ */ new Set();
          t.add(this);
          for (var e, i = (e = this.outputConnection) == null ? void 0 : e.targetBlock(); i; ) {
            t.add(i);
            let o;
            i = (o = i.outputConnection) == null ? void 0 : o.targetBlock();
          }
          return t;
        }
        getRowId() {
          var t, e, i = (t = this.outputConnection) == null || (e = t.targetConnection) == null ? void 0 : e.getParentInput();
          return i ? i.getRowId() : this.id;
        }
        recomputeAriaContext() {
          var t = this.getFullBlockField();
          t ? t.recomputeAriaContext() : (t = this.getAriaLabel(ot.STANDARD), !t || Ho || t.endsWith(",") || (t += ","), w(this.getFocusableElement(), y.LABEL, t), G(this.getSvgRoot(), W.NONE), t = this.getFocusableElement(), this.isInFlyout || G(t, W.FIGURE), w(t, y.ROLEDESCRIPTION, this.getAriaRoleDescription()));
        }
        getAriaLabel(t) {
          return Je(this, t);
        }
        getStackBlocksCountLabel() {
          for (var t = 1, e = this.getNextBlock(); e; ) t++, e = e.getNextBlock();
          return t <= 1 ? Je(this, ot.TERSE) : r.C.BLOCK_LABEL_STACK_BLOCKS.replace("%1", t.toString());
        }
      };
      ut.INLINE = -1, ut.COLLAPSED_WARNING_ID = "TEMP_COLLAPSED_WARNING_";
      var tp = class {
        constructor() {
        }
        onDragEnter() {
        }
        onDragOver() {
        }
        onDragExit() {
        }
        onDrop() {
        }
        getClientRect() {
          return null;
        }
        shouldPreventMove() {
          return !1;
        }
      }, jr = class extends tp {
        constructor() {
          super(), this.wouldDelete_ = !1;
        }
        wouldDelete(t) {
          return J.mover.isMoving() ? this.updateWouldDelete_(!1) : t instanceof ut ? (t = !t.getParent() && t.isDeletable(), this.updateWouldDelete_(t)) : this.updateWouldDelete_(ie(t) && t.isDeletable()), this.wouldDelete_;
        }
        updateWouldDelete_(t) {
          this.wouldDelete_ = t;
        }
      }, ss = class {
        constructor(t, e) {
          this.element = t, this.type = e;
        }
        getElement() {
          return this.element;
        }
        getType() {
          return this.type;
        }
      }, hu = class {
        constructor(t) {
          this.workspace_ = t;
        }
        getDimensionsPx_(t) {
          var e = 0, i = 0;
          return t && (e = t.getWidth(), i = t.getHeight()), new H(e, i);
        }
        getFlyoutMetrics(t) {
          return t = this.getDimensionsPx_(this.workspace_.getFlyout(t)), { width: t.width, height: t.height, position: this.workspace_.toolboxPosition };
        }
        getToolboxMetrics() {
          var t = this.getDimensionsPx_(this.workspace_.getToolbox());
          return { width: t.width, height: t.height, position: this.workspace_.toolboxPosition };
        }
        getSvgMetrics() {
          return this.workspace_.getCachedParentSvgSize();
        }
        getAbsoluteMetrics() {
          var t = 0, e = 0, i = this.getToolboxMetrics(), o = this.getFlyoutMetrics(), s = !!this.workspace_.getToolbox(), n, l = !((n = this.workspace_.getFlyout()) != null && n.autoClose);
          n = s ? i.position : o.position;
          var a = n === I.TOP;
          return n === I.LEFT && (s && (t += i.width), l && (t += o.width)), a && (s && (e += i.height), l && (e += o.height)), { top: e, left: t };
        }
        getViewMetrics(t) {
          t = t ? this.workspace_.scale : 1;
          var e = this.getSvgMetrics(), i = this.getToolboxMetrics(), o = this.getFlyoutMetrics(), s = !!this.workspace_.getToolbox(), n, l = !((n = this.workspace_.getFlyout()) != null && n.autoClose);
          n = s ? i.position : o.position;
          var a = n === I.LEFT || n === I.RIGHT;
          return (n === I.TOP || n === I.BOTTOM) && (s && (e.height -= i.height), l && (e.height -= o.height)), a && (s && (e.width -= i.width), l && (e.width -= o.width)), { height: e.height / t, width: e.width / t, top: -this.workspace_.scrollY / t, left: -this.workspace_.scrollX / t };
        }
        getContentMetrics(t) {
          t = t ? 1 : this.workspace_.scale;
          var e = this.workspace_.getBlocksBoundingBox();
          return { height: (e.bottom - e.top) * t, width: (e.right - e.left) * t, top: e.top * t, left: e.left * t };
        }
        hasFixedEdges() {
          return !this.workspace_.isMovableHorizontally() || !this.workspace_.isMovableVertically();
        }
        getComputedFixedEdges_(t) {
          if (!this.hasFixedEdges()) return {};
          var e = this.workspace_.isMovableHorizontally(), i = this.workspace_.isMovableVertically();
          t = t || this.getViewMetrics(!1);
          var o = {};
          return i || (o.top = t.top, o.bottom = t.top + t.height), e || (o.left = t.left, o.right = t.left + t.width), o;
        }
        getPaddedContent_(t, e) {
          var i = e.top + e.height, o = e.left + e.width, s = t.width;
          t = t.height;
          var n = s / 2, l = t / 2;
          return {
            top: Math.min(e.top - l, i - t),
            bottom: Math.max(i + l, e.top + t),
            left: Math.min(e.left - n, o - s),
            right: Math.max(o + n, e.left + s)
          };
        }
        getScrollMetrics(t, e, i) {
          t = t ? this.workspace_.scale : 1, e = e || this.getViewMetrics(!1);
          var o = i || this.getContentMetrics();
          i = this.getComputedFixedEdges_(e), e = this.getPaddedContent_(e, o), o = i.top !== void 0 ? i.top : e.top;
          var s = i.left !== void 0 ? i.left : e.left;
          return { top: o / t, left: s / t, width: ((i.right !== void 0 ? i.right : e.right) - s) / t, height: ((i.bottom !== void 0 ? i.bottom : e.bottom) - o) / t };
        }
        getUiMetrics() {
          return { viewMetrics: this.getViewMetrics(), absoluteMetrics: this.getAbsoluteMetrics(), toolboxMetrics: this.getToolboxMetrics() };
        }
        getMetrics() {
          var t = this.getToolboxMetrics(), e = this.getFlyoutMetrics(!0), i = this.getSvgMetrics(), o = this.getAbsoluteMetrics(), s = this.getViewMetrics(), n = this.getContentMetrics(), l = this.getScrollMetrics(!1, s, n);
          return {
            contentHeight: n.height,
            contentWidth: n.width,
            contentTop: n.top,
            contentLeft: n.left,
            scrollHeight: l.height,
            scrollWidth: l.width,
            scrollTop: l.top,
            scrollLeft: l.left,
            viewHeight: s.height,
            viewWidth: s.width,
            viewTop: s.top,
            viewLeft: s.left,
            absoluteTop: o.top,
            absoluteLeft: o.left,
            svgHeight: i.height,
            svgWidth: i.width,
            toolboxWidth: t.width,
            toolboxHeight: t.height,
            toolboxPosition: t.position,
            flyoutWidth: e.width,
            flyoutHeight: e.height
          };
        }
      };
      P(_.METRICS_MANAGER, "default", hu);
      var ep = class extends hu {
        constructor(t, e) {
          super(t), this.flyout_ = e;
        }
        getBoundingBox() {
          try {
            var t = this.workspace_.getCanvas().getBBox();
          } catch {
            t = { height: 0, y: 0, width: 0, x: 0 };
          }
          return t;
        }
        getContentMetrics(t) {
          var e = this.getBoundingBox();
          return t = t ? 1 : this.workspace_.scale, { height: e.height * t, width: e.width * t, top: e.y * t, left: e.x * t };
        }
        getScrollMetrics(t, e, i) {
          return e = i || this.getContentMetrics(), i = this.flyout_.MARGIN * this.workspace_.scale, t = t ? this.workspace_.scale : 1, {
            height: (e.height + 2 * i) / t,
            width: (e.width + e.left + i) / t,
            top: 0,
            left: 0
          };
        }
      }, $r = class {
        constructor(t, e) {
          this.gap = t, this.axis = e, this.y = this.x = 0;
        }
        getBoundingRectangle() {
          switch (this.axis) {
            case "x":
              return new F(this.y, this.y, this.x, this.x + this.gap);
            case "y":
              return new F(this.y, this.y + this.gap, this.x, this.x);
          }
        }
        moveBy(t, e) {
          this.x += t, this.y += e;
        }
        isNavigable() {
          return !1;
        }
        getFocusableElement() {
          throw Error("Cannot be focused");
        }
        getFocusableTree() {
          throw Error("Cannot be focused");
        }
        onNodeFocus() {
        }
        onNodeBlur() {
        }
        canBeFocused() {
          return !1;
        }
      }, ip = class {
        getFirstChild() {
          return null;
        }
        getParent(t) {
          return t.getWorkspace();
        }
        getNextSibling() {
          return null;
        }
        getPreviousSibling() {
          return null;
        }
        getRowId(t) {
          return t.getId();
        }
        isNavigable(t) {
          return t.canBeFocused();
        }
        isApplicable(t) {
          return t instanceof Gt;
        }
      }, op = class {
        getFirstChild() {
          return null;
        }
        getParent() {
          return null;
        }
        getNextSibling() {
          return null;
        }
        getPreviousSibling() {
          return null;
        }
        getRowId() {
          return "error";
        }
        isNavigable() {
          return !1;
        }
        isApplicable(t) {
          return t instanceof $r;
        }
      }, sp = class {
        getFirstChild(t) {
          return Ah(t)[0];
        }
        getParent(t) {
          var e;
          if ((e = t.previousConnection) != null && e.targetBlock()) {
            if (e = t.getSurroundParent()) return e;
          } else {
            let i;
            if ((i = t.outputConnection) != null && i.targetBlock()) return t.outputConnection.targetBlock();
          }
          return t.workspace;
        }
        getNextSibling(t) {
          if (t.nextConnection) {
            let i;
            return (i = t.nextConnection.targetBlock()) != null ? i : t.nextConnection;
          }
          var e;
          return (e = t.outputConnection) != null && e.targetConnection ? (e = this.getParent(t), oe(e, t, 1)) : null;
        }
        getPreviousSibling(t) {
          var e;
          if ((e = t.previousConnection) != null && e.targetBlock()) return t.previousConnection;
          var i;
          return (i = t.outputConnection) != null && i.targetBlock() ? oe(t.outputConnection.targetBlock(), t, -1) : null;
        }
        getRowId(t) {
          return t.getRowId();
        }
        isNavigable(t) {
          return t.canBeFocused();
        }
        isApplicable(t) {
          return t instanceof ut;
        }
      }, np = class {
        getFirstChild() {
          return null;
        }
        getParent(t) {
          var e;
          return (e = t.getOwner()) != null ? e : null;
        }
        getNextSibling(t) {
          var e;
          return oe((e = t.getOwner()) == null ? void 0 : e.getSourceBlock(), t, 1);
        }
        getPreviousSibling(t) {
          var e;
          return oe((e = t.getOwner()) == null ? void 0 : e.getSourceBlock(), t, -1);
        }
        getRowId(t) {
          var e, i, o;
          return (o = (e = t.getOwner()) == null || (i = e.getSourceBlock()) == null ? void 0 : i.getRowId()) != null ? o : "";
        }
        isNavigable(t) {
          return t.canBeFocused();
        }
        isApplicable(t) {
          return t instanceof j;
        }
      }, rp = class {
        getFirstChild() {
          return null;
        }
        getParent(t) {
          return t.getCommentView().workspace.getCommentById(t.getCommentView().commentId);
        }
        getNextSibling(t) {
          var e = t.getCommentView().getCommentBarButtons();
          return t = e.indexOf(t), t >= 0 && t + 1 < e.length ? e[t + 1] : null;
        }
        getPreviousSibling(t) {
          var e = t.getCommentView().getCommentBarButtons();
          return t = e.indexOf(t), t > 0 ? e[t - 1] : null;
        }
        getRowId(t) {
          return t.getCommentView().commentId;
        }
        isNavigable(t) {
          return t.canBeFocused();
        }
        isApplicable(t) {
          return t instanceof Fr;
        }
      }, lp = class {
        getFirstChild() {
          return null;
        }
        getParent() {
          return null;
        }
        getNextSibling() {
          return null;
        }
        getPreviousSibling() {
          return null;
        }
        getRowId(t) {
          return t.id;
        }
        isNavigable(t) {
          return t.canBeFocused();
        }
        isApplicable(t) {
          return t instanceof js;
        }
      }, ap = class {
        getFirstChild() {
          return null;
        }
        getParent(t) {
          return t.getSourceBlock();
        }
        getNextSibling(t) {
          if (t.getParentInput()) return oe(t.getSourceBlock(), t, 1);
          if (t.type === T.NEXT_STATEMENT && t.getSourceBlock().getSurroundParent() && !t.targetConnection) return oe(t.getSourceBlock().getSurroundParent(), t, 1);
          switch (t.type) {
            case T.NEXT_STATEMENT:
              return t.targetConnection;
            case T.PREVIOUS_STATEMENT:
            case T.OUTPUT_VALUE:
              return t.getSourceBlock();
          }
          return null;
        }
        getPreviousSibling(t) {
          if (t.getParentInput()) return oe(
            t.getParentInput().getSourceBlock(),
            t,
            -1
          );
          switch (t.type) {
            case T.NEXT_STATEMENT:
              return t.getSourceBlock();
            case T.PREVIOUS_STATEMENT:
            case T.OUTPUT_VALUE:
              return t.targetConnection;
          }
          return null;
        }
        getRowId(t) {
          switch (t.type) {
            case T.NEXT_STATEMENT:
            case T.PREVIOUS_STATEMENT:
              return t.id;
            case T.INPUT_VALUE:
              return t.getParentInput().getRowId();
            default:
              return t.getSourceBlock().getRowId();
          }
        }
        isNavigable(t) {
          if (!t.canBeFocused()) return !1;
          if (t.type === T.NEXT_STATEMENT) {
            if (t.targetBlock()) return !1;
            let e, i = (e = t.getSourceBlock().getRootBlock()) != null ? e : t.getSourceBlock();
            return t !== i.lastConnectionInStack(!1);
          }
          return t.type === T.INPUT_VALUE && !t.targetBlock();
        }
        isApplicable(t) {
          return t instanceof Dt;
        }
      }, hp = class {
        getFirstChild() {
          return null;
        }
        getParent(t) {
          return t.getSourceBlock();
        }
        getNextSibling(t) {
          return oe(t.getSourceBlock(), t, 1);
        }
        getPreviousSibling(t) {
          return oe(t.getSourceBlock(), t, -1);
        }
        getRowId(t) {
          return t.getParentInput().getRowId();
        }
        isNavigable(t) {
          var e;
          return t.canBeFocused() && t.isVisible() && (t.isClickable() || t.isCurrentlyEditable()) && !((e = t.getSourceBlock()) != null && e.isSimpleReporter() && t.isFullBlockField()) && t.getParentInput().isVisible();
        }
        isApplicable(t) {
          return t instanceof Z;
        }
      }, cp = class {
        getFirstChild() {
          return null;
        }
        getParent(t) {
          return t.getSourceBlock();
        }
        getNextSibling(t) {
          return oe(t.getSourceBlock(), t, 1);
        }
        getPreviousSibling(t) {
          return oe(t.getSourceBlock(), t, -1);
        }
        getRowId(t) {
          return t.getSourceBlock().getRowId();
        }
        isNavigable(t) {
          return t.canBeFocused();
        }
        isApplicable(t) {
          return t instanceof qo;
        }
      }, up = class {
        getFirstChild(t) {
          return t.view.getCommentBarButtons()[0];
        }
        getParent(t) {
          return t.workspace;
        }
        getNextSibling() {
          return null;
        }
        getPreviousSibling() {
          return null;
        }
        getRowId(t) {
          return t.id;
        }
        isNavigable(t) {
          return t.canBeFocused();
        }
        isApplicable(t) {
          return t instanceof ro;
        }
      }, dp = class {
        getFirstChild(t) {
          return t = t.getTopBlocks(!0), t.length ? t[0] : null;
        }
        getParent() {
          return null;
        }
        getNextSibling() {
          return null;
        }
        getPreviousSibling() {
          return null;
        }
        getRowId(t) {
          return t.id;
        }
        isNavigable(t) {
          return t.canBeFocused() && !t.isMutator;
        }
        isApplicable(t) {
          return t instanceof Ot;
        }
      }, ae, Ai = ae || (ae = {});
      Ai[Ai.NEXT = 0] = "NEXT", Ai[Ai.PREVIOUS = 1] = "PREVIOUS", Ai[Ai.IN = 2] = "IN", Ai[Ai.OUT = 3] = "OUT";
      var gp, Jr = class {
        constructor() {
          this.rules = [new sp(), new hp(), new ap(), new dp(), new cp(), new up(), new rp(), new np(), new lp()], this.navigationLoops = !0;
        }
        addNavigationPolicy(t) {
          this.rules.push(t);
        }
        get(t) {
          return this.rules.find((e) => e.isApplicable(t));
        }
        getFirstChild(t) {
          var e, i = (e = this.get(t)) == null ? void 0 : e.getFirstChild(t);
          return i ? this.isNavigable(i) ? i : this.getFirstChild(i) || this.getNextSibling(i) : null;
        }
        getParent(t) {
          var e, i = (e = this.get(t)) == null ? void 0 : e.getParent(t);
          return i ? this.isNavigable(i) ? i : this.getParent(i) : null;
        }
        getNextSibling(t) {
          var e, i = (e = this.get(t)) == null ? void 0 : e.getNextSibling(t);
          return i ? this.isNavigable(i) ? i : this.getNextSibling(i) : null;
        }
        getPreviousSibling(t) {
          var e, i = (e = this.get(t)) == null ? void 0 : e.getPreviousSibling(t);
          return i ? this.isNavigable(i) ? i : this.getPreviousSibling(i) : null;
        }
        getPreviousNode(t = r.t().getFocusedNode()) {
          if (!t) return null;
          var e = this.getPreviousNodeImpl(t, t, ae.PREVIOUS);
          if (!e || e === t.getFocusableTree()) {
            if (e = this.navigateStacks(t, -1), !e) return null;
            e = this.getLastNodeInStack(e, t);
          }
          return this.getLeftmostSibling(e);
        }
        getOutNode(t = r.t().getFocusedNode()) {
          return this.getPreviousNodeImpl(t, t, ae.OUT);
        }
        getNextNode(t = r.t().getFocusedNode()) {
          var e = this.getNextNodeImpl(t, t, ae.NEXT);
          return t && e === null ? this.navigateStacks(t, 1) : e;
        }
        getInNode(t = r.t().getFocusedNode()) {
          return this.getNextNodeImpl(t, t, ae.IN);
        }
        getPreviousNodeImpl(t, e, i, o = /* @__PURE__ */ new Set()) {
          if (!e || !t || o.has(e)) return null;
          var s = this.getRightMostChild(this.getPreviousSibling(e), e) || this.getParent(e);
          return s && this.transitionAllowed(t, s, i) ? s : s ? (o.add(e), this.getPreviousNodeImpl(t, s, i, o)) : null;
        }
        getNextNodeImpl(t, e, i, o = /* @__PURE__ */ new Set()) {
          if (!e || !t || o.has(e)) return null;
          for (var s = this.getFirstChild(e) || this.getNextSibling(e), n = e; n && !s && (n = this.getParent(n), !!n); )
            s = this.getNextSibling(n);
          return s && this.transitionAllowed(t, s, i) ? s : s ? (o.add(e), this.getNextNodeImpl(t, s, i, o)) : null;
        }
        getRightMostChild(t, e) {
          if (!t) return t;
          var i = this.getFirstChild(t);
          if (!i || i === e) return t;
          for (t = i; t && t !== e; t = this.getNextSibling(i)) i = t;
          return this.getRightMostChild(i, e);
        }
        setNavigationLoops(t) {
          this.navigationLoops = t;
        }
        getNavigationLoops() {
          return this.navigationLoops;
        }
        getNavigableItems(t = (gp = r.t().getFocusedTree()) == null ? void 0 : gp.getRootFocusableNode()) {
          return t ? this.getTopLevelItems(t).filter((e) => this.isNavigable(e)) : [];
        }
        getFirstNode() {
          var t, e = (t = r.t().getFocusedTree()) == null ? void 0 : t.getRootFocusableNode();
          return e ? this.getTopLevelItems(e)[0] : null;
        }
        getLastNode() {
          var t, e = (t = r.t().getFocusedTree()) == null ? void 0 : t.getRootFocusableNode();
          return e ? this.getTopLevelItems(e).slice(-1)[0] : null;
        }
        transitionAllowed(t, e, i) {
          switch (i) {
            case ae.IN:
            case ae.OUT:
              return this.getRowId(t) === this.getRowId(e);
            case ae.NEXT:
            case ae.PREVIOUS:
              return this.getRowId(t) !== this.getRowId(e);
          }
        }
        getLeftmostSibling(t) {
          if (!t) return null;
          for (var e; e = this.getPreviousNodeImpl(t, t, ae.OUT); ) t = e;
          return t;
        }
        getLastNodeInStack(t, e) {
          for (var i; (i = this.getNextNodeImpl(t, t, ae.NEXT)) && i !== e; ) t = i;
          return t;
        }
        getRowId(t) {
          var e;
          return (e = this.get(t)) == null ? void 0 : e.getRowId(t);
        }
        navigateStacks(t, e) {
          var i = this.getTopLevelItems(t), o, s, n = (s = (o = this.getSourceBlockFromNode(t)) == null ? void 0 : o.getRootBlock()) != null ? s : t;
          return t = i.indexOf(n) + e, e = null, t >= 0 && t < i.length ? e = i[t] : t < 0 && this.getNavigationLoops() ? e = i[i.length - 1] : t >= i.length && this.getNavigationLoops() && (e = i[0]), e;
        }
        getTopLevelItems(t) {
          return t.getFocusableTree().getTopBoundedElements(!0);
        }
        isNavigable(t) {
          var e;
          return (e = this.get(t)) == null ? void 0 : e.isNavigable(t);
        }
        getSourceBlockFromNode(t) {
          return t instanceof ut ? t : t instanceof Z || t instanceof Dt || t instanceof qo ? t.getSourceBlock() : t instanceof js ? (t = t.getParent(), t instanceof ut ? t : null) : null;
        }
      }, pp = class {
        getFirstChild(t) {
          return nr(t) ? t.getChildToolboxItems()[0] : null;
        }
        getParent(t) {
          return t.getParent();
        }
        getNextSibling(t) {
          var e = t.getParentToolbox().getToolboxItems();
          t = e.indexOf(t);
          var i;
          return (i = e[t + 1]) != null ? i : null;
        }
        getPreviousSibling(t) {
          var e = t.getParentToolbox().getToolboxItems();
          t = e.indexOf(t);
          var i;
          return (i = e[t - 1]) != null ? i : null;
        }
        getRowId(t) {
          return t.getId();
        }
        isNavigable(t) {
          return t.canBeFocused() && this.allParentsExpanded(t);
        }
        allParentsExpanded(t) {
          return (t = t.getParent()) && nr(t) ? t.isExpanded() && this.allParentsExpanded(t) : !0;
        }
        isApplicable(t) {
          return Yl(t);
        }
      }, fp = class extends Jr {
        constructor(t) {
          super(), this.toolbox = t, this.rules = [new pp()];
        }
        getInNode(t = r.t().getFocusedNode(), e = !1) {
          var i = qe(this.toolbox.getWorkspace());
          if (!e) switch (i) {
            case I.TOP:
            case I.BOTTOM:
              return this.getNextNode(t, !0);
            case I.RIGHT:
              return this.getOutNode(t, !0);
          }
          if (!Hi(t) || Hi(t) && !t.getContents().length) return null;
          var o;
          return (t = (o = this.toolbox.getFlyout()) == null ? void 0 : o.getWorkspace().getNavigator()) ? !this.toolbox.getWorkspace().RTL || i !== I.TOP && i !== I.BOTTOM ? t.getFirstNode() : t.getLastNode() : null;
        }
        getOutNode(t, e = !1) {
          if (!e) switch (qe(this.toolbox.getWorkspace())) {
            case I.TOP:
            case I.BOTTOM:
              return this.getPreviousNode(t, !0);
            case I.RIGHT:
              return this.getInNode(t, !0);
          }
          return super.getOutNode(t);
        }
        getNextNode(t, e = !1) {
          if (!e) switch (qe(this.toolbox.getWorkspace())) {
            case I.TOP:
              return this.getInNode(t, !0);
            case I.BOTTOM:
              return this.getOutNode(t, !0);
          }
          return super.getNextNode(t);
        }
        getPreviousNode(t, e = !1) {
          if (!e) switch (qe(this.toolbox.getWorkspace())) {
            case I.TOP:
              return this.getOutNode(t, !0);
            case I.BOTTOM:
              return this.getInNode(
                t,
                !0
              );
          }
          return super.getPreviousNode(t);
        }
        getTopLevelItems() {
          return this.toolbox.getToolboxItems();
        }
      }, Ep = class extends Jr {
        constructor(t) {
          super(), this.flyout = t, this.rules.push(new ip(), new op());
        }
        getOutNode(t, e = !1) {
          if (!e && this.flyout.targetWorkspace) switch (qe(this.flyout.targetWorkspace)) {
            case I.TOP:
            case I.BOTTOM:
              return this.flyout.RTL ? this.getNextNode(t, !0) : this.getPreviousNode(t, !0);
            case I.RIGHT:
              return null;
          }
          var i;
          return (t = (i = this.flyout.targetWorkspace) == null ? void 0 : i.getToolbox()) ? t.getSelectedItem() : null;
        }
        getInNode(t, e = !1) {
          if (!e && this.flyout.targetWorkspace) switch (qe(this.flyout.targetWorkspace)) {
            case I.TOP:
            case I.BOTTOM:
              return this.flyout.RTL ? this.getPreviousNode(t, !0) : this.getNextNode(t, !0);
            case I.RIGHT:
              return this.getOutNode(t, !0);
          }
          return super.getInNode(t);
        }
        getNextNode(t, e = !1) {
          if (!e && this.flyout.targetWorkspace) switch (qe(this.flyout.targetWorkspace)) {
            case I.TOP:
              return null;
            case I.BOTTOM:
              return this.getOutNode(t, !0);
          }
          return super.getNextNode(t);
        }
        getPreviousNode(t, e = !1) {
          if (!e && this.flyout.targetWorkspace) switch (qe(this.flyout.targetWorkspace)) {
            case I.TOP:
              return this.getOutNode(t, !0);
            case I.BOTTOM:
              return null;
          }
          return super.getPreviousNode(t);
        }
        getTopLevelItems() {
          return this.flyout.getContents().map((t) => t.getElement()).filter((t) => this.isNavigable(t));
        }
        isNavigable(t) {
          return super.isNavigable(t) && this.flyout.getContents().map((e) => e.getElement()).includes(t);
        }
      }, cu = class {
        constructor(t, e, i, o, s) {
          this.workspace = t, this.oldHostMetrics = this.corner_ = this.vScroll = this.hScroll = null, e = e === void 0 ? !0 : e, i = i === void 0 ? !0 : i;
          var n = e && i;
          e && (this.hScroll = new pt(t, !0, n, o, s)), i && (this.vScroll = new pt(t, !1, n, o, s)), n && (this.corner_ = v(g.RECT, { height: pt.scrollbarThickness, width: pt.scrollbarThickness, class: "blocklyScrollbarBackground" }), us(this.corner_, t.getBubbleCanvas()));
        }
        dispose() {
          Q(this.corner_), this.oldHostMetrics = this.corner_ = null, this.hScroll && (this.hScroll.dispose(), this.hScroll = null), this.vScroll && (this.vScroll.dispose(), this.vScroll = null);
        }
        resize() {
          var t = this.workspace.getMetrics();
          if (t) {
            var e = !1, i = !1;
            if (this.oldHostMetrics && this.oldHostMetrics.viewWidth === t.viewWidth && this.oldHostMetrics.viewHeight === t.viewHeight && this.oldHostMetrics.absoluteTop === t.absoluteTop && this.oldHostMetrics.absoluteLeft === t.absoluteLeft ? (this.oldHostMetrics && this.oldHostMetrics.scrollWidth === t.scrollWidth && this.oldHostMetrics.viewLeft === t.viewLeft && this.oldHostMetrics.scrollLeft === t.scrollLeft || (e = !0), this.oldHostMetrics && this.oldHostMetrics.scrollHeight === t.scrollHeight && this.oldHostMetrics.viewTop === t.viewTop && this.oldHostMetrics.scrollTop === t.scrollTop || (i = !0)) : i = e = !0, e || i) {
              try {
                r.Ub++, this.hScroll && e && this.hScroll.resize(t), this.vScroll && i && this.vScroll.resize(t);
              } finally {
                r.Ub--;
              }
              this.workspace.maybeFireViewportChangeEvent();
            }
            if (this.hScroll && this.vScroll) {
              if (!this.oldHostMetrics || this.oldHostMetrics.viewWidth !== t.viewWidth || this.oldHostMetrics.absoluteLeft !== t.absoluteLeft) {
                let o;
                (o = this.corner_) == null || o.setAttribute("x", String(this.vScroll.position.x));
              }
              if (!this.oldHostMetrics || this.oldHostMetrics.viewHeight !== t.viewHeight || this.oldHostMetrics.absoluteTop !== t.absoluteTop) {
                let o;
                (o = this.corner_) == null || o.setAttribute("y", String(this.hScroll.position.y));
              }
            }
            this.oldHostMetrics = t;
          }
        }
        canScrollHorizontally() {
          return !!this.hScroll;
        }
        canScrollVertically() {
          return !!this.vScroll;
        }
        setOrigin(t, e) {
          this.hScroll && this.hScroll.setOrigin(t, e), this.vScroll && this.vScroll.setOrigin(t, e);
        }
        set(t, e, i) {
          this.hScroll && this.hScroll.set(t, !1), this.vScroll && this.vScroll.set(e, !1), (i || i === void 0) && (t = {}, this.hScroll && (t.x = this.hScroll.getRatio_()), this.vScroll && (t.y = this.vScroll.getRatio_()), this.workspace.setMetrics(t));
        }
        setX(t) {
          this.hScroll && this.hScroll.set(t, !0);
        }
        setY(t) {
          this.vScroll && this.vScroll.set(t, !0);
        }
        setContainerVisible(t) {
          this.hScroll && this.hScroll.setContainerVisible(t), this.vScroll && this.vScroll.setContainerVisible(t);
        }
        isVisible() {
          var t = !1;
          return this.hScroll && (t = this.hScroll.isVisible()), this.vScroll && (t = t || this.vScroll.isVisible()), t;
        }
        setVisible(t) {
          this.hScroll && this.hScroll.setVisibleInternal(t), this.vScroll && this.vScroll.setVisibleInternal(t);
        }
        resizeContent(t) {
          this.hScroll && this.hScroll.resizeContentHorizontal(t), this.vScroll && this.vScroll.resizeContentVertical(t);
        }
        resizeView(t) {
          this.hScroll && this.hScroll.resizeViewHorizontal(t), this.vScroll && this.vScroll.resizeViewVertical(t);
        }
      }, vp = class {
        load(t, e) {
          return t = new $r(0, e.horizontalLayout ? "x" : "y"), new ss(t, "sep");
        }
        gapForItem(t, e) {
          var i;
          return (i = parseInt(String(t.gap))) != null ? i : e;
        }
        disposeItem() {
        }
        getType() {
          return "sep";
        }
      };
      P(_.FLYOUT_INFLATER, "sep", vp);
      var qr = class extends jr {
        constructor(t) {
          super(), this.horizontalLayout = !1, this.boundEvents = [], this.reflowWrapper = null, this.inhibitReflowWrapper = !1, this.contents = [], this.autoClose = !0, this.visible = !1, this.containerVisible = !0, this.CORNER_RADIUS = 8, this.SCROLLBAR_MARGIN = 2.5, this.height_ = this.width_ = 0, this.svgGroup_ = this.svgBackground_ = null, this.inflaters = /* @__PURE__ */ new Map(), t.setMetrics = this.setMetrics_.bind(this), this.workspace_ = new Ot(t), this.workspace_.setMetricsManager(new ep(this.workspace_, this)), this.workspace_.internalIsFlyout = !0, this.workspace_.setVisible(this.visible), this.workspace_.setNavigator(new Ep(this)), this.id = je(), this.RTL = !!t.RTL, this.toolboxPosition_ = t.toolboxPosition, this.tabWidth_ = this.workspace_.getRenderer().getConstants().TAB_WIDTH, this.MARGIN = this.CORNER_RADIUS, this.GAP_X = this.MARGIN * 3, this.GAP_Y = this.MARGIN * 3;
        }
        createDom(t) {
          return this.svgGroup_ = v(t, { class: "blocklyFlyout" }), this.svgGroup_.style.display = "none", this.svgBackground_ = v(g.PATH, { class: "blocklyFlyoutBackground" }, this.svgGroup_), this.svgGroup_.appendChild(this.workspace_.createDom()), this.workspace_.getThemeManager().subscribe(this.svgBackground_, "flyoutBackgroundColour", "fill"), this.workspace_.getThemeManager().subscribe(this.svgBackground_, "flyoutOpacity", "fill-opacity"), this.svgGroup_.addEventListener("keydown", (e) => {
            e.key === "Escape" && (r.t().focusTree(this.targetWorkspace), this.targetWorkspace.isMutator || this.autoHide(!1), e.preventDefault(), e.stopPropagation());
          }), this.svgGroup_;
        }
        init(t) {
          this.targetWorkspace = t, this.workspace_.targetWorkspace = t, this.workspace_.setInitialAriaContext(), this.workspace_.scrollbar = new cu(this.workspace_, this.horizontalLayout, !this.horizontalLayout, "blocklyFlyoutScrollbar", this.SCROLLBAR_MARGIN), this.hide(), this.boundEvents.push(M(this.svgGroup_, "wheel", this, this.wheel_, !1, { passive: !1 })), this.boundEvents.push(M(this.svgBackground_, "pointerdown", this, this.onMouseDown)), this.workspace_.getGesture = this.targetWorkspace.getGesture.bind(this.targetWorkspace), this.workspace_.setVariableMap(this.targetWorkspace.getVariableMap()), this.workspace_.createPotentialVariableMap(), t.getComponentManager().addComponent({ component: this, weight: nt.ComponentWeight.FLYOUT_WEIGHT, capabilities: [nt.Capability.AUTOHIDEABLE, nt.Capability.DELETE_AREA, nt.Capability.DRAG_TARGET] });
        }
        dispose() {
          this.hide(), this.targetWorkspace.getComponentManager().removeComponent(this.id);
          for (let t of this.boundEvents) $(t);
          this.boundEvents.length = 0, this.workspace_ && (this.workspace_.getThemeManager().unsubscribe(this.svgBackground_), this.workspace_.dispose()), this.svgGroup_ && Q(this.svgGroup_);
        }
        getWidth() {
          return this.width_;
        }
        getHeight() {
          return this.height_;
        }
        getFlyoutScale() {
          return this.targetWorkspace.scale;
        }
        getWorkspace() {
          return this.workspace_;
        }
        setAutoClose(t) {
          this.autoClose = t, this.targetWorkspace.recordDragTargets(), this.targetWorkspace.resizeContents();
        }
        autoHide(t) {
          !t && this.targetWorkspace.getFlyout(!0) === this && this.autoClose && this.hide();
        }
        getTargetWorkspace() {
          return this.targetWorkspace;
        }
        isVisible() {
          return this.visible;
        }
        setVisible(t) {
          var e = t !== this.isVisible();
          this.visible = t, e && (this.autoClose || this.targetWorkspace.recordDragTargets(), this.updateDisplay());
        }
        setContainerVisible(t) {
          var e = t !== this.containerVisible;
          this.containerVisible = t, e && this.updateDisplay();
        }
        getContents() {
          return this.contents;
        }
        setContents(t) {
          this.contents = t;
        }
        updateDisplay() {
          var t = this.containerVisible ? this.isVisible() : !1;
          this.svgGroup_ && (this.svgGroup_.style.display = t ? "block" : "none");
          var e;
          (e = this.workspace_.scrollbar) == null || e.setContainerVisible(t);
        }
        positionAt_(t, e, i, o) {
          var s;
          (s = this.svgGroup_) == null || s.setAttribute("width", `${t}`);
          var n;
          (n = this.svgGroup_) == null || n.setAttribute("height", `${e}`), this.workspace_.setCachedParentSvgSize(t, e), this.svgGroup_ && un(this.svgGroup_, "translate(" + i + "px," + o + "px)"), (t = this.workspace_.scrollbar) && (t.setOrigin(i, o), t.resize(), t.hScroll && t.hScroll.setPosition(t.hScroll.position.x, t.hScroll.position.y), t.vScroll && t.vScroll.setPosition(t.vScroll.position.x, t.vScroll.position.y));
        }
        hide() {
          this.isVisible() && (this.setVisible(!1), this.reflowWrapper && (this.workspace_.removeChangeListener(this.reflowWrapper), this.reflowWrapper = null));
        }
        show(t) {
          r.t().getFocusedTree() === this.workspace_ && r.t().getFocusedNode() !== this.workspace_ && r.t().focusNode(this.workspace_), this.workspace_.setResizesEnabled(!1), r.Qc = !1, this.hide(), this.clearOldBlocks(), typeof t == "string" && (t = this.getDynamicCategoryContents(t)), this.setVisible(!0), t = ms(t), t = this.createFlyoutInfo(t), Ne(this.workspace_), this.setContents(t), this.layout_(t), this.horizontalLayout ? this.height_ = 0 : this.width_ = 0, this.reflow(), this.updateAriaContext(), r.Qc = !0, this.workspace_.setResizesEnabled(!0), this.reflowWrapper = (e) => {
            this.inhibitReflowWrapper || e.type !== p.BLOCK_CHANGE && e.type !== p.BLOCK_FIELD_INTERMEDIATE_CHANGE || this.reflow();
          }, this.workspace_.addChangeListener(this.reflowWrapper);
        }
        updateAriaContext() {
          var t = this.getContents().map((i) => i.getElement()).filter((i) => i.canBeFocused()).map((i) => i.getFocusableElement().id);
          w(this.getWorkspace().getCanvas(), y.OWNS, t.join(" ")), this.targetWorkspace.isMutator || this.autoClose ? G(this.getWorkspace().svgGroup_, W.NONE) : G(this.getWorkspace().svgGroup_, W.REGION);
          var e = (t = (e = this.targetWorkspace.getToolbox()) == null ? void 0 : e.getSelectedItem()) && Hi(t) ? t.getName() : "";
          e = r.C.WORKSPACE_LABEL_FLYOUT_WORKSPACE.replace("%1", e).trim(), w(this.getWorkspace().getCanvas(), y.LABEL, e), G(this.getWorkspace().getCanvas(), W.LISTBOX);
        }
        createFlyoutInfo(t) {
          var e = [], i = this.horizontalLayout ? this.GAP_X : this.GAP_Y;
          for (let o of t) "custom" in o && (t = this.getDynamicCategoryContents(o.custom), t = ms(t), e.push(...this.createFlyoutInfo(t))), t = o.kind.toLowerCase(), (t = this.getInflaterForType(t)) && (e.push(t.load(o, this)), (t = t.gapForItem(o, i)) && e.push(new ss(new $r(t, this.horizontalLayout ? "x" : "y"), "sep")));
          return this.normalizeSeparators(e);
        }
        normalizeSeparators(t) {
          for (let e = t.length - 1; e > 0; e--) {
            let i = t[e].getType().toLowerCase(), o = t[e - 1].getType().toLowerCase();
            i === "sep" && o === "sep" && t.splice(e - 1, 1);
          }
          return t;
        }
        getDynamicCategoryContents(t) {
          if (t = this.workspace_.targetWorkspace.getToolboxCategoryCallback(t), typeof t != "function") throw TypeError("Couldn't find a callback function when opening a toolbox category.");
          return t(this.workspace_.targetWorkspace);
        }
        clearOldBlocks() {
          this.getContents().forEach((e) => {
            var i;
            (i = this.getInflaterForType(e.getType())) == null || i.disposeItem(e);
          });
          var t;
          (t = this.workspace_.getPotentialVariableMap()) == null || t.clear();
        }
        onMouseDown(t) {
          var e = this.targetWorkspace.getGesture(t);
          e && e.handleFlyoutStart(t, this);
        }
        reflow() {
          this.inhibitReflowWrapper = !0, this.reflowInternal_(), this.inhibitReflowWrapper = !1;
        }
        isScrollable() {
          return this.workspace_.scrollbar ? this.workspace_.scrollbar.isVisible() : !1;
        }
        getInflaterForType(t) {
          if (this.inflaters.has(t)) {
            var e;
            return (e = this.inflaters.get(t)) != null ? e : null;
          }
          return (e = Mt(_.FLYOUT_INFLATER, t, void 0)) ? (e = new e(), this.inflaters.set(t, e), e) : null;
        }
      }, _p = class {
        constructor(t) {
          this.workspace = t, this.horizontalScrollEnabled = this.workspace.isMovableHorizontally(), this.verticalScrollEnabled = this.workspace.isMovableVertically(), this.startScrollXY_ = new m(t.scrollX, t.scrollY);
        }
        startDrag() {
        }
        endDrag(t) {
          this.drag(t);
        }
        drag(t) {
          if (t = m.sum(this.startScrollXY_, t), this.horizontalScrollEnabled && this.verticalScrollEnabled) this.workspace.scroll(t.x, t.y);
          else if (this.horizontalScrollEnabled) this.workspace.scroll(t.x, this.workspace.scrollY);
          else if (this.verticalScrollEnabled) this.workspace.scroll(
            this.workspace.scrollX,
            t.y
          );
          else throw new TypeError("Invalid state.");
        }
      }, Zr = class {
        constructor(t, e) {
          this.creatorWorkspace = e, this.mouseDownXY = new m(0, 0), this.startWorkspace_ = this.targetBlock = this.startComment = this.startBlock = this.startIcon = this.startField = this.startBubble = null, this.hasExceededDragRadius = !1, this.boundEvents = [], this.workspaceDragger = this.dragger = null, this.dragging = !1, this.flyout = null, this.multiTouch = this.isEnding_ = this.gestureHasStarted = this.calledUpdateIsDragging = !1, this.cachedPoints = /* @__PURE__ */ new Map(), this.startDistance = this.previousScale = 0, this.currentDropdownOwner = this.isPinchZoomEnabled = null, this.mostRecentEvent = t, this.currentDragDeltaXY = new m(0, 0);
        }
        dispose() {
          Ft = null, ki = !1, this.creatorWorkspace.clearGesture();
          for (let t of this.boundEvents) $(t);
          this.boundEvents.length = 0;
        }
        updateFromEvent(t) {
          var e = new m(t.clientX, t.clientY);
          this.updateDragDelta(e) && (this.updateIsDragging(t), Se()), this.mostRecentEvent = t;
        }
        updateDragDelta(t) {
          return this.currentDragDeltaXY = m.difference(t, this.mouseDownXY), this.hasExceededDragRadius ? !1 : this.hasExceededDragRadius = m.magnitude(this.currentDragDeltaXY) > (this.flyout ? r.Og.flyoutDragRadius : r.Og.dragRadius);
        }
        updateIsDraggingWorkspace() {
          if (!this.startWorkspace_) throw Error("Cannot update dragging the workspace because the start workspace is undefined");
          (this.flyout ? this.flyout.isScrollable() : this.startWorkspace_ && this.startWorkspace_.isDraggable()) && (this.dragging = !0, this.workspaceDragger = new _p(this.startWorkspace_), this.workspaceDragger.startDrag());
        }
        updateIsDragging(t) {
          if (!this.startWorkspace_) throw Error("Cannot update dragging because the start workspace is undefined");
          if (this.calledUpdateIsDragging) throw Error("updateIsDragging_ should only be called once per gesture.");
          this.calledUpdateIsDragging = !0;
          var e = fs();
          e && Xi(e) && e.isMovable() ? (this.dragging = !0, this.dragger = this.createDragger(e), this.dragger.onDragStart(t), this.dragger.onDrag(t, this.currentDragDeltaXY)) : this.updateIsDraggingWorkspace();
        }
        createDragger(t) {
          return new (Pt(_.BLOCK_DRAGGER, this.creatorWorkspace.options, !0))(t);
        }
        doStart(t) {
          if (!this.startWorkspace_) throw Error("Cannot start the touch gesture becauase the start workspace is undefined");
          this.isPinchZoomEnabled = this.startWorkspace_.options.zoomOptions && this.startWorkspace_.options.zoomOptions.pinch, hs(t) ? this.cancel() : (this.gestureHasStarted = !0, Mo(), this.startWorkspace_.updateScreenCalculationsIfScrolled(), this.startWorkspace_.isMutator && this.startWorkspace_.resize(), this.currentDropdownOwner = mt, this.startWorkspace_.hideChaff(!!this.flyout), this.startWorkspace_.markFocused(), this.mostRecentEvent = t, _a(), _e(t) ? this.handleRightClick(t) : (t.type.toLowerCase() === "pointerdown" && t.pointerType !== "mouse" && ls(t, this), this.mouseDownXY = new m(t.clientX, t.clientY), this.bindMouseEvents(t), this.isEnding_ || this.handleTouchStart(t)));
        }
        bindMouseEvents(t) {
          this.boundEvents.push(M(document, "pointerdown", null, this.handleStart.bind(this), !0)), this.boundEvents.push(M(document, "pointermove", null, this.handleMove.bind(this), !0)), this.boundEvents.push(M(document, "pointerup", null, this.handleUp.bind(this), !0)), this.boundEvents.push(M(document, "pointercancel", null, this.handleUp.bind(this), !0)), t.preventDefault(), t.stopPropagation();
        }
        handleStart(t) {
          this.isDragging() || (this.handleTouchStart(t), this.isMultiTouch() && Se());
        }
        handleMove(t) {
          this.isDragging() && as(t) || !this.isMultiTouch() ? (this.updateFromEvent(t), this.workspaceDragger ? this.workspaceDragger.drag(this.currentDragDeltaXY) : this.dragger && this.dragger.onDrag(this.mostRecentEvent, this.currentDragDeltaXY), t.preventDefault(), t.stopPropagation()) : this.isMultiTouch() && (this.handleTouchMove(t), Se());
        }
        handleUp(t) {
          if (this.isDragging() || this.handleTouchEnd(t), !this.isMultiTouch() || this.isDragging()) {
            if (!as(t)) return;
            if (this.updateFromEvent(t), Se(), this.isEnding_) {
              console.log("Trying to end a gesture recursively.");
              return;
            }
            this.isEnding_ = !0, this.dragger ? (st.setIsActive(!1), this.dragger.onDragEnd(t, this.currentDragDeltaXY)) : this.workspaceDragger ? (st.setIsActive(!1), this.workspaceDragger.endDrag(this.currentDragDeltaXY)) : this.isBubbleClick() || this.isCommentClick() || (this.isFieldClick() ? this.doFieldClick() : this.isIconClick() ? this.doIconClick() : this.isBlockClick() ? this.doBlockClick() : this.isWorkspaceClick() && this.doWorkspaceClick(t));
          }
          t.preventDefault(), t.stopPropagation(), this.dispose();
        }
        handleTouchStart(t) {
          var e = mo(t);
          this.cachedPoints.set(e, this.getTouchPoint(t));
          var i = Array.from(this.cachedPoints.keys());
          i.length === 2 && (e = this.cachedPoints.get(i[0]), i = this.cachedPoints.get(i[1]), this.startDistance = m.distance(e, i), this.multiTouch = !0, t.preventDefault());
        }
        handleTouchMove(t) {
          var e = mo(t);
          this.cachedPoints.set(e, this.getTouchPoint(t)), this.isPinchZoomEnabled && this.cachedPoints.size === 2 ? this.handlePinch(t) : (this.updateFromEvent(t), this.workspaceDragger ? this.workspaceDragger.drag(this.currentDragDeltaXY) : this.dragger && this.dragger.onDrag(this.mostRecentEvent, this.currentDragDeltaXY), t.preventDefault(), t.stopPropagation());
        }
        handlePinch(t) {
          var e = Array.from(this.cachedPoints.keys()), i = this.cachedPoints.get(e[0]);
          if (e = this.cachedPoints.get(e[1]), i = m.distance(i, e) / this.startDistance, this.previousScale > 0 && this.previousScale < 1 / 0) {
            if (e = i - this.previousScale, e = e > 0 ? e * 5 : e * 6, !this.startWorkspace_) throw Error("Cannot handle a pinch because the start workspace is undefined");
            let o = this.startWorkspace_, s = To(t, o.getParentSvg(), o.getInverseScreenCTM());
            o.zoom(s.x, s.y, e);
          }
          this.previousScale = i, t.preventDefault();
        }
        handleTouchEnd(t) {
          t = mo(t), this.cachedPoints.has(t) && this.cachedPoints.delete(t), this.cachedPoints.size < 2 && (this.cachedPoints.clear(), this.previousScale = 0);
        }
        getTouchPoint(t) {
          return this.startWorkspace_ ? new m(t.pageX, t.pageY) : null;
        }
        isMultiTouch() {
          return this.multiTouch;
        }
        cancel() {
          this.isEnding_ || (Se(), this.dragger ? this.dragger.onDragEnd(this.mostRecentEvent, this.currentDragDeltaXY) : this.workspaceDragger && this.workspaceDragger.endDrag(this.currentDragDeltaXY), this.dispose());
        }
        handleRightClick(t) {
          var e = r.t().getFocusedNode();
          if (e && typeof e.showContextMenu == "function") {
            let i;
            (i = this.startWorkspace_) == null || i.hideChaff(!!this.flyout), e.showContextMenu(t);
          }
          t.preventDefault(), t.stopPropagation(), st.setIsActive(!1), this.dispose();
        }
        handleWsStart(t, e) {
          if (this.gestureHasStarted) throw Error("Tried to call gesture.handleWsStart, but the gesture had already been started.");
          this.setStartWorkspace(e), this.mostRecentEvent = t, this.targetBlock || this.startBubble || this.startComment || this.startIcon || r.t().focusNode(e), this.doStart(t);
        }
        fireWorkspaceClick(t) {
          N(new (D(p.CLICK))(null, t.id, "workspace"));
        }
        handleFlyoutStart(t, e) {
          if (this.gestureHasStarted) throw Error("Tried to call gesture.handleFlyoutStart, but the gesture had already been started.");
          this.setStartFlyout(e), this.handleWsStart(t, e.getWorkspace());
        }
        handleBlockStart(t, e) {
          if (this.gestureHasStarted) throw Error("Tried to call gesture.handleBlockStart, but the gesture had already been started.");
          this.setStartBlock(e), this.mostRecentEvent = t;
        }
        handleBubbleStart(t, e) {
          if (this.gestureHasStarted) throw Error("Tried to call gesture.handleBubbleStart, but the gesture had already been started.");
          this.setStartBubble(e), this.mostRecentEvent = t;
        }
        handleCommentStart(t, e) {
          if (this.gestureHasStarted) throw Error("Tried to call gesture.handleCommentStart, but the gesture had already been started.");
          this.setStartComment(e), this.mostRecentEvent = t;
        }
        doFieldClick() {
          if (!this.startField) throw Error("Cannot do a field click because the start field is undefined");
          this.currentDropdownOwner !== this.startField && this.startField.showEditor(this.mostRecentEvent);
        }
        doIconClick() {
          if (!this.startIcon) throw Error("Cannot do an icon click because the start icon is undefined");
          this.startIcon.onClick();
        }
        doBlockClick() {
          if (this.flyout && this.flyout.autoClose) {
            if (!this.targetBlock) throw Error("Cannot do a block click because the target block is undefined");
            var t = ee(this.targetBlock);
            let i = this.flyout.targetWorkspace;
            if (t && i) {
              var e = pi(this.flyout.getWorkspace(), this.targetBlock.getRelativeToSurfaceXY());
              e = gi(i, e), t.x = e.x, t.y = e.y, fi(t, i, { recordUndo: !0 }), i.hideChaff(!1);
            }
          } else {
            if (!this.startWorkspace_) throw Error("Cannot do a block click because the start workspace is undefined");
            t = new (D(p.CLICK))(this.startBlock, this.startWorkspace_.id, "block"), N(t);
          }
          r.B(!1);
        }
        doWorkspaceClick() {
          this.fireWorkspaceClick(this.startWorkspace_ || this.creatorWorkspace);
        }
        setStartField(t) {
          if (this.gestureHasStarted) throw Error("Tried to call gesture.setStartField, but the gesture had already been started.");
          this.startField || (this.startField = t);
        }
        setStartIcon(t) {
          if (this.gestureHasStarted) throw Error("Tried to call gesture.setStartIcon, but the gesture had already been started.");
          this.startIcon || (this.startIcon = t);
        }
        setStartBubble(t) {
          this.startBubble || (this.startBubble = t);
        }
        setStartComment(t) {
          this.startComment || (this.startComment = t);
        }
        setStartBlock(t) {
          var e, i, o;
          this.startBlock || this.startBubble || this.startIcon && (!t.isInFlyout || (o = (i = this.startIcon).isClickableInFlyout) != null && o.call(i, !((e = t.workspace.getFlyout()) == null || !e.autoClose))) || (this.startBlock = t, t.isInFlyout && t !== t.getRootBlock() ? this.setTargetBlock(t.getRootBlock()) : this.setTargetBlock(t));
        }
        setTargetBlock(t) {
          t.isShadow() ? this.setTargetBlock(t.getParent()) : (this.targetBlock = t, this.targetBlock.bringToFront(), r.t().focusNode(this.targetBlock));
        }
        setStartWorkspace(t) {
          this.startWorkspace_ || (this.startWorkspace_ = t);
        }
        setStartFlyout(t) {
          this.flyout || (this.flyout = t);
        }
        isBubbleClick() {
          return !!this.startBubble && !this.hasExceededDragRadius;
        }
        isCommentClick() {
          return !!this.startComment && !this.hasExceededDragRadius;
        }
        isBlockClick() {
          return !!this.startBlock && !this.hasExceededDragRadius && !this.isFieldClick() && !this.isIconClick();
        }
        isFieldClick() {
          return this.startField ? this.startField.isClickable() && !this.hasExceededDragRadius && (!this.flyout || this.startField.isClickableInFlyout(this.flyout.autoClose)) : !1;
        }
        isIconClick() {
          if (!this.startIcon) return !1;
          var t = !this.flyout || !this.startIcon.isClickableInFlyout || this.startIcon.isClickableInFlyout(this.flyout.autoClose);
          return !this.hasExceededDragRadius && t;
        }
        isWorkspaceClick() {
          return !this.startBlock && !this.startBubble && !this.startField && !this.hasExceededDragRadius;
        }
        getCurrentDragger() {
          var t, e;
          return (e = (t = this.workspaceDragger) != null ? t : this.dragger) != null ? e : null;
        }
        isDragging() {
          return this.dragging;
        }
        hasStarted() {
          return this.gestureHasStarted;
        }
        static inProgress() {
          var t = hi();
          for (let e = 0, i; i = t[e]; e++) if (i.currentGesture_) return !0;
          return !1;
        }
      }, uu = class {
        constructor(t, e) {
          this.pattern = t, this.scale = 1;
          var i;
          this.spacing = (i = e.spacing) != null ? i : 0;
          var o;
          this.length = (o = e.length) != null ? o : 1, this.line2 = (this.line1 = t.firstChild) && this.line1.nextSibling;
          var s;
          this.snapToGrid = (s = e.snap) != null ? s : !1;
        }
        setSpacing(t) {
          this.spacing = t, this.update(this.scale);
        }
        getSpacing() {
          return this.spacing;
        }
        setLength(t) {
          this.length = t, this.update(this.scale);
        }
        getLength() {
          return this.length;
        }
        setSnapToGrid(t) {
          this.snapToGrid = t;
        }
        shouldSnap() {
          return this.snapToGrid;
        }
        getPatternId() {
          return this.pattern.id;
        }
        update(t) {
          this.scale = t;
          var e = this.spacing * t;
          this.pattern.setAttribute("width", `${e}`), this.pattern.setAttribute("height", `${e}`), e = Math.floor(this.spacing / 2) + 0.5;
          var i = e - this.length / 2, o = e + this.length / 2;
          e *= t, i *= t, o *= t, this.setLineAttributes(this.line1, t, i, o, e, e), this.setLineAttributes(this.line2, t, e, e, i, o);
        }
        setLineAttributes(t, e, i, o, s, n) {
          t && (t.setAttribute("stroke-width", `${e}`), t.setAttribute("x1", `${i}`), t.setAttribute("y1", `${s}`), t.setAttribute("x2", `${o}`), t.setAttribute("y2", `${n}`));
        }
        moveTo(t, e) {
          this.pattern.setAttribute(
            "x",
            `${t}`
          ), this.pattern.setAttribute("y", `${e}`);
        }
        alignXY(t) {
          var e = this.getSpacing(), i = e / 2, o = Math.round(Math.round((t.x - i) / e) * e + i);
          return e = Math.round(Math.round((t.y - i) / e) * e + i), o === t.x && e === t.y ? t : new m(o, e);
        }
        static createDom(t, e, i, o) {
          t = v(g.PATTERN, { id: "blocklyGridPattern" + t, patternUnits: "userSpaceOnUse" }, i);
          var s, n;
          if (((s = e.length) != null ? s : 1) > 0 && ((n = e.spacing) != null ? n : 0) > 0) {
            v(g.LINE, { stroke: e.colour }, t);
            let l;
            (l = e.length) != null && l && v(g.LINE, { stroke: e.colour }, t);
          } else v(g.LINE, {}, t);
          return o && o.style.setProperty(
            "--blocklyGridPattern",
            `url(#${t.id})`
          ), t;
        }
      }, kf = class {
        constructor(t) {
          this.workspace = t, this.layers = /* @__PURE__ */ new Map(), (t = t.getInjectionDiv()) && (this.dragLayer = this.createDragLayer(t), this.animationLayer = this.createAnimationLayer(t)), t = this.createLayer(50), b(t, "blocklyBlockCanvas"), t = this.createLayer(100), b(t, "blocklyBubbleCanvas");
        }
        createDragLayer(t) {
          var e = v(g.SVG, { class: "blocklyBlockDragSurface", xmlns: "http://www.w3.org/2000/svg", "xmlns:html": "http://www.w3.org/1999/xhtml", "xmlns:xlink": "http://www.w3.org/1999/xlink", version: "1.1" });
          return t.append(e), v(
            g.G,
            {},
            e
          );
        }
        createAnimationLayer(t) {
          var e = v(g.SVG, { class: "blocklyAnimationLayer", xmlns: "http://www.w3.org/2000/svg", "xmlns:html": "http://www.w3.org/1999/xhtml", "xmlns:xlink": "http://www.w3.org/1999/xlink", version: "1.1" });
          return t.append(e), v(g.G, {}, e);
        }
        appendToAnimationLayer(t) {
          var e, i = (e = this.dragLayer) == null ? void 0 : e.getAttribute("transform");
          if (i) {
            let s;
            (s = this.animationLayer) == null || s.setAttribute("transform", i);
          }
          var o;
          (o = this.animationLayer) == null || o.appendChild(t.getSvgRoot());
        }
        translateLayers(t, e) {
          t = `translate(${t.x}, ${t.y}) scale(${e})`;
          var i;
          (i = this.dragLayer) == null || i.setAttribute("transform", t);
          for (let [, o] of this.layers) o.setAttribute("transform", t);
        }
        moveToDragLayer(t, e = !0) {
          var i;
          (i = this.dragLayer) == null || i.appendChild(t.getSvgRoot()), e && t.canBeFocused() && r.t().focusNode(t);
        }
        moveOffDragLayer(t, e, i = !0) {
          this.append(t, e), i && t.canBeFocused() && r.t().focusNode(t);
        }
        append(t, e) {
          this.layers.has(e) || this.createLayer(e), t = t.getSvgRoot();
          var i;
          if (((i = this.layers.get(e)) == null ? void 0 : i.lastChild) !== t) {
            let o;
            (o = this.layers.get(e)) == null || o.appendChild(t);
          }
        }
        createLayer(t) {
          var e = this.workspace.getSvgGroup(), i = v(g.G, {}), o = !1, s = [...this.layers].sort((n, l) => n[0] - l[0]);
          for (let [n, l] of s) if (t < n) {
            e.insertBefore(i, l), o = !0;
            break;
          }
          return o || e.appendChild(i), this.layers.set(t, i), i;
        }
        hasLayer(t) {
          return t === this.dragLayer || new Set(this.layers.values()).has(t);
        }
        getBlockLayer() {
          return this.layers.get(50);
        }
        getBubbleLayer() {
          return this.layers.get(100);
        }
        getDragLayer() {
          return this.dragLayer;
        }
      }, du = {};
      du.register = Nh, du.unregister = function(t) {
        Mi(_.ICON, t);
      };
      var ze = class extends qo {
        constructor(t) {
          super(t), this.sourceBlock = t, this.textInputBubble = null, this.text = "", this.bubbleSize = new H(160, 80), this.bubbleVisiblity = !1;
        }
        getType() {
          return ze.TYPE;
        }
        initView(t) {
          this.svgRoot || (super.initView(t), v(g.CIRCLE, { class: "blocklyIconShape", r: "8", cx: "8", cy: "8" }, this.svgRoot), v(
            g.PATH,
            { class: "blocklyIconSymbol", d: "m6.8,10h2c0.003,-0.617 0.271,-0.962 0.633,-1.266 2.875,-2.4050.607,-5.534 -3.765,-3.874v1.7c3.12,-1.657 3.698,0.118 2.336,1.25-1.201,0.998 -1.201,1.528 -1.204,2.19z" },
            this.svgRoot
          ), v(g.RECT, { class: "blocklyIconSymbol", x: "6.8", y: "10.78", height: "2", width: "2" }, this.svgRoot), b(this.svgRoot, "blocklyCommentIcon"));
        }
        dispose() {
          super.dispose();
          var t;
          (t = this.textInputBubble) == null || t.dispose();
        }
        getWeight() {
          return ze.WEIGHT;
        }
        getSize() {
          return new H(17, 17);
        }
        applyColour() {
          super.applyColour();
          var t = this.sourceBlock.getColour(), e;
          (e = this.textInputBubble) == null || e.setColour(t);
        }
        updateEditable() {
          var t = this, e = () => super.updateEditable;
          return (0, d.asyncExecutePromiseGeneratorFunction)(function* () {
            e().call(t), t.bubbleIsVisible() && (yield t.setBubbleVisible(!1), yield t.setBubbleVisible(!0));
          });
        }
        onLocationChange(t) {
          var e = this.workspaceLocation;
          super.onLocationChange(t), this.bubbleLocation && (t = m.difference(this.workspaceLocation, e), this.bubbleLocation = m.sum(this.bubbleLocation, t)), t = this.getAnchorLocation();
          var i;
          (i = this.textInputBubble) == null || i.setAnchorLocation(t);
        }
        setText(t) {
          var e = this.text;
          N(new (D(p.BLOCK_CHANGE))(this.sourceBlock, "comment", null, e, t)), this.text = t;
          var i;
          (i = this.textInputBubble) == null || i.setText(this.text);
        }
        getText() {
          return this.text;
        }
        setBubbleSize(t) {
          this.bubbleSize = t;
          var e;
          (e = this.textInputBubble) == null || e.setSize(this.bubbleSize, !0);
        }
        getBubbleSize() {
          return this.bubbleSize;
        }
        setBubbleLocation(t) {
          this.bubbleLocation = t;
          var e;
          (e = this.textInputBubble) == null || e.moveDuringDrag(t);
        }
        getBubbleLocation() {
          return this.bubbleLocation;
        }
        saveState() {
          if (this.text) {
            let t = { text: this.text, pinned: this.bubbleIsVisible(), height: this.bubbleSize.height, width: this.bubbleSize.width }, e = this.getBubbleLocation();
            return e && (t.x = this.sourceBlock.workspace.RTL ? this.sourceBlock.workspace.getWidth() - (e.x + this.bubbleSize.width) : e.x, t.y = e.y), t;
          }
          return null;
        }
        loadState(t) {
          var e;
          this.text = (e = t.text) != null ? e : "";
          var i, o;
          this.bubbleSize = new H((i = t.width) != null ? i : 160, (o = t.height) != null ? o : 80);
          var s;
          this.bubbleVisiblity = (s = t.pinned) != null ? s : !1, this.setBubbleVisible(this.bubbleVisiblity);
          var n = t.x, l = t.y;
          te().then(() => {
            n && l && (n = this.sourceBlock.workspace.RTL ? this.sourceBlock.workspace.getWidth() - (n + this.bubbleSize.width) : n, this.setBubbleLocation(new m(n, l)));
          });
        }
        onClick() {
          super.onClick(), this.setBubbleVisible(!this.bubbleIsVisible());
        }
        isClickableInFlyout() {
          return !1;
        }
        onTextChange() {
          if (this.textInputBubble) {
            var t = this.textInputBubble.getText();
            this.text !== t && (N(new (D(p.BLOCK_CHANGE))(this.sourceBlock, "comment", null, this.text, t)), this.text = t);
          }
        }
        onSizeChange() {
          this.textInputBubble && (this.bubbleSize = this.textInputBubble.getSize());
        }
        onBubbleLocationChange() {
          this.textInputBubble && (this.bubbleLocation = this.textInputBubble.getRelativeToSurfaceXY());
        }
        bubbleIsVisible() {
          return this.bubbleVisiblity;
        }
        setBubbleVisible(t) {
          var e = this;
          return (0, d.asyncExecutePromiseGeneratorFunction)(function* () {
            e.bubbleVisiblity !== t && (e.bubbleVisiblity = t, yield te(), !e.sourceBlock.rendered || e.sourceBlock.isInFlyout || e.sourceBlock.isInsertionMarker() || (t ? (e.sourceBlock.isEditable() ? e.showEditableBubble() : e.showNonEditableBubble(), e.applyColour()) : e.hideBubble(), N(new (D(p.BUBBLE_OPEN))(e.sourceBlock, t, "comment")), e.svgRoot && e.recomputeAriaContext()));
          });
        }
        getBubble() {
          return this.textInputBubble;
        }
        showEditableBubble() {
          this.createBubble();
          var t;
          (t = this.textInputBubble) == null || t.addTextChangeListener(() => this.onTextChange());
          var e;
          (e = this.textInputBubble) == null || e.addSizeChangeListener(() => this.onSizeChange());
        }
        showNonEditableBubble() {
          this.createBubble();
          var t;
          (t = this.textInputBubble) == null || t.setEditable(!1);
        }
        createBubble() {
          this.textInputBubble = new ru(this.sourceBlock.workspace, this.getAnchorLocation(), this.getBubbleOwnerRect(), this), this.textInputBubble.getEditor().setParent(this.sourceBlock), this.textInputBubble.setText(this.getText()), this.textInputBubble.setSize(this.bubbleSize, !0), this.bubbleLocation && this.textInputBubble.moveDuringDrag(this.bubbleLocation), this.textInputBubble.addTextChangeListener(() => this.onTextChange()), this.textInputBubble.addSizeChangeListener(() => this.onSizeChange()), this.textInputBubble.addLocationChangeListener(() => this.onBubbleLocationChange()), this.textInputBubble.setAriaLabelProvider(() => r.C.BUBBLE_LABEL_COMMENT.replace("%1", this.getText()));
        }
        hideBubble() {
          var t;
          (t = this.textInputBubble) == null || t.dispose(), this.textInputBubble = null;
        }
        getAnchorLocation() {
          return m.sum(this.workspaceLocation, new m(8.5, 8.5));
        }
        getBubbleOwnerRect() {
          return this.sourceBlock.getBoundingRectangleWithoutChildren();
        }
        getAriaLabel() {
          return this.bubbleIsVisible() ? r.C.ICON_LABEL_COMMENT_OPEN : r.C.ICON_LABEL_COMMENT_CLOSED;
        }
      };
      ze.TYPE = Ct.COMMENT, ze.WEIGHT = 3, Nh(ze.TYPE, ze);
      var Ni = {};
      Ni.CommentIcon = ze, Ni.Icon = qo, Ni.IconType = Ct, Ni.MutatorIcon = r.sh, Ni.WarningIcon = Ve, Ni.exceptions = Vg, Ni.registry = du;
      var gu, Qr;
      r.Cj = class {
        constructor(t, e) {
          this.db = /* @__PURE__ */ new Map(), this.dbReverse = /* @__PURE__ */ new Set(), this.variableMap = null, this.variablePrefix = e || "", this.reservedWords = new Set(t ? t.split(",") : []);
        }
        reset() {
          this.db.clear(), this.dbReverse.clear(), this.variableMap = null;
        }
        setVariableMap(t) {
          this.variableMap = t;
        }
        getNameForUserVariable(t) {
          return this.variableMap ? (t = this.variableMap.getVariableById(t)) ? t.getName() : null : (console.warn(`Deprecated call to Names.prototype.getName without defining a variable map. To fix, add the following code in your generator's init() function:
Blockly.YourGeneratorName.nameDB_.setVariableMap(workspace.getVariableMap());`), null);
        }
        populateVariables(t) {
          t = r.Bd(t);
          for (let e = 0; e < t.length; e++) this.getName(t[e].getId(), r.P.VARIABLE);
        }
        populateProcedures() {
          throw Error("The implementation of populateProcedures should be monkey-patched in by blockly.ts");
        }
        getName(t, e) {
          var i = t;
          e === r.P.VARIABLE && (t = this.getNameForUserVariable(t)) && (i = t), t = i.toLowerCase();
          var o = e === r.P.VARIABLE || e === r.P.DEVELOPER_VARIABLE ? this.variablePrefix : "";
          this.db.has(e) || this.db.set(e, /* @__PURE__ */ new Map());
          var s = this.db.get(e);
          return s.has(t) ? o + s.get(t) : (e = this.getDistinctName(i, e), s.set(t, e.substr(o.length)), e);
        }
        getUserNames(t) {
          var e;
          return (t = (e = this.db.get(t)) == null ? void 0 : e.keys()) ? Array.from(t) : [];
        }
        getDistinctName(t, e) {
          t = this.safeName(t);
          for (var i = null, o, s; this.dbReverse.has(t + ((o = i) != null ? o : "")) || this.reservedWords.has(t + ((s = i) != null ? s : "")); ) i = i ? i + 1 : 2;
          var n;
          return t += (n = i) != null ? n : "", this.dbReverse.add(t), (e === r.P.VARIABLE || e === r.P.DEVELOPER_VARIABLE ? this.variablePrefix : "") + t;
        }
        safeName(t) {
          return t ? (t = encodeURI(t.replace(/ /g, "_")).replace(/[^\w]/g, "_"), "0123456789".includes(t[0]) && (t = "my_" + t)) : t = r.C.UNNAMED_KEY || "unnamed", t;
        }
        static equals(t, e) {
          return t.toLowerCase() === e.toLowerCase();
        }
      }, gu = r.Cj || (r.Cj = {}), Qr = gu.NameType || (gu.NameType = {}), Qr.DEVELOPER_VARIABLE = "DEVELOPER_VARIABLE", Qr.VARIABLE = "VARIABLE", Qr.PROCEDURE = "PROCEDURE", r.P = r.Cj.NameType, r.Cj.DEVELOPER_VARIABLE_TYPE = r.P.DEVELOPER_VARIABLE;
      var mp = class extends Map {
        constructor() {
          super();
        }
        set(t, e) {
          return this.get(t) === e ? this : (super.set(t, e), rr(e) && e.startPublishing(), this);
        }
        delete(t) {
          var e = this.get(t);
          return t = super.delete(t), t && (rr(e) && e.stopPublishing(), t);
        }
        clear() {
          if (this.size) for (let t of this.keys()) this.delete(t);
        }
        add(t) {
          return this.set(t.getId(), t);
        }
        getProcedures() {
          return [...this.values()];
        }
      }, Zt = { CATEGORY_NAME: "PROCEDURE", DEFAULT_ARG: "x" };
      Zt.ObservableProcedureMap = mp, Zt.allProcedures = lr, Zt.findLegalName = r.Bj, Zt.flyoutCategory = ar, Zt.getCallers = Bh, Zt.getDefinition = r.Lj, Zt.isNameUsed = Oh, Zt.isProcedureBlock = vi, Zt.mutateCallers = r.Kj, Zt.mutatorOpenListener = xh, Zt.rename = r.Ej;
      var wf = class {
        constructor() {
          this.NONE = 0, this.FIELD = 1, this.HAT = 2, this.ICON = 4, this.SPACER = 8, this.BETWEEN_ROW_SPACER = 16, this.IN_ROW_SPACER = 32, this.EXTERNAL_VALUE_INPUT = 64, this.INPUT = 128, this.INLINE_INPUT = 256, this.STATEMENT_INPUT = 512, this.CONNECTION = 1024, this.PREVIOUS_CONNECTION = 2048, this.NEXT_CONNECTION = 4096, this.OUTPUT_CONNECTION = 8192, this.CORNER = 16384, this.LEFT_SQUARE_CORNER = 32768, this.LEFT_ROUND_CORNER = 65536, this.RIGHT_SQUARE_CORNER = 131072, this.RIGHT_ROUND_CORNER = 262144, this.JAGGED_EDGE = 524288, this.ROW = 1048576, this.TOP_ROW = 2097152, this.BOTTOM_ROW = 4194304, this.INPUT_ROW = 8388608, this.LEFT_CORNER = this.LEFT_SQUARE_CORNER | this.LEFT_ROUND_CORNER, this.RIGHT_CORNER = this.RIGHT_SQUARE_CORNER | this.RIGHT_ROUND_CORNER, this.nextTypeValue_ = 16777216;
        }
        getType(t) {
          return Object.prototype.hasOwnProperty.call(this, t) || (this[t] = this.nextTypeValue_, this.nextTypeValue_ <<= 1), this[t];
        }
        isField(t) {
          return (t.type & this.FIELD) >= 1;
        }
        isHat(t) {
          return (t.type & this.HAT) >= 1;
        }
        isIcon(t) {
          return (t.type & this.ICON) >= 1;
        }
        isSpacer(t) {
          return (t.type & this.SPACER) >= 1;
        }
        isInRowSpacer(t) {
          return (t.type & this.IN_ROW_SPACER) >= 1;
        }
        isSpacerRow(t) {
          return (t.type & this.BETWEEN_ROW_SPACER) >= 1;
        }
        isInput(t) {
          return (t.type & this.INPUT) >= 1;
        }
        isExternalInput(t) {
          return (t.type & this.EXTERNAL_VALUE_INPUT) >= 1;
        }
        isInlineInput(t) {
          return (t.type & this.INLINE_INPUT) >= 1;
        }
        isStatementInput(t) {
          return (t.type & this.STATEMENT_INPUT) >= 1;
        }
        isPreviousConnection(t) {
          return (t.type & this.PREVIOUS_CONNECTION) >= 1;
        }
        isNextConnection(t) {
          return (t.type & this.NEXT_CONNECTION) >= 1;
        }
        isPreviousOrNextConnection(t) {
          return this.isPreviousConnection(t) || this.isNextConnection(t);
        }
        isRoundCorner(t) {
          return (t.type & this.LEFT_ROUND_CORNER) >= 1 || (t.type & this.RIGHT_ROUND_CORNER) >= 1;
        }
        isLeftRoundedCorner(t) {
          return this.isRoundCorner(t) && (t.type & this.LEFT_ROUND_CORNER) >= 1;
        }
        isRightRoundedCorner(t) {
          return this.isRoundCorner(t) && (t.type & this.RIGHT_ROUND_CORNER) >= 1;
        }
        isLeftSquareCorner(t) {
          return (t.type & this.LEFT_SQUARE_CORNER) >= 1;
        }
        isRightSquareCorner(t) {
          return (t.type & this.RIGHT_SQUARE_CORNER) >= 1;
        }
        isCorner(t) {
          return (t.type & this.CORNER) >= 1;
        }
        isJaggedEdge(t) {
          return (t.type & this.JAGGED_EDGE) >= 1;
        }
        isRow(t) {
          return (t.type & this.ROW) >= 1;
        }
        isBetweenRowSpacer(t) {
          return (t.type & this.BETWEEN_ROW_SPACER) >= 1;
        }
        isTopRow(t) {
          return (t.type & this.TOP_ROW) >= 1;
        }
        isBottomRow(t) {
          return (t.type & this.BOTTOM_ROW) >= 1;
        }
        isTopOrBottomRow(t) {
          return this.isTopRow(t) || this.isBottomRow(t);
        }
        isInputRow(t) {
          return (t.type & this.INPUT_ROW) >= 1;
        }
      }, u = new wf(), Ke = class {
        constructor(t) {
          this.centerline = this.xPos = this.height = this.width = 0, this.constants_ = t, this.type = u.NONE, this.notchOffset = this.constants_.NOTCH_OFFSET_LEFT;
        }
      }, tn = class {
        constructor(t) {
          this.elements = [], this.xPos = this.yPos = this.widthWithConnectedBlocks = this.minWidth = this.minHeight = this.width = this.height = 0, this.hasStatement = this.hasExternalInput = !1, this.statementEdge = 0, this.hasJaggedEdge = this.hasDummyInput = this.hasInlineInput = !1, this.align = null, this.constants_ = t, this.type = u.ROW, this.notchOffset = this.constants_.NOTCH_OFFSET_LEFT;
        }
        getLastInput() {
          for (let t = this.elements.length - 1; t >= 0; t--) {
            let e = this.elements[t];
            if (u.isInput(e)) return e;
          }
          return null;
        }
        measure() {
          throw Error("Unexpected attempt to measure a base Row.");
        }
        startsWithElemSpacer() {
          return !0;
        }
        endsWithElemSpacer() {
          return !0;
        }
        getFirstSpacer() {
          for (let t = 0; t < this.elements.length; t++) {
            let e = this.elements[t];
            if (u.isInRowSpacer(e)) return e;
          }
          return null;
        }
        getLastSpacer() {
          for (let t = this.elements.length - 1; t >= 0; t--) {
            let e = this.elements[t];
            if (u.isInRowSpacer(e)) return e;
          }
          return null;
        }
      }, pu = class extends tn {
        constructor(t) {
          super(t), this.hasNextConnection = !1, this.connection = null, this.baseline = this.descenderHeight = 0, this.type |= u.BOTTOM_ROW;
        }
        hasLeftSquareCorner(t) {
          return !!t.outputConnection || !!t.getNextBlock();
        }
        hasRightSquareCorner() {
          return !0;
        }
        measure() {
          var t = 0, e = 0, i = 0;
          for (let o = 0; o < this.elements.length; o++) {
            let s = this.elements[o];
            e += s.width, u.isSpacer(s) || (u.isNextConnection(s) ? i = Math.max(i, s.height) : t = Math.max(t, s.height));
          }
          this.width = Math.max(this.minWidth, e), this.height = Math.max(
            this.minHeight,
            t
          ) + i, this.descenderHeight = i, this.widthWithConnectedBlocks = this.width;
        }
        startsWithElemSpacer() {
          return !1;
        }
        endsWithElemSpacer() {
          return !1;
        }
      }, po = class extends Ke {
        constructor(t, e) {
          super(t), this.connectionModel = e, this.type |= u.CONNECTION, this.shape = this.constants_.shapeFor(e), this.isDynamicShape = "isDynamic" in this.shape && this.shape.isDynamic, this.highlighted = e.isHighlighted();
        }
      }, tl = class extends po {
        constructor(t, e) {
          super(t, e.connection), this.input = e, this.connectionOffsetY = this.connectionOffsetX = 0, this.type |= u.INPUT, this.align = e.align, this.connectedBlock = e.connection && e.connection.targetBlock() ? e.connection.targetBlock() : null, t = e.connection.getInsertionMarker(), this.connectedBlockHeight = this.connectedBlockWidth = 0, this.connectedBlock && (e = this.connectedBlock.getHeightWidth(), this.connectedBlockWidth = e.width, this.connectedBlockHeight = e.height), t && (t = t.getHeightWidth(), this.connectedBlockWidth += t.width, this.connectedBlockHeight += t.height);
        }
      }, fu = class extends tl {
        constructor(t, e) {
          super(t, e), this.height = 0, this.type |= u.EXTERNAL_VALUE_INPUT, this.connectedBlockHeight ? ((t = this.connectionModel.getInsertionMarker()) && (this.connectedBlockHeight = t.getHeightWidth().height), this.height = this.connectedBlockHeight - this.constants_.TAB_OFFSET_FROM_TOP - this.constants_.MEDIUM_PADDING) : this.height = this.shape.height, this.width = this.shape.width + this.constants_.EXTERNAL_VALUE_INPUT_PADDING, this.connectionOffsetY = this.constants_.TAB_OFFSET_FROM_TOP, this.connectionHeight = this.shape.height, this.connectionWidth = this.shape.width;
        }
      }, Eu = class extends Ke {
        constructor(t, e, i) {
          super(t), this.field = e, this.parentInput = i, this.isEditable = e.EDITABLE, this.flipRtl = e.getFlipRtl(), this.type |= u.FIELD, t = this.field.getSize(), this.height = t.height, this.width = t.width;
        }
      }, Tp = class extends Ke {
        constructor(t) {
          super(t), this.type |= u.HAT, this.height = this.constants_.START_HAT.height, this.width = this.constants_.START_HAT.width, this.ascenderHeight = this.height;
        }
      }, Cp = class extends Ke {
        constructor(t, e) {
          super(t), this.icon = e, this.flipRtl = !1, this.type |= u.ICON, t = e.getSize(), this.height = t.height, this.width = t.width;
        }
      }, he = class extends Ke {
        constructor(t, e) {
          super(t), this.type |= u.SPACER | u.IN_ROW_SPACER, this.width = e, this.height = this.constants_.SPACER_DEFAULT_HEIGHT;
        }
      }, vu = class extends tl {
        constructor(t, e) {
          super(t, e), this.type |= u.INLINE_INPUT, this.connectedBlockWidth || this.connectedBlockHeight ? (this.width = this.connectedBlockWidth, this.height = this.connectedBlockHeight) : (this.height = this.constants_.EMPTY_INLINE_INPUT_HEIGHT, this.width = this.constants_.EMPTY_INLINE_INPUT_PADDING), this.connectionHeight = this.isDynamicShape ? this.shape.height(this.height) : this.shape.height, this.connectionWidth = this.isDynamicShape ? this.shape.width(this.height) : this.shape.width, this.connectedBlockHeight || (this.width += this.connectionWidth * (this.isDynamicShape ? 2 : 1)), this.connectionOffsetY = "connectionOffsetY" in this.shape ? this.shape.connectionOffsetY(this.connectionHeight) : this.constants_.TAB_OFFSET_FROM_TOP, this.connectionOffsetX = "connectionOffsetX" in this.shape ? this.shape.connectionOffsetX(this.connectionWidth) : 0;
        }
      }, _u = class extends tn {
        constructor(t) {
          super(t), this.connectedBlockWidths = 0, this.type |= u.INPUT_ROW;
        }
        measure() {
          this.width = this.minWidth, this.height = this.minHeight;
          var t = 0;
          for (let e = 0; e < this.elements.length; e++) {
            let i = this.elements[e];
            this.width += i.width, u.isInput(i) && (u.isStatementInput(i) ? t += i.connectedBlockWidth : u.isExternalInput(i) && i.connectedBlockWidth !== 0 && (t += i.connectedBlockWidth - i.connectionWidth)), u.isSpacer(i) || (this.height = Math.max(this.height, i.height));
          }
          this.connectedBlockWidths = t, this.widthWithConnectedBlocks = this.width + t;
        }
        endsWithElemSpacer() {
          return !this.hasExternalInput && !this.hasStatement;
        }
      }, yp = class extends Ke {
        constructor(t) {
          super(t), this.type |= u.JAGGED_EDGE, this.height = this.constants_.JAGGED_TEETH.height, this.width = this.constants_.JAGGED_TEETH.width;
        }
      }, bp = class extends po {
        constructor(t, e) {
          super(t, e), this.type |= u.NEXT_CONNECTION, this.height = this.shape.height, this.width = this.shape.width, (t = e.getInsertionMarker()) && (this.height += t.getHeightWidth().height);
        }
      }, kp = class extends po {
        constructor(t, e) {
          super(t, e), this.connectionOffsetX = 0, this.type |= u.OUTPUT_CONNECTION, this.height = this.isDynamicShape ? 0 : this.shape.height, this.startX = this.width = this.isDynamicShape ? 0 : this.shape.width, this.connectionOffsetY = this.constants_.TAB_OFFSET_FROM_TOP;
        }
      }, wp = class extends po {
        constructor(t, e) {
          super(t, e), this.type |= u.PREVIOUS_CONNECTION, this.height = this.shape.height, this.width = this.shape.width;
        }
      }, en = class extends Ke {
        constructor(t, e) {
          super(t), this.type = (e && e !== "left" ? u.RIGHT_ROUND_CORNER : u.LEFT_ROUND_CORNER) | u.CORNER, this.width = this.constants_.CORNER_RADIUS, this.height = this.constants_.CORNER_RADIUS / 2;
        }
      }, mu = class extends tn {
        constructor(t, e, i) {
          super(t), this.height = e, this.width = i, this.precedesStatement = this.followsStatement = !1, this.widthWithConnectedBlocks = 0, this.type |= u.SPACER | u.BETWEEN_ROW_SPACER, this.elements = [new he(this.constants_, i)];
        }
        measure() {
        }
      }, on = class extends Ke {
        constructor(t, e) {
          super(t), this.type = (e && e !== "left" ? u.RIGHT_SQUARE_CORNER : u.LEFT_SQUARE_CORNER) | u.CORNER, this.width = this.height = this.constants_.NO_PADDING;
        }
      }, el = class extends tl {
        constructor(t, e) {
          super(t, e), this.type |= u.STATEMENT_INPUT, this.height = this.connectedBlockHeight ? this.connectedBlockHeight + this.constants_.STATEMENT_BOTTOM_SPACER : this.constants_.EMPTY_STATEMENT_INPUT_HEIGHT, this.width = this.constants_.STATEMENT_INPUT_NOTCH_OFFSET + this.shape.width;
        }
      }, Tu = class extends tn {
        constructor(t) {
          super(t), this.ascenderHeight = this.capline = 0, this.hasPreviousConnection = !1, this.connection = null, this.type |= u.TOP_ROW;
        }
        hasLeftSquareCorner(t) {
          var e = (t.hat ? t.hat === "cap" : this.constants_.ADD_START_HATS) && !t.outputConnection && !t.previousConnection, i = t.getPreviousBlock();
          return !!t.outputConnection || e || (i ? i.getNextBlock() === t : !1);
        }
        hasRightSquareCorner() {
          return !0;
        }
        measure() {
          var t = 0, e = 0, i = 0;
          for (let o = 0; o < this.elements.length; o++) {
            let s = this.elements[o];
            e += s.width, u.isSpacer(s) || (u.isHat(s) ? i = Math.max(i, s.ascenderHeight) : t = Math.max(t, s.height));
          }
          this.width = Math.max(this.minWidth, e), this.height = Math.max(this.minHeight, t) + i, this.capline = this.ascenderHeight = i, this.widthWithConnectedBlocks = this.width;
        }
        startsWithElemSpacer() {
          return !1;
        }
        endsWithElemSpacer() {
          return !1;
        }
      }, Cu = /* @__PURE__ */ new Map(), il = class {
        constructor() {
          this.NO_PADDING = 0, this.SMALL_PADDING = 3, this.MEDIUM_PADDING = 5, this.MEDIUM_LARGE_PADDING = 8, this.LARGE_PADDING = 10, this.TAB_HEIGHT = 15, this.TAB_OFFSET_FROM_TOP = 5, this.TAB_VERTICAL_OVERLAP = 2.5, this.TAB_WIDTH = 8, this.NOTCH_WIDTH = 15, this.NOTCH_HEIGHT = 4, this.MIN_BLOCK_WIDTH = 12, this.EMPTY_BLOCK_SPACER_HEIGHT = 16, this.CORNER_RADIUS = 8, this.NOTCH_OFFSET_LEFT = 15, this.STATEMENT_BOTTOM_SPACER = 0, this.STATEMENT_INPUT_PADDING_LEFT = 20, this.BETWEEN_STATEMENT_PADDING_Y = 4, this.ADD_START_HATS = !1, this.START_HAT_HEIGHT = 15, this.START_HAT_WIDTH = 100, this.SPACER_DEFAULT_HEIGHT = 15, this.MIN_BLOCK_HEIGHT = 24, this.EMPTY_INLINE_INPUT_PADDING = 14.5, this.EXTERNAL_VALUE_INPUT_PADDING = 2, this.JAGGED_TEETH_HEIGHT = 12, this.JAGGED_TEETH_WIDTH = 6, this.FIELD_TEXT_FONTSIZE = 11, this.FIELD_TEXT_FONTWEIGHT = "normal", this.FIELD_TEXT_FONTFAMILY = "sans-serif", this.FIELD_TEXT_BASELINE = this.FIELD_TEXT_HEIGHT = -1, this.FIELD_BORDER_RECT_RADIUS = 4, this.FIELD_BORDER_RECT_HEIGHT = 16, this.FIELD_BORDER_RECT_X_PADDING = 5, this.FIELD_BORDER_RECT_Y_PADDING = 3, this.FIELD_BORDER_RECT_COLOUR = "#fff", this.FIELD_DROPDOWN_SVG_ARROW = this.FIELD_DROPDOWN_COLOURED_DIV = this.FIELD_DROPDOWN_NO_BORDER_RECT_SHADOW = !1, this.FIELD_DROPDOWN_SVG_ARROW_SIZE = 12, this.FIELD_COLOUR_FULL_BLOCK = this.FIELD_TEXTINPUT_BOX_SHADOW = !1, this.FIELD_COLOUR_DEFAULT_WIDTH = 26, this.defs = null, this.embossFilterId = "", this.embossFilter = null, this.disabledPatternId = "", this.disabledPattern = null, this.debugFilterId = "", this.debugFilter = null, this.CURSOR_COLOUR = "#cc0a0a", this.MARKER_COLOUR = "#4286f4", this.CURSOR_WS_WIDTH = 100, this.WS_CURSOR_HEIGHT = 5, this.CURSOR_STACK_PADDING = 10, this.CURSOR_BLOCK_PADDING = 2, this.CURSOR_STROKE_WIDTH = 4, this.FULL_BLOCK_FIELDS = !1, this.INSERTION_MARKER_COLOUR = "#000000", this.INSERTION_MARKER_OPACITY = 0.2, this.SHAPES = { PUZZLE: 1, NOTCH: 2 }, this.TALL_INPUT_FIELD_OFFSET_Y = this.MEDIUM_PADDING, this.DUMMY_INPUT_SHADOW_MIN_HEIGHT = this.DUMMY_INPUT_MIN_HEIGHT = this.TAB_HEIGHT, this.STATEMENT_INPUT_NOTCH_OFFSET = this.NOTCH_OFFSET_LEFT, this.TOP_ROW_MIN_HEIGHT = this.MEDIUM_PADDING, this.TOP_ROW_PRECEDES_STATEMENT_MIN_HEIGHT = this.LARGE_PADDING, this.BOTTOM_ROW_MIN_HEIGHT = this.MEDIUM_PADDING, this.BOTTOM_ROW_AFTER_STATEMENT_MIN_HEIGHT = this.LARGE_PADDING, this.EMPTY_INLINE_INPUT_HEIGHT = this.TAB_HEIGHT + 11, this.EMPTY_STATEMENT_INPUT_HEIGHT = this.MIN_BLOCK_HEIGHT, this.START_POINT = ct(0, 0), this.FIELD_TEXT_BASELINE_CENTER = !0, this.FIELD_DROPDOWN_BORDER_RECT_HEIGHT = this.FIELD_BORDER_RECT_HEIGHT, this.FIELD_DROPDOWN_SVG_ARROW_PADDING = this.FIELD_BORDER_RECT_X_PADDING, this.FIELD_DROPDOWN_SVG_ARROW_DATAURI = "data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMi43MSIgaGVpZ2h0PSI4Ljc5IiB2aWV3Qm94PSIwIDAgMTIuNzEgOC43OSI+PHRpdGxlPmRyb3Bkb3duLWFycm93PC90aXRsZT48ZyBvcGFjaXR5PSIwLjEiPjxwYXRoIGQ9Ik0xMi43MSwyLjQ0QTIuNDEsMi40MSwwLDAsMSwxMiw0LjE2TDguMDgsOC4wOGEyLjQ1LDIuNDUsMCwwLDEtMy40NSwwTDAuNzIsNC4xNkEyLjQyLDIuNDIsMCwwLDEsMCwyLjQ0LDIuNDgsMi40OCwwLDAsMSwuNzEuNzFDMSwwLjQ3LDEuNDMsMCw2LjM2LDBTMTEuNzUsMC40NiwxMiwuNzFBMi40NCwyLjQ0LDAsMCwxLDEyLjcxLDIuNDRaIiBmaWxsPSIjMjMxZjIwIi8+PC9nPjxwYXRoIGQ9Ik02LjM2LDcuNzlhMS40MywxLjQzLDAsMCwxLTEtLjQyTDEuNDIsMy40NWExLjQ0LDEuNDQsMCwwLDEsMC0yYzAuNTYtLjU2LDkuMzEtMC41Niw5Ljg3LDBhMS40NCwxLjQ0LDAsMCwxLDAsMkw3LjM3LDcuMzdBMS40MywxLjQzLDAsMCwxLDYuMzYsNy43OVoiIGZpbGw9IiNmZmYiLz48L3N2Zz4=", this.FIELD_COLOUR_DEFAULT_HEIGHT = this.FIELD_BORDER_RECT_HEIGHT, this.FIELD_CHECKBOX_X_OFFSET = this.FIELD_BORDER_RECT_X_PADDING - 3, this.randomIdentifier = String(Math.random()).substring(2);
        }
        init() {
          this.JAGGED_TEETH = this.makeJaggedTeeth(), this.NOTCH = this.makeNotch(), this.START_HAT = this.makeStartHat(), this.PUZZLE_TAB = this.makePuzzleTab(), this.INSIDE_CORNERS = this.makeInsideCorners(), this.OUTSIDE_CORNERS = this.makeOutsideCorners();
        }
        setTheme(t) {
          this.blockStyles = /* @__PURE__ */ Object.create(null);
          var e = t.blockStyles;
          for (let i in e) this.blockStyles[i] = this.validatedBlockStyle_(e[i]);
          this.setDynamicProperties_(t);
        }
        setDynamicProperties_(t) {
          this.setFontConstants_(t), this.setComponentConstants_(t), this.ADD_START_HATS = t.startHats !== void 0 ? t.startHats : this.ADD_START_HATS;
        }
        setFontConstants_(t) {
          t.fontStyle && t.fontStyle.family && (this.FIELD_TEXT_FONTFAMILY = t.fontStyle.family), t.fontStyle && t.fontStyle.weight && (this.FIELD_TEXT_FONTWEIGHT = t.fontStyle.weight), t.fontStyle && t.fontStyle.size && (this.FIELD_TEXT_FONTSIZE = t.fontStyle.size), t = dn("Hg", this.FIELD_TEXT_FONTSIZE + "pt", this.FIELD_TEXT_FONTWEIGHT, this.FIELD_TEXT_FONTFAMILY), this.FIELD_TEXT_HEIGHT = t.height, this.FIELD_TEXT_BASELINE = t.baseline;
        }
        setComponentConstants_(t) {
          this.CURSOR_COLOUR = t.getComponentStyle("cursorColour") || this.CURSOR_COLOUR, this.MARKER_COLOUR = t.getComponentStyle("markerColour") || this.MARKER_COLOUR, this.INSERTION_MARKER_COLOUR = t.getComponentStyle("insertionMarkerColour") || this.INSERTION_MARKER_COLOUR, this.INSERTION_MARKER_OPACITY = Number(t.getComponentStyle("insertionMarkerOpacity")) || this.INSERTION_MARKER_OPACITY;
        }
        getBlockStyleForColour(t) {
          var e = "auto_" + t;
          return this.blockStyles[e] || (this.blockStyles[e] = this.createBlockStyle_(t)), { style: this.blockStyles[e], name: e };
        }
        getBlockStyle(t) {
          return this.blockStyles[t || ""] || (t && t.startsWith("auto_") ? this.getBlockStyleForColour(t.substring(5)).style : this.createBlockStyle_("#000000"));
        }
        createBlockStyle_(t) {
          return this.validatedBlockStyle_({ colourPrimary: t });
        }
        validatedBlockStyle_(t) {
          var e = {};
          return t && Object.assign(e, t), t = Oo(e.colourPrimary || "#000"), e.colourPrimary = t.hex, e.colourSecondary = e.colourSecondary ? Oo(e.colourSecondary).hex : this.generateSecondaryColour_(e.colourPrimary), e.colourTertiary = e.colourTertiary ? Oo(e.colourTertiary).hex : this.generateTertiaryColour_(e.colourPrimary), e.hat = e.hat || "", e;
        }
        generateSecondaryColour_(t) {
          return Wi("#fff", t, 0.6) || t;
        }
        generateTertiaryColour_(t) {
          return Wi("#fff", t, 0.3) || t;
        }
        dispose() {
          this.embossFilter && Q(this.embossFilter), this.disabledPattern && Q(this.disabledPattern), this.debugFilter && Q(this.debugFilter);
        }
        makeJaggedTeeth() {
          var t = this.JAGGED_TEETH_HEIGHT, e = this.JAGGED_TEETH_WIDTH, i = Bo([R(
            e,
            t / 4
          ), R(-e * 2, t / 2), R(e, t / 4)]);
          return { height: t, width: e, path: i };
        }
        makeStartHat() {
          var t = this.START_HAT_HEIGHT, e = this.START_HAT_WIDTH, i = $t("c", [R(30, -t), R(70, -t), R(e, 0)]);
          return { height: t * 0.75, width: e, path: i };
        }
        makePuzzleTab() {
          function t(n) {
            n = n ? -1 : 1;
            var l = -n, a = i / 2, c = a + 2.5, E = a + 0.5, O = R(-e, n * a);
            return a = R(e, n * a), $t("c", [R(0, n * c), R(-e, l * E), O]) + $t("s", [R(e, l * 2.5), a]);
          }
          var e = this.TAB_WIDTH, i = this.TAB_HEIGHT, o = t(!0), s = t(!1);
          return { type: this.SHAPES.PUZZLE, width: e, height: i, pathDown: s, pathUp: o };
        }
        makeNotch() {
          function t(l) {
            return Bo([R(l * o, i), R(l * 3, 0), R(l * o, -i)]);
          }
          var e = this.NOTCH_WIDTH, i = this.NOTCH_HEIGHT, o = (e - 3) / 2, s = t(1), n = t(-1);
          return { type: this.SHAPES.NOTCH, width: e, height: i, pathLeft: s, pathRight: n };
        }
        makeInsideCorners() {
          var t = this.CORNER_RADIUS, e = dt("a", "0 0,0", t, R(-t, t)), i = dt("a", "0 0,0", t, R(t, t));
          return { width: t, height: t, pathTop: e, pathBottom: i };
        }
        makeOutsideCorners() {
          var t = this.CORNER_RADIUS, e = ct(0, t) + dt("a", "0 0,1", t, R(t, -t)), i = dt("a", "0 0,1", t, R(t, t)), o = dt("a", "0 0,1", t, R(-t, -t)), s = dt("a", "0 0,1", t, R(-t, t));
          return {
            topLeft: e,
            topRight: i,
            bottomRight: s,
            bottomLeft: o,
            rightHeight: t
          };
        }
        shapeFor(t) {
          switch (t.type) {
            case T.INPUT_VALUE:
            case T.OUTPUT_VALUE:
              return this.PUZZLE_TAB;
            case T.PREVIOUS_STATEMENT:
            case T.NEXT_STATEMENT:
              return this.NOTCH;
            default:
              throw Error("Unknown connection type");
          }
        }
        createDom(t, e, i) {
          if (i) {
            let o = i.getRootNode();
            this.injectCSS_(o, e);
          }
          this.defs = v(g.DEFS, {}, t), t = v(g.FILTER, { id: "blocklyEmbossFilter" + this.randomIdentifier }, this.defs), v(g.FEGAUSSIANBLUR, { in: "SourceAlpha", stdDeviation: 1, result: "blur" }, t), e = v(
            g.FESPECULARLIGHTING,
            { in: "blur", surfaceScale: 1, specularConstant: 0.5, specularExponent: 10, "lighting-color": "white", result: "specOut" },
            t
          ), v(g.FEPOINTLIGHT, { x: -5e3, y: -1e4, z: 2e4 }, e), v(g.FECOMPOSITE, { in: "specOut", in2: "SourceAlpha", operator: "in", result: "specOut" }, t), v(g.FECOMPOSITE, { in: "SourceGraphic", in2: "specOut", operator: "arithmetic", k1: 0, k2: 1, k3: 1, k4: 0 }, t), this.embossFilterId = t.id, this.embossFilter = t, t = v(g.PATTERN, { id: "blocklyDisabledPattern" + this.randomIdentifier, patternUnits: "userSpaceOnUse", width: 10, height: 10 }, this.defs), v(g.RECT, { width: 10, height: 10, fill: "#aaa" }, t), v(g.PATH, { d: "M 0 0 L 10 10 M 10 0 L 0 10", stroke: "#cc0" }, t), this.disabledPatternId = t.id, this.disabledPattern = t, this.createDebugFilter(), i && (i.style.setProperty("--blocklyEmbossFilter", `url(#${this.embossFilterId})`), i.style.setProperty("--blocklyDisabledPattern", `url(#${this.disabledPatternId})`), i.style.setProperty("--blocklyDebugFilter", `url(#${this.debugFilterId})`));
        }
        createDebugFilter() {
          if (!this.debugFilter) {
            let t = v(g.FILTER, { id: "blocklyDebugFilter" + this.randomIdentifier, height: "160%", width: "180%", y: "-30%", x: "-40%" }, this.defs), e = v(g.FECOMPONENTTRANSFER, { result: "outBlur" }, t);
            v(g.FEFUNCA, { type: "table", tableValues: "0 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1" }, e), v(g.FEFLOOD, { "flood-color": "#ff0000", "flood-opacity": 0.5, result: "outColor" }, t), v(g.FECOMPOSITE, { in: "outColor", in2: "outBlur", operator: "in", result: "outGlow" }, t), this.debugFilterId = t.id, this.debugFilter = t;
          }
        }
        injectCSS_(t, e) {
          if (typeof window < "u") {
            var i;
            if ((i = Cu.get(e)) == null || !i.has(t)) {
              i = document.createElement("style"), i.className = "blockly-renderer-style", i.textContent = this.getCSS_(e).join(`
`), (typeof globalThis.ShadowRoot < "u" && t instanceof ShadowRoot ? t : document.head).prepend(i);
              var o;
              i = (o = Cu.get(e)) != null ? o : /* @__PURE__ */ new WeakSet(), i.add(t), Cu.set(e, i);
            }
          }
        }
        getCSS_(t) {
          return [
            `${t}.injectionDiv {`,
            "--blockly-active-node-color: #fc3;",
            "}",
            `${t} .blocklyText, `,
            `${t} .blocklyFlyoutLabelText {`,
            `font: ${this.FIELD_TEXT_FONTWEIGHT} ${this.FIELD_TEXT_FONTSIZE}pt ${this.FIELD_TEXT_FONTFAMILY};`,
            "}",
            `${t} .blocklyText {`,
            "fill: #fff;",
            "}",
            `${t} .blocklyNonEditableField>rect,`,
            `${t} .blocklyEditableField>rect {`,
            `fill: ${this.FIELD_BORDER_RECT_COLOUR};`,
            "fill-opacity: .6;",
            "stroke: none;",
            "}",
            `${t} .blocklyNonEditableField>text,`,
            `${t} .blocklyEditableField>text {`,
            "fill: #000;",
            "}",
            `${t} .blocklyFlyoutLabelText {`,
            "fill: #000;",
            "}",
            `${t} .blocklyText.blocklyBubbleText {`,
            "fill: #000;",
            "}",
            `${t} .blocklyEditableField:not(.blocklyEditing):hover>rect {`,
            "stroke: #fff;",
            "stroke-width: 2;",
            "}",
            `${t} .blocklyHtmlInput {`,
            `font-family: ${this.FIELD_TEXT_FONTFAMILY};`,
            `font-weight: ${this.FIELD_TEXT_FONTWEIGHT};`,
            "}",
            `${t} .blocklySelected>.blocklyPath {`,
            "stroke: #fc3;",
            "stroke-width: 3px;",
            "}",
            `${t} .blocklyHighlightedConnectionPathVisible {`,
            "stroke: #fc3;",
            "}",
            `${t} .blocklyReplaceable .blocklyPath {`,
            "fill-opacity: .5;",
            "}",
            `${t} .blocklyReplaceable .blocklyPathLight,`,
            `${t} .blocklyReplaceable .blocklyPathDark {`,
            "display: none;",
            "}",
            `${t} .blocklyInsertionMarker>.blocklyPath {`,
            `fill-opacity: ${this.INSERTION_MARKER_OPACITY};`,
            "stroke: none;",
            "}"
          ];
        }
      }, ol = class {
        constructor(t, e) {
          this.inlinePath_ = this.outlinePath_ = "", this.block_ = t, this.info_ = e, this.topLeft_ = t.getRelativeToSurfaceXY(), this.constants_ = e.getRenderer().getConstants();
        }
        draw() {
          this.drawOutline_(), this.drawInternals_(), this.updateConnectionHighlights(), this.block_.pathObject.setPath(this.outlinePath_ + `
` + this.inlinePath_), this.info_.RTL && this.block_.pathObject.flipRTL(), this.recordSizeOnBlock_();
        }
        recordSizeOnBlock_() {
          this.block_.height = this.info_.height, this.block_.width = this.info_.widthWithChildren, this.block_.childlessWidth = this.info_.width;
        }
        drawOutline_() {
          this.drawTop_();
          for (let t = 1; t < this.info_.rows.length - 1; t++) {
            let e = this.info_.rows[t];
            e.hasJaggedEdge ? this.drawJaggedEdge_(e) : e.hasStatement ? this.drawStatementInput_(e) : e.hasExternalInput ? this.drawValueInput_(e) : this.drawRightSideRow_(e);
          }
          this.drawBottom_(), this.drawLeft_();
        }
        drawTop_() {
          var t = this.info_.topRow, e = t.elements;
          this.positionPreviousConnection_(), this.outlinePath_ += ct(t.xPos, this.info_.startY);
          for (let i = 0, o; o = e[i]; i++) u.isLeftRoundedCorner(o) ? this.outlinePath_ += this.constants_.OUTSIDE_CORNERS.topLeft : u.isRightRoundedCorner(o) ? this.outlinePath_ += this.constants_.OUTSIDE_CORNERS.topRight : u.isPreviousConnection(o) ? this.outlinePath_ += o.shape.pathLeft : u.isHat(o) ? this.outlinePath_ += this.constants_.START_HAT.path : u.isSpacer(o) && (this.outlinePath_ += A("h", o.width));
          this.outlinePath_ += A("v", t.height - t.ascenderHeight);
        }
        drawJaggedEdge_(t) {
          this.outlinePath_ += this.constants_.JAGGED_TEETH.path + A("v", t.height - this.constants_.JAGGED_TEETH.height);
        }
        drawValueInput_(t) {
          var e = t.getLastInput();
          this.positionExternalValueConnection_(t);
          var i = e.shape.isDynamic ? e.shape.pathDown(e.height) : e.shape.pathDown;
          this.outlinePath_ += A("H", e.xPos + e.width) + i + A("v", t.height - e.connectionHeight);
        }
        drawStatementInput_(t) {
          var e = t.getLastInput();
          if (e) {
            var i = e.xPos + e.notchOffset + e.shape.width;
            e = e.shape.pathRight + A("h", -(e.notchOffset - this.constants_.INSIDE_CORNERS.width)) + this.constants_.INSIDE_CORNERS.pathTop;
            var o = t.height - 2 * this.constants_.INSIDE_CORNERS.height;
            this.outlinePath_ += A("H", i) + e + A("v", o) + this.constants_.INSIDE_CORNERS.pathBottom + A("H", t.xPos + t.width), this.positionStatementInputConnection_(t);
          }
        }
        drawRightSideRow_(t) {
          this.outlinePath_ += A("V", t.yPos + t.height);
        }
        drawBottom_() {
          var t = this.info_.bottomRow, e = t.elements;
          this.positionNextConnection_();
          var i = 0, o = "";
          for (let s = e.length - 1, n; n = e[s]; s--) u.isNextConnection(n) ? o += n.shape.pathRight : u.isLeftSquareCorner(n) ? o += A("H", t.xPos) : u.isLeftRoundedCorner(n) ? o += this.constants_.OUTSIDE_CORNERS.bottomLeft : u.isRightRoundedCorner(n) ? (o += this.constants_.OUTSIDE_CORNERS.bottomRight, i = this.constants_.OUTSIDE_CORNERS.rightHeight) : u.isSpacer(n) && (o += A("h", n.width * -1));
          this.outlinePath_ += A("V", t.baseline - i), this.outlinePath_ += o;
        }
        drawLeft_() {
          var t = this.info_.outputConnection;
          if (this.positionOutputConnection_(), t) {
            let e = t.connectionOffsetY + t.height;
            t = t.shape.isDynamic ? t.shape.pathUp(t.height) : t.shape.pathUp, this.outlinePath_ += A("V", e) + t;
          }
          this.outlinePath_ += "z";
        }
        drawInternals_() {
          for (let t = 0, e; e = this.info_.rows[t]; t++) for (let i = 0, o; o = e.elements[i]; i++) u.isInlineInput(o) ? this.drawInlineInput_(o) : (u.isIcon(o) || u.isField(o)) && this.layoutField_(o);
        }
        layoutField_(t) {
          var e = t.centerline - t.height / 2, i = t.xPos, o = "";
          this.info_.RTL && (i = -(i + t.width), t.flipRtl && (i += t.width, o = "scale(-1 1)")), u.isIcon(t) ? (o = t.icon, o.setOffsetInBlock(new m(i, e)), this.info_.isInsertionMarker && o.hideForInsertionMarker()) : (t = t.field.getSvgRoot(), t.setAttribute("transform", "translate(" + i + "," + e + ")" + o), this.info_.isInsertionMarker && t.setAttribute("display", "none"));
        }
        drawInlineInput_(t) {
          var e = t.width, i = t.height, o = t.connectionOffsetY, s = t.connectionHeight + o;
          this.inlinePath_ += St(t.xPos + t.connectionWidth, t.centerline - i / 2) + A("v", o) + t.shape.pathDown + A("v", i - s) + A("h", e - t.connectionWidth) + A("v", -i) + "z", this.positionInlineInputConnection_(t);
        }
        positionInlineInputConnection_(t) {
          var e = t.centerline - t.height / 2;
          if (t.connectionModel) {
            let i = t.xPos + t.connectionWidth + t.connectionOffsetX;
            this.info_.RTL && (i *= -1), t.connectionModel.setOffsetInBlock(i, e + t.connectionOffsetY);
          }
        }
        positionStatementInputConnection_(t) {
          var e = t.getLastInput();
          if (e != null && e.connectionModel) {
            let i = t.xPos + t.statementEdge + e.notchOffset;
            this.info_.RTL && (i *= -1), e.connectionModel.setOffsetInBlock(i, t.yPos);
          }
        }
        positionExternalValueConnection_(t) {
          var e = t.getLastInput();
          if (e && e.connectionModel) {
            let i = t.xPos + t.width;
            this.info_.RTL && (i *= -1), e.connectionModel.setOffsetInBlock(i, t.yPos);
          }
        }
        positionPreviousConnection_() {
          var t = this.info_.topRow;
          if (t.connection) {
            let e = t.xPos + t.notchOffset;
            t.connection.connectionModel.setOffsetInBlock(this.info_.RTL ? -e : e, 0);
          }
        }
        positionNextConnection_() {
          var t = this.info_.bottomRow;
          if (t.connection) {
            let e = t.connection, i = e.xPos;
            e.connectionModel.setOffsetInBlock(this.info_.RTL ? -i : i, t.baseline);
          }
        }
        positionOutputConnection_() {
          if (this.info_.outputConnection) {
            var t = this.info_.startX + this.info_.outputConnection.connectionOffsetX;
            t = this.info_.RTL ? -t : t;
            let e;
            (e = this.block_.outputConnection) == null || e.setOffsetInBlock(t, this.info_.outputConnection.connectionOffsetY);
          }
        }
        updateConnectionHighlights() {
          for (let t of this.info_.rows) for (let e of t.elements) {
            if (!(e instanceof po)) continue;
            let i = this.drawConnectionHighlightPath(e);
            i && (e.connectionModel.setAriaRole(i), i.classList.toggle("blocklyHighlightedConnectionPathVisible", e.highlighted));
          }
        }
        drawConnectionHighlightPath(t) {
          var e = t.connectionModel;
          t = e.type === T.INPUT_VALUE || e.type === T.OUTPUT_VALUE ? this.getExpressionConnectionHighlightPath(t) : this.getStatementConnectionHighlightPath(t);
          var i = e.getSourceBlock(), o, s;
          return (s = (o = i.pathObject).addConnectionHighlight) == null ? void 0 : s.call(o, e, t, e.getOffsetInBlock(), i.RTL);
        }
        getExpressionConnectionHighlightPath(t) {
          var e = "";
          if (t.shape.isDynamic) e = t.shape.pathDown(t.height);
          else {
            var i = t.shape;
            i.pathDown !== void 0 && i.pathUp !== void 0 && (e = t.shape.pathDown);
          }
          return t = this.constants_.TAB_OFFSET_FROM_TOP, ct(0, -t) + A("v", t) + e + A("v", t);
        }
        getStatementConnectionHighlightPath(t) {
          var e = t.shape;
          if (e.pathLeft === void 0 || e.pathRight === void 0) throw Error("Statement connections should have notch shapes");
          return e = this.constants_.NOTCH_OFFSET_LEFT - this.constants_.CORNER_RADIUS, ct(-e, 0) + A("h", e) + t.shape.pathLeft + A("h", e);
        }
      }, sn = class {
        constructor(t, e) {
          this.statementEdge = this.width = this.widthWithChildren = this.height = 0, this.rows = [], this.inputRows = [], this.startY = this.startX = 0, this.renderer_ = t, this.block_ = e, this.constants_ = this.renderer_.getConstants(), this.outputConnection = e.outputConnection ? new kp(this.constants_, e.outputConnection) : null, this.isInline = e.getInputsInline() && !e.isCollapsed(), this.isCollapsed = e.isCollapsed(), this.isInsertionMarker = e.isInsertionMarker(), this.RTL = e.RTL, this.topRow = new Tu(this.constants_), this.bottomRow = new pu(this.constants_);
        }
        getRenderer() {
          return this.renderer_;
        }
        measure() {
          this.createRows_(), this.addElemSpacing_(), this.addRowSpacing_(), this.computeBounds_(), this.alignRowElements_(), this.finalize_();
        }
        createRows_() {
          this.populateTopRow_(), this.rows.push(this.topRow);
          var t = new _u(this.constants_);
          this.inputRows.push(t);
          var e = this.block_.getIcons();
          for (let i = 0, o; o = e[i]; i++) {
            let s = new Cp(this.constants_, o);
            this.isCollapsed && !o.isShownWhenCollapsed() || t.elements.push(s);
          }
          e = void 0;
          for (let i = 0, o; o = this.block_.inputList[i]; i++) if (o.isVisible()) {
            this.shouldStartNewRow_(o, e) && (this.rows.push(t), t = new _u(this.constants_), this.inputRows.push(t));
            for (let s = 0, n; n = o.fieldRow[s]; s++) t.elements.push(new Eu(this.constants_, n, o));
            this.addInput_(o, t), e = o;
          }
          this.isCollapsed && (t.hasJaggedEdge = !0, t.elements.push(new yp(this.constants_))), (t.elements.length || t.hasDummyInput) && this.rows.push(t), this.populateBottomRow_(), this.rows.push(this.bottomRow);
        }
        populateTopRow_() {
          var t = !!this.block_.previousConnection, e = (this.block_.hat ? this.block_.hat === "cap" : this.constants_.ADD_START_HATS) && !this.outputConnection && !t, i = this.topRow.hasLeftSquareCorner(this.block_) ? on : en;
          this.topRow.elements.push(new i(this.constants_)), e ? (t = new Tp(this.constants_), this.topRow.elements.push(t)) : t && (this.topRow.hasPreviousConnection = !0, this.topRow.connection = new wp(this.constants_, this.block_.previousConnection), this.topRow.elements.push(this.topRow.connection)), this.block_.inputList.length && this.block_.inputList[0] instanceof re && !this.block_.isCollapsed() ? this.topRow.minHeight = this.constants_.TOP_ROW_PRECEDES_STATEMENT_MIN_HEIGHT : this.topRow.minHeight = this.constants_.TOP_ROW_MIN_HEIGHT, i = this.topRow.hasRightSquareCorner(this.block_) ? on : en, this.topRow.elements.push(new i(this.constants_, "right"));
        }
        populateBottomRow_() {
          this.bottomRow.hasNextConnection = !!this.block_.nextConnection, this.bottomRow.minHeight = this.block_.inputList.length && this.block_.inputList[this.block_.inputList.length - 1] instanceof re ? this.constants_.BOTTOM_ROW_AFTER_STATEMENT_MIN_HEIGHT : this.constants_.BOTTOM_ROW_MIN_HEIGHT, this.bottomRow.hasLeftSquareCorner(this.block_) ? this.bottomRow.elements.push(new on(this.constants_)) : this.bottomRow.elements.push(new en(this.constants_)), this.bottomRow.hasNextConnection && (this.bottomRow.connection = new bp(this.constants_, this.block_.nextConnection), this.bottomRow.elements.push(this.bottomRow.connection)), this.bottomRow.hasRightSquareCorner(this.block_) ? this.bottomRow.elements.push(new on(this.constants_, "right")) : this.bottomRow.elements.push(new en(
            this.constants_,
            "right"
          ));
        }
        addInput_(t, e) {
          this.isInline && t instanceof r.go ? (e.elements.push(new vu(this.constants_, t)), e.hasInlineInput = !0) : t instanceof re ? (e.elements.push(new el(this.constants_, t)), e.hasStatement = !0) : t instanceof r.go ? (e.elements.push(new fu(this.constants_, t)), e.hasExternalInput = !0) : (t instanceof Ge || t instanceof ri) && (e.minHeight = Math.max(e.minHeight, t.getSourceBlock() && t.getSourceBlock().isShadow() ? this.constants_.DUMMY_INPUT_SHADOW_MIN_HEIGHT : this.constants_.DUMMY_INPUT_MIN_HEIGHT), e.hasDummyInput = !0), e.align === null && (e.align = t.align);
        }
        shouldStartNewRow_(t, e) {
          return e ? e instanceof ri || t instanceof re || e instanceof re ? !0 : t instanceof r.go || t instanceof Ge || e instanceof r.go ? !this.isInline : !1 : !1;
        }
        addElemSpacing_() {
          for (let t = 0, e; e = this.rows[t]; t++) {
            let i = e.elements;
            if (e.elements = [], e.startsWithElemSpacer() && e.elements.push(new he(this.constants_, this.getInRowSpacing_(null, i[0]))), i.length) {
              for (let o = 0; o < i.length - 1; o++) {
                e.elements.push(i[o]);
                let s = this.getInRowSpacing_(i[o], i[o + 1]);
                e.elements.push(new he(this.constants_, s));
              }
              e.elements.push(i[i.length - 1]), e.endsWithElemSpacer() && e.elements.push(new he(this.constants_, this.getInRowSpacing_(i[i.length - 1], null)));
            }
          }
        }
        getInRowSpacing_(t, e) {
          if (!t && e && u.isStatementInput(e)) return this.constants_.STATEMENT_INPUT_PADDING_LEFT;
          if (t && u.isInput(t) && !e) {
            if (u.isExternalInput(t)) return this.constants_.NO_PADDING;
            if (u.isInlineInput(t)) return this.constants_.LARGE_PADDING;
            if (u.isStatementInput(t)) return this.constants_.NO_PADDING;
          }
          return t && u.isLeftSquareCorner(t) && e && (u.isPreviousConnection(e) || u.isNextConnection(e)) ? e.notchOffset : t && u.isLeftRoundedCorner(t) && e && (u.isPreviousConnection(e) || u.isNextConnection(e)) ? e.notchOffset - this.constants_.CORNER_RADIUS : t && u.isField(t) && t.width === 0 ? this.constants_.NO_PADDING : this.constants_.MEDIUM_PADDING;
        }
        computeBounds_() {
          var t = 0, e = 0, i = 0;
          for (let s = 0, n; n = this.rows[s]; s++) {
            if (n.measure(), e = Math.max(e, n.width), n.hasStatement) {
              var o = n.getLastInput();
              let l;
              o = n.width - ((l = o?.width) != null ? l : 0), t = Math.max(t, o);
            }
            i = Math.max(
              i,
              n.widthWithConnectedBlocks
            );
          }
          this.statementEdge = t, this.width = e;
          for (let s = 0, n; n = this.rows[s]; s++) n.hasStatement && (n.statementEdge = this.statementEdge);
          this.widthWithChildren = Math.max(e, i), this.outputConnection && (this.startX = this.outputConnection.width, this.width += this.outputConnection.width, this.widthWithChildren += this.outputConnection.width);
        }
        alignRowElements_() {
          for (let e = 0, i; i = this.rows[e]; e++) if (i.hasStatement) this.alignStatementRow_(i);
          else {
            var t = i.width;
            t = this.getDesiredRowWidth_(i) - t, t > 0 && this.addAlignmentPadding_(
              i,
              t
            ), u.isTopOrBottomRow(i) && (i.widthWithConnectedBlocks = i.width);
          }
        }
        getDesiredRowWidth_() {
          return this.width - this.startX;
        }
        addAlignmentPadding_(t, e) {
          var i = t.getFirstSpacer(), o = t.getLastSpacer();
          if ((t.hasExternalInput || t.hasStatement) && (t.widthWithConnectedBlocks += e), t.align === r.Xn.LEFT && o) o.width += e;
          else if (t.align === r.Xn.CENTRE && i && o) i.width += e / 2, o.width += e / 2;
          else if (t.align === r.Xn.RIGHT && i) i.width += e;
          else if (o) o.width += e;
          else return;
          t.width += e;
        }
        alignStatementRow_(t) {
          var e = t.getLastInput();
          if (e) {
            var i = t.width - e.width, o = this.statementEdge;
            i = o - i, i > 0 && this.addAlignmentPadding_(t, i), i = t.width, o = this.getDesiredRowWidth_(t), e.width += o - i, e.height = Math.max(e.height, t.height), t.width += o - i, t.widthWithConnectedBlocks = Math.max(t.width, this.statementEdge + t.connectedBlockWidths);
          }
        }
        addRowSpacing_() {
          var t = this.rows;
          this.rows = [];
          for (let e = 0; e < t.length; e++) this.rows.push(t[e]), e !== t.length - 1 && this.rows.push(this.makeSpacerRow_(t[e], t[e + 1]));
        }
        makeSpacerRow_(t, e) {
          var i = this.getSpacerRowHeight_(t, e), o = this.getSpacerRowWidth_(
            t,
            e
          );
          return i = new mu(this.constants_, i, o), t.hasStatement && (i.followsStatement = !0), e.hasStatement && (i.precedesStatement = !0), i;
        }
        getSpacerRowWidth_() {
          return this.width - this.startX;
        }
        getSpacerRowHeight_() {
          return this.constants_.MEDIUM_PADDING;
        }
        getElemCenterline_(t, e) {
          return u.isSpacer(e) ? t.yPos + e.height / 2 : u.isBottomRow(t) ? (t = t.yPos + t.height - t.descenderHeight, u.isNextConnection(e) ? t + e.height / 2 : t - e.height / 2) : u.isTopRow(t) ? u.isHat(e) ? t.capline - e.height / 2 : t.capline + e.height / 2 : t.yPos + t.height / 2;
        }
        recordElemPositions_(t) {
          var e = t.xPos;
          for (let i = 0, o; o = t.elements[i]; i++) u.isSpacer(o) && (o.height = t.height), o.xPos = e, o.centerline = this.getElemCenterline_(t, o), e += o.width;
        }
        finalize_() {
          var t = 0, e = 0;
          for (let i = 0, o; o = this.rows[i]; i++) o.yPos = e, o.xPos = this.startX, e += o.height, t = Math.max(t, o.widthWithConnectedBlocks), this.recordElemPositions_(o);
          if (this.outputConnection && this.block_.nextConnection) {
            let i = this.block_.nextConnection.targetBlock();
            i && (t = Math.max(t, i.getHeightWidth().width));
          }
          this.widthWithChildren = t + this.startX, this.height = e, this.startY = this.topRow.capline, this.bottomRow.baseline = e - this.bottomRow.descenderHeight;
        }
        getMeasureableForConnection(t) {
          var e;
          if (((e = this.outputConnection) == null ? void 0 : e.connectionModel) === t) return this.outputConnection;
          for (let i of this.rows) for (let o of i.elements) if (o instanceof po && o.connectionModel === t) return o;
          return null;
        }
      }, sl = class {
        constructor(t, e, i) {
          this.connectionHighlights = /* @__PURE__ */ new WeakMap(), this.highlightOffsets = /* @__PURE__ */ new WeakMap(), this.constants = i, this.style = e, this.svgRoot = t, this.svgPath = v(g.PATH, { class: "blocklyPath" }, this.svgRoot), this.setClass_("blocklyBlock", !0);
        }
        setPath(t) {
          this.svgPath.setAttribute("d", t);
        }
        flipRTL() {
          this.svgPath.setAttribute("transform", "scale(-1 1)");
        }
        applyColour(t) {
          this.svgPath.setAttribute("stroke", this.style.colourTertiary), this.svgPath.setAttribute("fill", this.style.colourPrimary), this.updateShadow_(t.isShadow()), this.updateDisabled_(!t.isEnabled() || t.getInheritedDisabled());
        }
        setStyle(t) {
          this.style = t;
        }
        setClass_(t, e) {
          t && (e ? b(this.svgRoot, t) : Y(this.svgRoot, t));
        }
        updateHighlighted(t) {
          t ? this.setClass_("blocklyHighlighted", !0) : this.setClass_("blocklyHighlighted", !1);
        }
        updateShadow_(t) {
          t ? (this.setClass_("blocklyShadow", !0), this.svgPath.setAttribute("stroke", "none"), this.svgPath.setAttribute("fill", this.style.colourSecondary)) : this.setClass_("blocklyShadow", !1);
        }
        updateDisabled_(t) {
          this.setClass_("blocklyDisabled", t), this.setClass_(
            "blocklyDisabledPattern",
            t
          );
        }
        updateSelected(t) {
          this.setClass_("blocklySelected", t);
        }
        updateDraggingDelete(t) {
          this.setClass_("blocklyDraggingDelete", t);
        }
        updateInsertionMarker(t) {
          this.setClass_("blocklyInsertionMarker", t);
        }
        updateMovable(t) {
          this.setClass_("blocklyDraggable", t);
        }
        updateReplacing(t) {
          this.setClass_("blocklyReplaceable", t);
        }
        addConnectionHighlight(t, e, i, o) {
          return i = `translate(${i.x}, ${i.y})` + (o ? " scale(-1 1)" : ""), (o = this.connectionHighlights.get(t)) ? (o.setAttribute("d", e), o.setAttribute("transform", i), o) : (e = v(g.PATH, {
            id: t.id,
            class: "blocklyHighlightedConnectionPath",
            d: e,
            transform: i
          }, this.svgRoot), this.connectionHighlights.set(t, e), e);
        }
        removeConnectionHighlight(t) {
          var e = this.connectionHighlights.get(t);
          e && (Q(e), this.connectionHighlights.delete(t));
        }
      }, nl = class {
        constructor(t) {
          this.overrides = null, this.name = t;
        }
        getClassName() {
          return this.name + "-renderer";
        }
        init(t, e) {
          this.constants_ = this.makeConstants_(), e && (this.overrides = e, Object.assign(this.constants_, e)), this.constants_.setTheme(t), this.constants_.init();
        }
        createDom(t, e, i) {
          this.constants_.createDom(t, "." + this.getClassName() + "." + e.getClassName(), i);
        }
        refreshDom(t, e, i) {
          var o = this.getConstants();
          o.dispose(), this.constants_ = this.makeConstants_(), this.overrides && Object.assign(this.constants_, this.overrides), this.constants_.randomIdentifier = o.randomIdentifier, this.constants_.setTheme(e), this.constants_.init(), this.createDom(t, e, i);
        }
        dispose() {
          this.constants_ && this.constants_.dispose();
        }
        makeConstants_() {
          return new il();
        }
        makeRenderInfo_(t) {
          return new sn(this, t);
        }
        makeDrawer_(t, e) {
          return new ol(t, e);
        }
        makePathObject(t, e) {
          return new sl(t, e, this.constants_);
        }
        getConstants() {
          return this.constants_;
        }
        shouldHighlightConnection(t) {
          return !t.getSourceBlock().isDragging();
        }
        orphanCanConnectAtEnd(t, e, i) {
          return !!X.getConnectionForOrphanedConnection(
            t,
            i === T.OUTPUT_VALUE ? e.outputConnection : e.previousConnection
          );
        }
        render(t) {
          var e = this.makeRenderInfo_(t);
          e.measure(), this.makeDrawer_(t, e).draw();
        }
      }, q = {};
      q.BottomRow = pu, q.Connection = po, q.ConstantProvider = il, q.Drawer = ol, q.ExternalValueInput = fu, q.Field = Eu, q.Hat = Tp, q.Icon = Cp, q.InRowSpacer = he, q.InlineInput = vu, q.InputConnection = tl, q.InputRow = _u, q.JaggedEdge = yp, q.Measurable = Ke, q.NextConnection = bp, q.OutputConnection = kp, q.PathObject = sl, q.PreviousConnection = wp, q.RenderInfo = sn, q.Renderer = nl, q.RoundCorner = en, q.Row = tn, q.SpacerRow = mu, q.SquareCorner = on, q.StatementInput = el, q.TopRow = Tu, q.Types = u, q.init = Mh, q.register = xs, q.unregister = function(t) {
        Mi(_.RENDERER, t);
      };
      var Ip = class {
        constructor(t, e) {
          this.workspace = t, this.theme = e, this.subscribedWorkspaces = [], this.componentDB = /* @__PURE__ */ new Map();
        }
        getTheme() {
          return this.theme;
        }
        setTheme(t) {
          var e = this.theme;
          this.theme = t, (t = this.workspace.getInjectionDiv()) && (e && (e = e.getClassName()) && Y(t, e), (e = this.theme.getClassName()) && b(t, e));
          for (let i = 0, o; o = this.subscribedWorkspaces[i]; i++) o.refreshTheme();
          for (let [i, o] of this.componentDB) for (let s of o) {
            t = s.element, e = s.propertyName;
            let n = this.theme && this.theme.getComponentStyle(i);
            t.style.setProperty(
              e,
              n || ""
            );
          }
          for (let i of this.subscribedWorkspaces) i.hideChaff();
        }
        subscribeWorkspace(t) {
          this.subscribedWorkspaces.push(t);
        }
        unsubscribeWorkspace(t) {
          if (!Qt(this.subscribedWorkspaces, t)) throw Error("Cannot unsubscribe a workspace that hasn't been subscribed.");
        }
        subscribe(t, e, i) {
          this.componentDB.has(e) || this.componentDB.set(e, []), this.componentDB.get(e).push({ element: t, propertyName: i }), e = this.theme && this.theme.getComponentStyle(e), t.style.setProperty(i, e || "");
        }
        unsubscribe(t) {
          if (t) for (let [e, i] of this.componentDB) {
            for (let o = i.length - 1; o >= 0; o--) i[o].element === t && i.splice(o, 1);
            i.length || this.componentDB.delete(e);
          }
        }
        dispose() {
          this.subscribedWorkspaces.length = 0, this.componentDB.clear();
        }
      }, fo = { CATEGORY_NAME: "VARIABLE_DYNAMIC" };
      fo.flyoutCategory = hr, fo.flyoutCategoryBlocks = function(t) {
        t = t.getVariableMap().getAllVariables();
        var e = [];
        if (t.length > 0) {
          if (gt.variables_set_dynamic) {
            var i = t[t.length - 1];
            let o = r.sc("block");
            o.setAttribute("type", "variables_set_dynamic"), o.setAttribute("gap", "24"), o.appendChild(Pi(i)), e.push(o);
          }
          if (gt.variables_get_dynamic) {
            t.sort(Ao);
            for (let o = 0, s; s = t[o]; o++) i = r.sc("block"), i.setAttribute("type", "variables_get_dynamic"), i.setAttribute("gap", "8"), i.appendChild(Pi(s)), e.push(i);
          }
        }
        return e;
      }, fo.onCreateVariableButtonClick_Colour = Hh, fo.onCreateVariableButtonClick_Number = Fh, fo.onCreateVariableButtonClick_String = Ph;
      var ns = class {
        get isFlyout() {
          return this.internalIsFlyout;
        }
        get isMutator() {
          return this.internalIsMutator;
        }
        constructor(t) {
          this.isClearing = this.internalIsMutator = this.internalIsFlyout = this.rendered = !1, this.MAX_UNDO = 1024, this.connectionDBList = [], this.topBlocks = [], this.topComments = [], this.commentDB = /* @__PURE__ */ new Map(), this.listeners = [], this.undoStack_ = [], this.redoStack_ = [], this.blockDB = /* @__PURE__ */ new Map(), this.typedBlocksDB = /* @__PURE__ */ new Map(), this.procedureMap = new mp(), this.readOnly = !1, this.potentialVariableMap = null, this.id = je(), El(this), this.options = t || new We({}), this.RTL = !!this.options.RTL, this.horizontalLayout = !!this.options.horizontalLayout, this.toolboxPosition = this.options.toolboxPosition, this.connectionChecker = new (Pt(_.CONNECTION_CHECKER, this.options, !0))(this), this.variableMap = new (this.getVariableMapClass())(this), this.setIsReadOnly(this.options.readOnly);
        }
        dispose() {
          this.listeners.length = 0, this.clear(), gn(this);
        }
        sortObjects(t, e) {
          var i = (o) => ({ getBoundingRectangle: () => {
            var s = o.getRelativeToSurfaceXY();
            return new F(s.y, s.y, s.x, s.x);
          }, moveBy: () => {
          } });
          return this.sortByOrigin(i(t), i(e));
        }
        sortByOrigin(t, e) {
          var i = Math.sin(Gn(ns.SCAN_ANGLE)) * (this.RTL ? -1 : 1);
          return t = t.getBoundingRectangle().getOrigin(), e = e.getBoundingRectangle().getOrigin(), t.y + i * t.x - (e.y + i * e.x);
        }
        addTopBlock(t) {
          this.topBlocks.push(t);
        }
        removeTopBlock(t) {
          if (!Qt(this.topBlocks, t)) throw Error("Block not present in workspace's list of top-most blocks.");
        }
        getTopBlocks(t = !1) {
          var e = [].concat(this.topBlocks);
          return t && e.length > 1 && e.sort(this.sortObjects.bind(this)), e;
        }
        addTypedBlock(t) {
          this.typedBlocksDB.has(t.type) || this.typedBlocksDB.set(t.type, []), this.typedBlocksDB.get(t.type).push(t);
        }
        removeTypedBlock(t) {
          Qt(this.typedBlocksDB.get(t.type), t), this.typedBlocksDB.get(t.type).length || this.typedBlocksDB.delete(t.type);
        }
        getBlocksByType(t, e = !1) {
          return this.typedBlocksDB.has(t) ? (t = this.typedBlocksDB.get(t).slice(0), e && t && t.length > 1 && t.sort(this.sortObjects.bind(this)), t.filter((i) => !i.isInsertionMarker())) : [];
        }
        addTopComment(t) {
          this.topComments.push(t), this.commentDB.has(t.id) && console.warn('Overriding an existing comment on this workspace, with id "' + t.id + '"'), this.commentDB.set(t.id, t);
        }
        removeTopComment(t) {
          if (!Qt(this.topComments, t)) throw Error("Comment not present in workspace's list of top-most comments.");
          this.commentDB.delete(t.id);
        }
        getTopComments(t = !1) {
          var e = [].concat(this.topComments);
          return t && e.length > 1 && e.sort(this.sortObjects.bind(this)), e;
        }
        getAllBlocks(t = !1) {
          if (t) {
            var e = this.getTopBlocks(!0);
            t = [];
            for (let i = 0; i < e.length; i++) t.push(...e[i].getDescendants(!0));
          } else for (t = this.getTopBlocks(!1), e = 0; e < t.length; e++) t.push(...t[e].getChildren(!1));
          return t.filter((i) => !i.isInsertionMarker());
        }
        clear() {
          this.isClearing = !0;
          try {
            let t = r.gd;
            for (t || r.B(!0); this.topBlocks.length; ) this.topBlocks[0].dispose(!1);
            for (; this.topComments.length; ) this.topComments[this.topComments.length - 1].dispose();
            r.B(t), this.isFlyout || this.variableMap.clear(), this.potentialVariableMap && this.potentialVariableMap.clear();
          } finally {
            this.isClearing = !1;
          }
        }
        getWidth() {
          return 0;
        }
        newBlock() {
          throw Error("The implementation of newBlock should be monkey-patched in by blockly.ts");
        }
        newComment() {
          throw Error("The implementation of newComment should be monkey-patched in by blockly.ts");
        }
        remainingCapacity() {
          return isNaN(this.options.maxBlocks) ? 1 / 0 : this.options.maxBlocks - this.getAllBlocks(!1).length;
        }
        remainingCapacityOfType(t) {
          return this.options.maxInstances ? (this.options.maxInstances[t] !== void 0 ? this.options.maxInstances[t] : 1 / 0) - this.getBlocksByType(t, !1).length : 1 / 0;
        }
        isCapacityAvailable(t) {
          if (!this.hasBlockLimits()) return !0;
          var e = 0;
          for (let i in t) {
            if (t[i] > this.remainingCapacityOfType(i)) return !1;
            e += t[i];
          }
          return !(e > this.remainingCapacity());
        }
        hasBlockLimits() {
          return this.options.maxBlocks !== 1 / 0 || !!this.options.maxInstances;
        }
        getUndoStack() {
          return this.undoStack_;
        }
        getRedoStack() {
          return this.redoStack_;
        }
        undo(t = !1) {
          var e = t ? this.redoStack_ : this.undoStack_, i = t ? this.undoStack_ : this.redoStack_, o = e.pop();
          if (o) {
            for (var s = [o]; e.length && o.group && o.group === e[e.length - 1].group; ) {
              let n = e.pop();
              n && s.push(n);
            }
            for (e = 0; e < s.length; e++) i.push(s[e]);
            r.Qc = !1;
            try {
              for (i = 0; i < s.length; i++) s[i].run(t);
            } finally {
              r.Qc = !0;
            }
          }
        }
        redo() {
          this.undo(!0);
        }
        clearUndo() {
          this.undoStack_.length = 0, this.redoStack_.length = 0, bl();
        }
        addChangeListener(t) {
          return this.listeners.push(t), t;
        }
        removeChangeListener(t) {
          Qt(this.listeners, t);
        }
        fireChangeListener(t) {
          if (t.recordUndo) for (this.undoStack_.push(t), this.redoStack_.length = 0; this.undoStack_.length > this.MAX_UNDO && this.MAX_UNDO >= 0; ) this.undoStack_.shift();
          for (let e = 0; e < this.listeners.length; e++) (0, this.listeners[e])(t);
        }
        getBlockById(t) {
          return this.blockDB.get(t) || null;
        }
        setBlockById(t, e) {
          this.blockDB.set(t, e);
        }
        removeBlockById(t) {
          this.blockDB.delete(t);
        }
        getCommentById(t) {
          var e;
          return (e = this.commentDB.get(t)) != null ? e : null;
        }
        allInputsFilled(t) {
          var e = this.getTopBlocks(!1);
          for (let i = 0; i < e.length; i++) if (!e[i].allInputsFilled(t)) return !1;
          return !0;
        }
        getPotentialVariableMap() {
          return this.potentialVariableMap;
        }
        createPotentialVariableMap() {
          this.potentialVariableMap = new (this.getVariableMapClass())(this, !0);
        }
        getVariableMap() {
          return this.variableMap;
        }
        setVariableMap(t) {
          this.variableMap = t;
        }
        getProcedureMap() {
          return this.procedureMap;
        }
        getRootWorkspace() {
          var t = null, e = this.options.parentWorkspace;
          return this.isFlyout ? e && e.options && (t = e.options.parentWorkspace) : e && (t = e), t;
        }
        static getById(t) {
          return ai(t);
        }
        static getAll() {
          return hi();
        }
        getVariableMapClass() {
          var t = Pt(_.VARIABLE_MAP, this.options, !0);
          if (!t) throw Error("No variable map is registered.");
          return t;
        }
        isReadOnly() {
          return this.readOnly;
        }
        setIsReadOnly(t) {
          this.readOnly = t, this.options.readOnly = t;
        }
      };
      ns.SCAN_ANGLE = 3;
      var Sp = class {
        constructor(t) {
          this.parentWorkspace = t, this.sounds = /* @__PURE__ */ new Map(), this.lastSound = null, this.muted = !1, window.AudioContext && (this.context = new AudioContext());
        }
        dispose() {
          this.sounds.clear();
          var t;
          (t = this.context) == null || t.close();
        }
        load(t, e) {
          var i = this;
          return (0, d.asyncExecutePromiseGeneratorFunction)(function* () {
            if (t.length) {
              var o = yield (yield fetch(t[0])).arrayBuffer(), s;
              (s = i.context) == null || s.decodeAudioData(o, (n) => {
                i.sounds.set(e, n);
              });
            }
          });
        }
        play(t, e) {
          var i = this;
          return (0, d.asyncExecutePromiseGeneratorFunction)(function* () {
            if (i.isPlayingAllowed() && e !== 0) {
              var o = i.sounds.get(t);
              if (o) {
                if (yield i.prepareToPlay(), i.context.state === "running") {
                  var s = i.context.createBufferSource(), n = i.context.createGain();
                  n.gain.value = e ?? 1, n.connect(i.context.destination), s.buffer = o, s.connect(n), s.addEventListener("ended", () => {
                    s.disconnect(), n.disconnect();
                  }), s.start();
                }
              } else i.parentWorkspace && (o = i.parentWorkspace.getAudioManager(), o !== i && o.play(t, e));
            }
          });
        }
        beep(t, e = 0.2) {
          var i = this;
          return (0, d.asyncExecutePromiseGeneratorFunction)(function* () {
            if (i.isPlayingAllowed() && (yield i.prepareToPlay(), i.context.state === "running")) {
              var o = i.context.createOscillator();
              o.type = "sine", o.frequency.setValueAtTime(t, i.context.currentTime);
              var s = i.context.createGain();
              s.gain.setValueAtTime(0, i.context.currentTime), s.gain.linearRampToValueAtTime(0.5, i.context.currentTime + 0.01), s.gain.linearRampToValueAtTime(0, i.context.currentTime + e), o.connect(s), s.connect(i.context.destination), o.start(i.context.currentTime), o.stop(i.context.currentTime + e);
            }
          });
        }
        playErrorBeep() {
          var t = this;
          return (0, d.asyncExecutePromiseGeneratorFunction)(function* () {
            return t.beep(260);
          });
        }
        maybePlayScopeChangeAudioCue(t) {
          if (st.getScopeChangeAudioCuesEnabled()) {
            var e = this.parentWorkspace.getNavigator(), i = e.getSourceBlockFromNode(r.t().getFocusedNode());
            t = e.getSourceBlockFromNode(t), e = 0, i && t && i.getNestingLevel() !== (e = t.getNestingLevel()) && this.beep(400 + e * 60);
          }
        }
        isPlayingAllowed() {
          var t = /* @__PURE__ */ new Date();
          return !(this.getMuted() || !this.context || this.lastSound !== null && t.getTime() - this.lastSound.getTime() < 100);
        }
        prepareToPlay() {
          var t = this;
          return (0, d.asyncExecutePromiseGeneratorFunction)(function* () {
            t.lastSound = /* @__PURE__ */ new Date(), t.context.state === "suspended" && navigator.userActivation.hasBeenActive && (yield t.context.resume());
          });
        }
        setMuted(t) {
          this.muted = t;
        }
        getMuted() {
          return this.muted;
        }
      }, If = class {
        constructor(t, e) {
          this.workspace = t, this.element = e;
        }
        getFocusableElement() {
          return this.element;
        }
        getFocusableTree() {
          return this.workspace;
        }
        onNodeFocus() {
          this.workspace.handleWorkspaceFocusTargetFocus();
        }
        onNodeBlur() {
        }
        canBeFocused() {
          return !0;
        }
        getWorkspace() {
          return this.workspace;
        }
        showContextMenu(t) {
          this.workspace.showContextMenu(t);
        }
      }, Ot = class extends ns {
        constructor(t) {
          super(t), this.resizeHandlerWrapper = null, this.resizesEnabled = this.visible = this.rendered = !0, this.startScrollY = this.startScrollX = this.scrollY = this.scrollX = 0, this.oldScale = this.scale = 1, this.oldLeft = this.oldTop = 0, this.inverseScreenCTM = this.targetWorkspace = this.dummyWheelListener = this.configureContextMenu = this.lastRecordedPageScroll = this.injectionDiv = this.currentGesture_ = this.toolbox = this.flyout = this.scrollbar = this.trashcan = null, this.inverseScreenCTMDirty = !0, this.highlightedBlocks = [], this.toolboxCategoryCallbacks = /* @__PURE__ */ new Map(), this.flyoutButtonCallbacks = /* @__PURE__ */ new Map(), this.cachedParentSvg = null, this.topBoundedElements = [], this.dragTargetAreas = [], this.workspaceFocusTarget = this.workspaceFocusTargetElement = this.workspaceSelectionRing = this.workspaceFocusRing = this.zoomControls_ = this.layerManager = null, this.navigator = new Jr(), this.metricsManager = new (Pt(_.METRICS_MANAGER, t, !0))(this), this.getMetrics = t.getMetrics || this.metricsManager.getMetrics.bind(this.metricsManager), this.setMetrics = t.setMetrics || Ot.setTopLevelWorkspaceMetrics, this.componentManager = new nt(), this.connectionDBList = Qo.init(this.connectionChecker);
          var e;
          this.audioManager = new Sp((e = t.parentWorkspace) != null ? e : this), this.grid = this.options.gridPattern ? new uu(this.options.gridPattern, t.gridOptions) : null, _t && xn && this.registerToolboxCategoryCallback("VARIABLE", xn), fo && hr && this.registerToolboxCategoryCallback("VARIABLE_DYNAMIC", hr), Zt && ar && (this.registerToolboxCategoryCallback("PROCEDURE", ar), this.addChangeListener(xh)), this.addChangeListener(this.variableChangeCallback.bind(this)), this.themeManager_ = this.options.parentWorkspace ? this.options.parentWorkspace.getThemeManager() : new Ip(this, this.options.theme || Wr), this.themeManager_.subscribeWorkspace(this);
          var i;
          this.renderer = Mh(this.options.renderer || "geras", this.getTheme(), (i = this.options.rendererOverrides) != null ? i : void 0), this.cachedParentSvgSize = new H(0, 0);
        }
        getMetricsManager() {
          return this.metricsManager;
        }
        setMetricsManager(t) {
          this.metricsManager = t, this.getMetrics = this.metricsManager.getMetrics.bind(this.metricsManager);
        }
        getComponentManager() {
          return this.componentManager;
        }
        getRenderer() {
          return this.renderer;
        }
        getThemeManager() {
          return this.themeManager_;
        }
        getTheme() {
          return this.themeManager_.getTheme();
        }
        setTheme(t) {
          t || (t = Wr), this.themeManager_.setTheme(t);
        }
        refreshTheme() {
          if (this.svgGroup_) {
            var t = this.options.parentWorkspace === null;
            this.renderer.refreshDom(this.svgGroup_, this.getTheme(), t ? this.getInjectionDiv() : void 0);
          }
          this.updateBlockStyles(this.getAllBlocks(!1).filter((e) => !!e.getStyleName())), this.refreshToolboxSelection(), this.toolbox && this.toolbox.refreshTheme(), this.isVisible() && this.setVisible(!0), t = new (D(p.THEME_CHANGE))(this.getTheme().name, this.id), N(t);
        }
        updateBlockStyles(t) {
          for (let e = 0, i; i = t[e]; e++) {
            let o = i.getStyleName();
            o && i.setStyle(o);
          }
        }
        getInverseScreenCTM() {
          if (this.inverseScreenCTMDirty) {
            let t = this.getParentSvg().getScreenCTM();
            t && (this.inverseScreenCTM = t.inverse(), this.inverseScreenCTMDirty = !1);
          }
          return this.inverseScreenCTM;
        }
        updateInverseScreenCTM() {
          this.inverseScreenCTMDirty = !0;
        }
        isVisible() {
          return this.visible;
        }
        getSvgXY(t) {
          var e = 0, i = 0, o = 1;
          (this.getCanvas().contains(t) || this.getBubbleCanvas().contains(t)) && (o = this.scale);
          do {
            let s = mn(t);
            (t === this.getCanvas() || t === this.getBubbleCanvas()) && (o = 1), e += s.x * o, i += s.y * o, t = t.parentNode;
          } while (t && t !== this.getParentSvg() && t !== this.getInjectionDiv());
          return new m(e, i);
        }
        getCachedParentSvgSize() {
          var t = this.cachedParentSvgSize;
          return new H(t.width, t.height);
        }
        getOriginOffsetInPixels() {
          return Tn(this.getCanvas());
        }
        getInjectionDiv() {
          if (!this.injectionDiv) {
            let t = this.svgGroup_;
            for (; t; ) {
              if ((" " + (t.getAttribute("class") || "") + " ").includes(" injectionDiv ")) {
                this.injectionDiv = t;
                break;
              }
              t = t.parentNode;
            }
          }
          return this.injectionDiv;
        }
        getSvgGroup() {
          return this.svgGroup_;
        }
        getBlockCanvas() {
          return this.getCanvas();
        }
        setResizeHandlerWrapper(t) {
          this.resizeHandlerWrapper = t;
        }
        setInitialAriaContext() {
          if (!this.svgGroup_) throw Error("Must initialize svgGroup_ by calling `createDom` before calling setAriaContext");
          this.isFlyout || (G(this.svgGroup_, W.REGION), this.isMutator ? w(this.svgGroup_, y.LABEL, r.C.WORKSPACE_LABEL_MUTATOR_WORKSPACE) : (w(this.svgGroup_, y.LABEL, r.C.WORKSPACE_LABEL_PLAIN), this.workspaceFocusTargetElement && (G(this.workspaceFocusTargetElement, W.FIGURE), w(this.workspaceFocusTargetElement, y.ROLEDESCRIPTION, r.C.WORKSPACE_ROLEDESCRIPTION), this.updateAriaLabel())));
        }
        updateAriaLabel() {
          if (this.workspaceFocusTargetElement) {
            var t = this.getTopBlocks(!1).length;
            t == 1 ? w(this.workspaceFocusTargetElement, y.LABEL, r.C.WORKSPACE_LABEL_1_STACK) : w(this.workspaceFocusTargetElement, y.LABEL, r.C.WORKSPACE_LABEL_MANY_STACKS.replace("%1", String(t)));
          }
        }
        createDom(t, e) {
          return this.injectionDiv || (this.injectionDiv = e ?? null), this.svgGroup_ = v(g.G, { class: "blocklyWorkspace", id: this.id }), t && (this.svgBackground_ = v(g.RECT, { height: "100%", width: "100%", class: t }, this.svgGroup_), t === "blocklyMainBackground" && this.grid ? this.svgBackground_.style.fill = "var(--blocklyGridPattern)" : this.themeManager_.subscribe(this.svgBackground_, "workspaceBackgroundColour", "fill")), this.workspaceSelectionRing = t = v(g.RECT, { fill: "none", class: "blocklyWorkspaceSelectionRing" }, this.svgGroup_), this.workspaceFocusRing = v(g.RECT, { fill: "none", class: "blocklyWorkspaceFocusRing" }, this.svgGroup_), this.isFlyout || this.isMutator || (t.id = `${this.id}_focusTarget`, this.workspaceFocusTargetElement = t, this.workspaceFocusTarget = new If(this, t)), this.layerManager = new kf(this), this.svgBlockCanvas_ = this.layerManager.getBlockLayer(), this.svgBubbleCanvas_ = this.layerManager.getBubbleLayer(), this.setInitialAriaContext(), this.isFlyout || (M(this.svgGroup_, "pointerdown", this, this.onMouseDown, !1), this.dummyWheelListener = () => {
          }, document.body.addEventListener("wheel", this.dummyWheelListener, { passive: !0 }), M(this.svgGroup_, "wheel", this, this.onMouseWheel, !1, { passive: !1 })), this.options.hasCategories && (this.toolbox = new (Pt(_.TOOLBOX, this.options, !0))(this)), this.grid && this.grid.update(this.scale), this.recordDragTargets(), t = this.options.parentWorkspace === null, this.renderer.createDom(this.svgGroup_, this.getTheme(), t ? this.getInjectionDiv() : void 0), r.t().registerTree(this, !!this.injectionDiv || this.isFlyout), this.svgGroup_;
        }
        dispose() {
          if (this.rendered = !1, this.currentGesture_ && this.currentGesture_.cancel(), this.svgGroup_ && Q(this.svgGroup_), this.toolbox && (this.toolbox.dispose(), this.toolbox = null), this.flyout && (this.flyout.dispose(), this.flyout = null), this.trashcan && (this.trashcan.dispose(), this.trashcan = null), this.scrollbar && (this.scrollbar.dispose(), this.scrollbar = null), this.zoomControls_ && this.zoomControls_.dispose(), this.audioManager && this.audioManager.dispose(), this.grid && (this.grid = null), this.renderer.dispose(), super.dispose(), this.themeManager_ && (this.themeManager_.unsubscribeWorkspace(this), this.themeManager_.unsubscribe(this.svgBackground_), this.options.parentWorkspace || this.themeManager_.dispose()), this.connectionDBList.length = 0, this.toolboxCategoryCallbacks.clear(), this.flyoutButtonCallbacks.clear(), !this.options.parentWorkspace) {
            let i = this.getParentSvg();
            i && i.parentNode && Q(i.parentNode);
          }
          this.resizeHandlerWrapper && ($(this.resizeHandlerWrapper), this.resizeHandlerWrapper = null), this.dummyWheelListener && (document.body.removeEventListener("wheel", this.dummyWheelListener), this.dummyWheelListener = null);
          var t;
          (t = this.workspaceFocusRing) == null || t.remove();
          var e;
          (e = this.workspaceSelectionRing) == null || e.remove(), r.t().isRegistered(this) && r.t().unregisterTree(this);
        }
        addTrashcan() {
          this.trashcan = Ot.newTrashcan(this);
          var t = this.trashcan.createDom();
          this.svgGroup_.appendChild(t);
        }
        static newTrashcan() {
          throw Error("The implementation of newTrashcan should be monkey-patched in by blockly.ts");
        }
        addZoomControls() {
          this.zoomControls_ = new Vd(this);
          var t = this.zoomControls_.createDom();
          this.svgGroup_.appendChild(t);
        }
        copyOptionsForFlyout() {
          return new We({
            parentWorkspace: this,
            rtl: this.RTL,
            oneBasedIndex: this.options.oneBasedIndex,
            horizontalLayout: this.horizontalLayout,
            renderer: this.options.renderer,
            rendererOverrides: this.options.rendererOverrides,
            plugins: this.options.plugins,
            modalInputs: this.options.modalInputs,
            move: { scrollbars: !0 }
          });
        }
        addFlyout(t) {
          var e = this.copyOptionsForFlyout();
          return e.toolboxPosition = this.options.toolboxPosition, this.flyout = this.horizontalLayout ? new (Pt(_.FLYOUTS_HORIZONTAL_TOOLBOX, this.options, !0))(e) : new (Pt(_.FLYOUTS_VERTICAL_TOOLBOX, this.options, !0))(e), this.flyout.autoClose = !1, this.flyout.getWorkspace().setVisible(!0), this.flyout.createDom(t);
        }
        getFlyout(t) {
          return this.flyout || t ? this.flyout : this.toolbox ? this.toolbox.getFlyout() : null;
        }
        getToolbox() {
          return this.toolbox;
        }
        updateScreenCalculations() {
          this.updateInverseScreenCTM(), this.recordDragTargets();
        }
        resizeContents() {
          this.resizesEnabled && this.rendered && (this.scrollbar && this.scrollbar.resize(), this.updateInverseScreenCTM());
        }
        resize() {
          this.toolbox ? this.toolbox.position() : this.flyout && this.flyout.position();
          var t = this.componentManager.getComponents(nt.Capability.POSITIONABLE, !0), e = this.getMetricsManager().getUiMetrics(), i = [];
          for (let o = 0, s; s = t[o]; o++) {
            s.position(e, i);
            let n = s.getBoundingRectangle();
            n && i.push(n);
          }
          this.scrollbar && this.scrollbar.resize(), this.updateScreenCalculations(), this.workspaceFocusRing && this.workspaceSelectionRing && (this.resizeWorkspaceRing(this.workspaceSelectionRing, 5), this.resizeWorkspaceRing(this.workspaceFocusRing, 0));
        }
        resizeWorkspaceRing(t, e) {
          var i = this.getMetrics();
          t.setAttribute("x", `${i.absoluteLeft + e}`), t.setAttribute("y", `${i.absoluteTop + e}`), t.setAttribute("width", `${Math.max(0, i.viewWidth - e * 2)}`), t.setAttribute("height", `${Math.max(0, i.svgHeight - e * 2)}`);
        }
        updateScreenCalculationsIfScrolled() {
          var t = Al();
          m.equals(this.lastRecordedPageScroll, t) || (this.lastRecordedPageScroll = t, this.updateScreenCalculations());
        }
        getLayerManager() {
          return this.layerManager;
        }
        getCanvas() {
          return this.layerManager.getBlockLayer();
        }
        setCachedParentSvgSize(t, e) {
          var i = this.getParentSvg();
          t != null && (this.cachedParentSvgSize.width = t, i.setAttribute("data-cached-width", `${t}`)), e != null && (this.cachedParentSvgSize.height = e, i.setAttribute("data-cached-height", `${e}`));
        }
        getBubbleCanvas() {
          return this.layerManager.getBubbleLayer();
        }
        getParentSvg() {
          if (!this.cachedParentSvg) {
            let t = this.svgGroup_;
            for (; t; ) {
              if (t.tagName === "svg") {
                this.cachedParentSvg = t;
                break;
              }
              t = t.parentNode;
            }
          }
          return this.cachedParentSvg;
        }
        maybeFireViewportChangeEvent() {
          if (ht()) {
            var t = this.scale, e = -this.scrollY, i = -this.scrollX;
            if (!(t === this.oldScale && Math.abs(e - this.oldTop) < 1 && Math.abs(i - this.oldLeft) < 1)) {
              var o = new (D(p.VIEWPORT_CHANGE))(e, i, t, this.id, this.oldScale);
              this.oldScale = t, this.oldTop = e, this.oldLeft = i, N(o);
            }
          }
        }
        translate(t, e) {
          var i;
          (i = this.layerManager) == null || i.translateLayers(new m(t, e), this.scale);
          var o;
          (o = this.grid) == null || o.moveTo(t, e), this.maybeFireViewportChangeEvent();
        }
        getWidth() {
          var t = this.getMetrics();
          return t ? t.viewWidth / this.scale : 0;
        }
        setVisible(t) {
          this.visible = t, this.svgGroup_ && (this.scrollbar && this.scrollbar.setContainerVisible(t), this.getFlyout() && this.getFlyout().setContainerVisible(t), this.getParentSvg().style.display = t ? "block" : "none", this.toolbox && this.toolbox.setVisible(t), t || this.hideChaff(!0));
        }
        render() {
          var t = this.getAllBlocks(!1);
          for (let e = t.length - 1; e >= 0; e--) t[e].queueRender();
          this.getTopBlocks().flatMap((e) => e.getDescendants(!1)).filter((e) => e.isInsertionMarker()).forEach((e) => e.queueRender());
        }
        highlightBlock(t, e) {
          if (e === void 0) {
            for (let i = 0, o; o = this.highlightedBlocks[i]; i++) o.setHighlighted(!1);
            this.highlightedBlocks.length = 0;
          }
          (t = t ? this.getBlockById(t) : null) && ((e = e === void 0 || e) ? this.highlightedBlocks.includes(t) || this.highlightedBlocks.push(t) : Qt(this.highlightedBlocks, t), t.setHighlighted(e));
        }
        variableChangeCallback(t) {
          switch (t.type) {
            case p.VAR_CREATE:
            case p.VAR_DELETE:
            case p.VAR_RENAME:
            case p.VAR_TYPE_CHANGE:
              this.refreshToolboxSelection();
          }
        }
        refreshToolboxSelection() {
          var t = this.isFlyout ? this.targetWorkspace : this;
          t && !t.currentGesture_ && t.toolbox && t.toolbox.getFlyout() && t.toolbox.refreshSelection();
        }
        recordDragTargets() {
          var t = this.componentManager.getComponents(nt.Capability.DRAG_TARGET, !0);
          this.dragTargetAreas = [];
          for (let e = 0, i; i = t[e]; e++) {
            let o = i.getClientRect();
            o && this.dragTargetAreas.push({ component: i, clientRect: o });
          }
        }
        newBlock() {
          throw Error("The implementation of newBlock should be monkey-patched in by blockly.ts");
        }
        newComment() {
          throw Error("The implementation of newComment should be monkey-patched in by blockly.ts");
        }
        getDragTarget(t) {
          t = t instanceof m ? t : new m(t.clientX, t.clientY);
          for (let e = 0, i; i = this.dragTargetAreas[e]; e++) if (i.clientRect.contains(t.x, t.y)) return i.component;
          return null;
        }
        onMouseDown(t) {
          var e = this.getGesture(t);
          e && e.handleWsStart(t, this);
        }
        startDrag(t, e) {
          qn(this, t, e);
        }
        moveDrag(t) {
          return Zn(this, t);
        }
        isDragging() {
          return J.mover.isMoving() || this.currentGesture_ !== null && this.currentGesture_.isDragging();
        }
        isDraggable() {
          return this.options.moveOptions && this.options.moveOptions.drag;
        }
        isMovable() {
          return this.options.moveOptions && !!this.options.moveOptions.scrollbars || this.options.moveOptions && this.options.moveOptions.wheel || this.options.moveOptions && this.options.moveOptions.drag || this.options.zoomOptions && this.options.zoomOptions.wheel || this.options.zoomOptions && this.options.zoomOptions.pinch;
        }
        isMovableHorizontally() {
          var t = !!this.scrollbar;
          return this.isMovable() && (!t || t && this.scrollbar.canScrollHorizontally());
        }
        isMovableVertically() {
          var t = !!this.scrollbar;
          return this.isMovable() && (!t || t && this.scrollbar.canScrollVertically());
        }
        onMouseWheel(t) {
          if (Zr.inProgress()) t.preventDefault(), t.stopPropagation();
          else {
            var e = this.options.zoomOptions && this.options.zoomOptions.wheel, i = this.options.moveOptions && this.options.moveOptions.wheel;
            if (e || i) {
              var o = cs(t);
              if (Fo) var s = t.metaKey;
              e && (t.ctrlKey || s || !i) ? (o = -o.y / 50, e = To(t, this.getParentSvg(), this.getInverseScreenCTM()), this.zoom(e.x, e.y, o)) : (e = this.scrollX - o.x, i = this.scrollY - o.y, t.shiftKey && !o.x && (e = this.scrollX - o.y, i = this.scrollY), this.scroll(e, i)), t.preventDefault();
            }
          }
        }
        getBlocksBoundingBox() {
          var t = this.getTopBoundedElements();
          if (!t.length) return new F(
            0,
            0,
            0,
            0
          );
          var e = t[0].getBoundingRectangle();
          for (let o = 1; o < t.length; o++) {
            var i = t[o];
            i.isInsertionMarker && i.isInsertionMarker() || (i = i.getBoundingRectangle(), i.top < e.top && (e.top = i.top), i.bottom > e.bottom && (e.bottom = i.bottom), i.left < e.left && (e.left = i.left), i.right > e.right && (e.right = i.right));
          }
          return e;
        }
        cleanUp() {
          function t(l) {
            for (let a of s) if (l.intersects(a)) return a;
            return null;
          }
          this.setResizesEnabled(!1);
          var e = r.gd;
          e || r.B(!0);
          var i = this.getTopBlocks(!0), o = i.filter((l) => l.isMovable()), s = i.filter((l) => !l.isMovable()).map((l) => l.getBoundingRectangle()), n = 0;
          i = this.renderer.getConstants().MIN_BLOCK_HEIGHT;
          for (let l of o) {
            for (o = l.getBoundingRectangle(), l.moveBy(-o.left, n - o.top, ["cleanup"]), l.snapToGrid(), o = l.getBoundingRectangle(), n = t(o); n != null; ) n = n.top + n.getHeight() + i, l.moveBy(0, n - o.top, ["cleanup"]), l.snapToGrid(), o = l.getBoundingRectangle(), n = t(o);
            n = l.getRelativeToSurfaceXY().y + l.getHeightWidth().height + i;
          }
          r.B(e), this.setResizesEnabled(!0);
        }
        showContextMenu(t) {
          if (!this.isReadOnly() && !this.isFlyout) {
            var e = V.registry.getContextMenuOptions({ workspace: this, focusedNode: this }, t);
            if (this.configureContextMenu && this.configureContextMenu(e, t), t instanceof PointerEvent) var i = new m(t.clientX, t.clientY);
            else i = this.getMetricsManager().getViewMetrics(!0), i = pi(this, new m(this.RTL ? i.left + i.width - 5 : i.left + 5, i.top + 5));
            Lo(t, e, this.RTL, this, i);
          }
        }
        updateToolbox(t) {
          if (t = Cn(t)) {
            if (!this.options.languageTree) throw Error("Existing toolbox is null.  Can't create new toolbox.");
            if (yn(t)) {
              if (!this.toolbox) throw Error("Existing toolbox has no categories.  Can't change mode.");
              this.options.languageTree = t, this.toolbox.render(t);
            } else {
              if (!this.flyout) throw Error("Existing toolbox has categories.  Can't change mode.");
              this.options.languageTree = t, this.flyout.show(t);
            }
          } else if (this.options.languageTree) throw Error("Can't nullify an existing toolbox.");
        }
        markFocused() {
          this.options.parentWorkspace ? this.options.parentWorkspace.markFocused() : (ps(this), this.getParentSvg().focus({ preventScroll: !0 }));
        }
        zoom(t, e, i) {
          i = Math.pow(this.options.zoomOptions.scaleSpeed, i);
          var o = this.scale * i;
          if (this.scale !== o) {
            o > this.options.zoomOptions.maxScale ? i = this.options.zoomOptions.maxScale / this.scale : o < this.options.zoomOptions.minScale && (i = this.options.zoomOptions.minScale / this.scale);
            var s = this.getCanvas().getCTM(), n = this.getParentSvg().createSVGPoint();
            n.x = t, n.y = e, n = n.matrixTransform(s.inverse()), t = n.x, e = n.y, s = s.translate(t * (1 - i), e * (1 - i)).scale(i), this.scrollX = Math.round(s.e), this.scrollY = Math.round(s.f), this.setScale(o);
          }
        }
        zoomCenter(t) {
          var e = this.getMetrics();
          if (this.flyout) {
            var i = e.svgWidth ? e.svgWidth / 2 : 0;
            e = e.svgHeight ? e.svgHeight / 2 : 0;
          } else i = e.viewWidth / 2 + e.absoluteLeft, e = e.viewHeight / 2 + e.absoluteTop;
          this.zoom(i, e, t);
        }
        zoomToFit() {
          if (this.isMovable()) {
            var t = this.getMetrics(), e = t.viewWidth;
            t = t.viewHeight;
            var i = this.getBlocksBoundingBox(), o = i.right - i.left + 40;
            if (i = i.bottom - i.top + 40, o) {
              this.flyout && (this.horizontalLayout ? (t += this.flyout.getHeight(), i += this.flyout.getHeight() / this.scale) : (e += this.flyout.getWidth(), o += this.flyout.getWidth() / this.scale)), r.Ub++;
              try {
                this.setScale(Math.min(e / o, t / i)), this.scrollCenter();
              } finally {
                r.Ub--;
              }
              this.maybeFireViewportChangeEvent();
            }
          } else console.warn("Tried to move a non-movable workspace. This could result in blocks becoming inaccessible.");
        }
        beginCanvasTransition() {
          b(
            this.getCanvas(),
            "blocklyCanvasTransitioning"
          ), b(this.getBubbleCanvas(), "blocklyCanvasTransitioning");
        }
        endCanvasTransition() {
          Y(this.getCanvas(), "blocklyCanvasTransitioning"), Y(this.getBubbleCanvas(), "blocklyCanvasTransitioning");
        }
        scrollCenter() {
          if (this.isMovable()) {
            var t = this.getMetrics(), e = (t.scrollWidth - t.viewWidth) / 2, i = (t.scrollHeight - t.viewHeight) / 2;
            e = -e - t.scrollLeft, i = -i - t.scrollTop, this.scroll(e, i);
          } else console.warn("Tried to move a non-movable workspace. This could result in blocks becoming inaccessible.");
        }
        centerOnBlock(t, e) {
          if (this.isMovable()) {
            var i = t ? this.getBlockById(t) : null;
            if (i) {
              t = i.getRelativeToSurfaceXY(), i = e ? { height: i.height, width: i.width } : i.getHeightWidth();
              var o = this.scale;
              e = (t.x + (this.RTL ? -1 : 1) * i.width / 2) * o, t = (t.y + i.height / 2) * o, i = this.getMetrics(), this.scroll(-(e - i.viewWidth / 2), -(t - i.viewHeight / 2));
            }
          } else console.warn("Tried to move a non-movable workspace. This could result in blocks becoming inaccessible.");
        }
        setScale(t) {
          t = Math.round(t * 1e3) / 1e3, this.options.zoomOptions.maxScale && t > this.options.zoomOptions.maxScale ? t = this.options.zoomOptions.maxScale : this.options.zoomOptions.minScale && t < this.options.zoomOptions.minScale && (t = this.options.zoomOptions.minScale), this.scale = t, this.hideChaff(!1), (t = this.getFlyout(!1)) && t.isVisible() && (t.reflow(), this.recordDragTargets()), this.grid && this.grid.update(this.scale), t = this.getMetrics(), this.scrollX -= t.absoluteLeft, this.scrollY -= t.absoluteTop, t.viewLeft += t.absoluteLeft, t.viewTop += t.absoluteTop, this.scroll(this.scrollX, this.scrollY), this.scrollbar && (this.flyout ? this.scrollbar.resizeView(t) : this.scrollbar.resizeContent(t));
        }
        getScale() {
          return this.scale;
        }
        getAbsoluteScale() {
          var t = (i) => {
            if (i.isFlyout) {
              let o, s = (o = i.targetWorkspace) == null ? void 0 : o.getFlyout();
              if (s instanceof qr) return s.getFlyoutScale();
            }
            return i.getScale();
          }, e = (i, o) => i.options.parentWorkspace && i.options.parentWorkspace.getSvgGroup().contains(i.getSvgGroup()) ? e(i.options.parentWorkspace, o * t(i)) : o * t(i);
          return e(this, 1);
        }
        scroll(t, e, i = !0) {
          i && this.hideChaff(!0), i = this.getMetrics(), t = Math.min(t, -i.scrollLeft), e = Math.min(e, -i.scrollTop);
          var o = i.scrollTop + Math.max(0, i.scrollHeight - i.viewHeight);
          t = Math.round(Math.max(t, -(i.scrollLeft + Math.max(0, i.scrollWidth - i.viewWidth)))), e = Math.round(Math.max(e, -o)), this.scrollX = t, this.scrollY = e, this.scrollbar && this.scrollbar.set(-(t + i.scrollLeft), -(e + i.scrollTop), !1), t += i.absoluteLeft, e += i.absoluteTop, this.translate(t, e);
        }
        getBlockById(t) {
          return super.getBlockById(t);
        }
        getAllBlocks(t = !1) {
          return super.getAllBlocks(t);
        }
        getTopBlocks(t = !1) {
          return super.getTopBlocks(t);
        }
        addTopBlock(t) {
          this.addTopBoundedElement(t), super.addTopBlock(t);
        }
        removeTopBlock(t) {
          this.removeTopBoundedElement(t), super.removeTopBlock(t);
        }
        addTopComment(t) {
          this.addTopBoundedElement(t), super.addTopComment(t);
        }
        removeTopComment(t) {
          this.removeTopBoundedElement(t), super.removeTopComment(t);
        }
        getTopComments(t = !1) {
          return super.getTopComments(t);
        }
        getCommentById(t) {
          return super.getCommentById(t);
        }
        getRootWorkspace() {
          return super.getRootWorkspace();
        }
        addTopBoundedElement(t) {
          this.topBoundedElements.push(t);
        }
        removeTopBoundedElement(t) {
          Qt(
            this.topBoundedElements,
            t
          );
        }
        getTopBoundedElements(t = !1) {
          var e = [].concat(this.topBoundedElements);
          return t && e.sort(this.sortByOrigin.bind(this)), e;
        }
        setResizesEnabled(t) {
          var e = !this.resizesEnabled && t;
          this.resizesEnabled = t, e && this.resizeContents();
        }
        clear() {
          this.setResizesEnabled(!1), super.clear(), this.topBoundedElements = [], this.setResizesEnabled(!0);
        }
        registerButtonCallback(t, e) {
          if (typeof e != "function") throw TypeError("Button callbacks must be functions.");
          this.flyoutButtonCallbacks.set(t, e);
        }
        getButtonCallback(t) {
          var e;
          return (e = this.flyoutButtonCallbacks.get(t)) != null ? e : null;
        }
        removeButtonCallback(t) {
          this.flyoutButtonCallbacks.delete(t);
        }
        registerToolboxCategoryCallback(t, e) {
          if (typeof e != "function") throw TypeError("Toolbox category callbacks must be functions.");
          this.toolboxCategoryCallbacks.set(t, e);
        }
        getToolboxCategoryCallback(t) {
          return this.toolboxCategoryCallbacks.get(t) || null;
        }
        removeToolboxCategoryCallback(t) {
          this.toolboxCategoryCallbacks.delete(t);
        }
        getGesture(t) {
          if (J.mover.isMoving()) return t?.preventDefault(), t?.stopPropagation(), null;
          var e = t?.type === "pointerdown", i;
          return e && ((i = this.currentGesture_) != null && i.hasStarted()) && (console.warn("Tried to start the same gesture twice."), this.currentGesture_.cancel()), !this.currentGesture_ && e && (this.currentGesture_ = new Zr(t, this)), this.currentGesture_;
        }
        clearGesture() {
          this.currentGesture_ = null;
        }
        cancelCurrentGesture() {
          this.currentGesture_ && this.currentGesture_.cancel();
        }
        getAudioManager() {
          return this.audioManager;
        }
        getGrid() {
          return this.grid;
        }
        hideChaff(t = !1) {
          Le(), As(this), Oe(), this.hideComponents(t);
        }
        hideComponents(t = !1) {
          this.getComponentManager().getComponents(nt.Capability.AUTOHIDEABLE, !0).forEach((e) => e.autoHide(t));
        }
        static setTopLevelWorkspaceMetrics(t) {
          var e = this.getMetrics();
          typeof t.x == "number" && (this.scrollX = -(e.scrollLeft + (e.scrollWidth - e.viewWidth) * t.x)), typeof t.y == "number" && (this.scrollY = -(e.scrollTop + (e.scrollHeight - e.viewHeight) * t.y)), this.translate(this.scrollX + e.absoluteLeft, this.scrollY + e.absoluteTop);
        }
        addClass(t) {
          this.injectionDiv && b(this.injectionDiv, t);
        }
        removeClass(t) {
          this.injectionDiv && Y(this.injectionDiv, t);
        }
        setIsReadOnly(t) {
          super.setIsReadOnly(t), t ? this.addClass("blocklyReadOnly") : this.removeClass("blocklyReadOnly");
        }
        scrollBoundsIntoView(t, e = 10) {
          if (!Zr.inProgress()) {
            var i = this.getScale(), o = this.getMetricsManager().getViewMetrics(!0);
            if (o = new F(o.top, o.top + o.height, o.left, o.left + o.width), !(t.left >= o.left && t.top >= o.top && t.right <= o.right && t.bottom <= o.bottom)) {
              t = t.clone(), t.top -= e, t.bottom += e, t.left -= e, t.right += e;
              var s = e = 0;
              t.left < o.left ? e = this.RTL ? Math.min(o.left - t.left, o.right - t.right) : o.left - t.left : t.right > o.right && (e = this.RTL ? o.right - t.right : Math.max(o.right - t.right, o.left - t.left)), t.top < o.top ? s = o.top - t.top : t.bottom > o.bottom && (s = Math.max(o.bottom - t.bottom, o.top - t.top)), this.scroll(this.scrollX + e * i, this.scrollY + s * i, !1);
            }
          }
        }
        getFocusableElement() {
          return this.svgGroup_;
        }
        getFocusableTree() {
          return this;
        }
        onNodeFocus() {
          this.maybeAnnounceScreenreaderHint();
        }
        handleWorkspaceFocusTargetFocus() {
          this.updateAriaLabel(), this.maybeAnnounceScreenreaderHint();
        }
        maybeAnnounceScreenreaderHint() {
          Ot.everFocused || this.options.parentWorkspace || (ue(r.C.SCREENREADER_HINT.replace("%1", $e(B.TOGGLE_SCREENREADER))), Ot.everFocused = !0);
        }
        onNodeBlur() {
        }
        canBeFocused() {
          return !0;
        }
        getRootFocusableNode() {
          return this;
        }
        getRestoredFocusableNode(t) {
          if (t) return t;
          var e;
          if (t = (e = this.targetWorkspace) == null ? void 0 : e.getFlyout(), this.isFlyout && t) {
            let i, o;
            return (o = (i = t.getContents().find((s) => (s = s.getElement(), li(s) && s.canBeFocused()))) == null ? void 0 : i.getElement()) != null ? o : null;
          }
          if (this.isMutator) {
            let i;
            return (i = this.getTopBlocks(!0)[0]) != null ? i : null;
          }
          return this.workspaceFocusTarget;
        }
        getWorkspaceFocusTarget() {
          return this.workspaceFocusTarget;
        }
        getNestedTrees() {
          var t = hi().filter((i) => i.isMutator && i.options.parentWorkspace === this), e = this.getFlyout(!0);
          return e && t.push(e.getWorkspace()), t;
        }
        searchForWorkspaceComment(t) {
          for (let e of this.getTopComments()) if (e instanceof ro && e.canBeFocused() && e.getFocusableElement().id === t) return e;
        }
        lookUpFocusableNode(t) {
          if (this.workspaceFocusTargetElement && this.workspaceFocusTargetElement.id === t) return this.workspaceFocusTarget;
          var e, i = (e = this.targetWorkspace) == null ? void 0 : e.getFlyout();
          if (this.isFlyout && i) {
            for (var o of i.getContents()) if (e = o.getElement(), li(e) && e.canBeFocused() && e.getFocusableElement().id === t) return e;
          }
          if (o = t.indexOf("_field_"), e = t.indexOf("_connection_"), o !== -1) {
            var s = t.substring(0, o);
            if (s = this.getBlockById(s)) {
              for (var n of s.getFields()) if (n.canBeFocused() && n.getFocusableElement().id === t) return n;
            }
            return null;
          }
          if (e !== -1) {
            if (s = t.substring(0, e), s = this.getBlockById(s)) {
              for (let c of s.getConnections_(!0)) if (c.id === t) return c;
            }
            return null;
          }
          if (n = Math.max(t.indexOf("_comment_textarea_"), t.indexOf("_collapse_bar_button"), t.indexOf("_delete_bar_button")), n !== -1 && (n = t.substring(0, n), n = this.searchForWorkspaceComment(n))) {
            if (t.indexOf("_comment_textarea_") > -1) return n.getEditorFocusableNode();
            var l;
            return (l = n.view.getCommentBarButtons().find((c) => c.id.includes(t))) != null ? l : null;
          }
          if ((l = this.getAllBlocks(!1).find((c) => c.getFocusableElement().id === t)) || (l = this.searchForWorkspaceComment(t))) return l;
          l = this.getAllBlocks().map((c) => c.getIcons()).flat();
          for (var a of l) {
            if (a.canBeFocused() && a.getFocusableElement().id === t) return a;
            if (De(a)) {
              if ((l = a.getBubble()) && l.canBeFocused() && l.getFocusableElement().id === t) return l;
              if (l instanceof ru && l.getEditor().getFocusableElement().id === t) return l.getEditor();
            }
          }
          a = this.getComponentManager().getComponents(nt.Capability.FOCUSABLE, !1);
          for (s of a) if (s.getFocusableElement().getAttribute("id") === t) return s;
          return null;
        }
        onTreeFocus() {
          this.updateAriaLabel();
        }
        onTreeBlur(t) {
          if (this.isFlyout && this.targetWorkspace) {
            var e = this.targetWorkspace.getToolbox();
            e && t === e || r.t().ephemeralFocusTaken() && t !== this.targetWorkspace || (e && typeof e.autoHide == "function" ? e.autoHide(!1) : (t = this.targetWorkspace.getFlyout()) && typeof t.autoHide == "function" && t.autoHide(!1));
          }
        }
        performAction() {
          Xt.show(this, { message: r.C.KEYBOARD_NAV_WORKSPACE_NAVIGATION_HINT, id: "workspaceNavigationHint" });
        }
        getNavigator() {
          return this.navigator;
        }
        setNavigator(t) {
          this.navigator = t;
        }
      };
      Ot.everFocused = !1;
      var Rp = class {
        constructor(t, e, i, o) {
          this.workspace = t, this.name = e, this.type = i || "", this.id = o || je();
        }
        getId() {
          return this.id;
        }
        getName() {
          return this.name;
        }
        setName(t) {
          return this.name = t, this;
        }
        getType() {
          return this.type;
        }
        setType(t) {
          return this.type = t, this;
        }
        getWorkspace() {
          return this.workspace;
        }
        save() {
          var t = { name: this.getName(), id: this.getId() }, e = this.getType();
          return e && (t.type = e), t;
        }
        static load(t, e) {
          t = new this(e, t.name, t.type, t.id), e.getVariableMap().addVariable(t), N(new (D(p.VAR_CREATE))(t));
        }
      };
      P(_.VARIABLE_MODEL, "default", Rp);
      var Ap = class {
        constructor(t, e = !1) {
          this.workspace = t, this.potentialMap = e, this.variableMap = /* @__PURE__ */ new Map();
        }
        clear() {
          for (let t of this.variableMap.values()) for (let e of t.values()) this.deleteVariable(e);
          if (this.variableMap.size !== 0) throw Error("Non-empty variable map");
        }
        renameVariable(t, e) {
          if (t.getName() === e) return t;
          var i = t.getType();
          i = this.getVariable(e, i);
          var o = this.workspace.getAllBlocks(!1), s = "";
          this.potentialMap || (s = r.gd) || r.B(!0);
          try {
            i && i.getId() !== t.getId() ? this.renameVariableWithConflict(t, e, i, o) : this.renameVariableAndUses(
              t,
              e,
              o
            );
          } finally {
            this.potentialMap || r.B(s);
          }
          return t;
        }
        changeVariableType(t, e) {
          var i = t.getType();
          if (i === e) return t;
          var o = this.variableMap.get(i);
          o?.delete(t.getId()), o?.size === 0 && this.variableMap.delete(i), t.setType(e);
          var s;
          return o = (s = this.variableMap.get(e)) != null ? s : /* @__PURE__ */ new Map(), o.set(t.getId(), t), this.variableMap.has(e) || this.variableMap.set(e, o), N(new (D(p.VAR_TYPE_CHANGE))(t, i, e)), t;
        }
        renameVariableAndUses(t, e, i) {
          for (this.potentialMap || N(new (D(p.VAR_RENAME))(t, e)), t.setName(e), e = 0; e < i.length; e++) i[e].updateVarName(t);
        }
        renameVariableWithConflict(t, e, i, o) {
          var s = t.getType(), n = i.getName();
          for (e !== n && this.renameVariableAndUses(i, e, o), e = 0; e < o.length; e++) o[e].renameVarById(t.getId(), i.getId());
          this.potentialMap || N(new (D(p.VAR_DELETE))(t));
          var l;
          (l = this.variableMap.get(s)) == null || l.delete(t.getId());
        }
        createVariable(t, e, i) {
          var o = this.getVariable(t, e);
          if (o) {
            if (i && o.getId() !== i) throw Error('Variable "' + t + '" is already in use and its id is "' + o.getId() + '" which conflicts with the passed in id, "' + i + '".');
            return o;
          }
          if (i && this.getVariableById(i)) throw Error('Variable id, "' + i + '", is already in use.');
          if (o = i || je(), e = e || "", i = Pt(_.VARIABLE_MODEL, this.workspace.options, !0), !i) throw Error("No variable model is registered.");
          o = new i(this.workspace, t, e, o);
          var s;
          return t = (s = this.variableMap.get(e)) != null ? s : /* @__PURE__ */ new Map(), t.set(o.getId(), o), this.variableMap.has(e) || this.variableMap.set(e, t), this.potentialMap || N(new (D(p.VAR_CREATE))(o)), o;
        }
        addVariable(t) {
          var e = t.getType();
          this.variableMap.has(e) || this.variableMap.set(
            e,
            /* @__PURE__ */ new Map()
          );
          var i;
          (i = this.variableMap.get(e)) == null || i.set(t.getId(), t);
        }
        deleteVariable(t) {
          var e = Un(this.workspace, t.getId()), i = "";
          this.potentialMap || (i = r.gd) || r.B(!0);
          try {
            for (let s = 0; s < e.length; s++) e[s].isDeadOrDying() || e[s].dispose(!0);
            let o = this.variableMap.get(t.getType());
            o && o.has(t.getId()) && (o.delete(t.getId()), this.potentialMap || N(new (D(p.VAR_DELETE))(t)), o.size === 0 && this.variableMap.delete(t.getType()));
          } finally {
            this.potentialMap || r.B(i);
          }
        }
        getVariable(t, e) {
          if (e = this.variableMap.get(e || ""), !e) return null;
          var i;
          return (i = [...e.values()].find((o) => r.Cj.equals(o.getName(), t))) != null ? i : null;
        }
        getVariableById(t) {
          for (let e of this.variableMap.values()) if (e.has(t)) {
            let i;
            return (i = e.get(t)) != null ? i : null;
          }
          return null;
        }
        getVariablesOfType(t) {
          return (t = this.variableMap.get(t || "")) ? [...t.values()] : [];
        }
        getTypes() {
          return [...this.variableMap.keys()];
        }
        getAllVariables() {
          var t = [];
          for (let e of this.variableMap.values()) t = t.concat(...e.values());
          return t;
        }
      };
      P(_.VARIABLE_MAP, "default", Ap);
      var Np = class extends jr {
        constructor(t) {
          super(), this.workspace = t, this.id = "trashcan", this.uniqueId = It(), this.contents = [], this.flyout = null, this.isLidOpen = !1, this.svgGroup = null, this.top = this.left = 0, this.initialized = !1, this.workspace.options.maxTrashcanContents <= 0 || (t = this.workspace.copyOptionsForFlyout(), this.workspace.horizontalLayout ? (t.toolboxPosition = this.workspace.toolboxPosition === I.TOP ? I.BOTTOM : I.TOP, this.flyout = new (Pt(_.FLYOUTS_HORIZONTAL_TOOLBOX, this.workspace.options, !0))(t)) : (t.toolboxPosition = this.workspace.toolboxPosition === I.RIGHT ? I.LEFT : I.RIGHT, this.flyout = new (Pt(_.FLYOUTS_VERTICAL_TOOLBOX, this.workspace.options, !0))(t)), this.workspace.addChangeListener(this.onDelete.bind(this)));
        }
        createDom() {
          this.svgGroup = v(g.G, { class: "blocklyTrash", tabindex: "0", id: this.uniqueId }), v(g.RECT, { width: 55, height: 68, x: -4, y: -4, rx: 2, ry: 2, fill: "none", class: "blocklyFocusRing" }, this.svgGroup), G(this.svgGroup, W.BUTTON), w(this.svgGroup, y.LABEL, r.C.ARIA_LABEL_TRASH_EMPTY), w(this.svgGroup, y.DISABLED, !0);
          var t = String(Math.random()).substring(2), e = v(g.CLIPPATH, { id: "blocklyTrashBodyClipPath" + t }, this.svgGroup);
          return v(g.RECT, { width: 47, height: 44, y: 16 }, e), v(g.IMAGE, { width: Kt.width, x: -0, height: Kt.height, y: -32, "clip-path": "url(#blocklyTrashBodyClipPath" + t + ")" }, this.svgGroup).setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", this.workspace.options.pathToMedia + Kt.url), e = v(g.CLIPPATH, { id: "blocklyTrashLidClipPath" + t }, this.svgGroup), v(g.RECT, { width: 47, height: 16 }, e), e = v(g.G, { class: "blocklyTrashLid" }, this.svgGroup), e = v(g.SVG, { viewBox: "0 32 47 16", width: 47, height: 16 }, e), v(g.IMAGE, { width: Kt.width, height: Kt.height, href: this.workspace.options.pathToMedia + Kt.url }, e), jt(this.svgGroup, "pointerdown", this, this.blockMouseDownWhenOpenable), jt(this.svgGroup, "pointerup", this, this.click), jt(this.svgGroup, "keydown", this, this.onKeyDown), this.svgGroup;
        }
        init() {
          if (this.workspace.options.maxTrashcanContents > 0) {
            let t = this.flyout.createDom(g.SVG);
            b(t, "blocklyTrashcanFlyout"), us(t, this.workspace.getParentSvg()), this.flyout.init(this.workspace);
          }
          this.workspace.getComponentManager().addComponent({
            component: this,
            weight: nt.ComponentWeight.TRASHCAN_WEIGHT,
            capabilities: [nt.Capability.AUTOHIDEABLE, nt.Capability.DELETE_AREA, nt.Capability.DRAG_TARGET, nt.Capability.POSITIONABLE]
          }), this.initialized = !0, this.setLidOpen(!1);
        }
        dispose() {
          this.workspace.getComponentManager().removeComponent("trashcan");
          var t;
          (t = this.flyout) == null || t.dispose(), this.flyout = null, this.svgGroup && Q(this.svgGroup);
        }
        hasContents() {
          return !!this.contents.length;
        }
        contentsIsOpen() {
          return !!this.flyout && this.flyout.isVisible();
        }
        openFlyout() {
          if (!this.contentsIsOpen()) {
            var t = this.contents.map(function(i) {
              return JSON.parse(i);
            }), e = this.workspace.getParentSvg().style;
            e.cursor = "wait", setTimeout(() => {
              var i;
              (i = this.flyout) == null || i.show(t), e.cursor = "";
              var o;
              if ((o = this.workspace.scrollbar) == null || o.setVisible(!1), st.getIsActive()) {
                let s, n;
                (i = (n = (s = this.flyout) == null ? void 0 : s.getWorkspace()) == null ? void 0 : n.getNavigator().getFirstNode()) && r.t().focusNode(i);
              }
            }, 10), this.fireUiEvent(!0);
          }
        }
        closeFlyout() {
          if (this.contentsIsOpen()) {
            var t;
            (t = this.flyout) == null || t.hide();
            var e;
            (e = this.workspace.scrollbar) == null || e.setVisible(!0), this.fireUiEvent(!1), this.workspace.recordDragTargets();
          }
        }
        autoHide(t) {
          !t && this.flyout && this.closeFlyout();
        }
        emptyContents() {
          this.hasContents() && this.svgGroup && (this.contents.length = 0, this.svgGroup.classList.remove("blocklyTrashFull"), w(this.svgGroup, y.LABEL, r.C.ARIA_LABEL_TRASH_EMPTY), w(this.svgGroup, y.DISABLED, !0), this.closeFlyout());
        }
        position(t, e) {
          if (this.initialized) {
            var i = In(this.workspace, t);
            t = wn(i, new H(47, 60), 20, 20, t, this.workspace), e = Sn(t, 20, i.vertical === ei.TOP ? yi.DOWN : yi.UP, e), this.top = e.top, this.left = e.left;
            var o;
            (o = this.svgGroup) == null || o.setAttribute("transform", "translate(" + this.left + "," + this.top + ")");
            var s;
            (s = this.flyout) == null || s.position();
          }
        }
        getBoundingRectangle() {
          return new F(this.top, this.top + 44 + 16, this.left, this.left + 47);
        }
        getClientRect() {
          if (!this.svgGroup) return null;
          var t = this.svgGroup.getBoundingClientRect(), e = t.top + 32 - 10;
          return t = t.left + 0 - 10, new F(e, e + 16 + 44 + 20, t, t + 47 + 20);
        }
        onDragOver() {
          J.mover.isMoving() || this.setLidOpen(this.wouldDelete_);
        }
        onDragExit() {
          J.mover.isMoving() || this.setLidOpen(!1);
        }
        onDrop() {
          J.mover.isMoving() || setTimeout(this.setLidOpen.bind(this, !1), 100);
        }
        setLidOpen(t) {
          if (this.isLidOpen !== t) {
            this.isLidOpen = t;
            var e;
            (e = this.svgGroup) == null || e.classList.toggle("blocklyTrashOpen", t);
          }
        }
        closeLid() {
          this.setLidOpen(!1);
        }
        click() {
          this.hasContents() && !this.workspace.isDragging() && this.openFlyout();
        }
        onKeyDown(t) {
          (t.key === "Enter" || t.key === " ") && (t.preventDefault(), this.click());
        }
        fireUiEvent(t) {
          t = new (D(p.TRASHCAN_OPEN))(t, this.workspace.id), N(t);
        }
        blockMouseDownWhenOpenable(t) {
          !this.contentsIsOpen() && this.hasContents() && t.stopPropagation();
        }
        onDelete(t) {
          if (!(this.workspace.options.maxTrashcanContents <= 0 || t.type !== p.BLOCK_DELETE || t.wasShadow) && this.svgGroup) {
            if (!t.oldJson) throw Error("Encountered a delete event without proper oldJson");
            if (t = JSON.stringify(this.cleanBlockJson(t.oldJson)), !this.contents.includes(t)) {
              for (this.contents.unshift(t); this.contents.length > this.workspace.options.maxTrashcanContents; ) this.contents.pop();
              this.svgGroup.classList.add("blocklyTrashFull"), w(
                this.svgGroup,
                y.LABEL,
                r.C.OPEN_TRASH
              ), Co(this.svgGroup, y.DISABLED);
            }
          }
        }
        cleanBlockJson(t) {
          function e(i) {
            if (i) {
              if (delete i.id, delete i.x, delete i.y, delete i.enabled, delete i.disabledReasons, i.icons && i.icons.comment) {
                var o = i.icons.comment;
                delete o.height, delete o.width, delete o.pinned;
              }
              o = i.inputs;
              for (var s in o) {
                var n = o[s];
                let l = n.block;
                n = n.shadow, l && e(l), n && e(n);
              }
              i.next && (s = i.next, i = s.block, s = s.shadow, i && e(i), s && e(s));
            }
          }
          return t = JSON.parse(JSON.stringify(t)), e(t), Object.assign({}, { kind: "BLOCK" }, t);
        }
      };
      ce(`
  .blocklyTrash > image {
    opacity: 0.4;
    transition: opacity 0.08s ease-out;
  }

  .blocklyTrashLid {
    opacity: 0.4;
    transition: rotate 0.08s ease-out, opacity 0.08s ease-out;
    transform-origin: 46px 12px;
    rotate: 0deg;
    pointer-events: none;
  }

  .blocklyRTL .blocklyTrashLid {
    transform-origin: 0px 12px;
  }

  .blocklyTrash.blocklyTrashFull .blocklyTrashLid {
    rotate: 5deg;
  }

  .blocklyRTL .blocklyTrash.blocklyTrashFull .blocklyTrashLid {
    rotate: -5deg;
  }

  .blocklyTrash.blocklyTrashOpen > image,
  .blocklyTrash.blocklyTrashOpen > .blocklyTrashLid,
  .blocklyTrash.blocklyTrashFull:hover > image,
  .blocklyTrash.blocklyTrashFull:hover > .blocklyTrashLid,
  .blocklyTrash.blocklyTrashFull:focus > image,
  .blocklyTrash.blocklyTrashFull:focus > .blocklyTrashLid {
    opacity: 0.8;
  }

  .blocklyTrash.blocklyTrashOpen .blocklyTrashLid,
  .blocklyTrash.blocklyTrashFull:hover .blocklyTrashLid,
  .blocklyTrash.blocklyTrashFull:focus .blocklyTrashLid {
    rotate: 45deg;
  }

  .blocklyRTL .blocklyTrash.blocklyTrashOpen .blocklyTrashLid,
  .blocklyRTL .blocklyTrash.blocklyTrashFull:hover .blocklyTrashLid,
  .blocklyRTL .blocklyTrash.blocklyTrashFull:focus .blocklyTrashLid {
    rotate: -45deg;
  }
`);
      var Sf = class {
        constructor(t, e) {
          this.procedureModelClass = t, this.parameterModelClass = e, this.priority = 75;
        }
        save(t) {
          return t = t.getProcedureMap().getProcedures().map((e) => Uh(e)), t.length ? t : null;
        }
        load(t, e) {
          var i = e.getProcedureMap();
          for (let o of t) i.add(Wh(this.procedureModelClass, this.parameterModelClass, o, e));
        }
        clear(t) {
          t.getProcedureMap().clear();
        }
      }, rl = {};
      rl.ProcedureSerializer = Sf, rl.loadProcedure = Wh, rl.saveProcedure = Uh;
      var Dp = class {
        constructor() {
          this.priority = 100;
        }
        save(t) {
          return t = t.getVariableMap().getAllVariables().map((e) => e.save()), t.length ? t : null;
        }
        load(t, e) {
          var i = Mt(_.VARIABLE_MODEL, "default", void 0);
          t.forEach((o) => {
            i?.load(o, e);
          });
        }
        clear(t) {
          t.getVariableMap().clear();
        }
      };
      Ts("variables", new Dp());
      var Op = {};
      Op.VariableSerializer = Dp;
      var Rf = { blocks: Ks, exceptions: Qi, priorities: { BLOCKS: 50, PROCEDURES: 75, VARIABLES: 100, WORKSPACE_COMMENTS: 25 }, procedures: rl, registry: yc, variables: Op, workspaceComments: Cr, workspaces: { load: function(t, e, { recordUndo: i = !1 } = {}) {
        var o = fn(_.SERIALIZER, !0);
        if (o) {
          o = Object.entries(o).sort((n, l) => l[1].priority - n[1].priority);
          var s = r.Qc;
          r.Qc = i, (i = r.gd) || r.B(!0), Li(), e instanceof Ot && e.setResizesEnabled(!1);
          for (let [, n] of o.reverse()) {
            let l;
            (l = n) == null || l.clear(e);
          }
          for (let [n, l] of o.reverse()) if (t[n]) {
            let a;
            (a = l) == null || a.load(t[n], e);
          }
          e instanceof Ot && e.setResizesEnabled(!0), xi(), N(new (D(p.FINISHED_LOADING))(e)), r.B(i), r.Qc = s;
        }
      }, save: function(t) {
        var e = /* @__PURE__ */ Object.create(null), i = fn(_.SERIALIZER, !0);
        for (let o in i) {
          let s, n = (s = i[o]) == null ? void 0 : s.save(t);
          n && (e[o] = n);
        }
        return e;
      } } };
      "Blockly" in globalThis || (globalThis.Blockly = { Msg: Hd });
      var Lp = class {
        load(t, e) {
          return t = new Gt(e.getWorkspace(), e.targetWorkspace, t, !0), t.show(), new ss(t, "label");
        }
        gapForItem(t, e) {
          return e;
        }
        disposeItem(t) {
          t = t.getElement(), t instanceof Gt && t.dispose();
        }
        getType() {
          return "label";
        }
      };
      P(_.FLYOUT_INFLATER, "label", Lp);
      var Af = class {
        constructor() {
          this.size = new H(0, 0);
        }
        getHeightWidth() {
          return this.size;
        }
        show(t, e) {
          this.parentConnection = t, this.parentConnection.attachInsertionMarker(this);
          var i = e.getSourceBlock(), o = /* @__PURE__ */ new Map();
          for (var s of i.getConnections_(!1)) o.set(s, s.targetConnection), s.targetConnection = null;
          e.targetConnection = t, i.workspace.getRenderer().render(i), this.partiallyTighten(i, e), this.marker = this.makeMarker(i), s = i.getBoundingRectangleWithoutChildren(), this.size = new H(s.getWidth(), s.getHeight()), s = t.getSourceBlock().getRelativeToSurfaceXY();
          var n = m.difference(t.getOffsetInBlock(), e.getOffsetInBlock());
          for (let [l, a] of o.entries()) l.targetConnection = a;
          i.workspace.getRenderer().render(i), this.partiallyTighten(i, e), this.marker.setAttribute("transform", `${`translate(${s.x + n.x}, ${s.y + n.y})`} ${i.workspace.RTL ? "scale(-1, 1)" : ""}`), t.getSourceBlock().queueRender(), Ne();
        }
        hide() {
          if (this.parentConnection) {
            var t;
            (t = this.marker) == null || t.remove(), this.marker = void 0, this.parentConnection.detachInsertionMarker();
            var e;
            (e = this.parentConnection) == null || e.getSourceBlock().queueRender(), Ne(), this.parentConnection = void 0;
          }
        }
        makeMarker(t) {
          var e = v(g.G, { transform: `translate(${t.relativeCoords.x}, ${t.relativeCoords.y})`, class: "blocklyInsertionMarker" }), i;
          return v(g.PATH, { d: (i = t.pathObject.svgPath.getAttribute("d")) != null ? i : "", class: "blocklyPath" }, e), t.workspace.getCanvas().appendChild(e), e;
        }
        partiallyTighten(t, e) {
          for (let i of t.inputList) {
            if (i === e.getParentInput()) continue;
            let o = i.connection;
            o && o.tightenEfficiently();
          }
          t.nextConnection && t.nextConnection !== e && t.nextConnection.tightenEfficiently();
        }
      }, xp = class extends il {
        constructor() {
          super(), this.FIELD_TEXT_BASELINE_CENTER = !1, this.DARK_PATH_OFFSET = 1, this.MAX_BOTTOM_WIDTH = 30, this.STATEMENT_BOTTOM_SPACER = -this.NOTCH_HEIGHT / 2;
        }
        getCSS_(t) {
          return super.getCSS_(t).concat([`${t} .blocklyInsertionMarker>.blocklyPathLight,`, `${t} .blocklyInsertionMarker>.blocklyPathDark {`, `fill-opacity: ${this.INSERTION_MARKER_OPACITY};`, "stroke: none;", "}"]);
        }
      }, Bp = class {
        constructor(t) {
          this.inlineSteps_ = this.steps_ = "", this.info_ = t, this.RTL_ = this.info_.RTL, t = t.getRenderer(), this.constants_ = t.getConstants(), this.highlightConstants_ = t.getHighlightConstants(), this.highlightOffset = this.highlightConstants_.OFFSET, this.outsideCornerPaths_ = this.highlightConstants_.OUTSIDE_CORNER, this.insideCornerPaths_ = this.highlightConstants_.INSIDE_CORNER, this.puzzleTabPaths_ = this.highlightConstants_.PUZZLE_TAB, this.notchPaths_ = this.highlightConstants_.NOTCH, this.startPaths_ = this.highlightConstants_.START_HAT, this.jaggedTeethPaths_ = this.highlightConstants_.JAGGED_TEETH;
        }
        getPath() {
          return this.steps_ + `
` + this.inlineSteps_;
        }
        drawTopCorner(t) {
          this.steps_ += ct(t.xPos, this.info_.startY);
          for (let e = 0, i; i = t.elements[e]; e++) u.isLeftSquareCorner(i) ? this.steps_ += this.highlightConstants_.START_POINT : u.isLeftRoundedCorner(i) ? this.steps_ += this.outsideCornerPaths_.topLeft(this.RTL_) : u.isPreviousConnection(i) ? this.steps_ += this.notchPaths_.pathLeft : u.isHat(i) ? this.steps_ += this.startPaths_.path(this.RTL_) : u.isSpacer(i) && i.width !== 0 && (this.steps_ += A("H", i.xPos + i.width - this.highlightOffset));
          this.steps_ += A("H", t.xPos + t.width - this.highlightOffset);
        }
        drawJaggedEdge_(t) {
          this.info_.RTL && (this.steps_ += this.jaggedTeethPaths_.pathLeft + A("v", t.height - this.jaggedTeethPaths_.height - this.highlightOffset));
        }
        drawValueInput(t) {
          var e = t.getLastInput();
          if (this.RTL_) {
            let i = t.height - e.connectionHeight;
            this.steps_ += St(e.xPos + e.width - this.highlightOffset, t.yPos) + this.puzzleTabPaths_.pathDown(this.RTL_) + A("v", i);
          } else this.steps_ += St(e.xPos + e.width, t.yPos) + this.puzzleTabPaths_.pathDown(this.RTL_);
        }
        drawStatementInput(t) {
          var e = t.getLastInput();
          if (e) if (this.RTL_) {
            let i = t.height - 2 * this.insideCornerPaths_.height;
            this.steps_ += St(e.xPos, t.yPos) + this.insideCornerPaths_.pathTop(this.RTL_) + A("v", i) + this.insideCornerPaths_.pathBottom(this.RTL_) + Be(t.width - e.xPos - this.insideCornerPaths_.width, 0);
          } else this.steps_ += St(e.xPos, t.yPos + t.height) + this.insideCornerPaths_.pathBottom(this.RTL_) + Be(t.width - e.xPos - this.insideCornerPaths_.width, 0);
        }
        drawRightSideRow(t) {
          var e = t.xPos + t.width - this.highlightOffset;
          t instanceof mu && t.followsStatement && (this.steps_ += A("H", e)), this.RTL_ && (this.steps_ += A("H", e), t.height > this.highlightOffset && (this.steps_ += A("V", t.yPos + t.height - this.highlightOffset)));
        }
        drawBottomRow(t) {
          if (this.RTL_) this.steps_ += A("V", t.baseline - this.highlightOffset);
          else {
            let e = this.info_.bottomRow.elements[0];
            u.isLeftSquareCorner(e) ? this.steps_ += St(t.xPos + this.highlightOffset, t.baseline - this.highlightOffset) : u.isLeftRoundedCorner(e) && (this.steps_ += St(t.xPos, t.baseline), this.steps_ += this.outsideCornerPaths_.bottomLeft());
          }
        }
        drawLeft() {
          var t = this.info_.outputConnection;
          t && (t = t.connectionOffsetY + t.height, this.RTL_ ? this.steps_ += St(this.info_.startX, t) : (this.steps_ += St(this.info_.startX + this.highlightOffset, this.info_.bottomRow.baseline - this.highlightOffset), this.steps_ += A("V", t)), this.steps_ += this.puzzleTabPaths_.pathUp(this.RTL_)), this.RTL_ || (t = this.info_.topRow, u.isLeftRoundedCorner(t.elements[0]) ? this.steps_ += A("V", this.outsideCornerPaths_.height) : this.steps_ += A(
            "V",
            t.capline + this.highlightOffset
          ));
        }
        drawInlineInput(t) {
          var e = this.highlightOffset, i = t.xPos + t.connectionWidth, o = t.centerline - t.height / 2, s = t.width - t.connectionWidth, n = o + e;
          this.RTL_ ? (o = t.connectionOffsetY - e, t = t.height - (t.connectionOffsetY + t.connectionHeight) + e, this.inlineSteps_ += St(i - e, n) + A("v", o) + this.puzzleTabPaths_.pathDown(this.RTL_) + A("v", t) + A("h", s)) : this.inlineSteps_ += St(t.xPos + t.width + e, n) + A("v", t.height) + A("h", -s) + St(i, o + t.connectionOffsetY) + this.puzzleTabPaths_.pathDown(this.RTL_);
        }
      }, Mp = class extends ol {
        constructor(t, e) {
          super(t, e), this.highlighter_ = new Bp(e);
        }
        draw() {
          this.drawOutline_(), this.drawInternals_(), this.updateConnectionHighlights();
          var t = this.block_.pathObject;
          t.setPath(this.outlinePath_ + `
` + this.inlinePath_), t.setHighlightPath(this.highlighter_.getPath()), this.info_.RTL && t.flipRTL(), this.recordSizeOnBlock_();
        }
        drawTop_() {
          this.highlighter_.drawTopCorner(this.info_.topRow), this.highlighter_.drawRightSideRow(this.info_.topRow), super.drawTop_();
        }
        drawJaggedEdge_(t) {
          this.highlighter_.drawJaggedEdge_(t), super.drawJaggedEdge_(t);
        }
        drawValueInput_(t) {
          this.highlighter_.drawValueInput(t), super.drawValueInput_(t);
        }
        drawStatementInput_(t) {
          this.highlighter_.drawStatementInput(t), super.drawStatementInput_(t);
        }
        drawRightSideRow_(t) {
          this.highlighter_.drawRightSideRow(t), this.outlinePath_ += A("H", t.xPos + t.width) + A("V", t.yPos + t.height);
        }
        drawBottom_() {
          this.highlighter_.drawBottomRow(this.info_.bottomRow), super.drawBottom_();
        }
        drawLeft_() {
          this.highlighter_.drawLeft(), super.drawLeft_();
        }
        drawInlineInput_(t) {
          this.highlighter_.drawInlineInput(t), super.drawInlineInput_(t);
        }
        positionInlineInputConnection_(t) {
          var e = t.centerline - t.height / 2;
          if (t.connectionModel) {
            let i = t.xPos + t.connectionWidth + this.constants_.DARK_PATH_OFFSET;
            this.info_.RTL && (i *= -1), t.connectionModel.setOffsetInBlock(i, e + t.connectionOffsetY + this.constants_.DARK_PATH_OFFSET);
          }
        }
        positionStatementInputConnection_(t) {
          var e = t.getLastInput();
          if (e != null && e.connectionModel) {
            let i = t.xPos + t.statementEdge + e.notchOffset;
            i = this.info_.RTL ? i * -1 : i + this.constants_.DARK_PATH_OFFSET, e.connectionModel.setOffsetInBlock(
              i,
              t.yPos + this.constants_.DARK_PATH_OFFSET
            );
          }
        }
        positionExternalValueConnection_(t) {
          var e = t.getLastInput();
          if (e && e.connectionModel) {
            let i = t.xPos + t.width + this.constants_.DARK_PATH_OFFSET;
            this.info_.RTL && (i *= -1), e.connectionModel.setOffsetInBlock(i, t.yPos);
          }
        }
        positionNextConnection_() {
          var t = this.info_.bottomRow;
          if (t.connection) {
            let e = t.connection, i = e.xPos;
            e.connectionModel.setOffsetInBlock((this.info_.RTL ? -i : i) + this.constants_.DARK_PATH_OFFSET / 2, t.baseline + this.constants_.DARK_PATH_OFFSET);
          }
        }
      }, Pp = class {
        constructor(t) {
          this.OFFSET = 0.5, this.constantProvider = t, this.START_POINT = ct(this.OFFSET, this.OFFSET);
        }
        init() {
          this.INSIDE_CORNER = this.makeInsideCorner(), this.OUTSIDE_CORNER = this.makeOutsideCorner(), this.PUZZLE_TAB = this.makePuzzleTab(), this.NOTCH = this.makeNotch(), this.JAGGED_TEETH = this.makeJaggedTeeth(), this.START_HAT = this.makeStartHat();
        }
        makeInsideCorner() {
          var t = this.constantProvider.CORNER_RADIUS, e = this.OFFSET, i = (1 - Math.SQRT1_2) * (t + e) - e, o = ct(i, i) + dt("a", "0 0,0", t, R(-i - e, t - i)), s = dt(
            "a",
            "0 0,0",
            t + e,
            R(t + e, t + e)
          ), n = ct(i, -i) + dt("a", "0 0,0", t + e, R(t - i, i + e));
          return { width: t + e, height: t, pathTop(l) {
            return l ? o : "";
          }, pathBottom(l) {
            return l ? s : n;
          } };
        }
        makeOutsideCorner() {
          var t = this.constantProvider.CORNER_RADIUS, e = this.OFFSET, i = (1 - Math.SQRT1_2) * (t - e) + e, o = ct(i, i) + dt("a", "0 0,1", t - e, R(t - i, -i + e)), s = ct(e, t) + dt("a", "0 0,1", t - e, R(t, -t + e)), n = -i, l = ct(i, n) + dt("a", "0 0,1", t - e, R(-i + e, -n - t));
          return { height: t, topLeft(a) {
            return a ? o : s;
          }, bottomLeft() {
            return l;
          } };
        }
        makePuzzleTab() {
          var t = this.constantProvider.TAB_WIDTH, e = this.constantProvider.TAB_HEIGHT, i = ct(-2, -e + 2.5 + 0.9) + Be(t * -0.45, -2.1), o = A("v", 2.5) + ct(-t * 0.97, 2.5) + $t("q", [R(-t * 0.05, 10), R(t * 0.3, 9.5)]) + ct(t * 0.67, -1.9) + A("v", 2.5), s = A("v", -1.5) + ct(t * -0.92, -0.5) + $t("q", [R(t * -0.19, -5.5), R(0, -11)]) + ct(t * 0.92, 1), n = ct(-5, e - 0.7) + Be(t * 0.46, -2.1);
          return { width: t, height: e, pathUp(l) {
            return l ? i : s;
          }, pathDown(l) {
            return l ? o : n;
          } };
        }
        makeNotch() {
          return { pathLeft: A("h", this.OFFSET) + this.constantProvider.NOTCH.pathLeft };
        }
        makeJaggedTeeth() {
          return { pathLeft: Be(5.1, 2.6) + ct(-10.2, 6.8) + Be(5.1, 2.6), height: 12, width: 10.2 };
        }
        makeStartHat() {
          var t = this.constantProvider.START_HAT.height, e = ct(25, -8.7) + $t("c", [R(29.7, -6.2), R(57.2, -0.5), R(75, 8.7)]), i = $t("c", [R(17.8, -9.2), R(45.3, -14.9), R(75, -8.7)]) + St(100.5, t + 0.5);
          return { path(o) {
            return o ? e : i;
          } };
        }
      }, Fp = class extends vu {
        constructor(t, e) {
          super(t, e), this.constants_ = t, this.connectedBlock && (this.width += this.constants_.DARK_PATH_OFFSET, this.height += this.constants_.DARK_PATH_OFFSET);
        }
      }, Hp = class extends el {
        constructor(t, e) {
          super(t, e), this.constants_ = t, this.connectedBlock && (this.height += this.constants_.DARK_PATH_OFFSET);
        }
      }, Up = class extends sn {
        constructor(t, e) {
          super(t, e), this.renderer_ = t;
        }
        getRenderer() {
          return this.renderer_;
        }
        populateBottomRow_() {
          super.populateBottomRow_(), this.block_.inputList.length && this.block_.inputList[this.block_.inputList.length - 1] instanceof re || (this.bottomRow.minHeight = this.constants_.MEDIUM_PADDING - this.constants_.DARK_PATH_OFFSET);
        }
        addInput_(t, e) {
          this.isInline && t instanceof r.go ? (e.elements.push(new Fp(this.constants_, t)), e.hasInlineInput = !0) : t instanceof re ? (e.elements.push(new Hp(
            this.constants_,
            t
          )), e.hasStatement = !0) : t instanceof r.go ? (e.elements.push(new fu(this.constants_, t)), e.hasExternalInput = !0) : (t instanceof Ge || t instanceof ri) && (e.minHeight = Math.max(e.minHeight, this.constants_.DUMMY_INPUT_MIN_HEIGHT), e.hasDummyInput = !0), this.isInline || e.align !== null || (e.align = t.align);
        }
        addElemSpacing_() {
          var t = !1;
          for (let i = 0, o; o = this.rows[i]; i++) o.hasExternalInput && (t = !0);
          for (let i = 0, o; o = this.rows[i]; i++) {
            var e = o.elements;
            if (o.elements = [], o.startsWithElemSpacer() && o.elements.push(new he(
              this.constants_,
              this.getInRowSpacing_(null, e[0])
            )), e.length) {
              for (let s = 0; s < e.length - 1; s++) {
                o.elements.push(e[s]);
                let n = this.getInRowSpacing_(e[s], e[s + 1]);
                o.elements.push(new he(this.constants_, n));
              }
              o.elements.push(e[e.length - 1]), o.endsWithElemSpacer() && (e = this.getInRowSpacing_(e[e.length - 1], null), t && o.hasDummyInput && (e += this.constants_.TAB_WIDTH), o.elements.push(new he(this.constants_, e)));
            }
          }
        }
        getInRowSpacing_(t, e) {
          if (!t) return e && u.isField(e) && e.isEditable ? this.constants_.MEDIUM_PADDING : e && u.isInlineInput(e) ? this.constants_.MEDIUM_LARGE_PADDING : e && u.isStatementInput(e) ? this.constants_.STATEMENT_INPUT_PADDING_LEFT : this.constants_.LARGE_PADDING;
          if (!u.isInput(t) && (!e || u.isStatementInput(e))) return u.isField(t) && t.isEditable ? t.width === 0 ? this.constants_.NO_PADDING : this.constants_.MEDIUM_PADDING : u.isIcon(t) ? this.constants_.LARGE_PADDING * 2 + 1 : u.isHat(t) ? this.constants_.NO_PADDING : u.isPreviousOrNextConnection(t) ? this.constants_.LARGE_PADDING : u.isLeftRoundedCorner(t) ? this.constants_.MIN_BLOCK_WIDTH : u.isJaggedEdge(t) ? this.constants_.NO_PADDING : this.constants_.LARGE_PADDING;
          if (u.isInput(t) && !e) {
            if (u.isExternalInput(t)) return this.constants_.NO_PADDING;
            if (u.isInlineInput(t)) return this.constants_.LARGE_PADDING;
            if (u.isStatementInput(t)) return this.constants_.NO_PADDING;
          }
          if (!u.isInput(t) && e && u.isInput(e)) {
            if (u.isField(t) && t.isEditable) {
              if (u.isInlineInput(e) || u.isExternalInput(e)) return this.constants_.SMALL_PADDING;
            } else {
              if (u.isInlineInput(e) || u.isExternalInput(e)) return this.constants_.MEDIUM_LARGE_PADDING;
              if (u.isStatementInput(e)) return this.constants_.LARGE_PADDING;
            }
            return this.constants_.LARGE_PADDING - 1;
          }
          if (u.isIcon(t) && e && !u.isInput(e)) return this.constants_.LARGE_PADDING;
          if (u.isInlineInput(t) && e && u.isField(e)) return e.isEditable ? this.constants_.MEDIUM_PADDING : this.constants_.LARGE_PADDING;
          if (u.isLeftSquareCorner(t) && e) {
            if (u.isHat(e)) return this.constants_.NO_PADDING;
            if (u.isPreviousConnection(e)) return e.notchOffset;
            if (u.isNextConnection(e)) return e.notchOffset + (this.RTL ? 1 : -1) * this.constants_.DARK_PATH_OFFSET / 2;
          }
          if (u.isLeftRoundedCorner(t) && e) {
            if (u.isPreviousConnection(e)) return e.notchOffset - this.constants_.CORNER_RADIUS;
            if (u.isNextConnection(e)) return e.notchOffset - this.constants_.CORNER_RADIUS + (this.RTL ? 1 : -1) * this.constants_.DARK_PATH_OFFSET / 2;
          }
          return u.isField(t) && e && u.isField(e) && t.isEditable === e.isEditable ? t.width === 0 ? this.constants_.NO_PADDING : this.constants_.LARGE_PADDING : e && u.isJaggedEdge(e) ? this.constants_.LARGE_PADDING : this.constants_.MEDIUM_PADDING;
        }
        getSpacerRowHeight_(t, e) {
          return u.isTopRow(t) && u.isBottomRow(e) ? this.constants_.EMPTY_BLOCK_SPACER_HEIGHT : u.isTopRow(t) || u.isBottomRow(e) ? this.constants_.NO_PADDING : t.hasExternalInput && e.hasExternalInput ? this.constants_.LARGE_PADDING : !t.hasStatement && e.hasStatement ? this.constants_.BETWEEN_STATEMENT_PADDING_Y : t.hasStatement && e.hasStatement || !t.hasStatement && e.hasDummyInput || t.hasDummyInput ? this.constants_.LARGE_PADDING : this.constants_.MEDIUM_PADDING;
        }
        getElemCenterline_(t, e) {
          if (u.isSpacer(e)) return t.yPos + e.height / 2;
          if (u.isBottomRow(t)) return t = t.yPos + t.height - t.descenderHeight, u.isNextConnection(e) ? t + e.height / 2 : t - e.height / 2;
          if (u.isTopRow(t)) return u.isHat(e) ? t.capline - e.height / 2 : t.capline + e.height / 2;
          var i = t.yPos;
          return u.isField(e) || u.isIcon(e) ? (i += e.height / 2, (t.hasInlineInput || t.hasStatement) && e.height + this.constants_.TALL_INPUT_FIELD_OFFSET_Y <= t.height && (i += this.constants_.TALL_INPUT_FIELD_OFFSET_Y)) : i = u.isInlineInput(e) ? i + e.height / 2 : i + t.height / 2, i;
        }
        alignRowElements_() {
          if (this.isInline) {
            var t = 0, e = /* @__PURE__ */ new WeakMap(), i = null;
            for (let o = this.rows.length - 1, s; s = this.rows[o]; o--) e.set(s, t), u.isInputRow(s) && (s.hasStatement && this.alignStatementRow_(s), i && i.hasStatement && s.width < i.width ? e.set(s, i.width) : t = s.hasStatement ? s.width : Math.max(t, s.width), i = s);
            t = 0;
            for (let o = 0, s; s = this.rows[o]; o++) s.hasStatement ? t = this.getDesiredRowWidth_(s) : u.isSpacer(s) ? s.width = Math.max(t, e.get(s)) : (i = s.width, t = Math.max(t, e.get(s)) - i, t > 0 && this.addAlignmentPadding_(s, t), t = s.width);
          } else super.alignRowElements_();
        }
        getDesiredRowWidth_(t) {
          return this.isInline && t.hasStatement ? this.statementEdge + this.constants_.MAX_BOTTOM_WIDTH + this.startX : super.getDesiredRowWidth_(t);
        }
        finalize_() {
          var t = 0, e = 0;
          for (let o = 0, s; s = this.rows[o]; o++) {
            s.yPos = e, s.xPos = this.startX, e += s.height, t = Math.max(t, s.widthWithConnectedBlocks);
            var i = e - this.topRow.ascenderHeight;
            s === this.bottomRow && i < this.constants_.MIN_BLOCK_HEIGHT && (i = this.constants_.MIN_BLOCK_HEIGHT - i, this.bottomRow.height += i, e += i), this.recordElemPositions_(s);
          }
          this.outputConnection && this.block_.nextConnection && this.block_.nextConnection.isConnected() && (i = this.block_.nextConnection.targetBlock()) && (t = Math.max(t, i.getHeightWidth().width - this.constants_.DARK_PATH_OFFSET)), this.bottomRow.baseline = e - this.bottomRow.descenderHeight, this.widthWithChildren = t + this.startX + this.constants_.DARK_PATH_OFFSET, this.width += this.constants_.DARK_PATH_OFFSET, this.height = e + this.constants_.DARK_PATH_OFFSET, this.startY = this.topRow.capline;
        }
      }, Wp = class extends sl {
        constructor(t, e, i) {
          super(t, e, i), this.constants = i, this.colourDark = "#000000", this.svgPathDark = v(g.PATH, { class: "blocklyPathDark", transform: "translate(1,1)" }), this.svgRoot.insertBefore(this.svgPathDark, this.svgPath), this.svgPathLight = v(g.PATH, { class: "blocklyPathLight" }, this.svgRoot);
        }
        setPath(t) {
          this.svgPath.setAttribute("d", t), this.svgPathDark.setAttribute("d", t);
        }
        setHighlightPath(t) {
          this.svgPathLight.setAttribute("d", t);
        }
        flipRTL() {
          this.svgPath.setAttribute("transform", "scale(-1 1)"), this.svgPathLight.setAttribute("transform", "scale(-1 1)"), this.svgPathDark.setAttribute("transform", "translate(1,1) scale(-1 1)");
        }
        applyColour(t) {
          this.svgPathLight.style.display = "", this.svgPathDark.style.display = "", this.svgPathLight.setAttribute("stroke", this.style.colourTertiary), this.svgPathDark.setAttribute("fill", this.colourDark), super.applyColour(t), this.svgPath.setAttribute("stroke", "none");
        }
        setStyle(t) {
          this.style = t, this.colourDark = Wi("#000", this.style.colourPrimary, 0.2) || this.colourDark;
        }
        updateHighlighted(t) {
          super.updateHighlighted(t), this.svgPathLight.style.display = t ? "none" : "inline";
        }
        updateShadow_(t) {
          super.updateShadow_(t), t && (this.svgPathLight.style.display = "none", this.svgPathDark.setAttribute("fill", this.style.colourSecondary));
        }
        updateDisabled_(t) {
          super.updateDisabled_(t), t && this.svgPath.setAttribute("stroke", "none");
        }
      }, yu = class extends nl {
        constructor(t) {
          super(t), this.highlightConstants = null;
        }
        init(t, e) {
          super.init(t, e), this.highlightConstants = this.makeHighlightConstants_(), this.highlightConstants.init();
        }
        refreshDom(t, e, i) {
          super.refreshDom(t, e, i), this.getHighlightConstants().init();
        }
        makeConstants_() {
          return new xp();
        }
        makeRenderInfo_(t) {
          return new Up(this, t);
        }
        makeDrawer_(t, e) {
          return new Mp(t, e);
        }
        makePathObject(t, e) {
          return new Wp(t, e, this.getConstants());
        }
        makeHighlightConstants_() {
          return new Pp(this.getConstants());
        }
        getHighlightConstants() {
          if (!this.highlightConstants) throw Error("Cannot access the highlight constants because init has not been called");
          return this.highlightConstants;
        }
      };
      xs("geras", yu);
      var Gp = class extends sn {
        constructor(t, e) {
          super(t, e);
        }
        getRenderer() {
          return this.renderer_;
        }
        addElemSpacing_() {
          for (var t = !1, e = 0; e < this.rows.length; e++) if (this.rows[e].hasExternalInput) {
            t = !0;
            break;
          }
          for (e = 0; e < this.rows.length; e++) {
            let o = this.rows[e];
            var i = o.elements;
            if (o.elements = [], o.startsWithElemSpacer() && o.elements.push(new he(this.constants_, this.getInRowSpacing_(null, i[0]))), i.length) {
              for (let s = 0; s < i.length - 1; s++) {
                o.elements.push(i[s]);
                let n = this.getInRowSpacing_(i[s], i[s + 1]);
                o.elements.push(new he(
                  this.constants_,
                  n
                ));
              }
              o.elements.push(i[i.length - 1]), o.endsWithElemSpacer() && (i = this.getInRowSpacing_(i[i.length - 1], null), t && o.hasDummyInput && (i += this.constants_.TAB_WIDTH), o.elements.push(new he(this.constants_, i)));
            }
          }
        }
        getInRowSpacing_(t, e) {
          if (!t) return e && u.isField(e) && e.isEditable ? this.constants_.MEDIUM_PADDING : e && u.isInlineInput(e) ? this.constants_.MEDIUM_LARGE_PADDING : e && u.isStatementInput(e) ? this.constants_.STATEMENT_INPUT_PADDING_LEFT : this.constants_.LARGE_PADDING;
          if (!u.isInput(t) && !e) return u.isField(t) && t.isEditable ? t.width === 0 ? this.constants_.NO_PADDING : this.constants_.MEDIUM_PADDING : u.isIcon(t) ? this.constants_.LARGE_PADDING * 2 + 1 : u.isHat(t) ? this.constants_.NO_PADDING : u.isPreviousOrNextConnection(t) ? this.constants_.LARGE_PADDING : u.isLeftRoundedCorner(t) ? this.constants_.MIN_BLOCK_WIDTH : u.isJaggedEdge(t) ? this.constants_.NO_PADDING : this.constants_.LARGE_PADDING;
          if (u.isInput(t) && !e) {
            if (u.isExternalInput(t)) return this.constants_.NO_PADDING;
            if (u.isInlineInput(t)) return this.constants_.LARGE_PADDING;
            if (u.isStatementInput(t)) return this.constants_.NO_PADDING;
          }
          if (!u.isInput(t) && e && u.isInput(e)) {
            if (u.isField(t) && t.isEditable) {
              if (u.isInlineInput(e) || u.isExternalInput(e)) return this.constants_.SMALL_PADDING;
            } else {
              if (u.isInlineInput(e) || u.isExternalInput(e)) return this.constants_.MEDIUM_LARGE_PADDING;
              if (u.isStatementInput(e)) return this.constants_.LARGE_PADDING;
            }
            return this.constants_.LARGE_PADDING - 1;
          }
          if (u.isIcon(t) && e && !u.isInput(e)) return this.constants_.LARGE_PADDING;
          if (u.isInlineInput(t) && e && u.isField(e)) return e.isEditable ? this.constants_.MEDIUM_PADDING : this.constants_.LARGE_PADDING;
          if (u.isLeftSquareCorner(t) && e) {
            if (u.isHat(e)) return this.constants_.NO_PADDING;
            if (u.isPreviousConnection(e) || u.isNextConnection(e)) return e.notchOffset;
          }
          return u.isLeftRoundedCorner(t) && e ? e.notchOffset - this.constants_.CORNER_RADIUS : u.isField(t) && e && u.isField(e) && t.isEditable === e.isEditable ? t.width === 0 ? this.constants_.NO_PADDING : this.constants_.LARGE_PADDING : e && u.isJaggedEdge(e) ? this.constants_.LARGE_PADDING : this.constants_.MEDIUM_PADDING;
        }
        getSpacerRowHeight_(t, e) {
          return u.isTopRow(t) && u.isBottomRow(e) ? this.constants_.EMPTY_BLOCK_SPACER_HEIGHT : u.isTopRow(t) || u.isBottomRow(e) ? this.constants_.NO_PADDING : t.hasExternalInput && e.hasExternalInput ? this.constants_.LARGE_PADDING : !t.hasStatement && e.hasStatement ? this.constants_.BETWEEN_STATEMENT_PADDING_Y : t.hasStatement && e.hasStatement || t.hasDummyInput || e.hasDummyInput ? this.constants_.LARGE_PADDING : this.constants_.MEDIUM_PADDING;
        }
        getElemCenterline_(t, e) {
          if (u.isSpacer(e)) return t.yPos + e.height / 2;
          if (u.isBottomRow(t)) return t = t.yPos + t.height - t.descenderHeight, u.isNextConnection(e) ? t + e.height / 2 : t - e.height / 2;
          if (u.isTopRow(t)) return u.isHat(e) ? t.capline - e.height / 2 : t.capline + e.height / 2;
          var i = t.yPos;
          return i = u.isField(e) && t.hasStatement ? i + (this.constants_.TALL_INPUT_FIELD_OFFSET_Y + e.height / 2) : i + t.height / 2;
        }
        finalize_() {
          for (var t = 0, e = 0, i = 0; i < this.rows.length; i++) {
            let s = this.rows[i];
            s.yPos = e, s.xPos = this.startX, e += s.height, t = Math.max(t, s.widthWithConnectedBlocks);
            var o = e - this.topRow.ascenderHeight;
            s === this.bottomRow && o < this.constants_.MIN_BLOCK_HEIGHT && (o = this.constants_.MIN_BLOCK_HEIGHT - o, this.bottomRow.height += o, e += o), this.recordElemPositions_(s);
          }
          this.outputConnection && this.block_.nextConnection && this.block_.nextConnection.isConnected() && (i = this.block_.nextConnection.targetBlock()) && (t = Math.max(t, i.getHeightWidth().width)), this.bottomRow.baseline = e - this.bottomRow.descenderHeight, this.widthWithChildren = t + this.startX, this.height = e, this.startY = this.topRow.capline;
        }
      }, bu = class extends nl {
        constructor(t) {
          super(t);
        }
        makeRenderInfo_(t) {
          return new Gp(this, t);
        }
      };
      xs("thrasos", bu);
      var Vp = class extends il {
        constructor(t) {
          super(), this.GRID_UNIT = 4, this.CURSOR_COLOUR = "#ffa200", this.CURSOR_RADIUS = 5, this.JAGGED_TEETH_WIDTH = this.JAGGED_TEETH_HEIGHT = 0, this.START_HAT_HEIGHT = 22, this.START_HAT_WIDTH = 96, this.SHAPES = { HEXAGONAL: 1, ROUND: 2, SQUARE: 3, PUZZLE: 4, NOTCH: 5 }, this.SHAPE_IN_SHAPE_PADDING = { 1: { 0: 5 * this.GRID_UNIT, 1: 2 * this.GRID_UNIT, 2: 5 * this.GRID_UNIT, 3: 5 * this.GRID_UNIT }, 2: { 0: 3 * this.GRID_UNIT, 1: 3 * this.GRID_UNIT, 2: 1 * this.GRID_UNIT, 3: 2 * this.GRID_UNIT }, 3: {
            0: 2 * this.GRID_UNIT,
            1: 2 * this.GRID_UNIT,
            2: 2 * this.GRID_UNIT,
            3: 2 * this.GRID_UNIT
          } }, this.FULL_BLOCK_FIELDS = !0, this.FIELD_TEXT_FONTWEIGHT = "bold", this.FIELD_TEXT_FONTFAMILY = '"Helvetica Neue", "Segoe UI", Helvetica, sans-serif', this.FIELD_COLOUR_FULL_BLOCK = this.FIELD_TEXTINPUT_BOX_SHADOW = this.FIELD_DROPDOWN_SVG_ARROW = this.FIELD_DROPDOWN_COLOURED_DIV = this.FIELD_DROPDOWN_NO_BORDER_RECT_SHADOW = !0, this.SELECTED_GLOW_COLOUR = "#fff200", this.SELECTED_GLOW_SIZE = 0.5, this.selectedGlowFilterId = "", this.SQUARED = this.ROUNDED = this.HEXAGONAL = this.selectedGlowFilter = null, t && (this.GRID_UNIT = t), this.SMALL_PADDING = this.GRID_UNIT, this.MEDIUM_PADDING = 2 * this.GRID_UNIT, this.MEDIUM_LARGE_PADDING = 3 * this.GRID_UNIT, this.LARGE_PADDING = 4 * this.GRID_UNIT, this.CORNER_RADIUS = 1 * this.GRID_UNIT, this.NOTCH_WIDTH = 9 * this.GRID_UNIT, this.NOTCH_HEIGHT = 2 * this.GRID_UNIT, this.STATEMENT_INPUT_NOTCH_OFFSET = this.NOTCH_OFFSET_LEFT = 3 * this.GRID_UNIT, this.MIN_BLOCK_WIDTH = 2 * this.GRID_UNIT, this.MIN_BLOCK_HEIGHT = 12 * this.GRID_UNIT, this.EMPTY_STATEMENT_INPUT_HEIGHT = 6 * this.GRID_UNIT, this.TOP_ROW_MIN_HEIGHT = this.CORNER_RADIUS, this.TOP_ROW_PRECEDES_STATEMENT_MIN_HEIGHT = this.LARGE_PADDING, this.BOTTOM_ROW_MIN_HEIGHT = this.CORNER_RADIUS, this.BOTTOM_ROW_AFTER_STATEMENT_MIN_HEIGHT = 6 * this.GRID_UNIT, this.STATEMENT_BOTTOM_SPACER = -this.NOTCH_HEIGHT, this.STATEMENT_INPUT_SPACER_MIN_WIDTH = 40 * this.GRID_UNIT, this.STATEMENT_INPUT_PADDING_LEFT = 4 * this.GRID_UNIT, this.EMPTY_INLINE_INPUT_PADDING = 4 * this.GRID_UNIT, this.EMPTY_INLINE_INPUT_HEIGHT = 8 * this.GRID_UNIT, this.DUMMY_INPUT_MIN_HEIGHT = 8 * this.GRID_UNIT, this.DUMMY_INPUT_SHADOW_MIN_HEIGHT = 6 * this.GRID_UNIT, this.CURSOR_WS_WIDTH = 20 * this.GRID_UNIT, this.FIELD_TEXT_FONTSIZE = 3 * this.GRID_UNIT, this.FIELD_BORDER_RECT_RADIUS = this.CORNER_RADIUS, this.FIELD_BORDER_RECT_X_PADDING = 2 * this.GRID_UNIT, this.FIELD_BORDER_RECT_Y_PADDING = 1.625 * this.GRID_UNIT, this.FIELD_BORDER_RECT_HEIGHT = 8 * this.GRID_UNIT, this.FIELD_DROPDOWN_BORDER_RECT_HEIGHT = 8 * this.GRID_UNIT, this.FIELD_DROPDOWN_SVG_ARROW_PADDING = this.FIELD_BORDER_RECT_X_PADDING, this.FIELD_COLOUR_DEFAULT_WIDTH = 6 * this.GRID_UNIT, this.FIELD_COLOUR_DEFAULT_HEIGHT = 8 * this.GRID_UNIT, this.FIELD_CHECKBOX_X_OFFSET = 1 * this.GRID_UNIT, this.MAX_DYNAMIC_CONNECTION_SHAPE_WIDTH = 12 * this.GRID_UNIT;
        }
        setFontConstants_(t) {
          super.setFontConstants_(t), this.FIELD_DROPDOWN_BORDER_RECT_HEIGHT = this.FIELD_BORDER_RECT_HEIGHT = this.FIELD_TEXT_HEIGHT + this.FIELD_BORDER_RECT_Y_PADDING * 2;
        }
        init() {
          super.init(), this.HEXAGONAL = this.makeHexagonal(), this.ROUNDED = this.makeRounded(), this.SQUARED = this.makeSquared(), this.STATEMENT_INPUT_NOTCH_OFFSET = this.NOTCH_OFFSET_LEFT + this.INSIDE_CORNERS.rightWidth;
        }
        setDynamicProperties_(t) {
          super.setDynamicProperties_(t), this.SELECTED_GLOW_COLOUR = t.getComponentStyle("selectedGlowColour") || this.SELECTED_GLOW_COLOUR, this.SELECTED_GLOW_SIZE = (t = Number(t.getComponentStyle("selectedGlowSize"))) && !isNaN(t) ? t : this.SELECTED_GLOW_SIZE;
        }
        dispose() {
          super.dispose(), this.selectedGlowFilter && Q(this.selectedGlowFilter);
        }
        makeStartHat() {
          var t = this.START_HAT_HEIGHT, e = this.START_HAT_WIDTH, i = $t("c", [R(25, -t), R(71, -t), R(e, 0)]);
          return { height: t * 0.75, width: e, path: i };
        }
        makeHexagonal() {
          function t(i, o, s) {
            var n = i / 2;
            return n = n > e ? e : n, s = s ? -1 : 1, i = (o ? -1 : 1) * i / 2, Be(-s * n, i) + Be(s * n, i);
          }
          var e = this.MAX_DYNAMIC_CONNECTION_SHAPE_WIDTH;
          return { type: this.SHAPES.HEXAGONAL, isDynamic: !0, width(i) {
            return i /= 2, i > e ? e : i;
          }, height(i) {
            return i;
          }, connectionOffsetY(i) {
            return i / 2;
          }, connectionOffsetX(i) {
            return -i;
          }, pathDown(i) {
            return t(i, !1, !1);
          }, pathUp(i) {
            return t(i, !0, !1);
          }, pathRightDown(i) {
            return t(i, !1, !0);
          }, pathRightUp(i) {
            return t(i, !1, !0);
          } };
        }
        makeRounded() {
          function t(o, s, n) {
            var l = o > i ? o - i : 0;
            o = (o > i ? i : o) / 2;
            var a = n === s ? "0" : "1";
            return dt("a", "0 0," + a, o, R((n ? 1 : -1) * o, (s ? -1 : 1) * o)) + A("v", (s ? -1 : 1) * l) + dt("a", "0 0," + a, o, R((n ? -1 : 1) * o, (s ? -1 : 1) * o));
          }
          var e = this.MAX_DYNAMIC_CONNECTION_SHAPE_WIDTH, i = e * 2;
          return { type: this.SHAPES.ROUND, isDynamic: !0, width(o) {
            return o /= 2, o > e ? e : o;
          }, height(o) {
            return o;
          }, connectionOffsetY(o) {
            return o / 2;
          }, connectionOffsetX(o) {
            return -o;
          }, pathDown(o) {
            return t(o, !1, !1);
          }, pathUp(o) {
            return t(o, !0, !1);
          }, pathRightDown(o) {
            return t(o, !1, !0);
          }, pathRightUp(o) {
            return t(o, !1, !0);
          } };
        }
        makeSquared() {
          function t(i, o, s) {
            i -= e * 2;
            var n = s === o ? "0" : "1";
            return dt("a", "0 0," + n, e, R((s ? 1 : -1) * e, (o ? -1 : 1) * e)) + A("v", (o ? -1 : 1) * i) + dt("a", "0 0," + n, e, R((s ? -1 : 1) * e, (o ? -1 : 1) * e));
          }
          var e = this.CORNER_RADIUS;
          return { type: this.SHAPES.SQUARE, isDynamic: !0, width() {
            return e;
          }, height(i) {
            return i;
          }, connectionOffsetY(i) {
            return i / 2;
          }, connectionOffsetX(i) {
            return -i;
          }, pathDown(i) {
            return t(i, !1, !1);
          }, pathUp(i) {
            return t(i, !0, !1);
          }, pathRightDown(i) {
            return t(i, !1, !0);
          }, pathRightUp(i) {
            return t(i, !1, !0);
          } };
        }
        shapeFor(t) {
          var e = t.getCheck();
          switch (!e && t.targetConnection && (e = t.targetConnection.getCheck()), t.type) {
            case T.INPUT_VALUE:
            case T.OUTPUT_VALUE:
              if (t = t.getSourceBlock().getOutputShape(), t !== null) switch (t) {
                case this.SHAPES.HEXAGONAL:
                  return this.HEXAGONAL;
                case this.SHAPES.ROUND:
                  return this.ROUNDED;
                case this.SHAPES.SQUARE:
                  return this.SQUARED;
              }
              return e && e.includes("Boolean") ? this.HEXAGONAL : e && e.includes("Number") ? this.ROUNDED : (e && e.includes("String"), this.ROUNDED);
            case T.PREVIOUS_STATEMENT:
            case T.NEXT_STATEMENT:
              return this.NOTCH;
            default:
              throw Error("Unknown type");
          }
        }
        makeNotch() {
          function t(E) {
            return $t("c", [R(E * s / 2, 0), R(
              E * s * 3 / 4,
              l / 2
            ), R(E * s, l)]) + Bo([R(E * s, n)]) + $t("c", [R(E * s / 4, l / 2), R(E * s / 2, l), R(E * s, l)]) + A("h", E * o) + $t("c", [R(E * s / 2, 0), R(E * s * 3 / 4, -(l / 2)), R(E * s, -l)]) + Bo([R(E * s, -n)]) + $t("c", [R(E * s / 4, -(l / 2)), R(E * s / 2, -l), R(E * s, -l)]);
          }
          var e = this.NOTCH_WIDTH, i = this.NOTCH_HEIGHT, o = e / 3, s = o / 3, n = i / 2, l = n / 2, a = t(1), c = t(-1);
          return { type: this.SHAPES.NOTCH, width: e, height: i, pathLeft: a, pathRight: c };
        }
        makeInsideCorners() {
          var t = this.CORNER_RADIUS, e = dt("a", "0 0,0", t, R(-t, t)), i = dt("a", "0 0,1", t, R(-t, t)), o = dt("a", "0 0,0", t, R(t, t)), s = dt("a", "0 0,1", t, R(
            t,
            t
          ));
          return { width: t, height: t, pathTop: e, pathBottom: o, rightWidth: t, rightHeight: t, pathTopRight: i, pathBottomRight: s };
        }
        generateSecondaryColour_(t) {
          return Wi("#000", t, 0.15) || t;
        }
        generateTertiaryColour_(t) {
          return Wi("#000", t, 0.25) || t;
        }
        createDom(t, e, i) {
          super.createDom(t, e, i), t = v(g.DEFS, {}, t), t = v(g.FILTER, { id: "blocklySelectedGlowFilter" + this.randomIdentifier, height: "160%", width: "180%", y: "-30%", x: "-40%" }, t), v(g.FEGAUSSIANBLUR, { in: "SourceGraphic", stdDeviation: this.SELECTED_GLOW_SIZE }, t), e = v(
            g.FECOMPONENTTRANSFER,
            { result: "outBlur" },
            t
          ), v(g.FEFUNCA, { type: "table", tableValues: "0 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1" }, e), v(g.FEFLOOD, { "flood-color": this.SELECTED_GLOW_COLOUR, "flood-opacity": 1, result: "outColor" }, t), v(g.FECOMPOSITE, { in: "outColor", in2: "outBlur", operator: "in", result: "outGlow" }, t), this.selectedGlowFilterId = t.id, this.selectedGlowFilter = t, i && i.style.setProperty("--blocklySelectedGlowFilter", `url(#${this.selectedGlowFilterId})`);
        }
        getCSS_(t) {
          return [
            `${t} .blocklyText,`,
            `${t} .blocklyFlyoutLabelText {`,
            `font: ${this.FIELD_TEXT_FONTWEIGHT} ${this.FIELD_TEXT_FONTSIZE}pt ${this.FIELD_TEXT_FONTFAMILY};`,
            "}",
            `${t} .blocklyTextInputBubble textarea {`,
            "font-weight: normal;",
            "}",
            `${t} .blocklyText {`,
            "fill: #fff;",
            "}",
            `${t} .blocklyNonEditableField>rect:not(.blocklyDropdownRect),`,
            `${t} .blocklyEditableField>rect:not(.blocklyDropdownRect) {`,
            `fill: ${this.FIELD_BORDER_RECT_COLOUR};`,
            "}",
            `${t} .blocklyNonEditableField>text,`,
            `${t} .blocklyEditableField>text,`,
            `${t} .blocklyNonEditableField>g>text,`,
            `${t} .blocklyEditableField>g>text {`,
            "fill: #575E75;",
            "}",
            `${t} .blocklyFlyoutLabelText {`,
            "fill: #575E75;",
            "}",
            `${t} .blocklyText.blocklyBubbleText {`,
            "fill: #575E75;",
            "}",
            `${t} .blocklyDraggable:not(.blocklyDisabled)`,
            " .blocklyEditableField:not(.blocklyEditing):hover>rect,",
            `${t} .blocklyDraggable:not(.blocklyDisabled)`,
            " .blocklyEditableField:not(.blocklyEditing):hover>.blocklyPath {",
            "stroke: #fff;",
            "stroke-width: 2;",
            "}",
            `${t} .blocklyHtmlInput {`,
            `font-family: ${this.FIELD_TEXT_FONTFAMILY};`,
            `font-weight: ${this.FIELD_TEXT_FONTWEIGHT};`,
            "color: #575E75;",
            "}",
            `${t} .blocklyDropdownText {`,
            "fill: #fff !important;",
            "}",
            `${t}.blocklyWidgetDiv .blocklyMenuItem,`,
            `${t}.blocklyDropDownDiv .blocklyMenuItem {`,
            `font-family: ${this.FIELD_TEXT_FONTFAMILY};`,
            "}",
            `${t}.blocklyDropDownDiv .blocklyMenuItemContent {`,
            "color: #fff;",
            "}",
            `${t} .blocklyHighlightedConnectionPathVisible {`,
            `stroke: ${this.SELECTED_GLOW_COLOUR};`,
            "}",
            `${t} .blocklyDisabledPattern > .blocklyOutlinePath {`,
            "fill: var(--blocklyDisabledPattern)",
            "}",
            `${t} .blocklyInsertionMarker>.blocklyPath {`,
            `fill-opacity: ${this.INSERTION_MARKER_OPACITY};`,
            "stroke: none;",
            "}",
            `${t} .blocklySelected>.blocklyPath.blocklyPathSelected {`,
            "fill: none;",
            "filter: var(--blocklySelectedGlowFilter);",
            "}"
          ];
        }
      }, zp = class extends ol {
        constructor(t, e) {
          super(t, e);
        }
        draw() {
          var t = this.block_.pathObject;
          t.beginDrawing(), this.drawOutline_(), this.drawInternals_(), this.updateConnectionHighlights(), t.setPath(this.outlinePath_ + `
` + this.inlinePath_), this.info_.RTL && t.flipRTL(), this.recordSizeOnBlock_(), this.info_.outputConnection && (t.outputShapeType = this.info_.outputConnection.shape.type), t.endDrawing();
        }
        drawOutline_() {
          this.info_.outputConnection && this.info_.outputConnection.isDynamicShape && !this.info_.hasStatementInput && !this.info_.bottomRow.hasNextConnection ? (this.drawFlatTop_(), this.drawRightDynamicConnection_(), this.drawFlatBottom_(), this.drawLeftDynamicConnection_()) : super.drawOutline_();
        }
        drawLeft_() {
          this.info_.outputConnection && this.info_.outputConnection.isDynamicShape ? this.drawLeftDynamicConnection_() : super.drawLeft_();
        }
        drawRightSideRow_(t) {
          if (!(t.height <= 0)) {
            if (u.isSpacer(t)) {
              let o = t.precedesStatement;
              var e = t.followsStatement;
              if (o || e) {
                let s = this.constants_.INSIDE_CORNERS;
                var i = s.rightHeight;
                i = t.height - (o ? i : 0), e = e ? s.pathBottomRight : "", t = i > 0 ? A("V", t.yPos + i) : "", this.outlinePath_ += e + t + (o ? s.pathTopRight : "");
                return;
              }
            }
            this.outlinePath_ += A("V", t.yPos + t.height);
          }
        }
        drawRightDynamicConnection_() {
          if (!this.info_.outputConnection) throw Error("Cannot draw the output connection of a block that doesn't have one");
          this.outlinePath_ += this.info_.outputConnection.shape.pathRightDown(this.info_.outputConnection.height);
        }
        drawLeftDynamicConnection_() {
          if (!this.info_.outputConnection) throw Error("Cannot draw the output connection of a block that doesn't have one");
          this.positionOutputConnection_(), this.outlinePath_ += this.info_.outputConnection.shape.pathUp(this.info_.outputConnection.height), this.outlinePath_ += "z";
        }
        drawFlatTop_() {
          var t = this.info_.topRow;
          this.positionPreviousConnection_(), this.outlinePath_ += ct(t.xPos, this.info_.startY), this.outlinePath_ += A("h", t.width);
        }
        drawFlatBottom_() {
          var t = this.info_.bottomRow;
          this.positionNextConnection_(), this.outlinePath_ += A("V", t.baseline), this.outlinePath_ += A("h", -t.width);
        }
        drawInlineInput_(t) {
          this.positionInlineInputConnection_(t);
          var e = t.input.name;
          t.connectedBlock || this.info_.isInsertionMarker || (t = St(t.xPos + t.connectionWidth, t.centerline - t.height / 2) + this.getInlineInputPath(t), this.block_.pathObject.setOutlinePath(e, t));
        }
        getInlineInputPath(t) {
          var e = t.width - t.connectionWidth * 2, i = t.height;
          return A("h", e) + t.shape.pathRightDown(i) + A("h", -e) + t.shape.pathUp(i) + "z";
        }
        drawStatementInput_(t) {
          var e = t.getLastInput(), i = e.xPos + e.notchOffset + e.shape.width, o = this.constants_.INSIDE_CORNERS, s = e.shape.pathRight + A("h", -(e.notchOffset - o.width)) + o.pathTop, n = t.height - 2 * o.height;
          e = o.pathBottom + A("h", e.notchOffset - o.width) + (e.connectedBottomNextConnection ? "" : e.shape.pathLeft), this.outlinePath_ += A("H", i) + s + A("v", n) + e + A("H", t.xPos + t.width), this.positionStatementInputConnection_(t);
        }
        drawConnectionHighlightPath(t) {
          var e = t.connectionModel;
          if (e.type === T.NEXT_STATEMENT || e.type === T.PREVIOUS_STATEMENT || e.type === T.OUTPUT_VALUE && !t.isDynamicShape) return super.drawConnectionHighlightPath(t);
          t = e.type === T.INPUT_VALUE ? St(t.connectionWidth, -t.height / 2) + this.getInlineInputPath(t) : St(t.width, -t.height / 2) + t.shape.pathDown(t.height);
          var i = e.getSourceBlock(), o, s;
          return (s = (o = i.pathObject).addConnectionHighlight) == null ? void 0 : s.call(o, e, t, e.getOffsetInBlock(), i.RTL);
        }
      }, Eo = class extends Z {
        constructor(t, e, i, o, s, n, l) {
          if (super(Z.SKIP_SETUP), this.imageElement = this.clickHandler = null, this.flipRtl = this.isDirty_ = this.EDITABLE = !1, this.altText = "", i = Number(et(i)), e = Number(et(e)), isNaN(i) || isNaN(e)) throw Error("Height and width values of an image field must cast to numbers.");
          if (i <= 0 || e <= 0) throw Error("Height and width values of an image field must be greater than 0.");
          this.size_ = new H(e, i + Eo.Y_PADDING), this.imageHeight = i, typeof s == "function" && (this.clickHandler = s), t !== Z.SKIP_SETUP && (l ? this.configure_(l) : typeof o == "object" && o !== null && !Array.isArray(o) && ("alt" in o || "flipRtl" in o) ? this.configure_(o) : (this.flipRtl = !!n, this.altText = typeof o == "string" && et(o) || ""), this.setValue(et(t)));
        }
        configure_(t) {
          super.configure_(t), t.flipRtl && (this.flipRtl = t.flipRtl), t.alt && (this.altText = et(t.alt));
        }
        initView() {
          this.imageElement = v(g.IMAGE, { height: this.imageHeight + "px", width: this.size_.width + "px", alt: this.altText }, this.fieldGroup_), this.imageElement.setAttributeNS(
            "http://www.w3.org/1999/xlink",
            "xlink:href",
            this.value_
          ), this.fieldGroup_ && b(this.fieldGroup_, "blocklyImageField"), this.clickHandler && (this.imageElement.style.cursor = "pointer"), this.recomputeAriaContext();
        }
        updateSize_() {
        }
        doClassValidation_(t) {
          return typeof t != "string" ? null : t;
        }
        doValueUpdate_(t) {
          this.value_ = t, this.imageElement && this.imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", this.value_), this.recomputeAriaContext();
        }
        getFlipRtl() {
          return this.flipRtl;
        }
        setAlt(t) {
          t !== this.altText && (this.altText = t || "", this.imageElement && this.imageElement.setAttribute("alt", this.altText));
        }
        isClickable() {
          return super.isClickable() && !!this.clickHandler;
        }
        showEditor_() {
          this.clickHandler && this.clickHandler(this);
        }
        setOnClickHandler(t) {
          this.clickHandler = t;
        }
        getText_() {
          return this.altText;
        }
        static fromJson(t) {
          if (!t.src || !t.width || !t.height) throw Error("src, width, and height values for an image field arerequired. The width and height must be non-zero.");
          return new this(t.src, t.width, t.height, void 0, void 0, void 0, t);
        }
        getAriaTypeName() {
          return this.ariaTypeName || r.C.ARIA_TYPE_FIELD_IMAGE;
        }
        getAriaValue() {
          return this.altText || null;
        }
        computeAriaLabel(t) {
          var e = this.getAriaValue();
          return this.isClickable() || !e ? "" : (t = t ? this.getAriaTypeName() : null) ? `${t}: ${e}` : e;
        }
        recomputeAriaContext() {
          if (!super.recomputeAriaContext()) return !1;
          var t = this.getFocusableElement();
          if (!this.isClickable()) return G(t, W.NONE), Co(t, y.LABEL), !1;
          var e = this.getAriaValue() || "";
          return w(t, y.LABEL, e), !0;
        }
      };
      Eo.Y_PADDING = 1, xe("field_image", Eo), Eo.prototype.DEFAULT_VALUE = "";
      var vo = class extends Z {
        set size_(t) {
          super.size_ = t;
        }
        get size_() {
          var t = super.size_;
          return t.width < 14 && (t.width = 14), t;
        }
        constructor(t, e, i) {
          super(Z.SKIP_SETUP), this.spellcheck_ = !0, this.htmlInput_ = null, this.isTextValid_ = this.isBeingEdited_ = !1, this.onInputWrapper = this.onKeyDownWrapper = this.valueWhenEditorWasOpened_ = this.warningIcon = null, this.fullBlockClickTarget_ = !1, this.workspace_ = null, this.SERIALIZABLE = !0, t !== Z.SKIP_SETUP && (i && this.configure_(i), this.setValue(t), e && this.setValidator(e));
        }
        configure_(t) {
          super.configure_(t), t.spellcheck !== void 0 && (this.spellcheck_ = t.spellcheck);
        }
        initView() {
          if (!this.getSourceBlock()) throw new Et();
          this.isFullBlockField() || this.createBorderRect_(), this.createTextElement_(), this.fieldGroup_ && b(this.fieldGroup_, "blocklyField"), this.isFullBlockField() && (this.clickTarget_ = this.sourceBlock_.getSvgRoot()), this.fieldGroup_ && b(this.fieldGroup_, "blocklyInputField"), this.recomputeAriaContext();
        }
        isFullBlockField() {
          var t = this.getSourceBlock();
          if (!t) throw new Et();
          var e;
          return this.fullBlockClickTarget_ = !((e = this.getConstants()) == null || !e.FULL_BLOCK_FIELDS) && t.isSimpleReporter();
        }
        createWarningIcon() {
          if (!this.sourceBlock_) return null;
          var t = this.getScaledBBox();
          return t = t.bottom - t.top, t = v(g.SVG, { class: "blocklyInputWarning", viewBox: "-4 0 24 16", x: "0", y: "0", height: `${t}px`, width: `${t}px` }), v(g.PATH, { class: "blocklyInputWarningIconShape", d: "M2,15Q-1,15 0.5,12L6.5,1.7Q8,-1 9.5,1.7L15.5,12Q17,15 14,15z" }, t), v(g.PATH, { class: "blocklyInputWarningIconSymbol", d: "m7,4.8v3.16l0.27,2.27h1.46l0.27,-2.27v-3.16z" }, t), v(g.RECT, { class: "blocklyInputWarningIconSymbol", x: "7", y: "11", height: "2", width: "2" }, t), t;
        }
        doValueInvalid_(t, e = !0) {
          this.isBeingEdited_ && (this.isDirty_ = !0, this.isTextValid_ = !1, t = this.value_, this.value_ = this.valueWhenEditorWasOpened_, this.sourceBlock_ && ht() && this.value_ !== t && e && N(new (D(p.BLOCK_CHANGE))(this.sourceBlock_, "field", this.name || null, t, this.value_))), this.recomputeAriaContext();
        }
        doValueUpdate_(t) {
          this.isTextValid_ = this.isDirty_ = !0, this.value_ = t, this.recomputeAriaContext();
        }
        applyColour() {
          var t = this.getSourceBlock();
          if (!t) throw new Et();
          this.getConstants().FULL_BLOCK_FIELDS && this.fieldGroup_ && (!this.isFullBlockField() && this.borderRect_ ? (this.borderRect_.style.display = "block", this.borderRect_.setAttribute("stroke", t.getColourTertiary())) : t.pathObject.svgPath.setAttribute("fill", this.getConstants().FIELD_BORDER_RECT_COLOUR));
        }
        getSize() {
          var t;
          return (t = this.getConstants()) != null && t.FULL_BLOCK_FIELDS && (this.render_(), this.isDirty_ = !1), super.getSize();
        }
        onLocationChange() {
          this.isBeingEdited_ && this.resizeEditor_();
        }
        render_() {
          super.render_();
          var t = this.getSourceBlock();
          if (!t) throw new Et();
          if (this.isBeingEdited_) {
            let e = this.htmlInput_;
            this.renderWarningIcon(t.RTL, this.isTextValid_), this.isTextValid_ ? (Y(e, "blocklyInvalidInput"), w(e, y.INVALID, !1)) : (b(e, "blocklyInvalidInput"), w(e, y.INVALID, !0));
          }
          this.getConstants().FULL_BLOCK_FIELDS && t.applyColour();
        }
        renderWarningIcon(t, e) {
          var i = this.htmlInput_;
          if (this.warningIcon) if (e) i.style.paddingRight = "", i.style.paddingLeft = "", Y(this.warningIcon, "blocklyInputWarningInvalid");
          else {
            e = this.getScaledBBox();
            var o = e.bottom - e.top;
            o = (e = !!this.borderRect_) ? this.getConstants().FIELD_BORDER_RECT_X_PADDING : o / 2, b(this.warningIcon, "blocklyInputWarningInvalid");
            let s = this.warningIcon.getBoundingClientRect().width;
            i.setAttribute("width", `${i.offsetWidth + s}px`);
            let n = s / 1.5;
            t ? i.style.paddingRight = `${n}px` : i.style.paddingLeft = `${n}px`, this.size_.width = s, t = e ? this.getConstants().FIELD_TEXT_HEIGHT - this.getConstants().FIELD_BORDER_RECT_X_PADDING : 0, this.updateSize_(o + t);
          }
        }
        setSpellcheck(t) {
          t !== this.spellcheck_ && (this.spellcheck_ = t, this.htmlInput_ && this.htmlInput_.setAttribute("spellcheck", this.spellcheck_));
        }
        showEditor_(t, e = !1, i = !0) {
          this.workspace_ = this.sourceBlock_.workspace, !e && this.workspace_.options.modalInputs && (uc || wd || Ms) ? this.showPromptEditor() : this.showInlineEditor(e, i);
        }
        showPromptEditor() {
          On(r.C.CHANGE_VALUE_TITLE, this.getText(), (t) => {
            t !== null && this.setValue(this.getValueFromEditorText_(t)), this.onFinishEditing_(this.value_);
          });
        }
        showInlineEditor(t, e) {
          var i = this.getSourceBlock();
          if (!i) throw new Et();
          Jn(
            this,
            i.RTL,
            this.widgetDispose_.bind(this),
            this.workspace_,
            e
          ), this.htmlInput_ = this.widgetCreate_(), this.isBeingEdited_ = !0, this.valueWhenEditorWasOpened_ = this.value_, t || (this.htmlInput_.focus({ preventScroll: !0 }), this.htmlInput_.select());
        }
        widgetCreate_() {
          var t = this.getSourceBlock();
          if (!t) throw new Et();
          r.B(!0);
          var e = vt, i = this.getClickTarget_();
          if (!i) throw Error("A click target has not been set.");
          b(i, "blocklyEditing"), i = document.createElement("input"), i.className = "blocklyHtmlInput", i.setAttribute("spellcheck", this.spellcheck_), this.warningIcon = this.createWarningIcon();
          var o = this.workspace_.getAbsoluteScale(), s = this.getConstants().FIELD_TEXT_FONTSIZE * o + "pt";
          if (e.style.fontSize = s, i.style.fontSize = s, s = vo.BORDERRADIUS * o + "px", this.isFullBlockField()) {
            let n = this.getScaledBBox();
            s = (n.bottom - n.top) / 2 + "px", t = t.getParent() ? t.getParent().getColourTertiary() : this.sourceBlock_.getColourTertiary(), i.style.border = 1 * o + "px solid " + t, e.style.borderRadius = s, e.style.transition = "box-shadow 0.25s ease 0s", this.getConstants().FIELD_TEXTINPUT_BOX_SHADOW && (e.style.boxShadow = "rgba(255, 255, 255, 0.3) 0 0 0 " + 4 * o + "px"), t = (n.bottom - n.top) / 4, this.warningIcon.style.paddingLeft = `${t}px`, this.warningIcon.style.paddingRight = `${t}px`;
          }
          return i.style.borderRadius = s, this.warningIcon && e.appendChild(this.warningIcon), e.appendChild(i), i.value = i.defaultValue = this.getEditorText_(this.value_), i.setAttribute("data-untyped-default-value", String(this.value_)), this.resizeEditor_(), this.bindInputEvents_(i), i;
        }
        widgetDispose_() {
          this.isBeingEdited_ = !1, this.isTextValid_ = !0, this.forceRerender(), this.onFinishEditing_(this.value_), this.sourceBlock_ && ht() && this.valueWhenEditorWasOpened_ !== null && this.valueWhenEditorWasOpened_ !== this.value_ && (N(new (D(p.BLOCK_CHANGE))(this.sourceBlock_, "field", this.name || null, this.valueWhenEditorWasOpened_, this.value_)), this.valueWhenEditorWasOpened_ = null), r.B(!1), this.unbindInputEvents_();
          var t = vt.style;
          if (t.width = "auto", t.height = "auto", t.fontSize = "", t.transition = "", t.boxShadow = "", this.htmlInput_ = null, t = this.getClickTarget_(), !t) throw Error("A click target has not been set.");
          Y(t, "blocklyEditing"), this.recomputeAriaContext();
        }
        onFinishEditing_() {
        }
        bindInputEvents_(t) {
          this.onKeyDownWrapper = M(t, "keydown", this, this.onHtmlInputKeyDown_), this.onInputWrapper = M(t, "input", this, this.onHtmlInputChange);
        }
        unbindInputEvents_() {
          this.onKeyDownWrapper && ($(this.onKeyDownWrapper), this.onKeyDownWrapper = null), this.onInputWrapper && ($(this.onInputWrapper), this.onInputWrapper = null);
        }
        onHtmlInputKeyDown_(t) {
          if (t.key === "Enter") Vi(this), Oe(), t.stopPropagation();
          else if (t.key === "Escape") this.setValue(
            this.htmlInput_.getAttribute("data-untyped-default-value"),
            !1
          ), Vi(this), Oe();
          else if (t.key === "Tab") {
            t.preventDefault();
            var e;
            let i = (e = this.workspace_) == null ? void 0 : e.getNavigator(), o = (s) => (s instanceof vo || s instanceof ut && s.isSimpleReporter()) && s !== this.getSourceBlock();
            e = this;
            do
              e = t.shiftKey ? i?.getOutNode(e) : i?.getInNode(e);
            while (e && !o(e));
            e = e instanceof ut && e.isSimpleReporter() ? e.getFields().next().value : e, e instanceof vo && (Vi(this), Oe(), t = e.getSourceBlock(), e.isFullBlockField() && t && t instanceof ut ? r.t().focusNode(t) : r.t().focusNode(e), e.showEditor());
          }
        }
        onHtmlInputChange() {
          var t = this.value_;
          this.setValue(this.getValueFromEditorText_(this.htmlInput_.value), !1), this.sourceBlock_ && ht() && this.value_ !== t && N(new (D(p.BLOCK_FIELD_INTERMEDIATE_CHANGE))(this.sourceBlock_, this.name || null, t, this.value_));
        }
        setEditorValue_(t, e = !0) {
          this.isDirty_ = !0, this.isBeingEdited_ && (this.htmlInput_.value = this.getEditorText_(t)), this.setValue(t, e);
        }
        resizeEditor_() {
          te().then(() => {
            var t = this.getSourceBlock();
            if (!t) throw new Et();
            var e = vt;
            if (e) {
              var i = this.getScaledBBox();
              e.style.width = i.right - i.left + "px", e.style.height = i.bottom - i.top + "px", t = t.RTL ? i.right - e.offsetWidth : i.left, i = i.top;
              var o = e?.parentElement;
              o && ({ x: t, y: i } = ko(t, i, o)), e.style.left = `${t}px`, e.style.top = `${i}px`;
            }
          });
        }
        repositionForWindowResize() {
          var t = this.getSourceBlock(), e = this.workspace_;
          if (!(t instanceof ut)) return !1;
          if (this.resizeEditor_(), t = this.getClickTarget_(), !t || !e) return !0;
          t = F.from(t.getBoundingClientRect());
          var i = gi(e, t.getOrigin()), o = e.scale;
          return e.scrollBoundsIntoView(F.createFromPoint(
            i,
            t.getWidth() / o,
            t.getHeight() / o
          )), !0;
        }
        positionTextElement_(t, e) {
          var i = t * 2 + e;
          super.positionTextElement_(t + (i < 14 ? (14 - i) / 2 : 0), e);
        }
        getText_() {
          return this.isBeingEdited_ && this.htmlInput_ ? this.htmlInput_.value : null;
        }
        getEditorText_(t) {
          return `${t}`;
        }
        getValueFromEditorText_(t) {
          return t;
        }
        getAriaTypeName() {
          return this.ariaTypeName || r.C.ARIA_TYPE_FIELD_INPUT;
        }
        getAriaValue() {
          return this.getText() || r.C.FIELD_LABEL_EMPTY;
        }
        recomputeAriaContext() {
          if (!super.recomputeAriaContext()) return !1;
          var t = this.getFocusableElement(), e = this.computeAriaLabel(!0), i, o = this.isCurrentlyEditable() && !((i = this.getSourceBlock()) != null && i.isInFlyout);
          if (this.isFullBlockField()) {
            if (i = Je(this.getSourceBlock(), ot.STANDARD, e), o) {
              e = i.split(", "), o = $l(this.getSourceBlock()), o = o === void 0 ? -1 : e.indexOf(o), o = o === -1 ? 0 : o + 1;
              let s;
              e[o] = r.C.FIELD_LABEL_EDIT_PREFIX.replace("%1", (s = e[o]) != null ? s : ""), e = e.join(", ");
            }
          } else o && (e = r.C.FIELD_LABEL_EDIT_PREFIX.replace("%1", e));
          return w(t, y.LABEL, e), !0;
        }
      };
      vo.BORDERRADIUS = 4, ce(`
  .blocklyInputWarningIconShape {
    stroke: #1f1f1f;
    stroke-width: 1px;
    fill: none;
  }
  .blocklyInputWarningIconSymbol {
    fill: #1f1f1f;
  }
  .blocklyInputWarning {
    display: none;
    position: absolute;
  }
  .blocklyInputWarning.blocklyInputWarningInvalid {
    display: inline;
  }
`);
      var Kp = class extends pu {
        constructor(t) {
          super(t);
        }
        endsWithElemSpacer() {
          return !1;
        }
        hasLeftSquareCorner(t) {
          return !!t.outputConnection;
        }
        hasRightSquareCorner(t) {
          return !!t.outputConnection && !t.statementInputCount && !t.nextConnection;
        }
      }, ll = class extends el {
        constructor(t, e) {
          if (super(t, e), this.connectedBottomNextConnection = !1, this.connectedBlock) {
            for (t = this.connectedBlock; e = t.getNextBlock(); ) t = e;
            t.nextConnection || (this.height = this.connectedBlockHeight, this.connectedBottomNextConnection = !0);
          }
        }
      }, Xp = class extends Ke {
        constructor(t) {
          super(t), this.width = this.height = 0, this.type |= u.getType("RIGHT_CONNECTION");
        }
      }, Yp = class extends Tu {
        constructor(t) {
          super(t);
        }
        endsWithElemSpacer() {
          return !1;
        }
        hasLeftSquareCorner(t) {
          var e = (t.hat ? t.hat === "cap" : this.constants_.ADD_START_HATS) && !t.outputConnection && !t.previousConnection;
          return !!t.outputConnection || e;
        }
        hasRightSquareCorner(t) {
          return !!t.outputConnection && !t.statementInputCount && !t.nextConnection;
        }
      }, jp = class extends sn {
        constructor(t, e) {
          super(t, e), this.isInline = !0, this.renderer_ = t, this.constants_ = this.renderer_.getConstants(), this.topRow = new Yp(this.constants_), this.bottomRow = new Kp(this.constants_), this.isMultiRow = !e.getInputsInline() || e.isCollapsed(), this.hasStatementInput = e.statementInputCount > 0, this.rightSide = this.outputConnection ? new Xp(this.constants_) : null, this.rightAlignedDummyInputs = /* @__PURE__ */ new WeakMap();
        }
        getRenderer() {
          return this.renderer_;
        }
        measure() {
          this.createRows_(), this.addElemSpacing_(), this.addRowSpacing_(), this.adjustXPosition_(), this.computeBounds_(), this.alignRowElements_(), this.finalize_();
        }
        shouldStartNewRow_(t, e) {
          return e ? e instanceof ri || t instanceof re || e instanceof re ? !0 : t instanceof r.go || t instanceof Ge || t instanceof ri ? !this.isInline || this.isMultiRow : !1 : !1;
        }
        getDesiredRowWidth_(t) {
          return t.hasStatement ? this.width - this.startX - (this.constants_.INSIDE_CORNERS.rightWidth || 0) : super.getDesiredRowWidth_(t);
        }
        getInRowSpacing_(t, e) {
          return t && e || !this.outputConnection || !this.outputConnection.isDynamicShape || this.hasStatementInput || this.bottomRow.hasNextConnection ? !t && e && u.isStatementInput(e) ? this.constants_.STATEMENT_INPUT_PADDING_LEFT : t && u.isLeftRoundedCorner(t) && e && (u.isPreviousConnection(e) || u.isNextConnection(e)) ? e.notchOffset - this.constants_.CORNER_RADIUS : t && u.isLeftSquareCorner(t) && e && u.isHat(e) || t && u.isField(t) && t.width === 0 ? this.constants_.NO_PADDING : this.constants_.MEDIUM_PADDING : this.constants_.NO_PADDING;
        }
        getSpacerRowHeight_(t, e) {
          if (u.isTopRow(t) && u.isBottomRow(e)) return this.constants_.EMPTY_BLOCK_SPACER_HEIGHT;
          var i = u.isInputRow(t) && t.hasStatement, o = u.isInputRow(e) && e.hasStatement;
          return o || i ? (t = Math.max(this.constants_.NOTCH_HEIGHT, this.constants_.INSIDE_CORNERS.rightHeight || 0), o && i ? Math.max(t, this.constants_.DUMMY_INPUT_MIN_HEIGHT) : t) : u.isTopRow(t) ? t.hasPreviousConnection || this.outputConnection && !this.hasStatementInput ? this.constants_.NO_PADDING : Math.abs(this.constants_.NOTCH_HEIGHT - this.constants_.CORNER_RADIUS) : u.isBottomRow(e) ? this.outputConnection ? !e.hasNextConnection && this.hasStatementInput ? Math.abs(this.constants_.NOTCH_HEIGHT - this.constants_.CORNER_RADIUS) : this.constants_.NO_PADDING : Math.max(this.topRow.minHeight, Math.max(this.constants_.NOTCH_HEIGHT, this.constants_.CORNER_RADIUS)) - this.constants_.CORNER_RADIUS : this.constants_.MEDIUM_PADDING;
        }
        getSpacerRowWidth_(t, e) {
          var i = this.width - this.startX;
          return u.isInputRow(t) && t.hasStatement || u.isInputRow(e) && e.hasStatement ? Math.max(i, this.constants_.STATEMENT_INPUT_SPACER_MIN_WIDTH) : i;
        }
        getElemCenterline_(t, e) {
          if (t.hasStatement && !u.isSpacer(e) && !u.isStatementInput(e)) return t.yPos + this.constants_.EMPTY_STATEMENT_INPUT_HEIGHT / 2;
          if (u.isInlineInput(e)) {
            let i = e.connectedBlock;
            if (i && i.outputConnection && i.nextConnection) return t.yPos + i.height / 2;
          }
          return super.getElemCenterline_(t, e);
        }
        addInput_(t, e) {
          if ((t instanceof Ge || t instanceof ri) && e.hasDummyInput && e.align === r.Xn.LEFT && t.align === r.Xn.RIGHT) this.rightAlignedDummyInputs.set(e, t);
          else if (t instanceof re) {
            e.elements.push(new ll(this.constants_, t)), e.hasStatement = !0, e.align === null && (e.align = t.align);
            return;
          }
          super.addInput_(t, e);
        }
        addAlignmentPadding_(t, e) {
          if (this.rightAlignedDummyInputs.get(t)) {
            let i;
            for (let o = 0; o < t.elements.length; o++) {
              let s = t.elements[o];
              if (u.isSpacer(s) && (i = s), u.isField(s) && s.parentInput === this.rightAlignedDummyInputs.get(t)) break;
            }
            if (i) {
              i.width += e, t.width += e;
              return;
            }
          }
          super.addAlignmentPadding_(t, e);
        }
        adjustXPosition_() {
          var t = this.constants_.NOTCH_OFFSET_LEFT + this.constants_.NOTCH_WIDTH, e = t;
          for (let s = 2; s < this.rows.length - 1; s += 2) {
            var i = this.rows[s - 1];
            let n = this.rows[s];
            var o = this.rows[s + 1];
            if (i = s === 2 ? !!this.topRow.hasPreviousConnection : !!i.followsStatement, o = s + 2 >= this.rows.length - 1 ? !!this.bottomRow.hasNextConnection : !!o.precedesStatement, u.isInputRow(n) && n.hasStatement) {
              n.measure();
              let l, a;
              e = n.width - ((a = (l = n.getLastInput()) == null ? void 0 : l.width) != null ? a : 0) + t;
            } else if (i && (s === 2 || o) && u.isInputRow(n) && !n.hasStatement) {
              o = n.xPos, i = null;
              for (let l = 0; l < n.elements.length; l++) {
                let a = n.elements[l];
                u.isSpacer(a) && (i = a), !(i && (u.isField(a) || u.isInput(a)) && o < e) || u.isField(a) && (a.field instanceof go || a.field instanceof Eo) || (i.width += e - o), o += a.width;
              }
            }
          }
        }
        finalizeOutputConnection_() {
          if (this.outputConnection && this.outputConnection.isDynamicShape) {
            var t = this.outputConnection.shape;
            if ("isDynamic" in t && t.isDynamic) {
              for (var e = 0, i = 0; i < this.rows.length; i++) {
                let o = this.rows[i];
                o.yPos = e, e += o.height;
              }
              this.height = e, i = this.bottomRow.hasNextConnection ? this.height - this.bottomRow.descenderHeight : this.height, e = t.height(i), i = t.width(i), this.outputConnection.height = e, this.outputConnection.width = i, this.outputConnection.startX = i, this.outputConnection.connectionOffsetY = t.connectionOffsetY(e), this.outputConnection.connectionOffsetX = t.connectionOffsetX(i), t = 0, this.hasStatementInput || this.bottomRow.hasNextConnection || (t = i, this.rightSide.height = e, this.rightSide.width = t, this.rightSide.centerline = e / 2, this.rightSide.xPos = this.width + t), this.startX = i, this.width += i + t, this.widthWithChildren += i + t;
            }
          }
        }
        finalizeHorizontalAlignment_() {
          if (this.outputConnection && !this.hasStatementInput && !this.bottomRow.hasNextConnection) {
            for (var t = 0, e = 0; e < this.rows.length; e++) {
              var i = this.rows[e];
              if (!u.isInputRow(i)) continue;
              t = i.elements[i.elements.length - 2];
              let o = this.getNegativeSpacing_(i.elements[1]), s = this.getNegativeSpacing_(t);
              t = o + s;
              let n = this.constants_.MIN_BLOCK_WIDTH + this.outputConnection.width * 2;
              this.width - t < n && (t = this.width - n, o = t / 2, s = t / 2), i.elements.unshift(new he(this.constants_, -o)), i.elements.push(new he(this.constants_, -s));
            }
            if (t) for (this.width -= t, this.widthWithChildren -= t, this.rightSide.xPos -= t, e = 0; e < this.rows.length; e++) i = this.rows[e], u.isTopOrBottomRow(i) && (i.elements[1].width -= t), i.width -= t, i.widthWithConnectedBlocks -= t;
          }
        }
        getNegativeSpacing_(t) {
          if (!t || !this.outputConnection) return 0;
          var e = this.outputConnection.width, i = this.outputConnection.shape.type, o = this.constants_;
          if (this.inputRows.length > 1) switch (i) {
            case o.SHAPES.ROUND:
              return i = this.constants_.MAX_DYNAMIC_CONNECTION_SHAPE_WIDTH, i = this.height / 2 > i ? i : this.height / 2, i = Gh(i, i - this.constants_.SMALL_PADDING), e - i;
            default:
              return 0;
          }
          if (u.isInlineInput(t)) {
            var s = t.connectedBlock;
            return t = s ? s.pathObject.outputShapeType : t.shape.type, t == null || s && s.outputConnection && (s.statementInputCount || s.nextConnection) || i === o.SHAPES.HEXAGONAL && i !== t ? 0 : e - this.constants_.SHAPE_IN_SHAPE_PADDING[i][t];
          }
          if (u.isField(t)) {
            if (i === o.SHAPES.ROUND && t.field instanceof vo) return e - 2.75 * o.GRID_UNIT;
            let n = s = this.constants_.SHAPE_IN_SHAPE_PADDING[i][0];
            return i === o.SHAPES.ROUND && (i = Gh(e, t.height / 2) + o.SMALL_PADDING, n = Math.min(e, Math.max(s, i))), e - n;
          }
          return u.isIcon(t) ? this.constants_.SMALL_PADDING : 0;
        }
        finalizeVerticalAlignment_() {
          if (!this.outputConnection) for (let o = 2; o < this.rows.length - 1; o += 2) {
            let s = this.rows[o - 1], n = this.rows[o], l = this.rows[o + 1];
            var t = o === 2, e = o + 2 >= this.rows.length - 1 ? !!this.bottomRow.hasNextConnection : !!l.precedesStatement;
            if (t ? this.topRow.hasPreviousConnection : s.followsStatement) {
              var i = n.elements[1];
              if (i = n.elements.length === 3 && i instanceof Eu && (i.field instanceof go || i.field instanceof Eo), !t && i) s.height -= this.constants_.SMALL_PADDING, l.height -= this.constants_.SMALL_PADDING, n.height -= this.constants_.MEDIUM_PADDING;
              else if (!t && !e) s.height += this.constants_.SMALL_PADDING;
              else if (e) {
                for (t = !1, e = 0; e < n.elements.length; e++) if (i = n.elements[e], u.isInlineInput(i) && i.connectedBlock && !i.connectedBlock.isShadow() && i.connectedBlock.getHeightWidth().height >= 40) {
                  t = !0;
                  break;
                }
                t && (s.height -= this.constants_.SMALL_PADDING, l.height -= this.constants_.SMALL_PADDING);
              }
            }
          }
        }
        finalize_() {
          this.finalizeOutputConnection_(), this.finalizeHorizontalAlignment_(), this.finalizeVerticalAlignment_(), super.finalize_(), this.rightSide && (this.widthWithChildren += this.rightSide.width);
        }
      }, $p = class extends sl {
        constructor(t, e, i) {
          super(t, e, i), this.svgPathSelected = null, this.outlines = /* @__PURE__ */ new Map(), this.remainingOutlines = /* @__PURE__ */ new Set(), this.outputShapeType = null, this.constants = i;
        }
        setPath(t) {
          super.setPath(t), this.svgPathSelected && this.svgPathSelected.setAttribute("d", t);
        }
        applyColour(t) {
          super.applyColour(t);
          var e = t.getParent();
          t.isShadow() && e && this.svgPath.setAttribute("stroke", e.getColourTertiary());
          for (let i of this.outlines.values()) i.setAttribute("fill", this.style.colourTertiary);
        }
        flipRTL() {
          super.flipRTL();
          for (let e of this.outlines.values()) e.setAttribute("transform", "scale(-1 1)");
          var t;
          (t = this.svgPathSelected) == null || t.setAttribute("transform", "scale(-1 1)");
        }
        updateSelected(t) {
          this.setClass_("blocklySelected", t), t ? this.svgPathSelected || (this.svgPathSelected = v(
            g.PATH,
            { class: "blocklyPath blocklyPathSelected", stroke: this.svgPath.getAttribute("stroke") || "", fill: this.svgPath.getAttribute("fill") || "", d: this.svgPath.getAttribute("d") || "", transform: this.svgPath.getAttribute("transform") || "", role: W.NONE },
            this.svgRoot
          ), this.svgRoot.appendChild(this.svgPathSelected)) : this.svgPathSelected && (this.svgRoot.removeChild(this.svgPathSelected), this.svgPathSelected = null);
        }
        beginDrawing() {
          this.remainingOutlines.clear();
          for (let t of this.outlines.keys()) this.remainingOutlines.add(t);
        }
        endDrawing() {
          if (this.remainingOutlines.size) for (let t of this.remainingOutlines) this.removeOutlinePath(t);
          this.remainingOutlines.clear();
        }
        setOutlinePath(t, e) {
          t = this.getOutlinePath(t), t.setAttribute("d", e), t.setAttribute("fill", this.style.colourTertiary);
        }
        getOutlinePath(t) {
          if (!this.outlines.has(t)) {
            let e = v(g.PATH, { class: "blocklyOutlinePath", d: "" }, this.svgRoot);
            w(e, y.HIDDEN, !0), this.outlines.set(t, e);
          }
          return this.remainingOutlines.delete(t), this.outlines.get(t);
        }
        removeOutlinePath(t) {
          var e, i;
          (e = this.outlines.get(t)) == null || (i = e.parentNode) == null || i.removeChild(this.outlines.get(t)), this.outlines.delete(t);
        }
      }, al = class extends nl {
        constructor(t) {
          super(t);
        }
        makeConstants_() {
          return new Vp();
        }
        makeRenderInfo_(t) {
          return new jp(this, t);
        }
        makeDrawer_(t, e) {
          return new zp(t, e);
        }
        makePathObject(t, e) {
          return new $p(t, e, this.getConstants());
        }
        getConstants() {
          return this.constants_;
        }
        shouldHighlightConnection(t) {
          return super.shouldHighlightConnection(t) || t.type === T.INPUT_VALUE;
        }
      };
      xs("zelos", al);
      var hl = class {
        constructor(t) {
          this.staticConn = this.draggedConn = this.markerConn = this.fadedBlock = null, this.workspace = t.workspace, this.insertionMarker = new Af();
        }
        previewReplacement(t, e, i) {
          r.Ub++;
          try {
            this.hidePreview(), this.fadedBlock = i, i.fadeForReplacement(!0), this.workspace.getRenderer().shouldHighlightConnection(e) && (e.highlight(), this.staticConn = e);
          } finally {
            r.Ub--;
          }
        }
        previewConnection(t, e) {
          if (t !== this.draggedConn || e !== this.staticConn) {
            r.Ub++;
            try {
              this.hidePreview(), this.shouldUseMarkerPreview(t, e) && (this.shouldUseFastInsertionMarkers() ? this.insertionMarker.show(e, t) : this.markerConn = this.previewMarker(t, e)), this.workspace.getRenderer().shouldHighlightConnection(e) && e.highlight(), this.workspace.getRenderer().shouldHighlightConnection(t) && t.highlight(), this.draggedConn = t, this.staticConn = e;
            } finally {
              r.Ub--;
            }
          }
        }
        shouldUseMarkerPreview(t, e) {
          return e.type === T.PREVIOUS_STATEMENT || e.type === T.NEXT_STATEMENT || !(this.workspace.getRenderer() instanceof al);
        }
        previewMarker(t, e) {
          var i = t.getSourceBlock(), o = this.createInsertionMarker(i), s = this.getMatchingConnection(
            i,
            o,
            t
          );
          if (!s) return null;
          o.queueRender(), Ne(), s.connect(e);
          var n = { x: e.x - s.x, y: e.y - s.y }, l = s.getOffsetInBlock().clone();
          return te().then(() => {
            if (!o.isDeadOrDying()) {
              r.Ub++;
              try {
                o?.positionNearConnection(s, n, l), o?.getSvgRoot().setAttribute("visibility", "visible");
              } finally {
                r.Ub--;
              }
            }
          }), s;
        }
        serializeBlockToInsertionMarker(t) {
          var e = ee(t, { addCoordinates: !1, addInputBlocks: !1, addNextBlocks: !1, doFullSerialization: !1 });
          if (!e) throw Error(`Failed to serialize source block. ${t.toDevString()}`);
          return e;
        }
        createInsertionMarker(t) {
          t = this.serializeBlockToInsertionMarker(t), t = Fi(t, this.workspace);
          for (let e of t.getDescendants(!1)) e.setInsertionMarker(!0);
          return t.initSvg(), t.getSvgRoot().setAttribute("visibility", "hidden"), t;
        }
        getMatchingConnection(t, e, i) {
          if (t = t.getConnections_(!0), e = e.getConnections_(!0), t.length !== e.length) return null;
          for (let o = 0; o < t.length; o++) if (t[o] === i) return e[o];
          return null;
        }
        hidePreview() {
          r.Ub++;
          try {
            this.staticConn && (this.staticConn.unhighlight(), this.staticConn = null), this.draggedConn && (this.draggedConn.unhighlight(), this.draggedConn = null), this.fadedBlock && (this.fadedBlock.fadeForReplacement(!1), this.fadedBlock = null), this.shouldUseFastInsertionMarkers() ? this.insertionMarker.hide() : this.markerConn && (this.hideInsertionMarker(this.markerConn), this.draggedConn = this.markerConn = null);
          } finally {
            r.Ub--;
          }
        }
        hideInsertionMarker(t) {
          var e = t.getSourceBlock(), i = e.outputConnection, o;
          if ((o = e.previousConnection) != null && o.targetConnection || i != null && i.targetConnection) e.unplug(!0);
          else {
            let s;
            (s = t.targetBlock()) == null || s.unplug(!1);
          }
          e.dispose();
        }
        dispose() {
          this.hidePreview();
        }
        shouldUseFastInsertionMarkers() {
          var t = this.workspace.getRenderer();
          return t.constructor === bu || t.constructor === yu || t.constructor === al || hl.useFastInsertionMarkers;
        }
      };
      hl.useFastInsertionMarkers = !1, P(_.CONNECTION_PREVIEWER, "default", hl);
      var Di = {};
      Di.Align = r.Xn, Di.DummyInput = Ge, Di.EndRowInput = ri, Di.Input = es, Di.StatementInput = re, Di.ValueInput = r.go, Di.inputTypes = r.je;
      var Jp = !1;
      r.zq = class {
        constructor(t) {
          this.forBlock = /* @__PURE__ */ Object.create(null), this.FUNCTION_NAME_PLACEHOLDER_ = "{leCUI8hutHZI4480Dc}", this.STATEMENT_SUFFIX = this.STATEMENT_PREFIX = this.INFINITE_LOOP_TRAP = null, this.INDENT = "  ", this.COMMENT_WRAP = 60, this.ORDER_OVERRIDES = [], this.isInitialized = null, this.RESERVED_WORDS_ = "", this.definitions_ = /* @__PURE__ */ Object.create(null), this.functionNames_ = /* @__PURE__ */ Object.create(null), this.nameDB_ = void 0, this.name_ = t, this.FUNCTION_NAME_PLACEHOLDER_REGEXP_ = new RegExp(this.FUNCTION_NAME_PLACEHOLDER_, "g");
        }
        workspaceToCode(t) {
          t || (console.warn("No workspace specified in workspaceToCode call.  Guessing."), t = de);
          var e = [];
          this.init(t), t = t.getTopBlocks(!0);
          for (let i = 0, o; o = t[i]; i++) {
            let s = this.blockToCode(o);
            Array.isArray(s) && (s = s[0]), s && (o.outputConnection && (s = this.scrubNakedValue(s), this.STATEMENT_PREFIX && !o.suppressPrefixSuffix && (s = this.injectId(this.STATEMENT_PREFIX, o) + s), this.STATEMENT_SUFFIX && !o.suppressPrefixSuffix && (s += this.injectId(this.STATEMENT_SUFFIX, o))), e.push(s));
          }
          return e = e.join(`
`), e = this.finish(e), e = e.replace(
            /^\s+\n/,
            ""
          ), e = e.replace(/\n\s+$/, `
`), e = e.replace(/[ \t]+\n/g, `
`);
        }
        prefixLines(t, e) {
          return e + t.replace(/(?!\n$)\n/g, `
` + e);
        }
        allNestedComments(t) {
          var e = [];
          t = t.getDescendants(!0);
          for (let i = 0; i < t.length; i++) {
            let o = t[i].getCommentText();
            o && e.push(o);
          }
          return e.length && e.push(""), e.join(`
`);
        }
        blockToCode(t, e) {
          if (this.isInitialized === !1 && console.warn("CodeGenerator init was not called before blockToCode was called."), !t) return "";
          if (!t.isEnabled()) return e ? "" : this.blockToCode(t.getNextBlock());
          if (t.isInsertionMarker()) return e ? "" : this.blockToCode(t.getChildren(!1)[0]);
          var i = this.forBlock[t.type];
          if (typeof i != "function") throw Error(`${this.name_} generator does not know how to generate code for block type "${t.type}".`);
          if (i = i.call(t, t, this), Array.isArray(i)) {
            if (!t.outputConnection) throw TypeError("Expecting string from statement block: " + t.type);
            return [this.scrub_(t, i[0], e), i[1]];
          }
          if (typeof i == "string") return this.STATEMENT_PREFIX && !t.suppressPrefixSuffix && (i = this.injectId(this.STATEMENT_PREFIX, t) + i), this.STATEMENT_SUFFIX && !t.suppressPrefixSuffix && (i += this.injectId(this.STATEMENT_SUFFIX, t)), this.scrub_(t, i, e);
          if (i === null) return "";
          throw SyntaxError("Invalid code generated: " + i);
        }
        valueToCode(t, e, i) {
          if (isNaN(i)) throw TypeError("Expecting valid order from block: " + t.type);
          var o = t.getInputTargetBlock(e);
          if (!o && !t.getInput(e)) throw ReferenceError(`Input "${e}" doesn't exist on "${t.type}"`);
          if (!o || (e = this.blockToCode(o), e === "")) return "";
          if (!Array.isArray(e)) throw TypeError(`Expecting tuple from value block: ${o.type} See docs.blockly.com/guides/create-custom-blocks/code-generation/overview/ for more information`);
          if (t = e[0], e = e[1], isNaN(e)) throw TypeError("Expecting valid order from value block: " + o.type);
          if (!t) return "";
          o = !1;
          var s = Math.floor(i), n = Math.floor(e);
          if (s <= n && (s !== n || s !== 0 && s !== 99)) {
            for (o = !0, s = 0; s < this.ORDER_OVERRIDES.length; s++) if (this.ORDER_OVERRIDES[s][0] === i && this.ORDER_OVERRIDES[s][1] === e) {
              o = !1;
              break;
            }
          }
          return o && (t = "(" + t + ")"), t;
        }
        statementToCode(t, e) {
          var i = t.getInputTargetBlock(e);
          if (!i && !t.getInput(e)) throw ReferenceError(`Input "${e}" doesn't exist on "${t.type}"`);
          if (t = this.blockToCode(i), typeof t != "string") throw TypeError("Expecting code from statement block: " + (i && i.type));
          return t && (t = this.prefixLines(t, this.INDENT)), t;
        }
        addLoopTrap(t, e) {
          return this.INFINITE_LOOP_TRAP && (t = this.prefixLines(this.injectId(this.INFINITE_LOOP_TRAP, e), this.INDENT) + t), this.STATEMENT_SUFFIX && !e.suppressPrefixSuffix && (t = this.prefixLines(this.injectId(this.STATEMENT_SUFFIX, e), this.INDENT) + t), this.STATEMENT_PREFIX && !e.suppressPrefixSuffix && (t += this.prefixLines(this.injectId(this.STATEMENT_PREFIX, e), this.INDENT)), t;
        }
        injectId(t, e) {
          return e = e.id.replace(/\$/g, "$$$$"), t.replace(/%1/g, "'" + e + "'");
        }
        addReservedWords(t) {
          this.RESERVED_WORDS_ += t + ",";
        }
        provideFunction_(t, e) {
          if (!this.definitions_[t]) {
            let i = this.nameDB_.getDistinctName(t, r.P.PROCEDURE);
            this.functionNames_[t] = i, Array.isArray(e) && (e = e.join(`
`)), e = e.trim().replace(this.FUNCTION_NAME_PLACEHOLDER_REGEXP_, i);
            let o;
            for (; o !== e; ) o = e, e = e.replace(/^(( {2})*) {2}/gm, "$1\0");
            e = e.replace(/\0/g, this.INDENT), this.definitions_[t] = e;
          }
          return this.functionNames_[t];
        }
        getVariableName(t) {
          return this.getName(
            t,
            r.P.VARIABLE
          );
        }
        getProcedureName(t) {
          return this.getName(t, r.P.PROCEDURE);
        }
        getName(t, e) {
          if (!this.nameDB_) throw Error("Name database is not defined. You must initialize `nameDB_` in your generator class and call `init` first.");
          return this.nameDB_.getName(t, e);
        }
        init() {
          this.definitions_ = /* @__PURE__ */ Object.create(null), this.functionNames_ = /* @__PURE__ */ Object.create(null);
        }
        scrub_(t, e) {
          return e;
        }
        finish(t) {
          return this.definitions_ = /* @__PURE__ */ Object.create(null), this.functionNames_ = /* @__PURE__ */ Object.create(null), t;
        }
        scrubNakedValue(t) {
          return t;
        }
      };
      var ku = class extends qr {
        constructor(t) {
          super(t);
        }
        setMetrics_(t) {
          if (this.isVisible()) {
            var e = this.workspace_.getMetricsManager(), i = e.getScrollMetrics(), o = e.getViewMetrics();
            e = e.getAbsoluteMetrics(), typeof t.y == "number" && (this.workspace_.scrollY = -(i.top + (i.height - o.height) * t.y)), this.workspace_.translate(this.workspace_.scrollX + e.left, this.workspace_.scrollY + e.top);
          }
        }
        getX() {
          if (!this.isVisible()) return 0;
          var t = this.targetWorkspace.getMetricsManager(), e = t.getAbsoluteMetrics(), i = t.getViewMetrics();
          return t = t.getToolboxMetrics(), this.targetWorkspace.toolboxPosition === this.toolboxPosition_ ? this.targetWorkspace.getToolbox() ? this.toolboxPosition_ === I.LEFT ? t.width : i.width - this.getWidth() : this.toolboxPosition_ === I.LEFT ? 0 : i.width : this.toolboxPosition_ === I.LEFT ? 0 : i.width + e.left - this.getWidth();
        }
        getY() {
          return 0;
        }
        position() {
          if (this.isVisible() && this.targetWorkspace.isVisible()) {
            var t = this.targetWorkspace.getMetricsManager().getViewMetrics();
            this.height_ = t.height;
            var e = this.getWidth() - this.CORNER_RADIUS;
            this.setBackgroundPath(
              e,
              t.height - 2 * this.CORNER_RADIUS
            ), t = this.getX(), e = this.getY(), this.positionAt_(this.getWidth(), this.getHeight(), t, e);
          }
        }
        setBackgroundPath(t, e) {
          var i = this.toolboxPosition_ === I.RIGHT, o = t + this.CORNER_RADIUS;
          o = ["M " + (i ? o : 0) + ",0"], o.push("h", i ? -t : t), o.push("a", this.CORNER_RADIUS, this.CORNER_RADIUS, 0, 0, i ? 0 : 1, i ? -this.CORNER_RADIUS : this.CORNER_RADIUS, this.CORNER_RADIUS), o.push("v", Math.max(0, e)), o.push("a", this.CORNER_RADIUS, this.CORNER_RADIUS, 0, 0, i ? 0 : 1, i ? this.CORNER_RADIUS : -this.CORNER_RADIUS, this.CORNER_RADIUS), o.push("h", i ? t : -t), o.push("z"), this.svgBackground_.setAttribute("d", o.join(" "));
        }
        scrollToStart() {
          var t;
          (t = this.workspace_.scrollbar) == null || t.setY(0);
        }
        wheel_(t) {
          var e = cs(t);
          if (e.y) {
            let i = this.workspace_.getMetricsManager(), o = i.getScrollMetrics();
            e = i.getViewMetrics().top - o.top + e.y;
            let s;
            (s = this.workspace_.scrollbar) == null || s.setY(e), As(this.workspace_), Oe();
          }
          t.preventDefault(), t.stopPropagation();
        }
        layout_(t) {
          this.workspace_.scale = this.targetWorkspace.scale;
          var e = this.MARGIN, i = this.RTL ? e : e + this.tabWidth_;
          for (let o of t) o.getElement().moveBy(i, e), e += o.getElement().getBoundingRectangle().getHeight();
        }
        getClientRect() {
          if (!this.svgGroup_ || this.autoClose || !this.isVisible()) return null;
          var t = this.svgGroup_.getBoundingClientRect(), e = t.left;
          return this.toolboxPosition_ === I.LEFT ? new F(-1e9, 1e9, -1e9, e + t.width) : new F(-1e9, 1e9, e, 1e9);
        }
        reflowInternal_() {
          this.workspace_.scale = this.getFlyoutScale();
          var t = this.getContents().reduce((e, i) => Math.max(e, i.getElement().getBoundingRectangle().getWidth()), 0);
          if (t += this.MARGIN * 1.5 + this.tabWidth_, t *= this.workspace_.scale, t += pt.scrollbarThickness, this.getWidth() !== t) {
            if (this.RTL) for (let e of this.getContents()) {
              let i = e.getElement().getBoundingRectangle().left, o = t / this.workspace_.scale - e.getElement().getBoundingRectangle().getWidth() - this.MARGIN - this.tabWidth_;
              e.getElement().moveBy(o - i, 0);
            }
            this.targetWorkspace.scrollbar || this.autoClose || this.targetWorkspace.getFlyout() !== this || this.toolboxPosition_ !== I.LEFT || this.targetWorkspace.translate(
              this.targetWorkspace.scrollX + t,
              this.targetWorkspace.scrollY
            ), this.width_ = t, this.position(), this.targetWorkspace.resizeContents(), this.targetWorkspace.recordDragTargets();
          }
        }
      };
      ku.registryName = "verticalFlyout", P(_.FLYOUTS_VERTICAL_TOOLBOX, "default", ku);
      var qp = class extends qr {
        constructor(t) {
          super(t), this.horizontalLayout = !0;
        }
        setMetrics_(t) {
          if (this.isVisible()) {
            var e = this.workspace_.getMetricsManager(), i = e.getScrollMetrics(), o = e.getViewMetrics();
            e = e.getAbsoluteMetrics(), typeof t.x == "number" && (this.workspace_.scrollX = -(i.left + (i.width - o.width) * t.x)), this.workspace_.translate(this.workspace_.scrollX + e.left, this.workspace_.scrollY + e.top);
          }
        }
        getX() {
          return 0;
        }
        getY() {
          if (!this.isVisible()) return 0;
          var t = this.targetWorkspace.getMetricsManager(), e = t.getAbsoluteMetrics(), i = t.getViewMetrics();
          t = t.getToolboxMetrics();
          var o = this.toolboxPosition_ === I.TOP;
          return this.targetWorkspace.toolboxPosition === this.toolboxPosition_ ? this.targetWorkspace.getToolbox() ? o ? t.height : i.height - this.getHeight() : o ? 0 : i.height : o ? 0 : i.height + e.top - this.getHeight();
        }
        position() {
          if (this.isVisible() && this.targetWorkspace.isVisible()) {
            var t = this.targetWorkspace.getMetricsManager().getViewMetrics();
            this.width_ = t.width, t = t.width - 2 * this.CORNER_RADIUS;
            var e = this.getHeight() - this.CORNER_RADIUS;
            this.setBackgroundPath(
              t,
              e
            ), t = this.getX(), e = this.getY(), this.positionAt_(this.getWidth(), this.getHeight(), t, e);
          }
        }
        setBackgroundPath(t, e) {
          var i = this.toolboxPosition_ === I.TOP, o = ["M 0," + (i ? 0 : this.CORNER_RADIUS)];
          i ? (o.push("h", t + 2 * this.CORNER_RADIUS), o.push("v", e), o.push("a", this.CORNER_RADIUS, this.CORNER_RADIUS, 0, 0, 1, -this.CORNER_RADIUS, this.CORNER_RADIUS), o.push("h", -t), o.push("a", this.CORNER_RADIUS, this.CORNER_RADIUS, 0, 0, 1, -this.CORNER_RADIUS, -this.CORNER_RADIUS)) : (o.push(
            "a",
            this.CORNER_RADIUS,
            this.CORNER_RADIUS,
            0,
            0,
            1,
            this.CORNER_RADIUS,
            -this.CORNER_RADIUS
          ), o.push("h", t), o.push("a", this.CORNER_RADIUS, this.CORNER_RADIUS, 0, 0, 1, this.CORNER_RADIUS, this.CORNER_RADIUS), o.push("v", e), o.push("h", -t - 2 * this.CORNER_RADIUS)), o.push("z"), this.svgBackground_.setAttribute("d", o.join(" "));
        }
        scrollToStart() {
          var t;
          (t = this.workspace_.scrollbar) == null || t.setX(this.RTL ? 1 / 0 : 0);
        }
        wheel_(t) {
          var e = cs(t);
          if (e = e.x || e.y) {
            let i = this.workspace_.getMetricsManager(), o = i.getScrollMetrics();
            e = i.getViewMetrics().left - o.left + e;
            let s;
            (s = this.workspace_.scrollbar) == null || s.setX(e), As(this.workspace_), Oe();
          }
          t.preventDefault(), t.stopPropagation();
        }
        layout_(t) {
          this.workspace_.scale = this.targetWorkspace.scale;
          var e = this.MARGIN, i = e + this.tabWidth_;
          this.RTL && (t = t.reverse());
          for (let o of t) t = o.getElement().getBoundingRectangle(), t = this.RTL ? i + t.getWidth() : i, o.getElement().moveBy(t, e), i += o.getElement().getBoundingRectangle().getWidth();
        }
        getClientRect() {
          if (!this.svgGroup_ || this.autoClose || !this.isVisible()) return null;
          var t = this.svgGroup_.getBoundingClientRect(), e = t.top;
          return this.toolboxPosition_ === I.TOP ? new F(-1e9, e + t.height, -1e9, 1e9) : new F(e, 1e9, -1e9, 1e9);
        }
        reflowInternal_() {
          this.workspace_.scale = this.getFlyoutScale();
          var t = this.getContents().reduce((e, i) => Math.max(e, i.getElement().getBoundingRectangle().getHeight()), 0);
          t += this.MARGIN * 1.5, t *= this.workspace_.scale, t += pt.scrollbarThickness, this.getHeight() !== t && (this.targetWorkspace.scrollbar || this.autoClose || this.targetWorkspace.getFlyout() !== this || this.toolboxPosition_ !== I.TOP || this.targetWorkspace.translate(this.targetWorkspace.scrollX, this.targetWorkspace.scrollY + t), this.height_ = t, this.position(), this.targetWorkspace.resizeContents(), this.targetWorkspace.recordDragTargets());
        }
      };
      P(_.FLYOUTS_HORIZONTAL_TOOLBOX, "default", qp);
      var nn = class extends Nt {
        constructor(t, e, i, o, s) {
          super(Z.SKIP_SETUP), this.defaultType = "", this.variableTypes = [], this.variable = null, this.SERIALIZABLE = !0, this.menuGenerator_ = nn.dropdownCreate, this.defaultVariableName = typeof t == "string" ? t : "", this.size_ = new H(0, 0), t !== Z.SKIP_SETUP && (s ? this.configure_(s) : this.setTypes(i, o), e && this.setValidator(e));
        }
        configure_(t) {
          super.configure_(t), this.setTypes(t.variableTypes, t.defaultType);
        }
        initModel() {
          var t = this.getSourceBlock();
          if (!t) throw new Et();
          this.variable || (t = r.Wd(t.workspace, null, this.defaultVariableName, this.defaultType), this.doValueUpdate_(t.getId()));
        }
        initView() {
          super.initView(), b(this.fieldGroup_, "blocklyVariableField");
        }
        shouldAddBorderRect_() {
          var t = this.getSourceBlock();
          if (!t) throw new Et();
          return super.shouldAddBorderRect_() && (!this.getConstants().FIELD_DROPDOWN_NO_BORDER_RECT_SHADOW || t.type !== "variables_get");
        }
        fromXml(t) {
          var e = this.getSourceBlock();
          if (!e) throw new Et();
          var i = t.getAttribute("id"), o = t.textContent, s = t.getAttribute("variabletype") || t.getAttribute("variableType") || "";
          if (e = r.Wd(e.workspace, i, o, s), s !== null && s !== e.getType()) throw Error("Serialized variable type with id '" + e.getId() + "' had type " + e.getType() + ", and does not match variable field that references it: " + xo(t) + ".");
          this.setValue(e.getId());
        }
        toXml(t) {
          return this.initModel(), t.id = this.variable.getId(), t.textContent = this.variable.getName(), this.variable.getType() && t.setAttribute("variabletype", this.variable.getType()), t;
        }
        saveState(t) {
          var e = this.saveLegacyState(nn);
          return e !== null || (this.initModel(), e = { id: this.variable.getId() }, t && (e.name = this.variable.getName(), e.type = this.variable.getType())), e;
        }
        loadState(t) {
          var e = this.getSourceBlock();
          if (!e) throw new Et();
          this.loadLegacyState(nn, t) || (t = r.Wd(e.workspace, t.id || null, t.name, t.type || ""), this.setValue(t.getId()));
        }
        setSourceBlock(t) {
          if (t.isShadow()) throw Error("Variable fields are not allowed to exist on shadow blocks.");
          super.setSourceBlock(t);
        }
        getValue() {
          return this.variable ? this.variable.getId() : null;
        }
        getText() {
          return this.variable ? this.variable.getName() : "";
        }
        getVariable() {
          return this.variable;
        }
        getDefaultType() {
          return this.defaultType;
        }
        getValidator() {
          return this.variable ? this.validator_ : null;
        }
        doClassValidation_(t) {
          if (t === null) return null;
          var e = this.getSourceBlock();
          if (!e) throw new Et();
          return e = r.Vd(e.workspace, t), e ? (e = e.getType(), this.typeIsAllowed(e) ? t : (console.warn("Variable type doesn't match this field!  Type was " + e), null)) : (console.warn("Variable id doesn't point to a real variable! ID was " + t), null);
        }
        doValueUpdate_(t) {
          var e = this.getSourceBlock();
          if (!e) throw new Et();
          this.variable = r.Vd(e.workspace, t), super.doValueUpdate_(t);
        }
        typeIsAllowed(t) {
          var e = this.getVariableTypes();
          if (!e) return !0;
          for (let i = 0; i < e.length; i++) if (t === e[i]) return !0;
          return !1;
        }
        getVariableTypes() {
          if (this.variableTypes) return this.variableTypes;
          if (!this.sourceBlock_ || this.sourceBlock_.isDeadOrDying()) return [""];
          var t = this.sourceBlock_.workspace.getVariableMap().getTypes();
          if (this.sourceBlock_.isInFlyout) {
            let e = this.sourceBlock_.workspace.getPotentialVariableMap();
            if (!e) return t;
            t = Array.from(/* @__PURE__ */ new Set([...t, ...e.getTypes()]));
          }
          return t;
        }
        setTypes(t = null, e = "") {
          var i = this.getText();
          if (Array.isArray(t)) {
            if (t.length === 0) throw Error(`'variableTypes' of field variable ${i} was an empty list. If you want to include all variable types, pass 'null' instead.`);
            i = !1;
            for (let o = 0; o < t.length; o++) t[o] === e && (i = !0);
            if (!i) throw Error("Invalid default type '" + e + "' in the definition of a FieldVariable");
          } else if (t !== null) throw Error(`'variableTypes' was not an array or null in the definition of FieldVariable ${i}`);
          this.defaultType = e, this.variableTypes = t;
        }
        refreshVariableName() {
          this.forceRerender();
        }
        onItemSelected_(t, e) {
          if (t = e.getValue(), this.sourceBlock_ && !this.sourceBlock_.isDeadOrDying()) {
            if (t === "RENAME_VARIABLE_ID" && this.variable) {
              r.Rd(this.sourceBlock_.workspace, this.variable);
              return;
            }
            if (t === "DELETE_VARIABLE_ID" && this.variable) {
              t = this.variable.getWorkspace(), r.$d(t, this.variable, this.sourceBlock_);
              return;
            }
          }
          this.setValue(t);
        }
        referencesVariables() {
          return !0;
        }
        static fromJson(t) {
          return new this(
            et(t.variable),
            void 0,
            void 0,
            void 0,
            t
          );
        }
        static dropdownCreate() {
          if (!this.variable) throw Error("Tried to call dropdownCreate on a variable field with no variable selected.");
          var t = this.getText(), e = [], i = this.getSourceBlock();
          if (i && !i.isDeadOrDying()) {
            i = i.workspace;
            let n = this.getVariableTypes();
            for (let l = 0; l < n.length; l++) {
              let a = n[l], c = i.getVariableMap().getVariablesOfType(a);
              if (e = e.concat(c), i.isFlyout) {
                var o = void 0, s = void 0;
                e = e.concat((s = (o = i.getPotentialVariableMap()) == null ? void 0 : o.getVariablesOfType(a)) != null ? s : []);
              }
            }
          }
          for (e.sort(Ao), o = [], s = 0; s < e.length; s++) o[s] = [e[s].getName(), e[s].getId()];
          return o.push([r.C.RENAME_VARIABLE.replace("%1", t), "RENAME_VARIABLE_ID"]), r.C.DELETE_VARIABLE && o.push([r.C.DELETE_VARIABLE.replace("%1", t), "DELETE_VARIABLE_ID"]), o;
        }
        getAriaValue() {
          return r.C.FIELD_LABEL_VARIABLE.replace("%1", super.getAriaValue());
        }
      };
      xe("field_variable", nn), r.Dq = class extends vo {
        constructor(t, e, i) {
          super(t, e, i);
        }
        initView() {
          super.initView(), this.fieldGroup_ && b(this.fieldGroup_, "blocklyTextInputField");
        }
        doClassValidation_(t) {
          return t === void 0 ? null : `${t}`;
        }
        static fromJson(t) {
          return new this(et(t.text), void 0, t);
        }
        getAriaTypeName() {
          return this.ariaTypeName || r.C.ARIA_TYPE_FIELD_TEXT_INPUT;
        }
      }, xe("field_input", r.Dq), r.Dq.prototype.DEFAULT_VALUE = "";
      var wu = class extends vo {
        constructor(t, e, i, o, s, n) {
          super(Z.SKIP_SETUP), this.min_ = -1 / 0, this.max_ = 1 / 0, this.precision_ = 0, this.decimalPlaces = null, this.spellcheck_ = !1, t !== Z.SKIP_SETUP && (n ? this.configure_(n) : this.setConstraints(e, i, o), this.setValue(t), s && this.setValidator(s));
        }
        configure_(t) {
          super.configure_(t), this.setMinInternal(t.min), this.setMaxInternal(t.max), this.setPrecisionInternal(t.precision);
        }
        setConstraints(t, e, i) {
          this.setMinInternal(t), this.setMaxInternal(e), this.setPrecisionInternal(i), this.setValue(this.getValue());
        }
        setMin(t) {
          this.setMinInternal(t), this.setValue(this.getValue());
        }
        setMinInternal(t) {
          t == null ? this.min_ = -1 / 0 : (t = Number(t), isNaN(t) || (this.min_ = t));
        }
        getMin() {
          return this.min_;
        }
        setMax(t) {
          this.setMaxInternal(t), this.setValue(this.getValue());
        }
        setMaxInternal(t) {
          t == null ? this.max_ = 1 / 0 : (t = Number(t), isNaN(t) || (this.max_ = t));
        }
        getMax() {
          return this.max_;
        }
        setPrecision(t) {
          this.setPrecisionInternal(t), this.setValue(this.getValue());
        }
        setPrecisionInternal(t) {
          this.precision_ = Number(t) || 0;
          var e = String(this.precision_);
          e.includes("e") && (e = this.precision_.toLocaleString("en-US", { maximumFractionDigits: 20 }));
          var i = e.indexOf(".");
          this.decimalPlaces = i === -1 ? t ? 0 : null : e.length - i - 1;
        }
        getPrecision() {
          return this.precision_;
        }
        doClassValidation_(t) {
          return t === null || (t = `${t}`.replace(/O/gi, "0"), t = t.replace(/,/g, ""), t = t.replace(/infinity/i, "Infinity"), t = Number(t || 0), isNaN(t)) ? null : (t = Math.min(Math.max(t, this.min_), this.max_), this.precision_ && isFinite(t) && (t = Math.round(t / this.precision_) * this.precision_), this.decimalPlaces !== null && (t = Number(t.toFixed(this.decimalPlaces))), t);
        }
        widgetCreate_() {
          var t = super.widgetCreate_();
          return this.min_ > -1 / 0 && (t.min = `${this.min_}`), this.max_ < 1 / 0 && (t.max = `${this.max_}`), t;
        }
        initView() {
          super.initView(), this.fieldGroup_ && b(this.fieldGroup_, "blocklyNumberField");
        }
        static fromJson(t) {
          return new this(t.value, void 0, void 0, void 0, void 0, t);
        }
        getAriaTypeName() {
          return this.ariaTypeName || r.C.ARIA_TYPE_FIELD_NUMBER;
        }
      };
      xe("field_number", wu), wu.prototype.DEFAULT_VALUE = 0;
      var Zp = class extends go {
        constructor(t, e, i) {
          super(String(t ?? ""), e, i), this.EDITABLE = !1, this.SERIALIZABLE = !0;
        }
        static fromJson(t) {
          return new this(et(t.text), void 0, t);
        }
      };
      xe("field_label_serializable", Zp);
      var _o = class extends Z {
        constructor(t, e, i) {
          super(Z.SKIP_SETUP), this.SERIALIZABLE = !0, this.value_ = this.value_, this.checkChar = _o.CHECK_CHAR, t !== Z.SKIP_SETUP && (i && this.configure_(i), this.setValue(t), e && this.setValidator(e));
        }
        configure_(t) {
          super.configure_(t), t.checkCharacter && (this.checkChar = t.checkCharacter);
        }
        saveState() {
          var t = this.saveLegacyState(_o);
          return t !== null ? t : this.getValueBoolean();
        }
        initView() {
          super.initView();
          var t = this.getTextElement();
          b(this.fieldGroup_, "blocklyCheckboxField"), t.style.display = this.value_ ? "block" : "none", this.recomputeAriaContext();
        }
        render_() {
          this.textContent_ && (this.textContent_.nodeValue = this.getDisplayText_()), this.updateSize_(this.getConstants().FIELD_CHECKBOX_X_OFFSET);
        }
        getDisplayText_() {
          return this.checkChar;
        }
        setCheckCharacter(t) {
          this.checkChar = t || _o.CHECK_CHAR, this.forceRerender();
        }
        showEditor_() {
          this.setValue(!this.value_);
        }
        doClassValidation_(t) {
          return t === !0 || t === "TRUE" ? "TRUE" : t === !1 || t === "FALSE" ? "FALSE" : null;
        }
        doValueUpdate_(t) {
          this.value_ = this.convertValueToBool(t), this.textElement_ && (this.textElement_.style.display = this.value_ ? "block" : "none"), this.recomputeAriaContext();
        }
        getValue() {
          return this.value_ ? "TRUE" : "FALSE";
        }
        getValueBoolean() {
          return this.value_;
        }
        getText() {
          return String(this.convertValueToBool(this.value_));
        }
        convertValueToBool(t) {
          return typeof t == "string" ? t === "TRUE" : !!t;
        }
        getAriaTypeName() {
          return this.ariaTypeName || r.C.ARIA_TYPE_FIELD_CHECKBOX;
        }
        getAriaValue() {
          return this.convertValueToBool(this.value_) ? r.C.FIELD_LABEL_CHECKBOX_CHECKED : r.C.FIELD_LABEL_CHECKBOX_UNCHECKED;
        }
        static fromJson(t) {
          return new this(
            t.checked,
            void 0,
            t
          );
        }
        recomputeAriaContext() {
          if (!super.recomputeAriaContext()) return !1;
          var t = this.getFocusableElement();
          w(t, y.HIDDEN, !1), G(t, W.CHECKBOX);
          var e = this.convertValueToBool(this.value_);
          return w(t, y.CHECKED, e), e = this.getAriaTypeName(), w(t, y.LABEL, e), !0;
        }
      };
      _o.CHECK_CHAR = "✓", xe("field_checkbox", _o), _o.prototype.DEFAULT_VALUE = !1;
      var Qp = class {
        constructor(t) {
          this.draggable = t, this.dragTarget = null, this.revertShouldDelete = !1, t instanceof ut && t.workspace.isFlyout && (this.revertShouldDelete = !0), this.startLoc = t.getRelativeToSurfaceXY();
        }
        onDragStart(t) {
          return r.gd || r.B(!0), this.draggable = this.draggable.startDrag(t), this.startLoc = this.draggable.getRelativeToSurfaceXY(), this.draggable;
        }
        onDrag(t, e) {
          this.moveDraggable(t, e), (t = t instanceof PointerEvent ? t : null) && (t = new m(t.clientX, t.clientY), ie(this.draggable) && this.draggable.setDeleteStyle(this.wouldDeleteDraggable(
            t,
            this.draggable
          )), this.updateDragTarget(t));
        }
        updateDragTarget(t) {
          if (t = this.draggable.workspace.getDragTarget(t), this.dragTarget !== t) {
            let e;
            (e = this.dragTarget) == null || e.onDragExit(this.draggable), t?.onDragEnter(this.draggable);
          }
          t?.onDragOver(this.draggable), this.dragTarget = t;
        }
        moveDraggable(t, e) {
          e = this.pixelsToWorkspaceUnits(e), e = m.sum(this.startLoc, e), this.draggable.drag(e, t);
        }
        wouldDeleteDraggable(t, e) {
          return (t = this.draggable.workspace.getDragTarget(t)) && this.draggable.workspace.getComponentManager().hasCapability(
            t.id,
            nt.Capability.DELETE_AREA
          ) ? t.wouldDelete(e) : !1;
        }
        onDragEnd(t) {
          var e = r.gd, i = t instanceof PointerEvent ? t : null;
          if (i) {
            if (i = new m(i.clientX, i.clientY), this.draggable.workspace.getDragTarget(i)) {
              var o;
              (o = this.dragTarget) == null || o.onDrop(this.draggable);
            }
            o = !1, this.shouldReturnToStart(i, this.draggable) && (o = !0, this.draggable.revertDrag()), (i = ie(this.draggable) && this.wouldDeleteDraggable(i, this.draggable)) && ie(this.draggable) ? (this.draggable.endDrag(t, ve.DELETE), r.B(e), this.draggable.dispose()) : this.draggable.endDrag(
              t,
              o ? ve.REVERT : ve.COMMIT
            ), r.B(!1), !i && li(this.draggable) && r.t().focusNode(this.draggable);
          } else this.draggable.endDrag(t, ve.COMMIT), li(this.draggable) && r.t().focusNode(this.draggable);
        }
        onDragRevert(t) {
          this.revertShouldDelete && ie(this.draggable) ? (this.draggable.endDrag(t, ve.DELETE), this.draggable.dispose()) : (this.draggable.revertDrag(), li(this.draggable) && r.t().focusNode(this.draggable));
        }
        shouldReturnToStart(t, e) {
          return (t = this.draggable.workspace.getDragTarget(t)) ? t.shouldPreventMove(e) : !1;
        }
        pixelsToWorkspaceUnits(t) {
          return t = new m(t.x / this.draggable.workspace.scale, t.y / this.draggable.workspace.scale), this.draggable.workspace.isMutator && t.scale(1 / this.draggable.workspace.options.parentWorkspace.scale), t;
        }
      };
      P(_.BLOCK_DRAGGER, "default", Qp);
      var rn = {};
      rn.BlockDragStrategy = Zg, rn.BubbleDragStrategy = Wg, rn.CommentDragStrategy = Bg, rn.Dragger = Qp;
      var Xe = {};
      Xe.BottomRow = Kp, Xe.ConstantProvider = Vp, Xe.Drawer = zp, Xe.PathObject = $p, Xe.RenderInfo = jp, Xe.Renderer = al, Xe.RightConnectionShape = Xp, Xe.StatementInput = ll, Xe.TopRow = Yp, lc();
      var wt = {};
      wt.registerCleanup = Kh, wt.registerCollapse = Yh, wt.registerCollapseExpandBlock = tc, wt.registerComment = Zh, wt.registerCommentCreate = rc, wt.registerCommentDelete = sc, wt.registerCommentDuplicate = nc, wt.registerCommentOptions = function() {
        nc(), sc(), rc();
      }, wt.registerDefaultOptions = lc, wt.registerDelete = ic, wt.registerDeleteAll = Jh, wt.registerDisable = ec, wt.registerDuplicate = qh, wt.registerExpand = jh, wt.registerHelp = oc, wt.registerInline = Qh, wt.registerRedo = zh, wt.registerUndo = Vh;
      var tf = class {
        canConnect(t, e, i, o) {
          return this.canConnectWithReason(t, e, i, o) === X.CAN_CONNECT;
        }
        canConnectWithReason(t, e, i, o) {
          var s = this.doSafetyChecks(t, e);
          return s !== X.CAN_CONNECT ? s : this.doTypeChecks(t, e) ? i && !this.doDragChecks(t, e, o || 0) ? X.REASON_DRAG_CHECKS_FAILED : X.CAN_CONNECT : X.REASON_CHECKS_FAILED;
        }
        getErrorMessage(t, e, i) {
          switch (t) {
            case X.REASON_SELF_CONNECTION:
              return "Attempted to connect a block to itself.";
            case X.REASON_DIFFERENT_WORKSPACES:
              return "Blocks not on same workspace.";
            case X.REASON_WRONG_TYPE:
              return "Attempt to connect incompatible types.";
            case X.REASON_TARGET_NULL:
              return "Target connection is null.";
            case X.REASON_CHECKS_FAILED:
              return "Connection checks failed. " + (e + " expected " + e.getCheck() + ", found " + i.getCheck());
            case X.REASON_SHADOW_PARENT:
              return "Connecting non-shadow to shadow block.";
            case X.REASON_DRAG_CHECKS_FAILED:
              return "Drag checks failed.";
            case X.REASON_PREVIOUS_AND_OUTPUT:
              return "Block would have an output and a previous connection.";
            default:
              return "Unknown connection failure: this should never happen!";
          }
        }
        doSafetyChecks(t, e) {
          if (!t || !e) return X.REASON_TARGET_NULL;
          if (t.isSuperior())
            var i = t.getSourceBlock(), o = e.getSourceBlock(), s = e;
          else o = t.getSourceBlock(), i = e.getSourceBlock(), s = t, t = e;
          return i === o ? X.REASON_SELF_CONNECTION : s.type !== ho[t.type] ? X.REASON_WRONG_TYPE : i.workspace !== o.workspace ? X.REASON_DIFFERENT_WORKSPACES : i.isShadow() && !o.isShadow() ? X.REASON_SHADOW_PARENT : s.type === T.OUTPUT_VALUE && o.previousConnection && o.previousConnection.isConnected() || s.type === T.PREVIOUS_STATEMENT && o.outputConnection && o.outputConnection.isConnected() ? X.REASON_PREVIOUS_AND_OUTPUT : X.CAN_CONNECT;
        }
        doTypeChecks(t, e) {
          if (t = t.getCheck(), e = e.getCheck(), !t || !e) return !0;
          for (let i = 0; i < t.length; i++) if (e.includes(t[i])) return !0;
          return !1;
        }
        doDragChecks(t, e, i) {
          if (t.distanceFrom(e) > i || e.getSourceBlock().isInsertionMarker()) return !1;
          switch (e.type) {
            case T.PREVIOUS_STATEMENT:
              return this.canConnectToPrevious_(t, e);
            case T.OUTPUT_VALUE:
              if (e.isConnected() && !e.targetBlock().isInsertionMarker() || t.isConnected()) return !1;
              break;
            case T.INPUT_VALUE:
              if (e.isConnected() && !e.targetBlock().isMovable() && !e.targetBlock().isShadow()) return !1;
              break;
            case T.NEXT_STATEMENT:
              if (e.isConnected() && !t.getSourceBlock().nextConnection && !e.targetBlock().isShadow() && e.targetBlock().nextConnection || e.targetBlock() && !e.targetBlock().isMovable() && !e.targetBlock().isShadow()) return !1;
              break;
            default:
              return !1;
          }
          return !Ws.includes(e);
        }
        canConnectToPrevious_(t, e) {
          return t.targetConnection || Ws.includes(e) ? !1 : e.targetConnection ? (t = e.targetBlock(), t.isInsertionMarker() ? !t.getPreviousBlock() : !1) : !0;
        }
      };
      P(_.CONNECTION_CHECKER, "default", tf);
      var ef = class {
        load(t, e) {
          return t = new Gt(e.getWorkspace(), e.targetWorkspace, t, !1), t.show(), new ss(t, "button");
        }
        gapForItem(t, e) {
          return e;
        }
        disposeItem(t) {
          t = t.getElement(), t instanceof Gt && t.dispose();
        }
        getType() {
          return "button";
        }
      };
      P(_.FLYOUT_INFLATER, "button", ef);
      var ln = {};
      ln.Bubble = j, ln.MiniWorkspaceBubble = si, ln.TextBubble = Qg, ln.TextInputBubble = ru;
      var of = class {
        constructor() {
          this.permanentlyDisabledBlocks = /* @__PURE__ */ new Set(), this.listeners = /* @__PURE__ */ new Map(), this.capacityWrapper = this.filterFlyoutBasedOnCapacity.bind(this);
        }
        load(t, e) {
          this.setFlyout(e);
          var i = this.createBlock(t, e.getWorkspace());
          i.isEnabled() ? this.updateStateBasedOnCapacity(i) : this.permanentlyDisabledBlocks.add(i), i.getDescendants(!1).forEach((s) => {
            s.isInFlyout = !0;
            var n = s.getFocusableElement(), l = s.pathObject.svgPath;
            l !== n && (w(l, y.HIDDEN, !0), G(l, W.NONE)), s === i ? G(n, W.OPTION) : (w(n, y.HIDDEN, !0), G(n, W.NONE));
          }), t = i.getIcons().filter((s) => {
            var n;
            return (n = s.isClickableInFlyout) == null ? void 0 : n.call(s, e.autoClose);
          }).map((s) => s.getFocusableElement().id).filter((s) => !!s);
          var o = i.getConnections_(!0).map((s) => s.id);
          return t = [...t, ...o], t.length && w(i.getFocusableElement(), y.OWNS, t), this.addBlockListeners(i), new ss(i, "block");
        }
        createBlock(t, e) {
          return t.blockxml ? (t = typeof t.blockxml == "string" ? r.vc(t.blockxml) : t.blockxml, e = zi(t, e)) : (t.enabled === void 0 && (t.enabled = t.disabled !== "true" && t.disabled !== !0), t.disabledReasons === void 0 && t.enabled === !1 && (t.disabledReasons = ["MANUALLY_DISABLED"]), "x" in t && delete t.x, "y" in t && delete t.y, e = fi(t, e)), e;
        }
        gapForItem(t, e) {
          if (t.gap) var i = parseInt(String(t.gap));
          else t.blockxml && (t = typeof t.blockxml == "string" ? r.vc(t.blockxml) : t.blockxml, i = parseInt(t.getAttribute("gap")));
          return !i || isNaN(i) ? e : i;
        }
        disposeItem(t) {
          t = t.getElement(), t instanceof ut && (this.removeListeners(t.id), this.permanentlyDisabledBlocks.delete(t), t.dispose(!1, !1));
        }
        removeListeners(t) {
          var e;
          ((e = this.listeners.get(t)) != null ? e : []).forEach((i) => $(i)), this.listeners.delete(t);
        }
        setFlyout(t) {
          if (this.flyout !== t) {
            if (this.flyout) {
              let i;
              (i = this.flyout.targetWorkspace) == null || i.removeChangeListener(this.capacityWrapper);
            }
            this.flyout = t;
            var e;
            (e = this.flyout.targetWorkspace) == null || e.addChangeListener(this.capacityWrapper);
          }
        }
        updateStateBasedOnCapacity(t) {
          for (var e, i, o = (e = this.flyout) == null || (i = e.targetWorkspace) == null ? void 0 : i.isCapacityAvailable(Es(t)); t; ) t.setDisabledReason(!o, "WORKSPACE_AT_BLOCK_CAPACITY"), t = t.getNextBlock();
        }
        addBlockListeners(t) {
          var e = [];
          e.push(M(t.getSvgRoot(), "pointerdown", t, (i) => {
            var o, s, n = (o = this.flyout) == null || (s = o.targetWorkspace) == null ? void 0 : s.getGesture(i);
            n && this.flyout && (n.setStartBlock(t), n.handleFlyoutStart(i, this.flyout));
          })), e.push(jt(t.getSvgRoot(), "pointermove", null, () => {
            var i, o;
            !((i = this.flyout) == null || (o = i.targetWorkspace) == null) && o.isDragging() || t.addSelect();
          })), e.push(jt(t.getSvgRoot(), "pointerleave", null, () => {
            var i, o;
            !((i = this.flyout) == null || (o = i.targetWorkspace) == null) && o.isDragging() || t.removeSelect();
          })), this.listeners.set(t.id, e);
        }
        filterFlyoutBasedOnCapacity(t) {
          !this.flyout || t && t.type !== p.BLOCK_CREATE && t.type !== p.BLOCK_DELETE || this.flyout.getWorkspace().getTopBlocks(!1).forEach((e) => {
            this.permanentlyDisabledBlocks.has(e) || this.updateStateBasedOnCapacity(e);
          });
        }
        getType() {
          return "block";
        }
      };
      P(_.FLYOUT_INFLATER, "block", of);
      var Ye = {};
      Ye.ConstantProvider = xp, Ye.Drawer = Mp, Ye.HighlightConstantProvider = Pp, Ye.Highlighter = Bp, Ye.InlineInput = Fp, Ye.PathObject = Wp, Ye.RenderInfo = Up, Ye.Renderer = yu, Ye.StatementInput = Hp;
      var Iu = {};
      Iu.RenderInfo = Gp, Iu.Renderer = bu;
      var Nf = new lo("zelos", { colour_blocks: { colourPrimary: "#CF63CF", colourSecondary: "#C94FC9", colourTertiary: "#BD42BD" }, list_blocks: { colourPrimary: "#9966FF", colourSecondary: "#855CD6", colourTertiary: "#774DCB" }, logic_blocks: { colourPrimary: "#4C97FF", colourSecondary: "#4280D7", colourTertiary: "#3373CC" }, loop_blocks: { colourPrimary: "#0fBD8C", colourSecondary: "#0DA57A", colourTertiary: "#0B8E69" }, math_blocks: { colourPrimary: "#59C059", colourSecondary: "#46B946", colourTertiary: "#389438" }, procedure_blocks: {
        colourPrimary: "#FF6680",
        colourSecondary: "#FF4D6A",
        colourTertiary: "#FF3355"
      }, text_blocks: { colourPrimary: "#FFBF00", colourSecondary: "#E6AC00", colourTertiary: "#CC9900" }, variable_blocks: { colourPrimary: "#FF8C1A", colourSecondary: "#FF8000", colourTertiary: "#DB6E00" }, variable_dynamic_blocks: { colourPrimary: "#FF8C1A", colourSecondary: "#FF8000", colourTertiary: "#DB6E00" }, hat_blocks: { colourPrimary: "#4C97FF", colourSecondary: "#4280D7", colourTertiary: "#3373CC", hat: "cap" } }, {
        colour_category: { colour: "#CF63CF" },
        list_category: { colour: "#9966FF" },
        logic_category: { colour: "#4C97FF" },
        loop_category: { colour: "#0fBD8C" },
        math_category: { colour: "#59C059" },
        procedure_category: { colour: "#FF6680" },
        text_category: { colour: "#FFBF00" },
        variable_category: { colour: "#FF8C1A" },
        variable_dynamic_category: { colour: "#FF8C1A" }
      }), Df = { Classic: Wr, Zelos: Nf }, Su = class {
        constructor(t, e, i) {
          this.id_ = t.toolboxitemid || It(), this.level_ = (this.parent_ = i || null) ? this.parent_.getLevel() + 1 : 0, this.toolboxItemDef_ = t, this.parentToolbox_ = e, this.workspace_ = this.parentToolbox_.getWorkspace();
        }
        init() {
        }
        getDiv() {
          return null;
        }
        getClickTarget() {
          return null;
        }
        getId() {
          return this.id_;
        }
        getParent() {
          return null;
        }
        getLevel() {
          return this.level_;
        }
        isSelectable() {
          return !1;
        }
        isCollapsible() {
          return !1;
        }
        dispose() {
        }
        setVisible_() {
        }
        getFocusableElement() {
          var t = this.getDiv();
          if (!t) throw Error("Trying to access toolbox item before DOM is initialized.");
          if (!(t instanceof HTMLElement)) throw Error("Toolbox item div is unexpectedly not an HTML element.");
          return t;
        }
        getFocusableTree() {
          return this.parentToolbox_;
        }
        onNodeFocus() {
          this.getFocusableElement().scrollIntoView({ block: "nearest", inline: "nearest" });
        }
        onNodeBlur() {
        }
        canBeFocused() {
          return !0;
        }
        getParentToolbox() {
          return this.parentToolbox_;
        }
      }, Ie = class extends Su {
        constructor(t, e, i) {
          super(t, e, i), this.colour_ = this.name_ = "", this.labelDom_ = this.iconDom_ = this.rowContents_ = this.rowDiv_ = this.htmlDiv_ = null, this.isDisabled_ = this.isHidden_ = !1, this.flyoutItems_ = [], this.cssConfig_ = this.makeDefaultCssConfig_();
        }
        init() {
          this.parseCategoryDef_(this.toolboxItemDef_), this.parseContents_(this.toolboxItemDef_), this.createDom_(), this.toolboxItemDef_.hidden === "true" && this.hide();
        }
        makeDefaultCssConfig_() {
          return {
            container: "blocklyToolboxCategoryContainer",
            row: "blocklyToolboxCategory",
            rowcontentcontainer: "blocklyTreeRowContentContainer",
            icon: "blocklyToolboxCategoryIcon",
            label: "blocklyToolboxCategoryLabel",
            contents: "blocklyToolboxCategoryGroup",
            selected: "blocklyToolboxSelected",
            openicon: "blocklyToolboxCategoryIconOpen",
            closedicon: "blocklyToolboxCategoryIconClosed"
          };
        }
        parseContents_(t) {
          if ("custom" in t) this.flyoutItems_ = t.custom;
          else if (t = t.contents) for (let e = 0; e < t.length; e++) {
            let i = t[e];
            Array.isArray(this.flyoutItems_) && this.flyoutItems_.push(i);
          }
        }
        parseCategoryDef_(t) {
          this.name_ = "name" in t ? et(t.name) : "", this.colour_ = this.getColour_(t), Object.assign(this.cssConfig_, t.cssconfig || t.cssConfig);
        }
        createDom_() {
          this.htmlDiv_ = this.createContainer_(), G(this.htmlDiv_, W.TREEITEM), w(this.htmlDiv_, y.SELECTED, !1), w(this.htmlDiv_, y.LEVEL, this.level_ + 1), this.rowDiv_ = this.createRowContainer_(), this.rowDiv_.style.pointerEvents = "auto", this.htmlDiv_.appendChild(this.rowDiv_), this.rowContents_ = this.createRowContentsContainer_(), this.rowContents_.style.pointerEvents = "none", this.rowDiv_.appendChild(this.rowContents_), this.iconDom_ = this.createIconDom_(), G(this.iconDom_, W.NONE), this.rowContents_.appendChild(this.iconDom_), this.labelDom_ = this.createLabelDom_(this.name_), this.rowContents_.appendChild(this.labelDom_);
          var t = this.labelDom_.getAttribute("id");
          return t && w(this.htmlDiv_, y.LABELLEDBY, t), this.addColourBorder_(this.colour_), this.htmlDiv_;
        }
        createContainer_() {
          var t = document.createElement("div");
          t.tabIndex = -1, t.id = this.getId();
          var e = this.cssConfig_.container;
          return e && b(t, e), t;
        }
        createRowContainer_() {
          var t = document.createElement("div"), e = this.cssConfig_.row;
          return e && b(t, e), e = `${Ie.nestedPadding * this.getLevel()}px`, this.workspace_.RTL ? t.style.paddingRight = e : t.style.paddingLeft = e, t;
        }
        createRowContentsContainer_() {
          var t = document.createElement("div"), e = this.cssConfig_.rowcontentcontainer;
          return e && b(t, e), t;
        }
        createIconDom_() {
          var t = document.createElement("span");
          if (!this.parentToolbox_.isHorizontal()) {
            let e = this.cssConfig_.icon;
            e && b(t, e);
          }
          return t.style.display = "inline-block", t;
        }
        createLabelDom_(t) {
          var e = document.createElement("span");
          return e.setAttribute(
            "id",
            this.getId() + ".label"
          ), e.textContent = t, (t = this.cssConfig_.label) && b(e, t), e;
        }
        refreshTheme() {
          this.colour_ = this.getColour_(this.toolboxItemDef_), this.addColourBorder_(this.colour_);
        }
        addColourBorder_(t) {
          t && (t = Ie.borderWidth + "px solid " + (t || "#ddd"), this.workspace_.RTL ? this.rowDiv_.style.borderRight = t : this.rowDiv_.style.borderLeft = t);
        }
        getColour_(t) {
          var e = t.categorystyle || t.categoryStyle;
          if ((t = t.colour) && e) console.warn('Toolbox category "' + this.name_ + '" must not have both a style and a colour');
          else {
            if (e) return this.getColourfromStyle(e);
            if (t) return this.parseColour(t);
          }
          return "";
        }
        getColour() {
          return this.colour_;
        }
        getColourfromStyle(t) {
          var e = this.workspace_.getTheme();
          if (t && e) {
            if ((e = e.categoryStyles[t]) && e.colour) return this.parseColour(e.colour);
            console.warn('Style "' + t + '" must exist and contain a colour value');
          }
          return "";
        }
        getClickTarget() {
          return this.rowDiv_;
        }
        parseColour(t) {
          if (t = et(t), t == null || t === "") return "";
          var e = Number(t);
          return isNaN(e) ? (e = Ui(t)) ? e : (console.warn('Toolbox category "' + this.name_ + '" has unrecognized colour attribute: ' + t), "") : Ta(e);
        }
        openIcon_(t) {
          if (t) {
            var e = this.cssConfig_.closedicon;
            e && hn(t, e), (e = this.cssConfig_.openicon) && b(t, e);
          }
        }
        closeIcon_(t) {
          if (t) {
            var e = this.cssConfig_.openicon;
            e && hn(t, e), (e = this.cssConfig_.closedicon) && b(t, e);
          }
        }
        setVisible_(t) {
          this.htmlDiv_.style.display = t ? "block" : "none", this.isHidden_ = !t, this.parentToolbox_.getSelectedItem() === this && this.parentToolbox_.clearSelection();
        }
        hide() {
          this.setVisible_(!1);
        }
        show() {
          this.setVisible_(!0);
        }
        isVisible() {
          return !this.isHidden_ && this.allAncestorsExpanded_();
        }
        allAncestorsExpanded_() {
          for (var t = this; t.getParent(); ) if (t = t.getParent(), !t.isExpanded()) return !1;
          return !0;
        }
        isSelectable() {
          return this.isVisible() && !this.isDisabled_;
        }
        onClick() {
        }
        setSelected(t) {
          if (this.rowDiv_) {
            var e = this.cssConfig_.selected;
            if (t) {
              let i = this.parseColour(Ie.defaultBackgroundColour);
              this.rowDiv_.style.backgroundColor = this.colour_ || i, e && b(this.rowDiv_, e);
            } else this.rowDiv_.style.backgroundColor = "", e && Y(this.rowDiv_, e);
            w(this.htmlDiv_, y.SELECTED, t);
          }
        }
        setDisabled(t) {
          this.isDisabled_ = t, this.getDiv().setAttribute(
            "disabled",
            `${t}`
          ), t ? this.getDiv().setAttribute("disabled", "true") : this.getDiv().removeAttribute("disabled");
        }
        getName() {
          return this.name_;
        }
        getParent() {
          return this.parent_;
        }
        getDiv() {
          return this.htmlDiv_;
        }
        onNodeFocus() {
          super.onNodeFocus(), this.getParentToolbox().getSelectedItem() !== this && this.getParentToolbox().setSelectedItem(this);
        }
        getContents() {
          return this.flyoutItems_;
        }
        updateFlyoutContents(t) {
          this.flyoutItems_ = [], this.toolboxItemDef_ = typeof t == "string" ? {
            kind: this.toolboxItemDef_.kind,
            custom: t,
            id: this.toolboxItemDef_.id,
            categorystyle: this.toolboxItemDef_.categorystyle,
            colour: this.toolboxItemDef_.colour,
            cssconfig: this.toolboxItemDef_.cssconfig,
            hidden: this.toolboxItemDef_.hidden
          } : { kind: this.toolboxItemDef_.kind, name: "name" in this.toolboxItemDef_ ? this.toolboxItemDef_.name : "", contents: ms(t), id: this.toolboxItemDef_.id, categorystyle: this.toolboxItemDef_.categorystyle, colour: this.toolboxItemDef_.colour, cssconfig: this.toolboxItemDef_.cssconfig, hidden: this.toolboxItemDef_.hidden }, this.parseContents_(this.toolboxItemDef_);
        }
        dispose() {
          Q(this.htmlDiv_);
        }
      };
      Ie.registrationName = "category", Ie.nestedPadding = 19, Ie.borderWidth = 8, Ie.defaultBackgroundColour = "#57e", ce(`
.blocklyToolboxCategory:not(.blocklyToolboxSelected):hover {
  background-color: rgba(255, 255, 255, .2);
}

.blocklyToolbox[layout="h"] .blocklyToolboxCategoryContainer {
  margin: 1px 5px 1px 0;
}

.blocklyToolbox[dir="RTL"][layout="h"] .blocklyToolboxCategoryContainer {
  margin: 1px 0 1px 5px;
}

.blocklyToolboxCategory {
  height: 22px;
  line-height: 22px;
  margin-bottom: 3px;
  padding-right: 8px;
  white-space: nowrap;
}

.blocklyToolbox[dir="RTL"] .blocklyToolboxCategory {
  margin-left: 8px;
  padding-right: 0;
}

.blocklyToolboxCategoryIcon {
  background-image: url(<<<PATH>>>/sprites.svg);
  height: 16px;
  vertical-align: middle;
  visibility: hidden;
  width: 16px;
}

.blocklyToolboxCategoryIconClosed {
  background-position: -32px -1px;
}

.blocklyToolbox[dir="RTL"] .blocklyToolboxCategoryIconClosed {
  background-position: 0 -1px;
}

.blocklyToolboxSelected>.blocklyToolboxCategoryIconClosed {
  background-position: -32px -17px;
}

.blocklyToolbox[dir="RTL"] .blocklyToolboxSelected>.blocklyToolboxCategoryIconClosed {
  background-position: 0 -17px;
}

.blocklyToolboxCategoryIconOpen {
  background-position: -16px -1px;
}

.blocklyToolboxSelected>.blocklyToolboxCategoryIconOpen {
  background-position: -16px -17px;
}

.blocklyToolboxCategoryLabel {
  cursor: default;
  font: 16px sans-serif;
  padding: 0 3px;
  vertical-align: middle;
}

.blocklyToolboxDelete .blocklyToolboxCategoryLabel {
  cursor: url("<<<PATH>>>/handdelete.cur"), auto;
}

.blocklyToolboxSelected .blocklyToolboxCategoryLabel {
  color: #fff;
}
`), P(_.TOOLBOX_ITEM, Ie.registrationName, Ie);
      var an = class extends Su {
        constructor(t, e) {
          super(t, e), this.cssConfig_ = { container: "blocklyTreeSeparator" }, this.htmlDiv = null, Object.assign(this.cssConfig_, t.cssconfig || t.cssConfig);
        }
        init() {
          this.createDom_();
        }
        createDom_() {
          var t = document.createElement("div");
          t.id = this.getId();
          var e = this.cssConfig_.container;
          return e && b(t, e), G(t, W.NONE), this.htmlDiv = t;
        }
        getDiv() {
          return this.htmlDiv;
        }
        dispose() {
          Q(this.htmlDiv);
        }
        canBeFocused() {
          return !1;
        }
      };
      an.registrationName = "sep", ce(`
.blocklyTreeSeparator {
  border-bottom: solid #e5e5e5 1px;
  height: 0;
  margin: 5px 0;
}

.blocklyToolbox[layout="h"] .blocklyTreeSeparator {
  border-right: solid #e5e5e5 1px;
  border-bottom: none;
  height: auto;
  margin: 0 5px 0 5px;
  padding: 5px 0;
  width: 0;
}
`), P(_.TOOLBOX_ITEM, an.registrationName, an);
      var rs = class extends Ie {
        constructor(t, e, i) {
          super(t, e, i), this.subcategoriesDiv_ = null, this.expanded_ = !1, this.toolboxItems_ = [];
        }
        makeDefaultCssConfig_() {
          var t = super.makeDefaultCssConfig_();
          return t.contents = "blocklyToolboxCategoryGroup", t;
        }
        parseContents_(t) {
          if ("custom" in t) this.flyoutItems_ = t.custom;
          else {
            let e = t.contents;
            if (e) {
              this.flyoutItems_ = [], t = !0;
              for (let i = 0; i < e.length; i++) {
                let o = e[i];
                !pn(_.TOOLBOX_ITEM, o.kind) || o.kind.toLowerCase() === an.registrationName && t ? (this.flyoutItems_.push(o), t = !0) : (this.createToolboxItem(o), t = !1);
              }
            }
          }
        }
        createToolboxItem(t) {
          var e = t.kind;
          e.toUpperCase() === "CATEGORY" && bn(t) && (e = rs.registrationName), t = new (Mt(_.TOOLBOX_ITEM, e, void 0))(t, this.parentToolbox_, this), this.toolboxItems_.push(t);
        }
        init() {
          super.init(), this.setExpanded(this.toolboxItemDef_.expanded === "true" || this.toolboxItemDef_.expanded === !0);
        }
        createDom_() {
          super.createDom_();
          var t = this.getChildToolboxItems();
          return this.subcategoriesDiv_ = this.createSubCategoriesDom_(t), G(this.subcategoriesDiv_, W.GROUP), this.htmlDiv_.appendChild(this.subcategoriesDiv_), this.closeIcon_(this.iconDom_), w(this.htmlDiv_, y.EXPANDED, !1), this.htmlDiv_;
        }
        createIconDom_() {
          var t = document.createElement("span");
          if (!this.parentToolbox_.isHorizontal()) {
            let e = this.cssConfig_.icon;
            e && b(t, e), t.style.visibility = "visible";
          }
          return t.style.display = "inline-block", t;
        }
        createSubCategoriesDom_(t) {
          var e = document.createElement("div");
          e.style.display = "none";
          var i = this.cssConfig_.contents;
          for (i && b(e, i), i = 0; i < t.length; i++) {
            let o = t[i];
            o.init();
            let s = o.getDiv();
            if (e.appendChild(s), o.getClickTarget) {
              let n;
              (n = o.getClickTarget()) == null || n.setAttribute("id", o.getId());
            }
          }
          return e;
        }
        setExpanded(t) {
          this.expanded_ !== t && ((this.expanded_ = t) ? (this.subcategoriesDiv_.style.display = "block", this.openIcon_(this.iconDom_)) : (this.setFlyoutVisible(!1), this.subcategoriesDiv_.style.display = "none", this.closeIcon_(this.iconDom_)), w(this.htmlDiv_, y.EXPANDED, t), this.parentToolbox_.handleToolboxItemResize());
        }
        setVisible_(t) {
          this.htmlDiv_.style.display = t ? "block" : "none";
          var e = this.getChildToolboxItems();
          for (let i = 0; i < e.length; i++) e[i].setVisible_(t);
          this.isHidden_ = !t, this.parentToolbox_.getSelectedItem() === this && this.parentToolbox_.clearSelection();
        }
        isExpanded() {
          return this.expanded_;
        }
        isCollapsible() {
          return !0;
        }
        onClick() {
          if (this.flyoutItems_.length > 0) {
            var t = this.getParentToolbox();
            let e;
            if (t = t.getSelectedItem() === this && ((e = t.getFlyout()) == null ? void 0 : e.isVisible()), this.expanded_ && !t) {
              this.setFlyoutVisible(!0);
              return;
            }
          }
          this.toggleExpanded();
        }
        setFlyoutVisible(t) {
          var e;
          (e = this.parentToolbox_.getFlyout()) == null || e.setVisible(t);
        }
        toggleExpanded() {
          this.setExpanded(!this.expanded_);
        }
        getDiv() {
          return this.htmlDiv_;
        }
        getChildToolboxItems() {
          return this.toolboxItems_;
        }
      };
      rs.registrationName = "collapsibleCategory", P(_.TOOLBOX_ITEM, rs.registrationName, rs);
      var sf = class extends jr {
        constructor(t) {
          super(), this.id = "toolbox", this.contentsDiv_ = this.HtmlDiv = null, this.isVisible_ = !1, this.height_ = this.width_ = 0, this.flyout = null, this.contents = /* @__PURE__ */ new Map(), this.previouslySelectedItem_ = this.selectedItem_ = null, this.boundEvents_ = [], this.mouseDown = !1, this.navigator = new fp(this), this.workspace_ = t, this.toolboxDef_ = t.options.languageTree || { contents: [] }, this.horizontalLayout = t.options.horizontalLayout, this.RTL = t.options.RTL, this.toolboxPosition = t.options.toolboxPosition;
        }
        onShortcut() {
          return !1;
        }
        init() {
          var t = this.workspace_, e = t.getParentSvg();
          this.flyout = this.createFlyout_(), this.HtmlDiv = this.createDom_(this.workspace_);
          var i = this.flyout.createDom("svg");
          t.getInjectionDiv().insertBefore(i, e), b(i, "blocklyToolboxFlyout"), this.setVisible(!0), this.flyout.init(t), this.render(this.toolboxDef_), t = t.getThemeManager(), t.subscribe(this.HtmlDiv, "toolboxBackgroundColour", "background-color"), t.subscribe(this.HtmlDiv, "toolboxForegroundColour", "color"), this.workspace_.getComponentManager().addComponent({
            component: this,
            weight: nt.ComponentWeight.TOOLBOX_WEIGHT,
            capabilities: [nt.Capability.AUTOHIDEABLE, nt.Capability.DELETE_AREA, nt.Capability.DRAG_TARGET]
          }), r.t().registerTree(this, !0);
        }
        createDom_(t) {
          t = t.getParentSvg();
          var e = this.createContainer_();
          e.id = It(), this.contentsDiv_ = this.createContentsContainer_(), G(this.contentsDiv_, W.TREE), e.appendChild(this.contentsDiv_);
          var i;
          return (i = t.parentNode) == null || i.insertBefore(e, t), this.attachEvents_(e, this.contentsDiv_), e;
        }
        createContainer_() {
          var t = document.createElement("div");
          return t.setAttribute("layout", this.isHorizontal() ? "h" : "v"), b(t, "blocklyToolbox"), t.setAttribute("dir", this.RTL ? "RTL" : "LTR"), t;
        }
        createContentsContainer_() {
          var t = document.createElement("div");
          return b(t, "blocklyToolboxCategoryGroup"), this.isHorizontal() && (t.style.flexDirection = "row"), t;
        }
        attachEvents_(t, e) {
          var i = M(t, "pointerdown", this, this.onClick_, !1);
          this.boundEvents_.push(i), t = jt(t, "pointerup", this, () => {
            this.mouseDown = !1;
          }), this.boundEvents_.push(t), e = M(e, "keydown", this, this.onKeyDown_, !1), this.boundEvents_.push(e);
        }
        onClick_(t) {
          var e = () => {
            r.t().focusNode(this), this.clearSelection(), de.hideChaff(!1), t.preventDefault();
          };
          if (this.mouseDown = !0, _e(t) || t.target === this.HtmlDiv) e();
          else {
            var i = t.target.getAttribute("id");
            i && (i = this.getToolboxItemById(i), i == null ? 0 : i.isSelectable()) && (i.onClick(t), i === this.getSelectedItem() ? e() : (this.setSelectedItem(i), de.hideChaff(!0)));
          }
          Ft = null;
        }
        onKeyDown_(t) {
          var e = !1;
          switch (t.key) {
            case "ArrowLeft":
              e = this.toggleSelectedItem(!1);
              break;
            case "ArrowRight":
              e = this.toggleSelectedItem(!0);
              break;
            case "Escape":
              r.t().focusTree(this.getWorkspace()), e = !0;
          }
          e && (t.preventDefault(), t.stopPropagation());
        }
        createFlyout_() {
          var t = this.workspace_, e = t.copyOptionsForFlyout();
          return e.toolboxPosition = t.options.toolboxPosition, new (t.horizontalLayout ? Pt(_.FLYOUTS_HORIZONTAL_TOOLBOX, t.options, !0) : Pt(_.FLYOUTS_VERTICAL_TOOLBOX, t.options, !0))(e);
        }
        render(t) {
          this.toolboxDef_ = t, this.contents.forEach((e) => e.dispose()), this.contents.clear(), this.renderContents_(t.contents), this.position(), this.handleToolboxItemResize();
        }
        renderContents_(t) {
          var e = document.createDocumentFragment();
          for (let o = 0; o < t.length; o++) this.createToolboxItem(t[o], e);
          var i;
          (i = this.contentsDiv_) == null || i.appendChild(e);
        }
        createToolboxItem(t, e) {
          var i = t.kind;
          if (i.toUpperCase() === "CATEGORY" && bn(t) && (i = rs.registrationName), i = Tl(_.TOOLBOX_ITEM, i.toLowerCase())) {
            t = new i(t, this), t.init(), this.addToolboxItem_(t), (i = t.getDiv()) && e.appendChild(i);
            let o;
            (o = t.getClickTarget()) == null || o.setAttribute("id", t.getId());
          }
        }
        addToolboxItem_(t) {
          if (this.contents.set(t.getId(), t), t.isCollapsible()) {
            t = t.getChildToolboxItems();
            for (let e = 0; e < t.length; e++) this.addToolboxItem_(t[e]);
          }
        }
        getToolboxItems() {
          return [...this.contents.values()];
        }
        addStyle(t) {
          t && this.HtmlDiv && b(this.HtmlDiv, t);
        }
        removeStyle(t) {
          t && this.HtmlDiv && Y(this.HtmlDiv, t);
        }
        getClientRect() {
          if (!this.HtmlDiv || !this.isVisible_) return null;
          var t = this.HtmlDiv.getBoundingClientRect(), e = t.top, i = e + t.height, o = t.left;
          return t = o + t.width, this.toolboxPosition === I.TOP ? new F(-1e7, i, -1e7, 1e7) : this.toolboxPosition === I.BOTTOM ? new F(e, 1e7, -1e7, 1e7) : this.toolboxPosition === I.LEFT ? new F(
            -1e7,
            1e7,
            -1e7,
            t
          ) : new F(-1e7, 1e7, o, 1e7);
        }
        onDragEnter() {
          J.mover.isMoving() || this.updateCursorDeleteStyle_(!0);
        }
        onDragExit() {
          J.mover.isMoving() || this.updateCursorDeleteStyle_(!1);
        }
        onDrop() {
          J.mover.isMoving() || this.updateCursorDeleteStyle_(!1);
        }
        updateWouldDelete_(t) {
          t !== this.wouldDelete_ && (this.updateCursorDeleteStyle_(!1), this.wouldDelete_ = t, this.updateCursorDeleteStyle_(!0));
        }
        updateCursorDeleteStyle_(t) {
          var e = this.wouldDelete_ ? "blocklyToolboxDelete" : "blocklyToolboxGrab";
          t ? this.addStyle(e) : this.removeStyle(e);
        }
        getToolboxItemById(t) {
          return this.contents.get(t) || null;
        }
        getWidth() {
          return this.width_;
        }
        getHeight() {
          return this.height_;
        }
        getFlyout() {
          return this.flyout;
        }
        getWorkspace() {
          return this.workspace_;
        }
        getSelectedItem() {
          return this.selectedItem_;
        }
        getPreviouslySelectedItem() {
          return this.previouslySelectedItem_;
        }
        isHorizontal() {
          return this.horizontalLayout;
        }
        position() {
          var t = this.workspace_.getMetrics(), e = this.HtmlDiv;
          if (e) {
            this.horizontalLayout ? (e.style.left = "0", e.style.height = "auto", e.style.width = "100%", this.height_ = e.offsetHeight, this.width_ = t.viewWidth, this.toolboxPosition === I.TOP ? e.style.top = "0" : e.style.bottom = "0") : (this.toolboxPosition === I.RIGHT ? e.style.right = "0" : e.style.left = "0", e.style.height = "100%", this.width_ = e.offsetWidth, this.height_ = t.viewHeight);
            var i;
            (i = this.flyout) == null || i.position();
          }
        }
        handleToolboxItemResize() {
          if (this.HtmlDiv) {
            var t = this.workspace_, e = this.HtmlDiv.getBoundingClientRect(), i = this.getFlyout(), o = this.toolboxPosition === I.LEFT ? t.scrollX + e.width + (i && !i.autoClose ? i.getWidth() : 0) : t.scrollX;
            e = this.toolboxPosition === I.TOP ? t.scrollY + e.height + (i && !i.autoClose ? i.getHeight() : 0) : t.scrollY, t.translate(o, e), Bi(t);
          }
        }
        clearSelection() {
          this.setSelectedItem(null);
        }
        refreshTheme() {
          this.contents.forEach((t) => {
            t.refreshTheme && t.refreshTheme();
          });
        }
        refreshSelection() {
          if (this.selectedItem_ && this.selectedItem_.isSelectable() && this.selectedItem_.getContents().length) {
            let t;
            (t = this.flyout) == null || t.show(this.selectedItem_.getContents());
          }
        }
        setVisible(t) {
          this.isVisible_ !== t && (this.HtmlDiv && (this.HtmlDiv.style.display = t ? "block" : "none"), this.isVisible_ = t, this.workspace_.recordDragTargets());
        }
        autoHide(t) {
          !t && this.flyout && this.flyout.autoClose && this.clearSelection();
        }
        setSelectedItem(t) {
          var e = this.selectedItem_;
          !t && !e || t && !Hi(t) || (this.shouldDeselectItem_(e, t) && e !== null && this.deselectItem_(e), this.shouldSelectItem_(e, t) && t !== null && this.selectItem_(e, t), this.updateFlyout_(e, t), this.fireSelectEvent(e, t));
        }
        shouldDeselectItem_(t, e) {
          return t !== null && (!t.isCollapsible() || t !== e);
        }
        shouldSelectItem_(t, e) {
          return e !== null && e !== t;
        }
        deselectItem_(t) {
          this.selectedItem_ = null, this.previouslySelectedItem_ = t, t.setSelected(!1), w(this.contentsDiv_, y.ACTIVEDESCENDANT, "");
        }
        selectItem_(t, e) {
          this.selectedItem_ = e, this.previouslySelectedItem_ = t, e.setSelected(!0), w(this.contentsDiv_, y.ACTIVEDESCENDANT, e.getId());
        }
        selectItemByPosition(t) {
          (t = this.getToolboxItems()[t]) && this.setSelectedItem(t);
        }
        updateFlyout_(t, e) {
          if (e && (t !== e || e.isCollapsible()) && e.getContents().length) {
            let i;
            (i = this.flyout) == null || i.show(e.getContents());
            let o;
            (o = this.flyout) == null || o.scrollToStart();
          } else {
            let i;
            (i = this.flyout) == null || i.hide();
          }
        }
        fireSelectEvent(t, e) {
          var i = t && t.getName(), o = e && e.getName();
          t === e && (o = null), t = new (D(p.TOOLBOX_ITEM_SELECT))(i, o, this.workspace_.id), N(t);
        }
        toggleSelectedItem(t) {
          var e, i;
          return nr(this.selectedItem_) && ((e = this.selectedItem_) != null && e.isCollapsible()) && ((i = this.selectedItem_) == null ? void 0 : i.isExpanded()) !== t ? (this.selectedItem_.toggleExpanded(), !0) : !1;
        }
        dispose() {
          this.workspace_.getComponentManager().removeComponent("toolbox");
          var t;
          for ((t = this.flyout) == null || t.dispose(), this.contents.forEach((e) => e.dispose()), t = 0; t < this.boundEvents_.length; t++) $(this.boundEvents_[t]);
          this.boundEvents_ = [], this.contents.clear(), this.HtmlDiv && (this.workspace_.getThemeManager().unsubscribe(this.HtmlDiv), Q(this.HtmlDiv)), r.t().unregisterTree(this);
        }
        getFocusableElement() {
          if (!this.HtmlDiv) throw Error("Toolbox DOM has not yet been created.");
          return this.HtmlDiv;
        }
        getFocusableTree() {
          return this;
        }
        onNodeFocus() {
        }
        onNodeBlur() {
        }
        canBeFocused() {
          return !0;
        }
        getRootFocusableNode() {
          return this;
        }
        getRestoredFocusableNode(t) {
          if (!t || t === this) {
            let e;
            return (e = this.getToolboxItems().find((i) => i.isSelectable())) != null ? e : null;
          }
          return null;
        }
        getNestedTrees() {
          return [];
        }
        lookUpFocusableNode(t) {
          return this.getToolboxItemById(t);
        }
        onTreeFocus(t) {
          t !== this ? this.getSelectedItem() === t || this.mouseDown || this.setSelectedItem(t) : this.clearSelection();
        }
        onTreeBlur(t) {
          var e;
          t && t === ((e = this.flyout) == null ? void 0 : e.getWorkspace()) || this.autoHide(!1);
        }
        getNavigator() {
          return this.navigator;
        }
      };
      ce(`
.blocklyToolboxDelete {
  cursor: url("<<<PATH>>>/handdelete.cur"), auto;
}

.blocklyToolboxGrab {
  cursor: url("<<<PATH>>>/handclosed.cur"), auto;
  cursor: grabbing;
  cursor: -webkit-grabbing;
}

/* Category tree in Toolbox. */
.blocklyToolbox {
  box-sizing: border-box;
  user-select: none;
  -ms-user-select: none;
  -webkit-user-select: none;
  background-color: #ddd;
  overflow-x: visible;
  overflow-y: auto;
  padding: 4px 0 4px 0;
  position: absolute;
  z-index: 70;  /* so blocks go under toolbox when dragging */
  -webkit-tap-highlight-color: transparent;  /* issue #1345 */
}

.blocklyToolboxCategoryGroup {
  display: flex;
  flex-wrap: wrap;
  flex-direction: column;
}

.blocklyToolboxCategoryGroup:focus {
  outline: none;
}
`), P(_.TOOLBOX, "default", sf);
      var Of = T.INPUT_VALUE, Lf = T.OUTPUT_VALUE, xf = T.NEXT_STATEMENT, Bf = T.PREVIOUS_STATEMENT, Mf = I.TOP, Pf = I.BOTTOM, Ff = I.LEFT, Hf = I.RIGHT;
      ns.prototype.newBlock = function(t, e) {
        return new is(this, t, e);
      }, Ot.prototype.newBlock = function(t, e) {
        return new ut(this, t, e);
      }, ns.prototype.newComment = function(t) {
        return new Hr(this, t);
      }, Ot.prototype.newComment = function(t) {
        return new ro(this, t);
      }, Ot.newTrashcan = function(t) {
        return new Np(t);
      }, si.prototype.newWorkspaceSvg = function(t) {
        return new Ot(t);
      }, r.Cj.prototype.populateProcedures = function(t) {
        t = lr(t), t = t[0].concat(t[1]);
        for (let e = 0; e < t.length; e++) this.getName(t[e][0], r.Cj.NameType.PROCEDURE);
      };
      var f = {};
      return f.Block = is, f.BlockFlyoutInflater = of, f.BlockNavigationPolicy = sp, f.BlockSvg = ut, f.Blocks = gt, f.BubbleNavigationPolicy = np, f.ButtonFlyoutInflater = ef, f.COLLAPSED_FIELD_NAME = "_TEMP_COLLAPSED_FIELD", f.COLLAPSED_INPUT_NAME = "_TEMP_COLLAPSED_INPUT", f.COLLAPSE_CHARS = 30, f.CodeGenerator = r.zq, f.CollapsibleToolboxCategory = rs, f.CommentBarButtonNavigationPolicy = rp, f.CommentEditorNavigationPolicy = lp, f.ComponentManager = nt, f.Connection = X, f.ConnectionChecker = tf, f.ConnectionDB = Qo, f.ConnectionNavigationPolicy = ap, f.ConnectionType = T, f.ContextMenu = Ii, f.ContextMenuItems = wt, f.ContextMenuRegistry = V, f.Css = dc, f.DELETE_VARIABLE_ID = "DELETE_VARIABLE_ID", f.DeleteArea = jr, f.Direction = lt, f.DragDisposition = ve, f.DragTarget = tp, f.DropDownDiv = Wt, f.Events = k, f.Extensions = ke, f.Field = Z, f.FieldCheckbox = _o, f.FieldDropdown = Nt, f.FieldImage = Eo, f.FieldLabel = go, f.FieldLabelSerializable = Zp, f.FieldNavigationPolicy = hp, f.FieldNumber = wu, f.FieldTextInput = r.Dq, f.FieldVariable = nn, f.Flyout = qr, f.FlyoutButton = Gt, f.FlyoutButtonNavigationPolicy = ip, f.FlyoutItem = ss, f.FlyoutMetricsManager = ep, f.FlyoutNavigator = Ep, f.FlyoutSeparator = $r, f.FlyoutSeparatorNavigationPolicy = op, f.FocusManager = Ht, f.FocusableTreeTraverser = At, f.Generator = r.zq, f.Gesture = Zr, f.Grid = uu, f.HorizontalFlyout = qp, f.INPUT_VALUE = Of, f.IconNavigationPolicy = cp, f.Input = es, f.InsertionMarkerPreviewer = hl, f.KeyboardMover = J, f.KeyboardNavigationController = yg, f.LabelFlyoutInflater = Lp, f.Menu = kc, f.MenuItem = br, f.MetricsManager = hu, f.MoveIndicator = Ug, f.Msg = r.C, f.NEXT_STATEMENT = xf, f.Names = r.Cj, f.NavigationDirection = ae, f.Navigator = Jr, f.OPPOSITE_TYPE = ho, f.OUTPUT_VALUE = Lf, f.Options = We, f.PREVIOUS_STATEMENT = Bf, f.PROCEDURE_CATEGORY_NAME = "PROCEDURE", f.Procedures = Zt, f.RENAME_VARIABLE_ID = "RENAME_VARIABLE_ID", f.RenderedConnection = Dt, f.Scrollbar = pt, f.ScrollbarPair = cu, f.SeparatorFlyoutInflater = vp, f.ShortcutItems = K, f.ShortcutRegistry = S, f.TOOLBOX_AT_BOTTOM = Pf, f.TOOLBOX_AT_LEFT = Ff, f.TOOLBOX_AT_RIGHT = Hf, f.TOOLBOX_AT_TOP = Mf, f.Theme = lo, f.ThemeManager = Ip, f.Themes = Df, f.Toast = Xt, f.Toolbox = sf, f.ToolboxCategory = Ie, f.ToolboxItem = Su, f.ToolboxItemNavigationPolicy = pp, f.ToolboxNavigator = fp, f.ToolboxSeparator = an, f.Tooltip = qt, f.Touch = ji, f.Trashcan = Np, f.UnattachedFieldError = Et, f.VARIABLE_CATEGORY_NAME = "VARIABLE", f.VARIABLE_DYNAMIC_CATEGORY_NAME = "VARIABLE_DYNAMIC", f.VERSION = "13.4.0", f.VariableMap = Ap, f.VariableModel = Rp, f.Variables = _t, f.VariablesDynamic = fo, f.VerticalFlyout = ku, f.WidgetDiv = be, f.Workspace = ns, f.WorkspaceAudio = Sp, f.WorkspaceCommentNavigationPolicy = up, f.WorkspaceDragger = _p, f.WorkspaceNavigationPolicy = dp, f.WorkspaceSvg = Ot, f.Xml = Yt, f.ZoomControls = Vd, f.blockAnimations = qs, f.blockRendering = q, f.browserEvents = Ze, f.bubbles = ln, f.bumpObjects = Vr, f.clipboard = we, f.comments = Si, f.common = Tt, f.config = r.Og, f.constants = { COLLAPSED_FIELD_NAME: "_TEMP_COLLAPSED_FIELD", COLLAPSED_INPUT_NAME: "_TEMP_COLLAPSED_INPUT", MANUALLY_DISABLED: "MANUALLY_DISABLED" }, f.defineBlocksWithJsonArray = ml, f.dialog = ii, f.dragging = rn, f.fieldRegistry = Ur, f.geras = Ye, f.getFocusManager = r.t, f.getMainWorkspace = vl, f.getSelected = fs, f.hasBubble = De, f.hideChaff = function(t) {
        de.hideChaff(t);
      }, f.icons = Ni, f.inject = function(t, e) {
        var i = null;
        i = typeof t == "string" ? document.getElementById(t) || document.querySelector(t) : t;
        var o;
        if (!document.contains(i) && document !== ((o = i) == null ? void 0 : o.ownerDocument)) throw Error("Error: container is not in current document");
        t = new We(e || {}), o = document.createElement("div"), b(o, "injectionDiv"), e != null && e.rtl && b(o, "blocklyRTL"), G(o, W.APPLICATION), i.appendChild(o), e = ud(o, t);
        var s = dd(o, e, t);
        return gd(s), ps(s), Bi(s), o.addEventListener("focusin", function() {
          ps(s);
        }), M(
          o,
          "keydown",
          null,
          vs
        ), pl(o), s;
      }, f.inputs = Di, f.isBoundedElement = Ka, f.isCopyable = Po, f.isDeletable = ie, f.isDraggable = Xi, f.isIcon = Fa, f.isObservable = rr, f.isPaster = function(t) {
        return t && typeof t.paste == "function";
      }, f.isRenderedElement = function(t) {
        return t && typeof t.getSvgRoot == "function";
      }, f.isSelectable = gs, f.isSerializable = ys, f.isVariableBackedParameterModel = Hl, f.keyboardNavigationController = st, f.layers = { BLOCK: 50, BUBBLE: 100 }, f.navigateBlock = oe, f.procedures = Zt, f.registry = Qe, f.renderManagement = wr, f.serialization = Rf, f.setLocale = kl, f.setParentContainer = _l, f.svgResize = Bi, f.thrasos = Iu, f.uiPosition = qi, f.utils = at, f.zelos = Xe, r.__chunk_blockly = f, r.__chunk_blockly.__namespace__ = r, r.__chunk_blockly;
    });
  })(cl)), cl.exports;
}
var zf = Vf();
const Kf = /* @__PURE__ */ Wf(zf), {
  Block: Xf,
  BlockFlyoutInflater: Yf,
  BlockNavigationPolicy: jf,
  BlockSvg: $f,
  Blocks: Jf,
  BubbleNavigationPolicy: qf,
  ButtonFlyoutInflater: Zf,
  COLLAPSED_FIELD_NAME: Qf,
  COLLAPSED_INPUT_NAME: tE,
  COLLAPSE_CHARS: eE,
  CodeGenerator: iE,
  CollapsibleToolboxCategory: oE,
  CommentBarButtonNavigationPolicy: sE,
  CommentEditorNavigationPolicy: nE,
  ComponentManager: rE,
  Connection: lE,
  ConnectionChecker: aE,
  ConnectionDB: hE,
  ConnectionNavigationPolicy: cE,
  ConnectionType: uE,
  ContextMenu: dE,
  ContextMenuItems: gE,
  ContextMenuRegistry: pE,
  Css: fE,
  DELETE_VARIABLE_ID: EE,
  DeleteArea: vE,
  Direction: _E,
  DragDisposition: mE,
  DragTarget: TE,
  DropDownDiv: CE,
  Events: yE,
  Extensions: bE,
  Field: kE,
  FieldCheckbox: wE,
  FieldDropdown: IE,
  FieldImage: SE,
  FieldLabel: RE,
  FieldLabelSerializable: AE,
  FieldNavigationPolicy: NE,
  FieldNumber: DE,
  FieldTextInput: OE,
  FieldVariable: LE,
  Flyout: xE,
  FlyoutButton: BE,
  FlyoutButtonNavigationPolicy: ME,
  FlyoutItem: PE,
  FlyoutMetricsManager: FE,
  FlyoutNavigator: HE,
  FlyoutSeparator: UE,
  FlyoutSeparatorNavigationPolicy: WE,
  FocusManager: GE,
  FocusableTreeTraverser: VE,
  Generator: zE,
  Gesture: KE,
  Grid: XE,
  HorizontalFlyout: YE,
  INPUT_VALUE: jE,
  IconNavigationPolicy: $E,
  Input: JE,
  InsertionMarkerPreviewer: qE,
  KeyboardMover: ZE,
  KeyboardNavigationController: QE,
  LabelFlyoutInflater: tv,
  Menu: ev,
  MenuItem: iv,
  MetricsManager: ov,
  MoveIndicator: sv,
  Msg: nv,
  NEXT_STATEMENT: rv,
  Names: lv,
  NavigationDirection: av,
  Navigator: hv,
  OPPOSITE_TYPE: cv,
  OUTPUT_VALUE: uv,
  Options: dv,
  PREVIOUS_STATEMENT: gv,
  PROCEDURE_CATEGORY_NAME: pv,
  Procedures: fv,
  RENAME_VARIABLE_ID: Ev,
  RenderedConnection: vv,
  Scrollbar: _v,
  ScrollbarPair: mv,
  SeparatorFlyoutInflater: Tv,
  ShortcutItems: Cv,
  ShortcutRegistry: yv,
  TOOLBOX_AT_BOTTOM: bv,
  TOOLBOX_AT_LEFT: kv,
  TOOLBOX_AT_RIGHT: wv,
  TOOLBOX_AT_TOP: Iv,
  Theme: Sv,
  ThemeManager: Rv,
  Themes: Av,
  Toast: Nv,
  Toolbox: Dv,
  ToolboxCategory: Ov,
  ToolboxItem: Lv,
  ToolboxItemNavigationPolicy: xv,
  ToolboxNavigator: Bv,
  ToolboxSeparator: Mv,
  Tooltip: Pv,
  Touch: Fv,
  Trashcan: Hv,
  UnattachedFieldError: Uv,
  VARIABLE_CATEGORY_NAME: Wv,
  VARIABLE_DYNAMIC_CATEGORY_NAME: Gv,
  VERSION: Vv,
  VariableMap: zv,
  VariableModel: Kv,
  Variables: Xv,
  VariablesDynamic: Yv,
  VerticalFlyout: jv,
  WidgetDiv: $v,
  Workspace: Jv,
  WorkspaceAudio: qv,
  WorkspaceCommentNavigationPolicy: Zv,
  WorkspaceDragger: Qv,
  WorkspaceNavigationPolicy: t_,
  WorkspaceSvg: e_,
  Xml: i_,
  ZoomControls: o_,
  blockAnimations: s_,
  blockRendering: n_,
  browserEvents: r_,
  bubbles: l_,
  bumpObjects: a_,
  clipboard: h_,
  comments: c_,
  common: u_,
  config: d_,
  constants: g_,
  defineBlocksWithJsonArray: p_,
  dialog: f_,
  dragging: E_,
  fieldRegistry: v_,
  geras: __,
  getFocusManager: m_,
  getMainWorkspace: T_,
  getSelected: C_,
  hasBubble: y_,
  hideChaff: b_,
  icons: k_,
  inject: w_,
  inputs: I_,
  isBoundedElement: S_,
  isCopyable: R_,
  isDeletable: A_,
  isDraggable: N_,
  isIcon: D_,
  isObservable: O_,
  isPaster: L_,
  isRenderedElement: x_,
  isSelectable: B_,
  isSerializable: M_,
  isVariableBackedParameterModel: P_,
  keyboardNavigationController: F_,
  layers: H_,
  navigateBlock: U_,
  procedures: W_,
  registry: G_,
  renderManagement: V_,
  serialization: z_,
  setLocale: K_,
  setParentContainer: X_,
  svgResize: Y_,
  thrasos: j_,
  uiPosition: $_,
  utils: J_,
  zelos: q_
} = Kf, Q_ = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Block: Xf,
  BlockFlyoutInflater: Yf,
  BlockNavigationPolicy: jf,
  BlockSvg: $f,
  Blocks: Jf,
  BubbleNavigationPolicy: qf,
  ButtonFlyoutInflater: Zf,
  COLLAPSED_FIELD_NAME: Qf,
  COLLAPSED_INPUT_NAME: tE,
  COLLAPSE_CHARS: eE,
  CodeGenerator: iE,
  CollapsibleToolboxCategory: oE,
  CommentBarButtonNavigationPolicy: sE,
  CommentEditorNavigationPolicy: nE,
  ComponentManager: rE,
  Connection: lE,
  ConnectionChecker: aE,
  ConnectionDB: hE,
  ConnectionNavigationPolicy: cE,
  ConnectionType: uE,
  ContextMenu: dE,
  ContextMenuItems: gE,
  ContextMenuRegistry: pE,
  Css: fE,
  DELETE_VARIABLE_ID: EE,
  DeleteArea: vE,
  Direction: _E,
  DragDisposition: mE,
  DragTarget: TE,
  DropDownDiv: CE,
  Events: yE,
  Extensions: bE,
  Field: kE,
  FieldCheckbox: wE,
  FieldDropdown: IE,
  FieldImage: SE,
  FieldLabel: RE,
  FieldLabelSerializable: AE,
  FieldNavigationPolicy: NE,
  FieldNumber: DE,
  FieldTextInput: OE,
  FieldVariable: LE,
  Flyout: xE,
  FlyoutButton: BE,
  FlyoutButtonNavigationPolicy: ME,
  FlyoutItem: PE,
  FlyoutMetricsManager: FE,
  FlyoutNavigator: HE,
  FlyoutSeparator: UE,
  FlyoutSeparatorNavigationPolicy: WE,
  FocusManager: GE,
  FocusableTreeTraverser: VE,
  Generator: zE,
  Gesture: KE,
  Grid: XE,
  HorizontalFlyout: YE,
  INPUT_VALUE: jE,
  IconNavigationPolicy: $E,
  Input: JE,
  InsertionMarkerPreviewer: qE,
  KeyboardMover: ZE,
  KeyboardNavigationController: QE,
  LabelFlyoutInflater: tv,
  Menu: ev,
  MenuItem: iv,
  MetricsManager: ov,
  MoveIndicator: sv,
  Msg: nv,
  NEXT_STATEMENT: rv,
  Names: lv,
  NavigationDirection: av,
  Navigator: hv,
  OPPOSITE_TYPE: cv,
  OUTPUT_VALUE: uv,
  Options: dv,
  PREVIOUS_STATEMENT: gv,
  PROCEDURE_CATEGORY_NAME: pv,
  Procedures: fv,
  RENAME_VARIABLE_ID: Ev,
  RenderedConnection: vv,
  Scrollbar: _v,
  ScrollbarPair: mv,
  SeparatorFlyoutInflater: Tv,
  ShortcutItems: Cv,
  ShortcutRegistry: yv,
  TOOLBOX_AT_BOTTOM: bv,
  TOOLBOX_AT_LEFT: kv,
  TOOLBOX_AT_RIGHT: wv,
  TOOLBOX_AT_TOP: Iv,
  Theme: Sv,
  ThemeManager: Rv,
  Themes: Av,
  Toast: Nv,
  Toolbox: Dv,
  ToolboxCategory: Ov,
  ToolboxItem: Lv,
  ToolboxItemNavigationPolicy: xv,
  ToolboxNavigator: Bv,
  ToolboxSeparator: Mv,
  Tooltip: Pv,
  Touch: Fv,
  Trashcan: Hv,
  UnattachedFieldError: Uv,
  VARIABLE_CATEGORY_NAME: Wv,
  VARIABLE_DYNAMIC_CATEGORY_NAME: Gv,
  VERSION: Vv,
  VariableMap: zv,
  VariableModel: Kv,
  Variables: Xv,
  VariablesDynamic: Yv,
  VerticalFlyout: jv,
  WidgetDiv: $v,
  Workspace: Jv,
  WorkspaceAudio: qv,
  WorkspaceCommentNavigationPolicy: Zv,
  WorkspaceDragger: Qv,
  WorkspaceNavigationPolicy: t_,
  WorkspaceSvg: e_,
  Xml: i_,
  ZoomControls: o_,
  blockAnimations: s_,
  blockRendering: n_,
  browserEvents: r_,
  bubbles: l_,
  bumpObjects: a_,
  clipboard: h_,
  comments: c_,
  common: u_,
  config: d_,
  constants: g_,
  defineBlocksWithJsonArray: p_,
  dialog: f_,
  dragging: E_,
  fieldRegistry: v_,
  geras: __,
  getFocusManager: m_,
  getMainWorkspace: T_,
  getSelected: C_,
  hasBubble: y_,
  hideChaff: b_,
  icons: k_,
  inject: w_,
  inputs: I_,
  isBoundedElement: S_,
  isCopyable: R_,
  isDeletable: A_,
  isDraggable: N_,
  isIcon: D_,
  isObservable: O_,
  isPaster: L_,
  isRenderedElement: x_,
  isSelectable: B_,
  isSerializable: M_,
  isVariableBackedParameterModel: P_,
  keyboardNavigationController: F_,
  layers: H_,
  navigateBlock: U_,
  procedures: W_,
  registry: G_,
  renderManagement: V_,
  serialization: z_,
  setLocale: K_,
  setParentContainer: X_,
  svgResize: Y_,
  thrasos: j_,
  uiPosition: $_,
  utils: J_,
  zelos: q_
}, Symbol.toStringTag, { value: "Module" }));
export {
  $f as B,
  yE as E,
  OE as F,
  Sv as T,
  $v as W,
  C_ as a,
  Y_ as b,
  Jf as c,
  p_ as d,
  Av as e,
  v_ as f,
  Wf as g,
  Q_ as h,
  w_ as i,
  Vf as r,
  K_ as s
};
