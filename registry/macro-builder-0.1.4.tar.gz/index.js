import { l as e, o as l } from "./assets/index-C4WLIte_.js";
export {
  e as locales,
  l as openMacroBuilder
};
